/*    */ package org.springframework.context.expression;
/*    */ 
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.expression.AccessException;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.expression.PropertyAccessor;
/*    */ import org.springframework.expression.TypedValue;
/*    */ 
/*    */ public class BeanFactoryAccessor
/*    */   implements PropertyAccessor
/*    */ {
/*    */   public boolean canRead(EvaluationContext context, Object target, String name)
/*    */     throws AccessException
/*    */   {
/* 36 */     return ((BeanFactory)target).containsBean(name);
/*    */   }
/*    */ 
/*    */   public TypedValue read(EvaluationContext context, Object target, String name) throws AccessException {
/* 40 */     return new TypedValue(((BeanFactory)target).getBean(name));
/*    */   }
/*    */ 
/*    */   public boolean canWrite(EvaluationContext context, Object target, String name) throws AccessException {
/* 44 */     return false;
/*    */   }
/*    */ 
/*    */   public void write(EvaluationContext context, Object target, String name, Object newValue) throws AccessException {
/* 48 */     throw new AccessException("Beans in a BeanFactory are read-only");
/*    */   }
/*    */ 
/*    */   public Class[] getSpecificTargetClasses() {
/* 52 */     return new Class[] { BeanFactory.class };
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.expression.BeanFactoryAccessor
 * JD-Core Version:    0.6.1
 */