/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.util.Map;
/*     */ import javax.management.MBeanServer;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.jmx.export.annotation.AnnotationMBeanExporter;
/*     */ import org.springframework.jmx.support.RegistrationPolicy;
/*     */ import org.springframework.jmx.support.WebSphereMBeanServerFactoryBean;
/*     */ import org.springframework.jndi.JndiObjectFactoryBean;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ @Configuration
/*     */ public class MBeanExportConfiguration
/*     */   implements ImportAware, BeanFactoryAware
/*     */ {
/*     */   private static final String MBEAN_EXPORTER_BEAN_NAME = "mbeanExporter";
/*     */   private AnnotationAttributes attributes;
/*     */   private BeanFactory beanFactory;
/*     */ 
/*     */   public void setImportMetadata(AnnotationMetadata importMetadata)
/*     */   {
/*  60 */     Map map = importMetadata.getAnnotationAttributes(EnableMBeanExport.class.getName());
/*  61 */     this.attributes = AnnotationAttributes.fromMap(map);
/*  62 */     Assert.notNull(this.attributes, "@EnableMBeanExport is not present on importing class " + importMetadata.getClassName());
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException
/*     */   {
/*  67 */     this.beanFactory = beanFactory;
/*     */   }
/*     */   @Bean(name={"mbeanExporter"})
/*     */   @Role(2)
/*     */   public AnnotationMBeanExporter mbeanExporter() {
/*  73 */     AnnotationMBeanExporter exporter = new AnnotationMBeanExporter();
/*  74 */     setupDomain(exporter);
/*  75 */     setupServer(exporter);
/*  76 */     setupRegistrationPolicy(exporter);
/*  77 */     return exporter;
/*     */   }
/*     */ 
/*     */   private void setupDomain(AnnotationMBeanExporter exporter) {
/*  81 */     String defaultDomain = this.attributes.getString("defaultDomain");
/*  82 */     if (StringUtils.hasText(defaultDomain))
/*  83 */       exporter.setDefaultDomain(defaultDomain);
/*     */   }
/*     */ 
/*     */   private void setupServer(AnnotationMBeanExporter exporter)
/*     */   {
/*  88 */     String server = this.attributes.getString("server");
/*  89 */     if (StringUtils.hasText(server)) {
/*  90 */       exporter.setServer((MBeanServer)this.beanFactory.getBean(server, MBeanServer.class));
/*     */     }
/*     */     else {
/*  93 */       SpecificPlatform specificPlatform = SpecificPlatform.get();
/*  94 */       if (specificPlatform != null)
/*  95 */         exporter.setServer(specificPlatform.getMBeanServer());
/*     */     }
/*     */   }
/*     */ 
/*     */   private void setupRegistrationPolicy(AnnotationMBeanExporter exporter)
/*     */   {
/* 101 */     RegistrationPolicy registrationPolicy = (RegistrationPolicy)this.attributes.getEnum("registration");
/* 102 */     exporter.setRegistrationPolicy(registrationPolicy);
/*     */   }
/*     */ 
/*     */   private static abstract enum SpecificPlatform
/*     */   {
/* 108 */     WEBLOGIC("weblogic.management.Helper"), 
/*     */ 
/* 117 */     WEBSPHERE("com.ibm.websphere.management.AdminServiceFactory");
/*     */ 
/*     */     private final String identifyingClass;
/*     */ 
/*     */     private SpecificPlatform(String identifyingClass)
/*     */     {
/* 127 */       this.identifyingClass = identifyingClass;
/*     */     }
/*     */ 
/*     */     public MBeanServer getMBeanServer()
/*     */     {
/*     */       try {
/* 133 */         Object server = getMBeanServerFactory().getObject();
/* 134 */         Assert.isInstanceOf(MBeanServer.class, server);
/* 135 */         return (MBeanServer)server;
/*     */       } catch (Exception ex) {
/* 137 */         throw new IllegalStateException(ex);
/*     */       }
/*     */     }
/*     */ 
/*     */     protected abstract FactoryBean<?> getMBeanServerFactory();
/*     */ 
/*     */     public static SpecificPlatform get() {
/* 144 */       ClassLoader classLoader = MBeanExportConfiguration.class.getClassLoader();
/* 145 */       for (SpecificPlatform environment : values()) {
/* 146 */         if (ClassUtils.isPresent(environment.identifyingClass, classLoader)) {
/* 147 */           return environment;
/*     */         }
/*     */       }
/* 150 */       return null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.MBeanExportConfiguration
 * JD-Core Version:    0.6.1
 */