/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import org.springframework.beans.factory.parsing.Problem;
/*    */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.core.type.MethodMetadata;
/*    */ 
/*    */ final class BeanMethod extends ConfigurationMethod
/*    */ {
/*    */   public BeanMethod(MethodMetadata metadata, ConfigurationClass configurationClass)
/*    */   {
/* 37 */     super(metadata, configurationClass);
/*    */   }
/*    */ 
/*    */   public void validate(ProblemReporter problemReporter)
/*    */   {
/* 42 */     if (getMetadata().isStatic())
/*    */     {
/* 44 */       return;
/*    */     }
/*    */ 
/* 47 */     if ((this.configurationClass.getMetadata().isAnnotated(Configuration.class.getName())) && 
/* 48 */       (!getMetadata().isOverridable()))
/*    */     {
/* 50 */       problemReporter.error(new NonOverridableMethodError());
/*    */     }
/*    */   }
/*    */ 
/*    */   private class NonOverridableMethodError extends Problem
/*    */   {
/*    */     public NonOverridableMethodError()
/*    */     {
/* 59 */       super(BeanMethod.this.getResourceLocation());
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.BeanMethod
 * JD-Core Version:    0.6.1
 */