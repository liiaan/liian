/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.Serializable;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.Member;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import javax.annotation.PostConstruct;
/*     */ import javax.annotation.PreDestroy;
/*     */ import javax.annotation.Resource;
/*     */ import javax.ejb.EJB;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.ws.Service;
/*     */ import javax.xml.ws.WebServiceClient;
/*     */ import javax.xml.ws.WebServiceRef;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.annotation.InitDestroyAnnotationBeanPostProcessor;
/*     */ import org.springframework.beans.factory.annotation.InjectionMetadata;
/*     */ import org.springframework.beans.factory.annotation.InjectionMetadata.InjectedElement;
/*     */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.config.DependencyDescriptor;
/*     */ import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessor;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.core.BridgeMethodResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.jndi.support.SimpleJndiBeanFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class CommonAnnotationBeanPostProcessor extends InitDestroyAnnotationBeanPostProcessor
/*     */   implements InstantiationAwareBeanPostProcessor, BeanFactoryAware, Serializable
/*     */ {
/* 143 */   private static Class<? extends Annotation> webServiceRefClass = null;
/*     */ 
/* 145 */   private static Class<? extends Annotation> ejbRefClass = null;
/*     */ 
/* 168 */   private final Set<String> ignoredResourceTypes = new HashSet(1);
/*     */ 
/* 170 */   private boolean fallbackToDefaultTypeMatch = true;
/*     */ 
/* 172 */   private boolean alwaysUseJndiLookup = false;
/*     */ 
/* 174 */   private transient BeanFactory jndiFactory = new SimpleJndiBeanFactory();
/*     */   private transient BeanFactory resourceFactory;
/*     */   private transient BeanFactory beanFactory;
/* 180 */   private final transient Map<String, InjectionMetadata> injectionMetadataCache = new ConcurrentHashMap(64);
/*     */ 
/*     */   public CommonAnnotationBeanPostProcessor()
/*     */   {
/* 191 */     setOrder(2147483644);
/* 192 */     setInitAnnotationType(PostConstruct.class);
/* 193 */     setDestroyAnnotationType(PreDestroy.class);
/* 194 */     ignoreResourceType("javax.xml.ws.WebServiceContext");
/*     */   }
/*     */ 
/*     */   public void ignoreResourceType(String resourceType)
/*     */   {
/* 206 */     Assert.notNull(resourceType, "Ignored resource type must not be null");
/* 207 */     this.ignoredResourceTypes.add(resourceType);
/*     */   }
/*     */ 
/*     */   public void setFallbackToDefaultTypeMatch(boolean fallbackToDefaultTypeMatch)
/*     */   {
/* 221 */     this.fallbackToDefaultTypeMatch = fallbackToDefaultTypeMatch;
/*     */   }
/*     */ 
/*     */   public void setAlwaysUseJndiLookup(boolean alwaysUseJndiLookup)
/*     */   {
/* 235 */     this.alwaysUseJndiLookup = alwaysUseJndiLookup;
/*     */   }
/*     */ 
/*     */   public void setJndiFactory(BeanFactory jndiFactory)
/*     */   {
/* 250 */     Assert.notNull(jndiFactory, "BeanFactory must not be null");
/* 251 */     this.jndiFactory = jndiFactory;
/*     */   }
/*     */ 
/*     */   public void setResourceFactory(BeanFactory resourceFactory)
/*     */   {
/* 268 */     Assert.notNull(resourceFactory, "BeanFactory must not be null");
/* 269 */     this.resourceFactory = resourceFactory;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
/* 273 */     Assert.notNull(beanFactory, "BeanFactory must not be null");
/* 274 */     this.beanFactory = beanFactory;
/* 275 */     if (this.resourceFactory == null)
/* 276 */       this.resourceFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   public void postProcessMergedBeanDefinition(RootBeanDefinition beanDefinition, Class<?> beanType, String beanName)
/*     */   {
/* 283 */     super.postProcessMergedBeanDefinition(beanDefinition, beanType, beanName);
/* 284 */     if (beanType != null) {
/* 285 */       InjectionMetadata metadata = findResourceMetadata(beanName, beanType);
/* 286 */       metadata.checkConfigMembers(beanDefinition);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object postProcessBeforeInstantiation(Class<?> beanClass, String beanName) throws BeansException {
/* 291 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean postProcessAfterInstantiation(Object bean, String beanName) throws BeansException {
/* 295 */     return true;
/*     */   }
/*     */ 
/*     */   public PropertyValues postProcessPropertyValues(PropertyValues pvs, PropertyDescriptor[] pds, Object bean, String beanName)
/*     */     throws BeansException
/*     */   {
/* 301 */     InjectionMetadata metadata = findResourceMetadata(beanName, bean.getClass());
/*     */     try {
/* 303 */       metadata.inject(bean, beanName, pvs);
/*     */     }
/*     */     catch (Throwable ex) {
/* 306 */       throw new BeanCreationException(beanName, "Injection of resource dependencies failed", ex);
/*     */     }
/* 308 */     return pvs;
/*     */   }
/*     */ 
/*     */   private InjectionMetadata findResourceMetadata(String beanName, Class<?> clazz)
/*     */   {
/* 315 */     String cacheKey = StringUtils.hasLength(beanName) ? beanName : clazz.getName();
/* 316 */     InjectionMetadata metadata = (InjectionMetadata)this.injectionMetadataCache.get(cacheKey);
/* 317 */     if (InjectionMetadata.needsRefresh(metadata, clazz)) {
/* 318 */       synchronized (this.injectionMetadataCache) {
/* 319 */         metadata = (InjectionMetadata)this.injectionMetadataCache.get(cacheKey);
/* 320 */         if (InjectionMetadata.needsRefresh(metadata, clazz)) {
/* 321 */           LinkedList elements = new LinkedList();
/* 322 */           Class targetClass = clazz;
/*     */           do
/*     */           {
/* 325 */             LinkedList currElements = new LinkedList();
/* 326 */             for (Field field : targetClass.getDeclaredFields()) {
/* 327 */               if ((webServiceRefClass != null) && (field.isAnnotationPresent(webServiceRefClass))) {
/* 328 */                 if (Modifier.isStatic(field.getModifiers())) {
/* 329 */                   throw new IllegalStateException("@WebServiceRef annotation is not supported on static fields");
/*     */                 }
/* 331 */                 currElements.add(new WebServiceRefElement(field, null));
/*     */               }
/* 333 */               else if ((ejbRefClass != null) && (field.isAnnotationPresent(ejbRefClass))) {
/* 334 */                 if (Modifier.isStatic(field.getModifiers())) {
/* 335 */                   throw new IllegalStateException("@EJB annotation is not supported on static fields");
/*     */                 }
/* 337 */                 currElements.add(new EjbRefElement(field, null));
/*     */               }
/* 339 */               else if (field.isAnnotationPresent(Resource.class)) {
/* 340 */                 if (Modifier.isStatic(field.getModifiers())) {
/* 341 */                   throw new IllegalStateException("@Resource annotation is not supported on static fields");
/*     */                 }
/* 343 */                 if (!this.ignoredResourceTypes.contains(field.getType().getName())) {
/* 344 */                   currElements.add(new ResourceElement(field, null));
/*     */                 }
/*     */               }
/*     */             }
/* 348 */             for (Method method : targetClass.getDeclaredMethods()) {
/* 349 */               method = BridgeMethodResolver.findBridgedMethod(method);
/* 350 */               Method mostSpecificMethod = BridgeMethodResolver.findBridgedMethod(ClassUtils.getMostSpecificMethod(method, clazz));
/* 351 */               if (method.equals(mostSpecificMethod)) {
/* 352 */                 if ((webServiceRefClass != null) && (method.isAnnotationPresent(webServiceRefClass))) {
/* 353 */                   if (Modifier.isStatic(method.getModifiers())) {
/* 354 */                     throw new IllegalStateException("@WebServiceRef annotation is not supported on static methods");
/*     */                   }
/* 356 */                   if (method.getParameterTypes().length != 1) {
/* 357 */                     throw new IllegalStateException("@WebServiceRef annotation requires a single-arg method: " + method);
/*     */                   }
/* 359 */                   PropertyDescriptor pd = BeanUtils.findPropertyForMethod(method);
/* 360 */                   currElements.add(new WebServiceRefElement(method, pd));
/*     */                 }
/* 362 */                 else if ((ejbRefClass != null) && (method.isAnnotationPresent(ejbRefClass))) {
/* 363 */                   if (Modifier.isStatic(method.getModifiers())) {
/* 364 */                     throw new IllegalStateException("@EJB annotation is not supported on static methods");
/*     */                   }
/* 366 */                   if (method.getParameterTypes().length != 1) {
/* 367 */                     throw new IllegalStateException("@EJB annotation requires a single-arg method: " + method);
/*     */                   }
/* 369 */                   PropertyDescriptor pd = BeanUtils.findPropertyForMethod(method);
/* 370 */                   currElements.add(new EjbRefElement(method, pd));
/*     */                 }
/* 372 */                 else if (method.isAnnotationPresent(Resource.class)) {
/* 373 */                   if (Modifier.isStatic(method.getModifiers())) {
/* 374 */                     throw new IllegalStateException("@Resource annotation is not supported on static methods");
/*     */                   }
/* 376 */                   Class[] paramTypes = method.getParameterTypes();
/* 377 */                   if (paramTypes.length != 1) {
/* 378 */                     throw new IllegalStateException("@Resource annotation requires a single-arg method: " + method);
/*     */                   }
/* 380 */                   if (!this.ignoredResourceTypes.contains(paramTypes[0].getName())) {
/* 381 */                     PropertyDescriptor pd = BeanUtils.findPropertyForMethod(method);
/* 382 */                     currElements.add(new ResourceElement(method, pd));
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/* 387 */             elements.addAll(0, currElements);
/* 388 */             targetClass = targetClass.getSuperclass();
/*     */           }
/* 390 */           while ((targetClass != null) && (targetClass != Object.class));
/*     */ 
/* 392 */           metadata = new InjectionMetadata(clazz, elements);
/* 393 */           this.injectionMetadataCache.put(cacheKey, metadata);
/*     */         }
/*     */       }
/*     */     }
/* 397 */     return metadata;
/*     */   }
/*     */ 
/*     */   protected Object getResource(LookupElement element, String requestingBeanName)
/*     */     throws BeansException
/*     */   {
/* 408 */     if (StringUtils.hasLength(element.mappedName)) {
/* 409 */       return this.jndiFactory.getBean(element.mappedName, element.lookupType);
/*     */     }
/* 411 */     if (this.alwaysUseJndiLookup) {
/* 412 */       return this.jndiFactory.getBean(element.name, element.lookupType);
/*     */     }
/* 414 */     if (this.resourceFactory == null) {
/* 415 */       throw new NoSuchBeanDefinitionException(element.lookupType, "No resource factory configured - specify the 'resourceFactory' property");
/*     */     }
/*     */ 
/* 418 */     return autowireResource(this.resourceFactory, element, requestingBeanName);
/*     */   }
/*     */ 
/*     */   protected Object autowireResource(BeanFactory factory, LookupElement element, String requestingBeanName)
/*     */     throws BeansException
/*     */   {
/* 435 */     String name = element.name;
/*     */     Object resource;
/*     */     Object resource;
/*     */     Set autowiredBeanNames;
/* 437 */     if ((this.fallbackToDefaultTypeMatch) && (element.isDefaultName) && ((factory instanceof AutowireCapableBeanFactory)) && (!factory.containsBean(name)))
/*     */     {
/* 439 */       Set autowiredBeanNames = new LinkedHashSet();
/* 440 */       resource = ((AutowireCapableBeanFactory)factory).resolveDependency(element.getDependencyDescriptor(), requestingBeanName, autowiredBeanNames, null);
/*     */     }
/*     */     else
/*     */     {
/* 444 */       resource = factory.getBean(name, element.lookupType);
/* 445 */       autowiredBeanNames = Collections.singleton(name);
/*     */     }
/*     */     ConfigurableBeanFactory beanFactory;
/* 448 */     if ((factory instanceof ConfigurableBeanFactory)) {
/* 449 */       beanFactory = (ConfigurableBeanFactory)factory;
/* 450 */       for (String autowiredBeanName : autowiredBeanNames) {
/* 451 */         if (beanFactory.containsBean(autowiredBeanName)) {
/* 452 */           beanFactory.registerDependentBean(autowiredBeanName, requestingBeanName);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 457 */     return resource;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 148 */     ClassLoader cl = CommonAnnotationBeanPostProcessor.class.getClassLoader();
/*     */     try
/*     */     {
/* 151 */       Class clazz = cl.loadClass("javax.xml.ws.WebServiceRef");
/* 152 */       webServiceRefClass = clazz;
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 155 */       webServiceRefClass = null;
/*     */     }
/*     */     try
/*     */     {
/* 159 */       Class clazz = cl.loadClass("javax.ejb.EJB");
/* 160 */       ejbRefClass = clazz;
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 163 */       ejbRefClass = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class LookupDependencyDescriptor extends DependencyDescriptor
/*     */   {
/*     */     private final Class<?> lookupType;
/*     */ 
/*     */     public LookupDependencyDescriptor(Field field, Class<?> lookupType)
/*     */     {
/* 703 */       super(true);
/* 704 */       this.lookupType = lookupType;
/*     */     }
/*     */ 
/*     */     public LookupDependencyDescriptor(Method method, Class<?> lookupType) {
/* 708 */       super(true);
/* 709 */       this.lookupType = lookupType;
/*     */     }
/*     */ 
/*     */     public Class<?> getDependencyType()
/*     */     {
/* 714 */       return this.lookupType;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class EjbRefElement extends CommonAnnotationBeanPostProcessor.LookupElement
/*     */   {
/*     */     private final String beanName;
/*     */ 
/*     */     public EjbRefElement(Member member, PropertyDescriptor pd)
/*     */     {
/* 646 */       super(member, pd);
/* 647 */       AnnotatedElement ae = (AnnotatedElement)member;
/* 648 */       EJB resource = (EJB)ae.getAnnotation(EJB.class);
/* 649 */       String resourceBeanName = resource.beanName();
/* 650 */       String resourceName = resource.name();
/* 651 */       this.isDefaultName = (!StringUtils.hasLength(resourceName));
/* 652 */       if (this.isDefaultName) {
/* 653 */         resourceName = this.member.getName();
/* 654 */         if (((this.member instanceof Method)) && (resourceName.startsWith("set")) && (resourceName.length() > 3)) {
/* 655 */           resourceName = Introspector.decapitalize(resourceName.substring(3));
/*     */         }
/*     */       }
/* 658 */       Class resourceType = resource.beanInterface();
/* 659 */       if ((resourceType != null) && (!Object.class.equals(resourceType))) {
/* 660 */         checkResourceType(resourceType);
/*     */       }
/*     */       else
/*     */       {
/* 664 */         resourceType = getResourceType();
/*     */       }
/* 666 */       this.beanName = resourceBeanName;
/* 667 */       this.name = resourceName;
/* 668 */       this.lookupType = resourceType;
/* 669 */       this.mappedName = resource.mappedName();
/*     */     }
/*     */ 
/*     */     protected Object getResourceToInject(Object target, String requestingBeanName)
/*     */     {
/* 674 */       if (StringUtils.hasLength(this.beanName)) {
/* 675 */         if ((CommonAnnotationBeanPostProcessor.this.beanFactory != null) && (CommonAnnotationBeanPostProcessor.this.beanFactory.containsBean(this.beanName)))
/*     */         {
/* 677 */           Object bean = CommonAnnotationBeanPostProcessor.this.beanFactory.getBean(this.beanName, this.lookupType);
/* 678 */           if ((CommonAnnotationBeanPostProcessor.this.beanFactory instanceof ConfigurableBeanFactory)) {
/* 679 */             ((ConfigurableBeanFactory)CommonAnnotationBeanPostProcessor.this.beanFactory).registerDependentBean(this.beanName, requestingBeanName);
/*     */           }
/* 681 */           return bean;
/*     */         }
/* 683 */         if ((this.isDefaultName) && (!StringUtils.hasLength(this.mappedName))) {
/* 684 */           throw new NoSuchBeanDefinitionException(this.beanName, "Cannot resolve 'beanName' in local BeanFactory. Consider specifying a general 'name' value instead.");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 689 */       return CommonAnnotationBeanPostProcessor.this.getResource(this, requestingBeanName);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class WebServiceRefElement extends CommonAnnotationBeanPostProcessor.LookupElement
/*     */   {
/*     */     private final Class<?> elementType;
/*     */     private final String wsdlLocation;
/*     */ 
/*     */     public WebServiceRefElement(Member member, PropertyDescriptor pd)
/*     */     {
/* 562 */       super(member, pd);
/* 563 */       AnnotatedElement ae = (AnnotatedElement)member;
/* 564 */       WebServiceRef resource = (WebServiceRef)ae.getAnnotation(WebServiceRef.class);
/* 565 */       String resourceName = resource.name();
/* 566 */       Class resourceType = resource.type();
/* 567 */       this.isDefaultName = (!StringUtils.hasLength(resourceName));
/* 568 */       if (this.isDefaultName) {
/* 569 */         resourceName = this.member.getName();
/* 570 */         if (((this.member instanceof Method)) && (resourceName.startsWith("set")) && (resourceName.length() > 3)) {
/* 571 */           resourceName = Introspector.decapitalize(resourceName.substring(3));
/*     */         }
/*     */       }
/* 574 */       if ((resourceType != null) && (!Object.class.equals(resourceType))) {
/* 575 */         checkResourceType(resourceType);
/*     */       }
/*     */       else
/*     */       {
/* 579 */         resourceType = getResourceType();
/*     */       }
/* 581 */       this.name = resourceName;
/* 582 */       this.elementType = resourceType;
/* 583 */       if (Service.class.isAssignableFrom(resourceType)) {
/* 584 */         this.lookupType = resourceType;
/*     */       }
/*     */       else {
/* 587 */         this.lookupType = (!Object.class.equals(resource.value()) ? resource.value() : Service.class);
/*     */       }
/* 589 */       this.mappedName = resource.mappedName();
/* 590 */       this.wsdlLocation = resource.wsdlLocation();
/*     */     }
/*     */ 
/*     */     protected Object getResourceToInject(Object target, String requestingBeanName)
/*     */     {
/*     */       Service service;
/*     */       try {
/* 597 */         service = (Service)CommonAnnotationBeanPostProcessor.this.getResource(this, requestingBeanName);
/*     */       }
/*     */       catch (NoSuchBeanDefinitionException notFound)
/*     */       {
/* 601 */         if (Service.class.equals(this.lookupType)) {
/* 602 */           throw new IllegalStateException("No resource with name '" + this.name + "' found in context, " + "and no specific JAX-WS Service subclass specified. The typical solution is to either specify " + "a LocalJaxWsServiceFactoryBean with the given name or to specify the (generated) Service " + "subclass as @WebServiceRef(...) value.");
/*     */         }
/*     */ 
/* 607 */         if (StringUtils.hasLength(this.wsdlLocation)) {
/*     */           try {
/* 609 */             Constructor ctor = this.lookupType.getConstructor(new Class[] { URL.class, QName.class });
/* 610 */             WebServiceClient clientAnn = (WebServiceClient)this.lookupType.getAnnotation(WebServiceClient.class);
/* 611 */             if (clientAnn == null) {
/* 612 */               throw new IllegalStateException("JAX-WS Service class [" + this.lookupType.getName() + "] does not carry a WebServiceClient annotation");
/*     */             }
/*     */ 
/* 615 */             service = (Service)BeanUtils.instantiateClass(ctor, new Object[] { new URL(this.wsdlLocation), new QName(clientAnn.targetNamespace(), clientAnn.name()) });
/*     */           }
/*     */           catch (NoSuchMethodException ex)
/*     */           {
/* 619 */             throw new IllegalStateException("JAX-WS Service class [" + this.lookupType.getName() + "] does not have a (URL, QName) constructor. Cannot apply specified WSDL location [" + this.wsdlLocation + "].");
/*     */           }
/*     */           catch (MalformedURLException ex)
/*     */           {
/* 624 */             throw new IllegalArgumentException("Specified WSDL location [" + this.wsdlLocation + "] isn't a valid URL");
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 629 */           service = (Service)BeanUtils.instantiateClass(this.lookupType);
/*     */         }
/*     */       }
/* 632 */       return service.getPort(this.elementType);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ResourceElement extends CommonAnnotationBeanPostProcessor.LookupElement
/*     */   {
/*     */     protected final boolean shareable;
/*     */ 
/*     */     public ResourceElement(Member member, PropertyDescriptor pd)
/*     */     {
/* 516 */       super(member, pd);
/* 517 */       AnnotatedElement ae = (AnnotatedElement)member;
/* 518 */       Resource resource = (Resource)ae.getAnnotation(Resource.class);
/* 519 */       String resourceName = resource.name();
/* 520 */       Class resourceType = resource.type();
/* 521 */       this.isDefaultName = (!StringUtils.hasLength(resourceName));
/* 522 */       if (this.isDefaultName) {
/* 523 */         resourceName = this.member.getName();
/* 524 */         if (((this.member instanceof Method)) && (resourceName.startsWith("set")) && (resourceName.length() > 3)) {
/* 525 */           resourceName = Introspector.decapitalize(resourceName.substring(3));
/*     */         }
/*     */       }
/* 528 */       else if ((CommonAnnotationBeanPostProcessor.this.beanFactory instanceof ConfigurableBeanFactory)) {
/* 529 */         resourceName = ((ConfigurableBeanFactory)CommonAnnotationBeanPostProcessor.this.beanFactory).resolveEmbeddedValue(resourceName);
/*     */       }
/* 531 */       if ((resourceType != null) && (!Object.class.equals(resourceType))) {
/* 532 */         checkResourceType(resourceType);
/*     */       }
/*     */       else
/*     */       {
/* 536 */         resourceType = getResourceType();
/*     */       }
/* 538 */       this.name = resourceName;
/* 539 */       this.lookupType = resourceType;
/* 540 */       this.mappedName = resource.mappedName();
/* 541 */       this.shareable = resource.shareable();
/*     */     }
/*     */ 
/*     */     protected Object getResourceToInject(Object target, String requestingBeanName)
/*     */     {
/* 546 */       return CommonAnnotationBeanPostProcessor.this.getResource(this, requestingBeanName);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected abstract class LookupElement extends InjectionMetadata.InjectedElement
/*     */   {
/*     */     protected String name;
/* 469 */     protected boolean isDefaultName = false;
/*     */     protected Class<?> lookupType;
/*     */     protected String mappedName;
/*     */ 
/*     */     public LookupElement(Member member, PropertyDescriptor pd)
/*     */     {
/* 476 */       super(pd);
/*     */     }
/*     */ 
/*     */     public final String getName()
/*     */     {
/* 483 */       return this.name;
/*     */     }
/*     */ 
/*     */     public final Class<?> getLookupType()
/*     */     {
/* 490 */       return this.lookupType;
/*     */     }
/*     */ 
/*     */     public final DependencyDescriptor getDependencyDescriptor()
/*     */     {
/* 497 */       if (this.isField) {
/* 498 */         return new CommonAnnotationBeanPostProcessor.LookupDependencyDescriptor((Field)this.member, this.lookupType);
/*     */       }
/*     */ 
/* 501 */       return new CommonAnnotationBeanPostProcessor.LookupDependencyDescriptor((Method)this.member, this.lookupType);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.CommonAnnotationBeanPostProcessor
 * JD-Core Version:    0.6.1
 */