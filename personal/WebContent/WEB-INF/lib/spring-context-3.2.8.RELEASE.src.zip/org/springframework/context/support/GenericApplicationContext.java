/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.beans.factory.annotation.QualifierAnnotationAutowireCandidateResolver;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class GenericApplicationContext extends AbstractApplicationContext
/*     */   implements BeanDefinitionRegistry
/*     */ {
/*     */   private final DefaultListableBeanFactory beanFactory;
/*     */   private ResourceLoader resourceLoader;
/*  93 */   private boolean refreshed = false;
/*     */ 
/*     */   public GenericApplicationContext()
/*     */   {
/* 102 */     this.beanFactory = new DefaultListableBeanFactory();
/* 103 */     this.beanFactory.setAutowireCandidateResolver(new QualifierAnnotationAutowireCandidateResolver());
/*     */   }
/*     */ 
/*     */   public GenericApplicationContext(DefaultListableBeanFactory beanFactory)
/*     */   {
/* 113 */     Assert.notNull(beanFactory, "BeanFactory must not be null");
/* 114 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   public GenericApplicationContext(ApplicationContext parent)
/*     */   {
/* 124 */     this();
/* 125 */     setParent(parent);
/*     */   }
/*     */ 
/*     */   public GenericApplicationContext(DefaultListableBeanFactory beanFactory, ApplicationContext parent)
/*     */   {
/* 136 */     this(beanFactory);
/* 137 */     setParent(parent);
/*     */   }
/*     */ 
/*     */   public void setParent(ApplicationContext parent)
/*     */   {
/* 148 */     super.setParent(parent);
/* 149 */     this.beanFactory.setParentBeanFactory(getInternalParentBeanFactory());
/*     */   }
/*     */ 
/*     */   public void setId(String id)
/*     */   {
/* 154 */     super.setId(id);
/*     */   }
/*     */ 
/*     */   public void setAllowBeanDefinitionOverriding(boolean allowBeanDefinitionOverriding)
/*     */   {
/* 164 */     this.beanFactory.setAllowBeanDefinitionOverriding(allowBeanDefinitionOverriding);
/*     */   }
/*     */ 
/*     */   public void setAllowCircularReferences(boolean allowCircularReferences)
/*     */   {
/* 175 */     this.beanFactory.setAllowCircularReferences(allowCircularReferences);
/*     */   }
/*     */ 
/*     */   public void setResourceLoader(ResourceLoader resourceLoader)
/*     */   {
/* 197 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */   public Resource getResource(String location)
/*     */   {
/* 208 */     if (this.resourceLoader != null) {
/* 209 */       return this.resourceLoader.getResource(location);
/*     */     }
/* 211 */     return super.getResource(location);
/*     */   }
/*     */ 
/*     */   public Resource[] getResources(String locationPattern)
/*     */     throws IOException
/*     */   {
/* 222 */     if ((this.resourceLoader instanceof ResourcePatternResolver)) {
/* 223 */       return ((ResourcePatternResolver)this.resourceLoader).getResources(locationPattern);
/*     */     }
/* 225 */     return super.getResources(locationPattern);
/*     */   }
/*     */ 
/*     */   protected final void refreshBeanFactory()
/*     */     throws IllegalStateException
/*     */   {
/* 240 */     if (this.refreshed) {
/* 241 */       throw new IllegalStateException("GenericApplicationContext does not support multiple refresh attempts: just call 'refresh' once");
/*     */     }
/*     */ 
/* 244 */     this.beanFactory.setSerializationId(getId());
/* 245 */     this.refreshed = true;
/*     */   }
/*     */ 
/*     */   protected void cancelRefresh(BeansException ex)
/*     */   {
/* 250 */     this.beanFactory.setSerializationId(null);
/* 251 */     super.cancelRefresh(ex);
/*     */   }
/*     */ 
/*     */   protected final void closeBeanFactory()
/*     */   {
/* 260 */     this.beanFactory.setSerializationId(null);
/*     */   }
/*     */ 
/*     */   public final ConfigurableListableBeanFactory getBeanFactory()
/*     */   {
/* 269 */     return this.beanFactory;
/*     */   }
/*     */ 
/*     */   public final DefaultListableBeanFactory getDefaultListableBeanFactory()
/*     */   {
/* 281 */     return this.beanFactory;
/*     */   }
/*     */ 
/*     */   public void registerBeanDefinition(String beanName, BeanDefinition beanDefinition)
/*     */     throws BeanDefinitionStoreException
/*     */   {
/* 292 */     this.beanFactory.registerBeanDefinition(beanName, beanDefinition);
/*     */   }
/*     */ 
/*     */   public void removeBeanDefinition(String beanName) throws NoSuchBeanDefinitionException {
/* 296 */     this.beanFactory.removeBeanDefinition(beanName);
/*     */   }
/*     */ 
/*     */   public BeanDefinition getBeanDefinition(String beanName) throws NoSuchBeanDefinitionException {
/* 300 */     return this.beanFactory.getBeanDefinition(beanName);
/*     */   }
/*     */ 
/*     */   public boolean isBeanNameInUse(String beanName) {
/* 304 */     return this.beanFactory.isBeanNameInUse(beanName);
/*     */   }
/*     */ 
/*     */   public void registerAlias(String beanName, String alias) {
/* 308 */     this.beanFactory.registerAlias(beanName, alias);
/*     */   }
/*     */ 
/*     */   public void removeAlias(String alias) {
/* 312 */     this.beanFactory.removeAlias(alias);
/*     */   }
/*     */ 
/*     */   public boolean isAlias(String beanName) {
/* 316 */     return this.beanFactory.isAlias(beanName);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.GenericApplicationContext
 * JD-Core Version:    0.6.1
 */