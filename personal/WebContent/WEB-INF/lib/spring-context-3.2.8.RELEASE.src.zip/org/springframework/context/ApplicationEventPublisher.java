package org.springframework.context;

public abstract interface ApplicationEventPublisher
{
  public abstract void publishEvent(ApplicationEvent paramApplicationEvent);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.ApplicationEventPublisher
 * JD-Core Version:    0.6.1
 */