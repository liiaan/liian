/*     */ package org.springframework.context.weaving;
/*     */ 
/*     */ import java.lang.instrument.ClassFileTransformer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.instrument.classloading.InstrumentationLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.LoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.ReflectiveLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.glassfish.GlassFishLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.jboss.JBossLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.oc4j.OC4JLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.weblogic.WebLogicLoadTimeWeaver;
/*     */ import org.springframework.instrument.classloading.websphere.WebSphereLoadTimeWeaver;
/*     */ 
/*     */ public class DefaultContextLoadTimeWeaver
/*     */   implements LoadTimeWeaver, BeanClassLoaderAware, DisposableBean
/*     */ {
/*  62 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private LoadTimeWeaver loadTimeWeaver;
/*     */ 
/*     */   public DefaultContextLoadTimeWeaver()
/*     */   {
/*     */   }
/*     */ 
/*     */   public DefaultContextLoadTimeWeaver(ClassLoader beanClassLoader)
/*     */   {
/*  71 */     setBeanClassLoader(beanClassLoader);
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader) {
/*  75 */     LoadTimeWeaver serverSpecificLoadTimeWeaver = createServerSpecificLoadTimeWeaver(classLoader);
/*  76 */     if (serverSpecificLoadTimeWeaver != null) {
/*  77 */       if (this.logger.isInfoEnabled()) {
/*  78 */         this.logger.info("Determined server-specific load-time weaver: " + serverSpecificLoadTimeWeaver.getClass().getName());
/*     */       }
/*     */ 
/*  81 */       this.loadTimeWeaver = serverSpecificLoadTimeWeaver;
/*     */     }
/*  83 */     else if (InstrumentationLoadTimeWeaver.isInstrumentationAvailable()) {
/*  84 */       this.logger.info("Found Spring's JVM agent for instrumentation");
/*  85 */       this.loadTimeWeaver = new InstrumentationLoadTimeWeaver(classLoader);
/*     */     }
/*     */     else {
/*     */       try {
/*  89 */         this.loadTimeWeaver = new ReflectiveLoadTimeWeaver(classLoader);
/*  90 */         this.logger.info("Using a reflective load-time weaver for class loader: " + this.loadTimeWeaver.getInstrumentableClassLoader().getClass().getName());
/*     */       }
/*     */       catch (IllegalStateException ex)
/*     */       {
/*  94 */         throw new IllegalStateException(ex.getMessage() + " Specify a custom LoadTimeWeaver or start your " + "Java virtual machine with Spring's agent: -javaagent:org.springframework.instrument.jar");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected LoadTimeWeaver createServerSpecificLoadTimeWeaver(ClassLoader classLoader)
/*     */   {
/* 110 */     String name = classLoader.getClass().getName();
/*     */     try {
/* 112 */       if (name.startsWith("weblogic")) {
/* 113 */         return new WebLogicLoadTimeWeaver(classLoader);
/*     */       }
/* 115 */       if (name.startsWith("oracle")) {
/* 116 */         return new OC4JLoadTimeWeaver(classLoader);
/*     */       }
/* 118 */       if ((name.startsWith("com.sun.enterprise")) || (name.startsWith("org.glassfish"))) {
/* 119 */         return new GlassFishLoadTimeWeaver(classLoader);
/*     */       }
/* 121 */       if (name.startsWith("org.jboss")) {
/* 122 */         return new JBossLoadTimeWeaver(classLoader);
/*     */       }
/* 124 */       if (name.startsWith("com.ibm"))
/* 125 */         return new WebSphereLoadTimeWeaver(classLoader);
/*     */     }
/*     */     catch (IllegalStateException ex)
/*     */     {
/* 129 */       this.logger.info("Could not obtain server-specific LoadTimeWeaver: " + ex.getMessage());
/*     */     }
/* 131 */     return null;
/*     */   }
/*     */ 
/*     */   public void destroy() {
/* 135 */     if ((this.loadTimeWeaver instanceof InstrumentationLoadTimeWeaver)) {
/* 136 */       this.logger.info("Removing all registered transformers for class loader: " + this.loadTimeWeaver.getInstrumentableClassLoader().getClass().getName());
/*     */ 
/* 138 */       ((InstrumentationLoadTimeWeaver)this.loadTimeWeaver).removeTransformers();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addTransformer(ClassFileTransformer transformer)
/*     */   {
/* 144 */     this.loadTimeWeaver.addTransformer(transformer);
/*     */   }
/*     */ 
/*     */   public ClassLoader getInstrumentableClassLoader() {
/* 148 */     return this.loadTimeWeaver.getInstrumentableClassLoader();
/*     */   }
/*     */ 
/*     */   public ClassLoader getThrowawayClassLoader() {
/* 152 */     return this.loadTimeWeaver.getThrowawayClassLoader();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.weaving.DefaultContextLoadTimeWeaver
 * JD-Core Version:    0.6.1
 */