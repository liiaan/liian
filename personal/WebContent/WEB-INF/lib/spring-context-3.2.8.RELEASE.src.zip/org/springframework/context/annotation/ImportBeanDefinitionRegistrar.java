package org.springframework.context.annotation;

import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.core.type.AnnotationMetadata;

public abstract interface ImportBeanDefinitionRegistrar
{
  public abstract void registerBeanDefinitions(AnnotationMetadata paramAnnotationMetadata, BeanDefinitionRegistry paramBeanDefinitionRegistry);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ImportBeanDefinitionRegistrar
 * JD-Core Version:    0.6.1
 */