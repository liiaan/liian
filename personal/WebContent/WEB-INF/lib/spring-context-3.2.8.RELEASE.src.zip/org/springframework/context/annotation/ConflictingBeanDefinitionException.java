/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ class ConflictingBeanDefinitionException extends IllegalStateException
/*    */ {
/*    */   public ConflictingBeanDefinitionException(String message)
/*    */   {
/* 30 */     super(message);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ConflictingBeanDefinitionException
 * JD-Core Version:    0.6.1
 */