package org.springframework.context.event;

import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationListener;

public abstract interface ApplicationEventMulticaster
{
  public abstract void addApplicationListener(ApplicationListener paramApplicationListener);

  public abstract void addApplicationListenerBean(String paramString);

  public abstract void removeApplicationListener(ApplicationListener paramApplicationListener);

  public abstract void removeApplicationListenerBean(String paramString);

  public abstract void removeAllListeners();

  public abstract void multicastEvent(ApplicationEvent paramApplicationEvent);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.event.ApplicationEventMulticaster
 * JD-Core Version:    0.6.1
 */