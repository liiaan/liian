/*    */ package org.springframework.context.event;
/*    */ 
/*    */ import org.springframework.context.ApplicationContext;
/*    */ 
/*    */ public class ContextClosedEvent extends ApplicationContextEvent
/*    */ {
/*    */   public ContextClosedEvent(ApplicationContext source)
/*    */   {
/* 37 */     super(source);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.event.ContextClosedEvent
 * JD-Core Version:    0.6.1
 */