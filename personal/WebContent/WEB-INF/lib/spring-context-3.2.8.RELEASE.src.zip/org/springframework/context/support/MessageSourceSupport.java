/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public abstract class MessageSourceSupport
/*     */ {
/*  43 */   private static final MessageFormat INVALID_MESSAGE_FORMAT = new MessageFormat("");
/*     */ 
/*  46 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*  48 */   private boolean alwaysUseMessageFormat = false;
/*     */ 
/*  55 */   private final Map<String, Map<Locale, MessageFormat>> messageFormatsPerMessage = new HashMap();
/*     */ 
/*     */   public void setAlwaysUseMessageFormat(boolean alwaysUseMessageFormat)
/*     */   {
/*  74 */     this.alwaysUseMessageFormat = alwaysUseMessageFormat;
/*     */   }
/*     */ 
/*     */   protected boolean isAlwaysUseMessageFormat()
/*     */   {
/*  82 */     return this.alwaysUseMessageFormat;
/*     */   }
/*     */ 
/*     */   protected String renderDefaultMessage(String defaultMessage, Object[] args, Locale locale)
/*     */   {
/* 101 */     return formatMessage(defaultMessage, args, locale);
/*     */   }
/*     */ 
/*     */   protected String formatMessage(String msg, Object[] args, Locale locale)
/*     */   {
/* 115 */     if ((msg == null) || ((!this.alwaysUseMessageFormat) && (ObjectUtils.isEmpty(args)))) {
/* 116 */       return msg;
/*     */     }
/* 118 */     MessageFormat messageFormat = null;
/* 119 */     synchronized (this.messageFormatsPerMessage) {
/* 120 */       Map messageFormatsPerLocale = (Map)this.messageFormatsPerMessage.get(msg);
/* 121 */       if (messageFormatsPerLocale != null) {
/* 122 */         messageFormat = (MessageFormat)messageFormatsPerLocale.get(locale);
/*     */       }
/*     */       else {
/* 125 */         messageFormatsPerLocale = new HashMap();
/* 126 */         this.messageFormatsPerMessage.put(msg, messageFormatsPerLocale);
/*     */       }
/* 128 */       if (messageFormat == null) {
/*     */         try {
/* 130 */           messageFormat = createMessageFormat(msg, locale);
/*     */         }
/*     */         catch (IllegalArgumentException ex)
/*     */         {
/* 135 */           if (this.alwaysUseMessageFormat) {
/* 136 */             throw ex;
/*     */           }
/*     */ 
/* 139 */           messageFormat = INVALID_MESSAGE_FORMAT;
/*     */         }
/* 141 */         messageFormatsPerLocale.put(locale, messageFormat);
/*     */       }
/*     */     }
/* 144 */     if (messageFormat == INVALID_MESSAGE_FORMAT) {
/* 145 */       return msg;
/*     */     }
/* 147 */     synchronized (messageFormat) {
/* 148 */       return messageFormat.format(resolveArguments(args, locale));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected MessageFormat createMessageFormat(String msg, Locale locale)
/*     */   {
/* 159 */     return new MessageFormat(msg != null ? msg : "", locale);
/*     */   }
/*     */ 
/*     */   protected Object[] resolveArguments(Object[] args, Locale locale)
/*     */   {
/* 171 */     return args;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.MessageSourceSupport
 * JD-Core Version:    0.6.1
 */