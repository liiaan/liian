/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.StandardAnnotationMetadata;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.stereotype.Component;
/*     */ 
/*     */ abstract class ConfigurationClassUtils
/*     */ {
/*     */   private static final String CONFIGURATION_CLASS_FULL = "full";
/*     */   private static final String CONFIGURATION_CLASS_LITE = "lite";
/*  45 */   private static final String CONFIGURATION_CLASS_ATTRIBUTE = Conventions.getQualifiedAttributeName(ConfigurationClassPostProcessor.class, "configurationClass");
/*     */ 
/*  48 */   private static final Log logger = LogFactory.getLog(ConfigurationClassUtils.class);
/*     */ 
/*     */   public static boolean checkConfigurationClassCandidate(BeanDefinition beanDef, MetadataReaderFactory metadataReaderFactory)
/*     */   {
/*  59 */     AnnotationMetadata metadata = null;
/*     */ 
/*  63 */     if (((beanDef instanceof AbstractBeanDefinition)) && (((AbstractBeanDefinition)beanDef).hasBeanClass())) {
/*  64 */       Class beanClass = ((AbstractBeanDefinition)beanDef).getBeanClass();
/*  65 */       metadata = new StandardAnnotationMetadata(beanClass, true);
/*     */     }
/*     */     else {
/*  68 */       String className = beanDef.getBeanClassName();
/*  69 */       if (className != null) {
/*     */         try {
/*  71 */           MetadataReader metadataReader = metadataReaderFactory.getMetadataReader(className);
/*  72 */           metadata = metadataReader.getAnnotationMetadata();
/*     */         }
/*     */         catch (IOException ex) {
/*  75 */           if (logger.isDebugEnabled()) {
/*  76 */             logger.debug("Could not find class file for introspecting factory methods: " + className, ex);
/*     */           }
/*  78 */           return false;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*  83 */     if (metadata != null) {
/*  84 */       if (isFullConfigurationCandidate(metadata)) {
/*  85 */         beanDef.setAttribute(CONFIGURATION_CLASS_ATTRIBUTE, "full");
/*  86 */         return true;
/*     */       }
/*  88 */       if (isLiteConfigurationCandidate(metadata)) {
/*  89 */         beanDef.setAttribute(CONFIGURATION_CLASS_ATTRIBUTE, "lite");
/*  90 */         return true;
/*     */       }
/*     */     }
/*  93 */     return false;
/*     */   }
/*     */ 
/*     */   public static boolean isConfigurationCandidate(AnnotationMetadata metadata) {
/*  97 */     return (isFullConfigurationCandidate(metadata)) || (isLiteConfigurationCandidate(metadata));
/*     */   }
/*     */ 
/*     */   public static boolean isFullConfigurationCandidate(AnnotationMetadata metadata) {
/* 101 */     return metadata.isAnnotated(Configuration.class.getName());
/*     */   }
/*     */ 
/*     */   public static boolean isLiteConfigurationCandidate(AnnotationMetadata metadata)
/*     */   {
/* 106 */     return (!metadata.isInterface()) && ((metadata.isAnnotated(Component.class.getName())) || (metadata.hasAnnotatedMethods(Bean.class.getName())));
/*     */   }
/*     */ 
/*     */   public static boolean isFullConfigurationClass(BeanDefinition beanDef)
/*     */   {
/* 114 */     return "full".equals(beanDef.getAttribute(CONFIGURATION_CLASS_ATTRIBUTE));
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ConfigurationClassUtils
 * JD-Core Version:    0.6.1
 */