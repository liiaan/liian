/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.filter.AbstractTypeHierarchyTraversingFilter;
/*     */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*     */ import org.springframework.core.type.filter.AssignableTypeFilter;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ class ComponentScanAnnotationParser
/*     */ {
/*     */   private final ResourceLoader resourceLoader;
/*     */   private final Environment environment;
/*     */   private final BeanDefinitionRegistry registry;
/*     */   private final BeanNameGenerator beanNameGenerator;
/*     */ 
/*     */   public ComponentScanAnnotationParser(ResourceLoader resourceLoader, Environment environment, BeanNameGenerator beanNameGenerator, BeanDefinitionRegistry registry)
/*     */   {
/*  61 */     this.resourceLoader = resourceLoader;
/*  62 */     this.environment = environment;
/*  63 */     this.beanNameGenerator = beanNameGenerator;
/*  64 */     this.registry = registry;
/*     */   }
/*     */ 
/*     */   public Set<BeanDefinitionHolder> parse(AnnotationAttributes componentScan, final String declaringClass)
/*     */   {
/*  69 */     ClassPathBeanDefinitionScanner scanner = new ClassPathBeanDefinitionScanner(this.registry, componentScan.getBoolean("useDefaultFilters"));
/*     */ 
/*  72 */     Assert.notNull(this.environment, "Environment must not be null");
/*  73 */     scanner.setEnvironment(this.environment);
/*     */ 
/*  75 */     Assert.notNull(this.resourceLoader, "ResourceLoader must not be null");
/*  76 */     scanner.setResourceLoader(this.resourceLoader);
/*     */ 
/*  78 */     Class generatorClass = componentScan.getClass("nameGenerator");
/*  79 */     boolean useInheritedGenerator = BeanNameGenerator.class.equals(generatorClass);
/*  80 */     scanner.setBeanNameGenerator(useInheritedGenerator ? this.beanNameGenerator : (BeanNameGenerator)BeanUtils.instantiateClass(generatorClass));
/*     */ 
/*  83 */     ScopedProxyMode scopedProxyMode = (ScopedProxyMode)componentScan.getEnum("scopedProxy");
/*  84 */     if (scopedProxyMode != ScopedProxyMode.DEFAULT) {
/*  85 */       scanner.setScopedProxyMode(scopedProxyMode);
/*     */     }
/*     */     else {
/*  88 */       Class resolverClass = componentScan.getClass("scopeResolver");
/*  89 */       scanner.setScopeMetadataResolver((ScopeMetadataResolver)BeanUtils.instantiateClass(resolverClass));
/*     */     }
/*     */ 
/*  92 */     scanner.setResourcePattern(componentScan.getString("resourcePattern"));
/*     */ 
/*  94 */     for (AnnotationAttributes filter : componentScan.getAnnotationArray("includeFilters")) {
/*  95 */       for (TypeFilter typeFilter : typeFiltersFor(filter)) {
/*  96 */         scanner.addIncludeFilter(typeFilter);
/*     */       }
/*     */     }
/*  99 */     for (AnnotationAttributes filter : componentScan.getAnnotationArray("excludeFilters")) {
/* 100 */       for (TypeFilter typeFilter : typeFiltersFor(filter)) {
/* 101 */         scanner.addExcludeFilter(typeFilter);
/*     */       }
/*     */     }
/*     */ 
/* 105 */     List basePackages = new ArrayList();
/* 106 */     for (String pkg : componentScan.getStringArray("value")) {
/* 107 */       if (StringUtils.hasText(pkg)) {
/* 108 */         basePackages.add(pkg);
/*     */       }
/*     */     }
/* 111 */     for (String pkg : componentScan.getStringArray("basePackages")) {
/* 112 */       if (StringUtils.hasText(pkg)) {
/* 113 */         basePackages.add(pkg);
/*     */       }
/*     */     }
/* 116 */     for (Class clazz : componentScan.getClassArray("basePackageClasses")) {
/* 117 */       basePackages.add(ClassUtils.getPackageName(clazz));
/*     */     }
/*     */ 
/* 120 */     if (basePackages.isEmpty()) {
/* 121 */       basePackages.add(ClassUtils.getPackageName(declaringClass));
/*     */     }
/*     */ 
/* 124 */     scanner.addExcludeFilter(new AbstractTypeHierarchyTraversingFilter(false, false)
/*     */     {
/*     */       protected boolean matchClassName(String className) {
/* 127 */         return declaringClass.equals(className);
/*     */       }
/*     */     });
/* 130 */     return scanner.doScan(StringUtils.toStringArray(basePackages));
/*     */   }
/*     */ 
/*     */   private List<TypeFilter> typeFiltersFor(AnnotationAttributes filterAttributes) {
/* 134 */     List typeFilters = new ArrayList();
/* 135 */     FilterType filterType = (FilterType)filterAttributes.getEnum("type");
/*     */ 
/* 137 */     for (Class filterClass : filterAttributes.getClassArray("value")) {
/* 138 */       switch (2.$SwitchMap$org$springframework$context$annotation$FilterType[filterType.ordinal()]) {
/*     */       case 1:
/* 140 */         Assert.isAssignable(Annotation.class, filterClass, "An error occured when processing a @ComponentScan ANNOTATION type filter: ");
/*     */ 
/* 144 */         Class annoClass = filterClass;
/* 145 */         typeFilters.add(new AnnotationTypeFilter(annoClass));
/* 146 */         break;
/*     */       case 2:
/* 148 */         typeFilters.add(new AssignableTypeFilter(filterClass));
/* 149 */         break;
/*     */       case 3:
/* 151 */         Assert.isAssignable(TypeFilter.class, filterClass, "An error occured when processing a @ComponentScan CUSTOM type filter: ");
/*     */ 
/* 154 */         typeFilters.add(BeanUtils.instantiateClass(filterClass, TypeFilter.class));
/* 155 */         break;
/*     */       default:
/* 157 */         throw new IllegalArgumentException("unknown filter type " + filterType);
/*     */       }
/*     */     }
/* 160 */     return typeFilters;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ComponentScanAnnotationParser
 * JD-Core Version:    0.6.1
 */