/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import java.util.Set;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.aop.config.AopConfigUtils;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ 
/*    */ public class AutoProxyRegistrar
/*    */   implements ImportBeanDefinitionRegistrar
/*    */ {
/* 40 */   private final Log logger = LogFactory.getLog(getClass());
/*    */ 
/*    */   public void registerBeanDefinitions(AnnotationMetadata importingClassMetadata, BeanDefinitionRegistry registry)
/*    */   {
/* 58 */     boolean candidateFound = false;
/* 59 */     Set annoTypes = importingClassMetadata.getAnnotationTypes();
/* 60 */     for (String annoType : annoTypes) {
/* 61 */       AnnotationAttributes candidate = MetadataUtils.attributesFor(importingClassMetadata, annoType);
/* 62 */       Object mode = candidate.get("mode");
/* 63 */       Object proxyTargetClass = candidate.get("proxyTargetClass");
/* 64 */       if ((mode != null) && (proxyTargetClass != null) && (mode.getClass().equals(AdviceMode.class)) && (proxyTargetClass.getClass().equals(Boolean.class)))
/*    */       {
/* 66 */         candidateFound = true;
/* 67 */         if (mode == AdviceMode.PROXY) {
/* 68 */           AopConfigUtils.registerAutoProxyCreatorIfNecessary(registry);
/* 69 */           if (((Boolean)proxyTargetClass).booleanValue()) {
/* 70 */             AopConfigUtils.forceAutoProxyCreatorToUseClassProxying(registry);
/* 71 */             return;
/*    */           }
/*    */         }
/*    */       }
/*    */     }
/* 76 */     if (!candidateFound) {
/* 77 */       String name = getClass().getSimpleName();
/* 78 */       this.logger.warn(String.format("%s was imported but no annotations were found having both 'mode' and 'proxyTargetClass' attributes of type AdviceMode and boolean respectively. This means that auto proxy creator registration and configuration may not have occured as intended, and components may not be proxied as expected. Check to ensure that %s has been @Import'ed on the same class where these annotations are declared; otherwise remove the import of %s altogether.", new Object[] { name, name, name }));
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.AutoProxyRegistrar
 * JD-Core Version:    0.6.1
 */