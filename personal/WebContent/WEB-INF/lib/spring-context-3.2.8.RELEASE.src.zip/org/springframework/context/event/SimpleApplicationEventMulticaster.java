/*    */ package org.springframework.context.event;
/*    */ 
/*    */ import java.util.concurrent.Executor;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ 
/*    */ public class SimpleApplicationEventMulticaster extends AbstractApplicationEventMulticaster
/*    */ {
/*    */   private Executor taskExecutor;
/*    */ 
/*    */   public SimpleApplicationEventMulticaster()
/*    */   {
/*    */   }
/*    */ 
/*    */   public SimpleApplicationEventMulticaster(BeanFactory beanFactory)
/*    */   {
/* 57 */     setBeanFactory(beanFactory);
/*    */   }
/*    */ 
/*    */   public void setTaskExecutor(Executor taskExecutor)
/*    */   {
/* 73 */     this.taskExecutor = taskExecutor;
/*    */   }
/*    */ 
/*    */   protected Executor getTaskExecutor()
/*    */   {
/* 80 */     return this.taskExecutor;
/*    */   }
/*    */ 
/*    */   public void multicastEvent(final ApplicationEvent event)
/*    */   {
/* 86 */     for (final ApplicationListener listener : getApplicationListeners(event)) {
/* 87 */       Executor executor = getTaskExecutor();
/* 88 */       if (executor != null) {
/* 89 */         executor.execute(new Runnable() {
/*    */           public void run() {
/* 91 */             listener.onApplicationEvent(event);
/*    */           }
/*    */         });
/*    */       }
/*    */       else
/* 96 */         listener.onApplicationEvent(event);
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.event.SimpleApplicationEventMulticaster
 * JD-Core Version:    0.6.1
 */