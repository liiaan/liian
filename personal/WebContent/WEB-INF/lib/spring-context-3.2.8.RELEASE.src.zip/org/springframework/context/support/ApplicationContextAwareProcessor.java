/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.security.AccessControlContext;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.Aware;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ApplicationEventPublisherAware;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.context.EmbeddedValueResolverAware;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.context.MessageSourceAware;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ class ApplicationContextAwareProcessor
/*     */   implements BeanPostProcessor
/*     */ {
/*     */   private final ConfigurableApplicationContext applicationContext;
/*     */ 
/*     */   public ApplicationContextAwareProcessor(ConfigurableApplicationContext applicationContext)
/*     */   {
/*  69 */     this.applicationContext = applicationContext;
/*     */   }
/*     */ 
/*     */   public Object postProcessBeforeInitialization(final Object bean, String beanName) throws BeansException
/*     */   {
/*  74 */     AccessControlContext acc = null;
/*     */ 
/*  76 */     if ((System.getSecurityManager() != null) && (((bean instanceof EnvironmentAware)) || ((bean instanceof EmbeddedValueResolverAware)) || ((bean instanceof ResourceLoaderAware)) || ((bean instanceof ApplicationEventPublisherAware)) || ((bean instanceof MessageSourceAware)) || ((bean instanceof ApplicationContextAware))))
/*     */     {
/*  80 */       acc = this.applicationContext.getBeanFactory().getAccessControlContext();
/*     */     }
/*     */ 
/*  83 */     if (acc != null) {
/*  84 */       AccessController.doPrivileged(new PrivilegedAction() {
/*     */         public Object run() {
/*  86 */           ApplicationContextAwareProcessor.this.invokeAwareInterfaces(bean);
/*  87 */           return null;
/*     */         }
/*     */       }
/*     */       , acc);
/*     */     }
/*     */     else
/*     */     {
/*  92 */       invokeAwareInterfaces(bean);
/*     */     }
/*     */ 
/*  95 */     return bean;
/*     */   }
/*     */ 
/*     */   private void invokeAwareInterfaces(Object bean) {
/*  99 */     if ((bean instanceof Aware)) {
/* 100 */       if ((bean instanceof EnvironmentAware)) {
/* 101 */         ((EnvironmentAware)bean).setEnvironment(this.applicationContext.getEnvironment());
/*     */       }
/* 103 */       if ((bean instanceof EmbeddedValueResolverAware)) {
/* 104 */         ((EmbeddedValueResolverAware)bean).setEmbeddedValueResolver(new EmbeddedValueResolver(this.applicationContext.getBeanFactory()));
/*     */       }
/*     */ 
/* 107 */       if ((bean instanceof ResourceLoaderAware)) {
/* 108 */         ((ResourceLoaderAware)bean).setResourceLoader(this.applicationContext);
/*     */       }
/* 110 */       if ((bean instanceof ApplicationEventPublisherAware)) {
/* 111 */         ((ApplicationEventPublisherAware)bean).setApplicationEventPublisher(this.applicationContext);
/*     */       }
/* 113 */       if ((bean instanceof MessageSourceAware)) {
/* 114 */         ((MessageSourceAware)bean).setMessageSource(this.applicationContext);
/*     */       }
/* 116 */       if ((bean instanceof ApplicationContextAware))
/* 117 */         ((ApplicationContextAware)bean).setApplicationContext(this.applicationContext);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object postProcessAfterInitialization(Object bean, String beanName)
/*     */   {
/* 123 */     return bean;
/*     */   }
/*     */ 
/*     */   private static class EmbeddedValueResolver implements StringValueResolver
/*     */   {
/*     */     private final ConfigurableBeanFactory beanFactory;
/*     */ 
/*     */     public EmbeddedValueResolver(ConfigurableBeanFactory beanFactory)
/*     */     {
/* 132 */       this.beanFactory = beanFactory;
/*     */     }
/*     */ 
/*     */     public String resolveStringValue(String strVal) {
/* 136 */       return this.beanFactory.resolveEmbeddedValue(strVal);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.ApplicationContextAwareProcessor
 * JD-Core Version:    0.6.1
 */