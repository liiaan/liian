/*    */ package org.springframework.context.access;
/*    */ 
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.access.BeanFactoryReference;
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ConfigurableApplicationContext;
/*    */ 
/*    */ public class ContextBeanFactoryReference
/*    */   implements BeanFactoryReference
/*    */ {
/*    */   private ApplicationContext applicationContext;
/*    */ 
/*    */   public ContextBeanFactoryReference(ApplicationContext applicationContext)
/*    */   {
/* 47 */     this.applicationContext = applicationContext;
/*    */   }
/*    */ 
/*    */   public BeanFactory getFactory()
/*    */   {
/* 52 */     if (this.applicationContext == null) {
/* 53 */       throw new IllegalStateException("ApplicationContext owned by this BeanFactoryReference has been released");
/*    */     }
/*    */ 
/* 56 */     return this.applicationContext;
/*    */   }
/*    */ 
/*    */   public void release() {
/* 60 */     if (this.applicationContext != null)
/*    */     {
/*    */       ApplicationContext savedCtx;
/* 64 */       synchronized (this) {
/* 65 */         savedCtx = this.applicationContext;
/* 66 */         this.applicationContext = null;
/*    */       }
/*    */ 
/* 69 */       if ((savedCtx != null) && ((savedCtx instanceof ConfigurableApplicationContext)))
/* 70 */         ((ConfigurableApplicationContext)savedCtx).close();
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.access.ContextBeanFactoryReference
 * JD-Core Version:    0.6.1
 */