/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.annotation.QualifierAnnotationAutowireCandidateResolver;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ 
/*     */ public abstract class AbstractRefreshableApplicationContext extends AbstractApplicationContext
/*     */ {
/*     */   private Boolean allowBeanDefinitionOverriding;
/*     */   private Boolean allowCircularReferences;
/*     */   private DefaultListableBeanFactory beanFactory;
/*  75 */   private final Object beanFactoryMonitor = new Object();
/*     */ 
/*     */   public AbstractRefreshableApplicationContext()
/*     */   {
/*     */   }
/*     */ 
/*     */   public AbstractRefreshableApplicationContext(ApplicationContext parent)
/*     */   {
/*  89 */     super(parent);
/*     */   }
/*     */ 
/*     */   public void setAllowBeanDefinitionOverriding(boolean allowBeanDefinitionOverriding)
/*     */   {
/* 100 */     this.allowBeanDefinitionOverriding = Boolean.valueOf(allowBeanDefinitionOverriding);
/*     */   }
/*     */ 
/*     */   public void setAllowCircularReferences(boolean allowCircularReferences)
/*     */   {
/* 111 */     this.allowCircularReferences = Boolean.valueOf(allowCircularReferences);
/*     */   }
/*     */ 
/*     */   protected final void refreshBeanFactory()
/*     */     throws BeansException
/*     */   {
/* 122 */     if (hasBeanFactory()) {
/* 123 */       destroyBeans();
/* 124 */       closeBeanFactory();
/*     */     }
/*     */     try {
/* 127 */       DefaultListableBeanFactory beanFactory = createBeanFactory();
/* 128 */       beanFactory.setSerializationId(getId());
/* 129 */       customizeBeanFactory(beanFactory);
/* 130 */       loadBeanDefinitions(beanFactory);
/* 131 */       synchronized (this.beanFactoryMonitor) {
/* 132 */         this.beanFactory = beanFactory;
/*     */       }
/*     */     }
/*     */     catch (IOException ex) {
/* 136 */       throw new ApplicationContextException("I/O error parsing bean definition source for " + getDisplayName(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void cancelRefresh(BeansException ex)
/*     */   {
/* 142 */     synchronized (this.beanFactoryMonitor) {
/* 143 */       if (this.beanFactory != null)
/* 144 */         this.beanFactory.setSerializationId(null);
/*     */     }
/* 146 */     super.cancelRefresh(ex);
/*     */   }
/*     */ 
/*     */   protected final void closeBeanFactory()
/*     */   {
/* 151 */     synchronized (this.beanFactoryMonitor) {
/* 152 */       this.beanFactory.setSerializationId(null);
/* 153 */       this.beanFactory = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected final boolean hasBeanFactory()
/*     */   {
/* 162 */     synchronized (this.beanFactoryMonitor) {
/* 163 */       return this.beanFactory != null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public final ConfigurableListableBeanFactory getBeanFactory()
/*     */   {
/* 169 */     synchronized (this.beanFactoryMonitor) {
/* 170 */       if (this.beanFactory == null) {
/* 171 */         throw new IllegalStateException("BeanFactory not initialized or already closed - call 'refresh' before accessing beans via the ApplicationContext");
/*     */       }
/*     */ 
/* 174 */       return this.beanFactory;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected DefaultListableBeanFactory createBeanFactory()
/*     */   {
/* 194 */     return new DefaultListableBeanFactory(getInternalParentBeanFactory());
/*     */   }
/*     */ 
/*     */   protected void customizeBeanFactory(DefaultListableBeanFactory beanFactory)
/*     */   {
/* 212 */     if (this.allowBeanDefinitionOverriding != null) {
/* 213 */       beanFactory.setAllowBeanDefinitionOverriding(this.allowBeanDefinitionOverriding.booleanValue());
/*     */     }
/* 215 */     if (this.allowCircularReferences != null) {
/* 216 */       beanFactory.setAllowCircularReferences(this.allowCircularReferences.booleanValue());
/*     */     }
/* 218 */     beanFactory.setAutowireCandidateResolver(new QualifierAnnotationAutowireCandidateResolver());
/*     */   }
/*     */ 
/*     */   protected abstract void loadBeanDefinitions(DefaultListableBeanFactory paramDefaultListableBeanFactory)
/*     */     throws BeansException, IOException;
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.AbstractRefreshableApplicationContext
 * JD-Core Version:    0.6.1
 */