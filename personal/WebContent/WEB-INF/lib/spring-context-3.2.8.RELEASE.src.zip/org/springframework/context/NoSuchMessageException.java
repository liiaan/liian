/*    */ package org.springframework.context;
/*    */ 
/*    */ import java.util.Locale;
/*    */ 
/*    */ public class NoSuchMessageException extends RuntimeException
/*    */ {
/*    */   public NoSuchMessageException(String code, Locale locale)
/*    */   {
/* 35 */     super("No message found under code '" + code + "' for locale '" + locale + "'.");
/*    */   }
/*    */ 
/*    */   public NoSuchMessageException(String code)
/*    */   {
/* 43 */     super("No message found under code '" + code + "' for locale '" + Locale.getDefault() + "'.");
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.NoSuchMessageException
 * JD-Core Version:    0.6.1
 */