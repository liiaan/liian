/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ import org.springframework.context.HierarchicalMessageSource;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.MessageSourceResolvable;
/*     */ import org.springframework.context.NoSuchMessageException;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public abstract class AbstractMessageSource extends MessageSourceSupport
/*     */   implements HierarchicalMessageSource
/*     */ {
/*     */   private MessageSource parentMessageSource;
/*     */   private Properties commonMessages;
/*  70 */   private boolean useCodeAsDefaultMessage = false;
/*     */ 
/*     */   public void setParentMessageSource(MessageSource parent)
/*     */   {
/*  74 */     this.parentMessageSource = parent;
/*     */   }
/*     */ 
/*     */   public MessageSource getParentMessageSource() {
/*  78 */     return this.parentMessageSource;
/*     */   }
/*     */ 
/*     */   public void setCommonMessages(Properties commonMessages)
/*     */   {
/*  88 */     this.commonMessages = commonMessages;
/*     */   }
/*     */ 
/*     */   protected Properties getCommonMessages()
/*     */   {
/*  95 */     return this.commonMessages;
/*     */   }
/*     */ 
/*     */   public void setUseCodeAsDefaultMessage(boolean useCodeAsDefaultMessage)
/*     */   {
/* 116 */     this.useCodeAsDefaultMessage = useCodeAsDefaultMessage;
/*     */   }
/*     */ 
/*     */   protected boolean isUseCodeAsDefaultMessage()
/*     */   {
/* 128 */     return this.useCodeAsDefaultMessage;
/*     */   }
/*     */ 
/*     */   public final String getMessage(String code, Object[] args, String defaultMessage, Locale locale)
/*     */   {
/* 133 */     String msg = getMessageInternal(code, args, locale);
/* 134 */     if (msg != null) {
/* 135 */       return msg;
/*     */     }
/* 137 */     if (defaultMessage == null) {
/* 138 */       String fallback = getDefaultMessage(code);
/* 139 */       if (fallback != null) {
/* 140 */         return fallback;
/*     */       }
/*     */     }
/* 143 */     return renderDefaultMessage(defaultMessage, args, locale);
/*     */   }
/*     */ 
/*     */   public final String getMessage(String code, Object[] args, Locale locale) throws NoSuchMessageException {
/* 147 */     String msg = getMessageInternal(code, args, locale);
/* 148 */     if (msg != null) {
/* 149 */       return msg;
/*     */     }
/* 151 */     String fallback = getDefaultMessage(code);
/* 152 */     if (fallback != null) {
/* 153 */       return fallback;
/*     */     }
/* 155 */     throw new NoSuchMessageException(code, locale);
/*     */   }
/*     */ 
/*     */   public final String getMessage(MessageSourceResolvable resolvable, Locale locale)
/*     */     throws NoSuchMessageException
/*     */   {
/* 161 */     String[] codes = resolvable.getCodes();
/* 162 */     if (codes == null) {
/* 163 */       codes = new String[0];
/*     */     }
/* 165 */     for (String code : codes) {
/* 166 */       String msg = getMessageInternal(code, resolvable.getArguments(), locale);
/* 167 */       if (msg != null) {
/* 168 */         return msg;
/*     */       }
/*     */     }
/* 171 */     String defaultMessage = resolvable.getDefaultMessage();
/* 172 */     if (defaultMessage != null) {
/* 173 */       return renderDefaultMessage(defaultMessage, resolvable.getArguments(), locale);
/*     */     }
/* 175 */     if (codes.length > 0) {
/* 176 */       String fallback = getDefaultMessage(codes[0]);
/* 177 */       if (fallback != null) {
/* 178 */         return fallback;
/*     */       }
/*     */     }
/* 181 */     throw new NoSuchMessageException(codes.length > 0 ? codes[(codes.length - 1)] : null, locale);
/*     */   }
/*     */ 
/*     */   protected String getMessageInternal(String code, Object[] args, Locale locale)
/*     */   {
/* 200 */     if (code == null) {
/* 201 */       return null;
/*     */     }
/* 203 */     if (locale == null) {
/* 204 */       locale = Locale.getDefault();
/*     */     }
/* 206 */     Object[] argsToUse = args;
/*     */ 
/* 208 */     if ((!isAlwaysUseMessageFormat()) && (ObjectUtils.isEmpty(args)))
/*     */     {
/* 213 */       String message = resolveCodeWithoutArguments(code, locale);
/* 214 */       if (message != null) {
/* 215 */         return message;
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 223 */       argsToUse = resolveArguments(args, locale);
/*     */ 
/* 225 */       MessageFormat messageFormat = resolveCode(code, locale);
/* 226 */       if (messageFormat != null) {
/* 227 */         synchronized (messageFormat) {
/* 228 */           return messageFormat.format(argsToUse);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 234 */     Properties commonMessages = getCommonMessages();
/* 235 */     if (commonMessages != null) {
/* 236 */       String commonMessage = commonMessages.getProperty(code);
/* 237 */       if (commonMessage != null) {
/* 238 */         return formatMessage(commonMessage, args, locale);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 243 */     return getMessageFromParent(code, argsToUse, locale);
/*     */   }
/*     */ 
/*     */   protected String getMessageFromParent(String code, Object[] args, Locale locale)
/*     */   {
/* 256 */     MessageSource parent = getParentMessageSource();
/* 257 */     if (parent != null) {
/* 258 */       if ((parent instanceof AbstractMessageSource))
/*     */       {
/* 261 */         return ((AbstractMessageSource)parent).getMessageInternal(code, args, locale);
/*     */       }
/*     */ 
/* 265 */       return parent.getMessage(code, args, null, locale);
/*     */     }
/*     */ 
/* 269 */     return null;
/*     */   }
/*     */ 
/*     */   protected String getDefaultMessage(String code)
/*     */   {
/* 283 */     if (isUseCodeAsDefaultMessage()) {
/* 284 */       return code;
/*     */     }
/* 286 */     return null;
/*     */   }
/*     */ 
/*     */   protected Object[] resolveArguments(Object[] args, Locale locale)
/*     */   {
/* 300 */     if (args == null) {
/* 301 */       return new Object[0];
/*     */     }
/* 303 */     List resolvedArgs = new ArrayList(args.length);
/* 304 */     for (Object arg : args) {
/* 305 */       if ((arg instanceof MessageSourceResolvable)) {
/* 306 */         resolvedArgs.add(getMessage((MessageSourceResolvable)arg, locale));
/*     */       }
/*     */       else {
/* 309 */         resolvedArgs.add(arg);
/*     */       }
/*     */     }
/* 312 */     return resolvedArgs.toArray(new Object[resolvedArgs.size()]);
/*     */   }
/*     */ 
/*     */   protected String resolveCodeWithoutArguments(String code, Locale locale)
/*     */   {
/* 333 */     MessageFormat messageFormat = resolveCode(code, locale);
/* 334 */     if (messageFormat != null) {
/* 335 */       synchronized (messageFormat) {
/* 336 */         return messageFormat.format(new Object[0]);
/*     */       }
/*     */     }
/* 339 */     return null;
/*     */   }
/*     */ 
/*     */   protected abstract MessageFormat resolveCode(String paramString, Locale paramLocale);
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.AbstractMessageSource
 * JD-Core Version:    0.6.1
 */