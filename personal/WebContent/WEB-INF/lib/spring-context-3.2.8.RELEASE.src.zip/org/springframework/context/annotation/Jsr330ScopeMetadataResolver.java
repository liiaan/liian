/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ 
/*     */ public class Jsr330ScopeMetadataResolver
/*     */   implements ScopeMetadataResolver
/*     */ {
/*  44 */   private final Map<String, String> scopeMap = new HashMap();
/*     */ 
/*     */   public Jsr330ScopeMetadataResolver()
/*     */   {
/*  48 */     registerScope("javax.inject.Singleton", "singleton");
/*     */   }
/*     */ 
/*     */   public final void registerScope(Class annotationType, String scopeName)
/*     */   {
/*  59 */     this.scopeMap.put(annotationType.getName(), scopeName);
/*     */   }
/*     */ 
/*     */   public final void registerScope(String annotationType, String scopeName)
/*     */   {
/*  69 */     this.scopeMap.put(annotationType, scopeName);
/*     */   }
/*     */ 
/*     */   protected String resolveScopeName(String annotationType)
/*     */   {
/*  80 */     return (String)this.scopeMap.get(annotationType);
/*     */   }
/*     */ 
/*     */   public ScopeMetadata resolveScopeMetadata(BeanDefinition definition)
/*     */   {
/*  85 */     ScopeMetadata metadata = new ScopeMetadata();
/*  86 */     metadata.setScopeName("prototype");
/*     */     AnnotatedBeanDefinition annDef;
/*     */     String found;
/*  87 */     if ((definition instanceof AnnotatedBeanDefinition)) {
/*  88 */       annDef = (AnnotatedBeanDefinition)definition;
/*  89 */       Set annTypes = annDef.getMetadata().getAnnotationTypes();
/*  90 */       found = null;
/*  91 */       for (String annType : annTypes) {
/*  92 */         Set metaAnns = annDef.getMetadata().getMetaAnnotationTypes(annType);
/*  93 */         if (metaAnns.contains("javax.inject.Scope")) {
/*  94 */           if (found != null) {
/*  95 */             throw new IllegalStateException("Found ambiguous scope annotations on bean class [" + definition.getBeanClassName() + "]: " + found + ", " + annType);
/*     */           }
/*     */ 
/*  98 */           found = annType;
/*  99 */           String scopeName = resolveScopeName(annType);
/* 100 */           if (scopeName == null) {
/* 101 */             throw new IllegalStateException("Unsupported scope annotation - not mapped onto Spring scope name: " + annType);
/*     */           }
/*     */ 
/* 104 */           metadata.setScopeName(scopeName);
/*     */         }
/*     */       }
/*     */     }
/* 108 */     return metadata;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.Jsr330ScopeMetadataResolver
 * JD-Core Version:    0.6.1
 */