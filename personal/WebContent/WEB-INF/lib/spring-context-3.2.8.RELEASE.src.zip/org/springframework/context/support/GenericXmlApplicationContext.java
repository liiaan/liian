/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ 
/*     */ public class GenericXmlApplicationContext extends GenericApplicationContext
/*     */ {
/*  43 */   private final XmlBeanDefinitionReader reader = new XmlBeanDefinitionReader(this);
/*     */ 
/*     */   public GenericXmlApplicationContext()
/*     */   {
/*     */   }
/*     */ 
/*     */   public GenericXmlApplicationContext(Resource[] resources)
/*     */   {
/*  59 */     load(resources);
/*  60 */     refresh();
/*     */   }
/*     */ 
/*     */   public GenericXmlApplicationContext(String[] resourceLocations)
/*     */   {
/*  69 */     load(resourceLocations);
/*  70 */     refresh();
/*     */   }
/*     */ 
/*     */   public GenericXmlApplicationContext(Class<?> relativeClass, String[] resourceNames)
/*     */   {
/*  81 */     load(relativeClass, resourceNames);
/*  82 */     refresh();
/*     */   }
/*     */ 
/*     */   public void setValidating(boolean validating)
/*     */   {
/*  89 */     this.reader.setValidating(validating);
/*     */   }
/*     */ 
/*     */   public void setEnvironment(ConfigurableEnvironment environment)
/*     */   {
/*  98 */     super.setEnvironment(environment);
/*  99 */     this.reader.setEnvironment(getEnvironment());
/*     */   }
/*     */ 
/*     */   public void load(Resource[] resources)
/*     */   {
/* 107 */     this.reader.loadBeanDefinitions(resources);
/*     */   }
/*     */ 
/*     */   public void load(String[] resourceLocations)
/*     */   {
/* 115 */     this.reader.loadBeanDefinitions(resourceLocations);
/*     */   }
/*     */ 
/*     */   public void load(Class<?> relativeClass, String[] resourceNames)
/*     */   {
/* 125 */     Resource[] resources = new Resource[resourceNames.length];
/* 126 */     for (int i = 0; i < resourceNames.length; i++) {
/* 127 */       resources[i] = new ClassPathResource(resourceNames[i], relativeClass);
/*     */     }
/* 129 */     load(resources);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.GenericXmlApplicationContext
 * JD-Core Version:    0.6.1
 */