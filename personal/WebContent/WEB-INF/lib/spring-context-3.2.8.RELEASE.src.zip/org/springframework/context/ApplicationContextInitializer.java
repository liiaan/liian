package org.springframework.context;

public abstract interface ApplicationContextInitializer<C extends ConfigurableApplicationContext>
{
  public abstract void initialize(C paramC);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.ApplicationContextInitializer
 * JD-Core Version:    0.6.1
 */