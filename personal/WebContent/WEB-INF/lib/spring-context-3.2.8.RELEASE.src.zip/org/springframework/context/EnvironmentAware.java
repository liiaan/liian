package org.springframework.context;

import org.springframework.beans.factory.Aware;
import org.springframework.core.env.Environment;

public abstract interface EnvironmentAware extends Aware
{
  public abstract void setEnvironment(Environment paramEnvironment);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.EnvironmentAware
 * JD-Core Version:    0.6.1
 */