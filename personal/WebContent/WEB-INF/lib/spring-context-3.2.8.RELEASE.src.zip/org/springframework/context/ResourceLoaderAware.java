package org.springframework.context;

import org.springframework.beans.factory.Aware;
import org.springframework.core.io.ResourceLoader;

public abstract interface ResourceLoaderAware extends Aware
{
  public abstract void setResourceLoader(ResourceLoader paramResourceLoader);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.ResourceLoaderAware
 * JD-Core Version:    0.6.1
 */