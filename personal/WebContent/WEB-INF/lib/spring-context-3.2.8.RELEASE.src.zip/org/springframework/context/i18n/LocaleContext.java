package org.springframework.context.i18n;

import java.util.Locale;

public abstract interface LocaleContext
{
  public abstract Locale getLocale();
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.i18n.LocaleContext
 * JD-Core Version:    0.6.1
 */