package org.springframework.context;

public abstract interface MessageSourceResolvable
{
  public abstract String[] getCodes();

  public abstract Object[] getArguments();

  public abstract String getDefaultMessage();
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.MessageSourceResolvable
 * JD-Core Version:    0.6.1
 */