/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ public enum FilterType
/*    */ {
/* 38 */   ANNOTATION, 
/*    */ 
/* 44 */   ASSIGNABLE_TYPE, 
/*    */ 
/* 49 */   CUSTOM;
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.FilterType
 * JD-Core Version:    0.6.1
 */