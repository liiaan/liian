/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.ObjectName;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.context.ConfigurableApplicationContext;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class LiveBeansView
/*     */   implements LiveBeansViewMBean, ApplicationContextAware
/*     */ {
/*     */   public static final String MBEAN_DOMAIN_PROPERTY_NAME = "spring.liveBeansView.mbeanDomain";
/*     */   public static final String MBEAN_APPLICATION_KEY = "application";
/*  57 */   private static final Set<ConfigurableApplicationContext> applicationContexts = new LinkedHashSet();
/*     */   private ConfigurableApplicationContext applicationContext;
/*     */ 
/*     */   static void registerApplicationContext(ConfigurableApplicationContext applicationContext)
/*     */   {
/*  61 */     String mbeanDomain = applicationContext.getEnvironment().getProperty("spring.liveBeansView.mbeanDomain");
/*  62 */     if (mbeanDomain != null)
/*  63 */       synchronized (applicationContexts) {
/*  64 */         if (applicationContexts.isEmpty()) {
/*     */           try {
/*  66 */             MBeanServer server = ManagementFactory.getPlatformMBeanServer();
/*  67 */             server.registerMBean(new LiveBeansView(), new ObjectName(mbeanDomain, "application", applicationContext.getApplicationName()));
/*     */           }
/*     */           catch (Exception ex)
/*     */           {
/*  71 */             throw new ApplicationContextException("Failed to register LiveBeansView MBean", ex);
/*     */           }
/*     */         }
/*  74 */         applicationContexts.add(applicationContext);
/*     */       }
/*     */   }
/*     */ 
/*     */   static void unregisterApplicationContext(ConfigurableApplicationContext applicationContext)
/*     */   {
/*  80 */     synchronized (applicationContexts) {
/*  81 */       if ((applicationContexts.remove(applicationContext)) && (applicationContexts.isEmpty()))
/*     */         try {
/*  83 */           MBeanServer server = ManagementFactory.getPlatformMBeanServer();
/*  84 */           String mbeanDomain = applicationContext.getEnvironment().getProperty("spring.liveBeansView.mbeanDomain");
/*  85 */           server.unregisterMBean(new ObjectName(mbeanDomain, "application", applicationContext.getApplicationName()));
/*     */         }
/*     */         catch (Exception ex) {
/*  88 */           throw new ApplicationContextException("Failed to unregister LiveBeansView MBean", ex);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setApplicationContext(ApplicationContext applicationContext)
/*     */   {
/*  98 */     Assert.isTrue(applicationContext instanceof ConfigurableApplicationContext, "ApplicationContext does not implement ConfigurableApplicationContext");
/*     */ 
/* 100 */     this.applicationContext = ((ConfigurableApplicationContext)applicationContext);
/*     */   }
/*     */ 
/*     */   public String getSnapshotAsJson()
/*     */   {
/*     */     Set contexts;
/*     */     Set contexts;
/* 111 */     if (this.applicationContext != null) {
/* 112 */       contexts = Collections.singleton(this.applicationContext);
/*     */     }
/*     */     else {
/* 115 */       contexts = findApplicationContexts();
/*     */     }
/* 117 */     return generateJson(contexts);
/*     */   }
/*     */ 
/*     */   protected Set<ConfigurableApplicationContext> findApplicationContexts()
/*     */   {
/* 126 */     synchronized (applicationContexts) {
/* 127 */       return new LinkedHashSet(applicationContexts);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String generateJson(Set<ConfigurableApplicationContext> contexts)
/*     */   {
/* 143 */     StringBuilder result = new StringBuilder("[\n");
/* 144 */     for (Iterator it = contexts.iterator(); it.hasNext(); ) {
/* 145 */       ConfigurableApplicationContext context = (ConfigurableApplicationContext)it.next();
/* 146 */       result.append("{\n\"context\": \"").append(context.getId()).append("\",\n");
/* 147 */       if (context.getParent() != null) {
/* 148 */         result.append("\"parent\": \"").append(context.getParent().getId()).append("\",\n");
/*     */       }
/*     */       else {
/* 151 */         result.append("\"parent\": null,\n");
/*     */       }
/* 153 */       result.append("\"beans\": [\n");
/* 154 */       ConfigurableListableBeanFactory bf = context.getBeanFactory();
/* 155 */       String[] beanNames = bf.getBeanDefinitionNames();
/* 156 */       boolean elementAppended = false;
/* 157 */       for (String beanName : beanNames) {
/* 158 */         BeanDefinition bd = bf.getBeanDefinition(beanName);
/* 159 */         if (isBeanEligible(beanName, bd, bf)) {
/* 160 */           if (elementAppended) {
/* 161 */             result.append(",\n");
/*     */           }
/* 163 */           result.append("{\n\"bean\": \"").append(beanName).append("\",\n");
/* 164 */           String scope = bd.getScope();
/* 165 */           if (!StringUtils.hasText(scope)) {
/* 166 */             scope = "singleton";
/*     */           }
/* 168 */           result.append("\"scope\": \"").append(scope).append("\",\n");
/* 169 */           Class beanType = bf.getType(beanName);
/* 170 */           if (beanType != null) {
/* 171 */             result.append("\"type\": \"").append(beanType.getName()).append("\",\n");
/*     */           }
/*     */           else {
/* 174 */             result.append("\"type\": null,\n");
/*     */           }
/* 176 */           String resource = StringUtils.replace(bd.getResourceDescription(), "\\", "/");
/* 177 */           result.append("\"resource\": \"").append(resource).append("\",\n");
/* 178 */           result.append("\"dependencies\": [");
/* 179 */           String[] dependencies = bf.getDependenciesForBean(beanName);
/* 180 */           if (dependencies.length > 0) {
/* 181 */             result.append("\"");
/*     */           }
/* 183 */           result.append(StringUtils.arrayToDelimitedString(dependencies, "\", \""));
/* 184 */           if (dependencies.length > 0) {
/* 185 */             result.append("\"");
/*     */           }
/* 187 */           result.append("]\n}");
/* 188 */           elementAppended = true;
/*     */         }
/*     */       }
/* 191 */       result.append("]\n");
/* 192 */       result.append("}");
/* 193 */       if (it.hasNext()) {
/* 194 */         result.append(",\n");
/*     */       }
/*     */     }
/* 197 */     result.append("]");
/* 198 */     return result.toString();
/*     */   }
/*     */ 
/*     */   protected boolean isBeanEligible(String beanName, BeanDefinition bd, ConfigurableBeanFactory bf)
/*     */   {
/* 210 */     return (bd.getRole() != 2) && ((!bd.isLazyInit()) || (bf.containsSingleton(beanName)));
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.LiveBeansView
 * JD-Core Version:    0.6.1
 */