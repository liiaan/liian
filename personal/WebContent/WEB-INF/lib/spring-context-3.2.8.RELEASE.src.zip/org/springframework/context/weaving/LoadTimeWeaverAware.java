package org.springframework.context.weaving;

import org.springframework.beans.factory.Aware;
import org.springframework.instrument.classloading.LoadTimeWeaver;

public abstract interface LoadTimeWeaverAware extends Aware
{
  public abstract void setLoadTimeWeaver(LoadTimeWeaver paramLoadTimeWeaver);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.weaving.LoadTimeWeaverAware
 * JD-Core Version:    0.6.1
 */