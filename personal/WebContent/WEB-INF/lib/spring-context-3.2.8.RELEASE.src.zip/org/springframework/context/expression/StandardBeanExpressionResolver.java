/*     */ package org.springframework.context.expression;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanExpressionException;
/*     */ import org.springframework.beans.factory.config.BeanExpressionContext;
/*     */ import org.springframework.beans.factory.config.BeanExpressionResolver;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.expression.Expression;
/*     */ import org.springframework.expression.ExpressionParser;
/*     */ import org.springframework.expression.ParserContext;
/*     */ import org.springframework.expression.spel.standard.SpelExpressionParser;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.expression.spel.support.StandardTypeConverter;
/*     */ import org.springframework.expression.spel.support.StandardTypeLocator;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class StandardBeanExpressionResolver
/*     */   implements BeanExpressionResolver
/*     */ {
/*     */   public static final String DEFAULT_EXPRESSION_PREFIX = "#{";
/*     */   public static final String DEFAULT_EXPRESSION_SUFFIX = "}";
/*  57 */   private String expressionPrefix = "#{";
/*     */ 
/*  59 */   private String expressionSuffix = "}";
/*     */ 
/*  61 */   private ExpressionParser expressionParser = new SpelExpressionParser();
/*     */ 
/*  63 */   private final Map<String, Expression> expressionCache = new ConcurrentHashMap(256);
/*     */ 
/*  65 */   private final Map<BeanExpressionContext, StandardEvaluationContext> evaluationCache = new ConcurrentHashMap(8);
/*     */ 
/*  68 */   private final ParserContext beanExpressionParserContext = new ParserContext() {
/*     */     public boolean isTemplate() {
/*  70 */       return true;
/*     */     }
/*     */     public String getExpressionPrefix() {
/*  73 */       return StandardBeanExpressionResolver.this.expressionPrefix;
/*     */     }
/*     */     public String getExpressionSuffix() {
/*  76 */       return StandardBeanExpressionResolver.this.expressionSuffix;
/*     */     }
/*  68 */   };
/*     */ 
/*     */   public void setExpressionPrefix(String expressionPrefix)
/*     */   {
/*  87 */     Assert.hasText(expressionPrefix, "Expression prefix must not be empty");
/*  88 */     this.expressionPrefix = expressionPrefix;
/*     */   }
/*     */ 
/*     */   public void setExpressionSuffix(String expressionSuffix)
/*     */   {
/*  97 */     Assert.hasText(expressionSuffix, "Expression suffix must not be empty");
/*  98 */     this.expressionSuffix = expressionSuffix;
/*     */   }
/*     */ 
/*     */   public void setExpressionParser(ExpressionParser expressionParser)
/*     */   {
/* 107 */     Assert.notNull(expressionParser, "ExpressionParser must not be null");
/* 108 */     this.expressionParser = expressionParser;
/*     */   }
/*     */ 
/*     */   public Object evaluate(String value, BeanExpressionContext evalContext) throws BeansException
/*     */   {
/* 113 */     if (!StringUtils.hasLength(value))
/* 114 */       return value;
/*     */     try
/*     */     {
/* 117 */       Expression expr = (Expression)this.expressionCache.get(value);
/* 118 */       if (expr == null) {
/* 119 */         expr = this.expressionParser.parseExpression(value, this.beanExpressionParserContext);
/* 120 */         this.expressionCache.put(value, expr);
/*     */       }
/* 122 */       StandardEvaluationContext sec = (StandardEvaluationContext)this.evaluationCache.get(evalContext);
/* 123 */       if (sec == null) {
/* 124 */         sec = new StandardEvaluationContext();
/* 125 */         sec.setRootObject(evalContext);
/* 126 */         sec.addPropertyAccessor(new BeanExpressionContextAccessor());
/* 127 */         sec.addPropertyAccessor(new BeanFactoryAccessor());
/* 128 */         sec.addPropertyAccessor(new MapAccessor());
/* 129 */         sec.addPropertyAccessor(new EnvironmentAccessor());
/* 130 */         sec.setBeanResolver(new BeanFactoryResolver(evalContext.getBeanFactory()));
/* 131 */         sec.setTypeLocator(new StandardTypeLocator(evalContext.getBeanFactory().getBeanClassLoader()));
/* 132 */         ConversionService conversionService = evalContext.getBeanFactory().getConversionService();
/* 133 */         if (conversionService != null) {
/* 134 */           sec.setTypeConverter(new StandardTypeConverter(conversionService));
/*     */         }
/* 136 */         customizeEvaluationContext(sec);
/* 137 */         this.evaluationCache.put(evalContext, sec);
/*     */       }
/* 139 */       return expr.getValue(sec);
/*     */     }
/*     */     catch (Exception ex) {
/* 142 */       throw new BeanExpressionException("Expression parsing failed", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void customizeEvaluationContext(StandardEvaluationContext evalContext)
/*     */   {
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.expression.StandardBeanExpressionResolver
 * JD-Core Version:    0.6.1
 */