/*    */ package org.springframework.context.support;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.factory.ObjectFactory;
/*    */ import org.springframework.beans.factory.config.Scope;
/*    */ import org.springframework.core.NamedThreadLocal;
/*    */ 
/*    */ public class SimpleThreadScope
/*    */   implements Scope
/*    */ {
/* 51 */   private static final Log logger = LogFactory.getLog(SimpleThreadScope.class);
/*    */ 
/* 53 */   private final ThreadLocal<Map<String, Object>> threadScope = new NamedThreadLocal("SimpleThreadScope")
/*    */   {
/*    */     protected Map<String, Object> initialValue()
/*    */     {
/* 57 */       return new HashMap();
/*    */     }
/* 53 */   };
/*    */ 
/*    */   public Object get(String name, ObjectFactory<?> objectFactory)
/*    */   {
/* 63 */     Map scope = (Map)this.threadScope.get();
/* 64 */     Object object = scope.get(name);
/* 65 */     if (object == null) {
/* 66 */       object = objectFactory.getObject();
/* 67 */       scope.put(name, object);
/*    */     }
/* 69 */     return object;
/*    */   }
/*    */ 
/*    */   public Object remove(String name) {
/* 73 */     Map scope = (Map)this.threadScope.get();
/* 74 */     return scope.remove(name);
/*    */   }
/*    */ 
/*    */   public void registerDestructionCallback(String name, Runnable callback) {
/* 78 */     logger.warn("SimpleThreadScope does not support destruction callbacks. Consider using RequestScope in a web environment.");
/*    */   }
/*    */ 
/*    */   public Object resolveContextualObject(String key)
/*    */   {
/* 83 */     return null;
/*    */   }
/*    */ 
/*    */   public String getConversationId() {
/* 87 */     return Thread.currentThread().getName();
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.SimpleThreadScope
 * JD-Core Version:    0.6.1
 */