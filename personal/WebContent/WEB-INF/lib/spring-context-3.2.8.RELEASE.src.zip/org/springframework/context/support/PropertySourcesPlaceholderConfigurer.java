/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Properties;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanInitializationException;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.PlaceholderConfigurerSupport;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.core.env.ConfigurablePropertyResolver;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertiesPropertySource;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.core.env.PropertySources;
/*     */ import org.springframework.core.env.PropertySourcesPropertyResolver;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ public class PropertySourcesPlaceholderConfigurer extends PlaceholderConfigurerSupport
/*     */   implements EnvironmentAware
/*     */ {
/*     */   public static final String LOCAL_PROPERTIES_PROPERTY_SOURCE_NAME = "localProperties";
/*     */   public static final String ENVIRONMENT_PROPERTIES_PROPERTY_SOURCE_NAME = "environmentProperties";
/*     */   private MutablePropertySources propertySources;
/*     */   private Environment environment;
/*     */ 
/*     */   public void setPropertySources(PropertySources propertySources)
/*     */   {
/*  92 */     this.propertySources = new MutablePropertySources(propertySources);
/*     */   }
/*     */ 
/*     */   public void setEnvironment(Environment environment)
/*     */   {
/* 102 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*     */     throws BeansException
/*     */   {
/* 124 */     if (this.propertySources == null) {
/* 125 */       this.propertySources = new MutablePropertySources();
/* 126 */       if (this.environment != null) {
/* 127 */         this.propertySources.addLast(new PropertySource("environmentProperties", this.environment)
/*     */         {
/*     */           public String getProperty(String key)
/*     */           {
/* 131 */             return ((Environment)this.source).getProperty(key);
/*     */           }
/*     */         });
/*     */       }
/*     */       try
/*     */       {
/* 137 */         PropertySource localPropertySource = new PropertiesPropertySource("localProperties", mergeProperties());
/*     */ 
/* 139 */         if (this.localOverride) {
/* 140 */           this.propertySources.addFirst(localPropertySource);
/*     */         }
/*     */         else
/* 143 */           this.propertySources.addLast(localPropertySource);
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/* 147 */         throw new BeanInitializationException("Could not load properties", ex);
/*     */       }
/*     */     }
/*     */ 
/* 151 */     processProperties(beanFactory, new PropertySourcesPropertyResolver(this.propertySources));
/*     */   }
/*     */ 
/*     */   protected void processProperties(ConfigurableListableBeanFactory beanFactoryToProcess, final ConfigurablePropertyResolver propertyResolver)
/*     */     throws BeansException
/*     */   {
/* 161 */     propertyResolver.setPlaceholderPrefix(this.placeholderPrefix);
/* 162 */     propertyResolver.setPlaceholderSuffix(this.placeholderSuffix);
/* 163 */     propertyResolver.setValueSeparator(this.valueSeparator);
/*     */ 
/* 165 */     StringValueResolver valueResolver = new StringValueResolver() {
/*     */       public String resolveStringValue(String strVal) {
/* 167 */         String resolved = PropertySourcesPlaceholderConfigurer.this.ignoreUnresolvablePlaceholders ? propertyResolver.resolvePlaceholders(strVal) : propertyResolver.resolveRequiredPlaceholders(strVal);
/*     */ 
/* 170 */         return resolved.equals(PropertySourcesPlaceholderConfigurer.this.nullValue) ? null : resolved;
/*     */       }
/*     */     };
/* 174 */     doProcessProperties(beanFactoryToProcess, valueResolver);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   protected void processProperties(ConfigurableListableBeanFactory beanFactory, Properties props)
/*     */   {
/* 185 */     throw new UnsupportedOperationException("Call processProperties(ConfigurableListableBeanFactory, ConfigurablePropertyResolver) instead");
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.PropertySourcesPlaceholderConfigurer
 * JD-Core Version:    0.6.1
 */