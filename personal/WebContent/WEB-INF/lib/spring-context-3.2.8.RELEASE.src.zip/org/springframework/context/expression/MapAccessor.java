/*    */ package org.springframework.context.expression;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.expression.AccessException;
/*    */ import org.springframework.expression.EvaluationContext;
/*    */ import org.springframework.expression.PropertyAccessor;
/*    */ import org.springframework.expression.TypedValue;
/*    */ 
/*    */ public class MapAccessor
/*    */   implements PropertyAccessor
/*    */ {
/*    */   public boolean canRead(EvaluationContext context, Object target, String name)
/*    */     throws AccessException
/*    */   {
/* 37 */     Map map = (Map)target;
/* 38 */     return map.containsKey(name);
/*    */   }
/*    */ 
/*    */   public TypedValue read(EvaluationContext context, Object target, String name) throws AccessException {
/* 42 */     Map map = (Map)target;
/* 43 */     Object value = map.get(name);
/* 44 */     if ((value == null) && (!map.containsKey(name))) {
/* 45 */       throw new MapAccessException(name);
/*    */     }
/* 47 */     return new TypedValue(value);
/*    */   }
/*    */ 
/*    */   public boolean canWrite(EvaluationContext context, Object target, String name) throws AccessException {
/* 51 */     return true;
/*    */   }
/*    */ 
/*    */   public void write(EvaluationContext context, Object target, String name, Object newValue) throws AccessException
/*    */   {
/* 56 */     Map map = (Map)target;
/* 57 */     map.put(name, newValue);
/*    */   }
/*    */ 
/*    */   public Class[] getSpecificTargetClasses() {
/* 61 */     return new Class[] { Map.class };
/*    */   }
/*    */ 
/*    */   private static class MapAccessException extends AccessException
/*    */   {
/*    */     private final String key;
/*    */ 
/*    */     public MapAccessException(String key)
/*    */     {
/* 75 */       super();
/* 76 */       this.key = key;
/*    */     }
/*    */ 
/*    */     public String getMessage()
/*    */     {
/* 81 */       return "Map does not contain a value for key '" + this.key + "'";
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.expression.MapAccessor
 * JD-Core Version:    0.6.1
 */