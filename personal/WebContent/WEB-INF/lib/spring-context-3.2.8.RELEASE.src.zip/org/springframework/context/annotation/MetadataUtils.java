/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.core.type.MethodMetadata;
/*    */ 
/*    */ class MetadataUtils
/*    */ {
/*    */   public static AnnotationAttributes attributesFor(AnnotationMetadata metadata, Class<?> annoClass)
/*    */   {
/* 38 */     return attributesFor(metadata, annoClass.getName());
/*    */   }
/*    */ 
/*    */   public static AnnotationAttributes attributesFor(AnnotationMetadata metadata, String annoClassName) {
/* 42 */     return AnnotationAttributes.fromMap(metadata.getAnnotationAttributes(annoClassName, false));
/*    */   }
/*    */ 
/*    */   public static AnnotationAttributes attributesFor(MethodMetadata metadata, Class<?> targetAnno) {
/* 46 */     return AnnotationAttributes.fromMap(metadata.getAnnotationAttributes(targetAnno.getName()));
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.MetadataUtils
 * JD-Core Version:    0.6.1
 */