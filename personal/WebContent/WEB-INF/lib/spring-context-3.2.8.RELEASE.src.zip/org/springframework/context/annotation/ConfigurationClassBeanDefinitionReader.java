/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedGenericBeanDefinition;
/*     */ import org.springframework.beans.factory.annotation.Autowire;
/*     */ import org.springframework.beans.factory.annotation.RequiredAnnotationBeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.parsing.Location;
/*     */ import org.springframework.beans.factory.parsing.Problem;
/*     */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*     */ import org.springframework.beans.factory.parsing.SourceExtractor;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinitionReader;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionReader;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ class ConfigurationClassBeanDefinitionReader
/*     */ {
/*  69 */   private static final Log logger = LogFactory.getLog(ConfigurationClassBeanDefinitionReader.class);
/*     */   private final BeanDefinitionRegistry registry;
/*     */   private final SourceExtractor sourceExtractor;
/*     */   private final ProblemReporter problemReporter;
/*     */   private final MetadataReaderFactory metadataReaderFactory;
/*     */   private final ResourceLoader resourceLoader;
/*     */   private final Environment environment;
/*     */   private final BeanNameGenerator importBeanNameGenerator;
/*     */ 
/*     */   public ConfigurationClassBeanDefinitionReader(BeanDefinitionRegistry registry, SourceExtractor sourceExtractor, ProblemReporter problemReporter, MetadataReaderFactory metadataReaderFactory, ResourceLoader resourceLoader, Environment environment, BeanNameGenerator importBeanNameGenerator)
/*     */   {
/*  95 */     this.registry = registry;
/*  96 */     this.sourceExtractor = sourceExtractor;
/*  97 */     this.problemReporter = problemReporter;
/*  98 */     this.metadataReaderFactory = metadataReaderFactory;
/*  99 */     this.resourceLoader = resourceLoader;
/* 100 */     this.environment = environment;
/* 101 */     this.importBeanNameGenerator = importBeanNameGenerator;
/*     */   }
/*     */ 
/*     */   public void loadBeanDefinitions(Set<ConfigurationClass> configurationModel)
/*     */   {
/* 110 */     for (ConfigurationClass configClass : configurationModel)
/* 111 */       loadBeanDefinitionsForConfigurationClass(configClass);
/*     */   }
/*     */ 
/*     */   private void loadBeanDefinitionsForConfigurationClass(ConfigurationClass configClass)
/*     */   {
/* 120 */     if (configClass.isImported()) {
/* 121 */       registerBeanDefinitionForImportedConfigurationClass(configClass);
/*     */     }
/* 123 */     for (BeanMethod beanMethod : configClass.getBeanMethods()) {
/* 124 */       loadBeanDefinitionsForBeanMethod(beanMethod);
/*     */     }
/* 126 */     loadBeanDefinitionsFromImportedResources(configClass.getImportedResources());
/*     */   }
/*     */ 
/*     */   private void registerBeanDefinitionForImportedConfigurationClass(ConfigurationClass configClass)
/*     */   {
/* 133 */     AnnotationMetadata metadata = configClass.getMetadata();
/* 134 */     BeanDefinition configBeanDef = new AnnotatedGenericBeanDefinition(metadata);
/* 135 */     if (ConfigurationClassUtils.checkConfigurationClassCandidate(configBeanDef, this.metadataReaderFactory)) {
/* 136 */       String configBeanName = this.importBeanNameGenerator.generateBeanName(configBeanDef, this.registry);
/* 137 */       this.registry.registerBeanDefinition(configBeanName, configBeanDef);
/* 138 */       configClass.setBeanName(configBeanName);
/* 139 */       if (logger.isDebugEnabled())
/* 140 */         logger.debug(String.format("Registered bean definition for imported @Configuration class %s", new Object[] { configBeanName }));
/*     */     }
/*     */     else
/*     */     {
/* 144 */       this.problemReporter.error(new InvalidConfigurationImportProblem(metadata.getClassName(), configClass.getResource(), metadata));
/*     */     }
/*     */   }
/*     */ 
/*     */   private void loadBeanDefinitionsForBeanMethod(BeanMethod beanMethod)
/*     */   {
/* 154 */     ConfigurationClass configClass = beanMethod.getConfigurationClass();
/* 155 */     MethodMetadata metadata = beanMethod.getMetadata();
/*     */ 
/* 157 */     ConfigurationClassBeanDefinition beanDef = new ConfigurationClassBeanDefinition(configClass);
/* 158 */     beanDef.setResource(configClass.getResource());
/* 159 */     beanDef.setSource(this.sourceExtractor.extractSource(metadata, configClass.getResource()));
/* 160 */     if (metadata.isStatic())
/*     */     {
/* 162 */       beanDef.setBeanClassName(configClass.getMetadata().getClassName());
/* 163 */       beanDef.setFactoryMethodName(metadata.getMethodName());
/*     */     }
/*     */     else
/*     */     {
/* 167 */       beanDef.setFactoryBeanName(configClass.getBeanName());
/* 168 */       beanDef.setUniqueFactoryMethodName(metadata.getMethodName());
/*     */     }
/* 170 */     beanDef.setAutowireMode(3);
/* 171 */     beanDef.setAttribute(RequiredAnnotationBeanPostProcessor.SKIP_REQUIRED_CHECK_ATTRIBUTE, Boolean.TRUE);
/*     */ 
/* 174 */     AnnotationAttributes role = MetadataUtils.attributesFor(metadata, Role.class);
/* 175 */     if (role != null) {
/* 176 */       beanDef.setRole(((Integer)role.getNumber("value")).intValue());
/*     */     }
/*     */ 
/* 180 */     AnnotationAttributes bean = MetadataUtils.attributesFor(metadata, Bean.class);
/* 181 */     List names = new ArrayList(Arrays.asList(bean.getStringArray("name")));
/* 182 */     String beanName = names.size() > 0 ? (String)names.remove(0) : beanMethod.getMetadata().getMethodName();
/* 183 */     for (String alias : names) {
/* 184 */       this.registry.registerAlias(beanName, alias);
/*     */     }
/*     */ 
/* 188 */     if (this.registry.containsBeanDefinition(beanName)) {
/* 189 */       BeanDefinition existingBeanDef = this.registry.getBeanDefinition(beanName);
/*     */ 
/* 194 */       if ((existingBeanDef instanceof ConfigurationClassBeanDefinition)) {
/* 195 */         ConfigurationClassBeanDefinition ccbd = (ConfigurationClassBeanDefinition)existingBeanDef;
/* 196 */         if (ccbd.getMetadata().getClassName().equals(beanMethod.getConfigurationClass().getMetadata().getClassName())) {
/* 197 */           return;
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 203 */         if (logger.isDebugEnabled()) {
/* 204 */           logger.debug(String.format("Skipping loading bean definition for %s: a definition for bean '%s' already exists. This is likely due to an override in XML.", new Object[] { beanMethod, beanName }));
/*     */         }
/*     */ 
/* 207 */         return;
/*     */       }
/*     */     }
/*     */ 
/* 211 */     if (metadata.isAnnotated(Primary.class.getName())) {
/* 212 */       beanDef.setPrimary(true);
/*     */     }
/*     */ 
/* 216 */     if (metadata.isAnnotated(Lazy.class.getName())) {
/* 217 */       AnnotationAttributes lazy = MetadataUtils.attributesFor(metadata, Lazy.class);
/* 218 */       beanDef.setLazyInit(lazy.getBoolean("value"));
/*     */     }
/* 220 */     else if (configClass.getMetadata().isAnnotated(Lazy.class.getName())) {
/* 221 */       AnnotationAttributes lazy = MetadataUtils.attributesFor(configClass.getMetadata(), Lazy.class);
/* 222 */       beanDef.setLazyInit(lazy.getBoolean("value"));
/*     */     }
/*     */ 
/* 225 */     if (metadata.isAnnotated(DependsOn.class.getName())) {
/* 226 */       AnnotationAttributes dependsOn = MetadataUtils.attributesFor(metadata, DependsOn.class);
/* 227 */       String[] otherBeans = dependsOn.getStringArray("value");
/* 228 */       if (otherBeans.length > 0) {
/* 229 */         beanDef.setDependsOn(otherBeans);
/*     */       }
/*     */     }
/*     */ 
/* 233 */     Autowire autowire = (Autowire)bean.getEnum("autowire");
/* 234 */     if (autowire.isAutowire()) {
/* 235 */       beanDef.setAutowireMode(autowire.value());
/*     */     }
/*     */ 
/* 238 */     String initMethodName = bean.getString("initMethod");
/* 239 */     if (StringUtils.hasText(initMethodName)) {
/* 240 */       beanDef.setInitMethodName(initMethodName);
/*     */     }
/*     */ 
/* 243 */     String destroyMethodName = bean.getString("destroyMethod");
/* 244 */     if (StringUtils.hasText(destroyMethodName)) {
/* 245 */       beanDef.setDestroyMethodName(destroyMethodName);
/*     */     }
/*     */ 
/* 249 */     ScopedProxyMode proxyMode = ScopedProxyMode.NO;
/* 250 */     AnnotationAttributes scope = MetadataUtils.attributesFor(metadata, Scope.class);
/* 251 */     if (scope != null) {
/* 252 */       beanDef.setScope(scope.getString("value"));
/* 253 */       proxyMode = (ScopedProxyMode)scope.getEnum("proxyMode");
/* 254 */       if (proxyMode == ScopedProxyMode.DEFAULT) {
/* 255 */         proxyMode = ScopedProxyMode.NO;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 260 */     BeanDefinition beanDefToRegister = beanDef;
/* 261 */     if (proxyMode != ScopedProxyMode.NO) {
/* 262 */       BeanDefinitionHolder proxyDef = ScopedProxyCreator.createScopedProxy(new BeanDefinitionHolder(beanDef, beanName), this.registry, proxyMode == ScopedProxyMode.TARGET_CLASS);
/*     */ 
/* 264 */       beanDefToRegister = new ConfigurationClassBeanDefinition((RootBeanDefinition)proxyDef.getBeanDefinition(), configClass);
/*     */     }
/*     */ 
/* 268 */     if (logger.isDebugEnabled()) {
/* 269 */       logger.debug(String.format("Registering bean definition for @Bean method %s.%s()", new Object[] { configClass.getMetadata().getClassName(), beanName }));
/*     */     }
/*     */ 
/* 273 */     this.registry.registerBeanDefinition(beanName, beanDefToRegister);
/*     */   }
/*     */ 
/*     */   private void loadBeanDefinitionsFromImportedResources(Map<String, Class<? extends BeanDefinitionReader>> importedResources)
/*     */   {
/* 280 */     Map readerInstanceCache = new HashMap();
/* 281 */     for (Map.Entry entry : importedResources.entrySet()) {
/* 282 */       String resource = (String)entry.getKey();
/* 283 */       Class readerClass = (Class)entry.getValue();
/* 284 */       if (!readerInstanceCache.containsKey(readerClass)) {
/*     */         try
/*     */         {
/* 287 */           BeanDefinitionReader readerInstance = (BeanDefinitionReader)readerClass.getConstructor(new Class[] { BeanDefinitionRegistry.class }).newInstance(new Object[] { this.registry });
/*     */ 
/* 290 */           if ((readerInstance instanceof AbstractBeanDefinitionReader)) {
/* 291 */             AbstractBeanDefinitionReader abdr = (AbstractBeanDefinitionReader)readerInstance;
/* 292 */             abdr.setResourceLoader(this.resourceLoader);
/* 293 */             abdr.setEnvironment(this.environment);
/*     */           }
/* 295 */           readerInstanceCache.put(readerClass, readerInstance);
/*     */         }
/*     */         catch (Exception ex) {
/* 298 */           throw new IllegalStateException("Could not instantiate BeanDefinitionReader class [" + readerClass.getName() + "]");
/*     */         }
/*     */       }
/*     */ 
/* 302 */       BeanDefinitionReader reader = (BeanDefinitionReader)readerInstanceCache.get(readerClass);
/*     */ 
/* 304 */       reader.loadBeanDefinitions(resource);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class InvalidConfigurationImportProblem extends Problem
/*     */   {
/*     */     public InvalidConfigurationImportProblem(String className, Resource resource, AnnotationMetadata metadata)
/*     */     {
/* 358 */       super(new Location(resource, metadata));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ConfigurationClassBeanDefinition extends RootBeanDefinition
/*     */     implements AnnotatedBeanDefinition
/*     */   {
/*     */     private final AnnotationMetadata annotationMetadata;
/*     */ 
/*     */     public ConfigurationClassBeanDefinition(ConfigurationClass configClass)
/*     */     {
/* 321 */       this.annotationMetadata = configClass.getMetadata();
/* 322 */       setLenientConstructorResolution(false);
/*     */     }
/*     */ 
/*     */     public ConfigurationClassBeanDefinition(RootBeanDefinition original, ConfigurationClass configClass) {
/* 326 */       super();
/* 327 */       this.annotationMetadata = configClass.getMetadata();
/*     */     }
/*     */ 
/*     */     private ConfigurationClassBeanDefinition(ConfigurationClassBeanDefinition original) {
/* 331 */       super();
/* 332 */       this.annotationMetadata = original.annotationMetadata;
/*     */     }
/*     */ 
/*     */     public AnnotationMetadata getMetadata() {
/* 336 */       return this.annotationMetadata;
/*     */     }
/*     */ 
/*     */     public boolean isFactoryMethod(Method candidate)
/*     */     {
/* 341 */       return (super.isFactoryMethod(candidate)) && (BeanAnnotationHelper.isBeanAnnotated(candidate));
/*     */     }
/*     */ 
/*     */     public ConfigurationClassBeanDefinition cloneBeanDefinition()
/*     */     {
/* 346 */       return new ConfigurationClassBeanDefinition(this);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ConfigurationClassBeanDefinitionReader
 * JD-Core Version:    0.6.1
 */