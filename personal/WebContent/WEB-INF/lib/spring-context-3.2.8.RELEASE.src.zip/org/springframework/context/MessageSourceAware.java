package org.springframework.context;

import org.springframework.beans.factory.Aware;

public abstract interface MessageSourceAware extends Aware
{
  public abstract void setMessageSource(MessageSource paramMessageSource);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.MessageSourceAware
 * JD-Core Version:    0.6.1
 */