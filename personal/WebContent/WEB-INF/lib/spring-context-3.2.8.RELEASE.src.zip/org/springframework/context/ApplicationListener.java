package org.springframework.context;

import java.util.EventListener;

public abstract interface ApplicationListener<E extends ApplicationEvent> extends EventListener
{
  public abstract void onApplicationEvent(E paramE);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.ApplicationListener
 * JD-Core Version:    0.6.1
 */