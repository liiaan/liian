/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedActionException;
/*     */ import java.security.PrivilegedExceptionAction;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.MissingResourceException;
/*     */ import java.util.PropertyResourceBundle;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.ResourceBundle.Control;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.core.JdkVersion;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ResourceBundleMessageSource extends AbstractMessageSource
/*     */   implements BeanClassLoaderAware
/*     */ {
/*     */   private String[] basenames;
/*     */   private String defaultEncoding;
/*     */   private boolean fallbackToSystemLocale;
/*     */   private long cacheMillis;
/*     */   private ClassLoader bundleClassLoader;
/*     */   private ClassLoader beanClassLoader;
/*     */   private final Map<String, Map<Locale, ResourceBundle>> cachedResourceBundles;
/*     */   private final Map<ResourceBundle, Map<String, Map<Locale, MessageFormat>>> cachedBundleMessageFormats;
/*     */ 
/*     */   public ResourceBundleMessageSource()
/*     */   {
/*  69 */     this.basenames = new String[0];
/*     */ 
/*  73 */     this.fallbackToSystemLocale = true;
/*     */ 
/*  75 */     this.cacheMillis = -1L;
/*     */ 
/*  79 */     this.beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */ 
/*  88 */     this.cachedResourceBundles = new HashMap();
/*     */ 
/*  99 */     this.cachedBundleMessageFormats = new HashMap();
/*     */   }
/*     */ 
/*     */   public void setBasename(String basename)
/*     */   {
/* 119 */     setBasenames(new String[] { basename });
/*     */   }
/*     */ 
/*     */   public void setBasenames(String[] basenames)
/*     */   {
/* 139 */     if (basenames != null) {
/* 140 */       this.basenames = new String[basenames.length];
/* 141 */       for (int i = 0; i < basenames.length; i++) {
/* 142 */         String basename = basenames[i];
/* 143 */         Assert.hasText(basename, "Basename must not be empty");
/* 144 */         this.basenames[i] = basename.trim();
/*     */       }
/*     */     }
/*     */     else {
/* 148 */       this.basenames = new String[0];
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setDefaultEncoding(String defaultEncoding)
/*     */   {
/* 161 */     this.defaultEncoding = defaultEncoding;
/*     */   }
/*     */ 
/*     */   public void setFallbackToSystemLocale(boolean fallbackToSystemLocale)
/*     */   {
/* 177 */     this.fallbackToSystemLocale = fallbackToSystemLocale;
/*     */   }
/*     */ 
/*     */   public void setCacheSeconds(int cacheSeconds)
/*     */   {
/* 202 */     this.cacheMillis = cacheSeconds * 1000;
/*     */   }
/*     */ 
/*     */   public void setBundleClassLoader(ClassLoader classLoader)
/*     */   {
/* 214 */     this.bundleClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */   protected ClassLoader getBundleClassLoader()
/*     */   {
/* 223 */     return this.bundleClassLoader != null ? this.bundleClassLoader : this.beanClassLoader;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader) {
/* 227 */     this.beanClassLoader = (classLoader != null ? classLoader : ClassUtils.getDefaultClassLoader());
/*     */   }
/*     */ 
/*     */   protected String resolveCodeWithoutArguments(String code, Locale locale)
/*     */   {
/* 237 */     String result = null;
/* 238 */     for (int i = 0; (result == null) && (i < this.basenames.length); i++) {
/* 239 */       ResourceBundle bundle = getResourceBundle(this.basenames[i], locale);
/* 240 */       if (bundle != null) {
/* 241 */         result = getStringOrNull(bundle, code);
/*     */       }
/*     */     }
/* 244 */     return result;
/*     */   }
/*     */ 
/*     */   protected MessageFormat resolveCode(String code, Locale locale)
/*     */   {
/* 253 */     MessageFormat messageFormat = null;
/* 254 */     for (int i = 0; (messageFormat == null) && (i < this.basenames.length); i++) {
/* 255 */       ResourceBundle bundle = getResourceBundle(this.basenames[i], locale);
/* 256 */       if (bundle != null) {
/* 257 */         messageFormat = getMessageFormat(bundle, code, locale);
/*     */       }
/*     */     }
/* 260 */     return messageFormat;
/*     */   }
/*     */ 
/*     */   protected ResourceBundle getResourceBundle(String basename, Locale locale)
/*     */   {
/* 273 */     if (this.cacheMillis >= 0L)
/*     */     {
/* 276 */       return doGetBundle(basename, locale);
/*     */     }
/*     */ 
/* 280 */     synchronized (this.cachedResourceBundles) {
/* 281 */       Map localeMap = (Map)this.cachedResourceBundles.get(basename);
/* 282 */       if (localeMap != null) {
/* 283 */         ResourceBundle bundle = (ResourceBundle)localeMap.get(locale);
/* 284 */         if (bundle != null)
/* 285 */           return bundle;
/*     */       }
/*     */       try
/*     */       {
/* 289 */         ResourceBundle bundle = doGetBundle(basename, locale);
/* 290 */         if (localeMap == null) {
/* 291 */           localeMap = new HashMap();
/* 292 */           this.cachedResourceBundles.put(basename, localeMap);
/*     */         }
/* 294 */         localeMap.put(locale, bundle);
/* 295 */         return bundle;
/*     */       }
/*     */       catch (MissingResourceException ex) {
/* 298 */         if (this.logger.isWarnEnabled()) {
/* 299 */           this.logger.warn("ResourceBundle [" + basename + "] not found for MessageSource: " + ex.getMessage());
/*     */         }
/*     */ 
/* 303 */         return null;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected ResourceBundle doGetBundle(String basename, Locale locale)
/*     */     throws MissingResourceException
/*     */   {
/* 319 */     if (((this.defaultEncoding != null) && (!"ISO-8859-1".equals(this.defaultEncoding))) || (!this.fallbackToSystemLocale) || (this.cacheMillis >= 0L))
/*     */     {
/* 322 */       if (JdkVersion.getMajorJavaVersion() < 3) {
/* 323 */         throw new IllegalStateException("Cannot use 'defaultEncoding', 'fallbackToSystemLocale' and 'cacheSeconds' on the standard ResourceBundleMessageSource when running on Java 5. Consider using ReloadableResourceBundleMessageSource instead.");
/*     */       }
/*     */ 
/* 327 */       return new ControlBasedResourceBundleFactory(null).getBundle(basename, locale);
/*     */     }
/*     */ 
/* 331 */     return ResourceBundle.getBundle(basename, locale, getBundleClassLoader());
/*     */   }
/*     */ 
/*     */   protected MessageFormat getMessageFormat(ResourceBundle bundle, String code, Locale locale)
/*     */     throws MissingResourceException
/*     */   {
/* 348 */     synchronized (this.cachedBundleMessageFormats) {
/* 349 */       Map codeMap = (Map)this.cachedBundleMessageFormats.get(bundle);
/* 350 */       Map localeMap = null;
/* 351 */       if (codeMap != null) {
/* 352 */         localeMap = (Map)codeMap.get(code);
/* 353 */         if (localeMap != null) {
/* 354 */           MessageFormat result = (MessageFormat)localeMap.get(locale);
/* 355 */           if (result != null) {
/* 356 */             return result;
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 361 */       String msg = getStringOrNull(bundle, code);
/* 362 */       if (msg != null) {
/* 363 */         if (codeMap == null) {
/* 364 */           codeMap = new HashMap();
/* 365 */           this.cachedBundleMessageFormats.put(bundle, codeMap);
/*     */         }
/* 367 */         if (localeMap == null) {
/* 368 */           localeMap = new HashMap();
/* 369 */           codeMap.put(code, localeMap);
/*     */         }
/* 371 */         MessageFormat result = createMessageFormat(msg, locale);
/* 372 */         localeMap.put(locale, result);
/* 373 */         return result;
/*     */       }
/*     */ 
/* 376 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getStringOrNull(ResourceBundle bundle, String key) {
/*     */     try {
/* 382 */       return bundle.getString(key);
/*     */     }
/*     */     catch (MissingResourceException ex)
/*     */     {
/*     */     }
/* 387 */     return null;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 396 */     return getClass().getName() + ": basenames=[" + StringUtils.arrayToCommaDelimitedString(this.basenames) + "]";
/*     */   }
/*     */ 
/*     */   private class MessageSourceControl extends ResourceBundle.Control
/*     */   {
/*     */     private MessageSourceControl()
/*     */     {
/*     */     }
/*     */ 
/*     */     public ResourceBundle newBundle(String baseName, Locale locale, String format, ClassLoader loader, boolean reload)
/*     */       throws IllegalAccessException, InstantiationException, IOException
/*     */     {
/* 425 */       if (format.equals("java.properties")) { String bundleName = toBundleName(baseName, locale);
/* 427 */         final String resourceName = toResourceName(bundleName, "properties");
/* 428 */         final ClassLoader classLoader = loader;
/* 429 */         final boolean reloadFlag = reload;
/*     */         InputStream stream;
/*     */         try { stream = (InputStream)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*     */           {
/*     */             public InputStream run() throws IOException {
/* 435 */               InputStream is = null;
/* 436 */               if (reloadFlag) {
/* 437 */                 URL url = classLoader.getResource(resourceName);
/* 438 */                 if (url != null) {
/* 439 */                   URLConnection connection = url.openConnection();
/* 440 */                   if (connection != null) {
/* 441 */                     connection.setUseCaches(false);
/* 442 */                     is = connection.getInputStream();
/*     */                   }
/*     */                 }
/*     */               }
/*     */               else {
/* 447 */                 is = classLoader.getResourceAsStream(resourceName);
/*     */               }
/* 449 */               return is;
/*     */             }
/*     */           });
/*     */         } catch (PrivilegedActionException ex)
/*     */         {
/* 454 */           throw ((IOException)ex.getException());
/*     */         }
/* 456 */         if (stream != null) {
/*     */           try {
/* 458 */             return ResourceBundleMessageSource.this.defaultEncoding != null ? new PropertyResourceBundle(new InputStreamReader(stream, ResourceBundleMessageSource.this.defaultEncoding)) : new PropertyResourceBundle(stream);
/*     */           }
/*     */           finally
/*     */           {
/* 463 */             stream.close();
/*     */           }
/*     */         }
/*     */ 
/* 467 */         return null;
/*     */       }
/*     */ 
/* 471 */       return super.newBundle(baseName, locale, format, loader, reload);
/*     */     }
/*     */ 
/*     */     public Locale getFallbackLocale(String baseName, Locale locale)
/*     */     {
/* 477 */       return ResourceBundleMessageSource.this.fallbackToSystemLocale ? super.getFallbackLocale(baseName, locale) : null;
/*     */     }
/*     */ 
/*     */     public long getTimeToLive(String baseName, Locale locale)
/*     */     {
/* 482 */       return ResourceBundleMessageSource.this.cacheMillis >= 0L ? ResourceBundleMessageSource.this.cacheMillis : super.getTimeToLive(baseName, locale);
/*     */     }
/*     */ 
/*     */     public boolean needsReload(String baseName, Locale locale, String format, ClassLoader loader, ResourceBundle bundle, long loadTime)
/*     */     {
/* 487 */       if (super.needsReload(baseName, locale, format, loader, bundle, loadTime)) {
/* 488 */         ResourceBundleMessageSource.this.cachedBundleMessageFormats.remove(bundle);
/* 489 */         return true;
/*     */       }
/*     */ 
/* 492 */       return false;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ControlBasedResourceBundleFactory
/*     */   {
/*     */     private ControlBasedResourceBundleFactory()
/*     */     {
/*     */     }
/*     */ 
/*     */     public ResourceBundle getBundle(String basename, Locale locale)
/*     */     {
/* 410 */       return ResourceBundle.getBundle(basename, locale, ResourceBundleMessageSource.this.getBundleClassLoader(), new ResourceBundleMessageSource.MessageSourceControl(ResourceBundleMessageSource.this, null));
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.ResourceBundleMessageSource
 * JD-Core Version:    0.6.1
 */