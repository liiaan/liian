package org.springframework.context.annotation;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.beans.factory.support.BeanNameGenerator;

@Retention(RetentionPolicy.RUNTIME)
@Target({java.lang.annotation.ElementType.TYPE})
@Documented
public @interface ComponentScan
{
  public abstract String[] value();

  public abstract String[] basePackages();

  public abstract Class<?>[] basePackageClasses();

  public abstract Class<? extends BeanNameGenerator> nameGenerator();

  public abstract Class<? extends ScopeMetadataResolver> scopeResolver();

  public abstract ScopedProxyMode scopedProxy();

  public abstract String resourcePattern();

  public abstract boolean useDefaultFilters();

  public abstract Filter[] includeFilters();

  public abstract Filter[] excludeFilters();

  @Retention(RetentionPolicy.RUNTIME)
  @Target({})
  public static @interface Filter
  {
    public abstract FilterType type();

    public abstract Class<?>[] value();
  }
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ComponentScan
 * JD-Core Version:    0.6.1
 */