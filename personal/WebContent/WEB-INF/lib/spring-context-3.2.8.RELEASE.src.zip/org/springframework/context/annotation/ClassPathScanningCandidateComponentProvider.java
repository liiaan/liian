/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.EnvironmentCapable;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*     */ import org.springframework.core.io.support.ResourcePatternResolver;
/*     */ import org.springframework.core.io.support.ResourcePatternUtils;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.classreading.CachingMetadataReaderFactory;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.core.type.filter.AnnotationTypeFilter;
/*     */ import org.springframework.core.type.filter.TypeFilter;
/*     */ import org.springframework.stereotype.Component;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class ClassPathScanningCandidateComponentProvider
/*     */   implements EnvironmentCapable, ResourceLoaderAware
/*     */ {
/*     */   static final String DEFAULT_RESOURCE_PATTERN = "**/*.class";
/*  76 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private Environment environment;
/*  80 */   private ResourcePatternResolver resourcePatternResolver = new PathMatchingResourcePatternResolver();
/*     */ 
/*  82 */   private MetadataReaderFactory metadataReaderFactory = new CachingMetadataReaderFactory(this.resourcePatternResolver);
/*     */ 
/*  85 */   private String resourcePattern = "**/*.class";
/*     */ 
/*  87 */   private final List<TypeFilter> includeFilters = new LinkedList();
/*     */ 
/*  89 */   private final List<TypeFilter> excludeFilters = new LinkedList();
/*     */ 
/*     */   public ClassPathScanningCandidateComponentProvider(boolean useDefaultFilters)
/*     */   {
/* 101 */     this(useDefaultFilters, new StandardEnvironment());
/*     */   }
/*     */ 
/*     */   public ClassPathScanningCandidateComponentProvider(boolean useDefaultFilters, Environment environment)
/*     */   {
/* 114 */     if (useDefaultFilters) {
/* 115 */       registerDefaultFilters();
/*     */     }
/* 117 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   public void setResourceLoader(ResourceLoader resourceLoader)
/*     */   {
/* 130 */     this.resourcePatternResolver = ResourcePatternUtils.getResourcePatternResolver(resourceLoader);
/* 131 */     this.metadataReaderFactory = new CachingMetadataReaderFactory(resourceLoader);
/*     */   }
/*     */ 
/*     */   public final ResourceLoader getResourceLoader()
/*     */   {
/* 138 */     return this.resourcePatternResolver;
/*     */   }
/*     */ 
/*     */   public void setMetadataReaderFactory(MetadataReaderFactory metadataReaderFactory)
/*     */   {
/* 149 */     this.metadataReaderFactory = metadataReaderFactory;
/*     */   }
/*     */ 
/*     */   public final MetadataReaderFactory getMetadataReaderFactory()
/*     */   {
/* 156 */     return this.metadataReaderFactory;
/*     */   }
/*     */ 
/*     */   public void setEnvironment(Environment environment)
/*     */   {
/* 166 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   public final Environment getEnvironment() {
/* 170 */     return this.environment;
/*     */   }
/*     */ 
/*     */   public void setResourcePattern(String resourcePattern)
/*     */   {
/* 180 */     Assert.notNull(resourcePattern, "'resourcePattern' must not be null");
/* 181 */     this.resourcePattern = resourcePattern;
/*     */   }
/*     */ 
/*     */   public void addIncludeFilter(TypeFilter includeFilter)
/*     */   {
/* 188 */     this.includeFilters.add(includeFilter);
/*     */   }
/*     */ 
/*     */   public void addExcludeFilter(TypeFilter excludeFilter)
/*     */   {
/* 195 */     this.excludeFilters.add(0, excludeFilter);
/*     */   }
/*     */ 
/*     */   public void resetFilters(boolean useDefaultFilters)
/*     */   {
/* 207 */     this.includeFilters.clear();
/* 208 */     this.excludeFilters.clear();
/* 209 */     if (useDefaultFilters)
/* 210 */       registerDefaultFilters();
/*     */   }
/*     */ 
/*     */   protected void registerDefaultFilters()
/*     */   {
/* 226 */     this.includeFilters.add(new AnnotationTypeFilter(Component.class));
/* 227 */     ClassLoader cl = ClassPathScanningCandidateComponentProvider.class.getClassLoader();
/*     */     try {
/* 229 */       this.includeFilters.add(new AnnotationTypeFilter(cl.loadClass("javax.annotation.ManagedBean"), false));
/*     */ 
/* 231 */       this.logger.debug("JSR-250 'javax.annotation.ManagedBean' found and supported for component scanning");
/*     */     }
/*     */     catch (ClassNotFoundException ex)
/*     */     {
/*     */     }
/*     */     try {
/* 237 */       this.includeFilters.add(new AnnotationTypeFilter(cl.loadClass("javax.inject.Named"), false));
/*     */ 
/* 239 */       this.logger.debug("JSR-330 'javax.inject.Named' annotation found and supported for component scanning");
/*     */     }
/*     */     catch (ClassNotFoundException ex)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public Set<BeanDefinition> findCandidateComponents(String basePackage)
/*     */   {
/* 253 */     Set candidates = new LinkedHashSet();
/*     */     try {
/* 255 */       String packageSearchPath = "classpath*:" + resolveBasePackage(basePackage) + "/" + this.resourcePattern;
/*     */ 
/* 257 */       Resource[] resources = this.resourcePatternResolver.getResources(packageSearchPath);
/* 258 */       boolean traceEnabled = this.logger.isTraceEnabled();
/* 259 */       boolean debugEnabled = this.logger.isDebugEnabled();
/* 260 */       for (Resource resource : resources) {
/* 261 */         if (traceEnabled) {
/* 262 */           this.logger.trace("Scanning " + resource);
/*     */         }
/* 264 */         if (resource.isReadable()) {
/*     */           try {
/* 266 */             MetadataReader metadataReader = this.metadataReaderFactory.getMetadataReader(resource);
/* 267 */             if (isCandidateComponent(metadataReader)) {
/* 268 */               ScannedGenericBeanDefinition sbd = new ScannedGenericBeanDefinition(metadataReader);
/* 269 */               sbd.setResource(resource);
/* 270 */               sbd.setSource(resource);
/* 271 */               if (isCandidateComponent(sbd)) {
/* 272 */                 if (debugEnabled) {
/* 273 */                   this.logger.debug("Identified candidate component class: " + resource);
/*     */                 }
/* 275 */                 candidates.add(sbd);
/*     */               }
/* 278 */               else if (debugEnabled) {
/* 279 */                 this.logger.debug("Ignored because not a concrete top-level class: " + resource);
/*     */               }
/*     */ 
/*     */             }
/* 284 */             else if (traceEnabled) {
/* 285 */               this.logger.trace("Ignored because not matching any filter: " + resource);
/*     */             }
/*     */           }
/*     */           catch (Throwable ex)
/*     */           {
/* 290 */             throw new BeanDefinitionStoreException("Failed to read candidate component class: " + resource, ex);
/*     */           }
/*     */ 
/*     */         }
/* 295 */         else if (traceEnabled) {
/* 296 */           this.logger.trace("Ignored because not readable: " + resource);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 302 */       throw new BeanDefinitionStoreException("I/O failure during classpath scanning", ex);
/*     */     }
/* 304 */     return candidates;
/*     */   }
/*     */ 
/*     */   protected String resolveBasePackage(String basePackage)
/*     */   {
/* 317 */     return ClassUtils.convertClassNameToResourcePath(this.environment.resolveRequiredPlaceholders(basePackage));
/*     */   }
/*     */ 
/*     */   protected boolean isCandidateComponent(MetadataReader metadataReader)
/*     */     throws IOException
/*     */   {
/* 327 */     for (TypeFilter tf : this.excludeFilters) {
/* 328 */       if (tf.match(metadataReader, this.metadataReaderFactory)) {
/* 329 */         return false;
/*     */       }
/*     */     }
/* 332 */     for (TypeFilter tf : this.includeFilters) {
/* 333 */       if (tf.match(metadataReader, this.metadataReaderFactory)) {
/* 334 */         AnnotationMetadata metadata = metadataReader.getAnnotationMetadata();
/* 335 */         if (!metadata.isAnnotated(Profile.class.getName())) {
/* 336 */           return true;
/*     */         }
/* 338 */         AnnotationAttributes profile = MetadataUtils.attributesFor(metadata, Profile.class);
/* 339 */         return this.environment.acceptsProfiles(profile.getStringArray("value"));
/*     */       }
/*     */     }
/* 342 */     return false;
/*     */   }
/*     */ 
/*     */   protected boolean isCandidateComponent(AnnotatedBeanDefinition beanDefinition)
/*     */   {
/* 353 */     return (beanDefinition.getMetadata().isConcrete()) && (beanDefinition.getMetadata().isIndependent());
/*     */   }
/*     */ 
/*     */   public void clearCache()
/*     */   {
/* 361 */     if ((this.metadataReaderFactory instanceof CachingMetadataReaderFactory))
/* 362 */       ((CachingMetadataReaderFactory)this.metadataReaderFactory).clearCache();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider
 * JD-Core Version:    0.6.1
 */