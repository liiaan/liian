/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import org.springframework.beans.factory.annotation.AnnotatedGenericBeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.support.AutowireCandidateQualifier;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionReaderUtils;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.EnvironmentCapable;
/*     */ import org.springframework.core.env.StandardEnvironment;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class AnnotatedBeanDefinitionReader
/*     */ {
/*     */   private final BeanDefinitionRegistry registry;
/*     */   private Environment environment;
/*  51 */   private BeanNameGenerator beanNameGenerator = new AnnotationBeanNameGenerator();
/*     */ 
/*  53 */   private ScopeMetadataResolver scopeMetadataResolver = new AnnotationScopeMetadataResolver();
/*     */ 
/*     */   public AnnotatedBeanDefinitionReader(BeanDefinitionRegistry registry)
/*     */   {
/*  67 */     this(registry, getOrCreateEnvironment(registry));
/*     */   }
/*     */ 
/*     */   public AnnotatedBeanDefinitionReader(BeanDefinitionRegistry registry, Environment environment)
/*     */   {
/*  80 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/*  81 */     Assert.notNull(environment, "Environment must not be null");
/*  82 */     this.registry = registry;
/*  83 */     this.environment = environment;
/*  84 */     AnnotationConfigUtils.registerAnnotationConfigProcessors(this.registry);
/*     */   }
/*     */ 
/*     */   public final BeanDefinitionRegistry getRegistry()
/*     */   {
/*  91 */     return this.registry;
/*     */   }
/*     */ 
/*     */   public void setEnvironment(Environment environment)
/*     */   {
/* 101 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   public void setBeanNameGenerator(BeanNameGenerator beanNameGenerator)
/*     */   {
/* 109 */     this.beanNameGenerator = (beanNameGenerator != null ? beanNameGenerator : new AnnotationBeanNameGenerator());
/*     */   }
/*     */ 
/*     */   public void setScopeMetadataResolver(ScopeMetadataResolver scopeMetadataResolver)
/*     */   {
/* 117 */     this.scopeMetadataResolver = (scopeMetadataResolver != null ? scopeMetadataResolver : new AnnotationScopeMetadataResolver());
/*     */   }
/*     */ 
/*     */   public void register(Class<?>[] annotatedClasses)
/*     */   {
/* 122 */     for (Class annotatedClass : annotatedClasses)
/* 123 */       registerBean(annotatedClass);
/*     */   }
/*     */ 
/*     */   public void registerBean(Class<?> annotatedClass)
/*     */   {
/* 128 */     registerBean(annotatedClass, null, (Class[])null);
/*     */   }
/*     */ 
/*     */   public void registerBean(Class<?> annotatedClass, Class<? extends Annotation>[] qualifiers) {
/* 132 */     registerBean(annotatedClass, null, qualifiers);
/*     */   }
/*     */ 
/*     */   public void registerBean(Class<?> annotatedClass, String name, Class<? extends Annotation>[] qualifiers) {
/* 136 */     AnnotatedGenericBeanDefinition abd = new AnnotatedGenericBeanDefinition(annotatedClass);
/* 137 */     AnnotationMetadata metadata = abd.getMetadata();
/* 138 */     if (metadata.isAnnotated(Profile.class.getName())) {
/* 139 */       AnnotationAttributes profile = MetadataUtils.attributesFor(metadata, Profile.class);
/* 140 */       if (!this.environment.acceptsProfiles(profile.getStringArray("value"))) {
/* 141 */         return;
/*     */       }
/*     */     }
/* 144 */     ScopeMetadata scopeMetadata = this.scopeMetadataResolver.resolveScopeMetadata(abd);
/* 145 */     abd.setScope(scopeMetadata.getScopeName());
/* 146 */     String beanName = name != null ? name : this.beanNameGenerator.generateBeanName(abd, this.registry);
/* 147 */     AnnotationConfigUtils.processCommonDefinitionAnnotations(abd);
/* 148 */     if (qualifiers != null) {
/* 149 */       for (Class qualifier : qualifiers) {
/* 150 */         if (Primary.class.equals(qualifier)) {
/* 151 */           abd.setPrimary(true);
/*     */         }
/* 153 */         else if (Lazy.class.equals(qualifier)) {
/* 154 */           abd.setLazyInit(true);
/*     */         }
/*     */         else {
/* 157 */           abd.addQualifier(new AutowireCandidateQualifier(qualifier));
/*     */         }
/*     */       }
/*     */     }
/* 161 */     BeanDefinitionHolder definitionHolder = new BeanDefinitionHolder(abd, beanName);
/* 162 */     definitionHolder = AnnotationConfigUtils.applyScopedProxyMode(scopeMetadata, definitionHolder, this.registry);
/* 163 */     BeanDefinitionReaderUtils.registerBeanDefinition(definitionHolder, this.registry);
/*     */   }
/*     */ 
/*     */   private static Environment getOrCreateEnvironment(BeanDefinitionRegistry registry)
/*     */   {
/* 172 */     Assert.notNull(registry, "BeanDefinitionRegistry must not be null");
/* 173 */     if ((registry instanceof EnvironmentCapable)) {
/* 174 */       return ((EnvironmentCapable)registry).getEnvironment();
/*     */     }
/* 176 */     return new StandardEnvironment();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.AnnotatedBeanDefinitionReader
 * JD-Core Version:    0.6.1
 */