package org.springframework.context.annotation;

import org.springframework.beans.factory.Aware;
import org.springframework.core.type.AnnotationMetadata;

public abstract interface ImportAware extends Aware
{
  public abstract void setImportMetadata(AnnotationMetadata paramAnnotationMetadata);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ImportAware
 * JD-Core Version:    0.6.1
 */