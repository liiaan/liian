/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.Aware;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.parsing.Location;
/*     */ import org.springframework.beans.factory.parsing.Problem;
/*     */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.NestedIOException;
/*     */ import org.springframework.core.annotation.AnnotationAttributes;
/*     */ import org.springframework.core.env.CompositePropertySource;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.ResourcePropertySource;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.MethodMetadata;
/*     */ import org.springframework.core.type.StandardAnnotationMetadata;
/*     */ import org.springframework.core.type.classreading.MetadataReader;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.core.type.filter.AssignableTypeFilter;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ class ConfigurationClassParser
/*     */ {
/*     */   private final MetadataReaderFactory metadataReaderFactory;
/*     */   private final ProblemReporter problemReporter;
/*     */   private final Environment environment;
/*     */   private final ResourceLoader resourceLoader;
/*     */   private final BeanDefinitionRegistry registry;
/*     */   private final ComponentScanAnnotationParser componentScanParser;
/*  94 */   private final Set<ConfigurationClass> configurationClasses = new LinkedHashSet();
/*     */ 
/*  96 */   private final Map<String, ConfigurationClass> knownSuperclasses = new HashMap();
/*     */ 
/*  98 */   private final Stack<org.springframework.core.env.PropertySource<?>> propertySources = new Stack();
/*     */ 
/* 100 */   private final ImportStack importStack = new ImportStack(null);
/*     */ 
/*     */   public ConfigurationClassParser(MetadataReaderFactory metadataReaderFactory, ProblemReporter problemReporter, Environment environment, ResourceLoader resourceLoader, BeanNameGenerator componentScanBeanNameGenerator, BeanDefinitionRegistry registry)
/*     */   {
/* 111 */     this.metadataReaderFactory = metadataReaderFactory;
/* 112 */     this.problemReporter = problemReporter;
/* 113 */     this.environment = environment;
/* 114 */     this.resourceLoader = resourceLoader;
/* 115 */     this.registry = registry;
/* 116 */     this.componentScanParser = new ComponentScanAnnotationParser(resourceLoader, environment, componentScanBeanNameGenerator, registry);
/*     */   }
/*     */ 
/*     */   public void parse(String className, String beanName)
/*     */     throws IOException
/*     */   {
/* 128 */     MetadataReader reader = this.metadataReaderFactory.getMetadataReader(className);
/* 129 */     processConfigurationClass(new ConfigurationClass(reader, beanName));
/*     */   }
/*     */ 
/*     */   public void parse(Class<?> clazz, String beanName)
/*     */     throws IOException
/*     */   {
/* 138 */     processConfigurationClass(new ConfigurationClass(clazz, beanName));
/*     */   }
/*     */ 
/*     */   protected void processConfigurationClass(ConfigurationClass configClass) throws IOException {
/* 142 */     AnnotationMetadata metadata = configClass.getMetadata();
/* 143 */     if ((this.environment != null) && (metadata.isAnnotated(Profile.class.getName()))) {
/* 144 */       AnnotationAttributes profile = MetadataUtils.attributesFor(metadata, Profile.class);
/* 145 */       if (!this.environment.acceptsProfiles(profile.getStringArray("value")))
/*     */         return;
/*     */     }
/*     */     Iterator it;
/* 150 */     if ((this.configurationClasses.contains(configClass)) && (configClass.getBeanName() != null))
/*     */     {
/* 153 */       this.configurationClasses.remove(configClass);
/* 154 */       for (it = this.knownSuperclasses.values().iterator(); it.hasNext(); ) {
/* 155 */         if (configClass.equals(it.next())) {
/* 156 */           it.remove();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     do
/*     */     {
/* 163 */       metadata = doProcessConfigurationClass(configClass, metadata);
/*     */     }
/* 165 */     while (metadata != null);
/*     */ 
/* 167 */     this.configurationClasses.add(configClass);
/*     */   }
/*     */ 
/*     */   protected AnnotationMetadata doProcessConfigurationClass(ConfigurationClass configClass, AnnotationMetadata metadata)
/*     */     throws IOException
/*     */   {
/* 175 */     processMemberClasses(metadata);
/*     */ 
/* 178 */     AnnotationAttributes propertySource = MetadataUtils.attributesFor(metadata, PropertySource.class);
/*     */ 
/* 180 */     if (propertySource != null) {
/* 181 */       processPropertySource(propertySource);
/*     */     }
/*     */ 
/* 185 */     AnnotationAttributes componentScan = MetadataUtils.attributesFor(metadata, ComponentScan.class);
/* 186 */     if (componentScan != null)
/*     */     {
/* 188 */       Set scannedBeanDefinitions = this.componentScanParser.parse(componentScan, metadata.getClassName());
/*     */ 
/* 192 */       for (BeanDefinitionHolder holder : scannedBeanDefinitions) {
/* 193 */         if (ConfigurationClassUtils.checkConfigurationClassCandidate(holder.getBeanDefinition(), this.metadataReaderFactory)) {
/* 194 */           parse(holder.getBeanDefinition().getBeanClassName(), holder.getBeanName());
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 200 */     Set imports = new LinkedHashSet();
/* 201 */     Set visited = new LinkedHashSet();
/* 202 */     collectImports(metadata, imports, visited);
/* 203 */     if (!imports.isEmpty()) {
/* 204 */       processImport(configClass, metadata, imports, true);
/*     */     }
/*     */ 
/* 208 */     if (metadata.isAnnotated(ImportResource.class.getName())) {
/* 209 */       AnnotationAttributes importResource = MetadataUtils.attributesFor(metadata, ImportResource.class);
/* 210 */       String[] resources = importResource.getStringArray("value");
/* 211 */       Class readerClass = importResource.getClass("reader");
/* 212 */       for (String resource : resources) {
/* 213 */         String resolvedResource = this.environment.resolveRequiredPlaceholders(resource);
/* 214 */         configClass.addImportedResource(resolvedResource, readerClass);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 219 */     Set beanMethods = metadata.getAnnotatedMethods(Bean.class.getName());
/* 220 */     for (MethodMetadata methodMetadata : beanMethods) {
/* 221 */       configClass.addBeanMethod(new BeanMethod(methodMetadata, configClass));
/*     */     }
/*     */ 
/* 225 */     if (metadata.hasSuperClass()) {
/* 226 */       String superclass = metadata.getSuperClassName();
/* 227 */       if (!this.knownSuperclasses.containsKey(superclass)) {
/* 228 */         this.knownSuperclasses.put(superclass, configClass);
/*     */ 
/* 230 */         if ((metadata instanceof StandardAnnotationMetadata)) {
/* 231 */           Class clazz = ((StandardAnnotationMetadata)metadata).getIntrospectedClass();
/* 232 */           return new StandardAnnotationMetadata(clazz.getSuperclass(), true);
/*     */         }
/* 234 */         if (superclass.startsWith("java")) {
/*     */           try
/*     */           {
/* 237 */             return new StandardAnnotationMetadata(this.resourceLoader.getClassLoader().loadClass(superclass), true);
/*     */           }
/*     */           catch (ClassNotFoundException ex)
/*     */           {
/* 241 */             throw new IllegalStateException(ex);
/*     */           }
/*     */         }
/*     */ 
/* 245 */         MetadataReader reader = this.metadataReaderFactory.getMetadataReader(superclass);
/* 246 */         return reader.getAnnotationMetadata();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 252 */     return null;
/*     */   }
/*     */ 
/*     */   private void processMemberClasses(AnnotationMetadata metadata)
/*     */     throws IOException
/*     */   {
/* 261 */     if ((metadata instanceof StandardAnnotationMetadata)) {
/* 262 */       for (Class memberClass : ((StandardAnnotationMetadata)metadata).getIntrospectedClass().getDeclaredClasses()) {
/* 263 */         if (ConfigurationClassUtils.isConfigurationCandidate(new StandardAnnotationMetadata(memberClass))) {
/* 264 */           processConfigurationClass(new ConfigurationClass(memberClass, true));
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/* 269 */       for (String memberClassName : metadata.getMemberClassNames()) {
/* 270 */         MetadataReader reader = this.metadataReaderFactory.getMetadataReader(memberClassName);
/* 271 */         AnnotationMetadata memberClassMetadata = reader.getAnnotationMetadata();
/* 272 */         if (ConfigurationClassUtils.isConfigurationCandidate(memberClassMetadata))
/* 273 */           processConfigurationClass(new ConfigurationClass(reader, true));
/*     */       }
/*     */   }
/*     */ 
/*     */   private void processPropertySource(AnnotationAttributes propertySource)
/*     */     throws IOException
/*     */   {
/* 285 */     String name = propertySource.getString("name");
/* 286 */     String[] locations = propertySource.getStringArray("value");
/* 287 */     int locationCount = locations.length;
/* 288 */     if (locationCount == 0) {
/* 289 */       throw new IllegalArgumentException("At least one @PropertySource(value) location is required");
/*     */     }
/* 291 */     for (int i = 0; i < locationCount; i++) {
/* 292 */       locations[i] = this.environment.resolveRequiredPlaceholders(locations[i]);
/*     */     }
/* 294 */     ClassLoader classLoader = this.resourceLoader.getClassLoader();
/* 295 */     if (!StringUtils.hasText(name)) {
/* 296 */       for (String location : locations) {
/* 297 */         this.propertySources.push(new ResourcePropertySource(location, classLoader));
/*     */       }
/*     */ 
/*     */     }
/* 301 */     else if (locationCount == 1) {
/* 302 */       this.propertySources.push(new ResourcePropertySource(name, locations[0], classLoader));
/*     */     }
/*     */     else {
/* 305 */       CompositePropertySource ps = new CompositePropertySource(name);
/* 306 */       for (int i = locations.length - 1; i >= 0; i--) {
/* 307 */         ps.addPropertySource(new ResourcePropertySource(locations[i], classLoader));
/*     */       }
/* 309 */       this.propertySources.push(ps);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void collectImports(AnnotationMetadata metadata, Set<Object> imports, Set<Object> visited)
/*     */     throws IOException
/*     */   {
/* 328 */     String className = metadata.getClassName();
/* 329 */     if (visited.add(className))
/* 330 */       if ((metadata instanceof StandardAnnotationMetadata)) {
/* 331 */         StandardAnnotationMetadata stdMetadata = (StandardAnnotationMetadata)metadata;
/* 332 */         for (Annotation ann : stdMetadata.getIntrospectedClass().getAnnotations()) {
/* 333 */           if ((!ann.annotationType().getName().startsWith("java")) && (!(ann instanceof Import))) {
/* 334 */             collectImports(new StandardAnnotationMetadata(ann.annotationType()), imports, visited);
/*     */           }
/*     */         }
/* 337 */         Map attributes = stdMetadata.getAnnotationAttributes(Import.class.getName(), false);
/* 338 */         if (attributes != null) {
/* 339 */           Class[] value = (Class[])attributes.get("value");
/* 340 */           if (!ObjectUtils.isEmpty(value))
/* 341 */             imports.addAll(Arrays.asList(value));
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 346 */         for (String annotationType : metadata.getAnnotationTypes()) {
/* 347 */           if ((!className.startsWith("java")) && (!className.equals(Import.class.getName()))) {
/*     */             try {
/* 349 */               collectImports(new StandardAnnotationMetadata(this.resourceLoader.getClassLoader().loadClass(annotationType)), imports, visited);
/*     */             }
/*     */             catch (ClassNotFoundException ex)
/*     */             {
/*     */             }
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 358 */         Map attributes = metadata.getAnnotationAttributes(Import.class.getName(), true);
/* 359 */         if (attributes != null) {
/* 360 */           String[] value = (String[])attributes.get("value");
/* 361 */           if (!ObjectUtils.isEmpty(value))
/* 362 */             imports.addAll(Arrays.asList(value));
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   private void processImport(ConfigurationClass configClass, AnnotationMetadata metadata, Collection<?> classesToImport, boolean checkForCircularImports)
/*     */     throws IOException
/*     */   {
/* 372 */     if ((checkForCircularImports) && (this.importStack.contains(configClass))) {
/* 373 */       this.problemReporter.error(new CircularImportProblem(configClass, this.importStack, configClass.getMetadata()));
/*     */     }
/*     */     else {
/* 376 */       this.importStack.push(configClass);
/*     */       try {
/* 378 */         for (i$ = classesToImport.iterator(); i$.hasNext(); ) { Object candidate = i$.next();
/* 379 */           Object candidateToCheck = (candidate instanceof Class) ? (Class)candidate : this.metadataReaderFactory.getMetadataReader((String)candidate);
/*     */ 
/* 381 */           if (checkAssignability(ImportSelector.class, candidateToCheck))
/*     */           {
/* 383 */             Class candidateClass = (candidate instanceof Class) ? (Class)candidate : this.resourceLoader.getClassLoader().loadClass((String)candidate);
/*     */ 
/* 385 */             ImportSelector selector = (ImportSelector)BeanUtils.instantiateClass(candidateClass, ImportSelector.class);
/* 386 */             processImport(configClass, metadata, Arrays.asList(selector.selectImports(metadata)), false);
/*     */           }
/* 388 */           else if (checkAssignability(ImportBeanDefinitionRegistrar.class, candidateToCheck))
/*     */           {
/* 390 */             Class candidateClass = (candidate instanceof Class) ? (Class)candidate : this.resourceLoader.getClassLoader().loadClass((String)candidate);
/*     */ 
/* 392 */             ImportBeanDefinitionRegistrar registrar = (ImportBeanDefinitionRegistrar)BeanUtils.instantiateClass(candidateClass, ImportBeanDefinitionRegistrar.class);
/* 393 */             invokeAwareMethods(registrar);
/* 394 */             registrar.registerBeanDefinitions(metadata, this.registry);
/*     */           }
/*     */           else
/*     */           {
/* 398 */             this.importStack.registerImport(metadata, (candidate instanceof Class) ? ((Class)candidate).getName() : (String)candidate);
/*     */ 
/* 400 */             processConfigurationClass((candidateToCheck instanceof Class) ? new ConfigurationClass((Class)candidateToCheck, true) : new ConfigurationClass((MetadataReader)candidateToCheck, true));
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (ClassNotFoundException ex)
/*     */       {
/*     */         Iterator i$;
/* 406 */         throw new NestedIOException("Failed to load import candidate class", ex);
/*     */       }
/*     */       finally {
/* 409 */         this.importStack.pop();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean checkAssignability(Class<?> clazz, Object candidate) throws IOException {
/* 415 */     if ((candidate instanceof Class)) {
/* 416 */       return clazz.isAssignableFrom((Class)candidate);
/*     */     }
/*     */ 
/* 419 */     return new AssignableTypeFilter(clazz).match((MetadataReader)candidate, this.metadataReaderFactory);
/*     */   }
/*     */ 
/*     */   private void invokeAwareMethods(ImportBeanDefinitionRegistrar registrar)
/*     */   {
/* 428 */     if ((registrar instanceof Aware)) {
/* 429 */       if ((registrar instanceof ResourceLoaderAware)) {
/* 430 */         ((ResourceLoaderAware)registrar).setResourceLoader(this.resourceLoader);
/*     */       }
/* 432 */       if ((registrar instanceof BeanClassLoaderAware)) {
/* 433 */         ClassLoader classLoader = (this.registry instanceof ConfigurableBeanFactory) ? ((ConfigurableBeanFactory)this.registry).getBeanClassLoader() : this.resourceLoader.getClassLoader();
/*     */ 
/* 436 */         ((BeanClassLoaderAware)registrar).setBeanClassLoader(classLoader);
/*     */       }
/* 438 */       if (((registrar instanceof BeanFactoryAware)) && ((this.registry instanceof BeanFactory)))
/* 439 */         ((BeanFactoryAware)registrar).setBeanFactory((BeanFactory)this.registry);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void validate()
/*     */   {
/* 450 */     for (ConfigurationClass configClass : this.configurationClasses)
/* 451 */       configClass.validate(this.problemReporter);
/*     */   }
/*     */ 
/*     */   public Set<ConfigurationClass> getConfigurationClasses()
/*     */   {
/* 456 */     return this.configurationClasses;
/*     */   }
/*     */ 
/*     */   public Stack<org.springframework.core.env.PropertySource<?>> getPropertySources() {
/* 460 */     return this.propertySources;
/*     */   }
/*     */ 
/*     */   ImportRegistry getImportRegistry() {
/* 464 */     return this.importStack;
/*     */   }
/*     */ 
/*     */   private static class CircularImportProblem extends Problem
/*     */   {
/*     */     public CircularImportProblem(ConfigurationClass attemptedImport, Stack<ConfigurationClass> importStack, AnnotationMetadata metadata)
/*     */     {
/* 533 */       super(new Location(((ConfigurationClass)importStack.peek()).getResource(), metadata));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ImportStack extends Stack<ConfigurationClass>
/*     */     implements ConfigurationClassParser.ImportRegistry
/*     */   {
/* 477 */     private final Map<String, AnnotationMetadata> imports = new HashMap();
/*     */ 
/*     */     public void registerImport(AnnotationMetadata importingClass, String importedClass) {
/* 480 */       this.imports.put(importedClass, importingClass);
/*     */     }
/*     */ 
/*     */     public AnnotationMetadata getImportingClassFor(String importedClass) {
/* 484 */       return (AnnotationMetadata)this.imports.get(importedClass);
/*     */     }
/*     */ 
/*     */     public boolean contains(Object elem)
/*     */     {
/* 494 */       ConfigurationClass configClass = (ConfigurationClass)elem;
/* 495 */       Comparator comparator = new Comparator() {
/*     */         public int compare(ConfigurationClass first, ConfigurationClass second) {
/* 497 */           return first.getMetadata().getClassName().equals(second.getMetadata().getClassName()) ? 0 : 1;
/*     */         }
/*     */       };
/* 500 */       return Collections.binarySearch(this, configClass, comparator) != -1;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 514 */       StringBuilder builder = new StringBuilder("ImportStack: [");
/* 515 */       Iterator iterator = iterator();
/* 516 */       while (iterator.hasNext()) {
/* 517 */         builder.append(((ConfigurationClass)iterator.next()).getSimpleName());
/* 518 */         if (iterator.hasNext()) {
/* 519 */           builder.append("->");
/*     */         }
/*     */       }
/* 522 */       return ']';
/*     */     }
/*     */   }
/*     */ 
/*     */   static abstract interface ImportRegistry
/*     */   {
/*     */     public abstract AnnotationMetadata getImportingClassFor(String paramString);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ConfigurationClassParser
 * JD-Core Version:    0.6.1
 */