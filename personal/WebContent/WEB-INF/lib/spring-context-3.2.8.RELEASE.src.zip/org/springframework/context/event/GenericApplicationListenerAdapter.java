/*    */ package org.springframework.context.event;
/*    */ 
/*    */ import org.springframework.aop.support.AopUtils;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.core.GenericTypeResolver;
/*    */ import org.springframework.core.Ordered;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class GenericApplicationListenerAdapter
/*    */   implements SmartApplicationListener
/*    */ {
/*    */   private final ApplicationListener delegate;
/*    */ 
/*    */   public GenericApplicationListenerAdapter(ApplicationListener delegate)
/*    */   {
/* 44 */     Assert.notNull(delegate, "Delegate listener must not be null");
/* 45 */     this.delegate = delegate;
/*    */   }
/*    */ 
/*    */   public void onApplicationEvent(ApplicationEvent event)
/*    */   {
/* 51 */     this.delegate.onApplicationEvent(event);
/*    */   }
/*    */ 
/*    */   public boolean supportsEventType(Class<? extends ApplicationEvent> eventType) {
/* 55 */     Class typeArg = GenericTypeResolver.resolveTypeArgument(this.delegate.getClass(), ApplicationListener.class);
/* 56 */     if ((typeArg == null) || (typeArg.equals(ApplicationEvent.class))) {
/* 57 */       Class targetClass = AopUtils.getTargetClass(this.delegate);
/* 58 */       if (targetClass != this.delegate.getClass()) {
/* 59 */         typeArg = GenericTypeResolver.resolveTypeArgument(targetClass, ApplicationListener.class);
/*    */       }
/*    */     }
/* 62 */     return (typeArg == null) || (typeArg.isAssignableFrom(eventType));
/*    */   }
/*    */ 
/*    */   public boolean supportsSourceType(Class<?> sourceType) {
/* 66 */     return true;
/*    */   }
/*    */ 
/*    */   public int getOrder() {
/* 70 */     return (this.delegate instanceof Ordered) ? ((Ordered)this.delegate).getOrder() : 2147483647;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.event.GenericApplicationListenerAdapter
 * JD-Core Version:    0.6.1
 */