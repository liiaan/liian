/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.annotation.Documented;
/*     */ import java.lang.annotation.Retention;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.lang.annotation.Target;
/*     */ 
/*     */ @Target({java.lang.annotation.ElementType.TYPE})
/*     */ @Retention(RetentionPolicy.RUNTIME)
/*     */ @Documented
/*     */ @Import({LoadTimeWeavingConfiguration.class})
/*     */ public @interface EnableLoadTimeWeaving
/*     */ {
/*     */   public abstract AspectJWeaving aspectjWeaving();
/*     */ 
/*     */   public static enum AspectJWeaving
/*     */   {
/* 145 */     ENABLED, 
/*     */ 
/* 151 */     DISABLED, 
/*     */ 
/* 158 */     AUTODETECT;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.EnableLoadTimeWeaving
 * JD-Core Version:    0.6.1
 */