/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.Stack;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.beans.factory.config.SingletonBeanRegistry;
/*     */ import org.springframework.beans.factory.parsing.FailFastProblemReporter;
/*     */ import org.springframework.beans.factory.parsing.PassThroughSourceExtractor;
/*     */ import org.springframework.beans.factory.parsing.ProblemReporter;
/*     */ import org.springframework.beans.factory.parsing.SourceExtractor;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
/*     */ import org.springframework.beans.factory.support.BeanNameGenerator;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.context.EnvironmentAware;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.PriorityOrdered;
/*     */ import org.springframework.core.env.ConfigurableEnvironment;
/*     */ import org.springframework.core.env.Environment;
/*     */ import org.springframework.core.env.MutablePropertySources;
/*     */ import org.springframework.core.env.PropertySource;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.type.AnnotationMetadata;
/*     */ import org.springframework.core.type.classreading.CachingMetadataReaderFactory;
/*     */ import org.springframework.core.type.classreading.MetadataReaderFactory;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class ConfigurationClassPostProcessor
/*     */   implements BeanDefinitionRegistryPostProcessor, Ordered, ResourceLoaderAware, BeanClassLoaderAware, EnvironmentAware
/*     */ {
/*  88 */   private static final String IMPORT_AWARE_PROCESSOR_BEAN_NAME = ConfigurationClassPostProcessor.class.getName() + ".importAwareProcessor";
/*     */ 
/*  91 */   private static final String IMPORT_REGISTRY_BEAN_NAME = ConfigurationClassPostProcessor.class.getName() + ".importRegistry";
/*     */   private final Log logger;
/*     */   private SourceExtractor sourceExtractor;
/*     */   private ProblemReporter problemReporter;
/*     */   private Environment environment;
/*     */   private ResourceLoader resourceLoader;
/*     */   private ClassLoader beanClassLoader;
/*     */   private MetadataReaderFactory metadataReaderFactory;
/*     */   private boolean setMetadataReaderFactoryCalled;
/*     */   private final Set<Integer> registriesPostProcessed;
/*     */   private final Set<Integer> factoriesPostProcessed;
/*     */   private ConfigurationClassBeanDefinitionReader reader;
/*     */   private boolean localBeanNameGeneratorSet;
/*     */   private BeanNameGenerator componentScanBeanNameGenerator;
/*     */   private BeanNameGenerator importBeanNameGenerator;
/*     */ 
/*     */   public ConfigurationClassPostProcessor()
/*     */   {
/*  95 */     this.logger = LogFactory.getLog(getClass());
/*     */ 
/*  97 */     this.sourceExtractor = new PassThroughSourceExtractor();
/*     */ 
/*  99 */     this.problemReporter = new FailFastProblemReporter();
/*     */ 
/* 103 */     this.resourceLoader = new DefaultResourceLoader();
/*     */ 
/* 105 */     this.beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */ 
/* 107 */     this.metadataReaderFactory = new CachingMetadataReaderFactory();
/*     */ 
/* 109 */     this.setMetadataReaderFactoryCalled = false;
/*     */ 
/* 111 */     this.registriesPostProcessed = new HashSet();
/*     */ 
/* 113 */     this.factoriesPostProcessed = new HashSet();
/*     */ 
/* 117 */     this.localBeanNameGeneratorSet = false;
/*     */ 
/* 120 */     this.componentScanBeanNameGenerator = new AnnotationBeanNameGenerator();
/*     */ 
/* 123 */     this.importBeanNameGenerator = new AnnotationBeanNameGenerator()
/*     */     {
/*     */       protected String buildDefaultBeanName(BeanDefinition definition) {
/* 126 */         return definition.getBeanClassName();
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public int getOrder() {
/* 132 */     return -2147483648;
/*     */   }
/*     */ 
/*     */   public void setSourceExtractor(SourceExtractor sourceExtractor)
/*     */   {
/* 140 */     this.sourceExtractor = (sourceExtractor != null ? sourceExtractor : new PassThroughSourceExtractor());
/*     */   }
/*     */ 
/*     */   public void setProblemReporter(ProblemReporter problemReporter)
/*     */   {
/* 150 */     this.problemReporter = (problemReporter != null ? problemReporter : new FailFastProblemReporter());
/*     */   }
/*     */ 
/*     */   public void setMetadataReaderFactory(MetadataReaderFactory metadataReaderFactory)
/*     */   {
/* 159 */     Assert.notNull(metadataReaderFactory, "MetadataReaderFactory must not be null");
/* 160 */     this.metadataReaderFactory = metadataReaderFactory;
/* 161 */     this.setMetadataReaderFactoryCalled = true;
/*     */   }
/*     */ 
/*     */   public void setBeanNameGenerator(BeanNameGenerator beanNameGenerator)
/*     */   {
/* 182 */     Assert.notNull(beanNameGenerator, "BeanNameGenerator must not be null");
/* 183 */     this.localBeanNameGeneratorSet = true;
/* 184 */     this.componentScanBeanNameGenerator = beanNameGenerator;
/* 185 */     this.importBeanNameGenerator = beanNameGenerator;
/*     */   }
/*     */ 
/*     */   public void setEnvironment(Environment environment) {
/* 189 */     Assert.notNull(environment, "Environment must not be null");
/* 190 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   public void setResourceLoader(ResourceLoader resourceLoader) {
/* 194 */     Assert.notNull(resourceLoader, "ResourceLoader must not be null");
/* 195 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader beanClassLoader) {
/* 199 */     this.beanClassLoader = beanClassLoader;
/* 200 */     if (!this.setMetadataReaderFactoryCalled)
/* 201 */       this.metadataReaderFactory = new CachingMetadataReaderFactory(beanClassLoader);
/*     */   }
/*     */ 
/*     */   public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry registry)
/*     */   {
/* 210 */     RootBeanDefinition iabpp = new RootBeanDefinition(ImportAwareBeanPostProcessor.class);
/* 211 */     iabpp.setRole(2);
/* 212 */     registry.registerBeanDefinition(IMPORT_AWARE_PROCESSOR_BEAN_NAME, iabpp);
/*     */ 
/* 214 */     int registryId = System.identityHashCode(registry);
/* 215 */     if (this.registriesPostProcessed.contains(Integer.valueOf(registryId))) {
/* 216 */       throw new IllegalStateException("postProcessBeanDefinitionRegistry already called for this post-processor against " + registry);
/*     */     }
/*     */ 
/* 219 */     if (this.factoriesPostProcessed.contains(Integer.valueOf(registryId))) {
/* 220 */       throw new IllegalStateException("postProcessBeanFactory already called for this post-processor against " + registry);
/*     */     }
/*     */ 
/* 223 */     this.registriesPostProcessed.add(Integer.valueOf(registryId));
/*     */ 
/* 225 */     processConfigBeanDefinitions(registry);
/*     */   }
/*     */ 
/*     */   public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*     */   {
/* 233 */     int factoryId = System.identityHashCode(beanFactory);
/* 234 */     if (this.factoriesPostProcessed.contains(Integer.valueOf(factoryId))) {
/* 235 */       throw new IllegalStateException("postProcessBeanFactory already called for this post-processor against " + beanFactory);
/*     */     }
/*     */ 
/* 238 */     this.factoriesPostProcessed.add(Integer.valueOf(factoryId));
/* 239 */     if (!this.registriesPostProcessed.contains(Integer.valueOf(factoryId)))
/*     */     {
/* 242 */       processConfigBeanDefinitions((BeanDefinitionRegistry)beanFactory);
/*     */     }
/* 244 */     enhanceConfigurationClasses(beanFactory);
/*     */   }
/*     */ 
/*     */   public void processConfigBeanDefinitions(BeanDefinitionRegistry registry)
/*     */   {
/* 252 */     Set configCandidates = new LinkedHashSet();
/* 253 */     for (String beanName : registry.getBeanDefinitionNames()) {
/* 254 */       BeanDefinition beanDef = registry.getBeanDefinition(beanName);
/* 255 */       if (ConfigurationClassUtils.checkConfigurationClassCandidate(beanDef, this.metadataReaderFactory)) {
/* 256 */         configCandidates.add(new BeanDefinitionHolder(beanDef, beanName));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 261 */     if (configCandidates.isEmpty()) {
/* 262 */       return;
/*     */     }
/*     */ 
/* 266 */     SingletonBeanRegistry singletonRegistry = null;
/* 267 */     if ((registry instanceof SingletonBeanRegistry)) {
/* 268 */       singletonRegistry = (SingletonBeanRegistry)registry;
/* 269 */       if ((!this.localBeanNameGeneratorSet) && (singletonRegistry.containsSingleton("org.springframework.context.annotation.internalConfigurationBeanNameGenerator"))) {
/* 270 */         BeanNameGenerator generator = (BeanNameGenerator)singletonRegistry.getSingleton("org.springframework.context.annotation.internalConfigurationBeanNameGenerator");
/* 271 */         this.componentScanBeanNameGenerator = generator;
/* 272 */         this.importBeanNameGenerator = generator;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 277 */     ConfigurationClassParser parser = new ConfigurationClassParser(this.metadataReaderFactory, this.problemReporter, this.environment, this.resourceLoader, this.componentScanBeanNameGenerator, registry);
/*     */ 
/* 280 */     for (BeanDefinitionHolder holder : configCandidates) {
/* 281 */       BeanDefinition bd = holder.getBeanDefinition();
/*     */       try {
/* 283 */         if (((bd instanceof AbstractBeanDefinition)) && (((AbstractBeanDefinition)bd).hasBeanClass())) {
/* 284 */           parser.parse(((AbstractBeanDefinition)bd).getBeanClass(), holder.getBeanName());
/*     */         }
/*     */         else
/* 287 */           parser.parse(bd.getBeanClassName(), holder.getBeanName());
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/* 291 */         throw new BeanDefinitionStoreException("Failed to load bean class: " + bd.getBeanClassName(), ex);
/*     */       }
/*     */     }
/* 294 */     parser.validate();
/*     */ 
/* 297 */     Stack parsedPropertySources = parser.getPropertySources();
/* 298 */     if (!parsedPropertySources.isEmpty()) {
/* 299 */       if (!(this.environment instanceof ConfigurableEnvironment)) {
/* 300 */         this.logger.warn("Ignoring @PropertySource annotations. Reason: Environment must implement ConfigurableEnvironment");
/*     */       }
/*     */       else
/*     */       {
/* 304 */         MutablePropertySources envPropertySources = ((ConfigurableEnvironment)this.environment).getPropertySources();
/* 305 */         while (!parsedPropertySources.isEmpty()) {
/* 306 */           envPropertySources.addLast((PropertySource)parsedPropertySources.pop());
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 312 */     if (this.reader == null) {
/* 313 */       this.reader = new ConfigurationClassBeanDefinitionReader(registry, this.sourceExtractor, this.problemReporter, this.metadataReaderFactory, this.resourceLoader, this.environment, this.importBeanNameGenerator);
/*     */     }
/*     */ 
/* 317 */     this.reader.loadBeanDefinitions(parser.getConfigurationClasses());
/*     */ 
/* 320 */     if ((singletonRegistry != null) && 
/* 321 */       (!singletonRegistry.containsSingleton(IMPORT_REGISTRY_BEAN_NAME))) {
/* 322 */       singletonRegistry.registerSingleton(IMPORT_REGISTRY_BEAN_NAME, parser.getImportRegistry());
/*     */     }
/*     */ 
/* 326 */     if ((this.metadataReaderFactory instanceof CachingMetadataReaderFactory))
/* 327 */       ((CachingMetadataReaderFactory)this.metadataReaderFactory).clearCache();
/*     */   }
/*     */ 
/*     */   public void enhanceConfigurationClasses(ConfigurableListableBeanFactory beanFactory)
/*     */   {
/* 338 */     Map configBeanDefs = new LinkedHashMap();
/* 339 */     for (String beanName : beanFactory.getBeanDefinitionNames()) {
/* 340 */       BeanDefinition beanDef = beanFactory.getBeanDefinition(beanName);
/* 341 */       if (ConfigurationClassUtils.isFullConfigurationClass(beanDef)) {
/* 342 */         if (!(beanDef instanceof AbstractBeanDefinition)) {
/* 343 */           throw new BeanDefinitionStoreException("Cannot enhance @Configuration bean definition '" + beanName + "' since it is not stored in an AbstractBeanDefinition subclass");
/*     */         }
/*     */ 
/* 346 */         configBeanDefs.put(beanName, (AbstractBeanDefinition)beanDef);
/*     */       }
/*     */     }
/* 349 */     if (configBeanDefs.isEmpty())
/*     */     {
/* 351 */       return;
/*     */     }
/* 353 */     ConfigurationClassEnhancer enhancer = new ConfigurationClassEnhancer(beanFactory);
/* 354 */     for (Map.Entry entry : configBeanDefs.entrySet()) {
/* 355 */       AbstractBeanDefinition beanDef = (AbstractBeanDefinition)entry.getValue();
/*     */       try {
/* 357 */         Class configClass = beanDef.resolveBeanClass(this.beanClassLoader);
/* 358 */         Class enhancedClass = enhancer.enhance(configClass);
/* 359 */         if (configClass != enhancedClass) {
/* 360 */           if (this.logger.isDebugEnabled()) {
/* 361 */             this.logger.debug(String.format("Replacing bean definition '%s' existing class name '%s' with enhanced class name '%s'", new Object[] { entry.getKey(), configClass.getName(), enhancedClass.getName() }));
/*     */           }
/*     */ 
/* 364 */           beanDef.setBeanClass(enhancedClass);
/*     */         }
/*     */       }
/*     */       catch (Throwable ex) {
/* 368 */         throw new IllegalStateException("Cannot load configuration class: " + beanDef.getBeanClassName(), ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ImportAwareBeanPostProcessor implements BeanPostProcessor, BeanFactoryAware, PriorityOrdered
/*     */   {
/*     */     private BeanFactory beanFactory;
/*     */ 
/*     */     public void setBeanFactory(BeanFactory beanFactory)
/*     */     {
/* 379 */       this.beanFactory = beanFactory;
/*     */     }
/*     */ 
/*     */     public int getOrder() {
/* 383 */       return -2147483648;
/*     */     }
/*     */ 
/*     */     public Object postProcessBeforeInitialization(Object bean, String beanName)
/*     */     {
/* 388 */       if ((bean instanceof ImportAware)) {
/* 389 */         ConfigurationClassParser.ImportRegistry importRegistry = (ConfigurationClassParser.ImportRegistry)this.beanFactory.getBean(ConfigurationClassPostProcessor.IMPORT_REGISTRY_BEAN_NAME, ConfigurationClassParser.ImportRegistry.class);
/* 390 */         AnnotationMetadata importingClass = importRegistry.getImportingClassFor(bean.getClass().getSuperclass().getName());
/* 391 */         if (importingClass != null) {
/* 392 */           ((ImportAware)bean).setImportMetadata(importingClass);
/*     */         }
/*     */       }
/* 395 */       return bean;
/*     */     }
/*     */ 
/*     */     public Object postProcessAfterInitialization(Object bean, String beanName) {
/* 399 */       return bean;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ConfigurationClassPostProcessor
 * JD-Core Version:    0.6.1
 */