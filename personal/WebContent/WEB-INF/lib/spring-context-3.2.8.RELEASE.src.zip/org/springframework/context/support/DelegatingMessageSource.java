/*    */ package org.springframework.context.support;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.springframework.context.HierarchicalMessageSource;
/*    */ import org.springframework.context.MessageSource;
/*    */ import org.springframework.context.MessageSourceResolvable;
/*    */ import org.springframework.context.NoSuchMessageException;
/*    */ 
/*    */ public class DelegatingMessageSource extends MessageSourceSupport
/*    */   implements HierarchicalMessageSource
/*    */ {
/*    */   private MessageSource parentMessageSource;
/*    */ 
/*    */   public void setParentMessageSource(MessageSource parent)
/*    */   {
/* 43 */     this.parentMessageSource = parent;
/*    */   }
/*    */ 
/*    */   public MessageSource getParentMessageSource() {
/* 47 */     return this.parentMessageSource;
/*    */   }
/*    */ 
/*    */   public String getMessage(String code, Object[] args, String defaultMessage, Locale locale)
/*    */   {
/* 52 */     if (this.parentMessageSource != null) {
/* 53 */       return this.parentMessageSource.getMessage(code, args, defaultMessage, locale);
/*    */     }
/*    */ 
/* 56 */     return renderDefaultMessage(defaultMessage, args, locale);
/*    */   }
/*    */ 
/*    */   public String getMessage(String code, Object[] args, Locale locale) throws NoSuchMessageException
/*    */   {
/* 61 */     if (this.parentMessageSource != null) {
/* 62 */       return this.parentMessageSource.getMessage(code, args, locale);
/*    */     }
/*    */ 
/* 65 */     throw new NoSuchMessageException(code, locale);
/*    */   }
/*    */ 
/*    */   public String getMessage(MessageSourceResolvable resolvable, Locale locale) throws NoSuchMessageException
/*    */   {
/* 70 */     if (this.parentMessageSource != null) {
/* 71 */       return this.parentMessageSource.getMessage(resolvable, locale);
/*    */     }
/*    */ 
/* 74 */     if (resolvable.getDefaultMessage() != null) {
/* 75 */       return renderDefaultMessage(resolvable.getDefaultMessage(), resolvable.getArguments(), locale);
/*    */     }
/* 77 */     String[] codes = resolvable.getCodes();
/* 78 */     String code = (codes != null) && (codes.length > 0) ? codes[0] : null;
/* 79 */     throw new NoSuchMessageException(code, locale);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.DelegatingMessageSource
 * JD-Core Version:    0.6.1
 */