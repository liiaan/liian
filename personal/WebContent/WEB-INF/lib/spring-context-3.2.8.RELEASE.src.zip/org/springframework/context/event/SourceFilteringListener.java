/*    */ package org.springframework.context.event;
/*    */ 
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ 
/*    */ public class SourceFilteringListener
/*    */   implements SmartApplicationListener
/*    */ {
/*    */   private final Object source;
/*    */   private SmartApplicationListener delegate;
/*    */ 
/*    */   public SourceFilteringListener(Object source, ApplicationListener delegate)
/*    */   {
/* 49 */     this.source = source;
/* 50 */     this.delegate = ((delegate instanceof SmartApplicationListener) ? (SmartApplicationListener)delegate : new GenericApplicationListenerAdapter(delegate));
/*    */   }
/*    */ 
/*    */   protected SourceFilteringListener(Object source)
/*    */   {
/* 62 */     this.source = source;
/*    */   }
/*    */ 
/*    */   public void onApplicationEvent(ApplicationEvent event)
/*    */   {
/* 67 */     if (event.getSource() == this.source)
/* 68 */       onApplicationEventInternal(event);
/*    */   }
/*    */ 
/*    */   public boolean supportsEventType(Class<? extends ApplicationEvent> eventType)
/*    */   {
/* 73 */     return (this.delegate == null) || (this.delegate.supportsEventType(eventType));
/*    */   }
/*    */ 
/*    */   public boolean supportsSourceType(Class<?> sourceType) {
/* 77 */     return (sourceType != null) && (sourceType.isInstance(this.source));
/*    */   }
/*    */ 
/*    */   public int getOrder() {
/* 81 */     return this.delegate != null ? this.delegate.getOrder() : 2147483647;
/*    */   }
/*    */ 
/*    */   protected void onApplicationEventInternal(ApplicationEvent event)
/*    */   {
/* 92 */     if (this.delegate == null) {
/* 93 */       throw new IllegalStateException("Must specify a delegate object or override the onApplicationEventInternal method");
/*    */     }
/*    */ 
/* 96 */     this.delegate.onApplicationEvent(event);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.event.SourceFilteringListener
 * JD-Core Version:    0.6.1
 */