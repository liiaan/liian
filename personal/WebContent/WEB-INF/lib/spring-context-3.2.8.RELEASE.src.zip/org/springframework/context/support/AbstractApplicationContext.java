/*      */ package org.springframework.context.support;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.lang.annotation.Annotation;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Date;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.springframework.beans.BeansException;
/*      */ import org.springframework.beans.factory.BeanFactory;
/*      */ import org.springframework.beans.factory.DisposableBean;
/*      */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*      */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*      */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*      */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*      */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*      */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*      */ import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
/*      */ import org.springframework.beans.factory.support.MergedBeanDefinitionPostProcessor;
/*      */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*      */ import org.springframework.beans.support.ResourceEditorRegistrar;
/*      */ import org.springframework.context.ApplicationContext;
/*      */ import org.springframework.context.ApplicationContextAware;
/*      */ import org.springframework.context.ApplicationEvent;
/*      */ import org.springframework.context.ApplicationEventPublisher;
/*      */ import org.springframework.context.ApplicationEventPublisherAware;
/*      */ import org.springframework.context.ApplicationListener;
/*      */ import org.springframework.context.ConfigurableApplicationContext;
/*      */ import org.springframework.context.EnvironmentAware;
/*      */ import org.springframework.context.HierarchicalMessageSource;
/*      */ import org.springframework.context.LifecycleProcessor;
/*      */ import org.springframework.context.MessageSource;
/*      */ import org.springframework.context.MessageSourceAware;
/*      */ import org.springframework.context.MessageSourceResolvable;
/*      */ import org.springframework.context.NoSuchMessageException;
/*      */ import org.springframework.context.ResourceLoaderAware;
/*      */ import org.springframework.context.event.ApplicationEventMulticaster;
/*      */ import org.springframework.context.event.ContextClosedEvent;
/*      */ import org.springframework.context.event.ContextRefreshedEvent;
/*      */ import org.springframework.context.event.ContextStartedEvent;
/*      */ import org.springframework.context.event.ContextStoppedEvent;
/*      */ import org.springframework.context.event.SimpleApplicationEventMulticaster;
/*      */ import org.springframework.context.expression.StandardBeanExpressionResolver;
/*      */ import org.springframework.context.weaving.LoadTimeWeaverAware;
/*      */ import org.springframework.context.weaving.LoadTimeWeaverAwareProcessor;
/*      */ import org.springframework.core.OrderComparator;
/*      */ import org.springframework.core.Ordered;
/*      */ import org.springframework.core.PriorityOrdered;
/*      */ import org.springframework.core.convert.ConversionService;
/*      */ import org.springframework.core.env.ConfigurableEnvironment;
/*      */ import org.springframework.core.env.Environment;
/*      */ import org.springframework.core.env.StandardEnvironment;
/*      */ import org.springframework.core.io.DefaultResourceLoader;
/*      */ import org.springframework.core.io.Resource;
/*      */ import org.springframework.core.io.ResourceLoader;
/*      */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*      */ import org.springframework.core.io.support.ResourcePatternResolver;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ 
/*      */ public abstract class AbstractApplicationContext extends DefaultResourceLoader
/*      */   implements ConfigurableApplicationContext, DisposableBean
/*      */ {
/*      */   public static final String MESSAGE_SOURCE_BEAN_NAME = "messageSource";
/*      */   public static final String LIFECYCLE_PROCESSOR_BEAN_NAME = "lifecycleProcessor";
/*      */   public static final String APPLICATION_EVENT_MULTICASTER_BEAN_NAME = "applicationEventMulticaster";
/*  164 */   protected final Log logger = LogFactory.getLog(getClass());
/*      */ 
/*  167 */   private String id = ObjectUtils.identityToString(this);
/*      */ 
/*  170 */   private String displayName = ObjectUtils.identityToString(this);
/*      */   private ApplicationContext parent;
/*  176 */   private final List<BeanFactoryPostProcessor> beanFactoryPostProcessors = new ArrayList();
/*      */   private long startupDate;
/*  183 */   private boolean active = false;
/*      */ 
/*  186 */   private boolean closed = false;
/*      */ 
/*  189 */   private final Object activeMonitor = new Object();
/*      */ 
/*  192 */   private final Object startupShutdownMonitor = new Object();
/*      */   private Thread shutdownHook;
/*      */   private ResourcePatternResolver resourcePatternResolver;
/*      */   private LifecycleProcessor lifecycleProcessor;
/*      */   private MessageSource messageSource;
/*      */   private ApplicationEventMulticaster applicationEventMulticaster;
/*  210 */   private Set<ApplicationListener<?>> applicationListeners = new LinkedHashSet();
/*      */   private ConfigurableEnvironment environment;
/*      */ 
/*      */   public AbstractApplicationContext()
/*      */   {
/*  220 */     this.resourcePatternResolver = getResourcePatternResolver();
/*      */   }
/*      */ 
/*      */   public AbstractApplicationContext(ApplicationContext parent)
/*      */   {
/*  228 */     this();
/*  229 */     setParent(parent);
/*      */   }
/*      */ 
/*      */   public void setId(String id)
/*      */   {
/*  244 */     this.id = id;
/*      */   }
/*      */ 
/*      */   public String getId() {
/*  248 */     return this.id;
/*      */   }
/*      */ 
/*      */   public String getApplicationName() {
/*  252 */     return "";
/*      */   }
/*      */ 
/*      */   public void setDisplayName(String displayName)
/*      */   {
/*  261 */     Assert.hasLength(displayName, "Display name must not be empty");
/*  262 */     this.displayName = displayName;
/*      */   }
/*      */ 
/*      */   public String getDisplayName()
/*      */   {
/*  270 */     return this.displayName;
/*      */   }
/*      */ 
/*      */   public ApplicationContext getParent()
/*      */   {
/*  278 */     return this.parent;
/*      */   }
/*      */ 
/*      */   public ConfigurableEnvironment getEnvironment()
/*      */   {
/*  287 */     if (this.environment == null) {
/*  288 */       this.environment = createEnvironment();
/*      */     }
/*  290 */     return this.environment;
/*      */   }
/*      */ 
/*      */   public void setEnvironment(ConfigurableEnvironment environment)
/*      */   {
/*  302 */     this.environment = environment;
/*      */   }
/*      */ 
/*      */   public AutowireCapableBeanFactory getAutowireCapableBeanFactory()
/*      */     throws IllegalStateException
/*      */   {
/*  311 */     return getBeanFactory();
/*      */   }
/*      */ 
/*      */   public long getStartupDate()
/*      */   {
/*  318 */     return this.startupDate;
/*      */   }
/*      */ 
/*      */   public void publishEvent(ApplicationEvent event)
/*      */   {
/*  330 */     Assert.notNull(event, "Event must not be null");
/*  331 */     if (this.logger.isTraceEnabled()) {
/*  332 */       this.logger.trace("Publishing event in " + getDisplayName() + ": " + event);
/*      */     }
/*  334 */     getApplicationEventMulticaster().multicastEvent(event);
/*  335 */     if (this.parent != null)
/*  336 */       this.parent.publishEvent(event);
/*      */   }
/*      */ 
/*      */   private ApplicationEventMulticaster getApplicationEventMulticaster()
/*      */     throws IllegalStateException
/*      */   {
/*  346 */     if (this.applicationEventMulticaster == null) {
/*  347 */       throw new IllegalStateException("ApplicationEventMulticaster not initialized - call 'refresh' before multicasting events via the context: " + this);
/*      */     }
/*      */ 
/*  350 */     return this.applicationEventMulticaster;
/*      */   }
/*      */ 
/*      */   private LifecycleProcessor getLifecycleProcessor()
/*      */   {
/*  359 */     if (this.lifecycleProcessor == null) {
/*  360 */       throw new IllegalStateException("LifecycleProcessor not initialized - call 'refresh' before invoking lifecycle methods via the context: " + this);
/*      */     }
/*      */ 
/*  363 */     return this.lifecycleProcessor;
/*      */   }
/*      */ 
/*      */   protected ResourcePatternResolver getResourcePatternResolver()
/*      */   {
/*  381 */     return new PathMatchingResourcePatternResolver(this);
/*      */   }
/*      */ 
/*      */   public void setParent(ApplicationContext parent)
/*      */   {
/*  398 */     this.parent = parent;
/*  399 */     if (parent != null) {
/*  400 */       Environment parentEnvironment = parent.getEnvironment();
/*  401 */       if ((parentEnvironment instanceof ConfigurableEnvironment))
/*  402 */         getEnvironment().merge((ConfigurableEnvironment)parentEnvironment);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void addBeanFactoryPostProcessor(BeanFactoryPostProcessor beanFactoryPostProcessor)
/*      */   {
/*  408 */     this.beanFactoryPostProcessors.add(beanFactoryPostProcessor);
/*      */   }
/*      */ 
/*      */   public List<BeanFactoryPostProcessor> getBeanFactoryPostProcessors()
/*      */   {
/*  417 */     return this.beanFactoryPostProcessors;
/*      */   }
/*      */ 
/*      */   public void addApplicationListener(ApplicationListener<?> listener) {
/*  421 */     if (this.applicationEventMulticaster != null) {
/*  422 */       this.applicationEventMulticaster.addApplicationListener(listener);
/*      */     }
/*      */     else
/*  425 */       this.applicationListeners.add(listener);
/*      */   }
/*      */ 
/*      */   public Collection<ApplicationListener<?>> getApplicationListeners()
/*      */   {
/*  433 */     return this.applicationListeners;
/*      */   }
/*      */ 
/*      */   protected ConfigurableEnvironment createEnvironment()
/*      */   {
/*  442 */     return new StandardEnvironment();
/*      */   }
/*      */ 
/*      */   public void refresh() throws BeansException, IllegalStateException {
/*  446 */     synchronized (this.startupShutdownMonitor)
/*      */     {
/*  448 */       prepareRefresh();
/*      */ 
/*  451 */       ConfigurableListableBeanFactory beanFactory = obtainFreshBeanFactory();
/*      */ 
/*  454 */       prepareBeanFactory(beanFactory);
/*      */       try
/*      */       {
/*  458 */         postProcessBeanFactory(beanFactory);
/*      */ 
/*  461 */         invokeBeanFactoryPostProcessors(beanFactory);
/*      */ 
/*  464 */         registerBeanPostProcessors(beanFactory);
/*      */ 
/*  467 */         initMessageSource();
/*      */ 
/*  470 */         initApplicationEventMulticaster();
/*      */ 
/*  473 */         onRefresh();
/*      */ 
/*  476 */         registerListeners();
/*      */ 
/*  479 */         finishBeanFactoryInitialization(beanFactory);
/*      */ 
/*  482 */         finishRefresh();
/*      */       }
/*      */       catch (BeansException ex)
/*      */       {
/*  487 */         destroyBeans();
/*      */ 
/*  490 */         cancelRefresh(ex);
/*      */ 
/*  493 */         throw ex;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void prepareRefresh()
/*      */   {
/*  503 */     this.startupDate = System.currentTimeMillis();
/*      */ 
/*  505 */     synchronized (this.activeMonitor) {
/*  506 */       this.active = true;
/*      */     }
/*      */ 
/*  509 */     if (this.logger.isInfoEnabled()) {
/*  510 */       this.logger.info("Refreshing " + this);
/*      */     }
/*      */ 
/*  514 */     initPropertySources();
/*      */ 
/*  518 */     getEnvironment().validateRequiredProperties();
/*      */   }
/*      */ 
/*      */   protected void initPropertySources()
/*      */   {
/*      */   }
/*      */ 
/*      */   protected ConfigurableListableBeanFactory obtainFreshBeanFactory()
/*      */   {
/*  537 */     refreshBeanFactory();
/*  538 */     ConfigurableListableBeanFactory beanFactory = getBeanFactory();
/*  539 */     if (this.logger.isDebugEnabled()) {
/*  540 */       this.logger.debug("Bean factory for " + getDisplayName() + ": " + beanFactory);
/*      */     }
/*  542 */     return beanFactory;
/*      */   }
/*      */ 
/*      */   protected void prepareBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*      */   {
/*  552 */     beanFactory.setBeanClassLoader(getClassLoader());
/*  553 */     beanFactory.setBeanExpressionResolver(new StandardBeanExpressionResolver());
/*  554 */     beanFactory.addPropertyEditorRegistrar(new ResourceEditorRegistrar(this, getEnvironment()));
/*      */ 
/*  557 */     beanFactory.addBeanPostProcessor(new ApplicationContextAwareProcessor(this));
/*  558 */     beanFactory.ignoreDependencyInterface(ResourceLoaderAware.class);
/*  559 */     beanFactory.ignoreDependencyInterface(ApplicationEventPublisherAware.class);
/*  560 */     beanFactory.ignoreDependencyInterface(MessageSourceAware.class);
/*  561 */     beanFactory.ignoreDependencyInterface(ApplicationContextAware.class);
/*  562 */     beanFactory.ignoreDependencyInterface(EnvironmentAware.class);
/*      */ 
/*  566 */     beanFactory.registerResolvableDependency(BeanFactory.class, beanFactory);
/*  567 */     beanFactory.registerResolvableDependency(ResourceLoader.class, this);
/*  568 */     beanFactory.registerResolvableDependency(ApplicationEventPublisher.class, this);
/*  569 */     beanFactory.registerResolvableDependency(ApplicationContext.class, this);
/*      */ 
/*  572 */     if (beanFactory.containsBean("loadTimeWeaver")) {
/*  573 */       beanFactory.addBeanPostProcessor(new LoadTimeWeaverAwareProcessor(beanFactory));
/*      */ 
/*  575 */       beanFactory.setTempClassLoader(new ContextTypeMatchClassLoader(beanFactory.getBeanClassLoader()));
/*      */     }
/*      */ 
/*  579 */     if (!beanFactory.containsLocalBean("environment")) {
/*  580 */       beanFactory.registerSingleton("environment", getEnvironment());
/*      */     }
/*  582 */     if (!beanFactory.containsLocalBean("systemProperties")) {
/*  583 */       beanFactory.registerSingleton("systemProperties", getEnvironment().getSystemProperties());
/*      */     }
/*  585 */     if (!beanFactory.containsLocalBean("systemEnvironment"))
/*  586 */       beanFactory.registerSingleton("systemEnvironment", getEnvironment().getSystemEnvironment());
/*      */   }
/*      */ 
/*      */   protected void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory)
/*      */   {
/*      */   }
/*      */ 
/*      */   protected void invokeBeanFactoryPostProcessors(ConfigurableListableBeanFactory beanFactory)
/*      */   {
/*  607 */     Set processedBeans = new HashSet();
/*  608 */     if ((beanFactory instanceof BeanDefinitionRegistry)) {
/*  609 */       BeanDefinitionRegistry registry = (BeanDefinitionRegistry)beanFactory;
/*  610 */       List regularPostProcessors = new LinkedList();
/*  611 */       List registryPostProcessors = new LinkedList();
/*      */ 
/*  613 */       for (BeanFactoryPostProcessor postProcessor : getBeanFactoryPostProcessors()) {
/*  614 */         if ((postProcessor instanceof BeanDefinitionRegistryPostProcessor)) {
/*  615 */           BeanDefinitionRegistryPostProcessor registryPostProcessor = (BeanDefinitionRegistryPostProcessor)postProcessor;
/*      */ 
/*  617 */           registryPostProcessor.postProcessBeanDefinitionRegistry(registry);
/*  618 */           registryPostProcessors.add(registryPostProcessor);
/*      */         }
/*      */         else {
/*  621 */           regularPostProcessors.add(postProcessor);
/*      */         }
/*      */       }
/*  624 */       Map beanMap = beanFactory.getBeansOfType(BeanDefinitionRegistryPostProcessor.class, true, false);
/*      */ 
/*  626 */       List registryPostProcessorBeans = new ArrayList(beanMap.values());
/*      */ 
/*  628 */       OrderComparator.sort(registryPostProcessorBeans);
/*  629 */       for (BeanDefinitionRegistryPostProcessor postProcessor : registryPostProcessorBeans) {
/*  630 */         postProcessor.postProcessBeanDefinitionRegistry(registry);
/*      */       }
/*  632 */       invokeBeanFactoryPostProcessors(registryPostProcessors, beanFactory);
/*  633 */       invokeBeanFactoryPostProcessors(registryPostProcessorBeans, beanFactory);
/*  634 */       invokeBeanFactoryPostProcessors(regularPostProcessors, beanFactory);
/*  635 */       processedBeans.addAll(beanMap.keySet());
/*      */     }
/*      */     else
/*      */     {
/*  639 */       invokeBeanFactoryPostProcessors(getBeanFactoryPostProcessors(), beanFactory);
/*      */     }
/*      */ 
/*  644 */     String[] postProcessorNames = beanFactory.getBeanNamesForType(BeanFactoryPostProcessor.class, true, false);
/*      */ 
/*  649 */     List priorityOrderedPostProcessors = new ArrayList();
/*  650 */     List orderedPostProcessorNames = new ArrayList();
/*  651 */     List nonOrderedPostProcessorNames = new ArrayList();
/*  652 */     for (String ppName : postProcessorNames) {
/*  653 */       if (!processedBeans.contains(ppName))
/*      */       {
/*  656 */         if (isTypeMatch(ppName, PriorityOrdered.class)) {
/*  657 */           priorityOrderedPostProcessors.add(beanFactory.getBean(ppName, BeanFactoryPostProcessor.class));
/*      */         }
/*  659 */         else if (isTypeMatch(ppName, Ordered.class)) {
/*  660 */           orderedPostProcessorNames.add(ppName);
/*      */         }
/*      */         else {
/*  663 */           nonOrderedPostProcessorNames.add(ppName);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  668 */     OrderComparator.sort(priorityOrderedPostProcessors);
/*  669 */     invokeBeanFactoryPostProcessors(priorityOrderedPostProcessors, beanFactory);
/*      */ 
/*  672 */     List orderedPostProcessors = new ArrayList();
/*  673 */     for (String postProcessorName : orderedPostProcessorNames) {
/*  674 */       orderedPostProcessors.add(getBean(postProcessorName, BeanFactoryPostProcessor.class));
/*      */     }
/*  676 */     OrderComparator.sort(orderedPostProcessors);
/*  677 */     invokeBeanFactoryPostProcessors(orderedPostProcessors, beanFactory);
/*      */ 
/*  680 */     List nonOrderedPostProcessors = new ArrayList();
/*  681 */     for (String postProcessorName : nonOrderedPostProcessorNames) {
/*  682 */       nonOrderedPostProcessors.add(getBean(postProcessorName, BeanFactoryPostProcessor.class));
/*      */     }
/*  684 */     invokeBeanFactoryPostProcessors(nonOrderedPostProcessors, beanFactory);
/*      */   }
/*      */ 
/*      */   private void invokeBeanFactoryPostProcessors(Collection<? extends BeanFactoryPostProcessor> postProcessors, ConfigurableListableBeanFactory beanFactory)
/*      */   {
/*  693 */     for (BeanFactoryPostProcessor postProcessor : postProcessors)
/*  694 */       postProcessor.postProcessBeanFactory(beanFactory);
/*      */   }
/*      */ 
/*      */   protected void registerBeanPostProcessors(ConfigurableListableBeanFactory beanFactory)
/*      */   {
/*  704 */     String[] postProcessorNames = beanFactory.getBeanNamesForType(BeanPostProcessor.class, true, false);
/*      */ 
/*  709 */     int beanProcessorTargetCount = beanFactory.getBeanPostProcessorCount() + 1 + postProcessorNames.length;
/*  710 */     beanFactory.addBeanPostProcessor(new BeanPostProcessorChecker(beanFactory, beanProcessorTargetCount));
/*      */ 
/*  714 */     List priorityOrderedPostProcessors = new ArrayList();
/*  715 */     List internalPostProcessors = new ArrayList();
/*  716 */     List orderedPostProcessorNames = new ArrayList();
/*  717 */     List nonOrderedPostProcessorNames = new ArrayList();
/*  718 */     for (String ppName : postProcessorNames) {
/*  719 */       if (isTypeMatch(ppName, PriorityOrdered.class)) {
/*  720 */         BeanPostProcessor pp = (BeanPostProcessor)beanFactory.getBean(ppName, BeanPostProcessor.class);
/*  721 */         priorityOrderedPostProcessors.add(pp);
/*  722 */         if ((pp instanceof MergedBeanDefinitionPostProcessor)) {
/*  723 */           internalPostProcessors.add(pp);
/*      */         }
/*      */       }
/*  726 */       else if (isTypeMatch(ppName, Ordered.class)) {
/*  727 */         orderedPostProcessorNames.add(ppName);
/*      */       }
/*      */       else {
/*  730 */         nonOrderedPostProcessorNames.add(ppName);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  735 */     OrderComparator.sort(priorityOrderedPostProcessors);
/*  736 */     registerBeanPostProcessors(beanFactory, priorityOrderedPostProcessors);
/*      */ 
/*  739 */     List orderedPostProcessors = new ArrayList();
/*  740 */     for (String ppName : orderedPostProcessorNames) {
/*  741 */       BeanPostProcessor pp = (BeanPostProcessor)beanFactory.getBean(ppName, BeanPostProcessor.class);
/*  742 */       orderedPostProcessors.add(pp);
/*  743 */       if ((pp instanceof MergedBeanDefinitionPostProcessor)) {
/*  744 */         internalPostProcessors.add(pp);
/*      */       }
/*      */     }
/*  747 */     OrderComparator.sort(orderedPostProcessors);
/*  748 */     registerBeanPostProcessors(beanFactory, orderedPostProcessors);
/*      */ 
/*  751 */     List nonOrderedPostProcessors = new ArrayList();
/*  752 */     for (String ppName : nonOrderedPostProcessorNames) {
/*  753 */       BeanPostProcessor pp = (BeanPostProcessor)beanFactory.getBean(ppName, BeanPostProcessor.class);
/*  754 */       nonOrderedPostProcessors.add(pp);
/*  755 */       if ((pp instanceof MergedBeanDefinitionPostProcessor)) {
/*  756 */         internalPostProcessors.add(pp);
/*      */       }
/*      */     }
/*  759 */     registerBeanPostProcessors(beanFactory, nonOrderedPostProcessors);
/*      */ 
/*  762 */     OrderComparator.sort(internalPostProcessors);
/*  763 */     registerBeanPostProcessors(beanFactory, internalPostProcessors);
/*      */ 
/*  765 */     beanFactory.addBeanPostProcessor(new ApplicationListenerDetector(null));
/*      */   }
/*      */ 
/*      */   private void registerBeanPostProcessors(ConfigurableListableBeanFactory beanFactory, List<BeanPostProcessor> postProcessors)
/*      */   {
/*  774 */     for (BeanPostProcessor postProcessor : postProcessors)
/*  775 */       beanFactory.addBeanPostProcessor(postProcessor);
/*      */   }
/*      */ 
/*      */   protected void initMessageSource()
/*      */   {
/*  784 */     ConfigurableListableBeanFactory beanFactory = getBeanFactory();
/*  785 */     if (beanFactory.containsLocalBean("messageSource")) {
/*  786 */       this.messageSource = ((MessageSource)beanFactory.getBean("messageSource", MessageSource.class));
/*      */ 
/*  788 */       if ((this.parent != null) && ((this.messageSource instanceof HierarchicalMessageSource))) {
/*  789 */         HierarchicalMessageSource hms = (HierarchicalMessageSource)this.messageSource;
/*  790 */         if (hms.getParentMessageSource() == null)
/*      */         {
/*  793 */           hms.setParentMessageSource(getInternalParentMessageSource());
/*      */         }
/*      */       }
/*  796 */       if (this.logger.isDebugEnabled()) {
/*  797 */         this.logger.debug("Using MessageSource [" + this.messageSource + "]");
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  802 */       DelegatingMessageSource dms = new DelegatingMessageSource();
/*  803 */       dms.setParentMessageSource(getInternalParentMessageSource());
/*  804 */       this.messageSource = dms;
/*  805 */       beanFactory.registerSingleton("messageSource", this.messageSource);
/*  806 */       if (this.logger.isDebugEnabled())
/*  807 */         this.logger.debug("Unable to locate MessageSource with name 'messageSource': using default [" + this.messageSource + "]");
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void initApplicationEventMulticaster()
/*      */   {
/*  819 */     ConfigurableListableBeanFactory beanFactory = getBeanFactory();
/*  820 */     if (beanFactory.containsLocalBean("applicationEventMulticaster")) {
/*  821 */       this.applicationEventMulticaster = ((ApplicationEventMulticaster)beanFactory.getBean("applicationEventMulticaster", ApplicationEventMulticaster.class));
/*      */ 
/*  823 */       if (this.logger.isDebugEnabled())
/*  824 */         this.logger.debug("Using ApplicationEventMulticaster [" + this.applicationEventMulticaster + "]");
/*      */     }
/*      */     else
/*      */     {
/*  828 */       this.applicationEventMulticaster = new SimpleApplicationEventMulticaster(beanFactory);
/*  829 */       beanFactory.registerSingleton("applicationEventMulticaster", this.applicationEventMulticaster);
/*  830 */       if (this.logger.isDebugEnabled())
/*  831 */         this.logger.debug("Unable to locate ApplicationEventMulticaster with name 'applicationEventMulticaster': using default [" + this.applicationEventMulticaster + "]");
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void initLifecycleProcessor()
/*      */   {
/*  844 */     ConfigurableListableBeanFactory beanFactory = getBeanFactory();
/*  845 */     if (beanFactory.containsLocalBean("lifecycleProcessor")) {
/*  846 */       this.lifecycleProcessor = ((LifecycleProcessor)beanFactory.getBean("lifecycleProcessor", LifecycleProcessor.class));
/*      */ 
/*  848 */       if (this.logger.isDebugEnabled())
/*  849 */         this.logger.debug("Using LifecycleProcessor [" + this.lifecycleProcessor + "]");
/*      */     }
/*      */     else
/*      */     {
/*  853 */       DefaultLifecycleProcessor defaultProcessor = new DefaultLifecycleProcessor();
/*  854 */       defaultProcessor.setBeanFactory(beanFactory);
/*  855 */       this.lifecycleProcessor = defaultProcessor;
/*  856 */       beanFactory.registerSingleton("lifecycleProcessor", this.lifecycleProcessor);
/*  857 */       if (this.logger.isDebugEnabled())
/*  858 */         this.logger.debug("Unable to locate LifecycleProcessor with name 'lifecycleProcessor': using default [" + this.lifecycleProcessor + "]");
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void onRefresh()
/*      */     throws BeansException
/*      */   {
/*      */   }
/*      */ 
/*      */   protected void registerListeners()
/*      */   {
/*  882 */     for (ApplicationListener listener : getApplicationListeners()) {
/*  883 */       getApplicationEventMulticaster().addApplicationListener(listener);
/*      */     }
/*      */ 
/*  887 */     String[] listenerBeanNames = getBeanNamesForType(ApplicationListener.class, true, false);
/*  888 */     for (String lisName : listenerBeanNames)
/*  889 */       getApplicationEventMulticaster().addApplicationListenerBean(lisName);
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   protected void addListener(ApplicationListener<?> listener)
/*      */   {
/*  904 */     getApplicationEventMulticaster().addApplicationListener(listener);
/*      */   }
/*      */ 
/*      */   protected void finishBeanFactoryInitialization(ConfigurableListableBeanFactory beanFactory)
/*      */   {
/*  913 */     if ((beanFactory.containsBean("conversionService")) && (beanFactory.isTypeMatch("conversionService", ConversionService.class)))
/*      */     {
/*  915 */       beanFactory.setConversionService((ConversionService)beanFactory.getBean("conversionService", ConversionService.class));
/*      */     }
/*      */ 
/*  920 */     String[] weaverAwareNames = beanFactory.getBeanNamesForType(LoadTimeWeaverAware.class, false, false);
/*  921 */     for (String weaverAwareName : weaverAwareNames) {
/*  922 */       getBean(weaverAwareName);
/*      */     }
/*      */ 
/*  926 */     beanFactory.setTempClassLoader(null);
/*      */ 
/*  929 */     beanFactory.freezeConfiguration();
/*      */ 
/*  932 */     beanFactory.preInstantiateSingletons();
/*      */   }
/*      */ 
/*      */   protected void finishRefresh()
/*      */   {
/*  942 */     initLifecycleProcessor();
/*      */ 
/*  945 */     getLifecycleProcessor().onRefresh();
/*      */ 
/*  948 */     publishEvent(new ContextRefreshedEvent(this));
/*      */ 
/*  951 */     LiveBeansView.registerApplicationContext(this);
/*      */   }
/*      */ 
/*      */   protected void cancelRefresh(BeansException ex)
/*      */   {
/*  960 */     synchronized (this.activeMonitor) {
/*  961 */       this.active = false;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void registerShutdownHook()
/*      */   {
/*  975 */     if (this.shutdownHook == null)
/*      */     {
/*  977 */       this.shutdownHook = new Thread()
/*      */       {
/*      */         public void run() {
/*  980 */           AbstractApplicationContext.this.doClose();
/*      */         }
/*      */       };
/*  983 */       Runtime.getRuntime().addShutdownHook(this.shutdownHook);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void destroy()
/*      */   {
/*  998 */     close();
/*      */   }
/*      */ 
/*      */   public void close()
/*      */   {
/* 1009 */     synchronized (this.startupShutdownMonitor) {
/* 1010 */       doClose();
/*      */ 
/* 1013 */       if (this.shutdownHook != null)
/*      */         try {
/* 1015 */           Runtime.getRuntime().removeShutdownHook(this.shutdownHook);
/*      */         }
/*      */         catch (IllegalStateException ex)
/*      */         {
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void doClose()
/*      */   {
/*      */     boolean actuallyClose;
/* 1035 */     synchronized (this.activeMonitor) {
/* 1036 */       actuallyClose = (this.active) && (!this.closed);
/* 1037 */       this.closed = true;
/*      */     }
/*      */ 
/* 1040 */     if (actuallyClose) {
/* 1041 */       if (this.logger.isInfoEnabled()) {
/* 1042 */         this.logger.info("Closing " + this);
/*      */       }
/*      */ 
/* 1045 */       LiveBeansView.unregisterApplicationContext(this);
/*      */       try
/*      */       {
/* 1049 */         publishEvent(new ContextClosedEvent(this));
/*      */       }
/*      */       catch (Throwable ex) {
/* 1052 */         this.logger.warn("Exception thrown from ApplicationListener handling ContextClosedEvent", ex);
/*      */       }
/*      */ 
/*      */       try
/*      */       {
/* 1057 */         getLifecycleProcessor().onClose();
/*      */       }
/*      */       catch (Throwable ex) {
/* 1060 */         this.logger.warn("Exception thrown from LifecycleProcessor on context close", ex);
/*      */       }
/*      */ 
/* 1064 */       destroyBeans();
/*      */ 
/* 1067 */       closeBeanFactory();
/*      */ 
/* 1070 */       onClose();
/*      */ 
/* 1072 */       synchronized (this.activeMonitor) {
/* 1073 */         this.active = false;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void destroyBeans()
/*      */   {
/* 1090 */     getBeanFactory().destroySingletons();
/*      */   }
/*      */ 
/*      */   protected void onClose()
/*      */   {
/*      */   }
/*      */ 
/*      */   public boolean isActive()
/*      */   {
/* 1106 */     synchronized (this.activeMonitor) {
/* 1107 */       return this.active;
/*      */     }
/*      */   }
/*      */ 
/*      */   public Object getBean(String name)
/*      */     throws BeansException
/*      */   {
/* 1117 */     return getBeanFactory().getBean(name);
/*      */   }
/*      */ 
/*      */   public <T> T getBean(String name, Class<T> requiredType) throws BeansException {
/* 1121 */     return getBeanFactory().getBean(name, requiredType);
/*      */   }
/*      */ 
/*      */   public <T> T getBean(Class<T> requiredType) throws BeansException {
/* 1125 */     return getBeanFactory().getBean(requiredType);
/*      */   }
/*      */ 
/*      */   public Object getBean(String name, Object[] args) throws BeansException {
/* 1129 */     return getBeanFactory().getBean(name, args);
/*      */   }
/*      */ 
/*      */   public boolean containsBean(String name) {
/* 1133 */     return getBeanFactory().containsBean(name);
/*      */   }
/*      */ 
/*      */   public boolean isSingleton(String name) throws NoSuchBeanDefinitionException {
/* 1137 */     return getBeanFactory().isSingleton(name);
/*      */   }
/*      */ 
/*      */   public boolean isPrototype(String name) throws NoSuchBeanDefinitionException {
/* 1141 */     return getBeanFactory().isPrototype(name);
/*      */   }
/*      */ 
/*      */   public boolean isTypeMatch(String name, Class<?> targetType) throws NoSuchBeanDefinitionException {
/* 1145 */     return getBeanFactory().isTypeMatch(name, targetType);
/*      */   }
/*      */ 
/*      */   public Class<?> getType(String name) throws NoSuchBeanDefinitionException {
/* 1149 */     return getBeanFactory().getType(name);
/*      */   }
/*      */ 
/*      */   public String[] getAliases(String name) {
/* 1153 */     return getBeanFactory().getAliases(name);
/*      */   }
/*      */ 
/*      */   public boolean containsBeanDefinition(String beanName)
/*      */   {
/* 1162 */     return getBeanFactory().containsBeanDefinition(beanName);
/*      */   }
/*      */ 
/*      */   public int getBeanDefinitionCount() {
/* 1166 */     return getBeanFactory().getBeanDefinitionCount();
/*      */   }
/*      */ 
/*      */   public String[] getBeanDefinitionNames() {
/* 1170 */     return getBeanFactory().getBeanDefinitionNames();
/*      */   }
/*      */ 
/*      */   public String[] getBeanNamesForType(Class<?> type) {
/* 1174 */     return getBeanFactory().getBeanNamesForType(type);
/*      */   }
/*      */ 
/*      */   public String[] getBeanNamesForType(Class<?> type, boolean includeNonSingletons, boolean allowEagerInit) {
/* 1178 */     return getBeanFactory().getBeanNamesForType(type, includeNonSingletons, allowEagerInit);
/*      */   }
/*      */ 
/*      */   public <T> Map<String, T> getBeansOfType(Class<T> type) throws BeansException {
/* 1182 */     return getBeanFactory().getBeansOfType(type);
/*      */   }
/*      */ 
/*      */   public <T> Map<String, T> getBeansOfType(Class<T> type, boolean includeNonSingletons, boolean allowEagerInit)
/*      */     throws BeansException
/*      */   {
/* 1188 */     return getBeanFactory().getBeansOfType(type, includeNonSingletons, allowEagerInit);
/*      */   }
/*      */ 
/*      */   public Map<String, Object> getBeansWithAnnotation(Class<? extends Annotation> annotationType)
/*      */     throws BeansException
/*      */   {
/* 1194 */     return getBeanFactory().getBeansWithAnnotation(annotationType);
/*      */   }
/*      */ 
/*      */   public <A extends Annotation> A findAnnotationOnBean(String beanName, Class<A> annotationType) {
/* 1198 */     return getBeanFactory().findAnnotationOnBean(beanName, annotationType);
/*      */   }
/*      */ 
/*      */   public BeanFactory getParentBeanFactory()
/*      */   {
/* 1207 */     return getParent();
/*      */   }
/*      */ 
/*      */   public boolean containsLocalBean(String name) {
/* 1211 */     return getBeanFactory().containsLocalBean(name);
/*      */   }
/*      */ 
/*      */   protected BeanFactory getInternalParentBeanFactory()
/*      */   {
/* 1220 */     return (getParent() instanceof DisposableBean) ? ((DisposableBean)getParent()).getBeanFactory() : getParent();
/*      */   }
/*      */ 
/*      */   public String getMessage(String code, Object[] args, String defaultMessage, Locale locale)
/*      */   {
/* 1230 */     return getMessageSource().getMessage(code, args, defaultMessage, locale);
/*      */   }
/*      */ 
/*      */   public String getMessage(String code, Object[] args, Locale locale) throws NoSuchMessageException {
/* 1234 */     return getMessageSource().getMessage(code, args, locale);
/*      */   }
/*      */ 
/*      */   public String getMessage(MessageSourceResolvable resolvable, Locale locale) throws NoSuchMessageException {
/* 1238 */     return getMessageSource().getMessage(resolvable, locale);
/*      */   }
/*      */ 
/*      */   private MessageSource getMessageSource()
/*      */     throws IllegalStateException
/*      */   {
/* 1247 */     if (this.messageSource == null) {
/* 1248 */       throw new IllegalStateException("MessageSource not initialized - call 'refresh' before accessing messages via the context: " + this);
/*      */     }
/*      */ 
/* 1251 */     return this.messageSource;
/*      */   }
/*      */ 
/*      */   protected MessageSource getInternalParentMessageSource()
/*      */   {
/* 1259 */     return (getParent() instanceof AbstractApplicationContext) ? ((AbstractApplicationContext)getParent()).messageSource : getParent();
/*      */   }
/*      */ 
/*      */   public Resource[] getResources(String locationPattern)
/*      */     throws IOException
/*      */   {
/* 1269 */     return this.resourcePatternResolver.getResources(locationPattern);
/*      */   }
/*      */ 
/*      */   public void start()
/*      */   {
/* 1278 */     getLifecycleProcessor().start();
/* 1279 */     publishEvent(new ContextStartedEvent(this));
/*      */   }
/*      */ 
/*      */   public void stop() {
/* 1283 */     getLifecycleProcessor().stop();
/* 1284 */     publishEvent(new ContextStoppedEvent(this));
/*      */   }
/*      */ 
/*      */   public boolean isRunning() {
/* 1288 */     return getLifecycleProcessor().isRunning();
/*      */   }
/*      */ 
/*      */   protected abstract void refreshBeanFactory()
/*      */     throws BeansException, IllegalStateException;
/*      */ 
/*      */   protected abstract void closeBeanFactory();
/*      */ 
/*      */   public abstract ConfigurableListableBeanFactory getBeanFactory()
/*      */     throws IllegalStateException;
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1336 */     StringBuilder sb = new StringBuilder(getDisplayName());
/* 1337 */     sb.append(": startup date [").append(new Date(getStartupDate()));
/* 1338 */     sb.append("]; ");
/* 1339 */     ApplicationContext parent = getParent();
/* 1340 */     if (parent == null) {
/* 1341 */       sb.append("root of context hierarchy");
/*      */     }
/*      */     else {
/* 1344 */       sb.append("parent: ").append(parent.getDisplayName());
/*      */     }
/* 1346 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*  159 */     ContextClosedEvent.class.getName();
/*      */   }
/*      */ 
/*      */   private class ApplicationListenerDetector
/*      */     implements MergedBeanDefinitionPostProcessor
/*      */   {
/* 1390 */     private final Map<String, Boolean> singletonNames = new ConcurrentHashMap(64);
/*      */ 
/*      */     private ApplicationListenerDetector() {  } 
/* 1393 */     public void postProcessMergedBeanDefinition(RootBeanDefinition beanDefinition, Class<?> beanType, String beanName) { if (beanDefinition.isSingleton())
/* 1394 */         this.singletonNames.put(beanName, Boolean.TRUE);
/*      */     }
/*      */ 
/*      */     public Object postProcessBeforeInitialization(Object bean, String beanName)
/*      */     {
/* 1399 */       return bean;
/*      */     }
/*      */ 
/*      */     public Object postProcessAfterInitialization(Object bean, String beanName) {
/* 1403 */       if ((bean instanceof ApplicationListener))
/*      */       {
/* 1405 */         Boolean flag = (Boolean)this.singletonNames.get(beanName);
/* 1406 */         if (Boolean.TRUE.equals(flag))
/*      */         {
/* 1408 */           AbstractApplicationContext.this.addApplicationListener((ApplicationListener)bean);
/*      */         }
/* 1410 */         else if (flag == null) {
/* 1411 */           if ((AbstractApplicationContext.this.logger.isWarnEnabled()) && (!AbstractApplicationContext.this.containsBean(beanName)))
/*      */           {
/* 1413 */             AbstractApplicationContext.this.logger.warn("Inner bean '" + beanName + "' implements ApplicationListener interface " + "but is not reachable for event multicasting by its containing ApplicationContext " + "because it does not have singleton scope. Only top-level listener beans are allowed " + "to be of non-singleton scope.");
/*      */           }
/*      */ 
/* 1418 */           this.singletonNames.put(beanName, Boolean.FALSE);
/*      */         }
/*      */       }
/* 1421 */       return bean;
/*      */     }
/*      */   }
/*      */ 
/*      */   private class BeanPostProcessorChecker
/*      */     implements BeanPostProcessor
/*      */   {
/*      */     private final ConfigurableListableBeanFactory beanFactory;
/*      */     private final int beanPostProcessorTargetCount;
/*      */ 
/*      */     public BeanPostProcessorChecker(ConfigurableListableBeanFactory beanFactory, int beanPostProcessorTargetCount)
/*      */     {
/* 1362 */       this.beanFactory = beanFactory;
/* 1363 */       this.beanPostProcessorTargetCount = beanPostProcessorTargetCount;
/*      */     }
/*      */ 
/*      */     public Object postProcessBeforeInitialization(Object bean, String beanName) {
/* 1367 */       return bean;
/*      */     }
/*      */ 
/*      */     public Object postProcessAfterInitialization(Object bean, String beanName) {
/* 1371 */       if ((bean != null) && (!(bean instanceof BeanPostProcessor)) && (this.beanFactory.getBeanPostProcessorCount() < this.beanPostProcessorTargetCount))
/*      */       {
/* 1373 */         if (AbstractApplicationContext.this.logger.isInfoEnabled()) {
/* 1374 */           AbstractApplicationContext.this.logger.info("Bean '" + beanName + "' of type [" + bean.getClass() + "] is not eligible for getting processed by all BeanPostProcessors " + "(for example: not eligible for auto-proxying)");
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1379 */       return bean;
/*      */     }
/*      */   }
/*      */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.AbstractApplicationContext
 * JD-Core Version:    0.6.1
 */