/*     */ package org.springframework.context.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.BeanFactoryUtils;
/*     */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*     */ import org.springframework.context.ApplicationContextException;
/*     */ import org.springframework.context.Lifecycle;
/*     */ import org.springframework.context.LifecycleProcessor;
/*     */ import org.springframework.context.Phased;
/*     */ import org.springframework.context.SmartLifecycle;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class DefaultLifecycleProcessor
/*     */   implements LifecycleProcessor, BeanFactoryAware
/*     */ {
/*     */   private final Log logger;
/*     */   private volatile long timeoutPerShutdownPhase;
/*     */   private volatile boolean running;
/*     */   private volatile ConfigurableListableBeanFactory beanFactory;
/*     */ 
/*     */   public DefaultLifecycleProcessor()
/*     */   {
/*  53 */     this.logger = LogFactory.getLog(getClass());
/*     */ 
/*  55 */     this.timeoutPerShutdownPhase = 30000L;
/*     */   }
/*     */ 
/*     */   public void setTimeoutPerShutdownPhase(long timeoutPerShutdownPhase)
/*     */   {
/*  68 */     this.timeoutPerShutdownPhase = timeoutPerShutdownPhase;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory) {
/*  72 */     Assert.isInstanceOf(ConfigurableListableBeanFactory.class, beanFactory);
/*  73 */     this.beanFactory = ((ConfigurableListableBeanFactory)beanFactory);
/*     */   }
/*     */ 
/*     */   public void start()
/*     */   {
/*  89 */     startBeans(false);
/*  90 */     this.running = true;
/*     */   }
/*     */ 
/*     */   public void stop()
/*     */   {
/* 103 */     stopBeans();
/* 104 */     this.running = false;
/*     */   }
/*     */ 
/*     */   public void onRefresh() {
/* 108 */     startBeans(true);
/* 109 */     this.running = true;
/*     */   }
/*     */ 
/*     */   public void onClose() {
/* 113 */     stopBeans();
/* 114 */     this.running = false;
/*     */   }
/*     */ 
/*     */   public boolean isRunning() {
/* 118 */     return this.running;
/*     */   }
/*     */ 
/*     */   private void startBeans(boolean autoStartupOnly)
/*     */   {
/* 125 */     Map lifecycleBeans = getLifecycleBeans();
/* 126 */     Map phases = new HashMap();
/* 127 */     for (Map.Entry entry : lifecycleBeans.entrySet()) {
/* 128 */       Lifecycle bean = (Lifecycle)entry.getValue();
/* 129 */       if ((!autoStartupOnly) || (((bean instanceof SmartLifecycle)) && (((SmartLifecycle)bean).isAutoStartup()))) {
/* 130 */         int phase = getPhase(bean);
/* 131 */         LifecycleGroup group = (LifecycleGroup)phases.get(Integer.valueOf(phase));
/* 132 */         if (group == null) {
/* 133 */           group = new LifecycleGroup(phase, this.timeoutPerShutdownPhase, lifecycleBeans, autoStartupOnly);
/* 134 */           phases.put(Integer.valueOf(phase), group);
/*     */         }
/* 136 */         group.add((String)entry.getKey(), bean);
/*     */       }
/*     */     }
/* 139 */     if (phases.size() > 0) {
/* 140 */       List keys = new ArrayList(phases.keySet());
/* 141 */       Collections.sort(keys);
/* 142 */       for (Integer key : keys)
/* 143 */         ((LifecycleGroup)phases.get(key)).start();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void doStart(Map<String, ? extends Lifecycle> lifecycleBeans, String beanName, boolean autoStartupOnly)
/*     */   {
/* 155 */     Lifecycle bean = (Lifecycle)lifecycleBeans.remove(beanName);
/* 156 */     if ((bean != null) && (!equals(bean))) {
/* 157 */       String[] dependenciesForBean = this.beanFactory.getDependenciesForBean(beanName);
/* 158 */       for (String dependency : dependenciesForBean) {
/* 159 */         doStart(lifecycleBeans, dependency, autoStartupOnly);
/*     */       }
/* 161 */       if ((!bean.isRunning()) && ((!autoStartupOnly) || (!(bean instanceof SmartLifecycle)) || (((SmartLifecycle)bean).isAutoStartup())))
/*     */       {
/* 163 */         if (this.logger.isDebugEnabled())
/* 164 */           this.logger.debug("Starting bean '" + beanName + "' of type [" + bean.getClass() + "]");
/*     */         try
/*     */         {
/* 167 */           bean.start();
/*     */         }
/*     */         catch (Throwable ex) {
/* 170 */           throw new ApplicationContextException("Failed to start bean '" + beanName + "'", ex);
/*     */         }
/* 172 */         if (this.logger.isDebugEnabled())
/* 173 */           this.logger.debug("Successfully started bean '" + beanName + "'");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void stopBeans()
/*     */   {
/* 180 */     Map lifecycleBeans = getLifecycleBeans();
/* 181 */     Map phases = new HashMap();
/* 182 */     for (Map.Entry entry : lifecycleBeans.entrySet()) {
/* 183 */       Lifecycle bean = (Lifecycle)entry.getValue();
/* 184 */       int shutdownOrder = getPhase(bean);
/* 185 */       LifecycleGroup group = (LifecycleGroup)phases.get(Integer.valueOf(shutdownOrder));
/* 186 */       if (group == null) {
/* 187 */         group = new LifecycleGroup(shutdownOrder, this.timeoutPerShutdownPhase, lifecycleBeans, false);
/* 188 */         phases.put(Integer.valueOf(shutdownOrder), group);
/*     */       }
/* 190 */       group.add((String)entry.getKey(), bean);
/*     */     }
/* 192 */     if (phases.size() > 0) {
/* 193 */       List keys = new ArrayList(phases.keySet());
/* 194 */       Collections.sort(keys, Collections.reverseOrder());
/* 195 */       for (Integer key : keys)
/* 196 */         ((LifecycleGroup)phases.get(key)).stop();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void doStop(Map<String, ? extends Lifecycle> lifecycleBeans, final String beanName, final CountDownLatch latch, final Set<String> countDownBeanNames)
/*     */   {
/* 210 */     Lifecycle bean = (Lifecycle)lifecycleBeans.remove(beanName);
/* 211 */     if (bean != null) {
/* 212 */       String[] dependentBeans = this.beanFactory.getDependentBeans(beanName);
/* 213 */       for (String dependentBean : dependentBeans)
/* 214 */         doStop(lifecycleBeans, dependentBean, latch, countDownBeanNames);
/*     */       try
/*     */       {
/* 217 */         if (bean.isRunning()) {
/* 218 */           if ((bean instanceof SmartLifecycle)) {
/* 219 */             if (this.logger.isDebugEnabled()) {
/* 220 */               this.logger.debug("Asking bean '" + beanName + "' of type [" + bean.getClass() + "] to stop");
/*     */             }
/* 222 */             countDownBeanNames.add(beanName);
/* 223 */             ((SmartLifecycle)bean).stop(new Runnable() {
/*     */               public void run() {
/* 225 */                 latch.countDown();
/* 226 */                 countDownBeanNames.remove(beanName);
/* 227 */                 if (DefaultLifecycleProcessor.this.logger.isDebugEnabled())
/* 228 */                   DefaultLifecycleProcessor.this.logger.debug("Bean '" + beanName + "' completed its stop procedure");
/*     */               }
/*     */             });
/*     */           }
/*     */           else
/*     */           {
/* 234 */             if (this.logger.isDebugEnabled()) {
/* 235 */               this.logger.debug("Stopping bean '" + beanName + "' of type [" + bean.getClass() + "]");
/*     */             }
/* 237 */             bean.stop();
/* 238 */             if (this.logger.isDebugEnabled()) {
/* 239 */               this.logger.debug("Successfully stopped bean '" + beanName + "'");
/*     */             }
/*     */           }
/*     */         }
/* 243 */         else if ((bean instanceof SmartLifecycle))
/*     */         {
/* 245 */           latch.countDown();
/*     */         }
/*     */       }
/*     */       catch (Throwable ex) {
/* 249 */         if (this.logger.isWarnEnabled())
/* 250 */           this.logger.warn("Failed to stop bean '" + beanName + "'", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Map<String, Lifecycle> getLifecycleBeans()
/*     */   {
/* 265 */     Map beans = new LinkedHashMap();
/* 266 */     String[] beanNames = this.beanFactory.getBeanNamesForType(Lifecycle.class, false, false);
/* 267 */     for (String beanName : beanNames) {
/* 268 */       String beanNameToRegister = BeanFactoryUtils.transformedBeanName(beanName);
/* 269 */       boolean isFactoryBean = this.beanFactory.isFactoryBean(beanNameToRegister);
/* 270 */       String beanNameToCheck = isFactoryBean ? "&" + beanName : beanName;
/* 271 */       if (((this.beanFactory.containsSingleton(beanNameToRegister)) && ((!isFactoryBean) || (Lifecycle.class.isAssignableFrom(this.beanFactory.getType(beanNameToCheck))))) || (SmartLifecycle.class.isAssignableFrom(this.beanFactory.getType(beanNameToCheck))))
/*     */       {
/* 274 */         Lifecycle bean = (Lifecycle)this.beanFactory.getBean(beanNameToCheck, Lifecycle.class);
/* 275 */         if (bean != this) {
/* 276 */           beans.put(beanNameToRegister, bean);
/*     */         }
/*     */       }
/*     */     }
/* 280 */     return beans;
/*     */   }
/*     */ 
/*     */   protected int getPhase(Lifecycle bean)
/*     */   {
/* 293 */     return (bean instanceof Phased) ? ((Phased)bean).getPhase() : 0;
/*     */   }
/*     */ 
/*     */   private class LifecycleGroupMember
/*     */     implements Comparable<LifecycleGroupMember>
/*     */   {
/*     */     private final String name;
/*     */     private final Lifecycle bean;
/*     */ 
/*     */     LifecycleGroupMember(String name, Lifecycle bean)
/*     */     {
/* 388 */       this.name = name;
/* 389 */       this.bean = bean;
/*     */     }
/*     */ 
/*     */     public int compareTo(LifecycleGroupMember other) {
/* 393 */       int thisOrder = DefaultLifecycleProcessor.this.getPhase(this.bean);
/* 394 */       int otherOrder = DefaultLifecycleProcessor.this.getPhase(other.bean);
/* 395 */       return thisOrder < otherOrder ? -1 : thisOrder == otherOrder ? 0 : 1;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class LifecycleGroup
/*     */   {
/* 303 */     private final List<DefaultLifecycleProcessor.LifecycleGroupMember> members = new ArrayList();
/*     */     private final int phase;
/*     */     private final long timeout;
/*     */     private final Map<String, ? extends Lifecycle> lifecycleBeans;
/*     */     private final boolean autoStartupOnly;
/*     */     private volatile int smartMemberCount;
/*     */ 
/*     */     public LifecycleGroup(long phase, Map<String, ? extends Lifecycle> arg4, boolean lifecycleBeans)
/*     */     {
/* 316 */       this.phase = phase;
/* 317 */       this.timeout = timeout;
/* 318 */       this.lifecycleBeans = lifecycleBeans;
/* 319 */       this.autoStartupOnly = autoStartupOnly;
/*     */     }
/*     */ 
/*     */     public void add(String name, Lifecycle bean) {
/* 323 */       if ((bean instanceof SmartLifecycle)) {
/* 324 */         this.smartMemberCount += 1;
/*     */       }
/* 326 */       this.members.add(new DefaultLifecycleProcessor.LifecycleGroupMember(DefaultLifecycleProcessor.this, name, bean));
/*     */     }
/*     */ 
/*     */     public void start() {
/* 330 */       if (this.members.isEmpty()) {
/* 331 */         return;
/*     */       }
/* 333 */       if (DefaultLifecycleProcessor.this.logger.isInfoEnabled()) {
/* 334 */         DefaultLifecycleProcessor.this.logger.info("Starting beans in phase " + this.phase);
/*     */       }
/* 336 */       Collections.sort(this.members);
/* 337 */       for (DefaultLifecycleProcessor.LifecycleGroupMember member : this.members)
/* 338 */         if (this.lifecycleBeans.containsKey(member.name))
/* 339 */           DefaultLifecycleProcessor.this.doStart(this.lifecycleBeans, member.name, this.autoStartupOnly);
/*     */     }
/*     */ 
/*     */     public void stop()
/*     */     {
/* 345 */       if (this.members.isEmpty()) {
/* 346 */         return;
/*     */       }
/* 348 */       if (DefaultLifecycleProcessor.this.logger.isInfoEnabled()) {
/* 349 */         DefaultLifecycleProcessor.this.logger.info("Stopping beans in phase " + this.phase);
/*     */       }
/* 351 */       Collections.sort(this.members, Collections.reverseOrder());
/* 352 */       CountDownLatch latch = new CountDownLatch(this.smartMemberCount);
/* 353 */       Set countDownBeanNames = Collections.synchronizedSet(new LinkedHashSet());
/* 354 */       for (DefaultLifecycleProcessor.LifecycleGroupMember member : this.members)
/* 355 */         if (this.lifecycleBeans.containsKey(member.name)) {
/* 356 */           DefaultLifecycleProcessor.this.doStop(this.lifecycleBeans, member.name, latch, countDownBeanNames);
/*     */         }
/* 358 */         else if ((member.bean instanceof SmartLifecycle))
/*     */         {
/* 360 */           latch.countDown();
/*     */         }
/*     */       try
/*     */       {
/* 364 */         latch.await(this.timeout, TimeUnit.MILLISECONDS);
/* 365 */         if ((latch.getCount() > 0L) && (!countDownBeanNames.isEmpty()) && (DefaultLifecycleProcessor.this.logger.isWarnEnabled())) {
/* 366 */           DefaultLifecycleProcessor.this.logger.warn("Failed to shut down " + countDownBeanNames.size() + " bean" + (countDownBeanNames.size() > 1 ? "s" : "") + " with phase value " + this.phase + " within timeout of " + this.timeout + ": " + countDownBeanNames);
/*     */         }
/*     */ 
/*     */       }
/*     */       catch (InterruptedException ex)
/*     */       {
/* 372 */         Thread.currentThread().interrupt();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.support.DefaultLifecycleProcessor
 * JD-Core Version:    0.6.1
 */