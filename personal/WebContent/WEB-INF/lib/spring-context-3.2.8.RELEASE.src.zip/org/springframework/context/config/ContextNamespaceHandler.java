/*    */ package org.springframework.context.config;
/*    */ 
/*    */ import org.springframework.beans.factory.xml.NamespaceHandlerSupport;
/*    */ import org.springframework.context.annotation.AnnotationConfigBeanDefinitionParser;
/*    */ import org.springframework.context.annotation.ComponentScanBeanDefinitionParser;
/*    */ 
/*    */ public class ContextNamespaceHandler extends NamespaceHandlerSupport
/*    */ {
/*    */   public void init()
/*    */   {
/* 34 */     registerBeanDefinitionParser("property-placeholder", new PropertyPlaceholderBeanDefinitionParser());
/* 35 */     registerBeanDefinitionParser("property-override", new PropertyOverrideBeanDefinitionParser());
/* 36 */     registerBeanDefinitionParser("annotation-config", new AnnotationConfigBeanDefinitionParser());
/* 37 */     registerBeanDefinitionParser("component-scan", new ComponentScanBeanDefinitionParser());
/* 38 */     registerBeanDefinitionParser("load-time-weaver", new LoadTimeWeaverBeanDefinitionParser());
/* 39 */     registerBeanDefinitionParser("spring-configured", new SpringConfiguredBeanDefinitionParser());
/* 40 */     registerBeanDefinitionParser("mbean-export", new MBeanExportBeanDefinitionParser());
/* 41 */     registerBeanDefinitionParser("mbean-server", new MBeanServerBeanDefinitionParser());
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.config.ContextNamespaceHandler
 * JD-Core Version:    0.6.1
 */