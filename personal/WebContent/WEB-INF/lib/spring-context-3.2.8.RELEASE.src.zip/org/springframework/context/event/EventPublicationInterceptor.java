/*    */ package org.springframework.context.event;
/*    */ 
/*    */ import java.lang.reflect.Constructor;
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.context.ApplicationEvent;
/*    */ import org.springframework.context.ApplicationEventPublisher;
/*    */ import org.springframework.context.ApplicationEventPublisherAware;
/*    */ 
/*    */ public class EventPublicationInterceptor
/*    */   implements MethodInterceptor, ApplicationEventPublisherAware, InitializingBean
/*    */ {
/*    */   private Constructor applicationEventClassConstructor;
/*    */   private ApplicationEventPublisher applicationEventPublisher;
/*    */ 
/*    */   public void setApplicationEventClass(Class applicationEventClass)
/*    */   {
/* 66 */     if ((ApplicationEvent.class.equals(applicationEventClass)) || (!ApplicationEvent.class.isAssignableFrom(applicationEventClass)))
/*    */     {
/* 68 */       throw new IllegalArgumentException("applicationEventClass needs to extend ApplicationEvent");
/*    */     }
/*    */     try {
/* 71 */       this.applicationEventClassConstructor = applicationEventClass.getConstructor(new Class[] { Object.class });
/*    */     }
/*    */     catch (NoSuchMethodException ex)
/*    */     {
/* 75 */       throw new IllegalArgumentException("applicationEventClass [" + applicationEventClass.getName() + "] does not have the required Object constructor: " + ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher)
/*    */   {
/* 81 */     this.applicationEventPublisher = applicationEventPublisher;
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet() throws Exception {
/* 85 */     if (this.applicationEventClassConstructor == null)
/* 86 */       throw new IllegalArgumentException("applicationEventClass is required");
/*    */   }
/*    */ 
/*    */   public Object invoke(MethodInvocation invocation)
/*    */     throws Throwable
/*    */   {
/* 92 */     Object retVal = invocation.proceed();
/*    */ 
/* 94 */     ApplicationEvent event = (ApplicationEvent)this.applicationEventClassConstructor.newInstance(new Object[] { invocation.getThis() });
/*    */ 
/* 96 */     this.applicationEventPublisher.publishEvent(event);
/*    */ 
/* 98 */     return retVal;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.event.EventPublicationInterceptor
 * JD-Core Version:    0.6.1
 */