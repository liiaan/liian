/*     */ package org.springframework.context.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Arrays;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.scope.ScopedProxyFactoryBean;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.support.SimpleInstantiationStrategy;
/*     */ import org.springframework.cglib.core.SpringNamingPolicy;
/*     */ import org.springframework.cglib.proxy.Callback;
/*     */ import org.springframework.cglib.proxy.CallbackFilter;
/*     */ import org.springframework.cglib.proxy.Enhancer;
/*     */ import org.springframework.cglib.proxy.MethodInterceptor;
/*     */ import org.springframework.cglib.proxy.MethodProxy;
/*     */ import org.springframework.cglib.proxy.NoOp;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ class ConfigurationClassEnhancer
/*     */ {
/*  59 */   private static final Callback DISPOSABLE_BEAN_METHOD_INTERCEPTOR = new DisposableBeanMethodInterceptor(null);
/*     */ 
/*  61 */   private static final Class<?>[] CALLBACK_TYPES = { BeanMethodInterceptor.class, DisposableBeanMethodInterceptor.class, NoOp.class };
/*     */ 
/*  64 */   private static final CallbackFilter CALLBACK_FILTER = new ConfigurationClassCallbackFilter(null);
/*     */ 
/*  66 */   private static final Log logger = LogFactory.getLog(ConfigurationClassEnhancer.class);
/*     */   private final Callback[] callbackInstances;
/*     */ 
/*     */   public ConfigurationClassEnhancer(ConfigurableBeanFactory beanFactory)
/*     */   {
/*  75 */     Assert.notNull(beanFactory, "BeanFactory must not be null");
/*     */ 
/*  77 */     this.callbackInstances = new Callback[] { new BeanMethodInterceptor(beanFactory), DISPOSABLE_BEAN_METHOD_INTERCEPTOR, NoOp.INSTANCE };
/*     */   }
/*     */ 
/*     */   public Class<?> enhance(Class<?> configClass)
/*     */   {
/*  87 */     if (EnhancedConfiguration.class.isAssignableFrom(configClass)) {
/*  88 */       if (logger.isDebugEnabled()) {
/*  89 */         logger.debug(String.format("Ignoring request to enhance %s as it has already been enhanced. This usually indicates that more than one ConfigurationClassPostProcessor has been registered (e.g. via <context:annotation-config>). This is harmless, but you may want check your configuration and remove one CCPP if possible", new Object[] { configClass.getName() }));
/*     */       }
/*     */ 
/*  96 */       return configClass;
/*     */     }
/*  98 */     Class enhancedClass = createClass(newEnhancer(configClass));
/*  99 */     if (logger.isDebugEnabled()) {
/* 100 */       logger.debug(String.format("Successfully enhanced %s; enhanced class name is: %s", new Object[] { configClass.getName(), enhancedClass.getName() }));
/*     */     }
/*     */ 
/* 103 */     return enhancedClass;
/*     */   }
/*     */ 
/*     */   private Enhancer newEnhancer(Class<?> superclass)
/*     */   {
/* 110 */     Enhancer enhancer = new Enhancer();
/* 111 */     enhancer.setSuperclass(superclass);
/* 112 */     enhancer.setInterfaces(new Class[] { EnhancedConfiguration.class });
/* 113 */     enhancer.setUseFactory(false);
/* 114 */     enhancer.setNamingPolicy(SpringNamingPolicy.INSTANCE);
/* 115 */     enhancer.setCallbackFilter(CALLBACK_FILTER);
/* 116 */     enhancer.setCallbackTypes(CALLBACK_TYPES);
/* 117 */     return enhancer;
/*     */   }
/*     */ 
/*     */   private Class<?> createClass(Enhancer enhancer)
/*     */   {
/* 125 */     Class subclass = enhancer.createClass();
/*     */ 
/* 128 */     Enhancer.registerStaticCallbacks(subclass, this.callbackInstances);
/* 129 */     return subclass;
/*     */   }
/*     */ 
/*     */   private static class BeanMethodInterceptor
/*     */     implements MethodInterceptor
/*     */   {
/* 226 */     private static final Class<?>[] CALLBACK_TYPES = { ConfigurationClassEnhancer.GetObjectMethodInterceptor.class, NoOp.class };
/*     */ 
/* 228 */     private static final CallbackFilter CALLBACK_FILTER = new CallbackFilter() {
/*     */       public int accept(Method method) {
/* 230 */         return method.getName().equals("getObject") ? 0 : 1;
/*     */       }
/* 228 */     };
/*     */     private final ConfigurableBeanFactory beanFactory;
/*     */ 
/*     */     public BeanMethodInterceptor(ConfigurableBeanFactory beanFactory) {
/* 237 */       this.beanFactory = beanFactory;
/*     */     }
/*     */ 
/*     */     public Object intercept(Object enhancedConfigInstance, Method beanMethod, Object[] beanMethodArgs, MethodProxy cglibMethodProxy)
/*     */       throws Throwable
/*     */     {
/* 250 */       String beanName = BeanAnnotationHelper.determineBeanNameFor(beanMethod);
/*     */ 
/* 253 */       Scope scope = (Scope)AnnotationUtils.findAnnotation(beanMethod, Scope.class);
/* 254 */       if ((scope != null) && (scope.proxyMode() != ScopedProxyMode.NO)) {
/* 255 */         String scopedBeanName = ScopedProxyCreator.getTargetBeanName(beanName);
/* 256 */         if (this.beanFactory.isCurrentlyInCreation(scopedBeanName)) {
/* 257 */           beanName = scopedBeanName;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 268 */       if ((factoryContainsBean("&" + beanName)) && (factoryContainsBean(beanName))) {
/* 269 */         Object factoryBean = this.beanFactory.getBean("&" + beanName);
/* 270 */         if (!(factoryBean instanceof ScopedProxyFactoryBean))
/*     */         {
/* 276 */           return enhanceFactoryBean(factoryBean.getClass(), beanName);
/*     */         }
/*     */       }
/*     */ 
/* 280 */       if ((isCurrentlyInvokedFactoryMethod(beanMethod)) && (!this.beanFactory.containsSingleton(beanName)))
/*     */       {
/* 284 */         if (BeanFactoryPostProcessor.class.isAssignableFrom(beanMethod.getReturnType())) {
/* 285 */           ConfigurationClassEnhancer.logger.warn(String.format("@Bean method %s.%s is non-static and returns an object assignable to Spring's BeanFactoryPostProcessor interface. This will result in a failure to process annotations such as @Autowired, @Resource and @PostConstruct within the method's declaring @Configuration class. Add the 'static' modifier to this method to avoid these container lifecycle issues; see @Bean Javadoc for complete details", new Object[] { beanMethod.getDeclaringClass().getSimpleName(), beanMethod.getName() }));
/*     */         }
/*     */ 
/* 293 */         return cglibMethodProxy.invokeSuper(enhancedConfigInstance, beanMethodArgs);
/*     */       }
/*     */ 
/* 300 */       boolean alreadyInCreation = this.beanFactory.isCurrentlyInCreation(beanName);
/*     */       try {
/* 302 */         if (alreadyInCreation) {
/* 303 */           this.beanFactory.setCurrentlyInCreation(beanName, false);
/*     */         }
/* 305 */         return this.beanFactory.getBean(beanName);
/*     */       }
/*     */       finally {
/* 308 */         if (alreadyInCreation)
/* 309 */           this.beanFactory.setCurrentlyInCreation(beanName, true);
/*     */       }
/*     */     }
/*     */ 
/*     */     private boolean factoryContainsBean(String beanName)
/*     */     {
/* 329 */       return (this.beanFactory.containsBean(beanName)) && (!this.beanFactory.isCurrentlyInCreation(beanName));
/*     */     }
/*     */ 
/*     */     private boolean isCurrentlyInvokedFactoryMethod(Method method)
/*     */     {
/* 339 */       Method currentlyInvoked = SimpleInstantiationStrategy.getCurrentlyInvokedFactoryMethod();
/* 340 */       return (currentlyInvoked != null) && (method.getName().equals(currentlyInvoked.getName())) && (Arrays.equals(method.getParameterTypes(), currentlyInvoked.getParameterTypes()));
/*     */     }
/*     */ 
/*     */     private Object enhanceFactoryBean(Class<?> fbClass, String beanName)
/*     */       throws InstantiationException, IllegalAccessException
/*     */     {
/* 352 */       Enhancer enhancer = new Enhancer();
/* 353 */       enhancer.setSuperclass(fbClass);
/* 354 */       enhancer.setUseFactory(false);
/* 355 */       enhancer.setCallbackFilter(CALLBACK_FILTER);
/*     */ 
/* 357 */       Callback[] callbackInstances = { new ConfigurationClassEnhancer.GetObjectMethodInterceptor(this.beanFactory, beanName), NoOp.INSTANCE };
/*     */ 
/* 361 */       enhancer.setCallbackTypes(CALLBACK_TYPES);
/* 362 */       Class fbSubclass = enhancer.createClass();
/* 363 */       Enhancer.registerCallbacks(fbSubclass, callbackInstances);
/* 364 */       return fbSubclass.newInstance();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class DisposableBeanMethodInterceptor
/*     */     implements MethodInterceptor
/*     */   {
/*     */     public Object intercept(Object obj, Method method, Object[] args, MethodProxy proxy)
/*     */       throws Throwable
/*     */     {
/* 201 */       Enhancer.registerStaticCallbacks(obj.getClass(), null);
/*     */ 
/* 204 */       if (DisposableBean.class.isAssignableFrom(obj.getClass().getSuperclass())) {
/* 205 */         return proxy.invokeSuper(obj, args);
/*     */       }
/* 207 */       return null;
/*     */     }
/*     */ 
/*     */     public static boolean isDestroyMethod(Method candidateMethod) {
/* 211 */       return (candidateMethod.getName().equals("destroy")) && (candidateMethod.getParameterTypes().length == 0) && (DisposableBean.class.isAssignableFrom(candidateMethod.getDeclaringClass()));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class GetObjectMethodInterceptor
/*     */     implements MethodInterceptor
/*     */   {
/*     */     private final ConfigurableBeanFactory beanFactory;
/*     */     private final String beanName;
/*     */ 
/*     */     public GetObjectMethodInterceptor(ConfigurableBeanFactory beanFactory, String beanName)
/*     */     {
/* 182 */       this.beanFactory = beanFactory;
/* 183 */       this.beanName = beanName;
/*     */     }
/*     */ 
/*     */     public Object intercept(Object obj, Method method, Object[] args, MethodProxy proxy) throws Throwable {
/* 187 */       return this.beanFactory.getBean(this.beanName);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ConfigurationClassCallbackFilter
/*     */     implements CallbackFilter
/*     */   {
/*     */     public int accept(Method candidateMethod)
/*     */     {
/* 158 */       if (BeanAnnotationHelper.isBeanAnnotated(candidateMethod)) {
/* 159 */         return 0;
/*     */       }
/* 161 */       if (ConfigurationClassEnhancer.DisposableBeanMethodInterceptor.isDestroyMethod(candidateMethod)) {
/* 162 */         return 1;
/*     */       }
/* 164 */       return 2;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface EnhancedConfiguration extends DisposableBean
/*     */   {
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.ConfigurationClassEnhancer
 * JD-Core Version:    0.6.1
 */