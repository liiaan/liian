/*    */ package org.springframework.context.annotation;
/*    */ 
/*    */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.context.weaving.AspectJWeavingEnabler;
/*    */ import org.springframework.context.weaving.DefaultContextLoadTimeWeaver;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.instrument.classloading.LoadTimeWeaver;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ @Configuration
/*    */ public class LoadTimeWeavingConfiguration
/*    */   implements ImportAware, BeanClassLoaderAware
/*    */ {
/*    */   private AnnotationAttributes enableLTW;
/*    */ 
/*    */   @Autowired(required=false)
/*    */   private LoadTimeWeavingConfigurer ltwConfigurer;
/*    */   private ClassLoader beanClassLoader;
/*    */ 
/*    */   public void setImportMetadata(AnnotationMetadata importMetadata)
/*    */   {
/* 56 */     this.enableLTW = MetadataUtils.attributesFor(importMetadata, EnableLoadTimeWeaving.class);
/* 57 */     Assert.notNull(this.enableLTW, "@EnableLoadTimeWeaving is not present on importing class " + importMetadata.getClassName());
/*    */   }
/*    */ 
/*    */   public void setBeanClassLoader(ClassLoader beanClassLoader)
/*    */   {
/* 63 */     this.beanClassLoader = beanClassLoader;
/*    */   }
/*    */   @Bean(name={"loadTimeWeaver"})
/*    */   @Role(2)
/*    */   public LoadTimeWeaver loadTimeWeaver() {
/* 69 */     LoadTimeWeaver loadTimeWeaver = null;
/*    */ 
/* 71 */     if (this.ltwConfigurer != null)
/*    */     {
/* 73 */       loadTimeWeaver = this.ltwConfigurer.getLoadTimeWeaver();
/*    */     }
/*    */ 
/* 76 */     if (loadTimeWeaver == null)
/*    */     {
/* 78 */       loadTimeWeaver = new DefaultContextLoadTimeWeaver(this.beanClassLoader);
/*    */     }
/*    */ 
/* 81 */     EnableLoadTimeWeaving.AspectJWeaving aspectJWeaving = (EnableLoadTimeWeaving.AspectJWeaving)this.enableLTW.getEnum("aspectjWeaving");
/* 82 */     switch (1.$SwitchMap$org$springframework$context$annotation$EnableLoadTimeWeaving$AspectJWeaving[aspectJWeaving.ordinal()])
/*    */     {
/*    */     case 1:
/* 85 */       break;
/*    */     case 2:
/* 87 */       if (this.beanClassLoader.getResource("META-INF/aop.xml") == null)
/*    */       {
/*    */         break;
/*    */       }
/*    */ 
/*    */     case 3:
/* 93 */       AspectJWeavingEnabler.enableAspectJWeaving(loadTimeWeaver, this.beanClassLoader);
/*    */     }
/*    */ 
/* 96 */     return loadTimeWeaver;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.annotation.LoadTimeWeavingConfiguration
 * JD-Core Version:    0.6.1
 */