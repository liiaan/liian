package org.springframework.context;

import org.springframework.beans.factory.Aware;

public abstract interface ApplicationEventPublisherAware extends Aware
{
  public abstract void setApplicationEventPublisher(ApplicationEventPublisher paramApplicationEventPublisher);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.ApplicationEventPublisherAware
 * JD-Core Version:    0.6.1
 */