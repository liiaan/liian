/*     */ package org.springframework.context.event;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.context.ApplicationEvent;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.core.OrderComparator;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public abstract class AbstractApplicationEventMulticaster
/*     */   implements ApplicationEventMulticaster, BeanFactoryAware
/*     */ {
/*     */   private final ListenerRetriever defaultRetriever;
/*     */   private final Map<ListenerCacheKey, ListenerRetriever> retrieverCache;
/*     */   private BeanFactory beanFactory;
/*     */ 
/*     */   public AbstractApplicationEventMulticaster()
/*     */   {
/*  54 */     this.defaultRetriever = new ListenerRetriever(false);
/*     */ 
/*  56 */     this.retrieverCache = new ConcurrentHashMap(64);
/*     */   }
/*     */ 
/*     */   public void addApplicationListener(ApplicationListener listener)
/*     */   {
/*  63 */     synchronized (this.defaultRetriever) {
/*  64 */       this.defaultRetriever.applicationListeners.add(listener);
/*  65 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addApplicationListenerBean(String listenerBeanName) {
/*  70 */     synchronized (this.defaultRetriever) {
/*  71 */       this.defaultRetriever.applicationListenerBeans.add(listenerBeanName);
/*  72 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeApplicationListener(ApplicationListener listener) {
/*  77 */     synchronized (this.defaultRetriever) {
/*  78 */       this.defaultRetriever.applicationListeners.remove(listener);
/*  79 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeApplicationListenerBean(String listenerBeanName) {
/*  84 */     synchronized (this.defaultRetriever) {
/*  85 */       this.defaultRetriever.applicationListenerBeans.remove(listenerBeanName);
/*  86 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeAllListeners() {
/*  91 */     synchronized (this.defaultRetriever) {
/*  92 */       this.defaultRetriever.applicationListeners.clear();
/*  93 */       this.defaultRetriever.applicationListenerBeans.clear();
/*  94 */       this.retrieverCache.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void setBeanFactory(BeanFactory beanFactory) {
/*  99 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   private BeanFactory getBeanFactory() {
/* 103 */     if (this.beanFactory == null) {
/* 104 */       throw new IllegalStateException("ApplicationEventMulticaster cannot retrieve listener beans because it is not associated with a BeanFactory");
/*     */     }
/*     */ 
/* 107 */     return this.beanFactory;
/*     */   }
/*     */ 
/*     */   protected Collection<ApplicationListener> getApplicationListeners()
/*     */   {
/* 117 */     synchronized (this.defaultRetriever) {
/* 118 */       return this.defaultRetriever.getApplicationListeners();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Collection<ApplicationListener> getApplicationListeners(ApplicationEvent event)
/*     */   {
/* 131 */     Class eventType = event.getClass();
/* 132 */     Object source = event.getSource();
/* 133 */     Class sourceType = source != null ? source.getClass() : null;
/* 134 */     ListenerCacheKey cacheKey = new ListenerCacheKey(eventType, sourceType);
/* 135 */     ListenerRetriever retriever = (ListenerRetriever)this.retrieverCache.get(cacheKey);
/* 136 */     if (retriever != null) {
/* 137 */       return retriever.getApplicationListeners();
/*     */     }
/*     */ 
/* 140 */     retriever = new ListenerRetriever(true);
/* 141 */     LinkedList allListeners = new LinkedList();
/*     */     Set listeners;
/*     */     Set listenerBeans;
/* 144 */     synchronized (this.defaultRetriever) {
/* 145 */       listeners = new LinkedHashSet(this.defaultRetriever.applicationListeners);
/* 146 */       listenerBeans = new LinkedHashSet(this.defaultRetriever.applicationListenerBeans);
/*     */     }
/* 148 */     for (ApplicationListener listener : listeners)
/* 149 */       if (supportsEvent(listener, eventType, sourceType)) {
/* 150 */         retriever.applicationListeners.add(listener);
/* 151 */         allListeners.add(listener);
/*     */       }
/*     */     BeanFactory beanFactory;
/* 154 */     if (!listenerBeans.isEmpty()) {
/* 155 */       beanFactory = getBeanFactory();
/* 156 */       for (String listenerBeanName : listenerBeans) {
/* 157 */         ApplicationListener listener = (ApplicationListener)beanFactory.getBean(listenerBeanName, ApplicationListener.class);
/* 158 */         if ((!allListeners.contains(listener)) && (supportsEvent(listener, eventType, sourceType))) {
/* 159 */           retriever.applicationListenerBeans.add(listenerBeanName);
/* 160 */           allListeners.add(listener);
/*     */         }
/*     */       }
/*     */     }
/* 164 */     OrderComparator.sort(allListeners);
/* 165 */     this.retrieverCache.put(cacheKey, retriever);
/* 166 */     return allListeners;
/*     */   }
/*     */ 
/*     */   protected boolean supportsEvent(ApplicationListener listener, Class<? extends ApplicationEvent> eventType, Class sourceType)
/*     */   {
/* 185 */     SmartApplicationListener smartListener = (listener instanceof SmartApplicationListener) ? (SmartApplicationListener)listener : new GenericApplicationListenerAdapter(listener);
/*     */ 
/* 187 */     return (smartListener.supportsEventType(eventType)) && (smartListener.supportsSourceType(sourceType));
/*     */   }
/*     */ 
/*     */   private class ListenerRetriever
/*     */   {
/*     */     public final Set<ApplicationListener> applicationListeners;
/*     */     public final Set<String> applicationListenerBeans;
/*     */     private final boolean preFiltered;
/*     */ 
/*     */     public ListenerRetriever(boolean preFiltered)
/*     */     {
/* 236 */       this.applicationListeners = new LinkedHashSet();
/* 237 */       this.applicationListenerBeans = new LinkedHashSet();
/* 238 */       this.preFiltered = preFiltered;
/*     */     }
/*     */ 
/*     */     public Collection<ApplicationListener> getApplicationListeners() {
/* 242 */       LinkedList allListeners = new LinkedList();
/* 243 */       for (ApplicationListener listener : this.applicationListeners)
/* 244 */         allListeners.add(listener);
/*     */       BeanFactory beanFactory;
/* 246 */       if (!this.applicationListenerBeans.isEmpty()) {
/* 247 */         beanFactory = AbstractApplicationEventMulticaster.this.getBeanFactory();
/* 248 */         for (String listenerBeanName : this.applicationListenerBeans) {
/* 249 */           ApplicationListener listener = (ApplicationListener)beanFactory.getBean(listenerBeanName, ApplicationListener.class);
/* 250 */           if ((this.preFiltered) || (!allListeners.contains(listener))) {
/* 251 */             allListeners.add(listener);
/*     */           }
/*     */         }
/*     */       }
/* 255 */       OrderComparator.sort(allListeners);
/* 256 */       return allListeners;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ListenerCacheKey
/*     */   {
/*     */     private final Class<?> eventType;
/*     */     private final Class<?> sourceType;
/*     */ 
/*     */     public ListenerCacheKey(Class<?> eventType, Class<?> sourceType)
/*     */     {
/* 201 */       this.eventType = eventType;
/* 202 */       this.sourceType = sourceType;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 207 */       if (this == other) {
/* 208 */         return true;
/*     */       }
/* 210 */       ListenerCacheKey otherKey = (ListenerCacheKey)other;
/* 211 */       return (ObjectUtils.nullSafeEquals(this.eventType, otherKey.eventType)) && (ObjectUtils.nullSafeEquals(this.sourceType, otherKey.sourceType));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 217 */       return ObjectUtils.nullSafeHashCode(this.eventType) * 29 + ObjectUtils.nullSafeHashCode(this.sourceType);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.event.AbstractApplicationEventMulticaster
 * JD-Core Version:    0.6.1
 */