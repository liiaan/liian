package org.springframework.context;

public abstract interface SmartLifecycle extends Lifecycle, Phased
{
  public abstract boolean isAutoStartup();

  public abstract void stop(Runnable paramRunnable);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.context.SmartLifecycle
 * JD-Core Version:    0.6.1
 */