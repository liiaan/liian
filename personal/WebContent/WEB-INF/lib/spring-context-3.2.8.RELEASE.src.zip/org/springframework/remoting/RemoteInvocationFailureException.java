/*    */ package org.springframework.remoting;
/*    */ 
/*    */ public class RemoteInvocationFailureException extends RemoteAccessException
/*    */ {
/*    */   public RemoteInvocationFailureException(String msg, Throwable cause)
/*    */   {
/* 37 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.RemoteInvocationFailureException
 * JD-Core Version:    0.6.1
 */