/*     */ package org.springframework.remoting.support;
/*     */ 
/*     */ import com.sun.net.httpserver.Authenticator;
/*     */ import com.sun.net.httpserver.Filter;
/*     */ import com.sun.net.httpserver.HttpContext;
/*     */ import com.sun.net.httpserver.HttpHandler;
/*     */ import com.sun.net.httpserver.HttpServer;
/*     */ import java.io.IOException;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.Executor;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ 
/*     */ public class SimpleHttpServerFactoryBean
/*     */   implements FactoryBean<HttpServer>, InitializingBean, DisposableBean
/*     */ {
/*  56 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*  58 */   private int port = 8080;
/*     */   private String hostname;
/*  62 */   private int backlog = -1;
/*     */ 
/*  64 */   private int shutdownDelay = 0;
/*     */   private Executor executor;
/*     */   private Map<String, HttpHandler> contexts;
/*     */   private List<Filter> filters;
/*     */   private Authenticator authenticator;
/*     */   private HttpServer server;
/*     */ 
/*     */   public void setPort(int port)
/*     */   {
/*  81 */     this.port = port;
/*     */   }
/*     */ 
/*     */   public void setHostname(String hostname)
/*     */   {
/*  89 */     this.hostname = hostname;
/*     */   }
/*     */ 
/*     */   public void setBacklog(int backlog)
/*     */   {
/*  97 */     this.backlog = backlog;
/*     */   }
/*     */ 
/*     */   public void setShutdownDelay(int shutdownDelay)
/*     */   {
/* 105 */     this.shutdownDelay = shutdownDelay;
/*     */   }
/*     */ 
/*     */   public void setExecutor(Executor executor)
/*     */   {
/* 113 */     this.executor = executor;
/*     */   }
/*     */ 
/*     */   public void setContexts(Map<String, HttpHandler> contexts)
/*     */   {
/* 126 */     this.contexts = contexts;
/*     */   }
/*     */ 
/*     */   public void setFilters(List<Filter> filters)
/*     */   {
/* 134 */     this.filters = filters;
/*     */   }
/*     */ 
/*     */   public void setAuthenticator(Authenticator authenticator)
/*     */   {
/* 142 */     this.authenticator = authenticator;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() throws IOException
/*     */   {
/* 147 */     InetSocketAddress address = this.hostname != null ? new InetSocketAddress(this.hostname, this.port) : new InetSocketAddress(this.port);
/*     */ 
/* 149 */     this.server = HttpServer.create(address, this.backlog);
/* 150 */     if (this.executor != null) {
/* 151 */       this.server.setExecutor(this.executor);
/*     */     }
/* 153 */     if (this.contexts != null) {
/* 154 */       for (String key : this.contexts.keySet()) {
/* 155 */         HttpContext httpContext = this.server.createContext(key, (HttpHandler)this.contexts.get(key));
/* 156 */         if (this.filters != null) {
/* 157 */           httpContext.getFilters().addAll(this.filters);
/*     */         }
/* 159 */         if (this.authenticator != null) {
/* 160 */           httpContext.setAuthenticator(this.authenticator);
/*     */         }
/*     */       }
/*     */     }
/* 164 */     if (this.logger.isInfoEnabled()) {
/* 165 */       this.logger.info("Starting HttpServer at address " + address);
/*     */     }
/* 167 */     this.server.start();
/*     */   }
/*     */ 
/*     */   public HttpServer getObject() {
/* 171 */     return this.server;
/*     */   }
/*     */ 
/*     */   public Class<? extends HttpServer> getObjectType() {
/* 175 */     return this.server != null ? this.server.getClass() : HttpServer.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton() {
/* 179 */     return true;
/*     */   }
/*     */ 
/*     */   public void destroy() {
/* 183 */     this.logger.info("Stopping HttpServer");
/* 184 */     this.server.stop(this.shutdownDelay);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.support.SimpleHttpServerFactoryBean
 * JD-Core Version:    0.6.1
 */