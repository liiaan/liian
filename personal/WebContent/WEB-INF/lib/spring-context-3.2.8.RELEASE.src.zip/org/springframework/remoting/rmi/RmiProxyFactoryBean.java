/*    */ package org.springframework.remoting.rmi;
/*    */ 
/*    */ import org.springframework.aop.framework.ProxyFactory;
/*    */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ 
/*    */ public class RmiProxyFactoryBean extends RmiClientInterceptor
/*    */   implements FactoryBean<Object>, BeanClassLoaderAware
/*    */ {
/*    */   private Object serviceProxy;
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 68 */     super.afterPropertiesSet();
/* 69 */     if (getServiceInterface() == null) {
/* 70 */       throw new IllegalArgumentException("Property 'serviceInterface' is required");
/*    */     }
/* 72 */     this.serviceProxy = new ProxyFactory(getServiceInterface(), this).getProxy(getBeanClassLoader());
/*    */   }
/*    */ 
/*    */   public Object getObject()
/*    */   {
/* 77 */     return this.serviceProxy;
/*    */   }
/*    */ 
/*    */   public Class<?> getObjectType() {
/* 81 */     return getServiceInterface();
/*    */   }
/*    */ 
/*    */   public boolean isSingleton() {
/* 85 */     return true;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.rmi.RmiProxyFactoryBean
 * JD-Core Version:    0.6.1
 */