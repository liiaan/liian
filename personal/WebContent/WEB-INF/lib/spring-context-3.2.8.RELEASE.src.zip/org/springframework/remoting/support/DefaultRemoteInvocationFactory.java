/*    */ package org.springframework.remoting.support;
/*    */ 
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ 
/*    */ public class DefaultRemoteInvocationFactory
/*    */   implements RemoteInvocationFactory
/*    */ {
/*    */   public RemoteInvocation createRemoteInvocation(MethodInvocation methodInvocation)
/*    */   {
/* 31 */     return new RemoteInvocation(methodInvocation);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.support.DefaultRemoteInvocationFactory
 * JD-Core Version:    0.6.1
 */