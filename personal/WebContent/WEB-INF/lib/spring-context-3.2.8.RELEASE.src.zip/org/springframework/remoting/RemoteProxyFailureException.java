/*    */ package org.springframework.remoting;
/*    */ 
/*    */ public class RemoteProxyFailureException extends RemoteAccessException
/*    */ {
/*    */   public RemoteProxyFailureException(String msg, Throwable cause)
/*    */   {
/* 37 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.RemoteProxyFailureException
 * JD-Core Version:    0.6.1
 */