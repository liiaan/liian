/*    */ package org.springframework.remoting.support;
/*    */ 
/*    */ public abstract class RemoteAccessor extends RemotingSupport
/*    */ {
/*    */   private Class serviceInterface;
/*    */ 
/*    */   public void setServiceInterface(Class serviceInterface)
/*    */   {
/* 49 */     if ((serviceInterface != null) && (!serviceInterface.isInterface())) {
/* 50 */       throw new IllegalArgumentException("'serviceInterface' must be an interface");
/*    */     }
/* 52 */     this.serviceInterface = serviceInterface;
/*    */   }
/*    */ 
/*    */   public Class getServiceInterface()
/*    */   {
/* 59 */     return this.serviceInterface;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.support.RemoteAccessor
 * JD-Core Version:    0.6.1
 */