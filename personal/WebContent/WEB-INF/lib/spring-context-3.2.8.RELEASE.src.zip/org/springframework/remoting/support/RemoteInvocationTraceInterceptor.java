/*    */ package org.springframework.remoting.support;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ public class RemoteInvocationTraceInterceptor
/*    */   implements MethodInterceptor
/*    */ {
/* 48 */   protected static final Log logger = LogFactory.getLog(RemoteInvocationTraceInterceptor.class);
/*    */   private final String exporterNameClause;
/*    */ 
/*    */   public RemoteInvocationTraceInterceptor()
/*    */   {
/* 57 */     this.exporterNameClause = "";
/*    */   }
/*    */ 
/*    */   public RemoteInvocationTraceInterceptor(String exporterName)
/*    */   {
/* 66 */     this.exporterNameClause = (exporterName + " ");
/*    */   }
/*    */ 
/*    */   public Object invoke(MethodInvocation invocation) throws Throwable
/*    */   {
/* 71 */     Method method = invocation.getMethod();
/* 72 */     if (logger.isDebugEnabled()) {
/* 73 */       logger.debug("Incoming " + this.exporterNameClause + "remote call: " + ClassUtils.getQualifiedMethodName(method));
/*    */     }
/*    */     try
/*    */     {
/* 77 */       Object retVal = invocation.proceed();
/* 78 */       if (logger.isDebugEnabled()) {
/* 79 */         logger.debug("Finished processing of " + this.exporterNameClause + "remote call: " + ClassUtils.getQualifiedMethodName(method));
/*    */       }
/*    */ 
/* 82 */       return retVal;
/*    */     }
/*    */     catch (Throwable ex) {
/* 85 */       if (((ex instanceof RuntimeException)) || ((ex instanceof Error))) {
/* 86 */         if (logger.isWarnEnabled()) {
/* 87 */           logger.warn("Processing of " + this.exporterNameClause + "remote call resulted in fatal exception: " + ClassUtils.getQualifiedMethodName(method), ex);
/*    */         }
/*    */ 
/*    */       }
/* 92 */       else if (logger.isInfoEnabled()) {
/* 93 */         logger.info("Processing of " + this.exporterNameClause + "remote call resulted in exception: " + ClassUtils.getQualifiedMethodName(method), ex);
/*    */       }
/*    */ 
/* 97 */       throw ex;
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.support.RemoteInvocationTraceInterceptor
 * JD-Core Version:    0.6.1
 */