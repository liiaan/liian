/*    */ package org.springframework.remoting;
/*    */ 
/*    */ public class RemoteLookupFailureException extends RemoteAccessException
/*    */ {
/*    */   public RemoteLookupFailureException(String msg)
/*    */   {
/* 34 */     super(msg);
/*    */   }
/*    */ 
/*    */   public RemoteLookupFailureException(String msg, Throwable cause)
/*    */   {
/* 43 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.RemoteLookupFailureException
 * JD-Core Version:    0.6.1
 */