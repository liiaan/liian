package org.springframework.remoting.support;

import java.lang.reflect.InvocationTargetException;

public abstract interface RemoteInvocationExecutor
{
  public abstract Object invoke(RemoteInvocation paramRemoteInvocation, Object paramObject)
    throws NoSuchMethodException, IllegalAccessException, InvocationTargetException;
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.support.RemoteInvocationExecutor
 * JD-Core Version:    0.6.1
 */