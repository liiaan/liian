/*    */ package org.springframework.remoting;
/*    */ 
/*    */ import org.springframework.core.NestedRuntimeException;
/*    */ 
/*    */ public class RemoteAccessException extends NestedRuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = -4906825139312227864L;
/*    */ 
/*    */   public RemoteAccessException(String msg)
/*    */   {
/* 60 */     super(msg);
/*    */   }
/*    */ 
/*    */   public RemoteAccessException(String msg, Throwable cause)
/*    */   {
/* 70 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.RemoteAccessException
 * JD-Core Version:    0.6.1
 */