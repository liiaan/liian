/*     */ package org.springframework.remoting.rmi;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.SocketException;
/*     */ import java.rmi.ConnectException;
/*     */ import java.rmi.ConnectIOException;
/*     */ import java.rmi.NoSuchObjectException;
/*     */ import java.rmi.Remote;
/*     */ import java.rmi.RemoteException;
/*     */ import java.rmi.StubNotFoundException;
/*     */ import java.rmi.UnknownHostException;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.omg.CORBA.COMM_FAILURE;
/*     */ import org.omg.CORBA.CompletionStatus;
/*     */ import org.omg.CORBA.NO_RESPONSE;
/*     */ import org.omg.CORBA.SystemException;
/*     */ import org.springframework.remoting.RemoteAccessException;
/*     */ import org.springframework.remoting.RemoteConnectFailureException;
/*     */ import org.springframework.remoting.RemoteProxyFailureException;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public abstract class RmiClientInterceptorUtils
/*     */ {
/*     */   private static final String ORACLE_CONNECTION_EXCEPTION = "com.evermind.server.rmi.RMIConnectionException";
/*  56 */   private static final Log logger = LogFactory.getLog(RmiClientInterceptorUtils.class);
/*     */ 
/*     */   @Deprecated
/*     */   public static Object invoke(MethodInvocation invocation, Remote stub, String serviceName)
/*     */     throws Throwable
/*     */   {
/*     */     try
/*     */     {
/*  72 */       return invokeRemoteMethod(invocation, stub);
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/*  75 */       Throwable targetEx = ex.getTargetException();
/*  76 */       if ((targetEx instanceof RemoteException)) {
/*  77 */         RemoteException rex = (RemoteException)targetEx;
/*  78 */         throw convertRmiAccessException(invocation.getMethod(), rex, serviceName);
/*     */       }
/*     */ 
/*  81 */       throw targetEx;
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static Object doInvoke(MethodInvocation invocation, Remote stub)
/*     */     throws InvocationTargetException
/*     */   {
/*  93 */     return invokeRemoteMethod(invocation, stub);
/*     */   }
/*     */ 
/*     */   public static Object invokeRemoteMethod(MethodInvocation invocation, Object stub)
/*     */     throws InvocationTargetException
/*     */   {
/* 107 */     Method method = invocation.getMethod();
/*     */     try {
/* 109 */       if (method.getDeclaringClass().isInstance(stub))
/*     */       {
/* 111 */         return method.invoke(stub, invocation.getArguments());
/*     */       }
/*     */ 
/* 115 */       Method stubMethod = stub.getClass().getMethod(method.getName(), method.getParameterTypes());
/* 116 */       return stubMethod.invoke(stub, invocation.getArguments());
/*     */     }
/*     */     catch (InvocationTargetException ex)
/*     */     {
/* 120 */       throw ex;
/*     */     }
/*     */     catch (NoSuchMethodException ex) {
/* 123 */       throw new RemoteProxyFailureException("No matching RMI stub method found for: " + method, ex);
/*     */     }
/*     */     catch (Throwable ex) {
/* 126 */       throw new RemoteProxyFailureException("Invocation of RMI stub method failed: " + method, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Exception convertRmiAccessException(Method method, Throwable ex, String message)
/*     */   {
/* 144 */     if (logger.isDebugEnabled()) {
/* 145 */       logger.debug(message, ex);
/*     */     }
/* 147 */     if (ReflectionUtils.declaresException(method, RemoteException.class)) {
/* 148 */       return new RemoteException(message, ex);
/*     */     }
/*     */ 
/* 151 */     return new RemoteAccessException(message, ex);
/*     */   }
/*     */ 
/*     */   public static Exception convertRmiAccessException(Method method, RemoteException ex, String serviceName)
/*     */   {
/* 165 */     return convertRmiAccessException(method, ex, isConnectFailure(ex), serviceName);
/*     */   }
/*     */ 
/*     */   public static Exception convertRmiAccessException(Method method, RemoteException ex, boolean isConnectFailure, String serviceName)
/*     */   {
/* 182 */     if (logger.isDebugEnabled()) {
/* 183 */       logger.debug("Remote service [" + serviceName + "] threw exception", ex);
/*     */     }
/* 185 */     if (ReflectionUtils.declaresException(method, ex.getClass())) {
/* 186 */       return ex;
/*     */     }
/*     */ 
/* 189 */     if (isConnectFailure) {
/* 190 */       return new RemoteConnectFailureException("Could not connect to remote service [" + serviceName + "]", ex);
/*     */     }
/*     */ 
/* 193 */     return new RemoteAccessException("Could not access remote service [" + serviceName + "]", ex);
/*     */   }
/*     */ 
/*     */   public static boolean isConnectFailure(RemoteException ex)
/*     */   {
/* 213 */     return ((ex instanceof ConnectException)) || ((ex instanceof ConnectIOException)) || ((ex instanceof UnknownHostException)) || ((ex instanceof NoSuchObjectException)) || ((ex instanceof StubNotFoundException)) || ((ex.getCause() instanceof SocketException)) || (isCorbaConnectFailure(ex.getCause())) || ("com.evermind.server.rmi.RMIConnectionException".equals(ex.getClass().getName()));
/*     */   }
/*     */ 
/*     */   private static boolean isCorbaConnectFailure(Throwable ex)
/*     */   {
/* 229 */     return (((ex instanceof COMM_FAILURE)) || ((ex instanceof NO_RESPONSE))) && (((SystemException)ex).completed == CompletionStatus.COMPLETED_NO);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.rmi.RmiClientInterceptorUtils
 * JD-Core Version:    0.6.1
 */