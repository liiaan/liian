/*    */ package org.springframework.remoting.support;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class DefaultRemoteInvocationExecutor
/*    */   implements RemoteInvocationExecutor
/*    */ {
/*    */   public Object invoke(RemoteInvocation invocation, Object targetObject)
/*    */     throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
/*    */   {
/* 36 */     Assert.notNull(invocation, "RemoteInvocation must not be null");
/* 37 */     Assert.notNull(targetObject, "Target object must not be null");
/* 38 */     return invocation.invoke(targetObject);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.support.DefaultRemoteInvocationExecutor
 * JD-Core Version:    0.6.1
 */