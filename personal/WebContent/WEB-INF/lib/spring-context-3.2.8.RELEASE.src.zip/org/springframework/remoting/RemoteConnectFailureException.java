/*    */ package org.springframework.remoting;
/*    */ 
/*    */ public class RemoteConnectFailureException extends RemoteAccessException
/*    */ {
/*    */   public RemoteConnectFailureException(String msg, Throwable cause)
/*    */   {
/* 35 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.remoting.RemoteConnectFailureException
 * JD-Core Version:    0.6.1
 */