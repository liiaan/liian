/*     */ package org.springframework.scheduling.concurrent;
/*     */ 
/*     */ import java.util.concurrent.ForkJoinPool;
/*     */ import java.util.concurrent.ForkJoinPool.ForkJoinWorkerThreadFactory;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ 
/*     */ public class ForkJoinPoolFactoryBean
/*     */   implements FactoryBean<ForkJoinPool>, InitializingBean, DisposableBean
/*     */ {
/*  41 */   private int parallelism = Runtime.getRuntime().availableProcessors();
/*     */ 
/*  43 */   private ForkJoinPool.ForkJoinWorkerThreadFactory threadFactory = ForkJoinPool.defaultForkJoinWorkerThreadFactory;
/*     */   private Thread.UncaughtExceptionHandler uncaughtExceptionHandler;
/*  47 */   private boolean asyncMode = false;
/*     */   private ForkJoinPool forkJoinPool;
/*     */ 
/*     */   public void setParallelism(int parallelism)
/*     */   {
/*  56 */     this.parallelism = parallelism;
/*     */   }
/*     */ 
/*     */   public void setThreadFactory(ForkJoinPool.ForkJoinWorkerThreadFactory threadFactory)
/*     */   {
/*  64 */     this.threadFactory = threadFactory;
/*     */   }
/*     */ 
/*     */   public void setUncaughtExceptionHandler(Thread.UncaughtExceptionHandler uncaughtExceptionHandler)
/*     */   {
/*  72 */     this.uncaughtExceptionHandler = uncaughtExceptionHandler;
/*     */   }
/*     */ 
/*     */   public void setAsyncMode(boolean asyncMode)
/*     */   {
/*  82 */     this.asyncMode = asyncMode;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() {
/*  86 */     this.forkJoinPool = new ForkJoinPool(this.parallelism, this.threadFactory, this.uncaughtExceptionHandler, this.asyncMode);
/*     */   }
/*     */ 
/*     */   public ForkJoinPool getObject()
/*     */   {
/*  92 */     return this.forkJoinPool;
/*     */   }
/*     */ 
/*     */   public Class<?> getObjectType() {
/*  96 */     return ForkJoinPool.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton() {
/* 100 */     return true;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 105 */     this.forkJoinPool.shutdown();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.concurrent.ForkJoinPoolFactoryBean
 * JD-Core Version:    0.6.1
 */