/*     */ package org.springframework.scheduling.backportconcurrent;
/*     */ 
/*     */ import edu.emory.mathcs.backport.java.util.concurrent.Executor;
/*     */ import edu.emory.mathcs.backport.java.util.concurrent.Executors;
/*     */ import edu.emory.mathcs.backport.java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.FutureTask;
/*     */ import org.springframework.core.task.TaskRejectedException;
/*     */ import org.springframework.scheduling.SchedulingTaskExecutor;
/*     */ 
/*     */ @Deprecated
/*     */ public class ConcurrentTaskExecutor
/*     */   implements SchedulingTaskExecutor, Executor
/*     */ {
/*     */   private Executor concurrentExecutor;
/*     */ 
/*     */   public ConcurrentTaskExecutor()
/*     */   {
/*  71 */     setConcurrentExecutor(null);
/*     */   }
/*     */ 
/*     */   public ConcurrentTaskExecutor(Executor concurrentExecutor)
/*     */   {
/*  80 */     setConcurrentExecutor(concurrentExecutor);
/*     */   }
/*     */ 
/*     */   public final void setConcurrentExecutor(Executor concurrentExecutor)
/*     */   {
/*  88 */     this.concurrentExecutor = (concurrentExecutor != null ? concurrentExecutor : Executors.newSingleThreadExecutor());
/*     */   }
/*     */ 
/*     */   public final Executor getConcurrentExecutor()
/*     */   {
/*  97 */     return this.concurrentExecutor;
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task)
/*     */   {
/*     */     try
/*     */     {
/* 107 */       this.concurrentExecutor.execute(task);
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 110 */       throw new TaskRejectedException("Executor [" + this.concurrentExecutor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task, long startTimeout)
/*     */   {
/* 116 */     execute(task);
/*     */   }
/*     */ 
/*     */   public Future<?> submit(Runnable task) {
/* 120 */     FutureTask future = new FutureTask(task, null);
/* 121 */     execute(future);
/* 122 */     return future;
/*     */   }
/*     */ 
/*     */   public <T> Future<T> submit(Callable<T> task) {
/* 126 */     FutureTask future = new FutureTask(task);
/* 127 */     execute(future);
/* 128 */     return future;
/*     */   }
/*     */ 
/*     */   public boolean prefersShortLivedTasks()
/*     */   {
/* 135 */     return true;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.backportconcurrent.ConcurrentTaskExecutor
 * JD-Core Version:    0.6.1
 */