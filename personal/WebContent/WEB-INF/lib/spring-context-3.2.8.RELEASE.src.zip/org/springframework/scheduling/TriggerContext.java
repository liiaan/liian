package org.springframework.scheduling;

import java.util.Date;

public abstract interface TriggerContext
{
  public abstract Date lastScheduledExecutionTime();

  public abstract Date lastActualExecutionTime();

  public abstract Date lastCompletionTime();
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.TriggerContext
 * JD-Core Version:    0.6.1
 */