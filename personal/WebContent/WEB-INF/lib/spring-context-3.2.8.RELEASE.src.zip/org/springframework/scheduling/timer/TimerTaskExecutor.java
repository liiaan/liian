/*     */ package org.springframework.scheduling.timer;
/*     */ 
/*     */ import java.util.Timer;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.FutureTask;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.scheduling.SchedulingTaskExecutor;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ @Deprecated
/*     */ public class TimerTaskExecutor
/*     */   implements SchedulingTaskExecutor, BeanNameAware, InitializingBean, DisposableBean
/*     */ {
/*  48 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private Timer timer;
/*  52 */   private long delay = 0L;
/*     */   private String beanName;
/*  56 */   private boolean timerInternal = false;
/*     */ 
/*     */   public TimerTaskExecutor()
/*     */   {
/*     */   }
/*     */ 
/*     */   public TimerTaskExecutor(Timer timer)
/*     */   {
/*  72 */     Assert.notNull(timer, "Timer must not be null");
/*  73 */     this.timer = timer;
/*     */   }
/*     */ 
/*     */   public void setTimer(Timer timer)
/*     */   {
/*  85 */     this.timer = timer;
/*     */   }
/*     */ 
/*     */   public void setDelay(long delay)
/*     */   {
/*  96 */     this.delay = delay;
/*     */   }
/*     */ 
/*     */   public void setBeanName(String beanName) {
/* 100 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 105 */     if (this.timer == null) {
/* 106 */       this.logger.info("Initializing Timer");
/* 107 */       this.timer = createTimer();
/* 108 */       this.timerInternal = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Timer createTimer()
/*     */   {
/* 122 */     if (StringUtils.hasText(this.beanName)) {
/* 123 */       return new Timer(this.beanName);
/*     */     }
/*     */ 
/* 126 */     return new Timer();
/*     */   }
/*     */ 
/*     */   protected final Timer getTimer()
/*     */   {
/* 134 */     Assert.notNull(this.timer, "Timer not initialized yet");
/* 135 */     return this.timer;
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task)
/*     */   {
/* 145 */     getTimer().schedule(new DelegatingTimerTask(task), this.delay);
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task, long startTimeout) {
/* 149 */     long actualDelay = startTimeout < this.delay ? startTimeout : this.delay;
/* 150 */     getTimer().schedule(new DelegatingTimerTask(task), actualDelay);
/*     */   }
/*     */ 
/*     */   public Future<?> submit(Runnable task) {
/* 154 */     FutureTask future = new FutureTask(task, null);
/* 155 */     execute(future);
/* 156 */     return future;
/*     */   }
/*     */ 
/*     */   public <T> Future<T> submit(Callable<T> task) {
/* 160 */     FutureTask future = new FutureTask(task);
/* 161 */     execute(future);
/* 162 */     return future;
/*     */   }
/*     */ 
/*     */   public boolean prefersShortLivedTasks()
/*     */   {
/* 169 */     return true;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 178 */     if (this.timerInternal) {
/* 179 */       this.logger.info("Cancelling Timer");
/* 180 */       this.timer.cancel();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.timer.TimerTaskExecutor
 * JD-Core Version:    0.6.1
 */