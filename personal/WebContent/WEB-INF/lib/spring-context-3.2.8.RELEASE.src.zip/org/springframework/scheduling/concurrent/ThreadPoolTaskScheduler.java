/*     */ package org.springframework.scheduling.concurrent;
/*     */ 
/*     */ import java.util.Date;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.RejectedExecutionHandler;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.springframework.core.task.TaskRejectedException;
/*     */ import org.springframework.scheduling.SchedulingTaskExecutor;
/*     */ import org.springframework.scheduling.TaskScheduler;
/*     */ import org.springframework.scheduling.Trigger;
/*     */ import org.springframework.scheduling.support.TaskUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ErrorHandler;
/*     */ 
/*     */ public class ThreadPoolTaskScheduler extends ExecutorConfigurationSupport
/*     */   implements TaskScheduler, SchedulingTaskExecutor
/*     */ {
/*     */   private volatile int poolSize;
/*     */   private volatile ScheduledExecutorService scheduledExecutor;
/*     */   private volatile ErrorHandler errorHandler;
/*     */ 
/*     */   public ThreadPoolTaskScheduler()
/*     */   {
/*  55 */     this.poolSize = 1;
/*     */   }
/*     */ 
/*     */   public void setPoolSize(int poolSize)
/*     */   {
/*  67 */     Assert.isTrue(poolSize > 0, "'poolSize' must be 1 or higher");
/*  68 */     this.poolSize = poolSize;
/*     */   }
/*     */ 
/*     */   public void setErrorHandler(ErrorHandler errorHandler)
/*     */   {
/*  75 */     Assert.notNull(errorHandler, "'errorHandler' must not be null");
/*  76 */     this.errorHandler = errorHandler;
/*     */   }
/*     */ 
/*     */   protected ExecutorService initializeExecutor(ThreadFactory threadFactory, RejectedExecutionHandler rejectedExecutionHandler)
/*     */   {
/*  82 */     this.scheduledExecutor = createExecutor(this.poolSize, threadFactory, rejectedExecutionHandler);
/*  83 */     return this.scheduledExecutor;
/*     */   }
/*     */ 
/*     */   protected ScheduledExecutorService createExecutor(int poolSize, ThreadFactory threadFactory, RejectedExecutionHandler rejectedExecutionHandler)
/*     */   {
/* 100 */     return new ScheduledThreadPoolExecutor(poolSize, threadFactory, rejectedExecutionHandler);
/*     */   }
/*     */ 
/*     */   public ScheduledExecutorService getScheduledExecutor()
/*     */     throws IllegalStateException
/*     */   {
/* 109 */     Assert.state(this.scheduledExecutor != null, "ThreadPoolTaskScheduler not initialized");
/* 110 */     return this.scheduledExecutor;
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task)
/*     */   {
/* 117 */     Executor executor = getScheduledExecutor();
/*     */     try {
/* 119 */       executor.execute(errorHandlingTask(task, false));
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 122 */       throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task, long startTimeout) {
/* 127 */     execute(task);
/*     */   }
/*     */ 
/*     */   public Future<?> submit(Runnable task) {
/* 131 */     ExecutorService executor = getScheduledExecutor();
/*     */     try {
/* 133 */       return executor.submit(errorHandlingTask(task, false));
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 136 */       throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public <T> Future<T> submit(Callable<T> task) {
/* 141 */     ExecutorService executor = getScheduledExecutor();
/*     */     try {
/* 143 */       Callable taskToUse = task;
/* 144 */       if (this.errorHandler != null) {
/* 145 */         taskToUse = new DelegatingErrorHandlingCallable(task, this.errorHandler);
/*     */       }
/* 147 */       return executor.submit(taskToUse);
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 150 */       throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean prefersShortLivedTasks() {
/* 155 */     return true;
/*     */   }
/*     */ 
/*     */   public ScheduledFuture schedule(Runnable task, Trigger trigger)
/*     */   {
/* 162 */     ScheduledExecutorService executor = getScheduledExecutor();
/*     */     try {
/* 164 */       ErrorHandler errorHandler = this.errorHandler != null ? this.errorHandler : TaskUtils.getDefaultErrorHandler(true);
/*     */ 
/* 166 */       return new ReschedulingRunnable(task, trigger, executor, errorHandler).schedule();
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 169 */       throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ScheduledFuture schedule(Runnable task, Date startTime) {
/* 174 */     ScheduledExecutorService executor = getScheduledExecutor();
/* 175 */     long initialDelay = startTime.getTime() - System.currentTimeMillis();
/*     */     try {
/* 177 */       return executor.schedule(errorHandlingTask(task, false), initialDelay, TimeUnit.MILLISECONDS);
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 180 */       throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ScheduledFuture scheduleAtFixedRate(Runnable task, Date startTime, long period) {
/* 185 */     ScheduledExecutorService executor = getScheduledExecutor();
/* 186 */     long initialDelay = startTime.getTime() - System.currentTimeMillis();
/*     */     try {
/* 188 */       return executor.scheduleAtFixedRate(errorHandlingTask(task, true), initialDelay, period, TimeUnit.MILLISECONDS);
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 191 */       throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ScheduledFuture scheduleAtFixedRate(Runnable task, long period) {
/* 196 */     ScheduledExecutorService executor = getScheduledExecutor();
/*     */     try {
/* 198 */       return executor.scheduleAtFixedRate(errorHandlingTask(task, true), 0L, period, TimeUnit.MILLISECONDS);
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 201 */       throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ScheduledFuture scheduleWithFixedDelay(Runnable task, Date startTime, long delay) {
/* 206 */     ScheduledExecutorService executor = getScheduledExecutor();
/* 207 */     long initialDelay = startTime.getTime() - System.currentTimeMillis();
/*     */     try {
/* 209 */       return executor.scheduleWithFixedDelay(errorHandlingTask(task, true), initialDelay, delay, TimeUnit.MILLISECONDS);
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 212 */       throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ScheduledFuture scheduleWithFixedDelay(Runnable task, long delay) {
/* 217 */     ScheduledExecutorService executor = getScheduledExecutor();
/*     */     try {
/* 219 */       return executor.scheduleWithFixedDelay(errorHandlingTask(task, true), 0L, delay, TimeUnit.MILLISECONDS);
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 222 */       throw new TaskRejectedException("Executor [" + executor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Runnable errorHandlingTask(Runnable task, boolean isRepeatingTask)
/*     */   {
/* 228 */     return TaskUtils.decorateTaskWithErrorHandler(task, this.errorHandler, isRepeatingTask);
/*     */   }
/*     */ 
/*     */   private static class DelegatingErrorHandlingCallable<V> implements Callable<V>
/*     */   {
/*     */     private final Callable<V> delegate;
/*     */     private final ErrorHandler errorHandler;
/*     */ 
/*     */     public DelegatingErrorHandlingCallable(Callable<V> delegate, ErrorHandler errorHandler)
/*     */     {
/* 239 */       this.delegate = delegate;
/* 240 */       this.errorHandler = errorHandler;
/*     */     }
/*     */ 
/*     */     public V call() throws Exception {
/*     */       try {
/* 245 */         return this.delegate.call();
/*     */       }
/*     */       catch (Throwable t) {
/* 248 */         this.errorHandler.handleError(t);
/* 249 */       }return null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler
 * JD-Core Version:    0.6.1
 */