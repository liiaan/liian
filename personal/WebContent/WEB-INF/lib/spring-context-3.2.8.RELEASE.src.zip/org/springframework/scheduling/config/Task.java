/*    */ package org.springframework.scheduling.config;
/*    */ 
/*    */ public class Task
/*    */ {
/*    */   private final Runnable runnable;
/*    */ 
/*    */   public Task(Runnable runnable)
/*    */   {
/* 36 */     this.runnable = runnable;
/*    */   }
/*    */ 
/*    */   public Runnable getRunnable()
/*    */   {
/* 41 */     return this.runnable;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.config.Task
 * JD-Core Version:    0.6.1
 */