/*    */ package org.springframework.scheduling.config;
/*    */ 
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.xml.AbstractSingleBeanDefinitionParser;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ public class SchedulerBeanDefinitionParser extends AbstractSingleBeanDefinitionParser
/*    */ {
/*    */   protected String getBeanClassName(Element element)
/*    */   {
/* 35 */     return "org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler";
/*    */   }
/*    */ 
/*    */   protected void doParse(Element element, BeanDefinitionBuilder builder)
/*    */   {
/* 40 */     String poolSize = element.getAttribute("pool-size");
/* 41 */     if (StringUtils.hasText(poolSize))
/* 42 */       builder.addPropertyValue("poolSize", poolSize);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.config.SchedulerBeanDefinitionParser
 * JD-Core Version:    0.6.1
 */