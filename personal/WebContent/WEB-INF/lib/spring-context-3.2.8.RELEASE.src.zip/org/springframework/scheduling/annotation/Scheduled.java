package org.springframework.scheduling.annotation;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({java.lang.annotation.ElementType.METHOD, java.lang.annotation.ElementType.ANNOTATION_TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface Scheduled
{
  public abstract String cron();

  public abstract long fixedDelay();

  public abstract String fixedDelayString();

  public abstract long fixedRate();

  public abstract String fixedRateString();

  public abstract long initialDelay();

  public abstract String initialDelayString();
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.annotation.Scheduled
 * JD-Core Version:    0.6.1
 */