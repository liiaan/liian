/*    */ package org.springframework.scheduling.support;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.beans.support.ArgumentConvertingMethodInvoker;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ public class MethodInvokingRunnable extends ArgumentConvertingMethodInvoker
/*    */   implements Runnable, BeanClassLoaderAware, InitializingBean
/*    */ {
/* 44 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */ 
/* 46 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*    */ 
/*    */   public void setBeanClassLoader(ClassLoader classLoader)
/*    */   {
/* 50 */     this.beanClassLoader = classLoader;
/*    */   }
/*    */ 
/*    */   protected Class resolveClassName(String className) throws ClassNotFoundException
/*    */   {
/* 55 */     return ClassUtils.forName(className, this.beanClassLoader);
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet() throws ClassNotFoundException, NoSuchMethodException {
/* 59 */     prepare();
/*    */   }
/*    */ 
/*    */   public void run()
/*    */   {
/*    */     try {
/* 65 */       invoke();
/*    */     }
/*    */     catch (InvocationTargetException ex) {
/* 68 */       this.logger.error(getInvocationFailureMessage(), ex.getTargetException());
/*    */     }
/*    */     catch (Throwable ex)
/*    */     {
/* 72 */       this.logger.error(getInvocationFailureMessage(), ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   protected String getInvocationFailureMessage()
/*    */   {
/* 82 */     return "Invocation of method '" + getTargetMethod() + "' on target class [" + getTargetClass() + "] failed";
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.support.MethodInvokingRunnable
 * JD-Core Version:    0.6.1
 */