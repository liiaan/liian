package org.springframework.scheduling.annotation;

import java.util.concurrent.Executor;

public abstract interface AsyncConfigurer
{
  public abstract Executor getAsyncExecutor();
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.annotation.AsyncConfigurer
 * JD-Core Version:    0.6.1
 */