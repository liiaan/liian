/*     */ package org.springframework.scheduling.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.BitSet;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.TimeZone;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class CronSequenceGenerator
/*     */ {
/*  56 */   private final BitSet seconds = new BitSet(60);
/*     */ 
/*  58 */   private final BitSet minutes = new BitSet(60);
/*     */ 
/*  60 */   private final BitSet hours = new BitSet(24);
/*     */ 
/*  62 */   private final BitSet daysOfWeek = new BitSet(7);
/*     */ 
/*  64 */   private final BitSet daysOfMonth = new BitSet(31);
/*     */ 
/*  66 */   private final BitSet months = new BitSet(12);
/*     */   private final String expression;
/*     */   private final TimeZone timeZone;
/*     */ 
/*     */   public CronSequenceGenerator(String expression)
/*     */   {
/*  81 */     this(expression, TimeZone.getDefault());
/*     */   }
/*     */ 
/*     */   public CronSequenceGenerator(String expression, TimeZone timeZone)
/*     */   {
/*  92 */     this.expression = expression;
/*  93 */     this.timeZone = timeZone;
/*  94 */     parse(expression);
/*     */   }
/*     */ 
/*     */   public Date next(Date date)
/*     */   {
/* 125 */     Calendar calendar = new GregorianCalendar();
/* 126 */     calendar.setTimeZone(this.timeZone);
/* 127 */     calendar.setTime(date);
/*     */ 
/* 130 */     calendar.set(14, 0);
/* 131 */     long originalTimestamp = calendar.getTimeInMillis();
/* 132 */     doNext(calendar, calendar.get(1));
/*     */ 
/* 134 */     if (calendar.getTimeInMillis() == originalTimestamp)
/*     */     {
/* 136 */       calendar.add(13, 1);
/* 137 */       doNext(calendar, calendar.get(1));
/*     */     }
/*     */ 
/* 140 */     return calendar.getTime();
/*     */   }
/*     */ 
/*     */   private void doNext(Calendar calendar, int dot) {
/* 144 */     List resets = new ArrayList();
/*     */ 
/* 146 */     int second = calendar.get(13);
/* 147 */     List emptyList = Collections.emptyList();
/* 148 */     int updateSecond = findNext(this.seconds, second, calendar, 13, 12, emptyList);
/* 149 */     if (second == updateSecond) {
/* 150 */       resets.add(Integer.valueOf(13));
/*     */     }
/*     */ 
/* 153 */     int minute = calendar.get(12);
/* 154 */     int updateMinute = findNext(this.minutes, minute, calendar, 12, 11, resets);
/* 155 */     if (minute == updateMinute) {
/* 156 */       resets.add(Integer.valueOf(12));
/*     */     }
/*     */     else {
/* 159 */       doNext(calendar, dot);
/*     */     }
/*     */ 
/* 162 */     int hour = calendar.get(11);
/* 163 */     int updateHour = findNext(this.hours, hour, calendar, 11, 7, resets);
/* 164 */     if (hour == updateHour) {
/* 165 */       resets.add(Integer.valueOf(11));
/*     */     }
/*     */     else {
/* 168 */       doNext(calendar, dot);
/*     */     }
/*     */ 
/* 171 */     int dayOfWeek = calendar.get(7);
/* 172 */     int dayOfMonth = calendar.get(5);
/* 173 */     int updateDayOfMonth = findNextDay(calendar, this.daysOfMonth, dayOfMonth, this.daysOfWeek, dayOfWeek, resets);
/* 174 */     if (dayOfMonth == updateDayOfMonth) {
/* 175 */       resets.add(Integer.valueOf(5));
/*     */     }
/*     */     else {
/* 178 */       doNext(calendar, dot);
/*     */     }
/*     */ 
/* 181 */     int month = calendar.get(2);
/* 182 */     int updateMonth = findNext(this.months, month, calendar, 2, 1, resets);
/* 183 */     if (month != updateMonth) {
/* 184 */       if (calendar.get(1) - dot > 4) {
/* 185 */         throw new IllegalArgumentException("Invalid cron expression \"" + this.expression + "\" led to runaway search for next trigger");
/*     */       }
/*     */ 
/* 188 */       doNext(calendar, dot);
/*     */     }
/*     */   }
/*     */ 
/*     */   private int findNextDay(Calendar calendar, BitSet daysOfMonth, int dayOfMonth, BitSet daysOfWeek, int dayOfWeek, List<Integer> resets)
/*     */   {
/* 196 */     int count = 0;
/* 197 */     int max = 366;
/*     */ 
/* 200 */     while (((!daysOfMonth.get(dayOfMonth)) || (!daysOfWeek.get(dayOfWeek - 1))) && (count++ < max)) {
/* 201 */       calendar.add(5, 1);
/* 202 */       dayOfMonth = calendar.get(5);
/* 203 */       dayOfWeek = calendar.get(7);
/* 204 */       reset(calendar, resets);
/*     */     }
/* 206 */     if (count >= max) {
/* 207 */       throw new IllegalArgumentException("Overflow in day for expression \"" + this.expression + "\"");
/*     */     }
/* 209 */     return dayOfMonth;
/*     */   }
/*     */ 
/*     */   private int findNext(BitSet bits, int value, Calendar calendar, int field, int nextField, List<Integer> lowerOrders)
/*     */   {
/* 225 */     int nextValue = bits.nextSetBit(value);
/*     */ 
/* 227 */     if (nextValue == -1) {
/* 228 */       calendar.add(nextField, 1);
/* 229 */       reset(calendar, Arrays.asList(new Integer[] { Integer.valueOf(field) }));
/* 230 */       nextValue = bits.nextSetBit(0);
/*     */     }
/* 232 */     if (nextValue != value) {
/* 233 */       calendar.set(field, nextValue);
/* 234 */       reset(calendar, lowerOrders);
/*     */     }
/* 236 */     return nextValue;
/*     */   }
/*     */ 
/*     */   private void reset(Calendar calendar, List<Integer> fields)
/*     */   {
/* 243 */     for (Iterator i$ = fields.iterator(); i$.hasNext(); ) { int field = ((Integer)i$.next()).intValue();
/* 244 */       calendar.set(field, field == 5 ? 1 : 0);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void parse(String expression)
/*     */     throws IllegalArgumentException
/*     */   {
/* 255 */     String[] fields = StringUtils.tokenizeToStringArray(expression, " ");
/* 256 */     if (fields.length != 6) {
/* 257 */       throw new IllegalArgumentException(String.format("Cron expression must consist of 6 fields (found %d in \"%s\")", new Object[] { Integer.valueOf(fields.length), expression }));
/*     */     }
/*     */ 
/* 260 */     setNumberHits(this.seconds, fields[0], 0, 60);
/* 261 */     setNumberHits(this.minutes, fields[1], 0, 60);
/* 262 */     setNumberHits(this.hours, fields[2], 0, 24);
/* 263 */     setDaysOfMonth(this.daysOfMonth, fields[3]);
/* 264 */     setMonths(this.months, fields[4]);
/* 265 */     setDays(this.daysOfWeek, replaceOrdinals(fields[5], "SUN,MON,TUE,WED,THU,FRI,SAT"), 8);
/* 266 */     if (this.daysOfWeek.get(7))
/*     */     {
/* 268 */       this.daysOfWeek.set(0);
/* 269 */       this.daysOfWeek.clear(7);
/*     */     }
/*     */   }
/*     */ 
/*     */   private String replaceOrdinals(String value, String commaSeparatedList)
/*     */   {
/* 279 */     String[] list = StringUtils.commaDelimitedListToStringArray(commaSeparatedList);
/* 280 */     for (int i = 0; i < list.length; i++) {
/* 281 */       String item = list[i].toUpperCase();
/* 282 */       value = StringUtils.replace(value.toUpperCase(), item, "" + i);
/*     */     }
/* 284 */     return value;
/*     */   }
/*     */ 
/*     */   private void setDaysOfMonth(BitSet bits, String field) {
/* 288 */     int max = 31;
/*     */ 
/* 290 */     setDays(bits, field, max + 1);
/*     */ 
/* 292 */     bits.clear(0);
/*     */   }
/*     */ 
/*     */   private void setDays(BitSet bits, String field, int max) {
/* 296 */     if (field.contains("?")) {
/* 297 */       field = "*";
/*     */     }
/* 299 */     setNumberHits(bits, field, 0, max);
/*     */   }
/*     */ 
/*     */   private void setMonths(BitSet bits, String value) {
/* 303 */     int max = 12;
/* 304 */     value = replaceOrdinals(value, "FOO,JAN,FEB,MAR,APR,MAY,JUN,JUL,AUG,SEP,OCT,NOV,DEC");
/* 305 */     BitSet months = new BitSet(13);
/*     */ 
/* 307 */     setNumberHits(months, value, 1, max + 1);
/*     */ 
/* 309 */     for (int i = 1; i <= max; i++)
/* 310 */       if (months.get(i))
/* 311 */         bits.set(i - 1);
/*     */   }
/*     */ 
/*     */   private void setNumberHits(BitSet bits, String value, int min, int max)
/*     */   {
/* 317 */     String[] fields = StringUtils.delimitedListToStringArray(value, ",");
/* 318 */     for (String field : fields)
/* 319 */       if (!field.contains("/"))
/*     */       {
/* 321 */         int[] range = getRange(field, min, max);
/* 322 */         bits.set(range[0], range[1] + 1);
/*     */       }
/*     */       else {
/* 325 */         String[] split = StringUtils.delimitedListToStringArray(field, "/");
/* 326 */         if (split.length > 2) {
/* 327 */           throw new IllegalArgumentException("Incrementer has more than two fields: '" + field + "' in expression \"" + this.expression + "\"");
/*     */         }
/*     */ 
/* 330 */         int[] range = getRange(split[0], min, max);
/* 331 */         if (!split[0].contains("-")) {
/* 332 */           range[1] = (max - 1);
/*     */         }
/* 334 */         int delta = Integer.valueOf(split[1]).intValue();
/* 335 */         for (int i = range[0]; i <= range[1]; i += delta)
/* 336 */           bits.set(i);
/*     */       }
/*     */   }
/*     */ 
/*     */   private int[] getRange(String field, int min, int max)
/*     */   {
/* 343 */     int[] result = new int[2];
/* 344 */     if (field.contains("*")) {
/* 345 */       result[0] = min;
/* 346 */       result[1] = (max - 1);
/* 347 */       return result;
/*     */     }
/* 349 */     if (!field.contains("-"))
/*     */     {
/*     */       int tmp51_48 = Integer.valueOf(field).intValue(); result[1] = tmp51_48; result[0] = tmp51_48;
/*     */     }
/*     */     else {
/* 353 */       String[] split = StringUtils.delimitedListToStringArray(field, "-");
/* 354 */       if (split.length > 2) {
/* 355 */         throw new IllegalArgumentException("Range has more than two fields: '" + field + "' in expression \"" + this.expression + "\"");
/*     */       }
/*     */ 
/* 358 */       result[0] = Integer.valueOf(split[0]).intValue();
/* 359 */       result[1] = Integer.valueOf(split[1]).intValue();
/*     */     }
/* 361 */     if ((result[0] >= max) || (result[1] >= max)) {
/* 362 */       throw new IllegalArgumentException("Range exceeds maximum (" + max + "): '" + field + "' in expression \"" + this.expression + "\"");
/*     */     }
/*     */ 
/* 365 */     if ((result[0] < min) || (result[1] < min)) {
/* 366 */       throw new IllegalArgumentException("Range less than minimum (" + min + "): '" + field + "' in expression \"" + this.expression + "\"");
/*     */     }
/*     */ 
/* 369 */     return result;
/*     */   }
/*     */ 
/*     */   String getExpression() {
/* 373 */     return this.expression;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 378 */     if (!(obj instanceof CronSequenceGenerator)) {
/* 379 */       return false;
/*     */     }
/* 381 */     CronSequenceGenerator cron = (CronSequenceGenerator)obj;
/* 382 */     return (cron.months.equals(this.months)) && (cron.daysOfMonth.equals(this.daysOfMonth)) && (cron.daysOfWeek.equals(this.daysOfWeek)) && (cron.hours.equals(this.hours)) && (cron.minutes.equals(this.minutes)) && (cron.seconds.equals(this.seconds));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 389 */     return 37 + 17 * this.months.hashCode() + 29 * this.daysOfMonth.hashCode() + 37 * this.daysOfWeek.hashCode() + 41 * this.hours.hashCode() + 53 * this.minutes.hashCode() + 61 * this.seconds.hashCode();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 395 */     return getClass().getSimpleName() + ": " + this.expression;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.support.CronSequenceGenerator
 * JD-Core Version:    0.6.1
 */