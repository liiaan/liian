/*     */ package org.springframework.scheduling.config;
/*     */ 
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.BeanDefinitionHolder;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ public class AnnotationDrivenBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */ 
/*     */   @Deprecated
/*     */   public static final String ASYNC_ANNOTATION_PROCESSOR_BEAN_NAME = "org.springframework.context.annotation.internalAsyncAnnotationProcessor";
/*     */ 
/*     */   @Deprecated
/*     */   public static final String ASYNC_EXECUTION_ASPECT_BEAN_NAME = "org.springframework.scheduling.config.internalAsyncExecutionAspect";
/*     */ 
/*     */   @Deprecated
/*     */   public static final String SCHEDULED_ANNOTATION_PROCESSOR_BEAN_NAME = "org.springframework.context.annotation.internalScheduledAnnotationProcessor";
/*     */ 
/*     */   public BeanDefinition parse(Element element, ParserContext parserContext)
/*     */   {
/*  73 */     Object source = parserContext.extractSource(element);
/*     */ 
/*  76 */     CompositeComponentDefinition compDefinition = new CompositeComponentDefinition(element.getTagName(), source);
/*  77 */     parserContext.pushContainingComponent(compDefinition);
/*     */ 
/*  80 */     BeanDefinitionRegistry registry = parserContext.getRegistry();
/*     */ 
/*  82 */     String mode = element.getAttribute("mode");
/*  83 */     if ("aspectj".equals(mode))
/*     */     {
/*  85 */       registerAsyncExecutionAspect(element, parserContext);
/*     */     }
/*  89 */     else if (registry.containsBeanDefinition("org.springframework.context.annotation.internalAsyncAnnotationProcessor")) {
/*  90 */       parserContext.getReaderContext().error("Only one AsyncAnnotationBeanPostProcessor may exist within the context.", source);
/*     */     }
/*     */     else
/*     */     {
/*  94 */       BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition("org.springframework.scheduling.annotation.AsyncAnnotationBeanPostProcessor");
/*     */ 
/*  96 */       builder.getRawBeanDefinition().setSource(source);
/*  97 */       String executor = element.getAttribute("executor");
/*  98 */       if (StringUtils.hasText(executor)) {
/*  99 */         builder.addPropertyReference("executor", executor);
/*     */       }
/* 101 */       if (Boolean.valueOf(element.getAttribute("proxy-target-class")).booleanValue()) {
/* 102 */         builder.addPropertyValue("proxyTargetClass", Boolean.valueOf(true));
/*     */       }
/* 104 */       registerPostProcessor(parserContext, builder, "org.springframework.context.annotation.internalAsyncAnnotationProcessor");
/*     */     }
/*     */ 
/* 108 */     if (registry.containsBeanDefinition("org.springframework.context.annotation.internalScheduledAnnotationProcessor")) {
/* 109 */       parserContext.getReaderContext().error("Only one ScheduledAnnotationBeanPostProcessor may exist within the context.", source);
/*     */     }
/*     */     else
/*     */     {
/* 113 */       BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition("org.springframework.scheduling.annotation.ScheduledAnnotationBeanPostProcessor");
/*     */ 
/* 115 */       builder.getRawBeanDefinition().setSource(source);
/* 116 */       String scheduler = element.getAttribute("scheduler");
/* 117 */       if (StringUtils.hasText(scheduler)) {
/* 118 */         builder.addPropertyReference("scheduler", scheduler);
/*     */       }
/* 120 */       registerPostProcessor(parserContext, builder, "org.springframework.context.annotation.internalScheduledAnnotationProcessor");
/*     */     }
/*     */ 
/* 124 */     parserContext.popAndRegisterContainingComponent();
/*     */ 
/* 126 */     return null;
/*     */   }
/*     */ 
/*     */   private void registerAsyncExecutionAspect(Element element, ParserContext parserContext) {
/* 130 */     if (!parserContext.getRegistry().containsBeanDefinition("org.springframework.scheduling.config.internalAsyncExecutionAspect")) {
/* 131 */       BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition("org.springframework.scheduling.aspectj.AnnotationAsyncExecutionAspect");
/*     */ 
/* 133 */       builder.setFactoryMethod("aspectOf");
/* 134 */       String executor = element.getAttribute("executor");
/* 135 */       if (StringUtils.hasText(executor)) {
/* 136 */         builder.addPropertyReference("executor", executor);
/*     */       }
/* 138 */       parserContext.registerBeanComponent(new BeanComponentDefinition(builder.getBeanDefinition(), "org.springframework.scheduling.config.internalAsyncExecutionAspect"));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void registerPostProcessor(ParserContext parserContext, BeanDefinitionBuilder builder, String beanName)
/*     */   {
/* 147 */     builder.setRole(2);
/* 148 */     parserContext.getRegistry().registerBeanDefinition(beanName, builder.getBeanDefinition());
/* 149 */     BeanDefinitionHolder holder = new BeanDefinitionHolder(builder.getBeanDefinition(), beanName);
/* 150 */     parserContext.registerComponent(new BeanComponentDefinition(holder));
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.config.AnnotationDrivenBeanDefinitionParser
 * JD-Core Version:    0.6.1
 */