/*    */ package org.springframework.scheduling.config;
/*    */ 
/*    */ import org.springframework.context.ApplicationContext;
/*    */ import org.springframework.context.ApplicationContextAware;
/*    */ import org.springframework.context.ApplicationListener;
/*    */ import org.springframework.context.event.ContextRefreshedEvent;
/*    */ 
/*    */ public class ContextLifecycleScheduledTaskRegistrar extends ScheduledTaskRegistrar
/*    */   implements ApplicationContextAware, ApplicationListener<ContextRefreshedEvent>
/*    */ {
/*    */   private ApplicationContext applicationContext;
/*    */ 
/*    */   public void setApplicationContext(ApplicationContext applicationContext)
/*    */   {
/* 39 */     this.applicationContext = applicationContext;
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 49 */     if (this.applicationContext == null)
/* 50 */       scheduleTasks();
/*    */   }
/*    */ 
/*    */   public void onApplicationEvent(ContextRefreshedEvent event)
/*    */   {
/* 59 */     if (event.getApplicationContext() != this.applicationContext) {
/* 60 */       return;
/*    */     }
/* 62 */     scheduleTasks();
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.config.ContextLifecycleScheduledTaskRegistrar
 * JD-Core Version:    0.6.1
 */