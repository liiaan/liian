/*    */ package org.springframework.scheduling.annotation;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.util.concurrent.Executor;
/*    */ import org.springframework.aop.framework.AbstractAdvisingBeanPostProcessor;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class AsyncAnnotationBeanPostProcessor extends AbstractAdvisingBeanPostProcessor
/*    */   implements BeanFactoryAware
/*    */ {
/*    */   private Class<? extends Annotation> asyncAnnotationType;
/*    */   private Executor executor;
/*    */ 
/*    */   public AsyncAnnotationBeanPostProcessor()
/*    */   {
/* 61 */     setBeforeExistingAdvisors(true);
/*    */   }
/*    */ 
/*    */   public void setAsyncAnnotationType(Class<? extends Annotation> asyncAnnotationType)
/*    */   {
/* 74 */     Assert.notNull(asyncAnnotationType, "'asyncAnnotationType' must not be null");
/* 75 */     this.asyncAnnotationType = asyncAnnotationType;
/*    */   }
/*    */ 
/*    */   public void setExecutor(Executor executor)
/*    */   {
/* 82 */     this.executor = executor;
/*    */   }
/*    */ 
/*    */   public void setBeanFactory(BeanFactory beanFactory) {
/* 86 */     AsyncAnnotationAdvisor advisor = this.executor != null ? new AsyncAnnotationAdvisor(this.executor) : new AsyncAnnotationAdvisor();
/*    */ 
/* 88 */     if (this.asyncAnnotationType != null) {
/* 89 */       advisor.setAsyncAnnotationType(this.asyncAnnotationType);
/*    */     }
/* 91 */     advisor.setBeanFactory(beanFactory);
/* 92 */     this.advisor = advisor;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.annotation.AsyncAnnotationBeanPostProcessor
 * JD-Core Version:    0.6.1
 */