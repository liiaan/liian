package org.springframework.scheduling;

import org.springframework.core.task.AsyncTaskExecutor;

public abstract interface SchedulingTaskExecutor extends AsyncTaskExecutor
{
  public abstract boolean prefersShortLivedTasks();
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.SchedulingTaskExecutor
 * JD-Core Version:    0.6.1
 */