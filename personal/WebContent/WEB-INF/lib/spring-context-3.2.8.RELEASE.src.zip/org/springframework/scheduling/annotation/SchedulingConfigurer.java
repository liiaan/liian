package org.springframework.scheduling.annotation;

import org.springframework.scheduling.config.ScheduledTaskRegistrar;

public abstract interface SchedulingConfigurer
{
  public abstract void configureTasks(ScheduledTaskRegistrar paramScheduledTaskRegistrar);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.annotation.SchedulingConfigurer
 * JD-Core Version:    0.6.1
 */