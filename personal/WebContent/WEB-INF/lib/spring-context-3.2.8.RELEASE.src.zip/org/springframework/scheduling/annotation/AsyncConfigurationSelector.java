/*    */ package org.springframework.scheduling.annotation;
/*    */ 
/*    */ import org.springframework.context.annotation.AdviceMode;
/*    */ import org.springframework.context.annotation.AdviceModeImportSelector;
/*    */ 
/*    */ public class AsyncConfigurationSelector extends AdviceModeImportSelector<EnableAsync>
/*    */ {
/*    */   public String[] selectImports(AdviceMode adviceMode)
/*    */   {
/* 41 */     switch (1.$SwitchMap$org$springframework$context$annotation$AdviceMode[adviceMode.ordinal()]) {
/*    */     case 1:
/* 43 */       return new String[] { ProxyAsyncConfiguration.class.getName() };
/*    */     case 2:
/* 45 */       return new String[] { "org.springframework.scheduling.aspectj.AspectJAsyncConfiguration" };
/*    */     }
/* 47 */     return null;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.annotation.AsyncConfigurationSelector
 * JD-Core Version:    0.6.1
 */