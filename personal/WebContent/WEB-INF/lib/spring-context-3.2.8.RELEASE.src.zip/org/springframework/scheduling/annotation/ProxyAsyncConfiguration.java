/*    */ package org.springframework.scheduling.annotation;
/*    */ 
/*    */ import org.springframework.context.annotation.Bean;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.Role;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.annotation.AnnotationUtils;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ @Configuration
/*    */ public class ProxyAsyncConfiguration extends AbstractAsyncConfiguration
/*    */ {
/*    */   @Bean(name={"org.springframework.context.annotation.internalAsyncAnnotationProcessor"})
/*    */   @Role(2)
/*    */   public AsyncAnnotationBeanPostProcessor asyncAdvisor()
/*    */   {
/* 44 */     Assert.notNull(this.enableAsync, "@EnableAsync annotation metadata was not injected");
/* 45 */     AsyncAnnotationBeanPostProcessor bpp = new AsyncAnnotationBeanPostProcessor();
/* 46 */     Class customAsyncAnnotation = this.enableAsync.getClass("annotation");
/* 47 */     if (customAsyncAnnotation != AnnotationUtils.getDefaultValue(EnableAsync.class, "annotation")) {
/* 48 */       bpp.setAsyncAnnotationType(customAsyncAnnotation);
/*    */     }
/* 50 */     if (this.executor != null) {
/* 51 */       bpp.setExecutor(this.executor);
/*    */     }
/* 53 */     bpp.setProxyTargetClass(this.enableAsync.getBoolean("proxyTargetClass"));
/* 54 */     bpp.setOrder(((Integer)this.enableAsync.getNumber("order")).intValue());
/* 55 */     return bpp;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.annotation.ProxyAsyncConfiguration
 * JD-Core Version:    0.6.1
 */