/*    */ package org.springframework.scheduling.annotation;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import java.util.concurrent.Executor;
/*    */ import org.springframework.beans.factory.annotation.Autowired;
/*    */ import org.springframework.context.annotation.Configuration;
/*    */ import org.springframework.context.annotation.ImportAware;
/*    */ import org.springframework.core.annotation.AnnotationAttributes;
/*    */ import org.springframework.core.type.AnnotationMetadata;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ 
/*    */ @Configuration
/*    */ public abstract class AbstractAsyncConfiguration
/*    */   implements ImportAware
/*    */ {
/*    */   protected AnnotationAttributes enableAsync;
/*    */   protected Executor executor;
/*    */ 
/*    */   public void setImportMetadata(AnnotationMetadata importMetadata)
/*    */   {
/* 47 */     this.enableAsync = AnnotationAttributes.fromMap(importMetadata.getAnnotationAttributes(EnableAsync.class.getName(), false));
/*    */ 
/* 49 */     Assert.notNull(this.enableAsync, "@EnableAsync is not present on importing class " + importMetadata.getClassName());
/*    */   }
/*    */ 
/*    */   @Autowired(required=false)
/*    */   void setConfigurers(Collection<AsyncConfigurer> configurers)
/*    */   {
/* 58 */     if (CollectionUtils.isEmpty(configurers)) {
/* 59 */       return;
/*    */     }
/* 61 */     if (configurers.size() > 1) {
/* 62 */       throw new IllegalStateException("Only one AsyncConfigurer may exist");
/*    */     }
/* 64 */     AsyncConfigurer configurer = (AsyncConfigurer)configurers.iterator().next();
/* 65 */     this.executor = configurer.getAsyncExecutor();
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.annotation.AbstractAsyncConfiguration
 * JD-Core Version:    0.6.1
 */