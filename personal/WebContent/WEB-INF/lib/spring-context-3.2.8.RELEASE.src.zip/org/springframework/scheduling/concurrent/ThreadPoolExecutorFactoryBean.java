/*     */ package org.springframework.scheduling.concurrent;
/*     */ 
/*     */ import java.util.concurrent.BlockingQueue;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.RejectedExecutionHandler;
/*     */ import java.util.concurrent.SynchronousQueue;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ 
/*     */ public class ThreadPoolExecutorFactoryBean extends ExecutorConfigurationSupport
/*     */   implements FactoryBean<ExecutorService>, InitializingBean, DisposableBean
/*     */ {
/*  56 */   private int corePoolSize = 1;
/*     */ 
/*  58 */   private int maxPoolSize = 2147483647;
/*     */ 
/*  60 */   private int keepAliveSeconds = 60;
/*     */ 
/*  62 */   private boolean allowCoreThreadTimeOut = false;
/*     */ 
/*  64 */   private int queueCapacity = 2147483647;
/*     */ 
/*  66 */   private boolean exposeUnconfigurableExecutor = false;
/*     */   private ExecutorService exposedExecutor;
/*     */ 
/*     */   public void setCorePoolSize(int corePoolSize)
/*     */   {
/*  76 */     this.corePoolSize = corePoolSize;
/*     */   }
/*     */ 
/*     */   public void setMaxPoolSize(int maxPoolSize)
/*     */   {
/*  84 */     this.maxPoolSize = maxPoolSize;
/*     */   }
/*     */ 
/*     */   public void setKeepAliveSeconds(int keepAliveSeconds)
/*     */   {
/*  92 */     this.keepAliveSeconds = keepAliveSeconds;
/*     */   }
/*     */ 
/*     */   public void setAllowCoreThreadTimeOut(boolean allowCoreThreadTimeOut)
/*     */   {
/* 105 */     this.allowCoreThreadTimeOut = allowCoreThreadTimeOut;
/*     */   }
/*     */ 
/*     */   public void setQueueCapacity(int queueCapacity)
/*     */   {
/* 117 */     this.queueCapacity = queueCapacity;
/*     */   }
/*     */ 
/*     */   public void setExposeUnconfigurableExecutor(boolean exposeUnconfigurableExecutor)
/*     */   {
/* 129 */     this.exposeUnconfigurableExecutor = exposeUnconfigurableExecutor;
/*     */   }
/*     */ 
/*     */   protected ExecutorService initializeExecutor(ThreadFactory threadFactory, RejectedExecutionHandler rejectedExecutionHandler)
/*     */   {
/* 136 */     BlockingQueue queue = createQueue(this.queueCapacity);
/* 137 */     ThreadPoolExecutor executor = createExecutor(this.corePoolSize, this.maxPoolSize, this.keepAliveSeconds, queue, threadFactory, rejectedExecutionHandler);
/*     */ 
/* 139 */     if (this.allowCoreThreadTimeOut) {
/* 140 */       executor.allowCoreThreadTimeOut(true);
/*     */     }
/*     */ 
/* 144 */     this.exposedExecutor = (this.exposeUnconfigurableExecutor ? Executors.unconfigurableExecutorService(executor) : executor);
/*     */ 
/* 147 */     return executor;
/*     */   }
/*     */ 
/*     */   protected ThreadPoolExecutor createExecutor(int corePoolSize, int maxPoolSize, int keepAliveSeconds, BlockingQueue<Runnable> queue, ThreadFactory threadFactory, RejectedExecutionHandler rejectedExecutionHandler)
/*     */   {
/* 167 */     return new ThreadPoolExecutor(corePoolSize, maxPoolSize, keepAliveSeconds, TimeUnit.SECONDS, queue, threadFactory, rejectedExecutionHandler);
/*     */   }
/*     */ 
/*     */   protected BlockingQueue<Runnable> createQueue(int queueCapacity)
/*     */   {
/* 181 */     if (queueCapacity > 0) {
/* 182 */       return new LinkedBlockingQueue(queueCapacity);
/*     */     }
/*     */ 
/* 185 */     return new SynchronousQueue();
/*     */   }
/*     */ 
/*     */   public ExecutorService getObject()
/*     */     throws Exception
/*     */   {
/* 191 */     return this.exposedExecutor;
/*     */   }
/*     */ 
/*     */   public Class<? extends ExecutorService> getObjectType() {
/* 195 */     return this.exposedExecutor != null ? this.exposedExecutor.getClass() : ExecutorService.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton() {
/* 199 */     return true;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.concurrent.ThreadPoolExecutorFactoryBean
 * JD-Core Version:    0.6.1
 */