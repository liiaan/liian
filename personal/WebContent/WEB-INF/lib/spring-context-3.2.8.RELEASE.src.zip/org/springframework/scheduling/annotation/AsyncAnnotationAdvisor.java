/*     */ package org.springframework.scheduling.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.Executor;
/*     */ import org.aopalliance.aop.Advice;
/*     */ import org.springframework.aop.Pointcut;
/*     */ import org.springframework.aop.support.AbstractPointcutAdvisor;
/*     */ import org.springframework.aop.support.ComposablePointcut;
/*     */ import org.springframework.aop.support.annotation.AnnotationMatchingPointcut;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.core.task.SimpleAsyncTaskExecutor;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class AsyncAnnotationAdvisor extends AbstractPointcutAdvisor
/*     */   implements BeanFactoryAware
/*     */ {
/*     */   private Advice advice;
/*     */   private Pointcut pointcut;
/*     */ 
/*     */   public AsyncAnnotationAdvisor()
/*     */   {
/*  65 */     this(new SimpleAsyncTaskExecutor());
/*     */   }
/*     */ 
/*     */   public AsyncAnnotationAdvisor(Executor executor)
/*     */   {
/*  74 */     Set asyncAnnotationTypes = new LinkedHashSet(2);
/*  75 */     asyncAnnotationTypes.add(Async.class);
/*  76 */     ClassLoader cl = AsyncAnnotationAdvisor.class.getClassLoader();
/*     */     try {
/*  78 */       asyncAnnotationTypes.add(cl.loadClass("javax.ejb.Asynchronous"));
/*     */     }
/*     */     catch (ClassNotFoundException ex)
/*     */     {
/*     */     }
/*  83 */     this.advice = buildAdvice(executor);
/*  84 */     this.pointcut = buildPointcut(asyncAnnotationTypes);
/*     */   }
/*     */ 
/*     */   public void setTaskExecutor(Executor executor)
/*     */   {
/*  92 */     this.advice = buildAdvice(executor);
/*     */   }
/*     */ 
/*     */   public void setAsyncAnnotationType(Class<? extends Annotation> asyncAnnotationType)
/*     */   {
/* 105 */     Assert.notNull(asyncAnnotationType, "'asyncAnnotationType' must not be null");
/* 106 */     Set asyncAnnotationTypes = new HashSet();
/* 107 */     asyncAnnotationTypes.add(asyncAnnotationType);
/* 108 */     this.pointcut = buildPointcut(asyncAnnotationTypes);
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/* 115 */     if ((this.advice instanceof BeanFactoryAware))
/* 116 */       ((BeanFactoryAware)this.advice).setBeanFactory(beanFactory);
/*     */   }
/*     */ 
/*     */   public Advice getAdvice()
/*     */   {
/* 122 */     return this.advice;
/*     */   }
/*     */ 
/*     */   public Pointcut getPointcut() {
/* 126 */     return this.pointcut;
/*     */   }
/*     */ 
/*     */   protected Advice buildAdvice(Executor executor)
/*     */   {
/* 131 */     return new AnnotationAsyncExecutionInterceptor(executor);
/*     */   }
/*     */ 
/*     */   protected Pointcut buildPointcut(Set<Class<? extends Annotation>> asyncAnnotationTypes)
/*     */   {
/* 140 */     ComposablePointcut result = null;
/* 141 */     for (Class asyncAnnotationType : asyncAnnotationTypes) {
/* 142 */       Pointcut cpc = new AnnotationMatchingPointcut(asyncAnnotationType, true);
/* 143 */       Pointcut mpc = AnnotationMatchingPointcut.forMethodAnnotation(asyncAnnotationType);
/* 144 */       if (result == null) {
/* 145 */         result = new ComposablePointcut(cpc).union(mpc);
/*     */       }
/*     */       else {
/* 148 */         result.union(cpc).union(mpc);
/*     */       }
/*     */     }
/* 151 */     return result;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.annotation.AsyncAnnotationAdvisor
 * JD-Core Version:    0.6.1
 */