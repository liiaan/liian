/*     */ package org.springframework.scheduling.concurrent;
/*     */ 
/*     */ import java.util.Date;
/*     */ import java.util.concurrent.Executor;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.springframework.core.task.TaskRejectedException;
/*     */ import org.springframework.scheduling.TaskScheduler;
/*     */ import org.springframework.scheduling.Trigger;
/*     */ import org.springframework.scheduling.support.TaskUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ErrorHandler;
/*     */ 
/*     */ public class ConcurrentTaskScheduler extends ConcurrentTaskExecutor
/*     */   implements TaskScheduler
/*     */ {
/*     */   private volatile ScheduledExecutorService scheduledExecutor;
/*     */   private volatile ErrorHandler errorHandler;
/*     */ 
/*     */   public ConcurrentTaskScheduler()
/*     */   {
/*  68 */     setScheduledExecutor(null);
/*     */   }
/*     */ 
/*     */   public ConcurrentTaskScheduler(ScheduledExecutorService scheduledExecutor)
/*     */   {
/*  79 */     super(scheduledExecutor);
/*  80 */     setScheduledExecutor(scheduledExecutor);
/*     */   }
/*     */ 
/*     */   public ConcurrentTaskScheduler(Executor concurrentExecutor, ScheduledExecutorService scheduledExecutor)
/*     */   {
/*  92 */     super(concurrentExecutor);
/*  93 */     setScheduledExecutor(scheduledExecutor);
/*     */   }
/*     */ 
/*     */   public final void setScheduledExecutor(ScheduledExecutorService scheduledExecutor)
/*     */   {
/* 106 */     this.scheduledExecutor = (scheduledExecutor != null ? scheduledExecutor : Executors.newSingleThreadScheduledExecutor());
/*     */   }
/*     */ 
/*     */   public void setErrorHandler(ErrorHandler errorHandler)
/*     */   {
/* 114 */     Assert.notNull(errorHandler, "'errorHandler' must not be null");
/* 115 */     this.errorHandler = errorHandler;
/*     */   }
/*     */ 
/*     */   public ScheduledFuture schedule(Runnable task, Trigger trigger)
/*     */   {
/*     */     try {
/* 121 */       ErrorHandler errorHandler = this.errorHandler != null ? this.errorHandler : TaskUtils.getDefaultErrorHandler(true);
/*     */ 
/* 123 */       return new ReschedulingRunnable(task, trigger, this.scheduledExecutor, errorHandler).schedule();
/*     */     }
/*     */     catch (RejectedExecutionException ex) {
/* 126 */       throw new TaskRejectedException("Executor [" + this.scheduledExecutor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ScheduledFuture schedule(Runnable task, Date startTime) {
/* 131 */     long initialDelay = startTime.getTime() - System.currentTimeMillis();
/*     */     try {
/* 133 */       return this.scheduledExecutor.schedule(errorHandlingTask(task, false), initialDelay, TimeUnit.MILLISECONDS);
/*     */     }
/*     */     catch (RejectedExecutionException ex)
/*     */     {
/* 137 */       throw new TaskRejectedException("Executor [" + this.scheduledExecutor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ScheduledFuture scheduleAtFixedRate(Runnable task, Date startTime, long period) {
/* 142 */     long initialDelay = startTime.getTime() - System.currentTimeMillis();
/*     */     try {
/* 144 */       return this.scheduledExecutor.scheduleAtFixedRate(errorHandlingTask(task, true), initialDelay, period, TimeUnit.MILLISECONDS);
/*     */     }
/*     */     catch (RejectedExecutionException ex)
/*     */     {
/* 148 */       throw new TaskRejectedException("Executor [" + this.scheduledExecutor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ScheduledFuture scheduleAtFixedRate(Runnable task, long period) {
/*     */     try {
/* 154 */       return this.scheduledExecutor.scheduleAtFixedRate(errorHandlingTask(task, true), 0L, period, TimeUnit.MILLISECONDS);
/*     */     }
/*     */     catch (RejectedExecutionException ex)
/*     */     {
/* 158 */       throw new TaskRejectedException("Executor [" + this.scheduledExecutor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ScheduledFuture scheduleWithFixedDelay(Runnable task, Date startTime, long delay) {
/* 163 */     long initialDelay = startTime.getTime() - System.currentTimeMillis();
/*     */     try {
/* 165 */       return this.scheduledExecutor.scheduleWithFixedDelay(errorHandlingTask(task, true), initialDelay, delay, TimeUnit.MILLISECONDS);
/*     */     }
/*     */     catch (RejectedExecutionException ex)
/*     */     {
/* 169 */       throw new TaskRejectedException("Executor [" + this.scheduledExecutor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ScheduledFuture scheduleWithFixedDelay(Runnable task, long delay) {
/*     */     try {
/* 175 */       return this.scheduledExecutor.scheduleWithFixedDelay(errorHandlingTask(task, true), 0L, delay, TimeUnit.MILLISECONDS);
/*     */     }
/*     */     catch (RejectedExecutionException ex)
/*     */     {
/* 179 */       throw new TaskRejectedException("Executor [" + this.scheduledExecutor + "] did not accept task: " + task, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Runnable errorHandlingTask(Runnable task, boolean isRepeatingTask) {
/* 184 */     return TaskUtils.decorateTaskWithErrorHandler(task, this.errorHandler, isRepeatingTask);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.concurrent.ConcurrentTaskScheduler
 * JD-Core Version:    0.6.1
 */