/*    */ package org.springframework.scheduling.config;
/*    */ 
/*    */ import org.springframework.beans.factory.xml.NamespaceHandlerSupport;
/*    */ 
/*    */ public class TaskNamespaceHandler extends NamespaceHandlerSupport
/*    */ {
/*    */   public void init()
/*    */   {
/* 30 */     registerBeanDefinitionParser("annotation-driven", new AnnotationDrivenBeanDefinitionParser());
/* 31 */     registerBeanDefinitionParser("executor", new ExecutorBeanDefinitionParser());
/* 32 */     registerBeanDefinitionParser("scheduled-tasks", new ScheduledTasksBeanDefinitionParser());
/* 33 */     registerBeanDefinitionParser("scheduler", new SchedulerBeanDefinitionParser());
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.config.TaskNamespaceHandler
 * JD-Core Version:    0.6.1
 */