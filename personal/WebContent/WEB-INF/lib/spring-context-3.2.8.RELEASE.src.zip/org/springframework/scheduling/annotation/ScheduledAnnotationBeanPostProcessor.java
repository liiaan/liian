/*     */ package org.springframework.scheduling.annotation;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.config.BeanPostProcessor;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.ApplicationListener;
/*     */ import org.springframework.context.EmbeddedValueResolverAware;
/*     */ import org.springframework.context.event.ContextRefreshedEvent;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.scheduling.TaskScheduler;
/*     */ import org.springframework.scheduling.config.CronTask;
/*     */ import org.springframework.scheduling.config.IntervalTask;
/*     */ import org.springframework.scheduling.config.ScheduledTaskRegistrar;
/*     */ import org.springframework.scheduling.support.ScheduledMethodRunnable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.ReflectionUtils.MethodCallback;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ public class ScheduledAnnotationBeanPostProcessor
/*     */   implements BeanPostProcessor, Ordered, EmbeddedValueResolverAware, ApplicationContextAware, ApplicationListener<ContextRefreshedEvent>, DisposableBean
/*     */ {
/*     */   private Object scheduler;
/*     */   private StringValueResolver embeddedValueResolver;
/*     */   private ApplicationContext applicationContext;
/*  79 */   private final ScheduledTaskRegistrar registrar = new ScheduledTaskRegistrar();
/*     */ 
/*     */   public void setScheduler(Object scheduler)
/*     */   {
/*  88 */     this.scheduler = scheduler;
/*     */   }
/*     */ 
/*     */   public void setEmbeddedValueResolver(StringValueResolver resolver) {
/*  92 */     this.embeddedValueResolver = resolver;
/*     */   }
/*     */ 
/*     */   public void setApplicationContext(ApplicationContext applicationContext) {
/*  96 */     this.applicationContext = applicationContext;
/*     */   }
/*     */ 
/*     */   public int getOrder() {
/* 100 */     return 2147483647;
/*     */   }
/*     */ 
/*     */   public Object postProcessBeforeInitialization(Object bean, String beanName) {
/* 104 */     return bean;
/*     */   }
/*     */ 
/*     */   public Object postProcessAfterInitialization(final Object bean, String beanName) {
/* 108 */     final Class targetClass = AopUtils.getTargetClass(bean);
/* 109 */     ReflectionUtils.doWithMethods(targetClass, new ReflectionUtils.MethodCallback() {
/*     */       public void doWith(Method method) throws IllegalArgumentException, IllegalAccessException {
/* 111 */         Scheduled annotation = (Scheduled)AnnotationUtils.getAnnotation(method, Scheduled.class);
/* 112 */         if (annotation != null)
/*     */           try {
/* 114 */             Assert.isTrue(Void.TYPE.equals(method.getReturnType()), "Only void-returning methods may be annotated with @Scheduled");
/*     */ 
/* 116 */             Assert.isTrue(method.getParameterTypes().length == 0, "Only no-arg methods may be annotated with @Scheduled");
/*     */ 
/* 118 */             if (AopUtils.isJdkDynamicProxy(bean))
/*     */             {
/*     */               try
/*     */               {
/* 122 */                 method = bean.getClass().getMethod(method.getName(), method.getParameterTypes());
/*     */               }
/*     */               catch (SecurityException ex) {
/* 125 */                 ReflectionUtils.handleReflectionException(ex);
/*     */               }
/*     */               catch (NoSuchMethodException ex) {
/* 128 */                 throw new IllegalStateException(String.format("@Scheduled method '%s' found on bean target class '%s', but not found in any interface(s) for bean JDK proxy. Either pull the method up to an interface or switch to subclass (CGLIB) proxies by setting proxy-target-class/proxyTargetClass attribute to 'true'", new Object[] { method.getName(), targetClass.getSimpleName() }));
/*     */               }
/*     */ 
/*     */             }
/*     */ 
/* 136 */             Runnable runnable = new ScheduledMethodRunnable(bean, method);
/* 137 */             boolean processedSchedule = false;
/* 138 */             String errorMessage = "Exactly one of the 'cron', 'fixedDelay(String)', or 'fixedRate(String)' attributes is required";
/*     */ 
/* 140 */             long initialDelay = annotation.initialDelay();
/* 141 */             String initialDelayString = annotation.initialDelayString();
/* 142 */             if (!"".equals(initialDelayString)) {
/* 143 */               Assert.isTrue(initialDelay < 0L, "Specify 'initialDelay' or 'initialDelayString', not both");
/* 144 */               if (ScheduledAnnotationBeanPostProcessor.this.embeddedValueResolver != null)
/* 145 */                 initialDelayString = ScheduledAnnotationBeanPostProcessor.this.embeddedValueResolver.resolveStringValue(initialDelayString);
/*     */               try
/*     */               {
/* 148 */                 initialDelay = Integer.parseInt(initialDelayString);
/*     */               }
/*     */               catch (NumberFormatException ex) {
/* 151 */                 throw new IllegalArgumentException("Invalid initialDelayString value \"" + initialDelayString + "\" - cannot parse into integer");
/*     */               }
/*     */ 
/*     */             }
/*     */ 
/* 156 */             String cron = annotation.cron();
/* 157 */             if (!"".equals(cron)) {
/* 158 */               Assert.isTrue(initialDelay == -1L, "'initialDelay' not supported for cron triggers");
/* 159 */               processedSchedule = true;
/* 160 */               if (ScheduledAnnotationBeanPostProcessor.this.embeddedValueResolver != null) {
/* 161 */                 cron = ScheduledAnnotationBeanPostProcessor.this.embeddedValueResolver.resolveStringValue(cron);
/*     */               }
/* 163 */               ScheduledAnnotationBeanPostProcessor.this.registrar.addCronTask(new CronTask(runnable, cron));
/*     */             }
/*     */ 
/* 166 */             if (initialDelay < 0L) {
/* 167 */               initialDelay = 0L;
/*     */             }
/*     */ 
/* 170 */             long fixedDelay = annotation.fixedDelay();
/* 171 */             if (fixedDelay >= 0L) {
/* 172 */               Assert.isTrue(!processedSchedule, errorMessage);
/* 173 */               processedSchedule = true;
/* 174 */               ScheduledAnnotationBeanPostProcessor.this.registrar.addFixedDelayTask(new IntervalTask(runnable, fixedDelay, initialDelay));
/*     */             }
/* 176 */             String fixedDelayString = annotation.fixedDelayString();
/* 177 */             if (!"".equals(fixedDelayString)) {
/* 178 */               Assert.isTrue(!processedSchedule, errorMessage);
/* 179 */               processedSchedule = true;
/* 180 */               if (ScheduledAnnotationBeanPostProcessor.this.embeddedValueResolver != null)
/* 181 */                 fixedDelayString = ScheduledAnnotationBeanPostProcessor.this.embeddedValueResolver.resolveStringValue(fixedDelayString);
/*     */               try
/*     */               {
/* 184 */                 fixedDelay = Integer.parseInt(fixedDelayString);
/*     */               }
/*     */               catch (NumberFormatException ex) {
/* 187 */                 throw new IllegalArgumentException("Invalid fixedDelayString value \"" + fixedDelayString + "\" - cannot parse into integer");
/*     */               }
/*     */ 
/* 190 */               ScheduledAnnotationBeanPostProcessor.this.registrar.addFixedDelayTask(new IntervalTask(runnable, fixedDelay, initialDelay));
/*     */             }
/*     */ 
/* 193 */             long fixedRate = annotation.fixedRate();
/* 194 */             if (fixedRate >= 0L) {
/* 195 */               Assert.isTrue(!processedSchedule, errorMessage);
/* 196 */               processedSchedule = true;
/* 197 */               ScheduledAnnotationBeanPostProcessor.this.registrar.addFixedRateTask(new IntervalTask(runnable, fixedRate, initialDelay));
/*     */             }
/* 199 */             String fixedRateString = annotation.fixedRateString();
/* 200 */             if (!"".equals(fixedRateString)) {
/* 201 */               Assert.isTrue(!processedSchedule, errorMessage);
/* 202 */               processedSchedule = true;
/* 203 */               if (ScheduledAnnotationBeanPostProcessor.this.embeddedValueResolver != null)
/* 204 */                 fixedRateString = ScheduledAnnotationBeanPostProcessor.this.embeddedValueResolver.resolveStringValue(fixedRateString);
/*     */               try
/*     */               {
/* 207 */                 fixedRate = Integer.parseInt(fixedRateString);
/*     */               }
/*     */               catch (NumberFormatException ex) {
/* 210 */                 throw new IllegalArgumentException("Invalid fixedRateString value \"" + fixedRateString + "\" - cannot parse into integer");
/*     */               }
/*     */ 
/* 213 */               ScheduledAnnotationBeanPostProcessor.this.registrar.addFixedRateTask(new IntervalTask(runnable, fixedRate, initialDelay));
/*     */             }
/*     */ 
/* 216 */             Assert.isTrue(processedSchedule, errorMessage);
/*     */           }
/*     */           catch (IllegalArgumentException ex) {
/* 219 */             throw new IllegalStateException("Encountered invalid @Scheduled method '" + method.getName() + "': " + ex.getMessage());
/*     */           }
/*     */       }
/*     */     });
/* 225 */     return bean;
/*     */   }
/*     */ 
/*     */   public void onApplicationEvent(ContextRefreshedEvent event) {
/* 229 */     if (event.getApplicationContext() != this.applicationContext) {
/* 230 */       return;
/*     */     }
/* 232 */     Map configurers = this.applicationContext.getBeansOfType(SchedulingConfigurer.class);
/*     */ 
/* 234 */     if (this.scheduler != null) {
/* 235 */       this.registrar.setScheduler(this.scheduler);
/*     */     }
/* 237 */     for (SchedulingConfigurer configurer : configurers.values()) {
/* 238 */       configurer.configureTasks(this.registrar);
/*     */     }
/* 240 */     if ((this.registrar.hasTasks()) && (this.registrar.getScheduler() == null)) {
/* 241 */       Map schedulers = new HashMap();
/* 242 */       schedulers.putAll(this.applicationContext.getBeansOfType(TaskScheduler.class));
/* 243 */       schedulers.putAll(this.applicationContext.getBeansOfType(ScheduledExecutorService.class));
/* 244 */       if (schedulers.size() != 0)
/*     */       {
/* 247 */         if (schedulers.size() == 1) {
/* 248 */           this.registrar.setScheduler(schedulers.values().iterator().next());
/*     */         }
/* 250 */         else if (schedulers.size() >= 2) {
/* 251 */           throw new IllegalStateException("More than one TaskScheduler and/or ScheduledExecutorService  exist within the context. Remove all but one of the beans; or implement the SchedulingConfigurer interface and call ScheduledTaskRegistrar#setScheduler explicitly within the configureTasks() callback. Found the following beans: " + schedulers.keySet());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 259 */     this.registrar.afterPropertiesSet();
/*     */   }
/*     */ 
/*     */   public void destroy() throws Exception {
/* 263 */     if (this.registrar != null)
/* 264 */       this.registrar.destroy();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.annotation.ScheduledAnnotationBeanPostProcessor
 * JD-Core Version:    0.6.1
 */