/*     */ package org.springframework.format.datetime.joda;
/*     */ 
/*     */ import java.util.Calendar;
/*     */ import java.util.Collections;
/*     */ import java.util.Date;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.joda.time.DateTime;
/*     */ import org.joda.time.LocalDate;
/*     */ import org.joda.time.LocalDateTime;
/*     */ import org.joda.time.LocalTime;
/*     */ import org.joda.time.ReadableInstant;
/*     */ import org.joda.time.ReadablePartial;
/*     */ import org.joda.time.format.DateTimeFormatter;
/*     */ import org.springframework.context.EmbeddedValueResolverAware;
/*     */ import org.springframework.format.AnnotationFormatterFactory;
/*     */ import org.springframework.format.Parser;
/*     */ import org.springframework.format.Printer;
/*     */ import org.springframework.format.annotation.DateTimeFormat;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ public class JodaDateTimeFormatAnnotationFormatterFactory
/*     */   implements AnnotationFormatterFactory<DateTimeFormat>, EmbeddedValueResolverAware
/*     */ {
/*  67 */   private static final Set<Class<?>> FIELD_TYPES = Collections.unmodifiableSet(fieldTypes);
/*     */   private StringValueResolver embeddedValueResolver;
/*     */ 
/*     */   public void setEmbeddedValueResolver(StringValueResolver resolver)
/*     */   {
/*  75 */     this.embeddedValueResolver = resolver;
/*     */   }
/*     */ 
/*     */   protected String resolveEmbeddedValue(String value) {
/*  79 */     return this.embeddedValueResolver != null ? this.embeddedValueResolver.resolveStringValue(value) : value;
/*     */   }
/*     */ 
/*     */   public final Set<Class<?>> getFieldTypes()
/*     */   {
/*  84 */     return FIELD_TYPES;
/*     */   }
/*     */ 
/*     */   public Printer<?> getPrinter(DateTimeFormat annotation, Class<?> fieldType) {
/*  88 */     DateTimeFormatter formatter = getFormatter(annotation, fieldType);
/*  89 */     if (ReadablePartial.class.isAssignableFrom(fieldType)) {
/*  90 */       return new ReadablePartialPrinter(formatter);
/*     */     }
/*  92 */     if ((ReadableInstant.class.isAssignableFrom(fieldType)) || (Calendar.class.isAssignableFrom(fieldType)))
/*     */     {
/*  94 */       return new ReadableInstantPrinter(formatter);
/*     */     }
/*     */ 
/*  98 */     return new MillisecondInstantPrinter(formatter);
/*     */   }
/*     */ 
/*     */   public Parser<DateTime> getParser(DateTimeFormat annotation, Class<?> fieldType)
/*     */   {
/* 103 */     return new DateTimeParser(getFormatter(annotation, fieldType));
/*     */   }
/*     */ 
/*     */   protected DateTimeFormatter getFormatter(DateTimeFormat annotation, Class<?> fieldType)
/*     */   {
/* 114 */     DateTimeFormatterFactory factory = new DateTimeFormatterFactory();
/* 115 */     factory.setStyle(resolveEmbeddedValue(annotation.style()));
/* 116 */     factory.setIso(annotation.iso());
/* 117 */     factory.setPattern(resolveEmbeddedValue(annotation.pattern()));
/* 118 */     return factory.createDateTimeFormatter();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  59 */     Set fieldTypes = new HashSet(8);
/*  60 */     fieldTypes.add(ReadableInstant.class);
/*  61 */     fieldTypes.add(LocalDate.class);
/*  62 */     fieldTypes.add(LocalTime.class);
/*  63 */     fieldTypes.add(LocalDateTime.class);
/*  64 */     fieldTypes.add(Date.class);
/*  65 */     fieldTypes.add(Calendar.class);
/*  66 */     fieldTypes.add(Long.class);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.joda.JodaDateTimeFormatAnnotationFormatterFactory
 * JD-Core Version:    0.6.1
 */