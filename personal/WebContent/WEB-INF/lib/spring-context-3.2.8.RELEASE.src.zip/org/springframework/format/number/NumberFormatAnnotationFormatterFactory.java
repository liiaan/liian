/*    */ package org.springframework.format.number;
/*    */ 
/*    */ import java.math.BigDecimal;
/*    */ import java.math.BigInteger;
/*    */ import java.util.Collections;
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import org.springframework.context.EmbeddedValueResolverAware;
/*    */ import org.springframework.format.AnnotationFormatterFactory;
/*    */ import org.springframework.format.Formatter;
/*    */ import org.springframework.format.Parser;
/*    */ import org.springframework.format.Printer;
/*    */ import org.springframework.format.annotation.NumberFormat;
/*    */ import org.springframework.format.annotation.NumberFormat.Style;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.util.StringValueResolver;
/*    */ 
/*    */ public class NumberFormatAnnotationFormatterFactory
/*    */   implements AnnotationFormatterFactory<NumberFormat>, EmbeddedValueResolverAware
/*    */ {
/*    */   private final Set<Class<?>> fieldTypes;
/*    */   private StringValueResolver embeddedValueResolver;
/*    */ 
/*    */   public NumberFormatAnnotationFormatterFactory()
/*    */   {
/* 51 */     Set rawFieldTypes = new HashSet(7);
/* 52 */     rawFieldTypes.add(Short.class);
/* 53 */     rawFieldTypes.add(Integer.class);
/* 54 */     rawFieldTypes.add(Long.class);
/* 55 */     rawFieldTypes.add(Float.class);
/* 56 */     rawFieldTypes.add(Double.class);
/* 57 */     rawFieldTypes.add(BigDecimal.class);
/* 58 */     rawFieldTypes.add(BigInteger.class);
/* 59 */     this.fieldTypes = Collections.unmodifiableSet(rawFieldTypes);
/*    */   }
/*    */ 
/*    */   public final Set<Class<?>> getFieldTypes() {
/* 63 */     return this.fieldTypes;
/*    */   }
/*    */ 
/*    */   public void setEmbeddedValueResolver(StringValueResolver resolver)
/*    */   {
/* 68 */     this.embeddedValueResolver = resolver;
/*    */   }
/*    */ 
/*    */   protected String resolveEmbeddedValue(String value) {
/* 72 */     return this.embeddedValueResolver != null ? this.embeddedValueResolver.resolveStringValue(value) : value;
/*    */   }
/*    */ 
/*    */   public Printer<Number> getPrinter(NumberFormat annotation, Class<?> fieldType)
/*    */   {
/* 77 */     return configureFormatterFrom(annotation);
/*    */   }
/*    */ 
/*    */   public Parser<Number> getParser(NumberFormat annotation, Class<?> fieldType) {
/* 81 */     return configureFormatterFrom(annotation);
/*    */   }
/*    */ 
/*    */   private Formatter<Number> configureFormatterFrom(NumberFormat annotation)
/*    */   {
/* 86 */     if (StringUtils.hasLength(annotation.pattern())) {
/* 87 */       return new NumberFormatter(resolveEmbeddedValue(annotation.pattern()));
/*    */     }
/*    */ 
/* 90 */     NumberFormat.Style style = annotation.style();
/* 91 */     if (style == NumberFormat.Style.PERCENT) {
/* 92 */       return new PercentFormatter();
/*    */     }
/* 94 */     if (style == NumberFormat.Style.CURRENCY) {
/* 95 */       return new CurrencyFormatter();
/*    */     }
/*    */ 
/* 98 */     return new NumberFormatter();
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.format.number.NumberFormatAnnotationFormatterFactory
 * JD-Core Version:    0.6.1
 */