package org.springframework.format;

import java.util.Locale;

public abstract interface Printer<T>
{
  public abstract String print(T paramT, Locale paramLocale);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.format.Printer
 * JD-Core Version:    0.6.1
 */