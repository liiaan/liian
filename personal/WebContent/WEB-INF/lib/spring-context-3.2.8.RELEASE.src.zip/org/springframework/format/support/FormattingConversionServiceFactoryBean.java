/*     */ package org.springframework.format.support;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.EmbeddedValueResolverAware;
/*     */ import org.springframework.core.convert.support.ConversionServiceFactory;
/*     */ import org.springframework.format.AnnotationFormatterFactory;
/*     */ import org.springframework.format.Formatter;
/*     */ import org.springframework.format.FormatterRegistrar;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ public class FormattingConversionServiceFactoryBean
/*     */   implements FactoryBean<FormattingConversionService>, EmbeddedValueResolverAware, InitializingBean
/*     */ {
/*     */   private Set<?> converters;
/*     */   private Set<?> formatters;
/*     */   private Set<FormatterRegistrar> formatterRegistrars;
/*  72 */   private boolean registerDefaultFormatters = true;
/*     */   private StringValueResolver embeddedValueResolver;
/*     */   private FormattingConversionService conversionService;
/*     */ 
/*     */   public void setConverters(Set<?> converters)
/*     */   {
/*  87 */     this.converters = converters;
/*     */   }
/*     */ 
/*     */   public void setFormatters(Set<?> formatters)
/*     */   {
/*  95 */     this.formatters = formatters;
/*     */   }
/*     */ 
/*     */   public void setFormatterRegistrars(Set<FormatterRegistrar> formatterRegistrars)
/*     */   {
/* 113 */     this.formatterRegistrars = formatterRegistrars;
/*     */   }
/*     */ 
/*     */   public void setRegisterDefaultFormatters(boolean registerDefaultFormatters)
/*     */   {
/* 124 */     this.registerDefaultFormatters = registerDefaultFormatters;
/*     */   }
/*     */ 
/*     */   public void setEmbeddedValueResolver(StringValueResolver embeddedValueResolver) {
/* 128 */     this.embeddedValueResolver = embeddedValueResolver;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 133 */     this.conversionService = new DefaultFormattingConversionService(this.embeddedValueResolver, this.registerDefaultFormatters);
/* 134 */     ConversionServiceFactory.registerConverters(this.converters, this.conversionService);
/* 135 */     registerFormatters();
/*     */   }
/*     */ 
/*     */   private void registerFormatters()
/*     */   {
/*     */     Iterator i$;
/* 139 */     if (this.formatters != null) {
/* 140 */       for (i$ = this.formatters.iterator(); i$.hasNext(); ) { Object formatter = i$.next();
/* 141 */         if ((formatter instanceof Formatter)) {
/* 142 */           this.conversionService.addFormatter((Formatter)formatter);
/*     */         }
/* 144 */         else if ((formatter instanceof AnnotationFormatterFactory)) {
/* 145 */           this.conversionService.addFormatterForFieldAnnotation((AnnotationFormatterFactory)formatter);
/*     */         }
/*     */         else {
/* 148 */           throw new IllegalArgumentException("Custom formatters must be implementations of Formatter or AnnotationFormatterFactory");
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 153 */     if (this.formatterRegistrars != null) {
/* 154 */       for (FormatterRegistrar registrar : this.formatterRegistrars) {
/* 155 */         registrar.registerFormatters(this.conversionService);
/*     */       }
/*     */     }
/* 158 */     installFormatters(this.conversionService);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   protected void installFormatters(FormatterRegistry registry)
/*     */   {
/*     */   }
/*     */ 
/*     */   public FormattingConversionService getObject()
/*     */   {
/* 175 */     return this.conversionService;
/*     */   }
/*     */ 
/*     */   public Class<? extends FormattingConversionService> getObjectType() {
/* 179 */     return FormattingConversionService.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton() {
/* 183 */     return true;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.format.support.FormattingConversionServiceFactoryBean
 * JD-Core Version:    0.6.1
 */