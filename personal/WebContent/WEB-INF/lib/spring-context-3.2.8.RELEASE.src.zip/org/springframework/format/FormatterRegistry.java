package org.springframework.format;

import java.lang.annotation.Annotation;
import org.springframework.core.convert.converter.ConverterRegistry;

public abstract interface FormatterRegistry extends ConverterRegistry
{
  public abstract void addFormatter(Formatter<?> paramFormatter);

  public abstract void addFormatterForFieldType(Class<?> paramClass, Formatter<?> paramFormatter);

  public abstract void addFormatterForFieldType(Class<?> paramClass, Printer<?> paramPrinter, Parser<?> paramParser);

  public abstract void addFormatterForFieldAnnotation(AnnotationFormatterFactory<? extends Annotation> paramAnnotationFormatterFactory);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.format.FormatterRegistry
 * JD-Core Version:    0.6.1
 */