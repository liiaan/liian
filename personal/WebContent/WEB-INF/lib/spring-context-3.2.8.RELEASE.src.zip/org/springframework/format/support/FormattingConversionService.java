/*     */ package org.springframework.format.support;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.text.ParseException;
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.springframework.context.EmbeddedValueResolverAware;
/*     */ import org.springframework.context.i18n.LocaleContextHolder;
/*     */ import org.springframework.core.GenericTypeResolver;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.core.convert.TypeDescriptor;
/*     */ import org.springframework.core.convert.converter.ConditionalGenericConverter;
/*     */ import org.springframework.core.convert.converter.GenericConverter;
/*     */ import org.springframework.core.convert.converter.GenericConverter.ConvertiblePair;
/*     */ import org.springframework.core.convert.support.GenericConversionService;
/*     */ import org.springframework.format.AnnotationFormatterFactory;
/*     */ import org.springframework.format.Formatter;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.format.Parser;
/*     */ import org.springframework.format.Printer;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ public class FormattingConversionService extends GenericConversionService
/*     */   implements FormatterRegistry, EmbeddedValueResolverAware
/*     */ {
/*     */   private StringValueResolver embeddedValueResolver;
/*     */   private final Map<AnnotationConverterKey, GenericConverter> cachedPrinters;
/*     */   private final Map<AnnotationConverterKey, GenericConverter> cachedParsers;
/*     */ 
/*     */   public FormattingConversionService()
/*     */   {
/*  55 */     this.cachedPrinters = new ConcurrentHashMap(64);
/*     */ 
/*  58 */     this.cachedParsers = new ConcurrentHashMap(64);
/*     */   }
/*     */ 
/*     */   public void setEmbeddedValueResolver(StringValueResolver resolver)
/*     */   {
/*  63 */     this.embeddedValueResolver = resolver;
/*     */   }
/*     */ 
/*     */   public void addFormatter(Formatter<?> formatter)
/*     */   {
/*  68 */     Class fieldType = GenericTypeResolver.resolveTypeArgument(formatter.getClass(), Formatter.class);
/*  69 */     if (fieldType == null) {
/*  70 */       throw new IllegalArgumentException("Unable to extract parameterized field type argument from Formatter [" + formatter.getClass().getName() + "]; does the formatter parameterize the <T> generic type?");
/*     */     }
/*     */ 
/*  73 */     addFormatterForFieldType(fieldType, formatter);
/*     */   }
/*     */ 
/*     */   public void addFormatterForFieldType(Class<?> fieldType, Formatter<?> formatter) {
/*  77 */     addConverter(new PrinterConverter(fieldType, formatter, this));
/*  78 */     addConverter(new ParserConverter(fieldType, formatter, this));
/*     */   }
/*     */ 
/*     */   public void addFormatterForFieldType(Class<?> fieldType, Printer<?> printer, Parser<?> parser) {
/*  82 */     addConverter(new PrinterConverter(fieldType, printer, this));
/*  83 */     addConverter(new ParserConverter(fieldType, parser, this));
/*     */   }
/*     */ 
/*     */   public void addFormatterForFieldAnnotation(AnnotationFormatterFactory annotationFormatterFactory)
/*     */   {
/*  88 */     Class annotationType = GenericTypeResolver.resolveTypeArgument(annotationFormatterFactory.getClass(), AnnotationFormatterFactory.class);
/*     */ 
/*  90 */     if (annotationType == null) {
/*  91 */       throw new IllegalArgumentException("Unable to extract parameterized Annotation type argument from AnnotationFormatterFactory [" + annotationFormatterFactory.getClass().getName() + "]; does the factory parameterize the <A extends Annotation> generic type?");
/*     */     }
/*     */ 
/*  94 */     if ((this.embeddedValueResolver != null) && ((annotationFormatterFactory instanceof EmbeddedValueResolverAware))) {
/*  95 */       ((EmbeddedValueResolverAware)annotationFormatterFactory).setEmbeddedValueResolver(this.embeddedValueResolver);
/*     */     }
/*  97 */     Set fieldTypes = annotationFormatterFactory.getFieldTypes();
/*  98 */     for (Class fieldType : fieldTypes) {
/*  99 */       addConverter(new AnnotationPrinterConverter(annotationType, annotationFormatterFactory, fieldType));
/* 100 */       addConverter(new AnnotationParserConverter(annotationType, annotationFormatterFactory, fieldType));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class AnnotationConverterKey
/*     */   {
/*     */     private final Annotation annotation;
/*     */     private final Class<?> fieldType;
/*     */ 
/*     */     public AnnotationConverterKey(Annotation annotation, Class<?> fieldType)
/*     */     {
/* 289 */       this.annotation = annotation;
/* 290 */       this.fieldType = fieldType;
/*     */     }
/*     */ 
/*     */     public Annotation getAnnotation() {
/* 294 */       return this.annotation;
/*     */     }
/*     */ 
/*     */     public Class<?> getFieldType() {
/* 298 */       return this.fieldType;
/*     */     }
/*     */ 
/*     */     public boolean equals(Object o) {
/* 302 */       if (!(o instanceof AnnotationConverterKey)) {
/* 303 */         return false;
/*     */       }
/* 305 */       AnnotationConverterKey key = (AnnotationConverterKey)o;
/* 306 */       return (this.annotation.equals(key.annotation)) && (this.fieldType.equals(key.fieldType));
/*     */     }
/*     */ 
/*     */     public int hashCode() {
/* 310 */       return this.annotation.hashCode() + 29 * this.fieldType.hashCode();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class AnnotationParserConverter
/*     */     implements ConditionalGenericConverter
/*     */   {
/*     */     private Class<? extends Annotation> annotationType;
/*     */     private AnnotationFormatterFactory annotationFormatterFactory;
/*     */     private Class<?> fieldType;
/*     */ 
/*     */     public AnnotationParserConverter(AnnotationFormatterFactory<?> annotationType, Class<?> annotationFormatterFactory)
/*     */     {
/* 248 */       this.annotationType = annotationType;
/* 249 */       this.annotationFormatterFactory = annotationFormatterFactory;
/* 250 */       this.fieldType = fieldType;
/*     */     }
/*     */ 
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 254 */       return Collections.singleton(new GenericConverter.ConvertiblePair(String.class, this.fieldType));
/*     */     }
/*     */ 
/*     */     public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 258 */       return targetType.hasAnnotation(this.annotationType);
/*     */     }
/*     */ 
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 263 */       FormattingConversionService.AnnotationConverterKey converterKey = new FormattingConversionService.AnnotationConverterKey(targetType.getAnnotation(this.annotationType), targetType.getObjectType());
/*     */ 
/* 265 */       GenericConverter converter = (GenericConverter)FormattingConversionService.this.cachedParsers.get(converterKey);
/* 266 */       if (converter == null) {
/* 267 */         Parser parser = this.annotationFormatterFactory.getParser(converterKey.getAnnotation(), converterKey.getFieldType());
/*     */ 
/* 269 */         converter = new FormattingConversionService.ParserConverter(this.fieldType, parser, FormattingConversionService.this);
/* 270 */         FormattingConversionService.this.cachedParsers.put(converterKey, converter);
/*     */       }
/* 272 */       return converter.convert(source, sourceType, targetType);
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 276 */       return String.class.getName() + " -> @" + this.annotationType.getName() + " " + this.fieldType.getName() + ": " + this.annotationFormatterFactory;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class AnnotationPrinterConverter
/*     */     implements ConditionalGenericConverter
/*     */   {
/*     */     private Class<? extends Annotation> annotationType;
/*     */     private AnnotationFormatterFactory annotationFormatterFactory;
/*     */     private Class<?> fieldType;
/*     */ 
/*     */     public AnnotationPrinterConverter(AnnotationFormatterFactory annotationType, Class<?> annotationFormatterFactory)
/*     */     {
/* 204 */       this.annotationType = annotationType;
/* 205 */       this.annotationFormatterFactory = annotationFormatterFactory;
/* 206 */       this.fieldType = fieldType;
/*     */     }
/*     */ 
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 210 */       return Collections.singleton(new GenericConverter.ConvertiblePair(this.fieldType, String.class));
/*     */     }
/*     */ 
/*     */     public boolean matches(TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 214 */       return sourceType.hasAnnotation(this.annotationType);
/*     */     }
/*     */ 
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 219 */       FormattingConversionService.AnnotationConverterKey converterKey = new FormattingConversionService.AnnotationConverterKey(sourceType.getAnnotation(this.annotationType), sourceType.getObjectType());
/*     */ 
/* 221 */       GenericConverter converter = (GenericConverter)FormattingConversionService.this.cachedPrinters.get(converterKey);
/* 222 */       if (converter == null) {
/* 223 */         Printer printer = this.annotationFormatterFactory.getPrinter(converterKey.getAnnotation(), converterKey.getFieldType());
/*     */ 
/* 225 */         converter = new FormattingConversionService.PrinterConverter(this.fieldType, printer, FormattingConversionService.this);
/* 226 */         FormattingConversionService.this.cachedPrinters.put(converterKey, converter);
/*     */       }
/* 228 */       return converter.convert(source, sourceType, targetType);
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 232 */       return "@" + this.annotationType.getName() + " " + this.fieldType.getName() + " -> " + String.class.getName() + ": " + this.annotationFormatterFactory;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ParserConverter
/*     */     implements GenericConverter
/*     */   {
/*     */     private Class<?> fieldType;
/*     */     private Parser<?> parser;
/*     */     private ConversionService conversionService;
/*     */ 
/*     */     public ParserConverter(Class<?> fieldType, Parser<?> parser, ConversionService conversionService)
/*     */     {
/* 157 */       this.fieldType = fieldType;
/* 158 */       this.parser = parser;
/* 159 */       this.conversionService = conversionService;
/*     */     }
/*     */ 
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 163 */       return Collections.singleton(new GenericConverter.ConvertiblePair(String.class, this.fieldType));
/*     */     }
/*     */ 
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType) {
/* 167 */       String text = (String)source;
/* 168 */       if (!StringUtils.hasText(text))
/* 169 */         return null;
/*     */       Object result;
/*     */       try
/*     */       {
/* 173 */         result = this.parser.parse(text, LocaleContextHolder.getLocale());
/*     */       }
/*     */       catch (ParseException ex) {
/* 176 */         throw new IllegalArgumentException("Unable to parse '" + text + "'", ex);
/*     */       }
/* 178 */       if (result == null) {
/* 179 */         throw new IllegalStateException("Parsers are not allowed to return null");
/*     */       }
/* 181 */       TypeDescriptor resultType = TypeDescriptor.valueOf(result.getClass());
/* 182 */       if (!resultType.isAssignableTo(targetType)) {
/* 183 */         result = this.conversionService.convert(result, resultType, targetType);
/*     */       }
/* 185 */       return result;
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 189 */       return String.class.getName() + " -> " + this.fieldType.getName() + ": " + this.parser;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class PrinterConverter
/*     */     implements GenericConverter
/*     */   {
/*     */     private Class<?> fieldType;
/*     */     private TypeDescriptor printerObjectType;
/*     */     private Printer printer;
/*     */     private ConversionService conversionService;
/*     */ 
/*     */     public PrinterConverter(Class<?> fieldType, Printer<?> printer, ConversionService conversionService)
/*     */     {
/* 117 */       this.fieldType = fieldType;
/* 118 */       this.printerObjectType = TypeDescriptor.valueOf(resolvePrinterObjectType(printer));
/* 119 */       this.printer = printer;
/* 120 */       this.conversionService = conversionService;
/*     */     }
/*     */ 
/*     */     public Set<GenericConverter.ConvertiblePair> getConvertibleTypes() {
/* 124 */       return Collections.singleton(new GenericConverter.ConvertiblePair(this.fieldType, String.class));
/*     */     }
/*     */ 
/*     */     public Object convert(Object source, TypeDescriptor sourceType, TypeDescriptor targetType)
/*     */     {
/* 129 */       if (source == null) {
/* 130 */         return "";
/*     */       }
/* 132 */       if (!sourceType.isAssignableTo(this.printerObjectType)) {
/* 133 */         source = this.conversionService.convert(source, sourceType, this.printerObjectType);
/*     */       }
/* 135 */       return this.printer.print(source, LocaleContextHolder.getLocale());
/*     */     }
/*     */ 
/*     */     private Class<?> resolvePrinterObjectType(Printer<?> printer) {
/* 139 */       return GenericTypeResolver.resolveTypeArgument(printer.getClass(), Printer.class);
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 143 */       return this.fieldType.getName() + " -> " + String.class.getName() + " : " + this.printer;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.format.support.FormattingConversionService
 * JD-Core Version:    0.6.1
 */