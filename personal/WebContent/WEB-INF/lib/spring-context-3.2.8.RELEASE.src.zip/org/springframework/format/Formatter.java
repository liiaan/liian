package org.springframework.format;

public abstract interface Formatter<T> extends Printer<T>, Parser<T>
{
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.format.Formatter
 * JD-Core Version:    0.6.1
 */