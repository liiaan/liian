/*     */ package org.springframework.format.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.annotation.Retention;
/*     */ import java.lang.annotation.RetentionPolicy;
/*     */ import java.lang.annotation.Target;
/*     */ 
/*     */ @Target({java.lang.annotation.ElementType.METHOD, java.lang.annotation.ElementType.FIELD, java.lang.annotation.ElementType.PARAMETER, java.lang.annotation.ElementType.ANNOTATION_TYPE})
/*     */ @Retention(RetentionPolicy.RUNTIME)
/*     */ public @interface DateTimeFormat
/*     */ {
/*     */   public abstract String style();
/*     */ 
/*     */   public abstract ISO iso();
/*     */ 
/*     */   public abstract String pattern();
/*     */ 
/*     */   public static enum ISO
/*     */   {
/*  89 */     DATE, 
/*     */ 
/*  95 */     TIME, 
/*     */ 
/* 102 */     DATE_TIME, 
/*     */ 
/* 107 */     NONE;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.format.annotation.DateTimeFormat
 * JD-Core Version:    0.6.1
 */