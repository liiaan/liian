/*    */ package org.springframework.format.support;
/*    */ 
/*    */ import org.springframework.core.convert.support.DefaultConversionService;
/*    */ import org.springframework.format.FormatterRegistry;
/*    */ import org.springframework.format.datetime.DateFormatterRegistrar;
/*    */ import org.springframework.format.datetime.joda.JodaTimeFormatterRegistrar;
/*    */ import org.springframework.format.number.NumberFormatAnnotationFormatterFactory;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.util.StringValueResolver;
/*    */ 
/*    */ public class DefaultFormattingConversionService extends FormattingConversionService
/*    */ {
/* 41 */   private static final boolean jodaTimePresent = ClassUtils.isPresent("org.joda.time.LocalDate", DefaultFormattingConversionService.class.getClassLoader());
/*    */ 
/*    */   public DefaultFormattingConversionService()
/*    */   {
/* 50 */     this(null, true);
/*    */   }
/*    */ 
/*    */   public DefaultFormattingConversionService(boolean registerDefaultFormatters)
/*    */   {
/* 61 */     this(null, registerDefaultFormatters);
/*    */   }
/*    */ 
/*    */   public DefaultFormattingConversionService(StringValueResolver embeddedValueResolver, boolean registerDefaultFormatters)
/*    */   {
/* 74 */     setEmbeddedValueResolver(embeddedValueResolver);
/* 75 */     DefaultConversionService.addDefaultConverters(this);
/* 76 */     if (registerDefaultFormatters)
/* 77 */       addDefaultFormatters(this);
/*    */   }
/*    */ 
/*    */   public static void addDefaultFormatters(FormatterRegistry formatterRegistry)
/*    */   {
/* 87 */     formatterRegistry.addFormatterForFieldAnnotation(new NumberFormatAnnotationFormatterFactory());
/* 88 */     if (jodaTimePresent) {
/* 89 */       new JodaTimeFormatterRegistrar().registerFormatters(formatterRegistry);
/*    */     }
/*    */     else
/* 92 */       new DateFormatterRegistrar().registerFormatters(formatterRegistry);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.format.support.DefaultFormattingConversionService
 * JD-Core Version:    0.6.1
 */