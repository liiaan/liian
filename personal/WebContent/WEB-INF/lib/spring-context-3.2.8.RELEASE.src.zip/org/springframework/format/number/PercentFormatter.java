/*    */ package org.springframework.format.number;
/*    */ 
/*    */ import java.text.DecimalFormat;
/*    */ import java.text.NumberFormat;
/*    */ import java.util.Locale;
/*    */ 
/*    */ public class PercentFormatter extends AbstractNumberFormatter
/*    */ {
/*    */   protected NumberFormat getNumberFormat(Locale locale)
/*    */   {
/* 38 */     NumberFormat format = NumberFormat.getPercentInstance(locale);
/* 39 */     if ((format instanceof DecimalFormat)) {
/* 40 */       ((DecimalFormat)format).setParseBigDecimal(true);
/*    */     }
/* 42 */     return format;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.format.number.PercentFormatter
 * JD-Core Version:    0.6.1
 */