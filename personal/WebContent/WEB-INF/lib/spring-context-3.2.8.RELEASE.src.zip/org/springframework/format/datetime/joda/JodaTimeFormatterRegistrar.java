/*     */ package org.springframework.format.datetime.joda;
/*     */ 
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.joda.time.LocalDate;
/*     */ import org.joda.time.LocalDateTime;
/*     */ import org.joda.time.LocalTime;
/*     */ import org.joda.time.ReadableInstant;
/*     */ import org.joda.time.format.DateTimeFormat;
/*     */ import org.joda.time.format.DateTimeFormatter;
/*     */ import org.springframework.format.FormatterRegistrar;
/*     */ import org.springframework.format.FormatterRegistry;
/*     */ import org.springframework.format.Parser;
/*     */ import org.springframework.format.Printer;
/*     */ import org.springframework.format.annotation.DateTimeFormat.ISO;
/*     */ 
/*     */ public class JodaTimeFormatterRegistrar
/*     */   implements FormatterRegistrar
/*     */ {
/*  61 */   private final Map<Type, DateTimeFormatter> formatters = new HashMap();
/*     */   private final Map<Type, DateTimeFormatterFactory> factories;
/*     */ 
/*     */   public JodaTimeFormatterRegistrar()
/*     */   {
/*  70 */     this.factories = new HashMap();
/*  71 */     for (Type type : Type.values())
/*  72 */       this.factories.put(type, new DateTimeFormatterFactory());
/*     */   }
/*     */ 
/*     */   public void setUseIsoFormat(boolean useIsoFormat)
/*     */   {
/*  84 */     ((DateTimeFormatterFactory)this.factories.get(Type.DATE)).setIso(useIsoFormat ? DateTimeFormat.ISO.DATE : null);
/*  85 */     ((DateTimeFormatterFactory)this.factories.get(Type.TIME)).setIso(useIsoFormat ? DateTimeFormat.ISO.TIME : null);
/*  86 */     ((DateTimeFormatterFactory)this.factories.get(Type.DATE_TIME)).setIso(useIsoFormat ? DateTimeFormat.ISO.DATE_TIME : null);
/*     */   }
/*     */ 
/*     */   public void setDateStyle(String dateStyle)
/*     */   {
/*  94 */     ((DateTimeFormatterFactory)this.factories.get(Type.DATE)).setStyle(dateStyle + "-");
/*     */   }
/*     */ 
/*     */   public void setTimeStyle(String timeStyle)
/*     */   {
/* 102 */     ((DateTimeFormatterFactory)this.factories.get(Type.TIME)).setStyle("-" + timeStyle);
/*     */   }
/*     */ 
/*     */   public void setDateTimeStyle(String dateTimeStyle)
/*     */   {
/* 111 */     ((DateTimeFormatterFactory)this.factories.get(Type.DATE_TIME)).setStyle(dateTimeStyle);
/*     */   }
/*     */ 
/*     */   public void setDateFormatter(DateTimeFormatter formatter)
/*     */   {
/* 125 */     this.formatters.put(Type.DATE, formatter);
/*     */   }
/*     */ 
/*     */   public void setTimeFormatter(DateTimeFormatter formatter)
/*     */   {
/* 139 */     this.formatters.put(Type.TIME, formatter);
/*     */   }
/*     */ 
/*     */   public void setDateTimeFormatter(DateTimeFormatter formatter)
/*     */   {
/* 154 */     this.formatters.put(Type.DATE_TIME, formatter);
/*     */   }
/*     */ 
/*     */   public void registerFormatters(FormatterRegistry registry)
/*     */   {
/* 159 */     JodaTimeConverters.registerConverters(registry);
/*     */ 
/* 161 */     DateTimeFormatter dateFormatter = getFormatter(Type.DATE);
/* 162 */     DateTimeFormatter timeFormatter = getFormatter(Type.TIME);
/* 163 */     DateTimeFormatter dateTimeFormatter = getFormatter(Type.DATE_TIME);
/*     */ 
/* 165 */     addFormatterForFields(registry, new ReadablePartialPrinter(dateFormatter), new DateTimeParser(dateFormatter), new Class[] { LocalDate.class });
/*     */ 
/* 170 */     addFormatterForFields(registry, new ReadablePartialPrinter(timeFormatter), new DateTimeParser(timeFormatter), new Class[] { LocalTime.class });
/*     */ 
/* 175 */     addFormatterForFields(registry, new ReadablePartialPrinter(dateTimeFormatter), new DateTimeParser(dateTimeFormatter), new Class[] { LocalDateTime.class });
/*     */ 
/* 180 */     addFormatterForFields(registry, new ReadableInstantPrinter(dateTimeFormatter), new DateTimeParser(dateTimeFormatter), new Class[] { ReadableInstant.class });
/*     */ 
/* 187 */     if (this.formatters.containsKey(Type.DATE_TIME)) {
/* 188 */       addFormatterForFields(registry, new ReadableInstantPrinter(dateTimeFormatter), new DateTimeParser(dateTimeFormatter), new Class[] { Date.class, Calendar.class });
/*     */     }
/*     */ 
/* 194 */     registry.addFormatterForFieldAnnotation(new JodaDateTimeFormatAnnotationFormatterFactory());
/*     */   }
/*     */ 
/*     */   private DateTimeFormatter getFormatter(Type type) {
/* 198 */     DateTimeFormatter formatter = (DateTimeFormatter)this.formatters.get(type);
/* 199 */     if (formatter != null) {
/* 200 */       return formatter;
/*     */     }
/* 202 */     DateTimeFormatter fallbackFormatter = getFallbackFormatter(type);
/* 203 */     return ((DateTimeFormatterFactory)this.factories.get(type)).createDateTimeFormatter(fallbackFormatter);
/*     */   }
/*     */ 
/*     */   private DateTimeFormatter getFallbackFormatter(Type type) {
/* 207 */     switch (1.$SwitchMap$org$springframework$format$datetime$joda$JodaTimeFormatterRegistrar$Type[type.ordinal()]) { case 1:
/* 208 */       return DateTimeFormat.shortDate();
/*     */     case 2:
/* 209 */       return DateTimeFormat.shortTime(); }
/* 210 */     return DateTimeFormat.shortDateTime();
/*     */   }
/*     */ 
/*     */   private void addFormatterForFields(FormatterRegistry registry, Printer<?> printer, Parser<?> parser, Class<?>[] fieldTypes)
/*     */   {
/* 217 */     for (Class fieldType : fieldTypes)
/* 218 */       registry.addFormatterForFieldType(fieldType, printer, parser);
/*     */   }
/*     */ 
/*     */   private static enum Type
/*     */   {
/*  55 */     DATE, TIME, DATE_TIME;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.joda.JodaTimeFormatterRegistrar
 * JD-Core Version:    0.6.1
 */