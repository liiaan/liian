package org.springframework.format;

public abstract interface FormatterRegistrar
{
  public abstract void registerFormatters(FormatterRegistry paramFormatterRegistry);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.format.FormatterRegistrar
 * JD-Core Version:    0.6.1
 */