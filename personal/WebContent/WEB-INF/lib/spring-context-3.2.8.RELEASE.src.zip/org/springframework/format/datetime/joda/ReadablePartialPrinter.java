/*    */ package org.springframework.format.datetime.joda;
/*    */ 
/*    */ import java.util.Locale;
/*    */ import org.joda.time.ReadablePartial;
/*    */ import org.joda.time.format.DateTimeFormatter;
/*    */ import org.springframework.format.Printer;
/*    */ 
/*    */ public final class ReadablePartialPrinter
/*    */   implements Printer<ReadablePartial>
/*    */ {
/*    */   private final DateTimeFormatter formatter;
/*    */ 
/*    */   public ReadablePartialPrinter(DateTimeFormatter formatter)
/*    */   {
/* 41 */     this.formatter = formatter;
/*    */   }
/*    */ 
/*    */   public String print(ReadablePartial partial, Locale locale) {
/* 45 */     return JodaTimeContextHolder.getFormatter(this.formatter, locale).print(partial);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.format.datetime.joda.ReadablePartialPrinter
 * JD-Core Version:    0.6.1
 */