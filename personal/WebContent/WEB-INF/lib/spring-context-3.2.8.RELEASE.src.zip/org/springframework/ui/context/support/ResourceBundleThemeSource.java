/*     */ package org.springframework.ui.context.support;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.context.HierarchicalMessageSource;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.context.support.ResourceBundleMessageSource;
/*     */ import org.springframework.ui.context.HierarchicalThemeSource;
/*     */ import org.springframework.ui.context.Theme;
/*     */ import org.springframework.ui.context.ThemeSource;
/*     */ 
/*     */ public class ResourceBundleThemeSource
/*     */   implements HierarchicalThemeSource
/*     */ {
/*  46 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private ThemeSource parentThemeSource;
/*  50 */   private String basenamePrefix = "";
/*     */ 
/*  53 */   private final Map<String, Theme> themeCache = new HashMap();
/*     */ 
/*     */   public void setParentThemeSource(ThemeSource parent)
/*     */   {
/*  57 */     this.parentThemeSource = parent;
/*     */ 
/*  61 */     synchronized (this.themeCache) {
/*  62 */       for (Theme theme : this.themeCache.values())
/*  63 */         initParent(theme);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ThemeSource getParentThemeSource()
/*     */   {
/*  69 */     return this.parentThemeSource;
/*     */   }
/*     */ 
/*     */   public void setBasenamePrefix(String basenamePrefix)
/*     */   {
/*  83 */     this.basenamePrefix = (basenamePrefix != null ? basenamePrefix : "");
/*     */   }
/*     */ 
/*     */   public Theme getTheme(String themeName)
/*     */   {
/*  97 */     if (themeName == null) {
/*  98 */       return null;
/*     */     }
/* 100 */     synchronized (this.themeCache) {
/* 101 */       Theme theme = (Theme)this.themeCache.get(themeName);
/* 102 */       if (theme == null) {
/* 103 */         String basename = this.basenamePrefix + themeName;
/* 104 */         MessageSource messageSource = createMessageSource(basename);
/* 105 */         theme = new SimpleTheme(themeName, messageSource);
/* 106 */         initParent(theme);
/* 107 */         this.themeCache.put(themeName, theme);
/* 108 */         if (this.logger.isDebugEnabled()) {
/* 109 */           this.logger.debug("Theme created: name '" + themeName + "', basename [" + basename + "]");
/*     */         }
/*     */       }
/* 112 */       return theme;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected MessageSource createMessageSource(String basename)
/*     */   {
/* 128 */     ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
/* 129 */     messageSource.setBasename(basename);
/* 130 */     return messageSource;
/*     */   }
/*     */ 
/*     */   protected void initParent(Theme theme)
/*     */   {
/* 139 */     if ((theme.getMessageSource() instanceof HierarchicalMessageSource)) {
/* 140 */       HierarchicalMessageSource messageSource = (HierarchicalMessageSource)theme.getMessageSource();
/* 141 */       if ((getParentThemeSource() != null) && (messageSource.getParentMessageSource() == null)) {
/* 142 */         Theme parentTheme = getParentThemeSource().getTheme(theme.getName());
/* 143 */         if (parentTheme != null)
/* 144 */           messageSource.setParentMessageSource(parentTheme.getMessageSource());
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.ui.context.support.ResourceBundleThemeSource
 * JD-Core Version:    0.6.1
 */