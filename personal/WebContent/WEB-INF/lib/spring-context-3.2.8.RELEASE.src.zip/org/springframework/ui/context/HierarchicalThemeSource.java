package org.springframework.ui.context;

public abstract interface HierarchicalThemeSource extends ThemeSource
{
  public abstract void setParentThemeSource(ThemeSource paramThemeSource);

  public abstract ThemeSource getParentThemeSource();
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.ui.context.HierarchicalThemeSource
 * JD-Core Version:    0.6.1
 */