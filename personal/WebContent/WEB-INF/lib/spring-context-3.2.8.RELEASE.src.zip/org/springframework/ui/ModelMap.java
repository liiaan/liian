/*     */ package org.springframework.ui;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class ModelMap extends LinkedHashMap<String, Object>
/*     */ {
/*     */   public ModelMap()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ModelMap(String attributeName, Object attributeValue)
/*     */   {
/*  56 */     addAttribute(attributeName, attributeValue);
/*     */   }
/*     */ 
/*     */   public ModelMap(Object attributeValue)
/*     */   {
/*  66 */     addAttribute(attributeValue);
/*     */   }
/*     */ 
/*     */   public ModelMap addAttribute(String attributeName, Object attributeValue)
/*     */   {
/*  76 */     Assert.notNull(attributeName, "Model attribute name must not be null");
/*  77 */     put(attributeName, attributeValue);
/*  78 */     return this;
/*     */   }
/*     */ 
/*     */   public ModelMap addAttribute(Object attributeValue)
/*     */   {
/*  91 */     Assert.notNull(attributeValue, "Model object must not be null");
/*  92 */     if (((attributeValue instanceof Collection)) && (((Collection)attributeValue).isEmpty())) {
/*  93 */       return this;
/*     */     }
/*  95 */     return addAttribute(Conventions.getVariableName(attributeValue), attributeValue);
/*     */   }
/*     */ 
/*     */   public ModelMap addAllAttributes(Collection<?> attributeValues)
/*     */   {
/*     */     Iterator i$;
/* 104 */     if (attributeValues != null) {
/* 105 */       for (i$ = attributeValues.iterator(); i$.hasNext(); ) { Object attributeValue = i$.next();
/* 106 */         addAttribute(attributeValue);
/*     */       }
/*     */     }
/* 109 */     return this;
/*     */   }
/*     */ 
/*     */   public ModelMap addAllAttributes(Map<String, ?> attributes)
/*     */   {
/* 117 */     if (attributes != null) {
/* 118 */       putAll(attributes);
/*     */     }
/* 120 */     return this;
/*     */   }
/*     */ 
/*     */   public ModelMap mergeAttributes(Map<String, ?> attributes)
/*     */   {
/* 129 */     if (attributes != null) {
/* 130 */       for (String key : attributes.keySet()) {
/* 131 */         if (!containsKey(key)) {
/* 132 */           put(key, attributes.get(key));
/*     */         }
/*     */       }
/*     */     }
/* 136 */     return this;
/*     */   }
/*     */ 
/*     */   public boolean containsAttribute(String attributeName)
/*     */   {
/* 145 */     return containsKey(attributeName);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public ModelMap addObject(String modelName, Object modelObject)
/*     */   {
/* 154 */     return addAttribute(modelName, modelObject);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public ModelMap addObject(Object modelObject)
/*     */   {
/* 162 */     return addAttribute(modelObject);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public ModelMap addAllObjects(Collection objects)
/*     */   {
/* 170 */     return addAllAttributes(objects);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public ModelMap addAllObjects(Map objects)
/*     */   {
/* 178 */     return addAllAttributes(objects);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.ui.ModelMap
 * JD-Core Version:    0.6.1
 */