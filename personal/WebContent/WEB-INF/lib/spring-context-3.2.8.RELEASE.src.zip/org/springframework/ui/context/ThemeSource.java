package org.springframework.ui.context;

public abstract interface ThemeSource
{
  public abstract Theme getTheme(String paramString);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.ui.context.ThemeSource
 * JD-Core Version:    0.6.1
 */