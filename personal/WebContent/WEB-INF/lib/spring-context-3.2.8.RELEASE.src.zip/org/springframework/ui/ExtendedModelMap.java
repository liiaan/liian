/*    */ package org.springframework.ui;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class ExtendedModelMap extends ModelMap
/*    */   implements Model
/*    */ {
/*    */   public ExtendedModelMap addAttribute(String attributeName, Object attributeValue)
/*    */   {
/* 34 */     super.addAttribute(attributeName, attributeValue);
/* 35 */     return this;
/*    */   }
/*    */ 
/*    */   public ExtendedModelMap addAttribute(Object attributeValue)
/*    */   {
/* 40 */     super.addAttribute(attributeValue);
/* 41 */     return this;
/*    */   }
/*    */ 
/*    */   public ExtendedModelMap addAllAttributes(Collection<?> attributeValues)
/*    */   {
/* 46 */     super.addAllAttributes(attributeValues);
/* 47 */     return this;
/*    */   }
/*    */ 
/*    */   public ExtendedModelMap addAllAttributes(Map<String, ?> attributes)
/*    */   {
/* 52 */     super.addAllAttributes(attributes);
/* 53 */     return this;
/*    */   }
/*    */ 
/*    */   public ExtendedModelMap mergeAttributes(Map<String, ?> attributes)
/*    */   {
/* 58 */     super.mergeAttributes(attributes);
/* 59 */     return this;
/*    */   }
/*    */ 
/*    */   public Map<String, Object> asMap() {
/* 63 */     return this;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.ui.ExtendedModelMap
 * JD-Core Version:    0.6.1
 */