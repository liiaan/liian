/*    */ package org.springframework.ejb.support;
/*    */ 
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.FatalBeanException;
/*    */ 
/*    */ @Deprecated
/*    */ public abstract class AbstractStatefulSessionBean extends AbstractSessionBean
/*    */ {
/*    */   protected void loadBeanFactory()
/*    */     throws BeansException
/*    */   {
/* 62 */     super.loadBeanFactory();
/*    */   }
/*    */ 
/*    */   protected void unloadBeanFactory()
/*    */     throws FatalBeanException
/*    */   {
/* 75 */     super.unloadBeanFactory();
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.ejb.support.AbstractStatefulSessionBean
 * JD-Core Version:    0.6.1
 */