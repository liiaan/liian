/*    */ package org.springframework.ejb.support;
/*    */ 
/*    */ import javax.ejb.MessageDrivenBean;
/*    */ import javax.ejb.MessageDrivenContext;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ @Deprecated
/*    */ public abstract class AbstractMessageDrivenBean extends AbstractEnterpriseBean
/*    */   implements MessageDrivenBean
/*    */ {
/* 51 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */   private MessageDrivenContext messageDrivenContext;
/*    */ 
/*    */   public void setMessageDrivenContext(MessageDrivenContext messageDrivenContext)
/*    */   {
/* 61 */     this.messageDrivenContext = messageDrivenContext;
/*    */   }
/*    */ 
/*    */   protected final MessageDrivenContext getMessageDrivenContext()
/*    */   {
/* 69 */     return this.messageDrivenContext;
/*    */   }
/*    */ 
/*    */   public void ejbCreate()
/*    */   {
/* 81 */     loadBeanFactory();
/* 82 */     onEjbCreate();
/*    */   }
/*    */ 
/*    */   protected abstract void onEjbCreate();
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.ejb.support.AbstractMessageDrivenBean
 * JD-Core Version:    0.6.1
 */