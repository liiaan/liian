/*     */ package org.springframework.ejb.access;
/*     */ 
/*     */ import javax.naming.NamingException;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class SimpleRemoteStatelessSessionProxyFactoryBean extends SimpleRemoteSlsbInvokerInterceptor
/*     */   implements FactoryBean<Object>, BeanClassLoaderAware
/*     */ {
/*     */   private Class businessInterface;
/*  67 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */   private Object proxy;
/*     */ 
/*     */   public void setBusinessInterface(Class businessInterface)
/*     */   {
/*  84 */     this.businessInterface = businessInterface;
/*     */   }
/*     */ 
/*     */   public Class getBusinessInterface()
/*     */   {
/*  91 */     return this.businessInterface;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader) {
/*  95 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() throws NamingException
/*     */   {
/* 100 */     super.afterPropertiesSet();
/* 101 */     if (this.businessInterface == null) {
/* 102 */       throw new IllegalArgumentException("businessInterface is required");
/*     */     }
/* 104 */     this.proxy = new ProxyFactory(this.businessInterface, this).getProxy(this.beanClassLoader);
/*     */   }
/*     */ 
/*     */   public Object getObject()
/*     */   {
/* 109 */     return this.proxy;
/*     */   }
/*     */ 
/*     */   public Class<?> getObjectType() {
/* 113 */     return this.businessInterface;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton() {
/* 117 */     return true;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.ejb.access.SimpleRemoteStatelessSessionProxyFactoryBean
 * JD-Core Version:    0.6.1
 */