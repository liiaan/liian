/*    */ package org.springframework.ejb.config;
/*    */ 
/*    */ import org.springframework.beans.factory.xml.NamespaceHandlerSupport;
/*    */ 
/*    */ public class JeeNamespaceHandler extends NamespaceHandlerSupport
/*    */ {
/*    */   public void init()
/*    */   {
/* 31 */     registerBeanDefinitionParser("jndi-lookup", new JndiLookupBeanDefinitionParser());
/* 32 */     registerBeanDefinitionParser("local-slsb", new LocalStatelessSessionBeanDefinitionParser());
/* 33 */     registerBeanDefinitionParser("remote-slsb", new RemoteStatelessSessionBeanDefinitionParser());
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.ejb.config.JeeNamespaceHandler
 * JD-Core Version:    0.6.1
 */