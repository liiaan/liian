/*    */ package org.springframework.ejb.support;
/*    */ 
/*    */ import javax.ejb.SessionContext;
/*    */ 
/*    */ @Deprecated
/*    */ public abstract class AbstractSessionBean extends AbstractEnterpriseBean
/*    */   implements SmartSessionBean
/*    */ {
/*    */   private SessionContext sessionContext;
/*    */ 
/*    */   public void setSessionContext(SessionContext sessionContext)
/*    */   {
/* 46 */     this.sessionContext = sessionContext;
/*    */   }
/*    */ 
/*    */   public final SessionContext getSessionContext()
/*    */   {
/* 54 */     return this.sessionContext;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.ejb.support.AbstractSessionBean
 * JD-Core Version:    0.6.1
 */