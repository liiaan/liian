/*     */ package org.springframework.ejb.access;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.rmi.RemoteException;
/*     */ import javax.ejb.CreateException;
/*     */ import javax.ejb.EJBObject;
/*     */ import javax.naming.NamingException;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.remoting.RemoteLookupFailureException;
/*     */ import org.springframework.remoting.rmi.RmiClientInterceptorUtils;
/*     */ 
/*     */ public class SimpleRemoteSlsbInvokerInterceptor extends AbstractRemoteSlsbInvokerInterceptor
/*     */   implements DisposableBean
/*     */ {
/*  68 */   private boolean cacheSessionBean = false;
/*     */   private Object beanInstance;
/*  72 */   private final Object beanInstanceMonitor = new Object();
/*     */ 
/*     */   public void setCacheSessionBean(boolean cacheSessionBean)
/*     */   {
/*  83 */     this.cacheSessionBean = cacheSessionBean;
/*     */   }
/*     */ 
/*     */   protected Object doInvoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/*  96 */     Object ejb = null;
/*     */     try {
/*  98 */       ejb = getSessionBeanInstance();
/*  99 */       return RmiClientInterceptorUtils.invokeRemoteMethod(invocation, ejb);
/*     */     }
/*     */     catch (NamingException ex) {
/* 102 */       throw new RemoteLookupFailureException("Failed to locate remote EJB [" + getJndiName() + "]", ex);
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 105 */       Throwable targetEx = ex.getTargetException();
/* 106 */       if ((targetEx instanceof RemoteException)) {
/* 107 */         RemoteException rex = (RemoteException)targetEx;
/* 108 */         throw RmiClientInterceptorUtils.convertRmiAccessException(invocation.getMethod(), rex, isConnectFailure(rex), getJndiName());
/*     */       }
/*     */ 
/* 111 */       if ((targetEx instanceof CreateException)) {
/* 112 */         throw RmiClientInterceptorUtils.convertRmiAccessException(invocation.getMethod(), targetEx, "Could not create remote EJB [" + getJndiName() + "]");
/*     */       }
/*     */ 
/* 115 */       throw targetEx;
/*     */     }
/*     */     finally {
/* 118 */       if ((ejb instanceof EJBObject))
/* 119 */         releaseSessionBeanInstance((EJBObject)ejb);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object getSessionBeanInstance()
/*     */     throws NamingException, InvocationTargetException
/*     */   {
/* 133 */     if (this.cacheSessionBean) {
/* 134 */       synchronized (this.beanInstanceMonitor) {
/* 135 */         if (this.beanInstance == null) {
/* 136 */           this.beanInstance = newSessionBeanInstance();
/*     */         }
/* 138 */         return this.beanInstance;
/*     */       }
/*     */     }
/*     */ 
/* 142 */     return newSessionBeanInstance();
/*     */   }
/*     */ 
/*     */   protected void releaseSessionBeanInstance(EJBObject ejb)
/*     */   {
/* 153 */     if (!this.cacheSessionBean)
/* 154 */       removeSessionBeanInstance(ejb);
/*     */   }
/*     */ 
/*     */   protected void refreshHome()
/*     */     throws NamingException
/*     */   {
/* 163 */     super.refreshHome();
/* 164 */     if (this.cacheSessionBean)
/* 165 */       synchronized (this.beanInstanceMonitor) {
/* 166 */         this.beanInstance = null;
/*     */       }
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 175 */     if (this.cacheSessionBean)
/* 176 */       synchronized (this.beanInstanceMonitor) {
/* 177 */         if ((this.beanInstance instanceof EJBObject))
/* 178 */           removeSessionBeanInstance((EJBObject)this.beanInstance);
/*     */       }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.ejb.access.SimpleRemoteSlsbInvokerInterceptor
 * JD-Core Version:    0.6.1
 */