/*     */ package org.springframework.ejb.access;
/*     */ 
/*     */ import javax.naming.NamingException;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class LocalStatelessSessionProxyFactoryBean extends LocalSlsbInvokerInterceptor
/*     */   implements FactoryBean<Object>, BeanClassLoaderAware
/*     */ {
/*     */   private Class businessInterface;
/*  57 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */   private Object proxy;
/*     */ 
/*     */   public void setBusinessInterface(Class businessInterface)
/*     */   {
/*  70 */     this.businessInterface = businessInterface;
/*     */   }
/*     */ 
/*     */   public Class getBusinessInterface()
/*     */   {
/*  77 */     return this.businessInterface;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader) {
/*  81 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() throws NamingException
/*     */   {
/*  86 */     super.afterPropertiesSet();
/*  87 */     if (this.businessInterface == null) {
/*  88 */       throw new IllegalArgumentException("businessInterface is required");
/*     */     }
/*  90 */     this.proxy = new ProxyFactory(this.businessInterface, this).getProxy(this.beanClassLoader);
/*     */   }
/*     */ 
/*     */   public Object getObject()
/*     */   {
/*  95 */     return this.proxy;
/*     */   }
/*     */ 
/*     */   public Class<?> getObjectType() {
/*  99 */     return this.businessInterface;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton() {
/* 103 */     return true;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.ejb.access.LocalStatelessSessionProxyFactoryBean
 * JD-Core Version:    0.6.1
 */