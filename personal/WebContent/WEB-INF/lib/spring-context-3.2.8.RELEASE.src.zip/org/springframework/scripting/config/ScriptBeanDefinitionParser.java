/*     */ package org.springframework.scripting.config;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionDefaults;
/*     */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.AbstractBeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParserDelegate;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*     */ import org.springframework.scripting.support.ScriptFactoryPostProcessor;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ class ScriptBeanDefinitionParser extends AbstractBeanDefinitionParser
/*     */ {
/*     */   private static final String SCRIPT_SOURCE_ATTRIBUTE = "script-source";
/*     */   private static final String INLINE_SCRIPT_ELEMENT = "inline-script";
/*     */   private static final String SCOPE_ATTRIBUTE = "scope";
/*     */   private static final String AUTOWIRE_ATTRIBUTE = "autowire";
/*     */   private static final String DEPENDENCY_CHECK_ATTRIBUTE = "dependency-check";
/*     */   private static final String DEPENDS_ON_ATTRIBUTE = "depends-on";
/*     */   private static final String INIT_METHOD_ATTRIBUTE = "init-method";
/*     */   private static final String DESTROY_METHOD_ATTRIBUTE = "destroy-method";
/*     */   private static final String SCRIPT_INTERFACES_ATTRIBUTE = "script-interfaces";
/*     */   private static final String REFRESH_CHECK_DELAY_ATTRIBUTE = "refresh-check-delay";
/*     */   private static final String PROXY_TARGET_CLASS_ATTRIBUTE = "proxy-target-class";
/*     */   private static final String CUSTOMIZER_REF_ATTRIBUTE = "customizer-ref";
/*     */   private final String scriptFactoryClassName;
/*     */ 
/*     */   public ScriptBeanDefinitionParser(String scriptFactoryClassName)
/*     */   {
/*  96 */     this.scriptFactoryClassName = scriptFactoryClassName;
/*     */   }
/*     */ 
/*     */   protected AbstractBeanDefinition parseInternal(Element element, ParserContext parserContext)
/*     */   {
/* 108 */     String value = resolveScriptSource(element, parserContext.getReaderContext());
/* 109 */     if (value == null) {
/* 110 */       return null;
/*     */     }
/*     */ 
/* 114 */     LangNamespaceUtils.registerScriptFactoryPostProcessorIfNecessary(parserContext.getRegistry());
/*     */ 
/* 117 */     GenericBeanDefinition bd = new GenericBeanDefinition();
/* 118 */     bd.setBeanClassName(this.scriptFactoryClassName);
/* 119 */     bd.setSource(parserContext.extractSource(element));
/* 120 */     bd.setAttribute(ScriptFactoryPostProcessor.LANGUAGE_ATTRIBUTE, element.getLocalName());
/*     */ 
/* 123 */     String scope = element.getAttribute("scope");
/* 124 */     if (StringUtils.hasLength(scope)) {
/* 125 */       bd.setScope(scope);
/*     */     }
/*     */ 
/* 129 */     String autowire = element.getAttribute("autowire");
/* 130 */     int autowireMode = parserContext.getDelegate().getAutowireMode(autowire);
/*     */ 
/* 132 */     if (autowireMode == 4) {
/* 133 */       autowireMode = 2;
/*     */     }
/* 135 */     else if (autowireMode == 3) {
/* 136 */       autowireMode = 0;
/*     */     }
/* 138 */     bd.setAutowireMode(autowireMode);
/*     */ 
/* 141 */     String dependencyCheck = element.getAttribute("dependency-check");
/* 142 */     bd.setDependencyCheck(parserContext.getDelegate().getDependencyCheck(dependencyCheck));
/*     */ 
/* 145 */     String dependsOn = element.getAttribute("depends-on");
/* 146 */     if (StringUtils.hasLength(dependsOn)) {
/* 147 */       bd.setDependsOn(StringUtils.tokenizeToStringArray(dependsOn, ",; "));
/*     */     }
/*     */ 
/* 152 */     BeanDefinitionDefaults beanDefinitionDefaults = parserContext.getDelegate().getBeanDefinitionDefaults();
/*     */ 
/* 155 */     String initMethod = element.getAttribute("init-method");
/* 156 */     if (StringUtils.hasLength(initMethod)) {
/* 157 */       bd.setInitMethodName(initMethod);
/*     */     }
/* 159 */     else if (beanDefinitionDefaults.getInitMethodName() != null) {
/* 160 */       bd.setInitMethodName(beanDefinitionDefaults.getInitMethodName());
/*     */     }
/*     */ 
/* 163 */     String destroyMethod = element.getAttribute("destroy-method");
/* 164 */     if (StringUtils.hasLength(destroyMethod)) {
/* 165 */       bd.setDestroyMethodName(destroyMethod);
/*     */     }
/* 167 */     else if (beanDefinitionDefaults.getDestroyMethodName() != null) {
/* 168 */       bd.setDestroyMethodName(beanDefinitionDefaults.getDestroyMethodName());
/*     */     }
/*     */ 
/* 172 */     String refreshCheckDelay = element.getAttribute("refresh-check-delay");
/* 173 */     if (StringUtils.hasText(refreshCheckDelay)) {
/* 174 */       bd.setAttribute(ScriptFactoryPostProcessor.REFRESH_CHECK_DELAY_ATTRIBUTE, new Long(refreshCheckDelay));
/*     */     }
/*     */ 
/* 178 */     String proxyTargetClass = element.getAttribute("proxy-target-class");
/* 179 */     if (StringUtils.hasText(proxyTargetClass)) {
/* 180 */       Boolean flag = new Boolean(proxyTargetClass);
/* 181 */       bd.setAttribute(ScriptFactoryPostProcessor.PROXY_TARGET_CLASS_ATTRIBUTE, flag);
/*     */     }
/*     */ 
/* 185 */     ConstructorArgumentValues cav = bd.getConstructorArgumentValues();
/* 186 */     int constructorArgNum = 0;
/* 187 */     cav.addIndexedArgumentValue(constructorArgNum++, value);
/* 188 */     if (element.hasAttribute("script-interfaces")) {
/* 189 */       cav.addIndexedArgumentValue(constructorArgNum++, element.getAttribute("script-interfaces"));
/*     */     }
/*     */ 
/* 193 */     if (element.hasAttribute("customizer-ref")) {
/* 194 */       String customizerBeanName = element.getAttribute("customizer-ref");
/* 195 */       if (!StringUtils.hasText(customizerBeanName)) {
/* 196 */         parserContext.getReaderContext().error("Attribute 'customizer-ref' has empty value", element);
/*     */       }
/*     */       else {
/* 199 */         cav.addIndexedArgumentValue(constructorArgNum++, new RuntimeBeanReference(customizerBeanName));
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 204 */     parserContext.getDelegate().parsePropertyElements(element, bd);
/*     */ 
/* 206 */     return bd;
/*     */   }
/*     */ 
/*     */   private String resolveScriptSource(Element element, XmlReaderContext readerContext)
/*     */   {
/* 215 */     boolean hasScriptSource = element.hasAttribute("script-source");
/* 216 */     List elements = DomUtils.getChildElementsByTagName(element, "inline-script");
/* 217 */     if ((hasScriptSource) && (!elements.isEmpty())) {
/* 218 */       readerContext.error("Only one of 'script-source' and 'inline-script' should be specified.", element);
/* 219 */       return null;
/*     */     }
/* 221 */     if (hasScriptSource) {
/* 222 */       return element.getAttribute("script-source");
/*     */     }
/* 224 */     if (!elements.isEmpty()) {
/* 225 */       Element inlineElement = (Element)elements.get(0);
/* 226 */       return "inline:" + DomUtils.getTextValue(inlineElement);
/*     */     }
/*     */ 
/* 229 */     readerContext.error("Must specify either 'script-source' or 'inline-script'.", element);
/* 230 */     return null;
/*     */   }
/*     */ 
/*     */   protected boolean shouldGenerateIdAsFallback()
/*     */   {
/* 239 */     return true;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.config.ScriptBeanDefinitionParser
 * JD-Core Version:    0.6.1
 */