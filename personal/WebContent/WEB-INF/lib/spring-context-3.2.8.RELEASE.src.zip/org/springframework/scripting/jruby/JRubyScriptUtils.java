/*     */ package org.springframework.scripting.jruby;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import org.jruby.Ruby;
/*     */ import org.jruby.RubyArray;
/*     */ import org.jruby.RubyException;
/*     */ import org.jruby.RubyNil;
/*     */ import org.jruby.ast.ClassNode;
/*     */ import org.jruby.ast.Colon2Node;
/*     */ import org.jruby.ast.NewlineNode;
/*     */ import org.jruby.ast.Node;
/*     */ import org.jruby.exceptions.JumpException;
/*     */ import org.jruby.exceptions.RaiseException;
/*     */ import org.jruby.javasupport.JavaEmbedUtils;
/*     */ import org.jruby.runtime.builtin.IRubyObject;
/*     */ import org.springframework.core.NestedRuntimeException;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class JRubyScriptUtils
/*     */ {
/*     */   public static Object createJRubyObject(String scriptSource, Class<?>[] interfaces)
/*     */     throws JumpException
/*     */   {
/*  67 */     return createJRubyObject(scriptSource, interfaces, ClassUtils.getDefaultClassLoader());
/*     */   }
/*     */ 
/*     */   public static Object createJRubyObject(String scriptSource, Class<?>[] interfaces, ClassLoader classLoader)
/*     */   {
/*  80 */     Ruby ruby = initializeRuntime();
/*     */ 
/*  82 */     Node scriptRootNode = ruby.parseEval(scriptSource, "", null, 0);
/*     */ 
/*  84 */     IRubyObject rubyObject = ruby.runNormally(scriptRootNode, false);
/*     */ 
/*  86 */     if ((rubyObject instanceof RubyNil)) {
/*  87 */       String className = findClassName(scriptRootNode);
/*  88 */       rubyObject = ruby.evalScriptlet("\n" + className + ".new");
/*     */     }
/*     */ 
/*  91 */     if ((rubyObject instanceof RubyNil)) {
/*  92 */       throw new IllegalStateException("Compilation of JRuby script returned RubyNil: " + rubyObject);
/*     */     }
/*     */ 
/*  95 */     return Proxy.newProxyInstance(classLoader, interfaces, new RubyObjectInvocationHandler(rubyObject, ruby));
/*     */   }
/*     */ 
/*     */   private static Ruby initializeRuntime()
/*     */   {
/* 102 */     return JavaEmbedUtils.initialize(Collections.EMPTY_LIST);
/*     */   }
/*     */ 
/*     */   private static String findClassName(Node rootNode)
/*     */   {
/* 111 */     ClassNode classNode = findClassNode(rootNode);
/* 112 */     if (classNode == null) {
/* 113 */       throw new IllegalArgumentException("Unable to determine class name for root node '" + rootNode + "'");
/*     */     }
/* 115 */     Colon2Node node = (Colon2Node)classNode.getCPath();
/* 116 */     return node.getName();
/*     */   }
/*     */ 
/*     */   private static ClassNode findClassNode(Node node)
/*     */   {
/* 125 */     if ((node instanceof ClassNode)) {
/* 126 */       return (ClassNode)node;
/*     */     }
/* 128 */     List children = node.childNodes();
/* 129 */     for (Node child : children) {
/* 130 */       if ((child instanceof ClassNode)) {
/* 131 */         return (ClassNode)child;
/*     */       }
/* 133 */       if ((child instanceof NewlineNode)) {
/* 134 */         NewlineNode nn = (NewlineNode)child;
/* 135 */         ClassNode found = findClassNode(nn.getNextNode());
/* 136 */         if (found != null) {
/* 137 */           return found;
/*     */         }
/*     */       }
/*     */     }
/* 141 */     for (Node child : children) {
/* 142 */       ClassNode found = findClassNode(child);
/* 143 */       if (found != null) {
/* 144 */         return found;
/*     */       }
/*     */     }
/* 147 */     return null;
/*     */   }
/*     */ 
/*     */   public static class JRubyExecutionException extends NestedRuntimeException
/*     */   {
/*     */     public JRubyExecutionException(RaiseException ex)
/*     */     {
/* 246 */       super(ex);
/*     */     }
/*     */ 
/*     */     private static String buildMessage(RaiseException ex) {
/* 250 */       RubyException rubyEx = ex.getException();
/* 251 */       return (rubyEx != null) && (rubyEx.message != null) ? rubyEx.message.toString() : "Unexpected JRuby error";
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class RubyObjectInvocationHandler
/*     */     implements InvocationHandler
/*     */   {
/*     */     private final IRubyObject rubyObject;
/*     */     private final Ruby ruby;
/*     */ 
/*     */     public RubyObjectInvocationHandler(IRubyObject rubyObject, Ruby ruby)
/*     */     {
/* 161 */       this.rubyObject = rubyObject;
/* 162 */       this.ruby = ruby;
/*     */     }
/*     */ 
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 166 */       if (ReflectionUtils.isEqualsMethod(method)) {
/* 167 */         return Boolean.valueOf(isProxyForSameRubyObject(args[0]));
/*     */       }
/* 169 */       if (ReflectionUtils.isHashCodeMethod(method)) {
/* 170 */         return Integer.valueOf(this.rubyObject.hashCode());
/*     */       }
/* 172 */       if (ReflectionUtils.isToStringMethod(method)) {
/* 173 */         String toStringResult = this.rubyObject.toString();
/* 174 */         if (!StringUtils.hasText(toStringResult)) {
/* 175 */           toStringResult = ObjectUtils.identityToString(this.rubyObject);
/*     */         }
/* 177 */         return "JRuby object [" + toStringResult + "]";
/*     */       }
/*     */       try {
/* 180 */         IRubyObject[] rubyArgs = convertToRuby(args);
/* 181 */         IRubyObject rubyResult = this.rubyObject.callMethod(this.ruby.getCurrentContext(), method.getName(), rubyArgs);
/*     */ 
/* 183 */         return convertFromRuby(rubyResult, method.getReturnType());
/*     */       }
/*     */       catch (RaiseException ex) {
/* 186 */         throw new JRubyScriptUtils.JRubyExecutionException(ex);
/*     */       }
/*     */     }
/*     */ 
/*     */     private boolean isProxyForSameRubyObject(Object other) {
/* 191 */       if (!Proxy.isProxyClass(other.getClass())) {
/* 192 */         return false;
/*     */       }
/* 194 */       InvocationHandler ih = Proxy.getInvocationHandler(other);
/* 195 */       return ((ih instanceof RubyObjectInvocationHandler)) && (this.rubyObject.equals(((RubyObjectInvocationHandler)ih).rubyObject));
/*     */     }
/*     */ 
/*     */     private IRubyObject[] convertToRuby(Object[] javaArgs)
/*     */     {
/* 200 */       if ((javaArgs == null) || (javaArgs.length == 0)) {
/* 201 */         return new IRubyObject[0];
/*     */       }
/* 203 */       IRubyObject[] rubyArgs = new IRubyObject[javaArgs.length];
/* 204 */       for (int i = 0; i < javaArgs.length; i++) {
/* 205 */         rubyArgs[i] = JavaEmbedUtils.javaToRuby(this.ruby, javaArgs[i]);
/*     */       }
/* 207 */       return rubyArgs;
/*     */     }
/*     */ 
/*     */     private Object convertFromRuby(IRubyObject rubyResult, Class<?> returnType) {
/* 211 */       Object result = JavaEmbedUtils.rubyToJava(this.ruby, rubyResult, returnType);
/* 212 */       if (((result instanceof RubyArray)) && (returnType.isArray())) {
/* 213 */         result = convertFromRubyArray(((RubyArray)result).toJavaArray(), returnType);
/*     */       }
/* 215 */       return result;
/*     */     }
/*     */ 
/*     */     private Object convertFromRubyArray(IRubyObject[] rubyArray, Class<?> returnType) {
/* 219 */       Class targetType = returnType.getComponentType();
/* 220 */       Object javaArray = Array.newInstance(targetType, rubyArray.length);
/* 221 */       for (int i = 0; i < rubyArray.length; i++) {
/* 222 */         IRubyObject rubyObject = rubyArray[i];
/* 223 */         Array.set(javaArray, i, convertFromRuby(rubyObject, targetType));
/*     */       }
/* 225 */       return javaArray;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.jruby.JRubyScriptUtils
 * JD-Core Version:    0.6.1
 */