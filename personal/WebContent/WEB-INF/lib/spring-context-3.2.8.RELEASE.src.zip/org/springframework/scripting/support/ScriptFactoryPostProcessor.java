/*     */ package org.springframework.scripting.support;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.TargetSource;
/*     */ import org.springframework.aop.framework.AopInfrastructureBean;
/*     */ import org.springframework.aop.framework.ProxyFactory;
/*     */ import org.springframework.aop.support.DelegatingIntroductionInterceptor;
/*     */ import org.springframework.asm.Type;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.PropertyValue;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanCreationException;
/*     */ import org.springframework.beans.factory.BeanCurrentlyInCreationException;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.beans.factory.config.ConstructorArgumentValues;
/*     */ import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessorAdapter;
/*     */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionValidationException;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.beans.factory.support.GenericBeanDefinition;
/*     */ import org.springframework.cglib.core.Signature;
/*     */ import org.springframework.cglib.proxy.InterfaceMaker;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.Conventions;
/*     */ import org.springframework.core.Ordered;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.scripting.ScriptFactory;
/*     */ import org.springframework.scripting.ScriptSource;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ScriptFactoryPostProcessor extends InstantiationAwareBeanPostProcessorAdapter
/*     */   implements BeanClassLoaderAware, BeanFactoryAware, ResourceLoaderAware, DisposableBean, Ordered
/*     */ {
/*     */   public static final String INLINE_SCRIPT_PREFIX = "inline:";
/* 150 */   public static final String REFRESH_CHECK_DELAY_ATTRIBUTE = Conventions.getQualifiedAttributeName(ScriptFactoryPostProcessor.class, "refreshCheckDelay");
/*     */ 
/* 153 */   public static final String PROXY_TARGET_CLASS_ATTRIBUTE = Conventions.getQualifiedAttributeName(ScriptFactoryPostProcessor.class, "proxyTargetClass");
/*     */ 
/* 156 */   public static final String LANGUAGE_ATTRIBUTE = Conventions.getQualifiedAttributeName(ScriptFactoryPostProcessor.class, "language");
/*     */   private static final String SCRIPT_FACTORY_NAME_PREFIX = "scriptFactory.";
/*     */   private static final String SCRIPTED_OBJECT_NAME_PREFIX = "scriptedObject.";
/* 164 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/* 166 */   private long defaultRefreshCheckDelay = -1L;
/*     */ 
/* 168 */   private boolean defaultProxyTargetClass = false;
/*     */ 
/* 170 */   private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */   private ConfigurableBeanFactory beanFactory;
/* 174 */   private ResourceLoader resourceLoader = new DefaultResourceLoader();
/*     */ 
/* 176 */   final DefaultListableBeanFactory scriptBeanFactory = new DefaultListableBeanFactory();
/*     */ 
/* 179 */   private final Map<String, ScriptSource> scriptSourceCache = new HashMap();
/*     */ 
/*     */   public void setDefaultRefreshCheckDelay(long defaultRefreshCheckDelay)
/*     */   {
/* 190 */     this.defaultRefreshCheckDelay = defaultRefreshCheckDelay;
/*     */   }
/*     */ 
/*     */   public void setDefaultProxyTargetClass(boolean defaultProxyTargetClass)
/*     */   {
/* 198 */     this.defaultProxyTargetClass = defaultProxyTargetClass;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader)
/*     */   {
/* 203 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory)
/*     */   {
/* 208 */     if (!(beanFactory instanceof ConfigurableBeanFactory)) {
/* 209 */       throw new IllegalStateException("ScriptFactoryPostProcessor doesn't work with a BeanFactory which does not implement ConfigurableBeanFactory: " + beanFactory.getClass());
/*     */     }
/*     */ 
/* 212 */     this.beanFactory = ((ConfigurableBeanFactory)beanFactory);
/*     */ 
/* 215 */     this.scriptBeanFactory.setParentBeanFactory(this.beanFactory);
/*     */ 
/* 218 */     this.scriptBeanFactory.copyConfigurationFrom(this.beanFactory);
/*     */ 
/* 222 */     for (Iterator it = this.scriptBeanFactory.getBeanPostProcessors().iterator(); it.hasNext(); )
/* 223 */       if ((it.next() instanceof AopInfrastructureBean))
/* 224 */         it.remove();
/*     */   }
/*     */ 
/*     */   public void setResourceLoader(ResourceLoader resourceLoader)
/*     */   {
/* 231 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */   public int getOrder()
/*     */   {
/* 236 */     return -2147483648;
/*     */   }
/*     */ 
/*     */   public Class<?> predictBeanType(Class<?> beanClass, String beanName)
/*     */   {
/* 242 */     if (!ScriptFactory.class.isAssignableFrom(beanClass)) {
/* 243 */       return null;
/*     */     }
/*     */ 
/* 246 */     BeanDefinition bd = this.beanFactory.getMergedBeanDefinition(beanName);
/*     */     try
/*     */     {
/* 249 */       String scriptFactoryBeanName = "scriptFactory." + beanName;
/* 250 */       String scriptedObjectBeanName = "scriptedObject." + beanName;
/* 251 */       prepareScriptBeans(bd, scriptFactoryBeanName, scriptedObjectBeanName);
/*     */ 
/* 253 */       ScriptFactory scriptFactory = (ScriptFactory)this.scriptBeanFactory.getBean(scriptFactoryBeanName, ScriptFactory.class);
/* 254 */       ScriptSource scriptSource = getScriptSource(scriptFactoryBeanName, scriptFactory.getScriptSourceLocator());
/* 255 */       Class[] interfaces = scriptFactory.getScriptInterfaces();
/*     */ 
/* 257 */       Class scriptedType = scriptFactory.getScriptedObjectType(scriptSource);
/* 258 */       if (scriptedType != null) {
/* 259 */         return scriptedType;
/*     */       }
/* 261 */       if (!ObjectUtils.isEmpty(interfaces)) {
/* 262 */         return interfaces.length == 1 ? interfaces[0] : createCompositeInterface(interfaces);
/*     */       }
/*     */ 
/* 265 */       if (bd.isSingleton()) {
/* 266 */         Object bean = this.scriptBeanFactory.getBean(scriptedObjectBeanName);
/* 267 */         if (bean != null) {
/* 268 */           return bean.getClass();
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 274 */       if (((ex instanceof BeanCreationException)) && ((((BeanCreationException)ex).getMostSpecificCause() instanceof BeanCurrentlyInCreationException)))
/*     */       {
/* 276 */         if (this.logger.isTraceEnabled()) {
/* 277 */           this.logger.trace("Could not determine scripted object type for bean '" + beanName + "': " + ex.getMessage());
/*     */         }
/*     */ 
/*     */       }
/* 282 */       else if (this.logger.isDebugEnabled()) {
/* 283 */         this.logger.debug("Could not determine scripted object type for bean '" + beanName + "'", ex);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 288 */     return null;
/*     */   }
/*     */ 
/*     */   public Object postProcessBeforeInstantiation(Class<?> beanClass, String beanName)
/*     */   {
/* 294 */     if (!ScriptFactory.class.isAssignableFrom(beanClass)) {
/* 295 */       return null;
/*     */     }
/*     */ 
/* 298 */     BeanDefinition bd = this.beanFactory.getMergedBeanDefinition(beanName);
/* 299 */     String scriptFactoryBeanName = "scriptFactory." + beanName;
/* 300 */     String scriptedObjectBeanName = "scriptedObject." + beanName;
/* 301 */     prepareScriptBeans(bd, scriptFactoryBeanName, scriptedObjectBeanName);
/*     */ 
/* 303 */     ScriptFactory scriptFactory = (ScriptFactory)this.scriptBeanFactory.getBean(scriptFactoryBeanName, ScriptFactory.class);
/* 304 */     ScriptSource scriptSource = getScriptSource(scriptFactoryBeanName, scriptFactory.getScriptSourceLocator());
/* 305 */     boolean isFactoryBean = false;
/*     */     try {
/* 307 */       Class scriptedObjectType = scriptFactory.getScriptedObjectType(scriptSource);
/*     */ 
/* 309 */       if (scriptedObjectType != null)
/* 310 */         isFactoryBean = FactoryBean.class.isAssignableFrom(scriptedObjectType);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 314 */       throw new BeanCreationException(beanName, "Could not determine scripted object type for " + scriptFactory, ex);
/*     */     }
/*     */ 
/* 318 */     long refreshCheckDelay = resolveRefreshCheckDelay(bd);
/* 319 */     if (refreshCheckDelay >= 0L) {
/* 320 */       Class[] interfaces = scriptFactory.getScriptInterfaces();
/* 321 */       RefreshableScriptTargetSource ts = new RefreshableScriptTargetSource(this.scriptBeanFactory, scriptedObjectBeanName, scriptFactory, scriptSource, isFactoryBean);
/*     */ 
/* 323 */       boolean proxyTargetClass = resolveProxyTargetClass(bd);
/* 324 */       String language = (String)bd.getAttribute(LANGUAGE_ATTRIBUTE);
/* 325 */       if ((proxyTargetClass) && ((language == null) || (!language.equals("groovy")))) {
/* 326 */         throw new BeanDefinitionValidationException("Cannot use proxyTargetClass=true with script beans where language is not 'groovy': '" + language + "'");
/*     */       }
/*     */ 
/* 330 */       ts.setRefreshCheckDelay(refreshCheckDelay);
/* 331 */       return createRefreshableProxy(ts, interfaces, proxyTargetClass);
/*     */     }
/*     */ 
/* 334 */     if (isFactoryBean) {
/* 335 */       scriptedObjectBeanName = "&" + scriptedObjectBeanName;
/*     */     }
/* 337 */     return this.scriptBeanFactory.getBean(scriptedObjectBeanName);
/*     */   }
/*     */ 
/*     */   protected void prepareScriptBeans(BeanDefinition bd, String scriptFactoryBeanName, String scriptedObjectBeanName)
/*     */   {
/* 351 */     synchronized (this.scriptBeanFactory) {
/* 352 */       if (!this.scriptBeanFactory.containsBeanDefinition(scriptedObjectBeanName))
/*     */       {
/* 354 */         this.scriptBeanFactory.registerBeanDefinition(scriptFactoryBeanName, createScriptFactoryBeanDefinition(bd));
/*     */ 
/* 356 */         ScriptFactory scriptFactory = (ScriptFactory)this.scriptBeanFactory.getBean(scriptFactoryBeanName, ScriptFactory.class);
/*     */ 
/* 358 */         ScriptSource scriptSource = getScriptSource(scriptFactoryBeanName, scriptFactory.getScriptSourceLocator());
/*     */ 
/* 360 */         Class[] interfaces = scriptFactory.getScriptInterfaces();
/*     */ 
/* 362 */         Class[] scriptedInterfaces = interfaces;
/* 363 */         if ((scriptFactory.requiresConfigInterface()) && (!bd.getPropertyValues().isEmpty())) {
/* 364 */           Class configInterface = createConfigInterface(bd, interfaces);
/* 365 */           scriptedInterfaces = (Class[])ObjectUtils.addObjectToArray(interfaces, configInterface);
/*     */         }
/*     */ 
/* 368 */         BeanDefinition objectBd = createScriptedObjectBeanDefinition(bd, scriptFactoryBeanName, scriptSource, scriptedInterfaces);
/*     */ 
/* 370 */         long refreshCheckDelay = resolveRefreshCheckDelay(bd);
/* 371 */         if (refreshCheckDelay >= 0L) {
/* 372 */           objectBd.setScope("prototype");
/*     */         }
/*     */ 
/* 375 */         this.scriptBeanFactory.registerBeanDefinition(scriptedObjectBeanName, objectBd);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected long resolveRefreshCheckDelay(BeanDefinition beanDefinition)
/*     */   {
/* 391 */     long refreshCheckDelay = this.defaultRefreshCheckDelay;
/* 392 */     Object attributeValue = beanDefinition.getAttribute(REFRESH_CHECK_DELAY_ATTRIBUTE);
/* 393 */     if ((attributeValue instanceof Number)) {
/* 394 */       refreshCheckDelay = ((Number)attributeValue).longValue();
/*     */     }
/* 396 */     else if ((attributeValue instanceof String)) {
/* 397 */       refreshCheckDelay = Long.parseLong((String)attributeValue);
/*     */     }
/* 399 */     else if (attributeValue != null) {
/* 400 */       throw new BeanDefinitionStoreException("Invalid refresh check delay attribute [" + REFRESH_CHECK_DELAY_ATTRIBUTE + "] with value '" + attributeValue + "': needs to be of type Number or String");
/*     */     }
/*     */ 
/* 404 */     return refreshCheckDelay;
/*     */   }
/*     */ 
/*     */   protected boolean resolveProxyTargetClass(BeanDefinition beanDefinition) {
/* 408 */     boolean proxyTargetClass = this.defaultProxyTargetClass;
/* 409 */     Object attributeValue = beanDefinition.getAttribute(PROXY_TARGET_CLASS_ATTRIBUTE);
/* 410 */     if ((attributeValue instanceof Boolean)) {
/* 411 */       proxyTargetClass = ((Boolean)attributeValue).booleanValue();
/*     */     }
/* 413 */     else if ((attributeValue instanceof String)) {
/* 414 */       proxyTargetClass = Boolean.valueOf((String)attributeValue).booleanValue();
/*     */     }
/* 416 */     else if (attributeValue != null) {
/* 417 */       throw new BeanDefinitionStoreException("Invalid proxy target class attribute [" + PROXY_TARGET_CLASS_ATTRIBUTE + "] with value '" + attributeValue + "': needs to be of type Boolean or String");
/*     */     }
/*     */ 
/* 421 */     return proxyTargetClass;
/*     */   }
/*     */ 
/*     */   protected BeanDefinition createScriptFactoryBeanDefinition(BeanDefinition bd)
/*     */   {
/* 433 */     GenericBeanDefinition scriptBd = new GenericBeanDefinition();
/* 434 */     scriptBd.setBeanClassName(bd.getBeanClassName());
/* 435 */     scriptBd.getConstructorArgumentValues().addArgumentValues(bd.getConstructorArgumentValues());
/* 436 */     return scriptBd;
/*     */   }
/*     */ 
/*     */   protected ScriptSource getScriptSource(String beanName, String scriptSourceLocator)
/*     */   {
/* 448 */     synchronized (this.scriptSourceCache) {
/* 449 */       ScriptSource scriptSource = (ScriptSource)this.scriptSourceCache.get(beanName);
/* 450 */       if (scriptSource == null) {
/* 451 */         scriptSource = convertToScriptSource(beanName, scriptSourceLocator, this.resourceLoader);
/* 452 */         this.scriptSourceCache.put(beanName, scriptSource);
/*     */       }
/* 454 */       return scriptSource;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected ScriptSource convertToScriptSource(String beanName, String scriptSourceLocator, ResourceLoader resourceLoader)
/*     */   {
/* 471 */     if (scriptSourceLocator.startsWith("inline:")) {
/* 472 */       return new StaticScriptSource(scriptSourceLocator.substring("inline:".length()), beanName);
/*     */     }
/*     */ 
/* 475 */     return new ResourceScriptSource(resourceLoader.getResource(scriptSourceLocator));
/*     */   }
/*     */ 
/*     */   protected Class<?> createConfigInterface(BeanDefinition bd, Class<?>[] interfaces)
/*     */   {
/* 494 */     InterfaceMaker maker = new InterfaceMaker();
/* 495 */     PropertyValue[] pvs = bd.getPropertyValues().getPropertyValues();
/* 496 */     for (PropertyValue pv : pvs) {
/* 497 */       String propertyName = pv.getName();
/* 498 */       Class propertyType = BeanUtils.findPropertyType(propertyName, interfaces);
/* 499 */       String setterName = "set" + StringUtils.capitalize(propertyName);
/* 500 */       Signature signature = new Signature(setterName, Type.VOID_TYPE, new Type[] { Type.getType(propertyType) });
/* 501 */       maker.add(signature, new Type[0]);
/*     */     }
/* 503 */     if ((bd instanceof AbstractBeanDefinition)) {
/* 504 */       AbstractBeanDefinition abd = (AbstractBeanDefinition)bd;
/* 505 */       if (abd.getInitMethodName() != null) {
/* 506 */         Signature signature = new Signature(abd.getInitMethodName(), Type.VOID_TYPE, new Type[0]);
/* 507 */         maker.add(signature, new Type[0]);
/*     */       }
/* 509 */       if (abd.getDestroyMethodName() != null) {
/* 510 */         Signature signature = new Signature(abd.getDestroyMethodName(), Type.VOID_TYPE, new Type[0]);
/* 511 */         maker.add(signature, new Type[0]);
/*     */       }
/*     */     }
/* 514 */     return maker.create();
/*     */   }
/*     */ 
/*     */   protected Class<?> createCompositeInterface(Class<?>[] interfaces)
/*     */   {
/* 527 */     return ClassUtils.createCompositeInterface(interfaces, this.beanClassLoader);
/*     */   }
/*     */ 
/*     */   protected BeanDefinition createScriptedObjectBeanDefinition(BeanDefinition bd, String scriptFactoryBeanName, ScriptSource scriptSource, Class<?>[] interfaces)
/*     */   {
/* 544 */     GenericBeanDefinition objectBd = new GenericBeanDefinition(bd);
/* 545 */     objectBd.setFactoryBeanName(scriptFactoryBeanName);
/* 546 */     objectBd.setFactoryMethodName("getScriptedObject");
/* 547 */     objectBd.getConstructorArgumentValues().clear();
/* 548 */     objectBd.getConstructorArgumentValues().addIndexedArgumentValue(0, scriptSource);
/* 549 */     objectBd.getConstructorArgumentValues().addIndexedArgumentValue(1, interfaces);
/* 550 */     return objectBd;
/*     */   }
/*     */ 
/*     */   protected Object createRefreshableProxy(TargetSource ts, Class<?>[] interfaces, boolean proxyTargetClass)
/*     */   {
/* 562 */     ProxyFactory proxyFactory = new ProxyFactory();
/* 563 */     proxyFactory.setTargetSource(ts);
/* 564 */     ClassLoader classLoader = this.beanClassLoader;
/*     */ 
/* 566 */     if (interfaces == null) {
/* 567 */       interfaces = ClassUtils.getAllInterfacesForClass(ts.getTargetClass(), this.beanClassLoader);
/*     */     }
/* 569 */     proxyFactory.setInterfaces(interfaces);
/* 570 */     if (proxyTargetClass) {
/* 571 */       classLoader = null;
/* 572 */       proxyFactory.setProxyTargetClass(proxyTargetClass);
/*     */     }
/*     */ 
/* 575 */     DelegatingIntroductionInterceptor introduction = new DelegatingIntroductionInterceptor(ts);
/* 576 */     introduction.suppressInterface(TargetSource.class);
/* 577 */     proxyFactory.addAdvice(introduction);
/*     */ 
/* 579 */     return proxyFactory.getProxy(classLoader);
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 587 */     this.scriptBeanFactory.destroySingletons();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.support.ScriptFactoryPostProcessor
 * JD-Core Version:    0.6.1
 */