/*     */ package org.springframework.scripting.bsh;
/*     */ 
/*     */ import bsh.EvalError;
/*     */ import bsh.Interpreter;
/*     */ import bsh.Primitive;
/*     */ import bsh.XThis;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import org.springframework.core.NestedRuntimeException;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public abstract class BshScriptUtils
/*     */ {
/*     */   public static Object createBshObject(String scriptSource)
/*     */     throws EvalError
/*     */   {
/*  51 */     return createBshObject(scriptSource, null, null);
/*     */   }
/*     */ 
/*     */   public static Object createBshObject(String scriptSource, Class<?>[] scriptInterfaces)
/*     */     throws EvalError
/*     */   {
/*  70 */     return createBshObject(scriptSource, scriptInterfaces, ClassUtils.getDefaultClassLoader());
/*     */   }
/*     */ 
/*     */   public static Object createBshObject(String scriptSource, Class<?>[] scriptInterfaces, ClassLoader classLoader)
/*     */     throws EvalError
/*     */   {
/*  90 */     Object result = evaluateBshScript(scriptSource, scriptInterfaces, classLoader);
/*  91 */     if ((result instanceof Class)) {
/*  92 */       Class clazz = (Class)result;
/*     */       try {
/*  94 */         return clazz.newInstance();
/*     */       }
/*     */       catch (Throwable ex) {
/*  97 */         throw new IllegalStateException("Could not instantiate script class [" + clazz.getName() + "]. Root cause is " + ex);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 102 */     return result;
/*     */   }
/*     */ 
/*     */   static Class<?> determineBshObjectType(String scriptSource)
/*     */     throws EvalError
/*     */   {
/* 117 */     Assert.hasText(scriptSource, "Script source must not be empty");
/* 118 */     Interpreter interpreter = new Interpreter();
/* 119 */     Object result = interpreter.eval(scriptSource);
/* 120 */     if ((result instanceof Class)) {
/* 121 */       return (Class)result;
/*     */     }
/* 123 */     if (result != null) {
/* 124 */       return result.getClass();
/*     */     }
/*     */ 
/* 127 */     return null;
/*     */   }
/*     */ 
/*     */   static Object evaluateBshScript(String scriptSource, Class<?>[] scriptInterfaces, ClassLoader classLoader)
/*     */     throws EvalError
/*     */   {
/* 149 */     Assert.hasText(scriptSource, "Script source must not be empty");
/* 150 */     Interpreter interpreter = new Interpreter();
/* 151 */     Object result = interpreter.eval(scriptSource);
/* 152 */     if (result != null) {
/* 153 */       return result;
/*     */     }
/*     */ 
/* 157 */     Assert.notEmpty(scriptInterfaces, "Given script requires a script proxy: At least one script interface is required.");
/*     */ 
/* 159 */     XThis xt = (XThis)interpreter.eval("return this");
/* 160 */     return Proxy.newProxyInstance(classLoader, scriptInterfaces, new BshObjectInvocationHandler(xt));
/*     */   }
/*     */ 
/*     */   public static class BshExecutionException extends NestedRuntimeException
/*     */   {
/*     */     private BshExecutionException(EvalError ex)
/*     */     {
/* 219 */       super(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class BshObjectInvocationHandler
/*     */     implements InvocationHandler
/*     */   {
/*     */     private final XThis xt;
/*     */ 
/*     */     public BshObjectInvocationHandler(XThis xt)
/*     */     {
/* 173 */       this.xt = xt;
/*     */     }
/*     */ 
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 177 */       if (ReflectionUtils.isEqualsMethod(method)) {
/* 178 */         return Boolean.valueOf(isProxyForSameBshObject(args[0]));
/*     */       }
/* 180 */       if (ReflectionUtils.isHashCodeMethod(method)) {
/* 181 */         return Integer.valueOf(this.xt.hashCode());
/*     */       }
/* 183 */       if (ReflectionUtils.isToStringMethod(method))
/* 184 */         return "BeanShell object [" + this.xt + "]";
/*     */       try
/*     */       {
/* 187 */         Object result = this.xt.invokeMethod(method.getName(), args);
/* 188 */         if ((result == Primitive.NULL) || (result == Primitive.VOID)) {
/* 189 */           return null;
/*     */         }
/* 191 */         if ((result instanceof Primitive)) {
/* 192 */           return ((Primitive)result).getValue();
/*     */         }
/* 194 */         return result;
/*     */       }
/*     */       catch (EvalError ex) {
/* 197 */         throw new BshScriptUtils.BshExecutionException(ex, null);
/*     */       }
/*     */     }
/*     */ 
/*     */     private boolean isProxyForSameBshObject(Object other) {
/* 202 */       if (!Proxy.isProxyClass(other.getClass())) {
/* 203 */         return false;
/*     */       }
/* 205 */       InvocationHandler ih = Proxy.getInvocationHandler(other);
/* 206 */       return ((ih instanceof BshObjectInvocationHandler)) && (this.xt.equals(((BshObjectInvocationHandler)ih).xt));
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.bsh.BshScriptUtils
 * JD-Core Version:    0.6.1
 */