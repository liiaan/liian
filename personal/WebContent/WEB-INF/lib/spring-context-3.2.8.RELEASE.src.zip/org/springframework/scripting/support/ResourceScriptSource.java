/*     */ package org.springframework.scripting.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.scripting.ScriptSource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ResourceScriptSource
/*     */   implements ScriptSource
/*     */ {
/*  51 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private final Resource resource;
/*  55 */   private String encoding = "UTF-8";
/*     */ 
/*  57 */   private long lastModified = -1L;
/*     */ 
/*  59 */   private final Object lastModifiedMonitor = new Object();
/*     */ 
/*     */   public ResourceScriptSource(Resource resource)
/*     */   {
/*  67 */     Assert.notNull(resource, "Resource must not be null");
/*  68 */     this.resource = resource;
/*     */   }
/*     */ 
/*     */   public final Resource getResource()
/*     */   {
/*  76 */     return this.resource;
/*     */   }
/*     */ 
/*     */   public void setEncoding(String encoding)
/*     */   {
/*  85 */     this.encoding = encoding;
/*     */   }
/*     */ 
/*     */   public String getScriptAsString() throws IOException
/*     */   {
/*  90 */     synchronized (this.lastModifiedMonitor) {
/*  91 */       this.lastModified = retrieveLastModifiedTime();
/*     */     }
/*  93 */     InputStream stream = this.resource.getInputStream();
/*  94 */     Object reader = StringUtils.hasText(this.encoding) ? new InputStreamReader(stream, this.encoding) : new InputStreamReader(stream);
/*     */ 
/*  96 */     return FileCopyUtils.copyToString((Reader)reader);
/*     */   }
/*     */ 
/*     */   public boolean isModified() {
/* 100 */     synchronized (this.lastModifiedMonitor) {
/* 101 */       return (this.lastModified < 0L) || (retrieveLastModifiedTime() > this.lastModified);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected long retrieveLastModifiedTime()
/*     */   {
/*     */     try
/*     */     {
/* 111 */       return getResource().lastModified();
/*     */     }
/*     */     catch (IOException ex) {
/* 114 */       if (this.logger.isDebugEnabled()) {
/* 115 */         this.logger.debug(getResource() + " could not be resolved in the file system - " + "current timestamp not available for script modification check", ex);
/*     */       }
/*     */     }
/* 118 */     return 0L;
/*     */   }
/*     */ 
/*     */   public String suggestedClassName()
/*     */   {
/* 123 */     return StringUtils.stripFilenameExtension(getResource().getFilename());
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 128 */     return this.resource.toString();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.support.ResourceScriptSource
 * JD-Core Version:    0.6.1
 */