/*    */ package org.springframework.scripting.support;
/*    */ 
/*    */ import org.springframework.scripting.ScriptSource;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class StaticScriptSource
/*    */   implements ScriptSource
/*    */ {
/*    */   private String script;
/*    */   private boolean modified;
/*    */   private String className;
/*    */ 
/*    */   public StaticScriptSource(String script)
/*    */   {
/* 46 */     setScript(script);
/*    */   }
/*    */ 
/*    */   public StaticScriptSource(String script, String className)
/*    */   {
/* 56 */     setScript(script);
/* 57 */     this.className = className;
/*    */   }
/*    */ 
/*    */   public synchronized void setScript(String script)
/*    */   {
/* 65 */     Assert.hasText(script, "Script must not be empty");
/* 66 */     this.modified = (!script.equals(this.script));
/* 67 */     this.script = script;
/*    */   }
/*    */ 
/*    */   public synchronized String getScriptAsString()
/*    */   {
/* 72 */     this.modified = false;
/* 73 */     return this.script;
/*    */   }
/*    */ 
/*    */   public synchronized boolean isModified() {
/* 77 */     return this.modified;
/*    */   }
/*    */ 
/*    */   public String suggestedClassName() {
/* 81 */     return this.className;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 87 */     return "static script" + (this.className != null ? " [" + this.className + "]" : "");
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.support.StaticScriptSource
 * JD-Core Version:    0.6.1
 */