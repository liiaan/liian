/*    */ package org.springframework.scripting.config;
/*    */ 
/*    */ import org.springframework.beans.factory.xml.NamespaceHandlerSupport;
/*    */ 
/*    */ public class LangNamespaceHandler extends NamespaceHandlerSupport
/*    */ {
/*    */   public void init()
/*    */   {
/* 43 */     registerScriptBeanDefinitionParser("groovy", "org.springframework.scripting.groovy.GroovyScriptFactory");
/* 44 */     registerScriptBeanDefinitionParser("jruby", "org.springframework.scripting.jruby.JRubyScriptFactory");
/* 45 */     registerScriptBeanDefinitionParser("bsh", "org.springframework.scripting.bsh.BshScriptFactory");
/* 46 */     registerBeanDefinitionParser("defaults", new ScriptingDefaultsParser());
/*    */   }
/*    */ 
/*    */   private void registerScriptBeanDefinitionParser(String key, String scriptFactoryClassName) {
/* 50 */     registerBeanDefinitionParser(key, new ScriptBeanDefinitionParser(scriptFactoryClassName));
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.config.LangNamespaceHandler
 * JD-Core Version:    0.6.1
 */