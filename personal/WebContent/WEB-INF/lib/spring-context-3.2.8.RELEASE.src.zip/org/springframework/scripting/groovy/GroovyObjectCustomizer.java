package org.springframework.scripting.groovy;

import groovy.lang.GroovyObject;

public abstract interface GroovyObjectCustomizer
{
  public abstract void customize(GroovyObject paramGroovyObject);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scripting.groovy.GroovyObjectCustomizer
 * JD-Core Version:    0.6.1
 */