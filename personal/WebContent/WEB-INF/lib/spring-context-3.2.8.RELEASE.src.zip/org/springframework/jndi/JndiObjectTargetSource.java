/*     */ package org.springframework.jndi;
/*     */ 
/*     */ import javax.naming.NamingException;
/*     */ import org.springframework.aop.TargetSource;
/*     */ 
/*     */ public class JndiObjectTargetSource extends JndiObjectLocator
/*     */   implements TargetSource
/*     */ {
/*  63 */   private boolean lookupOnStartup = true;
/*     */ 
/*  65 */   private boolean cache = true;
/*     */   private Object cachedObject;
/*     */   private Class targetClass;
/*     */ 
/*     */   public void setLookupOnStartup(boolean lookupOnStartup)
/*     */   {
/*  79 */     this.lookupOnStartup = lookupOnStartup;
/*     */   }
/*     */ 
/*     */   public void setCache(boolean cache)
/*     */   {
/*  90 */     this.cache = cache;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() throws NamingException
/*     */   {
/*  95 */     super.afterPropertiesSet();
/*  96 */     if (this.lookupOnStartup) {
/*  97 */       Object object = lookup();
/*  98 */       if (this.cache) {
/*  99 */         this.cachedObject = object;
/*     */       }
/*     */       else
/* 102 */         this.targetClass = object.getClass();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Class<?> getTargetClass()
/*     */   {
/* 109 */     if (this.cachedObject != null) {
/* 110 */       return this.cachedObject.getClass();
/*     */     }
/* 112 */     if (this.targetClass != null) {
/* 113 */       return this.targetClass;
/*     */     }
/*     */ 
/* 116 */     return getExpectedType();
/*     */   }
/*     */ 
/*     */   public boolean isStatic()
/*     */   {
/* 121 */     return this.cachedObject != null;
/*     */   }
/*     */ 
/*     */   public Object getTarget() {
/*     */     try {
/* 126 */       if ((this.lookupOnStartup) || (!this.cache)) {
/* 127 */         return this.cachedObject != null ? this.cachedObject : lookup();
/*     */       }
/*     */ 
/* 130 */       synchronized (this) {
/* 131 */         if (this.cachedObject == null) {
/* 132 */           this.cachedObject = lookup();
/*     */         }
/* 134 */         return this.cachedObject;
/*     */       }
/*     */     }
/*     */     catch (NamingException ex)
/*     */     {
/* 139 */       throw new JndiLookupFailureException("JndiObjectTargetSource failed to obtain new target object", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void releaseTarget(Object target)
/*     */   {
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jndi.JndiObjectTargetSource
 * JD-Core Version:    0.6.1
 */