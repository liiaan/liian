/*     */ package org.springframework.jndi.support;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.naming.NameNotFoundException;
/*     */ import javax.naming.NamingException;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.BeanDefinitionStoreException;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanNotOfRequiredTypeException;
/*     */ import org.springframework.beans.factory.NoSuchBeanDefinitionException;
/*     */ import org.springframework.jndi.JndiLocatorSupport;
/*     */ import org.springframework.jndi.TypeMismatchNamingException;
/*     */ 
/*     */ public class SimpleJndiBeanFactory extends JndiLocatorSupport
/*     */   implements BeanFactory
/*     */ {
/*  63 */   private final Set<String> shareableResources = new HashSet();
/*     */ 
/*  66 */   private final Map<String, Object> singletonObjects = new HashMap();
/*     */ 
/*  69 */   private final Map<String, Class> resourceTypes = new HashMap();
/*     */ 
/*     */   public SimpleJndiBeanFactory()
/*     */   {
/*  73 */     setResourceRef(true);
/*     */   }
/*     */ 
/*     */   public void setShareableResources(String[] shareableResources)
/*     */   {
/*  84 */     this.shareableResources.addAll(Arrays.asList(shareableResources));
/*     */   }
/*     */ 
/*     */   public void addShareableResource(String shareableResource)
/*     */   {
/*  94 */     this.shareableResources.add(shareableResource);
/*     */   }
/*     */ 
/*     */   public Object getBean(String name)
/*     */     throws BeansException
/*     */   {
/* 104 */     return getBean(name, Object.class);
/*     */   }
/*     */ 
/*     */   public <T> T getBean(String name, Class<T> requiredType) throws BeansException {
/*     */     try {
/* 109 */       if (isSingleton(name)) {
/* 110 */         return doGetSingleton(name, requiredType);
/*     */       }
/*     */ 
/* 113 */       return lookup(name, requiredType);
/*     */     }
/*     */     catch (NameNotFoundException ex)
/*     */     {
/* 117 */       throw new NoSuchBeanDefinitionException(name, "not found in JNDI environment");
/*     */     }
/*     */     catch (TypeMismatchNamingException ex) {
/* 120 */       throw new BeanNotOfRequiredTypeException(name, ex.getRequiredType(), ex.getActualType());
/*     */     }
/*     */     catch (NamingException ex) {
/* 123 */       throw new BeanDefinitionStoreException("JNDI environment", name, "JNDI lookup failed", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public <T> T getBean(Class<T> requiredType) throws BeansException {
/* 128 */     return getBean(requiredType.getSimpleName(), requiredType);
/*     */   }
/*     */ 
/*     */   public Object getBean(String name, Object[] args) throws BeansException {
/* 132 */     if (args != null) {
/* 133 */       throw new UnsupportedOperationException("SimpleJndiBeanFactory does not support explicit bean creation arguments)");
/*     */     }
/*     */ 
/* 136 */     return getBean(name);
/*     */   }
/*     */ 
/*     */   public boolean containsBean(String name) {
/* 140 */     if ((this.singletonObjects.containsKey(name)) || (this.resourceTypes.containsKey(name)))
/* 141 */       return true;
/*     */     try
/*     */     {
/* 144 */       doGetType(name);
/* 145 */       return true;
/*     */     } catch (NamingException ex) {
/*     */     }
/* 148 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton(String name) throws NoSuchBeanDefinitionException
/*     */   {
/* 153 */     return this.shareableResources.contains(name);
/*     */   }
/*     */ 
/*     */   public boolean isPrototype(String name) throws NoSuchBeanDefinitionException {
/* 157 */     return !this.shareableResources.contains(name);
/*     */   }
/*     */ 
/*     */   public boolean isTypeMatch(String name, Class targetType) throws NoSuchBeanDefinitionException {
/* 161 */     Class type = getType(name);
/* 162 */     return (targetType == null) || ((type != null) && (targetType.isAssignableFrom(type)));
/*     */   }
/*     */ 
/*     */   public Class<?> getType(String name) throws NoSuchBeanDefinitionException {
/*     */     try {
/* 167 */       return doGetType(name);
/*     */     }
/*     */     catch (NameNotFoundException ex) {
/* 170 */       throw new NoSuchBeanDefinitionException(name, "not found in JNDI environment");
/*     */     } catch (NamingException ex) {
/*     */     }
/* 173 */     return null;
/*     */   }
/*     */ 
/*     */   public String[] getAliases(String name)
/*     */   {
/* 178 */     return new String[0];
/*     */   }
/*     */ 
/*     */   private <T> T doGetSingleton(String name, Class<T> requiredType)
/*     */     throws NamingException
/*     */   {
/* 184 */     synchronized (this.singletonObjects) {
/* 185 */       if (this.singletonObjects.containsKey(name)) {
/* 186 */         Object jndiObject = this.singletonObjects.get(name);
/* 187 */         if ((requiredType != null) && (!requiredType.isInstance(jndiObject))) {
/* 188 */           throw new TypeMismatchNamingException(convertJndiName(name), requiredType, jndiObject != null ? jndiObject.getClass() : null);
/*     */         }
/*     */ 
/* 191 */         return jndiObject;
/*     */       }
/* 193 */       Object jndiObject = lookup(name, requiredType);
/* 194 */       this.singletonObjects.put(name, jndiObject);
/* 195 */       return jndiObject;
/*     */     }
/*     */   }
/*     */ 
/*     */   private Class doGetType(String name) throws NamingException {
/* 200 */     if (isSingleton(name)) {
/* 201 */       Object jndiObject = doGetSingleton(name, null);
/* 202 */       return jndiObject != null ? jndiObject.getClass() : null;
/*     */     }
/*     */ 
/* 205 */     synchronized (this.resourceTypes) {
/* 206 */       if (this.resourceTypes.containsKey(name)) {
/* 207 */         return (Class)this.resourceTypes.get(name);
/*     */       }
/*     */ 
/* 210 */       Object jndiObject = lookup(name, null);
/* 211 */       Class type = jndiObject != null ? jndiObject.getClass() : null;
/* 212 */       this.resourceTypes.put(name, type);
/* 213 */       return type;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jndi.support.SimpleJndiBeanFactory
 * JD-Core Version:    0.6.1
 */