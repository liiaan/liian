/*    */ package org.springframework.jndi;
/*    */ 
/*    */ import javax.naming.NamingException;
/*    */ import org.springframework.core.NestedRuntimeException;
/*    */ 
/*    */ public class JndiLookupFailureException extends NestedRuntimeException
/*    */ {
/*    */   public JndiLookupFailureException(String msg, NamingException cause)
/*    */   {
/* 42 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jndi.JndiLookupFailureException
 * JD-Core Version:    0.6.1
 */