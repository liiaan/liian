/*    */ package org.springframework.validation;
/*    */ 
/*    */ import java.beans.PropertyEditor;
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.PropertyEditorRegistry;
/*    */ 
/*    */ public abstract interface BindingResult extends Errors
/*    */ {
/* 50 */   public static final String MODEL_KEY_PREFIX = BindingResult.class.getName() + ".";
/*    */ 
/*    */   public abstract Object getTarget();
/*    */ 
/*    */   public abstract Map<String, Object> getModel();
/*    */ 
/*    */   public abstract Object getRawFieldValue(String paramString);
/*    */ 
/*    */   public abstract PropertyEditor findEditor(String paramString, Class<?> paramClass);
/*    */ 
/*    */   public abstract PropertyEditorRegistry getPropertyEditorRegistry();
/*    */ 
/*    */   public abstract void addError(ObjectError paramObjectError);
/*    */ 
/*    */   public abstract String[] resolveMessageCodes(String paramString);
/*    */ 
/*    */   public abstract String[] resolveMessageCodes(String paramString1, String paramString2);
/*    */ 
/*    */   public abstract void recordSuppressedField(String paramString);
/*    */ 
/*    */   public abstract String[] getSuppressedFields();
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.validation.BindingResult
 * JD-Core Version:    0.6.1
 */