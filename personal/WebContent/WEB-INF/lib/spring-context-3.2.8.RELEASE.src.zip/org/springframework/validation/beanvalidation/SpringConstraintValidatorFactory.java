/*    */ package org.springframework.validation.beanvalidation;
/*    */ 
/*    */ import javax.validation.ConstraintValidator;
/*    */ import javax.validation.ConstraintValidatorFactory;
/*    */ import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class SpringConstraintValidatorFactory
/*    */   implements ConstraintValidatorFactory
/*    */ {
/*    */   private final AutowireCapableBeanFactory beanFactory;
/*    */ 
/*    */   public SpringConstraintValidatorFactory(AutowireCapableBeanFactory beanFactory)
/*    */   {
/* 44 */     Assert.notNull(beanFactory, "BeanFactory must not be null");
/* 45 */     this.beanFactory = beanFactory;
/*    */   }
/*    */ 
/*    */   public <T extends ConstraintValidator<?, ?>> T getInstance(Class<T> key)
/*    */   {
/* 50 */     return (ConstraintValidator)this.beanFactory.createBean(key);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.validation.beanvalidation.SpringConstraintValidatorFactory
 * JD-Core Version:    0.6.1
 */