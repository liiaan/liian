package org.springframework.validation;

public abstract interface Validator
{
  public abstract boolean supports(Class<?> paramClass);

  public abstract void validate(Object paramObject, Errors paramErrors);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.validation.Validator
 * JD-Core Version:    0.6.1
 */