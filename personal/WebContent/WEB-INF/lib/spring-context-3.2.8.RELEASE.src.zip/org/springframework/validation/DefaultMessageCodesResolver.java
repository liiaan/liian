/*     */ package org.springframework.validation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class DefaultMessageCodesResolver
/*     */   implements MessageCodesResolver, Serializable
/*     */ {
/*     */   public static final String CODE_SEPARATOR = ".";
/*  98 */   private static final MessageCodeFormatter DEFAULT_FORMATTER = Format.PREFIX_ERROR_CODE;
/*     */   private String prefix;
/*     */   private MessageCodeFormatter formatter;
/*     */ 
/*     */   public DefaultMessageCodesResolver()
/*     */   {
/* 101 */     this.prefix = "";
/*     */ 
/* 103 */     this.formatter = DEFAULT_FORMATTER;
/*     */   }
/*     */ 
/*     */   public void setPrefix(String prefix)
/*     */   {
/* 112 */     this.prefix = (prefix != null ? prefix : "");
/*     */   }
/*     */ 
/*     */   public void setMessageCodeFormatter(MessageCodeFormatter formatter)
/*     */   {
/* 122 */     this.formatter = (formatter == null ? DEFAULT_FORMATTER : formatter);
/*     */   }
/*     */ 
/*     */   protected String getPrefix()
/*     */   {
/* 130 */     return this.prefix;
/*     */   }
/*     */ 
/*     */   public String[] resolveMessageCodes(String errorCode, String objectName)
/*     */   {
/* 135 */     return resolveMessageCodes(errorCode, objectName, "", null);
/*     */   }
/*     */ 
/*     */   public String[] resolveMessageCodes(String errorCode, String objectName, String field, Class<?> fieldType)
/*     */   {
/* 148 */     Set codeList = new LinkedHashSet();
/* 149 */     List fieldList = new ArrayList();
/* 150 */     buildFieldList(field, fieldList);
/* 151 */     addCodes(codeList, errorCode, objectName, fieldList);
/* 152 */     int dotIndex = field.lastIndexOf('.');
/* 153 */     if (dotIndex != -1) {
/* 154 */       buildFieldList(field.substring(dotIndex + 1), fieldList);
/*     */     }
/* 156 */     addCodes(codeList, errorCode, null, fieldList);
/* 157 */     if (fieldType != null) {
/* 158 */       addCode(codeList, errorCode, null, fieldType.getName());
/*     */     }
/* 160 */     addCode(codeList, errorCode, null, null);
/* 161 */     return StringUtils.toStringArray(codeList);
/*     */   }
/*     */ 
/*     */   private void addCodes(Collection<String> codeList, String errorCode, String objectName, Iterable<String> fields) {
/* 165 */     for (String field : fields)
/* 166 */       addCode(codeList, errorCode, objectName, field);
/*     */   }
/*     */ 
/*     */   private void addCode(Collection<String> codeList, String errorCode, String objectName, String field)
/*     */   {
/* 171 */     codeList.add(postProcessMessageCode(this.formatter.format(errorCode, objectName, field)));
/*     */   }
/*     */ 
/*     */   protected void buildFieldList(String field, List<String> fieldList)
/*     */   {
/* 179 */     fieldList.add(field);
/* 180 */     String plainField = field;
/* 181 */     int keyIndex = plainField.lastIndexOf('[');
/* 182 */     while (keyIndex != -1) {
/* 183 */       int endKeyIndex = plainField.indexOf(']', keyIndex);
/* 184 */       if (endKeyIndex != -1) {
/* 185 */         plainField = plainField.substring(0, keyIndex) + plainField.substring(endKeyIndex + 1);
/* 186 */         fieldList.add(plainField);
/* 187 */         keyIndex = plainField.lastIndexOf('[');
/*     */       }
/*     */       else {
/* 190 */         keyIndex = -1;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected String postProcessMessageCode(String code)
/*     */   {
/* 203 */     return getPrefix() + code;
/*     */   }
/*     */ 
/*     */   public static abstract enum Format
/*     */     implements MessageCodeFormatter
/*     */   {
/* 222 */     PREFIX_ERROR_CODE, 
/*     */ 
/* 232 */     POSTFIX_ERROR_CODE;
/*     */ 
/*     */     public static String toDelimitedString(String[] elements)
/*     */     {
/* 244 */       StringBuilder rtn = new StringBuilder();
/* 245 */       for (String element : elements) {
/* 246 */         if (StringUtils.hasLength(element)) {
/* 247 */           rtn.append(rtn.length() == 0 ? "" : ".");
/* 248 */           rtn.append(element);
/*     */         }
/*     */       }
/* 251 */       return rtn.toString();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.validation.DefaultMessageCodesResolver
 * JD-Core Version:    0.6.1
 */