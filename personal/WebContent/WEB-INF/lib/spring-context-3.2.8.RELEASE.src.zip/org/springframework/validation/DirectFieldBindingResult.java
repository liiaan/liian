/*    */ package org.springframework.validation;
/*    */ 
/*    */ import org.springframework.beans.ConfigurablePropertyAccessor;
/*    */ import org.springframework.beans.PropertyAccessorFactory;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class DirectFieldBindingResult extends AbstractPropertyBindingResult
/*    */ {
/*    */   private final Object target;
/*    */   private transient ConfigurablePropertyAccessor directFieldAccessor;
/*    */ 
/*    */   public DirectFieldBindingResult(Object target, String objectName)
/*    */   {
/* 51 */     super(objectName);
/* 52 */     this.target = target;
/*    */   }
/*    */ 
/*    */   public final Object getTarget()
/*    */   {
/* 58 */     return this.target;
/*    */   }
/*    */ 
/*    */   public final ConfigurablePropertyAccessor getPropertyAccessor()
/*    */   {
/* 68 */     if (this.directFieldAccessor == null) {
/* 69 */       this.directFieldAccessor = createDirectFieldAccessor();
/* 70 */       this.directFieldAccessor.setExtractOldValueForEditor(true);
/*    */     }
/* 72 */     return this.directFieldAccessor;
/*    */   }
/*    */ 
/*    */   protected ConfigurablePropertyAccessor createDirectFieldAccessor()
/*    */   {
/* 80 */     Assert.state(this.target != null, "Cannot access fields on null target instance '" + getObjectName() + "'!");
/* 81 */     return PropertyAccessorFactory.forDirectFieldAccess(this.target);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.validation.DirectFieldBindingResult
 * JD-Core Version:    0.6.1
 */