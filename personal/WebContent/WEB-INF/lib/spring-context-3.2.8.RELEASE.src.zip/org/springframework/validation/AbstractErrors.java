/*     */ package org.springframework.validation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.EmptyStackException;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Stack;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class AbstractErrors
/*     */   implements Errors, Serializable
/*     */ {
/*  40 */   private String nestedPath = "";
/*     */ 
/*  42 */   private final Stack<String> nestedPathStack = new Stack();
/*     */ 
/*     */   public void setNestedPath(String nestedPath)
/*     */   {
/*  46 */     doSetNestedPath(nestedPath);
/*  47 */     this.nestedPathStack.clear();
/*     */   }
/*     */ 
/*     */   public String getNestedPath() {
/*  51 */     return this.nestedPath;
/*     */   }
/*     */ 
/*     */   public void pushNestedPath(String subPath) {
/*  55 */     this.nestedPathStack.push(getNestedPath());
/*  56 */     doSetNestedPath(getNestedPath() + subPath);
/*     */   }
/*     */ 
/*     */   public void popNestedPath() throws IllegalArgumentException {
/*     */     try {
/*  61 */       String formerNestedPath = (String)this.nestedPathStack.pop();
/*  62 */       doSetNestedPath(formerNestedPath);
/*     */     }
/*     */     catch (EmptyStackException ex) {
/*  65 */       throw new IllegalStateException("Cannot pop nested path: no nested path on stack");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void doSetNestedPath(String nestedPath)
/*     */   {
/*  74 */     if (nestedPath == null) {
/*  75 */       nestedPath = "";
/*     */     }
/*  77 */     nestedPath = canonicalFieldName(nestedPath);
/*  78 */     if ((nestedPath.length() > 0) && (!nestedPath.endsWith("."))) {
/*  79 */       nestedPath = nestedPath + ".";
/*     */     }
/*  81 */     this.nestedPath = nestedPath;
/*     */   }
/*     */ 
/*     */   protected String fixedField(String field)
/*     */   {
/*  89 */     if (StringUtils.hasLength(field)) {
/*  90 */       return getNestedPath() + canonicalFieldName(field);
/*     */     }
/*     */ 
/*  93 */     String path = getNestedPath();
/*  94 */     return path.endsWith(".") ? path.substring(0, path.length() - ".".length()) : path;
/*     */   }
/*     */ 
/*     */   protected String canonicalFieldName(String field)
/*     */   {
/* 106 */     return field;
/*     */   }
/*     */ 
/*     */   public void reject(String errorCode)
/*     */   {
/* 111 */     reject(errorCode, null, null);
/*     */   }
/*     */ 
/*     */   public void reject(String errorCode, String defaultMessage) {
/* 115 */     reject(errorCode, null, defaultMessage);
/*     */   }
/*     */ 
/*     */   public void rejectValue(String field, String errorCode) {
/* 119 */     rejectValue(field, errorCode, null, null);
/*     */   }
/*     */ 
/*     */   public void rejectValue(String field, String errorCode, String defaultMessage) {
/* 123 */     rejectValue(field, errorCode, null, defaultMessage);
/*     */   }
/*     */ 
/*     */   public boolean hasErrors()
/*     */   {
/* 128 */     return !getAllErrors().isEmpty();
/*     */   }
/*     */ 
/*     */   public int getErrorCount() {
/* 132 */     return getAllErrors().size();
/*     */   }
/*     */ 
/*     */   public List<ObjectError> getAllErrors() {
/* 136 */     List result = new LinkedList();
/* 137 */     result.addAll(getGlobalErrors());
/* 138 */     result.addAll(getFieldErrors());
/* 139 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   public boolean hasGlobalErrors() {
/* 143 */     return getGlobalErrorCount() > 0;
/*     */   }
/*     */ 
/*     */   public int getGlobalErrorCount() {
/* 147 */     return getGlobalErrors().size();
/*     */   }
/*     */ 
/*     */   public ObjectError getGlobalError() {
/* 151 */     List globalErrors = getGlobalErrors();
/* 152 */     return !globalErrors.isEmpty() ? (ObjectError)globalErrors.get(0) : null;
/*     */   }
/*     */ 
/*     */   public boolean hasFieldErrors() {
/* 156 */     return getFieldErrorCount() > 0;
/*     */   }
/*     */ 
/*     */   public int getFieldErrorCount() {
/* 160 */     return getFieldErrors().size();
/*     */   }
/*     */ 
/*     */   public FieldError getFieldError() {
/* 164 */     List fieldErrors = getFieldErrors();
/* 165 */     return !fieldErrors.isEmpty() ? (FieldError)fieldErrors.get(0) : null;
/*     */   }
/*     */ 
/*     */   public boolean hasFieldErrors(String field) {
/* 169 */     return getFieldErrorCount(field) > 0;
/*     */   }
/*     */ 
/*     */   public int getFieldErrorCount(String field) {
/* 173 */     return getFieldErrors(field).size();
/*     */   }
/*     */ 
/*     */   public List<FieldError> getFieldErrors(String field) {
/* 177 */     List fieldErrors = getFieldErrors();
/* 178 */     List result = new LinkedList();
/* 179 */     String fixedField = fixedField(field);
/* 180 */     for (FieldError error : fieldErrors) {
/* 181 */       if (isMatchingFieldError(fixedField, error)) {
/* 182 */         result.add(error);
/*     */       }
/*     */     }
/* 185 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   public FieldError getFieldError(String field) {
/* 189 */     List fieldErrors = getFieldErrors(field);
/* 190 */     return !fieldErrors.isEmpty() ? (FieldError)fieldErrors.get(0) : null;
/*     */   }
/*     */ 
/*     */   public Class<?> getFieldType(String field)
/*     */   {
/* 195 */     Object value = getFieldValue(field);
/* 196 */     return value != null ? value.getClass() : null;
/*     */   }
/*     */ 
/*     */   protected boolean isMatchingFieldError(String field, FieldError fieldError)
/*     */   {
/* 206 */     if (field.equals(fieldError.getField())) {
/* 207 */       return true;
/*     */     }
/*     */ 
/* 210 */     int endIndex = field.length() - 1;
/* 211 */     return (endIndex >= 0) && (field.charAt(endIndex) == '*') && ((endIndex == 0) || (field.regionMatches(0, fieldError.getField(), 0, endIndex)));
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 218 */     StringBuilder sb = new StringBuilder(getClass().getName());
/* 219 */     sb.append(": ").append(getErrorCount()).append(" errors");
/* 220 */     for (ObjectError error : getAllErrors()) {
/* 221 */       sb.append('\n').append(error);
/*     */     }
/* 223 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.validation.AbstractErrors
 * JD-Core Version:    0.6.1
 */