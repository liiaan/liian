package org.springframework.validation;

public abstract interface MessageCodeFormatter
{
  public abstract String format(String paramString1, String paramString2, String paramString3);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.validation.MessageCodeFormatter
 * JD-Core Version:    0.6.1
 */