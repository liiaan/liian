/*    */ package org.springframework.validation;
/*    */ 
/*    */ import org.springframework.beans.PropertyAccessException;
/*    */ import org.springframework.context.support.DefaultMessageSourceResolvable;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ public class DefaultBindingErrorProcessor
/*    */   implements BindingErrorProcessor
/*    */ {
/*    */   public static final String MISSING_FIELD_ERROR_CODE = "required";
/*    */ 
/*    */   public void processMissingFieldError(String missingField, BindingResult bindingResult)
/*    */   {
/* 57 */     String fixedField = bindingResult.getNestedPath() + missingField;
/* 58 */     String[] codes = bindingResult.resolveMessageCodes("required", missingField);
/* 59 */     Object[] arguments = getArgumentsForBindError(bindingResult.getObjectName(), fixedField);
/* 60 */     bindingResult.addError(new FieldError(bindingResult.getObjectName(), fixedField, "", true, codes, arguments, "Field '" + fixedField + "' is required"));
/*    */   }
/*    */ 
/*    */   public void processPropertyAccessException(PropertyAccessException ex, BindingResult bindingResult)
/*    */   {
/* 67 */     String field = ex.getPropertyName();
/* 68 */     String[] codes = bindingResult.resolveMessageCodes(ex.getErrorCode(), field);
/* 69 */     Object[] arguments = getArgumentsForBindError(bindingResult.getObjectName(), field);
/* 70 */     Object rejectedValue = ex.getValue();
/* 71 */     if ((rejectedValue != null) && (rejectedValue.getClass().isArray())) {
/* 72 */       rejectedValue = StringUtils.arrayToCommaDelimitedString(ObjectUtils.toObjectArray(rejectedValue));
/*    */     }
/* 74 */     bindingResult.addError(new FieldError(bindingResult.getObjectName(), field, rejectedValue, true, codes, arguments, ex.getLocalizedMessage()));
/*    */   }
/*    */ 
/*    */   protected Object[] getArgumentsForBindError(String objectName, String field)
/*    */   {
/* 91 */     String[] codes = { objectName + "." + field, field };
/* 92 */     return new Object[] { new DefaultMessageSourceResolvable(codes, field) };
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.validation.DefaultBindingErrorProcessor
 * JD-Core Version:    0.6.1
 */