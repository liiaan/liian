/*    */ package org.springframework.validation.beanvalidation;
/*    */ 
/*    */ import javax.validation.MessageInterpolator;
/*    */ import javax.validation.TraversableResolver;
/*    */ import javax.validation.Validation;
/*    */ import javax.validation.Validator;
/*    */ import javax.validation.ValidatorContext;
/*    */ import javax.validation.ValidatorFactory;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ 
/*    */ public class CustomValidatorBean extends SpringValidatorAdapter
/*    */   implements Validator, InitializingBean
/*    */ {
/*    */   private ValidatorFactory validatorFactory;
/*    */   private MessageInterpolator messageInterpolator;
/*    */   private TraversableResolver traversableResolver;
/*    */ 
/*    */   public void setValidatorFactory(ValidatorFactory validatorFactory)
/*    */   {
/* 50 */     this.validatorFactory = validatorFactory;
/*    */   }
/*    */ 
/*    */   public void setMessageInterpolator(MessageInterpolator messageInterpolator)
/*    */   {
/* 57 */     this.messageInterpolator = messageInterpolator;
/*    */   }
/*    */ 
/*    */   public void setTraversableResolver(TraversableResolver traversableResolver)
/*    */   {
/* 64 */     this.traversableResolver = traversableResolver;
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 69 */     if (this.validatorFactory == null) {
/* 70 */       this.validatorFactory = Validation.buildDefaultValidatorFactory();
/*    */     }
/*    */ 
/* 73 */     ValidatorContext validatorContext = this.validatorFactory.usingContext();
/* 74 */     MessageInterpolator targetInterpolator = this.messageInterpolator;
/* 75 */     if (targetInterpolator == null) {
/* 76 */       targetInterpolator = this.validatorFactory.getMessageInterpolator();
/*    */     }
/* 78 */     validatorContext.messageInterpolator(new LocaleContextMessageInterpolator(targetInterpolator));
/* 79 */     if (this.traversableResolver != null) {
/* 80 */       validatorContext.traversableResolver(this.traversableResolver);
/*    */     }
/*    */ 
/* 83 */     setTargetValidator(validatorContext.getValidator());
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.validation.beanvalidation.CustomValidatorBean
 * JD-Core Version:    0.6.1
 */