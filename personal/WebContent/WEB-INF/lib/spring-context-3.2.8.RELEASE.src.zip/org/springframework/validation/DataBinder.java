/*     */ package org.springframework.validation;
/*     */ 
/*     */ import java.beans.PropertyEditor;
/*     */ import java.lang.reflect.Field;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.ConfigurablePropertyAccessor;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.PropertyAccessException;
/*     */ import org.springframework.beans.PropertyAccessorUtils;
/*     */ import org.springframework.beans.PropertyBatchUpdateException;
/*     */ import org.springframework.beans.PropertyEditorRegistry;
/*     */ import org.springframework.beans.PropertyValue;
/*     */ import org.springframework.beans.PropertyValues;
/*     */ import org.springframework.beans.SimpleTypeConverter;
/*     */ import org.springframework.beans.TypeConverter;
/*     */ import org.springframework.beans.TypeMismatchException;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.core.convert.ConversionService;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class DataBinder
/*     */   implements PropertyEditorRegistry, TypeConverter
/*     */ {
/*     */   public static final String DEFAULT_OBJECT_NAME = "target";
/*     */   public static final int DEFAULT_AUTO_GROW_COLLECTION_LIMIT = 256;
/* 120 */   protected static final Log logger = LogFactory.getLog(DataBinder.class);
/*     */   private final Object target;
/*     */   private final String objectName;
/*     */   private AbstractPropertyBindingResult bindingResult;
/*     */   private SimpleTypeConverter typeConverter;
/*     */   private BindException bindException;
/* 132 */   private boolean ignoreUnknownFields = true;
/*     */ 
/* 134 */   private boolean ignoreInvalidFields = false;
/*     */ 
/* 136 */   private boolean autoGrowNestedPaths = true;
/*     */ 
/* 138 */   private int autoGrowCollectionLimit = 256;
/*     */   private String[] allowedFields;
/*     */   private String[] disallowedFields;
/*     */   private String[] requiredFields;
/* 146 */   private BindingErrorProcessor bindingErrorProcessor = new DefaultBindingErrorProcessor();
/*     */ 
/* 148 */   private final List<Validator> validators = new ArrayList();
/*     */   private ConversionService conversionService;
/*     */ 
/*     */   public DataBinder(Object target)
/*     */   {
/* 160 */     this(target, "target");
/*     */   }
/*     */ 
/*     */   public DataBinder(Object target, String objectName)
/*     */   {
/* 170 */     this.target = target;
/* 171 */     this.objectName = objectName;
/*     */   }
/*     */ 
/*     */   public Object getTarget()
/*     */   {
/* 179 */     return this.target;
/*     */   }
/*     */ 
/*     */   public String getObjectName()
/*     */   {
/* 186 */     return this.objectName;
/*     */   }
/*     */ 
/*     */   public void setAutoGrowNestedPaths(boolean autoGrowNestedPaths)
/*     */   {
/* 200 */     Assert.state(this.bindingResult == null, "DataBinder is already initialized - call setAutoGrowNestedPaths before other configuration methods");
/*     */ 
/* 202 */     this.autoGrowNestedPaths = autoGrowNestedPaths;
/*     */   }
/*     */ 
/*     */   public boolean isAutoGrowNestedPaths()
/*     */   {
/* 209 */     return this.autoGrowNestedPaths;
/*     */   }
/*     */ 
/*     */   public void setAutoGrowCollectionLimit(int autoGrowCollectionLimit)
/*     */   {
/* 218 */     this.autoGrowCollectionLimit = autoGrowCollectionLimit;
/*     */   }
/*     */ 
/*     */   public int getAutoGrowCollectionLimit()
/*     */   {
/* 225 */     return this.autoGrowCollectionLimit;
/*     */   }
/*     */ 
/*     */   public void initBeanPropertyAccess()
/*     */   {
/* 234 */     Assert.state(this.bindingResult == null, "DataBinder is already initialized - call initBeanPropertyAccess before other configuration methods");
/*     */ 
/* 236 */     this.bindingResult = new BeanPropertyBindingResult(getTarget(), getObjectName(), isAutoGrowNestedPaths(), getAutoGrowCollectionLimit());
/*     */ 
/* 238 */     if (this.conversionService != null)
/* 239 */       this.bindingResult.initConversion(this.conversionService);
/*     */   }
/*     */ 
/*     */   public void initDirectFieldAccess()
/*     */   {
/* 249 */     Assert.state(this.bindingResult == null, "DataBinder is already initialized - call initDirectFieldAccess before other configuration methods");
/*     */ 
/* 251 */     this.bindingResult = new DirectFieldBindingResult(getTarget(), getObjectName());
/* 252 */     if (this.conversionService != null)
/* 253 */       this.bindingResult.initConversion(this.conversionService);
/*     */   }
/*     */ 
/*     */   protected AbstractPropertyBindingResult getInternalBindingResult()
/*     */   {
/* 262 */     if (this.bindingResult == null) {
/* 263 */       initBeanPropertyAccess();
/*     */     }
/* 265 */     return this.bindingResult;
/*     */   }
/*     */ 
/*     */   protected ConfigurablePropertyAccessor getPropertyAccessor()
/*     */   {
/* 272 */     return getInternalBindingResult().getPropertyAccessor();
/*     */   }
/*     */ 
/*     */   protected SimpleTypeConverter getSimpleTypeConverter()
/*     */   {
/* 279 */     if (this.typeConverter == null) {
/* 280 */       this.typeConverter = new SimpleTypeConverter();
/* 281 */       if (this.conversionService != null) {
/* 282 */         this.typeConverter.setConversionService(this.conversionService);
/*     */       }
/*     */     }
/* 285 */     return this.typeConverter;
/*     */   }
/*     */ 
/*     */   protected PropertyEditorRegistry getPropertyEditorRegistry()
/*     */   {
/* 292 */     if (getTarget() != null) {
/* 293 */       return getInternalBindingResult().getPropertyAccessor();
/*     */     }
/*     */ 
/* 296 */     return getSimpleTypeConverter();
/*     */   }
/*     */ 
/*     */   protected TypeConverter getTypeConverter()
/*     */   {
/* 304 */     if (getTarget() != null) {
/* 305 */       return getInternalBindingResult().getPropertyAccessor();
/*     */     }
/*     */ 
/* 308 */     return getSimpleTypeConverter();
/*     */   }
/*     */ 
/*     */   public BindingResult getBindingResult()
/*     */   {
/* 322 */     return getInternalBindingResult();
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public BindException getErrors()
/*     */   {
/* 335 */     if (this.bindException == null) {
/* 336 */       this.bindException = new BindException(getBindingResult());
/*     */     }
/* 338 */     return this.bindException;
/*     */   }
/*     */ 
/*     */   public void setIgnoreUnknownFields(boolean ignoreUnknownFields)
/*     */   {
/* 353 */     this.ignoreUnknownFields = ignoreUnknownFields;
/*     */   }
/*     */ 
/*     */   public boolean isIgnoreUnknownFields()
/*     */   {
/* 360 */     return this.ignoreUnknownFields;
/*     */   }
/*     */ 
/*     */   public void setIgnoreInvalidFields(boolean ignoreInvalidFields)
/*     */   {
/* 375 */     this.ignoreInvalidFields = ignoreInvalidFields;
/*     */   }
/*     */ 
/*     */   public boolean isIgnoreInvalidFields()
/*     */   {
/* 382 */     return this.ignoreInvalidFields;
/*     */   }
/*     */ 
/*     */   public void setAllowedFields(String[] allowedFields)
/*     */   {
/* 398 */     this.allowedFields = PropertyAccessorUtils.canonicalPropertyNames(allowedFields);
/*     */   }
/*     */ 
/*     */   public String[] getAllowedFields()
/*     */   {
/* 406 */     return this.allowedFields;
/*     */   }
/*     */ 
/*     */   public void setDisallowedFields(String[] disallowedFields)
/*     */   {
/* 422 */     this.disallowedFields = PropertyAccessorUtils.canonicalPropertyNames(disallowedFields);
/*     */   }
/*     */ 
/*     */   public String[] getDisallowedFields()
/*     */   {
/* 430 */     return this.disallowedFields;
/*     */   }
/*     */ 
/*     */   public void setRequiredFields(String[] requiredFields)
/*     */   {
/* 444 */     this.requiredFields = PropertyAccessorUtils.canonicalPropertyNames(requiredFields);
/* 445 */     if (logger.isDebugEnabled())
/* 446 */       logger.debug("DataBinder requires binding of required fields [" + StringUtils.arrayToCommaDelimitedString(requiredFields) + "]");
/*     */   }
/*     */ 
/*     */   public String[] getRequiredFields()
/*     */   {
/* 456 */     return this.requiredFields;
/*     */   }
/*     */ 
/*     */   public void setExtractOldValueForEditor(boolean extractOldValueForEditor)
/*     */   {
/* 466 */     getPropertyAccessor().setExtractOldValueForEditor(extractOldValueForEditor);
/*     */   }
/*     */ 
/*     */   public void setMessageCodesResolver(MessageCodesResolver messageCodesResolver)
/*     */   {
/* 477 */     getInternalBindingResult().setMessageCodesResolver(messageCodesResolver);
/*     */   }
/*     */ 
/*     */   public void setBindingErrorProcessor(BindingErrorProcessor bindingErrorProcessor)
/*     */   {
/* 487 */     Assert.notNull(bindingErrorProcessor, "BindingErrorProcessor must not be null");
/* 488 */     this.bindingErrorProcessor = bindingErrorProcessor;
/*     */   }
/*     */ 
/*     */   public BindingErrorProcessor getBindingErrorProcessor()
/*     */   {
/* 495 */     return this.bindingErrorProcessor;
/*     */   }
/*     */ 
/*     */   public void setValidator(Validator validator)
/*     */   {
/* 504 */     assertValidators(new Validator[] { validator });
/* 505 */     this.validators.clear();
/* 506 */     this.validators.add(validator);
/*     */   }
/*     */ 
/*     */   private void assertValidators(Validator[] validators) {
/* 510 */     Assert.notNull(validators, "Validators required");
/* 511 */     for (Validator validator : validators)
/* 512 */       if ((validator != null) && (getTarget() != null) && (!validator.supports(getTarget().getClass())))
/* 513 */         throw new IllegalStateException("Invalid target for Validator [" + validator + "]: " + getTarget());
/*     */   }
/*     */ 
/*     */   public void addValidators(Validator[] validators)
/*     */   {
/* 524 */     assertValidators(validators);
/* 525 */     this.validators.addAll(Arrays.asList(validators));
/*     */   }
/*     */ 
/*     */   public void replaceValidators(Validator[] validators)
/*     */   {
/* 534 */     assertValidators(validators);
/* 535 */     this.validators.clear();
/* 536 */     this.validators.addAll(Arrays.asList(validators));
/*     */   }
/*     */ 
/*     */   public Validator getValidator()
/*     */   {
/* 543 */     return this.validators.size() > 0 ? (Validator)this.validators.get(0) : null;
/*     */   }
/*     */ 
/*     */   public List<Validator> getValidators()
/*     */   {
/* 550 */     return Collections.unmodifiableList(this.validators);
/*     */   }
/*     */ 
/*     */   public void setConversionService(ConversionService conversionService)
/*     */   {
/* 562 */     Assert.state(this.conversionService == null, "DataBinder is already initialized with ConversionService");
/* 563 */     this.conversionService = conversionService;
/* 564 */     if ((this.bindingResult != null) && (conversionService != null))
/* 565 */       this.bindingResult.initConversion(conversionService);
/*     */   }
/*     */ 
/*     */   public ConversionService getConversionService()
/*     */   {
/* 573 */     return this.conversionService;
/*     */   }
/*     */ 
/*     */   public void registerCustomEditor(Class<?> requiredType, PropertyEditor propertyEditor) {
/* 577 */     getPropertyEditorRegistry().registerCustomEditor(requiredType, propertyEditor);
/*     */   }
/*     */ 
/*     */   public void registerCustomEditor(Class<?> requiredType, String field, PropertyEditor propertyEditor) {
/* 581 */     getPropertyEditorRegistry().registerCustomEditor(requiredType, field, propertyEditor);
/*     */   }
/*     */ 
/*     */   public PropertyEditor findCustomEditor(Class<?> requiredType, String propertyPath) {
/* 585 */     return getPropertyEditorRegistry().findCustomEditor(requiredType, propertyPath);
/*     */   }
/*     */ 
/*     */   public <T> T convertIfNecessary(Object value, Class<T> requiredType) throws TypeMismatchException {
/* 589 */     return getTypeConverter().convertIfNecessary(value, requiredType);
/*     */   }
/*     */ 
/*     */   public <T> T convertIfNecessary(Object value, Class<T> requiredType, MethodParameter methodParam)
/*     */     throws TypeMismatchException
/*     */   {
/* 595 */     return getTypeConverter().convertIfNecessary(value, requiredType, methodParam);
/*     */   }
/*     */ 
/*     */   public <T> T convertIfNecessary(Object value, Class<T> requiredType, Field field)
/*     */     throws TypeMismatchException
/*     */   {
/* 601 */     return getTypeConverter().convertIfNecessary(value, requiredType, field);
/*     */   }
/*     */ 
/*     */   public void bind(PropertyValues pvs)
/*     */   {
/* 619 */     MutablePropertyValues mpvs = (pvs instanceof MutablePropertyValues) ? (MutablePropertyValues)pvs : new MutablePropertyValues(pvs);
/*     */ 
/* 621 */     doBind(mpvs);
/*     */   }
/*     */ 
/*     */   protected void doBind(MutablePropertyValues mpvs)
/*     */   {
/* 634 */     checkAllowedFields(mpvs);
/* 635 */     checkRequiredFields(mpvs);
/* 636 */     applyPropertyValues(mpvs);
/*     */   }
/*     */ 
/*     */   protected void checkAllowedFields(MutablePropertyValues mpvs)
/*     */   {
/* 647 */     PropertyValue[] pvs = mpvs.getPropertyValues();
/* 648 */     for (PropertyValue pv : pvs) {
/* 649 */       String field = PropertyAccessorUtils.canonicalPropertyName(pv.getName());
/* 650 */       if (!isAllowed(field)) {
/* 651 */         mpvs.removePropertyValue(pv);
/* 652 */         getBindingResult().recordSuppressedField(field);
/* 653 */         if (logger.isDebugEnabled())
/* 654 */           logger.debug("Field [" + field + "] has been removed from PropertyValues " + "and will not be bound, because it has not been found in the list of allowed fields");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isAllowed(String field)
/*     */   {
/* 676 */     String[] allowed = getAllowedFields();
/* 677 */     String[] disallowed = getDisallowedFields();
/* 678 */     return ((ObjectUtils.isEmpty(allowed)) || (PatternMatchUtils.simpleMatch(allowed, field))) && ((ObjectUtils.isEmpty(disallowed)) || (!PatternMatchUtils.simpleMatch(disallowed, field)));
/*     */   }
/*     */ 
/*     */   protected void checkRequiredFields(MutablePropertyValues mpvs)
/*     */   {
/* 691 */     String[] requiredFields = getRequiredFields();
/* 692 */     if (!ObjectUtils.isEmpty(requiredFields)) {
/* 693 */       Map propertyValues = new HashMap();
/* 694 */       PropertyValue[] pvs = mpvs.getPropertyValues();
/* 695 */       for (PropertyValue pv : pvs) {
/* 696 */         String canonicalName = PropertyAccessorUtils.canonicalPropertyName(pv.getName());
/* 697 */         propertyValues.put(canonicalName, pv);
/*     */       }
/* 699 */       for (String field : requiredFields) {
/* 700 */         PropertyValue pv = (PropertyValue)propertyValues.get(field);
/* 701 */         boolean empty = (pv == null) || (pv.getValue() == null);
/* 702 */         if (!empty) {
/* 703 */           if ((pv.getValue() instanceof String)) {
/* 704 */             empty = !StringUtils.hasText((String)pv.getValue());
/*     */           }
/* 706 */           else if ((pv.getValue() instanceof String[])) {
/* 707 */             String[] values = (String[])pv.getValue();
/* 708 */             empty = (values.length == 0) || (!StringUtils.hasText(values[0]));
/*     */           }
/*     */         }
/* 711 */         if (empty)
/*     */         {
/* 713 */           getBindingErrorProcessor().processMissingFieldError(field, getInternalBindingResult());
/*     */ 
/* 716 */           if (pv != null) {
/* 717 */             mpvs.removePropertyValue(pv);
/* 718 */             propertyValues.remove(field);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void applyPropertyValues(MutablePropertyValues mpvs)
/*     */   {
/*     */     try
/*     */     {
/* 740 */       getPropertyAccessor().setPropertyValues(mpvs, isIgnoreUnknownFields(), isIgnoreInvalidFields());
/*     */     }
/*     */     catch (PropertyBatchUpdateException ex)
/*     */     {
/* 744 */       for (PropertyAccessException pae : ex.getPropertyAccessExceptions())
/* 745 */         getBindingErrorProcessor().processPropertyAccessException(pae, getInternalBindingResult());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void validate()
/*     */   {
/* 757 */     for (Validator validator : this.validators)
/* 758 */       validator.validate(getTarget(), getBindingResult());
/*     */   }
/*     */ 
/*     */   public void validate(Object[] validationHints)
/*     */   {
/* 770 */     for (Validator validator : getValidators())
/* 771 */       if ((!ObjectUtils.isEmpty(validationHints)) && ((validator instanceof SmartValidator))) {
/* 772 */         ((SmartValidator)validator).validate(getTarget(), getBindingResult(), validationHints);
/*     */       }
/* 774 */       else if (validator != null)
/* 775 */         validator.validate(getTarget(), getBindingResult());
/*     */   }
/*     */ 
/*     */   public Map<?, ?> close()
/*     */     throws BindException
/*     */   {
/* 788 */     if (getBindingResult().hasErrors()) {
/* 789 */       throw new BindException(getBindingResult());
/*     */     }
/* 791 */     return getBindingResult().getModel();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.validation.DataBinder
 * JD-Core Version:    0.6.1
 */