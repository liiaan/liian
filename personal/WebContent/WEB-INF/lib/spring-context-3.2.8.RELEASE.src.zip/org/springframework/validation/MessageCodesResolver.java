package org.springframework.validation;

public abstract interface MessageCodesResolver
{
  public abstract String[] resolveMessageCodes(String paramString1, String paramString2);

  public abstract String[] resolveMessageCodes(String paramString1, String paramString2, String paramString3, Class<?> paramClass);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.validation.MessageCodesResolver
 * JD-Core Version:    0.6.1
 */