/*     */ package org.springframework.validation.beanvalidation;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import javax.validation.Configuration;
/*     */ import javax.validation.ConstraintValidatorFactory;
/*     */ import javax.validation.MessageInterpolator;
/*     */ import javax.validation.TraversableResolver;
/*     */ import javax.validation.Validation;
/*     */ import javax.validation.Validator;
/*     */ import javax.validation.ValidatorContext;
/*     */ import javax.validation.ValidatorFactory;
/*     */ import javax.validation.bootstrap.GenericBootstrap;
/*     */ import javax.validation.bootstrap.ProviderSpecificBootstrap;
/*     */ import org.hibernate.validator.messageinterpolation.ResourceBundleMessageInterpolator;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.MessageSource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ public class LocalValidatorFactoryBean extends SpringValidatorAdapter
/*     */   implements ValidatorFactory, ApplicationContextAware, InitializingBean
/*     */ {
/*     */   private Class providerClass;
/*     */   private MessageInterpolator messageInterpolator;
/*     */   private TraversableResolver traversableResolver;
/*     */   private ConstraintValidatorFactory constraintValidatorFactory;
/*     */   private Resource[] mappingLocations;
/*     */   private final Map<String, String> validationPropertyMap;
/*     */   private ApplicationContext applicationContext;
/*     */   private ValidatorFactory validatorFactory;
/*     */ 
/*     */   public LocalValidatorFactoryBean()
/*     */   {
/*  84 */     this.validationPropertyMap = new HashMap();
/*     */   }
/*     */ 
/*     */   public void setProviderClass(Class providerClass)
/*     */   {
/*  99 */     this.providerClass = providerClass;
/*     */   }
/*     */ 
/*     */   public void setMessageInterpolator(MessageInterpolator messageInterpolator)
/*     */   {
/* 107 */     this.messageInterpolator = messageInterpolator;
/*     */   }
/*     */ 
/*     */   public void setValidationMessageSource(MessageSource messageSource)
/*     */   {
/* 126 */     this.messageInterpolator = HibernateValidatorDelegate.buildMessageInterpolator(messageSource);
/*     */   }
/*     */ 
/*     */   public void setTraversableResolver(TraversableResolver traversableResolver)
/*     */   {
/* 134 */     this.traversableResolver = traversableResolver;
/*     */   }
/*     */ 
/*     */   public void setConstraintValidatorFactory(ConstraintValidatorFactory constraintValidatorFactory)
/*     */   {
/* 143 */     this.constraintValidatorFactory = constraintValidatorFactory;
/*     */   }
/*     */ 
/*     */   public void setMappingLocations(Resource[] mappingLocations)
/*     */   {
/* 150 */     this.mappingLocations = mappingLocations;
/*     */   }
/*     */ 
/*     */   public void setValidationProperties(Properties jpaProperties)
/*     */   {
/* 160 */     CollectionUtils.mergePropertiesIntoMap(jpaProperties, this.validationPropertyMap);
/*     */   }
/*     */ 
/*     */   public void setValidationPropertyMap(Map<String, String> validationProperties)
/*     */   {
/* 169 */     if (validationProperties != null)
/* 170 */       this.validationPropertyMap.putAll(validationProperties);
/*     */   }
/*     */ 
/*     */   public Map<String, String> getValidationPropertyMap()
/*     */   {
/* 180 */     return this.validationPropertyMap;
/*     */   }
/*     */ 
/*     */   public void setApplicationContext(ApplicationContext applicationContext) {
/* 184 */     this.applicationContext = applicationContext;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 191 */     Configuration configuration = this.providerClass != null ? Validation.byProvider(this.providerClass).configure() : Validation.byDefaultProvider().configure();
/*     */ 
/* 195 */     MessageInterpolator targetInterpolator = this.messageInterpolator;
/* 196 */     if (targetInterpolator == null) {
/* 197 */       targetInterpolator = configuration.getDefaultMessageInterpolator();
/*     */     }
/* 199 */     configuration.messageInterpolator(new LocaleContextMessageInterpolator(targetInterpolator));
/*     */ 
/* 201 */     if (this.traversableResolver != null) {
/* 202 */       configuration.traversableResolver(this.traversableResolver);
/*     */     }
/*     */ 
/* 205 */     ConstraintValidatorFactory targetConstraintValidatorFactory = this.constraintValidatorFactory;
/* 206 */     if ((targetConstraintValidatorFactory == null) && (this.applicationContext != null)) {
/* 207 */       targetConstraintValidatorFactory = new SpringConstraintValidatorFactory(this.applicationContext.getAutowireCapableBeanFactory());
/*     */     }
/*     */ 
/* 210 */     if (targetConstraintValidatorFactory != null) {
/* 211 */       configuration.constraintValidatorFactory(targetConstraintValidatorFactory);
/*     */     }
/*     */ 
/* 214 */     if (this.mappingLocations != null) {
/* 215 */       for (Resource location : this.mappingLocations) {
/*     */         try {
/* 217 */           configuration.addMapping(location.getInputStream());
/*     */         }
/*     */         catch (IOException ex) {
/* 220 */           throw new IllegalStateException("Cannot read mapping resource: " + location);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 225 */     for (Map.Entry entry : this.validationPropertyMap.entrySet()) {
/* 226 */       configuration.addProperty((String)entry.getKey(), (String)entry.getValue());
/*     */     }
/*     */ 
/* 230 */     postProcessConfiguration(configuration);
/*     */ 
/* 232 */     this.validatorFactory = configuration.buildValidatorFactory();
/* 233 */     setTargetValidator(this.validatorFactory.getValidator());
/*     */   }
/*     */ 
/*     */   protected void postProcessConfiguration(Configuration configuration)
/*     */   {
/*     */   }
/*     */ 
/*     */   public Validator getValidator()
/*     */   {
/* 248 */     return this.validatorFactory.getValidator();
/*     */   }
/*     */ 
/*     */   public ValidatorContext usingContext() {
/* 252 */     return this.validatorFactory.usingContext();
/*     */   }
/*     */ 
/*     */   public MessageInterpolator getMessageInterpolator() {
/* 256 */     return this.validatorFactory.getMessageInterpolator();
/*     */   }
/*     */ 
/*     */   public TraversableResolver getTraversableResolver() {
/* 260 */     return this.validatorFactory.getTraversableResolver();
/*     */   }
/*     */ 
/*     */   public ConstraintValidatorFactory getConstraintValidatorFactory() {
/* 264 */     return this.validatorFactory.getConstraintValidatorFactory();
/*     */   }
/*     */ 
/*     */   private static class HibernateValidatorDelegate
/*     */   {
/*     */     public static MessageInterpolator buildMessageInterpolator(MessageSource messageSource)
/*     */     {
/* 274 */       return new ResourceBundleMessageInterpolator(new MessageSourceResourceBundleLocator(messageSource));
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.validation.beanvalidation.LocalValidatorFactoryBean
 * JD-Core Version:    0.6.1
 */