/*     */ package org.springframework.validation.beanvalidation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import java.util.TreeMap;
/*     */ import javax.validation.ConstraintViolation;
/*     */ import javax.validation.Validator;
/*     */ import javax.validation.metadata.BeanDescriptor;
/*     */ import javax.validation.metadata.ConstraintDescriptor;
/*     */ import org.springframework.beans.NotReadablePropertyException;
/*     */ import org.springframework.context.support.DefaultMessageSourceResolvable;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.validation.BindingResult;
/*     */ import org.springframework.validation.Errors;
/*     */ import org.springframework.validation.FieldError;
/*     */ import org.springframework.validation.ObjectError;
/*     */ import org.springframework.validation.SmartValidator;
/*     */ 
/*     */ public class SpringValidatorAdapter
/*     */   implements SmartValidator, Validator
/*     */ {
/*  52 */   private static final Set<String> internalAnnotationAttributes = new HashSet(3);
/*     */   private Validator targetValidator;
/*     */ 
/*     */   public SpringValidatorAdapter(Validator targetValidator)
/*     */   {
/*  68 */     Assert.notNull(targetValidator, "Target Validator must not be null");
/*  69 */     this.targetValidator = targetValidator;
/*     */   }
/*     */ 
/*     */   SpringValidatorAdapter() {
/*     */   }
/*     */ 
/*     */   void setTargetValidator(Validator targetValidator) {
/*  76 */     this.targetValidator = targetValidator;
/*     */   }
/*     */ 
/*     */   public boolean supports(Class<?> clazz)
/*     */   {
/*  85 */     return true;
/*     */   }
/*     */ 
/*     */   public void validate(Object target, Errors errors) {
/*  89 */     processConstraintViolations(this.targetValidator.validate(target, new Class[0]), errors);
/*     */   }
/*     */ 
/*     */   public void validate(Object target, Errors errors, Object[] validationHints)
/*     */   {
/*  94 */     Set groups = new LinkedHashSet();
/*  95 */     if (validationHints != null) {
/*  96 */       for (Object hint : validationHints) {
/*  97 */         if ((hint instanceof Class)) {
/*  98 */           groups.add((Class)hint);
/*     */         }
/*     */       }
/*     */     }
/* 102 */     processConstraintViolations(this.targetValidator.validate(target, (Class[])groups.toArray(new Class[groups.size()])), errors);
/*     */   }
/*     */ 
/*     */   protected void processConstraintViolations(Set<ConstraintViolation<Object>> violations, Errors errors)
/*     */   {
/* 113 */     for (ConstraintViolation violation : violations) {
/* 114 */       String field = violation.getPropertyPath().toString();
/* 115 */       FieldError fieldError = errors.getFieldError(field);
/* 116 */       if ((fieldError == null) || (!fieldError.isBindingFailure()))
/*     */         try {
/* 118 */           ConstraintDescriptor cd = violation.getConstraintDescriptor();
/* 119 */           String errorCode = cd.getAnnotation().annotationType().getSimpleName();
/* 120 */           Object[] errorArgs = getArgumentsForConstraint(errors.getObjectName(), field, cd);
/* 121 */           if ((errors instanceof BindingResult))
/*     */           {
/* 124 */             BindingResult bindingResult = (BindingResult)errors;
/* 125 */             String nestedField = bindingResult.getNestedPath() + field;
/* 126 */             if ("".equals(nestedField)) {
/* 127 */               String[] errorCodes = bindingResult.resolveMessageCodes(errorCode);
/* 128 */               bindingResult.addError(new ObjectError(errors.getObjectName(), errorCodes, errorArgs, violation.getMessage()));
/*     */             }
/*     */             else
/*     */             {
/* 132 */               Object invalidValue = violation.getInvalidValue();
/* 133 */               if ((!"".equals(field)) && ((invalidValue == violation.getLeafBean()) || ((field.contains(".")) && (!field.contains("[]")))))
/*     */               {
/* 137 */                 invalidValue = bindingResult.getRawFieldValue(field);
/*     */               }
/* 139 */               String[] errorCodes = bindingResult.resolveMessageCodes(errorCode, field);
/* 140 */               bindingResult.addError(new FieldError(errors.getObjectName(), nestedField, invalidValue, false, errorCodes, errorArgs, violation.getMessage()));
/*     */             }
/*     */ 
/*     */           }
/*     */           else
/*     */           {
/* 148 */             errors.rejectValue(field, errorCode, errorArgs, violation.getMessage());
/*     */           }
/*     */         }
/*     */         catch (NotReadablePropertyException ex) {
/* 152 */           throw new IllegalStateException("JSR-303 validated property '" + field + "' does not have a corresponding accessor for Spring data binding - " + "check your DataBinder's configuration (bean property versus direct field access)", ex);
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object[] getArgumentsForConstraint(String objectName, String field, ConstraintDescriptor<?> descriptor)
/*     */   {
/* 177 */     List arguments = new LinkedList();
/* 178 */     String[] codes = { objectName + "." + field, field };
/* 179 */     arguments.add(new DefaultMessageSourceResolvable(codes, field));
/*     */ 
/* 181 */     Map attributesToExpose = new TreeMap();
/* 182 */     for (Map.Entry entry : descriptor.getAttributes().entrySet()) {
/* 183 */       String attributeName = (String)entry.getKey();
/* 184 */       Object attributeValue = entry.getValue();
/* 185 */       if (!internalAnnotationAttributes.contains(attributeName)) {
/* 186 */         attributesToExpose.put(attributeName, attributeValue);
/*     */       }
/*     */     }
/* 189 */     arguments.addAll(attributesToExpose.values());
/* 190 */     return arguments.toArray(new Object[arguments.size()]);
/*     */   }
/*     */ 
/*     */   public <T> Set<ConstraintViolation<T>> validate(T object, Class<?>[] groups)
/*     */   {
/* 199 */     return this.targetValidator.validate(object, groups);
/*     */   }
/*     */ 
/*     */   public <T> Set<ConstraintViolation<T>> validateProperty(T object, String propertyName, Class<?>[] groups) {
/* 203 */     return this.targetValidator.validateProperty(object, propertyName, groups);
/*     */   }
/*     */ 
/*     */   public <T> Set<ConstraintViolation<T>> validateValue(Class<T> beanType, String propertyName, Object value, Class<?>[] groups)
/*     */   {
/* 209 */     return this.targetValidator.validateValue(beanType, propertyName, value, groups);
/*     */   }
/*     */ 
/*     */   public BeanDescriptor getConstraintsForClass(Class<?> clazz) {
/* 213 */     return this.targetValidator.getConstraintsForClass(clazz);
/*     */   }
/*     */ 
/*     */   public <T> T unwrap(Class<T> type) {
/* 217 */     return this.targetValidator.unwrap(type);
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  55 */     internalAnnotationAttributes.add("message");
/*  56 */     internalAnnotationAttributes.add("groups");
/*  57 */     internalAnnotationAttributes.add("payload");
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.validation.beanvalidation.SpringValidatorAdapter
 * JD-Core Version:    0.6.1
 */