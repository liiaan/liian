/*     */ package org.springframework.cache.support;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.cache.CacheManager;
/*     */ 
/*     */ public class CompositeCacheManager
/*     */   implements CacheManager, InitializingBean
/*     */ {
/*  55 */   private final List<CacheManager> cacheManagers = new ArrayList();
/*     */ 
/*  57 */   private boolean fallbackToNoOpCache = false;
/*     */ 
/*     */   public CompositeCacheManager()
/*     */   {
/*     */   }
/*     */ 
/*     */   public CompositeCacheManager(CacheManager[] cacheManagers)
/*     */   {
/*  72 */     setCacheManagers(Arrays.asList(cacheManagers));
/*     */   }
/*     */ 
/*     */   public void setCacheManagers(Collection<CacheManager> cacheManagers)
/*     */   {
/*  80 */     this.cacheManagers.clear();
/*  81 */     this.cacheManagers.addAll(cacheManagers);
/*     */   }
/*     */ 
/*     */   public void setFallbackToNoOpCache(boolean fallbackToNoOpCache)
/*     */   {
/*  90 */     this.fallbackToNoOpCache = fallbackToNoOpCache;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() {
/*  94 */     if (this.fallbackToNoOpCache)
/*  95 */       this.cacheManagers.add(new NoOpCacheManager());
/*     */   }
/*     */ 
/*     */   public Cache getCache(String name)
/*     */   {
/* 101 */     for (CacheManager cacheManager : this.cacheManagers) {
/* 102 */       Cache cache = cacheManager.getCache(name);
/* 103 */       if (cache != null) {
/* 104 */         return cache;
/*     */       }
/*     */     }
/* 107 */     return null;
/*     */   }
/*     */ 
/*     */   public Collection<String> getCacheNames() {
/* 111 */     Set names = new LinkedHashSet();
/* 112 */     for (CacheManager manager : this.cacheManagers) {
/* 113 */       names.addAll(manager.getCacheNames());
/*     */     }
/* 115 */     return Collections.unmodifiableSet(names);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.support.CompositeCacheManager
 * JD-Core Version:    0.6.1
 */