/*     */ package org.springframework.cache.config;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.config.TypedStringValue;
/*     */ import org.springframework.beans.factory.parsing.ReaderContext;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*     */ import org.springframework.beans.factory.support.ManagedList;
/*     */ import org.springframework.beans.factory.support.ManagedMap;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.AbstractSingleBeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.cache.annotation.AnnotationCacheOperationSource;
/*     */ import org.springframework.cache.interceptor.CacheEvictOperation;
/*     */ import org.springframework.cache.interceptor.CacheInterceptor;
/*     */ import org.springframework.cache.interceptor.CacheOperation;
/*     */ import org.springframework.cache.interceptor.CachePutOperation;
/*     */ import org.springframework.cache.interceptor.CacheableOperation;
/*     */ import org.springframework.cache.interceptor.NameMatchCacheOperationSource;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.xml.DomUtils;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ class CacheAdviceParser extends AbstractSingleBeanDefinitionParser
/*     */ {
/*     */   private static final String CACHEABLE_ELEMENT = "cacheable";
/*     */   private static final String CACHE_EVICT_ELEMENT = "cache-evict";
/*     */   private static final String CACHE_PUT_ELEMENT = "cache-put";
/*     */   private static final String METHOD_ATTRIBUTE = "method";
/*     */   private static final String DEFS_ELEMENT = "caching";
/*     */ 
/*     */   protected Class<?> getBeanClass(Element element)
/*     */   {
/* 116 */     return CacheInterceptor.class;
/*     */   }
/*     */ 
/*     */   protected void doParse(Element element, ParserContext parserContext, BeanDefinitionBuilder builder)
/*     */   {
/* 121 */     builder.addPropertyReference("cacheManager", CacheNamespaceHandler.extractCacheManager(element));
/* 122 */     CacheNamespaceHandler.parseKeyGenerator(element, builder.getBeanDefinition());
/*     */ 
/* 124 */     List cacheDefs = DomUtils.getChildElementsByTagName(element, "caching");
/* 125 */     if (cacheDefs.size() >= 1)
/*     */     {
/* 127 */       List attributeSourceDefinitions = parseDefinitionsSources(cacheDefs, parserContext);
/* 128 */       builder.addPropertyValue("cacheOperationSources", attributeSourceDefinitions);
/*     */     }
/*     */     else {
/* 131 */       builder.addPropertyValue("cacheOperationSources", new RootBeanDefinition(AnnotationCacheOperationSource.class));
/*     */     }
/*     */   }
/*     */ 
/*     */   private List<RootBeanDefinition> parseDefinitionsSources(List<Element> definitions, ParserContext parserContext)
/*     */   {
/* 137 */     ManagedList defs = new ManagedList(definitions.size());
/*     */ 
/* 140 */     for (Element element : definitions) {
/* 141 */       defs.add(parseDefinitionSource(element, parserContext));
/*     */     }
/*     */ 
/* 144 */     return defs;
/*     */   }
/*     */ 
/*     */   private RootBeanDefinition parseDefinitionSource(Element definition, ParserContext parserContext) {
/* 148 */     Props prop = new Props(definition);
/*     */ 
/* 151 */     ManagedMap cacheOpMap = new ManagedMap();
/* 152 */     cacheOpMap.setSource(parserContext.extractSource(definition));
/*     */ 
/* 154 */     List cacheableCacheMethods = DomUtils.getChildElementsByTagName(definition, "cacheable");
/*     */ 
/* 156 */     for (Element opElement : cacheableCacheMethods) {
/* 157 */       String name = prop.merge(opElement, parserContext.getReaderContext());
/* 158 */       TypedStringValue nameHolder = new TypedStringValue(name);
/* 159 */       nameHolder.setSource(parserContext.extractSource(opElement));
/* 160 */       CacheableOperation op = (CacheableOperation)prop.merge(opElement, parserContext.getReaderContext(), new CacheableOperation());
/* 161 */       op.setUnless(getAttributeValue(opElement, "unless", ""));
/*     */ 
/* 163 */       Collection col = (Collection)cacheOpMap.get(nameHolder);
/* 164 */       if (col == null) {
/* 165 */         col = new ArrayList(2);
/* 166 */         cacheOpMap.put(nameHolder, col);
/*     */       }
/* 168 */       col.add(op);
/*     */     }
/*     */ 
/* 171 */     List evictCacheMethods = DomUtils.getChildElementsByTagName(definition, "cache-evict");
/*     */ 
/* 173 */     for (Element opElement : evictCacheMethods) {
/* 174 */       String name = prop.merge(opElement, parserContext.getReaderContext());
/* 175 */       TypedStringValue nameHolder = new TypedStringValue(name);
/* 176 */       nameHolder.setSource(parserContext.extractSource(opElement));
/* 177 */       CacheEvictOperation op = (CacheEvictOperation)prop.merge(opElement, parserContext.getReaderContext(), new CacheEvictOperation());
/*     */ 
/* 179 */       String wide = opElement.getAttribute("all-entries");
/* 180 */       if (StringUtils.hasText(wide)) {
/* 181 */         op.setCacheWide(Boolean.valueOf(wide.trim()).booleanValue());
/*     */       }
/*     */ 
/* 184 */       String after = opElement.getAttribute("before-invocation");
/* 185 */       if (StringUtils.hasText(after)) {
/* 186 */         op.setBeforeInvocation(Boolean.valueOf(after.trim()).booleanValue());
/*     */       }
/*     */ 
/* 189 */       Collection col = (Collection)cacheOpMap.get(nameHolder);
/* 190 */       if (col == null) {
/* 191 */         col = new ArrayList(2);
/* 192 */         cacheOpMap.put(nameHolder, col);
/*     */       }
/* 194 */       col.add(op);
/*     */     }
/*     */ 
/* 197 */     List putCacheMethods = DomUtils.getChildElementsByTagName(definition, "cache-put");
/*     */ 
/* 199 */     for (Element opElement : putCacheMethods) {
/* 200 */       String name = prop.merge(opElement, parserContext.getReaderContext());
/* 201 */       TypedStringValue nameHolder = new TypedStringValue(name);
/* 202 */       nameHolder.setSource(parserContext.extractSource(opElement));
/* 203 */       CachePutOperation op = (CachePutOperation)prop.merge(opElement, parserContext.getReaderContext(), new CachePutOperation());
/* 204 */       op.setUnless(getAttributeValue(opElement, "unless", ""));
/*     */ 
/* 206 */       Collection col = (Collection)cacheOpMap.get(nameHolder);
/* 207 */       if (col == null) {
/* 208 */         col = new ArrayList(2);
/* 209 */         cacheOpMap.put(nameHolder, col);
/*     */       }
/* 211 */       col.add(op);
/*     */     }
/*     */ 
/* 214 */     RootBeanDefinition attributeSourceDefinition = new RootBeanDefinition(NameMatchCacheOperationSource.class);
/* 215 */     attributeSourceDefinition.setSource(parserContext.extractSource(definition));
/* 216 */     attributeSourceDefinition.getPropertyValues().add("nameMap", cacheOpMap);
/* 217 */     return attributeSourceDefinition;
/*     */   }
/*     */ 
/*     */   private static String getAttributeValue(Element element, String attributeName, String defaultValue)
/*     */   {
/* 222 */     String attribute = element.getAttribute(attributeName);
/* 223 */     if (StringUtils.hasText(attribute)) {
/* 224 */       return attribute.trim();
/*     */     }
/* 226 */     return defaultValue;
/*     */   }
/*     */ 
/*     */   private static class Props
/*     */   {
/*     */     private String key;
/*     */     private String condition;
/*     */     private String method;
/*  61 */     private String[] caches = null;
/*     */ 
/*     */     Props(Element root) {
/*  64 */       String defaultCache = root.getAttribute("cache");
/*  65 */       this.key = root.getAttribute("key");
/*  66 */       this.condition = root.getAttribute("condition");
/*  67 */       this.method = root.getAttribute("method");
/*     */ 
/*  69 */       if (StringUtils.hasText(defaultCache))
/*  70 */         this.caches = StringUtils.commaDelimitedListToStringArray(defaultCache.trim());
/*     */     }
/*     */ 
/*     */     <T extends CacheOperation> T merge(Element element, ReaderContext readerCtx, T op)
/*     */     {
/*  75 */       String cache = element.getAttribute("cache");
/*     */ 
/*  78 */       String[] localCaches = this.caches;
/*  79 */       if (StringUtils.hasText(cache)) {
/*  80 */         localCaches = StringUtils.commaDelimitedListToStringArray(cache.trim());
/*     */       }
/*  82 */       else if (this.caches == null) {
/*  83 */         readerCtx.error("No cache specified specified for " + element.getNodeName(), element);
/*     */       }
/*     */ 
/*  86 */       op.setCacheNames(localCaches);
/*     */ 
/*  88 */       op.setKey(CacheAdviceParser.getAttributeValue(element, "key", this.key));
/*  89 */       op.setCondition(CacheAdviceParser.getAttributeValue(element, "condition", this.condition));
/*     */ 
/*  91 */       return op;
/*     */     }
/*     */ 
/*     */     String merge(Element element, ReaderContext readerCtx) {
/*  95 */       String m = element.getAttribute("method");
/*     */ 
/*  97 */       if (StringUtils.hasText(m)) {
/*  98 */         return m.trim();
/*     */       }
/* 100 */       if (StringUtils.hasText(this.method)) {
/* 101 */         return this.method;
/*     */       }
/* 103 */       readerCtx.error("No method specified for " + element.getNodeName(), element);
/* 104 */       return null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.config.CacheAdviceParser
 * JD-Core Version:    0.6.1
 */