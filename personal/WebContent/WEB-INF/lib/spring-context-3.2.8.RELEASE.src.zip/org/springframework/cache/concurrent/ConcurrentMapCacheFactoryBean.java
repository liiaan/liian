/*    */ package org.springframework.cache.concurrent;
/*    */ 
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ import org.springframework.beans.factory.BeanNameAware;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ public class ConcurrentMapCacheFactoryBean
/*    */   implements FactoryBean<ConcurrentMapCache>, BeanNameAware, InitializingBean
/*    */ {
/* 42 */   private String name = "";
/*    */   private ConcurrentMap<Object, Object> store;
/* 46 */   private boolean allowNullValues = true;
/*    */   private ConcurrentMapCache cache;
/*    */ 
/*    */   public void setName(String name)
/*    */   {
/* 56 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public void setStore(ConcurrentMap<Object, Object> store)
/*    */   {
/* 65 */     this.store = store;
/*    */   }
/*    */ 
/*    */   public void setAllowNullValues(boolean allowNullValues)
/*    */   {
/* 74 */     this.allowNullValues = allowNullValues;
/*    */   }
/*    */ 
/*    */   public void setBeanName(String beanName) {
/* 78 */     if (!StringUtils.hasLength(this.name))
/* 79 */       setName(beanName);
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 84 */     this.cache = (this.store != null ? new ConcurrentMapCache(this.name, this.store, this.allowNullValues) : new ConcurrentMapCache(this.name, this.allowNullValues));
/*    */   }
/*    */ 
/*    */   public ConcurrentMapCache getObject()
/*    */   {
/* 90 */     return this.cache;
/*    */   }
/*    */ 
/*    */   public Class<?> getObjectType() {
/* 94 */     return ConcurrentMapCache.class;
/*    */   }
/*    */ 
/*    */   public boolean isSingleton() {
/* 98 */     return true;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.concurrent.ConcurrentMapCacheFactoryBean
 * JD-Core Version:    0.6.1
 */