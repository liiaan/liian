/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Method;
/*    */ import org.springframework.aop.support.StaticMethodMatcherPointcut;
/*    */ import org.springframework.util.CollectionUtils;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ abstract class CacheOperationSourcePointcut extends StaticMethodMatcherPointcut
/*    */   implements Serializable
/*    */ {
/*    */   public boolean matches(Method method, Class<?> targetClass)
/*    */   {
/* 37 */     CacheOperationSource cas = getCacheOperationSource();
/* 38 */     return (cas != null) && (!CollectionUtils.isEmpty(cas.getCacheOperations(method, targetClass)));
/*    */   }
/*    */ 
/*    */   public boolean equals(Object other)
/*    */   {
/* 43 */     if (this == other) {
/* 44 */       return true;
/*    */     }
/* 46 */     if (!(other instanceof CacheOperationSourcePointcut)) {
/* 47 */       return false;
/*    */     }
/* 49 */     CacheOperationSourcePointcut otherPc = (CacheOperationSourcePointcut)other;
/* 50 */     return ObjectUtils.nullSafeEquals(getCacheOperationSource(), otherPc.getCacheOperationSource());
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 55 */     return CacheOperationSourcePointcut.class.hashCode();
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 60 */     return getClass().getName() + ": " + getCacheOperationSource();
/*    */   }
/*    */ 
/*    */   protected abstract CacheOperationSource getCacheOperationSource();
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.CacheOperationSourcePointcut
 * JD-Core Version:    0.6.1
 */