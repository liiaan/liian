/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import org.springframework.aop.ClassFilter;
/*    */ import org.springframework.aop.Pointcut;
/*    */ import org.springframework.aop.support.AbstractBeanFactoryPointcutAdvisor;
/*    */ 
/*    */ public class BeanFactoryCacheOperationSourceAdvisor extends AbstractBeanFactoryPointcutAdvisor
/*    */ {
/*    */   private CacheOperationSource cacheOperationSource;
/* 35 */   private final CacheOperationSourcePointcut pointcut = new CacheOperationSourcePointcut()
/*    */   {
/*    */     protected CacheOperationSource getCacheOperationSource() {
/* 38 */       return BeanFactoryCacheOperationSourceAdvisor.this.cacheOperationSource;
/*    */     }
/* 35 */   };
/*    */ 
/*    */   public void setCacheOperationSource(CacheOperationSource cacheOperationSource)
/*    */   {
/* 49 */     this.cacheOperationSource = cacheOperationSource;
/*    */   }
/*    */ 
/*    */   public void setClassFilter(ClassFilter classFilter)
/*    */   {
/* 57 */     this.pointcut.setClassFilter(classFilter);
/*    */   }
/*    */ 
/*    */   public Pointcut getPointcut() {
/* 61 */     return this.pointcut;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.BeanFactoryCacheOperationSourceAdvisor
 * JD-Core Version:    0.6.1
 */