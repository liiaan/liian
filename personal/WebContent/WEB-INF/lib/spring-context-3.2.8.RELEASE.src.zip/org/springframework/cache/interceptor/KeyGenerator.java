package org.springframework.cache.interceptor;

import java.lang.reflect.Method;

public abstract interface KeyGenerator
{
  public abstract Object generate(Object paramObject, Method paramMethod, Object[] paramArrayOfObject);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.KeyGenerator
 * JD-Core Version:    0.6.1
 */