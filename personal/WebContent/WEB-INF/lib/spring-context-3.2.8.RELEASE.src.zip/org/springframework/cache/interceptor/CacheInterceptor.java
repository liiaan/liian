/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.lang.reflect.Method;
/*    */ import org.aopalliance.intercept.MethodInterceptor;
/*    */ import org.aopalliance.intercept.MethodInvocation;
/*    */ 
/*    */ public class CacheInterceptor extends CacheAspectSupport
/*    */   implements MethodInterceptor, Serializable
/*    */ {
/*    */   public Object invoke(final MethodInvocation invocation)
/*    */     throws Throwable
/*    */   {
/* 53 */     Method method = invocation.getMethod();
/*    */ 
/* 55 */     CacheAspectSupport.Invoker aopAllianceInvoker = new CacheAspectSupport.Invoker() {
/*    */       public Object invoke() {
/*    */         try {
/* 58 */           return invocation.proceed();
/*    */         } catch (Throwable ex) {
/* 60 */           throw new CacheInterceptor.ThrowableWrapper(ex);
/*    */         }
/*    */       }
/*    */     };
/*    */     try
/*    */     {
/* 66 */       return execute(aopAllianceInvoker, invocation.getThis(), method, invocation.getArguments());
/*    */     } catch (ThrowableWrapper th) {
/* 68 */       throw th.original;
/*    */     }
/*    */   }
/*    */ 
/*    */   private static class ThrowableWrapper extends RuntimeException
/*    */   {
/*    */     private final Throwable original;
/*    */ 
/*    */     ThrowableWrapper(Throwable original)
/*    */     {
/* 48 */       this.original = original;
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.CacheInterceptor
 * JD-Core Version:    0.6.1
 */