/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ import org.springframework.aop.Pointcut;
/*    */ import org.springframework.aop.framework.AbstractSingletonProxyFactoryBean;
/*    */ import org.springframework.aop.support.DefaultPointcutAdvisor;
/*    */ 
/*    */ public class CacheProxyFactoryBean extends AbstractSingletonProxyFactoryBean
/*    */ {
/* 44 */   private final CacheInterceptor cachingInterceptor = new CacheInterceptor();
/*    */   private Pointcut pointcut;
/*    */ 
/*    */   public void setPointcut(Pointcut pointcut)
/*    */   {
/* 55 */     this.pointcut = pointcut;
/*    */   }
/*    */ 
/*    */   protected Object createMainInterceptor()
/*    */   {
/* 60 */     this.cachingInterceptor.afterPropertiesSet();
/* 61 */     if (this.pointcut != null) {
/* 62 */       return new DefaultPointcutAdvisor(this.pointcut, this.cachingInterceptor);
/*    */     }
/*    */ 
/* 65 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public void setCacheOperationSources(CacheOperationSource[] cacheOperationSources)
/*    */   {
/* 73 */     this.cachingInterceptor.setCacheOperationSources(cacheOperationSources);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.CacheProxyFactoryBean
 * JD-Core Version:    0.6.1
 */