/*     */ package org.springframework.cache.config;
/*     */ 
/*     */ import org.springframework.aop.config.AopNamespaceUtils;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.config.BeanDefinition;
/*     */ import org.springframework.beans.factory.config.RuntimeBeanReference;
/*     */ import org.springframework.beans.factory.parsing.BeanComponentDefinition;
/*     */ import org.springframework.beans.factory.parsing.CompositeComponentDefinition;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.RootBeanDefinition;
/*     */ import org.springframework.beans.factory.xml.BeanDefinitionParser;
/*     */ import org.springframework.beans.factory.xml.ParserContext;
/*     */ import org.springframework.beans.factory.xml.XmlReaderContext;
/*     */ import org.springframework.cache.annotation.AnnotationCacheOperationSource;
/*     */ import org.springframework.cache.interceptor.BeanFactoryCacheOperationSourceAdvisor;
/*     */ import org.springframework.cache.interceptor.CacheInterceptor;
/*     */ import org.w3c.dom.Element;
/*     */ 
/*     */ class AnnotationDrivenCacheBeanDefinitionParser
/*     */   implements BeanDefinitionParser
/*     */ {
/*     */   public BeanDefinition parse(Element element, ParserContext parserContext)
/*     */   {
/*  57 */     String mode = element.getAttribute("mode");
/*  58 */     if ("aspectj".equals(mode))
/*     */     {
/*  60 */       registerCacheAspect(element, parserContext);
/*     */     }
/*     */     else
/*     */     {
/*  64 */       AopAutoProxyConfigurer.configureAutoProxyCreator(element, parserContext);
/*     */     }
/*     */ 
/*  67 */     return null;
/*     */   }
/*     */ 
/*     */   private static void parseCacheManagerProperty(Element element, BeanDefinition def) {
/*  71 */     def.getPropertyValues().add("cacheManager", new RuntimeBeanReference(CacheNamespaceHandler.extractCacheManager(element)));
/*     */   }
/*     */ 
/*     */   private void registerCacheAspect(Element element, ParserContext parserContext)
/*     */   {
/*  88 */     if (!parserContext.getRegistry().containsBeanDefinition("org.springframework.cache.config.internalCacheAspect")) {
/*  89 */       RootBeanDefinition def = new RootBeanDefinition();
/*  90 */       def.setBeanClassName("org.springframework.cache.aspectj.AnnotationCacheAspect");
/*  91 */       def.setFactoryMethodName("aspectOf");
/*  92 */       parseCacheManagerProperty(element, def);
/*  93 */       CacheNamespaceHandler.parseKeyGenerator(element, def);
/*  94 */       parserContext.registerBeanComponent(new BeanComponentDefinition(def, "org.springframework.cache.config.internalCacheAspect"));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class AopAutoProxyConfigurer
/*     */   {
/*     */     public static void configureAutoProxyCreator(Element element, ParserContext parserContext)
/*     */     {
/* 105 */       AopNamespaceUtils.registerAutoProxyCreatorIfNecessary(parserContext, element);
/*     */ 
/* 107 */       if (!parserContext.getRegistry().containsBeanDefinition("org.springframework.cache.config.internalCacheAdvisor")) {
/* 108 */         Object eleSource = parserContext.extractSource(element);
/*     */ 
/* 111 */         RootBeanDefinition sourceDef = new RootBeanDefinition(AnnotationCacheOperationSource.class);
/* 112 */         sourceDef.setSource(eleSource);
/* 113 */         sourceDef.setRole(2);
/* 114 */         String sourceName = parserContext.getReaderContext().registerWithGeneratedName(sourceDef);
/*     */ 
/* 117 */         RootBeanDefinition interceptorDef = new RootBeanDefinition(CacheInterceptor.class);
/* 118 */         interceptorDef.setSource(eleSource);
/* 119 */         interceptorDef.setRole(2);
/* 120 */         AnnotationDrivenCacheBeanDefinitionParser.parseCacheManagerProperty(element, interceptorDef);
/* 121 */         CacheNamespaceHandler.parseKeyGenerator(element, interceptorDef);
/* 122 */         interceptorDef.getPropertyValues().add("cacheOperationSources", new RuntimeBeanReference(sourceName));
/* 123 */         String interceptorName = parserContext.getReaderContext().registerWithGeneratedName(interceptorDef);
/*     */ 
/* 126 */         RootBeanDefinition advisorDef = new RootBeanDefinition(BeanFactoryCacheOperationSourceAdvisor.class);
/* 127 */         advisorDef.setSource(eleSource);
/* 128 */         advisorDef.setRole(2);
/* 129 */         advisorDef.getPropertyValues().add("cacheOperationSource", new RuntimeBeanReference(sourceName));
/* 130 */         advisorDef.getPropertyValues().add("adviceBeanName", interceptorName);
/* 131 */         if (element.hasAttribute("order")) {
/* 132 */           advisorDef.getPropertyValues().add("order", element.getAttribute("order"));
/*     */         }
/* 134 */         parserContext.getRegistry().registerBeanDefinition("org.springframework.cache.config.internalCacheAdvisor", advisorDef);
/*     */ 
/* 136 */         CompositeComponentDefinition compositeDef = new CompositeComponentDefinition(element.getTagName(), eleSource);
/*     */ 
/* 138 */         compositeDef.addNestedComponent(new BeanComponentDefinition(sourceDef, sourceName));
/* 139 */         compositeDef.addNestedComponent(new BeanComponentDefinition(interceptorDef, interceptorName));
/* 140 */         compositeDef.addNestedComponent(new BeanComponentDefinition(advisorDef, "org.springframework.cache.config.internalCacheAdvisor"));
/* 141 */         parserContext.registerComponent(compositeDef);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.config.AnnotationDrivenCacheBeanDefinitionParser
 * JD-Core Version:    0.6.1
 */