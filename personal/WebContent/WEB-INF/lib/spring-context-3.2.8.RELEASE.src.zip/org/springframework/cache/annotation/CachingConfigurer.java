package org.springframework.cache.annotation;

import org.springframework.cache.CacheManager;
import org.springframework.cache.interceptor.KeyGenerator;

public abstract interface CachingConfigurer
{
  public abstract CacheManager cacheManager();

  public abstract KeyGenerator keyGenerator();
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.annotation.CachingConfigurer
 * JD-Core Version:    0.6.1
 */