/*    */ package org.springframework.cache.support;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Collections;
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.Set;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.concurrent.ConcurrentMap;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.cache.Cache;
/*    */ import org.springframework.cache.CacheManager;
/*    */ 
/*    */ public abstract class AbstractCacheManager
/*    */   implements CacheManager, InitializingBean
/*    */ {
/* 40 */   private final ConcurrentMap<String, Cache> cacheMap = new ConcurrentHashMap(16);
/*    */ 
/* 42 */   private Set<String> cacheNames = new LinkedHashSet(16);
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 46 */     Collection caches = loadCaches();
/*    */ 
/* 49 */     this.cacheMap.clear();
/* 50 */     this.cacheNames.clear();
/* 51 */     for (Cache cache : caches) {
/* 52 */       this.cacheMap.put(cache.getName(), decorateCache(cache));
/* 53 */       this.cacheNames.add(cache.getName());
/*    */     }
/*    */   }
/*    */ 
/*    */   protected final void addCache(Cache cache) {
/* 58 */     this.cacheMap.put(cache.getName(), decorateCache(cache));
/* 59 */     this.cacheNames.add(cache.getName());
/*    */   }
/*    */ 
/*    */   protected Cache decorateCache(Cache cache)
/*    */   {
/* 69 */     return cache;
/*    */   }
/*    */ 
/*    */   public Cache getCache(String name)
/*    */   {
/* 74 */     return (Cache)this.cacheMap.get(name);
/*    */   }
/*    */ 
/*    */   public Collection<String> getCacheNames() {
/* 78 */     return Collections.unmodifiableSet(this.cacheNames);
/*    */   }
/*    */ 
/*    */   protected abstract Collection<? extends Cache> loadCaches();
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.support.AbstractCacheManager
 * JD-Core Version:    0.6.1
 */