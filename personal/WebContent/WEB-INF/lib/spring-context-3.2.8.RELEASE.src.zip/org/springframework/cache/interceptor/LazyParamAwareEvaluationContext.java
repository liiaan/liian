/*     */ package org.springframework.cache.interceptor;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.core.ParameterNameDiscoverer;
/*     */ import org.springframework.expression.spel.support.StandardEvaluationContext;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ class LazyParamAwareEvaluationContext extends StandardEvaluationContext
/*     */ {
/*     */   private final ParameterNameDiscoverer paramDiscoverer;
/*     */   private final Method method;
/*     */   private final Object[] args;
/*     */   private final Class<?> targetClass;
/*     */   private final Map<String, Method> methodCache;
/*  50 */   private boolean paramLoaded = false;
/*     */ 
/*     */   LazyParamAwareEvaluationContext(Object rootObject, ParameterNameDiscoverer paramDiscoverer, Method method, Object[] args, Class<?> targetClass, Map<String, Method> methodCache)
/*     */   {
/*  55 */     super(rootObject);
/*     */ 
/*  57 */     this.paramDiscoverer = paramDiscoverer;
/*  58 */     this.method = method;
/*  59 */     this.args = args;
/*  60 */     this.targetClass = targetClass;
/*  61 */     this.methodCache = methodCache;
/*     */   }
/*     */ 
/*     */   public Object lookupVariable(String name)
/*     */   {
/*  70 */     Object variable = super.lookupVariable(name);
/*  71 */     if (variable != null) {
/*  72 */       return variable;
/*     */     }
/*  74 */     if (!this.paramLoaded) {
/*  75 */       loadArgsAsVariables();
/*  76 */       this.paramLoaded = true;
/*  77 */       variable = super.lookupVariable(name);
/*     */     }
/*  79 */     return variable;
/*     */   }
/*     */ 
/*     */   private void loadArgsAsVariables()
/*     */   {
/*  84 */     if (ObjectUtils.isEmpty(this.args)) {
/*  85 */       return;
/*     */     }
/*     */ 
/*  88 */     String mKey = toString(this.method);
/*  89 */     Method targetMethod = (Method)this.methodCache.get(mKey);
/*  90 */     if (targetMethod == null) {
/*  91 */       targetMethod = AopUtils.getMostSpecificMethod(this.method, this.targetClass);
/*  92 */       if (targetMethod == null) {
/*  93 */         targetMethod = this.method;
/*     */       }
/*  95 */       this.methodCache.put(mKey, targetMethod);
/*     */     }
/*     */ 
/*  99 */     for (int i = 0; i < this.args.length; i++) {
/* 100 */       setVariable("a" + i, this.args[i]);
/* 101 */       setVariable("p" + i, this.args[i]);
/*     */     }
/*     */ 
/* 104 */     String[] parameterNames = this.paramDiscoverer.getParameterNames(targetMethod);
/*     */ 
/* 106 */     if (parameterNames != null)
/* 107 */       for (int i = 0; i < parameterNames.length; i++)
/* 108 */         setVariable(parameterNames[i], this.args[i]);
/*     */   }
/*     */ 
/*     */   private String toString(Method m)
/*     */   {
/* 114 */     StringBuilder sb = new StringBuilder();
/* 115 */     sb.append(m.getDeclaringClass().getName());
/* 116 */     sb.append("#");
/* 117 */     sb.append(m.toString());
/* 118 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.LazyParamAwareEvaluationContext
 * JD-Core Version:    0.6.1
 */