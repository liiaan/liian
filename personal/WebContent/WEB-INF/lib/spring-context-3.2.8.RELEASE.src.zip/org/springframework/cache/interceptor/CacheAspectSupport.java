/*     */ package org.springframework.cache.interceptor;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.aop.framework.AopProxyUtils;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.cache.Cache;
/*     */ import org.springframework.cache.Cache.ValueWrapper;
/*     */ import org.springframework.cache.CacheManager;
/*     */ import org.springframework.expression.EvaluationContext;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class CacheAspectSupport
/*     */   implements InitializingBean
/*     */ {
/*     */   private static final String CACHEABLE = "cacheable";
/*     */   private static final String UPDATE = "cacheupdate";
/*     */   private static final String EVICT = "cacheevict";
/*     */   protected final Log logger;
/*     */   private final ExpressionEvaluator evaluator;
/*     */   private CacheManager cacheManager;
/*     */   private CacheOperationSource cacheOperationSource;
/*     */   private KeyGenerator keyGenerator;
/*     */   private boolean initialized;
/*     */ 
/*     */   public CacheAspectSupport()
/*     */   {
/*  72 */     this.logger = LogFactory.getLog(getClass());
/*     */ 
/*  74 */     this.evaluator = new ExpressionEvaluator();
/*     */ 
/*  80 */     this.keyGenerator = new DefaultKeyGenerator();
/*     */ 
/*  82 */     this.initialized = false;
/*     */   }
/*     */ 
/*     */   public void setCacheManager(CacheManager cacheManager)
/*     */   {
/*  89 */     this.cacheManager = cacheManager;
/*     */   }
/*     */ 
/*     */   public CacheManager getCacheManager()
/*     */   {
/*  96 */     return this.cacheManager;
/*     */   }
/*     */ 
/*     */   public void setCacheOperationSources(CacheOperationSource[] cacheOperationSources)
/*     */   {
/* 106 */     Assert.notEmpty(cacheOperationSources);
/* 107 */     this.cacheOperationSource = (cacheOperationSources.length > 1 ? new CompositeCacheOperationSource(cacheOperationSources) : cacheOperationSources[0]);
/*     */   }
/*     */ 
/*     */   public CacheOperationSource getCacheOperationSource()
/*     */   {
/* 115 */     return this.cacheOperationSource;
/*     */   }
/*     */ 
/*     */   public void setKeyGenerator(KeyGenerator keyGenerator)
/*     */   {
/* 123 */     this.keyGenerator = keyGenerator;
/*     */   }
/*     */ 
/*     */   public KeyGenerator getKeyGenerator()
/*     */   {
/* 130 */     return this.keyGenerator;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() {
/* 134 */     if (this.cacheManager == null) {
/* 135 */       throw new IllegalStateException("'cacheManager' is required");
/*     */     }
/* 137 */     if (this.cacheOperationSource == null) {
/* 138 */       throw new IllegalStateException("The 'cacheOperationSources' property is required: If there are no cacheable methods, then don't use a cache aspect.");
/*     */     }
/*     */ 
/* 142 */     this.initialized = true;
/*     */   }
/*     */ 
/*     */   protected String methodIdentification(Method method, Class<?> targetClass)
/*     */   {
/* 156 */     Method specificMethod = ClassUtils.getMostSpecificMethod(method, targetClass);
/* 157 */     return ClassUtils.getQualifiedMethodName(specificMethod);
/*     */   }
/*     */ 
/*     */   protected Collection<Cache> getCaches(CacheOperation operation) {
/* 161 */     Set cacheNames = operation.getCacheNames();
/* 162 */     Collection caches = new ArrayList(cacheNames.size());
/* 163 */     for (String cacheName : cacheNames) {
/* 164 */       Cache cache = this.cacheManager.getCache(cacheName);
/* 165 */       if (cache == null) {
/* 166 */         throw new IllegalArgumentException("Cannot find cache named '" + cacheName + "' for " + operation);
/*     */       }
/* 168 */       caches.add(cache);
/*     */     }
/* 170 */     return caches;
/*     */   }
/*     */ 
/*     */   protected CacheOperationContext getOperationContext(CacheOperation operation, Method method, Object[] args, Object target, Class<?> targetClass)
/*     */   {
/* 176 */     return new CacheOperationContext(operation, method, args, target, targetClass);
/*     */   }
/*     */ 
/*     */   protected Object execute(Invoker invoker, Object target, Method method, Object[] args)
/*     */   {
/* 182 */     if (!this.initialized) {
/* 183 */       return invoker.invoke();
/*     */     }
/*     */ 
/* 187 */     Class targetClass = AopProxyUtils.ultimateTargetClass(target);
/* 188 */     if ((targetClass == null) && (target != null)) {
/* 189 */       targetClass = target.getClass();
/*     */     }
/* 191 */     Collection cacheOp = getCacheOperationSource().getCacheOperations(method, targetClass);
/*     */ 
/* 194 */     if (!CollectionUtils.isEmpty(cacheOp)) {
/* 195 */       Map ops = createOperationContext(cacheOp, method, args, target, targetClass);
/*     */ 
/* 197 */       inspectBeforeCacheEvicts((Collection)ops.get("cacheevict"));
/*     */ 
/* 199 */       CacheStatus status = inspectCacheables((Collection)ops.get("cacheable"));
/*     */ 
/* 201 */       Map updates = inspectCacheUpdates((Collection)ops.get("cacheupdate"));
/* 202 */       if (status != null) {
/* 203 */         if (status.updateRequired) {
/* 204 */           updates.putAll(status.cacheUpdates);
/*     */         }
/*     */         else
/*     */         {
/* 208 */           return status.retVal;
/*     */         }
/*     */       }
/* 211 */       Object retVal = invoker.invoke();
/* 212 */       inspectAfterCacheEvicts((Collection)ops.get("cacheevict"), retVal);
/* 213 */       if (!updates.isEmpty()) {
/* 214 */         update(updates, retVal);
/*     */       }
/* 216 */       return retVal;
/*     */     }
/*     */ 
/* 219 */     return invoker.invoke();
/*     */   }
/*     */ 
/*     */   private void inspectBeforeCacheEvicts(Collection<CacheOperationContext> evictions) {
/* 223 */     inspectCacheEvicts(evictions, true, ExpressionEvaluator.NO_RESULT);
/*     */   }
/*     */ 
/*     */   private void inspectAfterCacheEvicts(Collection<CacheOperationContext> evictions, Object result) {
/* 227 */     inspectCacheEvicts(evictions, false, result);
/*     */   }
/*     */ 
/*     */   private void inspectCacheEvicts(Collection<CacheOperationContext> evictions, boolean beforeInvocation, Object result)
/*     */   {
/*     */     boolean log;
/* 231 */     if (!evictions.isEmpty()) {
/* 232 */       log = this.logger.isTraceEnabled();
/* 233 */       for (CacheOperationContext context : evictions) {
/* 234 */         CacheEvictOperation evictOp = (CacheEvictOperation)context.operation;
/* 235 */         if (beforeInvocation == evictOp.isBeforeInvocation())
/*     */         {
/*     */           Object key;
/* 236 */           if (context.isConditionPassing(result))
/*     */           {
/* 239 */             key = null;
/* 240 */             for (Cache cache : context.getCaches())
/*     */             {
/* 242 */               if (evictOp.isCacheWide()) {
/* 243 */                 cache.clear();
/* 244 */                 if (log) {
/* 245 */                   this.logger.trace("Invalidating entire cache for operation " + evictOp + " on method " + context.method);
/*     */                 }
/*     */               }
/*     */               else
/*     */               {
/* 250 */                 if (key == null) {
/* 251 */                   key = context.generateKey();
/*     */                 }
/* 253 */                 if (log) {
/* 254 */                   this.logger.trace("Invalidating cache key " + key + " for operation " + evictOp + " on method " + context.method);
/*     */                 }
/* 256 */                 cache.evict(key);
/*     */               }
/*     */             }
/*     */ 
/*     */           }
/* 261 */           else if (log) {
/* 262 */             this.logger.trace("Cache condition failed on method " + context.method + " for operation " + context.operation);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private CacheStatus inspectCacheables(Collection<CacheOperationContext> cacheables)
/*     */   {
/* 271 */     Map cacheUpdates = new LinkedHashMap(cacheables.size());
/* 272 */     boolean cacheHit = false;
/* 273 */     Object retVal = null;
/*     */ 
/* 275 */     if (!cacheables.isEmpty()) {
/* 276 */       boolean log = this.logger.isTraceEnabled();
/* 277 */       boolean atLeastOnePassed = false;
/* 278 */       for (CacheOperationContext context : cacheables)
/*     */       {
/*     */         Object key;
/* 279 */         if (context.isConditionPassing()) {
/* 280 */           atLeastOnePassed = true;
/* 281 */           key = context.generateKey();
/* 282 */           if (log) {
/* 283 */             this.logger.trace("Computed cache key " + key + " for operation " + context.operation);
/*     */           }
/* 285 */           if (key == null) {
/* 286 */             throw new IllegalArgumentException("Null key returned for cache operation (maybe you are using named params on classes without debug info?) " + context.operation);
/*     */           }
/*     */ 
/* 290 */           cacheUpdates.put(context, key);
/*     */ 
/* 292 */           if (!cacheHit) {
/* 293 */             for (Cache cache : context.getCaches()) {
/* 294 */               Cache.ValueWrapper wrapper = cache.get(key);
/* 295 */               if (wrapper != null) {
/* 296 */                 retVal = wrapper.get();
/* 297 */                 cacheHit = true;
/* 298 */                 break;
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/*     */         }
/* 304 */         else if (log) {
/* 305 */           this.logger.trace("Cache condition failed on method " + context.method + " for operation " + context.operation);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 311 */       if (atLeastOnePassed) {
/* 312 */         return new CacheStatus(cacheUpdates, !cacheHit, retVal);
/*     */       }
/*     */     }
/*     */ 
/* 316 */     return null;
/*     */   }
/*     */ 
/*     */   private Map<CacheOperationContext, Object> inspectCacheUpdates(Collection<CacheOperationContext> updates) {
/* 320 */     Map cacheUpdates = new LinkedHashMap(updates.size());
/*     */     boolean log;
/* 321 */     if (!updates.isEmpty()) {
/* 322 */       log = this.logger.isTraceEnabled();
/* 323 */       for (CacheOperationContext context : updates) {
/* 324 */         if (context.isConditionPassing()) {
/* 325 */           Object key = context.generateKey();
/* 326 */           if (log) {
/* 327 */             this.logger.trace("Computed cache key " + key + " for operation " + context.operation);
/*     */           }
/* 329 */           if (key == null) {
/* 330 */             throw new IllegalArgumentException("Null key returned for cache operation (maybe you are using named params on classes without debug info?) " + context.operation);
/*     */           }
/*     */ 
/* 334 */           cacheUpdates.put(context, key);
/*     */         }
/* 337 */         else if (log) {
/* 338 */           this.logger.trace("Cache condition failed on method " + context.method + " for operation " + context.operation);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 343 */     return cacheUpdates;
/*     */   }
/*     */ 
/*     */   private void update(Map<CacheOperationContext, Object> updates, Object retVal) {
/* 347 */     for (Iterator i$ = updates.entrySet().iterator(); i$.hasNext(); ) { entry = (Map.Entry)i$.next();
/* 348 */       CacheOperationContext operationContext = (CacheOperationContext)entry.getKey();
/* 349 */       if (operationContext.canPutToCache(retVal))
/* 350 */         for (Cache cache : operationContext.getCaches())
/* 351 */           cache.put(entry.getValue(), retVal);
/*     */     }
/*     */     Map.Entry entry;
/*     */   }
/*     */ 
/*     */   private Map<String, Collection<CacheOperationContext>> createOperationContext(Collection<CacheOperation> cacheOperations, Method method, Object[] args, Object target, Class<?> targetClass)
/*     */   {
/* 360 */     Map result = new LinkedHashMap(3);
/* 361 */     Collection cacheables = new ArrayList();
/* 362 */     Collection evicts = new ArrayList();
/* 363 */     Collection updates = new ArrayList();
/*     */ 
/* 365 */     for (CacheOperation cacheOperation : cacheOperations) {
/* 366 */       CacheOperationContext opContext = getOperationContext(cacheOperation, method, args, target, targetClass);
/* 367 */       if ((cacheOperation instanceof CacheableOperation)) {
/* 368 */         cacheables.add(opContext);
/*     */       }
/* 370 */       if ((cacheOperation instanceof CacheEvictOperation)) {
/* 371 */         evicts.add(opContext);
/*     */       }
/* 373 */       if ((cacheOperation instanceof CachePutOperation)) {
/* 374 */         updates.add(opContext);
/*     */       }
/*     */     }
/*     */ 
/* 378 */     result.put("cacheable", cacheables);
/* 379 */     result.put("cacheevict", evicts);
/* 380 */     result.put("cacheupdate", updates);
/* 381 */     return result;
/*     */   }
/*     */ 
/*     */   private static class CacheStatus
/*     */   {
/*     */     final Map<CacheAspectSupport.CacheOperationContext, Object> cacheUpdates;
/*     */     final boolean updateRequired;
/*     */     final Object retVal;
/*     */ 
/*     */     CacheStatus(Map<CacheAspectSupport.CacheOperationContext, Object> cacheUpdates, boolean updateRequired, Object retVal)
/*     */     {
/* 473 */       this.cacheUpdates = cacheUpdates;
/* 474 */       this.updateRequired = updateRequired;
/* 475 */       this.retVal = retVal;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class CacheOperationContext
/*     */   {
/*     */     private final CacheOperation operation;
/*     */     private final Method method;
/*     */     private final Object[] args;
/*     */     private final Object target;
/*     */     private final Class<?> targetClass;
/*     */     private final Collection<Cache> caches;
/*     */ 
/*     */     public CacheOperationContext(Method operation, Object[] method, Object args, Class<?> target)
/*     */     {
/* 406 */       this.operation = operation;
/* 407 */       this.method = method;
/* 408 */       this.args = args;
/* 409 */       this.target = target;
/* 410 */       this.targetClass = targetClass;
/* 411 */       this.caches = CacheAspectSupport.this.getCaches(operation);
/*     */     }
/*     */ 
/*     */     protected boolean isConditionPassing() {
/* 415 */       return isConditionPassing(ExpressionEvaluator.NO_RESULT);
/*     */     }
/*     */ 
/*     */     protected boolean isConditionPassing(Object result) {
/* 419 */       if (StringUtils.hasText(this.operation.getCondition())) {
/* 420 */         EvaluationContext evaluationContext = createEvaluationContext(result);
/* 421 */         return CacheAspectSupport.this.evaluator.condition(this.operation.getCondition(), this.method, evaluationContext);
/*     */       }
/* 423 */       return true;
/*     */     }
/*     */ 
/*     */     protected boolean canPutToCache(Object value) {
/* 427 */       String unless = "";
/* 428 */       if ((this.operation instanceof CacheableOperation)) {
/* 429 */         unless = ((CacheableOperation)this.operation).getUnless();
/*     */       }
/* 431 */       else if ((this.operation instanceof CachePutOperation)) {
/* 432 */         unless = ((CachePutOperation)this.operation).getUnless();
/*     */       }
/* 434 */       if (StringUtils.hasText(unless)) {
/* 435 */         EvaluationContext evaluationContext = createEvaluationContext(value);
/* 436 */         return !CacheAspectSupport.this.evaluator.unless(unless, this.method, evaluationContext);
/*     */       }
/* 438 */       return true;
/*     */     }
/*     */ 
/*     */     protected Object generateKey()
/*     */     {
/* 446 */       if (StringUtils.hasText(this.operation.getKey())) {
/* 447 */         EvaluationContext evaluationContext = createEvaluationContext(ExpressionEvaluator.NO_RESULT);
/* 448 */         return CacheAspectSupport.this.evaluator.key(this.operation.getKey(), this.method, evaluationContext);
/*     */       }
/* 450 */       return CacheAspectSupport.this.keyGenerator.generate(this.target, this.method, this.args);
/*     */     }
/*     */ 
/*     */     private EvaluationContext createEvaluationContext(Object result) {
/* 454 */       return CacheAspectSupport.this.evaluator.createEvaluationContext(this.caches, this.method, this.args, this.target, this.targetClass, result);
/*     */     }
/*     */ 
/*     */     protected Collection<Cache> getCaches() {
/* 458 */       return this.caches;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface Invoker
/*     */   {
/*     */     public abstract Object invoke();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.CacheAspectSupport
 * JD-Core Version:    0.6.1
 */