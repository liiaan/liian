/*    */ package org.springframework.cache.support;
/*    */ 
/*    */ import org.springframework.cache.Cache.ValueWrapper;
/*    */ 
/*    */ public class SimpleValueWrapper
/*    */   implements Cache.ValueWrapper
/*    */ {
/*    */   private final Object value;
/*    */ 
/*    */   public SimpleValueWrapper(Object value)
/*    */   {
/* 38 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public Object get()
/*    */   {
/* 46 */     return this.value;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.support.SimpleValueWrapper
 * JD-Core Version:    0.6.1
 */