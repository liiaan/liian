/*     */ package org.springframework.cache.annotation;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.AnnotatedElement;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.springframework.cache.interceptor.AbstractFallbackCacheOperationSource;
/*     */ import org.springframework.cache.interceptor.CacheOperation;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class AnnotationCacheOperationSource extends AbstractFallbackCacheOperationSource
/*     */   implements Serializable
/*     */ {
/*     */   private final boolean publicMethodsOnly;
/*     */   private final Set<CacheAnnotationParser> annotationParsers;
/*     */ 
/*     */   public AnnotationCacheOperationSource()
/*     */   {
/*  59 */     this(true);
/*     */   }
/*     */ 
/*     */   public AnnotationCacheOperationSource(boolean publicMethodsOnly)
/*     */   {
/*  70 */     this.publicMethodsOnly = publicMethodsOnly;
/*  71 */     this.annotationParsers = new LinkedHashSet(1);
/*  72 */     this.annotationParsers.add(new SpringCacheAnnotationParser());
/*     */   }
/*     */ 
/*     */   public AnnotationCacheOperationSource(CacheAnnotationParser annotationParser)
/*     */   {
/*  80 */     this.publicMethodsOnly = true;
/*  81 */     Assert.notNull(annotationParser, "CacheAnnotationParser must not be null");
/*  82 */     this.annotationParsers = Collections.singleton(annotationParser);
/*     */   }
/*     */ 
/*     */   public AnnotationCacheOperationSource(CacheAnnotationParser[] annotationParsers)
/*     */   {
/*  90 */     this.publicMethodsOnly = true;
/*  91 */     Assert.notEmpty(annotationParsers, "At least one CacheAnnotationParser needs to be specified");
/*  92 */     Set parsers = new LinkedHashSet(annotationParsers.length);
/*  93 */     Collections.addAll(parsers, annotationParsers);
/*  94 */     this.annotationParsers = parsers;
/*     */   }
/*     */ 
/*     */   public AnnotationCacheOperationSource(Set<CacheAnnotationParser> annotationParsers)
/*     */   {
/* 102 */     this.publicMethodsOnly = true;
/* 103 */     Assert.notEmpty(annotationParsers, "At least one CacheAnnotationParser needs to be specified");
/* 104 */     this.annotationParsers = annotationParsers;
/*     */   }
/*     */ 
/*     */   protected Collection<CacheOperation> findCacheOperations(Class<?> clazz)
/*     */   {
/* 110 */     return determineCacheOperations(clazz);
/*     */   }
/*     */ 
/*     */   protected Collection<CacheOperation> findCacheOperations(Method method)
/*     */   {
/* 115 */     return determineCacheOperations(method);
/*     */   }
/*     */ 
/*     */   protected Collection<CacheOperation> determineCacheOperations(AnnotatedElement ae)
/*     */   {
/* 129 */     Collection ops = null;
/* 130 */     for (CacheAnnotationParser annotationParser : this.annotationParsers) {
/* 131 */       Collection annOps = annotationParser.parseCacheAnnotations(ae);
/* 132 */       if (annOps != null) {
/* 133 */         if (ops == null) {
/* 134 */           ops = new ArrayList();
/*     */         }
/* 136 */         ops.addAll(annOps);
/*     */       }
/*     */     }
/* 139 */     return ops;
/*     */   }
/*     */ 
/*     */   protected boolean allowPublicMethodsOnly()
/*     */   {
/* 147 */     return this.publicMethodsOnly;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 153 */     if (this == other) {
/* 154 */       return true;
/*     */     }
/* 156 */     if (!(other instanceof AnnotationCacheOperationSource)) {
/* 157 */       return false;
/*     */     }
/* 159 */     AnnotationCacheOperationSource otherCos = (AnnotationCacheOperationSource)other;
/* 160 */     return (this.annotationParsers.equals(otherCos.annotationParsers)) && (this.publicMethodsOnly == otherCos.publicMethodsOnly);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 166 */     return this.annotationParsers.hashCode();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.annotation.AnnotationCacheOperationSource
 * JD-Core Version:    0.6.1
 */