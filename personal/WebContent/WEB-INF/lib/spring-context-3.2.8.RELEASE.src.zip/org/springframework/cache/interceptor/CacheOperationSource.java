package org.springframework.cache.interceptor;

import java.lang.reflect.Method;
import java.util.Collection;

public abstract interface CacheOperationSource
{
  public abstract Collection<CacheOperation> getCacheOperations(Method paramMethod, Class<?> paramClass);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.CacheOperationSource
 * JD-Core Version:    0.6.1
 */