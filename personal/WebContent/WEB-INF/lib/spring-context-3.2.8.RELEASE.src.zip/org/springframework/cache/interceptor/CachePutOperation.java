/*    */ package org.springframework.cache.interceptor;
/*    */ 
/*    */ public class CachePutOperation extends CacheOperation
/*    */ {
/*    */   private String unless;
/*    */ 
/*    */   public String getUnless()
/*    */   {
/* 32 */     return this.unless;
/*    */   }
/*    */ 
/*    */   public void setUnless(String unless) {
/* 36 */     this.unless = unless;
/*    */   }
/*    */ 
/*    */   protected StringBuilder getOperationDescription()
/*    */   {
/* 41 */     StringBuilder sb = super.getOperationDescription();
/* 42 */     sb.append(" | unless='");
/* 43 */     sb.append(this.unless);
/* 44 */     sb.append("'");
/* 45 */     return sb;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.interceptor.CachePutOperation
 * JD-Core Version:    0.6.1
 */