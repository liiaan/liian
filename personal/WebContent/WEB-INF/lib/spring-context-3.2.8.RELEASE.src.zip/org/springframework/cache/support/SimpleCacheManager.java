/*    */ package org.springframework.cache.support;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.cache.Cache;
/*    */ 
/*    */ public class SimpleCacheManager extends AbstractCacheManager
/*    */ {
/*    */   private Collection<? extends Cache> caches;
/*    */ 
/*    */   public void setCaches(Collection<? extends Cache> caches)
/*    */   {
/* 38 */     this.caches = caches;
/*    */   }
/*    */ 
/*    */   protected Collection<? extends Cache> loadCaches()
/*    */   {
/* 43 */     return this.caches;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.support.SimpleCacheManager
 * JD-Core Version:    0.6.1
 */