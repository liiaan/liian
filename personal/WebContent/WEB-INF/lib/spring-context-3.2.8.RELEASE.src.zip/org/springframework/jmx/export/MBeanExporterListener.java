package org.springframework.jmx.export;

import javax.management.ObjectName;

public abstract interface MBeanExporterListener
{
  public abstract void mbeanRegistered(ObjectName paramObjectName);

  public abstract void mbeanUnregistered(ObjectName paramObjectName);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.MBeanExporterListener
 * JD-Core Version:    0.6.1
 */