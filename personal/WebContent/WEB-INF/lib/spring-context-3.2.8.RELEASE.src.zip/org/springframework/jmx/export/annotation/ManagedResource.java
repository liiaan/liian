package org.springframework.jmx.export.annotation;

import java.lang.annotation.Annotation;
import java.lang.annotation.Documented;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({java.lang.annotation.ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface ManagedResource
{
  public abstract String value();

  public abstract String objectName();

  public abstract String description();

  public abstract int currencyTimeLimit();

  public abstract boolean log();

  public abstract String logFile();

  public abstract String persistPolicy();

  public abstract int persistPeriod();

  public abstract String persistName();

  public abstract String persistLocation();
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.annotation.ManagedResource
 * JD-Core Version:    0.6.1
 */