package org.springframework.jmx.export.notification;

import javax.management.Notification;

public abstract interface NotificationPublisher
{
  public abstract void sendNotification(Notification paramNotification)
    throws UnableToSendNotificationException;
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.notification.NotificationPublisher
 * JD-Core Version:    0.6.1
 */