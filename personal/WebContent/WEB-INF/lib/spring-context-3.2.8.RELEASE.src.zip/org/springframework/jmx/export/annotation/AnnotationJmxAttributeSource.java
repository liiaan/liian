/*     */ package org.springframework.jmx.export.annotation;
/*     */ 
/*     */ import java.lang.annotation.Annotation;
/*     */ import java.lang.reflect.Method;
/*     */ import org.springframework.beans.annotation.AnnotationBeanUtils;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*     */ import org.springframework.core.annotation.AnnotationUtils;
/*     */ import org.springframework.jmx.export.metadata.InvalidMetadataException;
/*     */ import org.springframework.jmx.export.metadata.JmxAttributeSource;
/*     */ import org.springframework.jmx.export.metadata.ManagedNotification;
/*     */ import org.springframework.jmx.export.metadata.ManagedOperationParameter;
/*     */ import org.springframework.util.StringUtils;
/*     */ import org.springframework.util.StringValueResolver;
/*     */ 
/*     */ public class AnnotationJmxAttributeSource
/*     */   implements JmxAttributeSource, BeanFactoryAware
/*     */ {
/*     */   private StringValueResolver embeddedValueResolver;
/*     */ 
/*     */   public void setBeanFactory(final BeanFactory beanFactory)
/*     */   {
/*  56 */     if ((beanFactory instanceof ConfigurableBeanFactory))
/*     */     {
/*  59 */       this.embeddedValueResolver = new StringValueResolver() {
/*     */         public String resolveStringValue(String strVal) {
/*  61 */           return ((ConfigurableBeanFactory)beanFactory).resolveEmbeddedValue(strVal);
/*     */         }
/*     */       };
/*     */     }
/*     */   }
/*     */ 
/*     */   public org.springframework.jmx.export.metadata.ManagedResource getManagedResource(Class<?> beanClass) throws InvalidMetadataException
/*     */   {
/*  69 */     ManagedResource ann = (ManagedResource)beanClass.getAnnotation(ManagedResource.class);
/*     */ 
/*  71 */     if (ann == null) {
/*  72 */       return null;
/*     */     }
/*  74 */     org.springframework.jmx.export.metadata.ManagedResource managedResource = new org.springframework.jmx.export.metadata.ManagedResource();
/*  75 */     AnnotationBeanUtils.copyPropertiesToBean(ann, managedResource, this.embeddedValueResolver, new String[0]);
/*  76 */     if ((!"".equals(ann.value())) && (!StringUtils.hasLength(managedResource.getObjectName()))) {
/*  77 */       String value = ann.value();
/*  78 */       if (this.embeddedValueResolver != null) {
/*  79 */         value = this.embeddedValueResolver.resolveStringValue(value);
/*     */       }
/*  81 */       managedResource.setObjectName(value);
/*     */     }
/*  83 */     return managedResource;
/*     */   }
/*     */ 
/*     */   public org.springframework.jmx.export.metadata.ManagedAttribute getManagedAttribute(Method method) throws InvalidMetadataException {
/*  87 */     ManagedAttribute ann = (ManagedAttribute)AnnotationUtils.findAnnotation(method, ManagedAttribute.class);
/*     */ 
/*  89 */     if (ann == null) {
/*  90 */       return null;
/*     */     }
/*  92 */     org.springframework.jmx.export.metadata.ManagedAttribute managedAttribute = new org.springframework.jmx.export.metadata.ManagedAttribute();
/*  93 */     AnnotationBeanUtils.copyPropertiesToBean(ann, managedAttribute, new String[] { "defaultValue" });
/*  94 */     if (ann.defaultValue().length() > 0) {
/*  95 */       managedAttribute.setDefaultValue(ann.defaultValue());
/*     */     }
/*  97 */     return managedAttribute;
/*     */   }
/*     */ 
/*     */   public org.springframework.jmx.export.metadata.ManagedMetric getManagedMetric(Method method) throws InvalidMetadataException {
/* 101 */     ManagedMetric ann = (ManagedMetric)AnnotationUtils.findAnnotation(method, ManagedMetric.class);
/*     */ 
/* 103 */     if (ann == null) {
/* 104 */       return null;
/*     */     }
/* 106 */     org.springframework.jmx.export.metadata.ManagedMetric managedMetric = new org.springframework.jmx.export.metadata.ManagedMetric();
/* 107 */     AnnotationBeanUtils.copyPropertiesToBean(ann, managedMetric, new String[0]);
/* 108 */     return managedMetric;
/*     */   }
/*     */ 
/*     */   public org.springframework.jmx.export.metadata.ManagedOperation getManagedOperation(Method method) throws InvalidMetadataException {
/* 112 */     Annotation ann = AnnotationUtils.findAnnotation(method, ManagedOperation.class);
/* 113 */     if (ann == null) {
/* 114 */       return null;
/*     */     }
/* 116 */     org.springframework.jmx.export.metadata.ManagedOperation op = new org.springframework.jmx.export.metadata.ManagedOperation();
/* 117 */     AnnotationBeanUtils.copyPropertiesToBean(ann, op, new String[0]);
/* 118 */     return op;
/*     */   }
/*     */ 
/*     */   public ManagedOperationParameter[] getManagedOperationParameters(Method method)
/*     */     throws InvalidMetadataException
/*     */   {
/* 124 */     ManagedOperationParameters params = (ManagedOperationParameters)AnnotationUtils.findAnnotation(method, ManagedOperationParameters.class);
/* 125 */     ManagedOperationParameter[] result = null;
/* 126 */     if (params == null) {
/* 127 */       result = new ManagedOperationParameter[0];
/*     */     }
/*     */     else {
/* 130 */       Annotation[] paramData = params.value();
/* 131 */       result = new ManagedOperationParameter[paramData.length];
/* 132 */       for (int i = 0; i < paramData.length; i++) {
/* 133 */         Annotation annotation = paramData[i];
/* 134 */         ManagedOperationParameter managedOperationParameter = new ManagedOperationParameter();
/* 135 */         AnnotationBeanUtils.copyPropertiesToBean(annotation, managedOperationParameter, new String[0]);
/* 136 */         result[i] = managedOperationParameter;
/*     */       }
/*     */     }
/* 139 */     return result;
/*     */   }
/*     */ 
/*     */   public ManagedNotification[] getManagedNotifications(Class<?> clazz) throws InvalidMetadataException {
/* 143 */     ManagedNotifications notificationsAnn = (ManagedNotifications)clazz.getAnnotation(ManagedNotifications.class);
/* 144 */     if (notificationsAnn == null) {
/* 145 */       return new ManagedNotification[0];
/*     */     }
/* 147 */     Annotation[] notifications = notificationsAnn.value();
/* 148 */     ManagedNotification[] result = new ManagedNotification[notifications.length];
/* 149 */     for (int i = 0; i < notifications.length; i++) {
/* 150 */       Annotation notification = notifications[i];
/* 151 */       ManagedNotification managedNotification = new ManagedNotification();
/* 152 */       AnnotationBeanUtils.copyPropertiesToBean(notification, managedNotification, new String[0]);
/* 153 */       result[i] = managedNotification;
/*     */     }
/* 155 */     return result;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.annotation.AnnotationJmxAttributeSource
 * JD-Core Version:    0.6.1
 */