package org.springframework.jmx.export.annotation;

import java.lang.annotation.Annotation;

public @interface ManagedOperationParameter
{
  public abstract String name();

  public abstract String description();
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.annotation.ManagedOperationParameter
 * JD-Core Version:    0.6.1
 */