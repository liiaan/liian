/*     */ package org.springframework.jmx.export.assembler;
/*     */ 
/*     */ import javax.management.Descriptor;
/*     */ import javax.management.JMException;
/*     */ import javax.management.modelmbean.ModelMBeanAttributeInfo;
/*     */ import javax.management.modelmbean.ModelMBeanConstructorInfo;
/*     */ import javax.management.modelmbean.ModelMBeanInfo;
/*     */ import javax.management.modelmbean.ModelMBeanInfoSupport;
/*     */ import javax.management.modelmbean.ModelMBeanNotificationInfo;
/*     */ import javax.management.modelmbean.ModelMBeanOperationInfo;
/*     */ import org.springframework.aop.support.AopUtils;
/*     */ import org.springframework.jmx.support.JmxUtils;
/*     */ 
/*     */ public abstract class AbstractMBeanInfoAssembler
/*     */   implements MBeanInfoAssembler
/*     */ {
/*     */   public ModelMBeanInfo getMBeanInfo(Object managedBean, String beanKey)
/*     */     throws JMException
/*     */   {
/*  63 */     checkManagedBean(managedBean);
/*  64 */     ModelMBeanInfo info = new ModelMBeanInfoSupport(getClassName(managedBean, beanKey), getDescription(managedBean, beanKey), getAttributeInfo(managedBean, beanKey), getConstructorInfo(managedBean, beanKey), getOperationInfo(managedBean, beanKey), getNotificationInfo(managedBean, beanKey));
/*     */ 
/*  68 */     Descriptor desc = info.getMBeanDescriptor();
/*  69 */     populateMBeanDescriptor(desc, managedBean, beanKey);
/*  70 */     info.setMBeanDescriptor(desc);
/*  71 */     return info;
/*     */   }
/*     */ 
/*     */   protected void checkManagedBean(Object managedBean)
/*     */     throws IllegalArgumentException
/*     */   {
/*     */   }
/*     */ 
/*     */   protected Class getTargetClass(Object managedBean)
/*     */   {
/*  94 */     return AopUtils.getTargetClass(managedBean);
/*     */   }
/*     */ 
/*     */   protected Class<?> getClassToExpose(Object managedBean)
/*     */   {
/* 106 */     return JmxUtils.getClassToExpose(managedBean);
/*     */   }
/*     */ 
/*     */   protected Class<?> getClassToExpose(Class<?> beanClass)
/*     */   {
/* 117 */     return JmxUtils.getClassToExpose(beanClass);
/*     */   }
/*     */ 
/*     */   protected String getClassName(Object managedBean, String beanKey)
/*     */     throws JMException
/*     */   {
/* 131 */     return getTargetClass(managedBean).getName();
/*     */   }
/*     */ 
/*     */   protected String getDescription(Object managedBean, String beanKey)
/*     */     throws JMException
/*     */   {
/* 144 */     String targetClassName = getTargetClass(managedBean).getName();
/* 145 */     if (AopUtils.isAopProxy(managedBean)) {
/* 146 */       return "Proxy for " + targetClassName;
/*     */     }
/* 148 */     return targetClassName;
/*     */   }
/*     */ 
/*     */   protected void populateMBeanDescriptor(Descriptor descriptor, Object managedBean, String beanKey)
/*     */     throws JMException
/*     */   {
/*     */   }
/*     */ 
/*     */   protected ModelMBeanConstructorInfo[] getConstructorInfo(Object managedBean, String beanKey)
/*     */     throws JMException
/*     */   {
/* 179 */     return new ModelMBeanConstructorInfo[0];
/*     */   }
/*     */ 
/*     */   protected ModelMBeanNotificationInfo[] getNotificationInfo(Object managedBean, String beanKey)
/*     */     throws JMException
/*     */   {
/* 195 */     return new ModelMBeanNotificationInfo[0];
/*     */   }
/*     */ 
/*     */   protected abstract ModelMBeanAttributeInfo[] getAttributeInfo(Object paramObject, String paramString)
/*     */     throws JMException;
/*     */ 
/*     */   protected abstract ModelMBeanOperationInfo[] getOperationInfo(Object paramObject, String paramString)
/*     */     throws JMException;
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.assembler.AbstractMBeanInfoAssembler
 * JD-Core Version:    0.6.1
 */