/*      */ package org.springframework.jmx.export;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Set;
/*      */ import javax.management.DynamicMBean;
/*      */ import javax.management.JMException;
/*      */ import javax.management.MBeanException;
/*      */ import javax.management.MBeanServer;
/*      */ import javax.management.MalformedObjectNameException;
/*      */ import javax.management.NotCompliantMBeanException;
/*      */ import javax.management.NotificationListener;
/*      */ import javax.management.ObjectName;
/*      */ import javax.management.StandardMBean;
/*      */ import javax.management.modelmbean.ModelMBean;
/*      */ import javax.management.modelmbean.ModelMBeanInfo;
/*      */ import javax.management.modelmbean.RequiredModelMBean;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.springframework.aop.framework.ProxyFactory;
/*      */ import org.springframework.aop.support.AopUtils;
/*      */ import org.springframework.aop.target.LazyInitTargetSource;
/*      */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*      */ import org.springframework.beans.factory.BeanFactory;
/*      */ import org.springframework.beans.factory.BeanFactoryAware;
/*      */ import org.springframework.beans.factory.CannotLoadBeanClassException;
/*      */ import org.springframework.beans.factory.DisposableBean;
/*      */ import org.springframework.beans.factory.InitializingBean;
/*      */ import org.springframework.beans.factory.ListableBeanFactory;
/*      */ import org.springframework.beans.factory.config.BeanDefinition;
/*      */ import org.springframework.beans.factory.config.ConfigurableBeanFactory;
/*      */ import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
/*      */ import org.springframework.core.Constants;
/*      */ import org.springframework.jmx.export.assembler.AutodetectCapableMBeanInfoAssembler;
/*      */ import org.springframework.jmx.export.assembler.MBeanInfoAssembler;
/*      */ import org.springframework.jmx.export.assembler.SimpleReflectiveMBeanInfoAssembler;
/*      */ import org.springframework.jmx.export.naming.KeyNamingStrategy;
/*      */ import org.springframework.jmx.export.naming.ObjectNamingStrategy;
/*      */ import org.springframework.jmx.export.naming.SelfNaming;
/*      */ import org.springframework.jmx.export.notification.ModelMBeanNotificationPublisher;
/*      */ import org.springframework.jmx.export.notification.NotificationPublisherAware;
/*      */ import org.springframework.jmx.support.JmxUtils;
/*      */ import org.springframework.jmx.support.MBeanRegistrationSupport;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.ClassUtils;
/*      */ import org.springframework.util.CollectionUtils;
/*      */ import org.springframework.util.ObjectUtils;
/*      */ 
/*      */ public class MBeanExporter extends MBeanRegistrationSupport
/*      */   implements MBeanExportOperations, BeanClassLoaderAware, BeanFactoryAware, InitializingBean, DisposableBean
/*      */ {
/*      */   public static final int AUTODETECT_NONE = 0;
/*      */   public static final int AUTODETECT_MBEAN = 1;
/*      */   public static final int AUTODETECT_ASSEMBLER = 2;
/*      */   public static final int AUTODETECT_ALL = 3;
/*      */   private static final String WILDCARD = "*";
/*      */   private static final String MR_TYPE_OBJECT_REFERENCE = "ObjectReference";
/*      */   private static final String CONSTANT_PREFIX_AUTODETECT = "AUTODETECT_";
/*  138 */   private static final Constants constants = new Constants(MBeanExporter.class);
/*      */   private Map<String, Object> beans;
/*      */   private Integer autodetectMode;
/*      */   private boolean allowEagerInit;
/*      */   private boolean ensureUniqueRuntimeObjectNames;
/*      */   private boolean exposeManagedResourceClassLoader;
/*      */   private Set<String> excludedBeans;
/*      */   private MBeanExporterListener[] listeners;
/*      */   private NotificationListenerBean[] notificationListeners;
/*      */   private final Map<NotificationListenerBean, ObjectName[]> registeredNotificationListeners;
/*      */   private MBeanInfoAssembler assembler;
/*      */   private ObjectNamingStrategy namingStrategy;
/*      */   private ClassLoader beanClassLoader;
/*      */   private ListableBeanFactory beanFactory;
/*      */ 
/*      */   public MBeanExporter()
/*      */   {
/*  147 */     this.allowEagerInit = false;
/*      */ 
/*  150 */     this.ensureUniqueRuntimeObjectNames = true;
/*      */ 
/*  153 */     this.exposeManagedResourceClassLoader = true;
/*      */ 
/*  165 */     this.registeredNotificationListeners = new LinkedHashMap();
/*      */ 
/*  169 */     this.assembler = new SimpleReflectiveMBeanInfoAssembler();
/*      */ 
/*  172 */     this.namingStrategy = new KeyNamingStrategy();
/*      */ 
/*  175 */     this.beanClassLoader = ClassUtils.getDefaultClassLoader();
/*      */   }
/*      */ 
/*      */   public void setBeans(Map<String, Object> beans)
/*      */   {
/*  199 */     this.beans = beans;
/*      */   }
/*      */ 
/*      */   public void setAutodetect(boolean autodetect)
/*      */   {
/*  213 */     this.autodetectMode = Integer.valueOf(autodetect ? 3 : 0);
/*      */   }
/*      */ 
/*      */   public void setAutodetectMode(int autodetectMode)
/*      */   {
/*  227 */     if (!constants.getValues("AUTODETECT_").contains(Integer.valueOf(autodetectMode))) {
/*  228 */       throw new IllegalArgumentException("Only values of autodetect constants allowed");
/*      */     }
/*  230 */     this.autodetectMode = Integer.valueOf(autodetectMode);
/*      */   }
/*      */ 
/*      */   public void setAutodetectModeName(String constantName)
/*      */   {
/*  244 */     if ((constantName == null) || (!constantName.startsWith("AUTODETECT_"))) {
/*  245 */       throw new IllegalArgumentException("Only autodetect constants allowed");
/*      */     }
/*  247 */     this.autodetectMode = ((Integer)constants.asNumber(constantName));
/*      */   }
/*      */ 
/*      */   public void setAllowEagerInit(boolean allowEagerInit)
/*      */   {
/*  258 */     this.allowEagerInit = allowEagerInit;
/*      */   }
/*      */ 
/*      */   public void setAssembler(MBeanInfoAssembler assembler)
/*      */   {
/*  273 */     this.assembler = assembler;
/*      */   }
/*      */ 
/*      */   public void setNamingStrategy(ObjectNamingStrategy namingStrategy)
/*      */   {
/*  283 */     this.namingStrategy = namingStrategy;
/*      */   }
/*      */ 
/*      */   public void setListeners(MBeanExporterListener[] listeners)
/*      */   {
/*  292 */     this.listeners = listeners;
/*      */   }
/*      */ 
/*      */   public void setExcludedBeans(String[] excludedBeans)
/*      */   {
/*  299 */     this.excludedBeans = (excludedBeans != null ? new HashSet(Arrays.asList(excludedBeans)) : null);
/*      */   }
/*      */ 
/*      */   public void setEnsureUniqueRuntimeObjectNames(boolean ensureUniqueRuntimeObjectNames)
/*      */   {
/*  312 */     this.ensureUniqueRuntimeObjectNames = ensureUniqueRuntimeObjectNames;
/*      */   }
/*      */ 
/*      */   public void setExposeManagedResourceClassLoader(boolean exposeManagedResourceClassLoader)
/*      */   {
/*  324 */     this.exposeManagedResourceClassLoader = exposeManagedResourceClassLoader;
/*      */   }
/*      */ 
/*      */   public void setNotificationListeners(NotificationListenerBean[] notificationListeners)
/*      */   {
/*  336 */     this.notificationListeners = notificationListeners;
/*      */   }
/*      */ 
/*      */   public void setNotificationListenerMappings(Map<?, ? extends NotificationListener> listeners)
/*      */   {
/*  354 */     Assert.notNull(listeners, "'listeners' must not be null");
/*  355 */     List notificationListeners = new ArrayList(listeners.size());
/*      */ 
/*  358 */     for (Map.Entry entry : listeners.entrySet())
/*      */     {
/*  360 */       NotificationListenerBean bean = new NotificationListenerBean((NotificationListener)entry.getValue());
/*      */ 
/*  362 */       Object key = entry.getKey();
/*  363 */       if ((key != null) && (!"*".equals(key)))
/*      */       {
/*  365 */         bean.setMappedObjectName(entry.getKey());
/*      */       }
/*  367 */       notificationListeners.add(bean);
/*      */     }
/*      */ 
/*  370 */     this.notificationListeners = ((NotificationListenerBean[])notificationListeners.toArray(new NotificationListenerBean[notificationListeners.size()]));
/*      */   }
/*      */ 
/*      */   public void setBeanClassLoader(ClassLoader classLoader)
/*      */   {
/*  375 */     this.beanClassLoader = classLoader;
/*      */   }
/*      */ 
/*      */   public void setBeanFactory(BeanFactory beanFactory)
/*      */   {
/*  387 */     if ((beanFactory instanceof ListableBeanFactory)) {
/*  388 */       this.beanFactory = ((ListableBeanFactory)beanFactory);
/*      */     }
/*      */     else
/*  391 */       this.logger.info("MBeanExporter not running in a ListableBeanFactory: autodetection of MBeans not available.");
/*      */   }
/*      */ 
/*      */   public void afterPropertiesSet()
/*      */   {
/*  408 */     if (this.server == null)
/*  409 */       this.server = JmxUtils.locateMBeanServer();
/*      */     try
/*      */     {
/*  412 */       this.logger.info("Registering beans for JMX exposure on startup");
/*  413 */       registerBeans();
/*  414 */       registerNotificationListeners();
/*      */     }
/*      */     catch (RuntimeException ex)
/*      */     {
/*  418 */       unregisterNotificationListeners();
/*  419 */       unregisterBeans();
/*  420 */       throw ex;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void destroy()
/*      */   {
/*  429 */     this.logger.info("Unregistering JMX-exposed beans on shutdown");
/*  430 */     unregisterNotificationListeners();
/*  431 */     unregisterBeans();
/*      */   }
/*      */ 
/*      */   public ObjectName registerManagedResource(Object managedResource)
/*      */     throws MBeanExportException
/*      */   {
/*  440 */     Assert.notNull(managedResource, "Managed resource must not be null");
/*      */     ObjectName objectName;
/*      */     try
/*      */     {
/*  443 */       objectName = getObjectName(managedResource, null);
/*  444 */       if (this.ensureUniqueRuntimeObjectNames)
/*  445 */         objectName = JmxUtils.appendIdentityToObjectName(objectName, managedResource);
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  449 */       throw new MBeanExportException("Unable to generate ObjectName for MBean [" + managedResource + "]", ex);
/*      */     }
/*  451 */     registerManagedResource(managedResource, objectName);
/*  452 */     return objectName;
/*      */   }
/*      */ 
/*      */   public void registerManagedResource(Object managedResource, ObjectName objectName) throws MBeanExportException {
/*  456 */     Assert.notNull(managedResource, "Managed resource must not be null");
/*  457 */     Assert.notNull(objectName, "ObjectName must not be null");
/*      */     try {
/*  459 */       if (isMBean(managedResource.getClass())) {
/*  460 */         doRegister(managedResource, objectName);
/*      */       }
/*      */       else {
/*  463 */         ModelMBean mbean = createAndConfigureMBean(managedResource, managedResource.getClass().getName());
/*  464 */         doRegister(mbean, objectName);
/*  465 */         injectNotificationPublisherIfNecessary(managedResource, mbean, objectName);
/*      */       }
/*      */     }
/*      */     catch (JMException ex) {
/*  469 */       throw new UnableToRegisterMBeanException("Unable to register MBean [" + managedResource + "] with object name [" + objectName + "]", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void unregisterManagedResource(ObjectName objectName)
/*      */   {
/*  475 */     Assert.notNull(objectName, "ObjectName must not be null");
/*  476 */     doUnregister(objectName);
/*      */   }
/*      */ 
/*      */   protected void registerBeans()
/*      */   {
/*  499 */     if (this.beans == null) {
/*  500 */       this.beans = new HashMap();
/*      */ 
/*  502 */       if (this.autodetectMode == null) {
/*  503 */         this.autodetectMode = Integer.valueOf(3);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  508 */     int mode = this.autodetectMode != null ? this.autodetectMode.intValue() : 0;
/*  509 */     if (mode != 0) {
/*  510 */       if (this.beanFactory == null) {
/*  511 */         throw new MBeanExportException("Cannot autodetect MBeans if not running in a BeanFactory");
/*      */       }
/*  513 */       if ((mode == 1) || (mode == 3))
/*      */       {
/*  515 */         this.logger.debug("Autodetecting user-defined JMX MBeans");
/*  516 */         autodetectMBeans();
/*      */       }
/*      */ 
/*  519 */       if (((mode == 2) || (mode == 3)) && ((this.assembler instanceof AutodetectCapableMBeanInfoAssembler)))
/*      */       {
/*  521 */         autodetectBeans((AutodetectCapableMBeanInfoAssembler)this.assembler);
/*      */       }
/*      */     }
/*      */ 
/*  525 */     if (!this.beans.isEmpty())
/*  526 */       for (Map.Entry entry : this.beans.entrySet())
/*  527 */         registerBeanNameOrInstance(entry.getValue(), (String)entry.getKey());
/*      */   }
/*      */ 
/*      */   protected boolean isBeanDefinitionLazyInit(ListableBeanFactory beanFactory, String beanName)
/*      */   {
/*  540 */     return ((beanFactory instanceof ConfigurableListableBeanFactory)) && (beanFactory.containsBeanDefinition(beanName)) && (((ConfigurableListableBeanFactory)beanFactory).getBeanDefinition(beanName).isLazyInit());
/*      */   }
/*      */ 
/*      */   protected ObjectName registerBeanNameOrInstance(Object mapValue, String beanKey)
/*      */     throws MBeanExportException
/*      */   {
/*      */     try
/*      */     {
/*  566 */       if ((mapValue instanceof String))
/*      */       {
/*  568 */         if (this.beanFactory == null) {
/*  569 */           throw new MBeanExportException("Cannot resolve bean names if not running in a BeanFactory");
/*      */         }
/*  571 */         String beanName = (String)mapValue;
/*  572 */         if (isBeanDefinitionLazyInit(this.beanFactory, beanName)) {
/*  573 */           ObjectName objectName = registerLazyInit(beanName, beanKey);
/*  574 */           replaceNotificationListenerBeanNameKeysIfNecessary(beanName, objectName);
/*  575 */           return objectName;
/*      */         }
/*      */ 
/*  578 */         Object bean = this.beanFactory.getBean(beanName);
/*  579 */         ObjectName objectName = registerBeanInstance(bean, beanKey);
/*  580 */         replaceNotificationListenerBeanNameKeysIfNecessary(beanName, objectName);
/*  581 */         return objectName;
/*      */       }
/*      */ 
/*  586 */       if (this.beanFactory != null) {
/*  587 */         Map beansOfSameType = this.beanFactory.getBeansOfType(mapValue.getClass(), false, this.allowEagerInit);
/*      */ 
/*  589 */         for (Map.Entry entry : beansOfSameType.entrySet()) {
/*  590 */           if (entry.getValue() == mapValue) {
/*  591 */             String beanName = (String)entry.getKey();
/*  592 */             ObjectName objectName = registerBeanInstance(mapValue, beanKey);
/*  593 */             replaceNotificationListenerBeanNameKeysIfNecessary(beanName, objectName);
/*  594 */             return objectName;
/*      */           }
/*      */         }
/*      */       }
/*  598 */       return registerBeanInstance(mapValue, beanKey);
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  602 */       throw new UnableToRegisterMBeanException("Unable to register MBean [" + mapValue + "] with key '" + beanKey + "'", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void replaceNotificationListenerBeanNameKeysIfNecessary(String beanName, ObjectName objectName)
/*      */   {
/*  615 */     if (this.notificationListeners != null)
/*  616 */       for (NotificationListenerBean notificationListener : this.notificationListeners)
/*  617 */         notificationListener.replaceObjectName(beanName, objectName);
/*      */   }
/*      */ 
/*      */   private ObjectName registerBeanInstance(Object bean, String beanKey)
/*      */     throws JMException
/*      */   {
/*  631 */     ObjectName objectName = getObjectName(bean, beanKey);
/*  632 */     Object mbeanToExpose = null;
/*  633 */     if (isMBean(bean.getClass())) {
/*  634 */       mbeanToExpose = bean;
/*      */     }
/*      */     else {
/*  637 */       DynamicMBean adaptedBean = adaptMBeanIfPossible(bean);
/*  638 */       if (adaptedBean != null) {
/*  639 */         mbeanToExpose = adaptedBean;
/*      */       }
/*      */     }
/*  642 */     if (mbeanToExpose != null) {
/*  643 */       if (this.logger.isInfoEnabled()) {
/*  644 */         this.logger.info("Located MBean '" + beanKey + "': registering with JMX server as MBean [" + objectName + "]");
/*      */       }
/*      */ 
/*  647 */       doRegister(mbeanToExpose, objectName);
/*      */     }
/*      */     else {
/*  650 */       if (this.logger.isInfoEnabled()) {
/*  651 */         this.logger.info("Located managed bean '" + beanKey + "': registering with JMX server as MBean [" + objectName + "]");
/*      */       }
/*      */ 
/*  654 */       ModelMBean mbean = createAndConfigureMBean(bean, beanKey);
/*  655 */       doRegister(mbean, objectName);
/*  656 */       injectNotificationPublisherIfNecessary(bean, mbean, objectName);
/*      */     }
/*  658 */     return objectName;
/*      */   }
/*      */ 
/*      */   private ObjectName registerLazyInit(String beanName, String beanKey)
/*      */     throws JMException
/*      */   {
/*  670 */     ProxyFactory proxyFactory = new ProxyFactory();
/*  671 */     proxyFactory.setProxyTargetClass(true);
/*  672 */     proxyFactory.setFrozen(true);
/*      */ 
/*  674 */     if (isMBean(this.beanFactory.getType(beanName)))
/*      */     {
/*  676 */       LazyInitTargetSource targetSource = new LazyInitTargetSource();
/*  677 */       targetSource.setTargetBeanName(beanName);
/*  678 */       targetSource.setBeanFactory(this.beanFactory);
/*  679 */       proxyFactory.setTargetSource(targetSource);
/*      */ 
/*  681 */       Object proxy = proxyFactory.getProxy(this.beanClassLoader);
/*  682 */       ObjectName objectName = getObjectName(proxy, beanKey);
/*  683 */       if (this.logger.isDebugEnabled()) {
/*  684 */         this.logger.debug("Located MBean '" + beanKey + "': registering with JMX server as lazy-init MBean [" + objectName + "]");
/*      */       }
/*      */ 
/*  687 */       doRegister(proxy, objectName);
/*  688 */       return objectName;
/*      */     }
/*      */ 
/*  693 */     NotificationPublisherAwareLazyTargetSource targetSource = new NotificationPublisherAwareLazyTargetSource(null);
/*  694 */     targetSource.setTargetBeanName(beanName);
/*  695 */     targetSource.setBeanFactory(this.beanFactory);
/*  696 */     proxyFactory.setTargetSource(targetSource);
/*      */ 
/*  698 */     Object proxy = proxyFactory.getProxy(this.beanClassLoader);
/*  699 */     ObjectName objectName = getObjectName(proxy, beanKey);
/*  700 */     if (this.logger.isDebugEnabled()) {
/*  701 */       this.logger.debug("Located simple bean '" + beanKey + "': registering with JMX server as lazy-init MBean [" + objectName + "]");
/*      */     }
/*      */ 
/*  704 */     ModelMBean mbean = createAndConfigureMBean(proxy, beanKey);
/*  705 */     targetSource.setModelMBean(mbean);
/*  706 */     targetSource.setObjectName(objectName);
/*  707 */     doRegister(mbean, objectName);
/*  708 */     return objectName;
/*      */   }
/*      */ 
/*      */   protected ObjectName getObjectName(Object bean, String beanKey)
/*      */     throws MalformedObjectNameException
/*      */   {
/*  724 */     if ((bean instanceof SelfNaming)) {
/*  725 */       return ((SelfNaming)bean).getObjectName();
/*      */     }
/*      */ 
/*  728 */     return this.namingStrategy.getObjectName(bean, beanKey);
/*      */   }
/*      */ 
/*      */   protected boolean isMBean(Class beanClass)
/*      */   {
/*  743 */     return JmxUtils.isMBean(beanClass);
/*      */   }
/*      */ 
/*      */   protected DynamicMBean adaptMBeanIfPossible(Object bean)
/*      */     throws JMException
/*      */   {
/*  756 */     Class targetClass = AopUtils.getTargetClass(bean);
/*  757 */     if (targetClass != bean.getClass()) {
/*  758 */       Class ifc = JmxUtils.getMXBeanInterface(targetClass);
/*  759 */       if (ifc != null) {
/*  760 */         if (!ifc.isInstance(bean)) {
/*  761 */           throw new NotCompliantMBeanException("Managed bean [" + bean + "] has a target class with an MXBean interface but does not expose it in the proxy");
/*      */         }
/*      */ 
/*  764 */         return new StandardMBean(bean, ifc, true);
/*      */       }
/*      */ 
/*  767 */       ifc = JmxUtils.getMBeanInterface(targetClass);
/*  768 */       if (ifc != null) {
/*  769 */         if (!ifc.isInstance(bean)) {
/*  770 */           throw new NotCompliantMBeanException("Managed bean [" + bean + "] has a target class with an MBean interface but does not expose it in the proxy");
/*      */         }
/*      */ 
/*  773 */         return new StandardMBean(bean, ifc);
/*      */       }
/*      */     }
/*      */ 
/*  777 */     return null;
/*      */   }
/*      */ 
/*      */   protected ModelMBean createAndConfigureMBean(Object managedResource, String beanKey)
/*      */     throws MBeanExportException
/*      */   {
/*      */     try
/*      */     {
/*  791 */       ModelMBean mbean = createModelMBean();
/*  792 */       mbean.setModelMBeanInfo(getMBeanInfo(managedResource, beanKey));
/*  793 */       mbean.setManagedResource(managedResource, "ObjectReference");
/*  794 */       return mbean;
/*      */     }
/*      */     catch (Exception ex) {
/*  797 */       throw new MBeanExportException("Could not create ModelMBean for managed resource [" + managedResource + "] with key '" + beanKey + "'", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected ModelMBean createModelMBean()
/*      */     throws MBeanException
/*      */   {
/*  811 */     return this.exposeManagedResourceClassLoader ? new SpringModelMBean() : new RequiredModelMBean();
/*      */   }
/*      */ 
/*      */   private ModelMBeanInfo getMBeanInfo(Object managedBean, String beanKey)
/*      */     throws JMException
/*      */   {
/*  819 */     ModelMBeanInfo info = this.assembler.getMBeanInfo(managedBean, beanKey);
/*  820 */     if ((this.logger.isWarnEnabled()) && (ObjectUtils.isEmpty(info.getAttributes())) && (ObjectUtils.isEmpty(info.getOperations())))
/*      */     {
/*  822 */       this.logger.warn("Bean with key '" + beanKey + "' has been registered as an MBean but has no exposed attributes or operations");
/*      */     }
/*      */ 
/*  825 */     return info;
/*      */   }
/*      */ 
/*      */   private void autodetectBeans(final AutodetectCapableMBeanInfoAssembler assembler)
/*      */   {
/*  842 */     autodetect(new AutodetectCallback() {
/*      */       public boolean include(Class beanClass, String beanName) {
/*  844 */         return assembler.includeBean(beanClass, beanName);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private void autodetectMBeans()
/*      */   {
/*  854 */     autodetect(new AutodetectCallback() {
/*      */       public boolean include(Class beanClass, String beanName) {
/*  856 */         return MBeanExporter.this.isMBean(beanClass);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private void autodetect(AutodetectCallback callback)
/*      */   {
/*  869 */     Set beanNames = new LinkedHashSet(this.beanFactory.getBeanDefinitionCount());
/*  870 */     beanNames.addAll(Arrays.asList(this.beanFactory.getBeanDefinitionNames()));
/*  871 */     if ((this.beanFactory instanceof ConfigurableBeanFactory)) {
/*  872 */       beanNames.addAll(Arrays.asList(((ConfigurableBeanFactory)this.beanFactory).getSingletonNames()));
/*      */     }
/*  874 */     for (String beanName : beanNames)
/*  875 */       if ((!isExcluded(beanName)) && (!isBeanDefinitionAbstract(this.beanFactory, beanName)))
/*      */         try {
/*  877 */           Class beanClass = this.beanFactory.getType(beanName);
/*  878 */           if ((beanClass != null) && (callback.include(beanClass, beanName))) {
/*  879 */             boolean lazyInit = isBeanDefinitionLazyInit(this.beanFactory, beanName);
/*  880 */             Object beanInstance = !lazyInit ? this.beanFactory.getBean(beanName) : null;
/*  881 */             if ((!this.beans.containsValue(beanName)) && ((beanInstance == null) || (!CollectionUtils.containsInstance(this.beans.values(), beanInstance))))
/*      */             {
/*  884 */               this.beans.put(beanName, beanInstance != null ? beanInstance : beanName);
/*  885 */               if (this.logger.isInfoEnabled()) {
/*  886 */                 this.logger.info("Bean with name '" + beanName + "' has been autodetected for JMX exposure");
/*      */               }
/*      */ 
/*      */             }
/*  890 */             else if (this.logger.isDebugEnabled()) {
/*  891 */               this.logger.debug("Bean with name '" + beanName + "' is already registered for JMX exposure");
/*      */             }
/*      */           }
/*      */         }
/*      */         catch (CannotLoadBeanClassException ex)
/*      */         {
/*  897 */           if (this.allowEagerInit)
/*  898 */             throw ex;
/*      */         }
/*      */   }
/*      */ 
/*      */   private boolean isExcluded(String beanName)
/*      */   {
/*  910 */     return (this.excludedBeans != null) && ((this.excludedBeans.contains(beanName)) || ((beanName.startsWith("&")) && (this.excludedBeans.contains(beanName.substring("&".length())))));
/*      */   }
/*      */ 
/*      */   private boolean isBeanDefinitionAbstract(ListableBeanFactory beanFactory, String beanName)
/*      */   {
/*  920 */     return ((beanFactory instanceof ConfigurableListableBeanFactory)) && (beanFactory.containsBeanDefinition(beanName)) && (((ConfigurableListableBeanFactory)beanFactory).getBeanDefinition(beanName).isAbstract());
/*      */   }
/*      */ 
/*      */   private void injectNotificationPublisherIfNecessary(Object managedResource, ModelMBean modelMBean, ObjectName objectName)
/*      */   {
/*  936 */     if ((managedResource instanceof NotificationPublisherAware))
/*  937 */       ((NotificationPublisherAware)managedResource).setNotificationPublisher(new ModelMBeanNotificationPublisher(modelMBean, objectName, managedResource));
/*      */   }
/*      */ 
/*      */   private void registerNotificationListeners()
/*      */     throws MBeanExportException
/*      */   {
/*  947 */     if (this.notificationListeners != null)
/*  948 */       for (NotificationListenerBean bean : this.notificationListeners)
/*      */         try {
/*  950 */           ObjectName[] mappedObjectNames = bean.getResolvedObjectNames();
/*  951 */           if (mappedObjectNames == null)
/*      */           {
/*  953 */             mappedObjectNames = getRegisteredObjectNames();
/*      */           }
/*  955 */           if (this.registeredNotificationListeners.put(bean, mappedObjectNames) == null) {
/*  956 */             for (ObjectName mappedObjectName : mappedObjectNames) {
/*  957 */               this.server.addNotificationListener(mappedObjectName, bean.getNotificationListener(), bean.getNotificationFilter(), bean.getHandback());
/*      */             }
/*      */           }
/*      */         }
/*      */         catch (Exception ex)
/*      */         {
/*  963 */           throw new MBeanExportException("Unable to register NotificationListener", ex);
/*      */         }
/*      */   }
/*      */ 
/*      */   private void unregisterNotificationListeners()
/*      */   {
/*  974 */     for (Map.Entry entry : this.registeredNotificationListeners.entrySet()) {
/*  975 */       NotificationListenerBean bean = (NotificationListenerBean)entry.getKey();
/*  976 */       ObjectName[] mappedObjectNames = (ObjectName[])entry.getValue();
/*  977 */       for (ObjectName mappedObjectName : mappedObjectNames) {
/*      */         try {
/*  979 */           this.server.removeNotificationListener(mappedObjectName, bean.getNotificationListener(), bean.getNotificationFilter(), bean.getHandback());
/*      */         }
/*      */         catch (Exception ex)
/*      */         {
/*  983 */           if (this.logger.isDebugEnabled()) {
/*  984 */             this.logger.debug("Unable to unregister NotificationListener", ex);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  989 */     this.registeredNotificationListeners.clear();
/*      */   }
/*      */ 
/*      */   protected void onRegister(ObjectName objectName)
/*      */   {
/* 1004 */     notifyListenersOfRegistration(objectName);
/*      */   }
/*      */ 
/*      */   protected void onUnregister(ObjectName objectName)
/*      */   {
/* 1019 */     notifyListenersOfUnregistration(objectName);
/*      */   }
/*      */ 
/*      */   private void notifyListenersOfRegistration(ObjectName objectName)
/*      */   {
/* 1028 */     if (this.listeners != null)
/* 1029 */       for (MBeanExporterListener listener : this.listeners)
/* 1030 */         listener.mbeanRegistered(objectName);
/*      */   }
/*      */ 
/*      */   private void notifyListenersOfUnregistration(ObjectName objectName)
/*      */   {
/* 1040 */     if (this.listeners != null)
/* 1041 */       for (MBeanExporterListener listener : this.listeners)
/* 1042 */         listener.mbeanUnregistered(objectName);
/*      */   }
/*      */ 
/*      */   private class NotificationPublisherAwareLazyTargetSource extends LazyInitTargetSource
/*      */   {
/*      */     private ModelMBean modelMBean;
/*      */     private ObjectName objectName;
/*      */ 
/*      */     private NotificationPublisherAwareLazyTargetSource()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void setModelMBean(ModelMBean modelMBean)
/*      */     {
/* 1080 */       this.modelMBean = modelMBean;
/*      */     }
/*      */ 
/*      */     public void setObjectName(ObjectName objectName) {
/* 1084 */       this.objectName = objectName;
/*      */     }
/*      */ 
/*      */     protected void postProcessTargetObject(Object targetObject)
/*      */     {
/* 1089 */       MBeanExporter.this.injectNotificationPublisherIfNecessary(targetObject, this.modelMBean, this.objectName);
/*      */     }
/*      */   }
/*      */ 
/*      */   private static abstract interface AutodetectCallback
/*      */   {
/*      */     public abstract boolean include(Class paramClass, String paramString);
/*      */   }
/*      */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.MBeanExporter
 * JD-Core Version:    0.6.1
 */