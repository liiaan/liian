package org.springframework.jmx.export.naming;

import javax.management.MalformedObjectNameException;
import javax.management.ObjectName;

public abstract interface ObjectNamingStrategy
{
  public abstract ObjectName getObjectName(Object paramObject, String paramString)
    throws MalformedObjectNameException;
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.naming.ObjectNamingStrategy
 * JD-Core Version:    0.6.1
 */