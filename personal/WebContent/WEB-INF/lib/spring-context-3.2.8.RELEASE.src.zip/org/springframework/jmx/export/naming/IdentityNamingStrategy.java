/*    */ package org.springframework.jmx.export.naming;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ import javax.management.MalformedObjectNameException;
/*    */ import javax.management.ObjectName;
/*    */ import org.springframework.jmx.support.ObjectNameManager;
/*    */ import org.springframework.util.ClassUtils;
/*    */ import org.springframework.util.ObjectUtils;
/*    */ 
/*    */ public class IdentityNamingStrategy
/*    */   implements ObjectNamingStrategy
/*    */ {
/*    */   public static final String TYPE_KEY = "type";
/*    */   public static final String HASH_CODE_KEY = "hashCode";
/*    */ 
/*    */   public ObjectName getObjectName(Object managedBean, String beanKey)
/*    */     throws MalformedObjectNameException
/*    */   {
/* 51 */     String domain = ClassUtils.getPackageName(managedBean.getClass());
/* 52 */     Hashtable keys = new Hashtable();
/* 53 */     keys.put("type", ClassUtils.getShortName(managedBean.getClass()));
/* 54 */     keys.put("hashCode", ObjectUtils.getIdentityHexString(managedBean));
/* 55 */     return ObjectNameManager.getInstance(domain, keys);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.naming.IdentityNamingStrategy
 * JD-Core Version:    0.6.1
 */