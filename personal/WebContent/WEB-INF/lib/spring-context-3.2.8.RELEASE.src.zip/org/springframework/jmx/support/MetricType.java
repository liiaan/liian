/*    */ package org.springframework.jmx.support;
/*    */ 
/*    */ public enum MetricType
/*    */ {
/* 29 */   GAUGE, 
/*    */ 
/* 34 */   COUNTER;
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.support.MetricType
 * JD-Core Version:    0.6.1
 */