/*    */ package org.springframework.jmx.access;
/*    */ 
/*    */ import org.springframework.jmx.JmxException;
/*    */ 
/*    */ public class MBeanConnectFailureException extends JmxException
/*    */ {
/*    */   public MBeanConnectFailureException(String msg, Throwable cause)
/*    */   {
/* 39 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.access.MBeanConnectFailureException
 * JD-Core Version:    0.6.1
 */