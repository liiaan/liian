/*    */ package org.springframework.jmx.export.assembler;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ public class SimpleReflectiveMBeanInfoAssembler extends AbstractConfigurableMBeanInfoAssembler
/*    */ {
/*    */   protected boolean includeReadAttribute(Method method, String beanKey)
/*    */   {
/* 37 */     return true;
/*    */   }
/*    */ 
/*    */   protected boolean includeWriteAttribute(Method method, String beanKey)
/*    */   {
/* 45 */     return true;
/*    */   }
/*    */ 
/*    */   protected boolean includeOperation(Method method, String beanKey)
/*    */   {
/* 53 */     return true;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.assembler.SimpleReflectiveMBeanInfoAssembler
 * JD-Core Version:    0.6.1
 */