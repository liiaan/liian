/*    */ package org.springframework.jmx;
/*    */ 
/*    */ public class MBeanServerNotFoundException extends JmxException
/*    */ {
/*    */   public MBeanServerNotFoundException(String msg)
/*    */   {
/* 37 */     super(msg);
/*    */   }
/*    */ 
/*    */   public MBeanServerNotFoundException(String msg, Throwable cause)
/*    */   {
/* 47 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.MBeanServerNotFoundException
 * JD-Core Version:    0.6.1
 */