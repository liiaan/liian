/*    */ package org.springframework.jmx.export.metadata;
/*    */ 
/*    */ import org.springframework.jmx.JmxException;
/*    */ 
/*    */ public class InvalidMetadataException extends JmxException
/*    */ {
/*    */   public InvalidMetadataException(String msg)
/*    */   {
/* 39 */     super(msg);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.metadata.InvalidMetadataException
 * JD-Core Version:    0.6.1
 */