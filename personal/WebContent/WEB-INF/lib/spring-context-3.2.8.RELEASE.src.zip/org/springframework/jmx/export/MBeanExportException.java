/*    */ package org.springframework.jmx.export;
/*    */ 
/*    */ import org.springframework.jmx.JmxException;
/*    */ 
/*    */ public class MBeanExportException extends JmxException
/*    */ {
/*    */   public MBeanExportException(String msg)
/*    */   {
/* 37 */     super(msg);
/*    */   }
/*    */ 
/*    */   public MBeanExportException(String msg, Throwable cause)
/*    */   {
/* 47 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.MBeanExportException
 * JD-Core Version:    0.6.1
 */