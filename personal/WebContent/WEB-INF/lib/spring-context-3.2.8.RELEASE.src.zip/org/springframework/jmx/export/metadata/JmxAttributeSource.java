package org.springframework.jmx.export.metadata;

import java.lang.reflect.Method;

public abstract interface JmxAttributeSource
{
  public abstract ManagedResource getManagedResource(Class<?> paramClass)
    throws InvalidMetadataException;

  public abstract ManagedAttribute getManagedAttribute(Method paramMethod)
    throws InvalidMetadataException;

  public abstract ManagedMetric getManagedMetric(Method paramMethod)
    throws InvalidMetadataException;

  public abstract ManagedOperation getManagedOperation(Method paramMethod)
    throws InvalidMetadataException;

  public abstract ManagedOperationParameter[] getManagedOperationParameters(Method paramMethod)
    throws InvalidMetadataException;

  public abstract ManagedNotification[] getManagedNotifications(Class<?> paramClass)
    throws InvalidMetadataException;
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.metadata.JmxAttributeSource
 * JD-Core Version:    0.6.1
 */