/*     */ package org.springframework.jmx.access;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.Array;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.MalformedURLException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.management.Attribute;
/*     */ import javax.management.InstanceNotFoundException;
/*     */ import javax.management.IntrospectionException;
/*     */ import javax.management.JMException;
/*     */ import javax.management.JMX;
/*     */ import javax.management.MBeanAttributeInfo;
/*     */ import javax.management.MBeanException;
/*     */ import javax.management.MBeanInfo;
/*     */ import javax.management.MBeanOperationInfo;
/*     */ import javax.management.MBeanServerConnection;
/*     */ import javax.management.MBeanServerInvocationHandler;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import javax.management.OperationsException;
/*     */ import javax.management.ReflectionException;
/*     */ import javax.management.RuntimeErrorException;
/*     */ import javax.management.RuntimeMBeanException;
/*     */ import javax.management.RuntimeOperationsException;
/*     */ import javax.management.openmbean.CompositeData;
/*     */ import javax.management.openmbean.TabularData;
/*     */ import javax.management.remote.JMXServiceURL;
/*     */ import org.aopalliance.intercept.MethodInterceptor;
/*     */ import org.aopalliance.intercept.MethodInvocation;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.CollectionFactory;
/*     */ import org.springframework.core.GenericCollectionTypeResolver;
/*     */ import org.springframework.core.MethodParameter;
/*     */ import org.springframework.jmx.support.JmxUtils;
/*     */ import org.springframework.jmx.support.ObjectNameManager;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class MBeanClientInterceptor
/*     */   implements MethodInterceptor, BeanClassLoaderAware, InitializingBean, DisposableBean
/*     */ {
/*     */   protected final Log logger;
/*     */   private MBeanServerConnection server;
/*     */   private JMXServiceURL serviceUrl;
/*     */   private Map<String, ?> environment;
/*     */   private String agentId;
/*     */   private boolean connectOnStartup;
/*     */   private boolean refreshOnConnectFailure;
/*     */   private ObjectName objectName;
/*     */   private boolean useStrictCasing;
/*     */   private Class managementInterface;
/*     */   private ClassLoader beanClassLoader;
/*     */   private final ConnectorDelegate connector;
/*     */   private MBeanServerConnection serverToUse;
/*     */   private MBeanServerInvocationHandler invocationHandler;
/*     */   private Map<String, MBeanAttributeInfo> allowedAttributes;
/*     */   private Map<MethodCacheKey, MBeanOperationInfo> allowedOperations;
/*     */   private final Map<Method, String[]> signatureCache;
/*     */   private final Object preparationMonitor;
/*     */ 
/*     */   public MBeanClientInterceptor()
/*     */   {
/*  92 */     this.logger = LogFactory.getLog(getClass());
/*     */ 
/* 102 */     this.connectOnStartup = true;
/*     */ 
/* 104 */     this.refreshOnConnectFailure = false;
/*     */ 
/* 108 */     this.useStrictCasing = true;
/*     */ 
/* 112 */     this.beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */ 
/* 114 */     this.connector = new ConnectorDelegate();
/*     */ 
/* 124 */     this.signatureCache = new HashMap();
/*     */ 
/* 126 */     this.preparationMonitor = new Object();
/*     */   }
/*     */ 
/*     */   public void setServer(MBeanServerConnection server)
/*     */   {
/* 134 */     this.server = server;
/*     */   }
/*     */ 
/*     */   public void setServiceUrl(String url)
/*     */     throws MalformedURLException
/*     */   {
/* 141 */     this.serviceUrl = new JMXServiceURL(url);
/*     */   }
/*     */ 
/*     */   public void setEnvironment(Map<String, ?> environment)
/*     */   {
/* 149 */     this.environment = environment;
/*     */   }
/*     */ 
/*     */   public Map<String, ?> getEnvironment()
/*     */   {
/* 160 */     return this.environment;
/*     */   }
/*     */ 
/*     */   public void setAgentId(String agentId)
/*     */   {
/* 172 */     this.agentId = agentId;
/*     */   }
/*     */ 
/*     */   public void setConnectOnStartup(boolean connectOnStartup)
/*     */   {
/* 181 */     this.connectOnStartup = connectOnStartup;
/*     */   }
/*     */ 
/*     */   public void setRefreshOnConnectFailure(boolean refreshOnConnectFailure)
/*     */   {
/* 191 */     this.refreshOnConnectFailure = refreshOnConnectFailure;
/*     */   }
/*     */ 
/*     */   public void setObjectName(Object objectName)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 199 */     this.objectName = ObjectNameManager.getInstance(objectName);
/*     */   }
/*     */ 
/*     */   public void setUseStrictCasing(boolean useStrictCasing)
/*     */   {
/* 210 */     this.useStrictCasing = useStrictCasing;
/*     */   }
/*     */ 
/*     */   public void setManagementInterface(Class managementInterface)
/*     */   {
/* 219 */     this.managementInterface = managementInterface;
/*     */   }
/*     */ 
/*     */   protected final Class getManagementInterface()
/*     */   {
/* 227 */     return this.managementInterface;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader beanClassLoader) {
/* 231 */     this.beanClassLoader = beanClassLoader;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 240 */     if ((this.server != null) && (this.refreshOnConnectFailure)) {
/* 241 */       throw new IllegalArgumentException("'refreshOnConnectFailure' does not work when setting a 'server' reference. Prefer 'serviceUrl' etc instead.");
/*     */     }
/*     */ 
/* 244 */     if (this.connectOnStartup)
/* 245 */       prepare();
/*     */   }
/*     */ 
/*     */   public void prepare()
/*     */   {
/* 254 */     synchronized (this.preparationMonitor) {
/* 255 */       if (this.server != null) {
/* 256 */         this.serverToUse = this.server;
/*     */       }
/*     */       else {
/* 259 */         this.serverToUse = null;
/* 260 */         this.serverToUse = this.connector.connect(this.serviceUrl, this.environment, this.agentId);
/*     */       }
/* 262 */       this.invocationHandler = null;
/* 263 */       if (this.useStrictCasing)
/*     */       {
/* 266 */         if (JmxUtils.isMXBeanSupportAvailable()) {
/* 267 */           this.invocationHandler = new MBeanServerInvocationHandler(this.serverToUse, this.objectName, (this.managementInterface != null) && (JMX.isMXBeanInterface(this.managementInterface)));
/*     */         }
/*     */         else
/*     */         {
/* 272 */           this.invocationHandler = new MBeanServerInvocationHandler(this.serverToUse, this.objectName);
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 278 */         retrieveMBeanInfo();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void retrieveMBeanInfo()
/*     */     throws MBeanInfoRetrievalException
/*     */   {
/*     */     try
/*     */     {
/* 289 */       MBeanInfo info = this.serverToUse.getMBeanInfo(this.objectName);
/*     */ 
/* 291 */       MBeanAttributeInfo[] attributeInfo = info.getAttributes();
/* 292 */       this.allowedAttributes = new HashMap(attributeInfo.length);
/* 293 */       for (MBeanAttributeInfo infoEle : attributeInfo) {
/* 294 */         this.allowedAttributes.put(infoEle.getName(), infoEle);
/*     */       }
/*     */ 
/* 297 */       MBeanOperationInfo[] operationInfo = info.getOperations();
/* 298 */       this.allowedOperations = new HashMap(operationInfo.length);
/* 299 */       for (MBeanOperationInfo infoEle : operationInfo) {
/* 300 */         Class[] paramTypes = JmxUtils.parameterInfoToTypes(infoEle.getSignature(), this.beanClassLoader);
/* 301 */         this.allowedOperations.put(new MethodCacheKey(infoEle.getName(), paramTypes), infoEle);
/*     */       }
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 305 */       throw new MBeanInfoRetrievalException("Unable to locate class specified in method signature", ex);
/*     */     }
/*     */     catch (IntrospectionException ex) {
/* 308 */       throw new MBeanInfoRetrievalException("Unable to obtain MBean info for bean [" + this.objectName + "]", ex);
/*     */     }
/*     */     catch (InstanceNotFoundException ex)
/*     */     {
/* 312 */       throw new MBeanInfoRetrievalException("Unable to obtain MBean info for bean [" + this.objectName + "]: it is likely that this bean was unregistered during the proxy creation process", ex);
/*     */     }
/*     */     catch (ReflectionException ex)
/*     */     {
/* 317 */       throw new MBeanInfoRetrievalException("Unable to read MBean info for bean [ " + this.objectName + "]", ex);
/*     */     }
/*     */     catch (IOException ex) {
/* 320 */       throw new MBeanInfoRetrievalException("An IOException occurred when communicating with the MBeanServer. It is likely that you are communicating with a remote MBeanServer. Check the inner exception for exact details.", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected boolean isPrepared()
/*     */   {
/* 331 */     synchronized (this.preparationMonitor) {
/* 332 */       return this.serverToUse != null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object invoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/* 347 */     synchronized (this.preparationMonitor) {
/* 348 */       if (!isPrepared())
/* 349 */         prepare();
/*     */     }
/*     */     try
/*     */     {
/* 353 */       return doInvoke(invocation);
/*     */     }
/*     */     catch (MBeanConnectFailureException ex) {
/* 356 */       return handleConnectFailure(invocation, ex);
/*     */     }
/*     */     catch (IOException ex) {
/* 359 */       return handleConnectFailure(invocation, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object handleConnectFailure(MethodInvocation invocation, Exception ex)
/*     */     throws Throwable
/*     */   {
/* 376 */     if (this.refreshOnConnectFailure) {
/* 377 */       String msg = "Could not connect to JMX server - retrying";
/* 378 */       if (this.logger.isDebugEnabled()) {
/* 379 */         this.logger.warn(msg, ex);
/*     */       }
/* 381 */       else if (this.logger.isWarnEnabled()) {
/* 382 */         this.logger.warn(msg);
/*     */       }
/* 384 */       prepare();
/* 385 */       return doInvoke(invocation);
/*     */     }
/*     */ 
/* 388 */     throw ex;
/*     */   }
/*     */ 
/*     */   protected Object doInvoke(MethodInvocation invocation)
/*     */     throws Throwable
/*     */   {
/* 401 */     Method method = invocation.getMethod();
/*     */     try {
/* 403 */       Object result = null;
/* 404 */       if (this.invocationHandler != null) {
/* 405 */         result = this.invocationHandler.invoke(invocation.getThis(), method, invocation.getArguments());
/*     */       }
/*     */       else {
/* 408 */         PropertyDescriptor pd = BeanUtils.findPropertyForMethod(method);
/* 409 */         if (pd != null) {
/* 410 */           result = invokeAttribute(pd, invocation);
/*     */         }
/*     */         else {
/* 413 */           result = invokeOperation(method, invocation.getArguments());
/*     */         }
/*     */       }
/* 416 */       return convertResultValueIfNecessary(result, new MethodParameter(method, -1));
/*     */     }
/*     */     catch (MBeanException ex) {
/* 419 */       throw ex.getTargetException();
/*     */     }
/*     */     catch (RuntimeMBeanException ex) {
/* 422 */       throw ex.getTargetException();
/*     */     }
/*     */     catch (RuntimeErrorException ex) {
/* 425 */       throw ex.getTargetError();
/*     */     }
/*     */     catch (RuntimeOperationsException ex)
/*     */     {
/* 429 */       RuntimeException rex = ex.getTargetException();
/* 430 */       if ((rex instanceof RuntimeMBeanException)) {
/* 431 */         throw ((RuntimeMBeanException)rex).getTargetException();
/*     */       }
/* 433 */       if ((rex instanceof RuntimeErrorException)) {
/* 434 */         throw ((RuntimeErrorException)rex).getTargetError();
/*     */       }
/*     */ 
/* 437 */       throw rex;
/*     */     }
/*     */     catch (OperationsException ex)
/*     */     {
/* 441 */       if (ReflectionUtils.declaresException(method, ex.getClass())) {
/* 442 */         throw ex;
/*     */       }
/*     */ 
/* 445 */       throw new InvalidInvocationException(ex.getMessage());
/*     */     }
/*     */     catch (JMException ex)
/*     */     {
/* 449 */       if (ReflectionUtils.declaresException(method, ex.getClass())) {
/* 450 */         throw ex;
/*     */       }
/*     */ 
/* 453 */       throw new InvocationFailureException("JMX access failed", ex);
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 457 */       if (ReflectionUtils.declaresException(method, ex.getClass())) {
/* 458 */         throw ex;
/*     */       }
/*     */ 
/* 461 */       throw new MBeanConnectFailureException("I/O failure during JMX access", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Object invokeAttribute(PropertyDescriptor pd, MethodInvocation invocation)
/*     */     throws JMException, IOException
/*     */   {
/* 469 */     String attributeName = JmxUtils.getAttributeName(pd, this.useStrictCasing);
/* 470 */     MBeanAttributeInfo inf = (MBeanAttributeInfo)this.allowedAttributes.get(attributeName);
/*     */ 
/* 473 */     if (inf == null) {
/* 474 */       throw new InvalidInvocationException("Attribute '" + pd.getName() + "' is not exposed on the management interface");
/*     */     }
/*     */ 
/* 477 */     if (invocation.getMethod().equals(pd.getReadMethod())) {
/* 478 */       if (inf.isReadable()) {
/* 479 */         return this.serverToUse.getAttribute(this.objectName, attributeName);
/*     */       }
/*     */ 
/* 482 */       throw new InvalidInvocationException("Attribute '" + attributeName + "' is not readable");
/*     */     }
/*     */ 
/* 485 */     if (invocation.getMethod().equals(pd.getWriteMethod())) {
/* 486 */       if (inf.isWritable()) {
/* 487 */         this.serverToUse.setAttribute(this.objectName, new Attribute(attributeName, invocation.getArguments()[0]));
/* 488 */         return null;
/*     */       }
/*     */ 
/* 491 */       throw new InvalidInvocationException("Attribute '" + attributeName + "' is not writable");
/*     */     }
/*     */ 
/* 495 */     throw new IllegalStateException("Method [" + invocation.getMethod() + "] is neither a bean property getter nor a setter");
/*     */   }
/*     */ 
/*     */   private Object invokeOperation(Method method, Object[] args)
/*     */     throws JMException, IOException
/*     */   {
/* 508 */     MethodCacheKey key = new MethodCacheKey(method.getName(), method.getParameterTypes());
/* 509 */     MBeanOperationInfo info = (MBeanOperationInfo)this.allowedOperations.get(key);
/* 510 */     if (info == null) {
/* 511 */       throw new InvalidInvocationException("Operation '" + method.getName() + "' is not exposed on the management interface");
/*     */     }
/*     */ 
/* 514 */     String[] signature = null;
/* 515 */     synchronized (this.signatureCache) {
/* 516 */       signature = (String[])this.signatureCache.get(method);
/* 517 */       if (signature == null) {
/* 518 */         signature = JmxUtils.getMethodSignature(method);
/* 519 */         this.signatureCache.put(method, signature);
/*     */       }
/*     */     }
/* 522 */     return this.serverToUse.invoke(this.objectName, method.getName(), args, signature);
/*     */   }
/*     */ 
/*     */   protected Object convertResultValueIfNecessary(Object result, MethodParameter parameter)
/*     */   {
/* 534 */     Class targetClass = parameter.getParameterType();
/*     */     try {
/* 536 */       if (result == null) {
/* 537 */         return null;
/*     */       }
/* 539 */       if (ClassUtils.isAssignableValue(targetClass, result)) {
/* 540 */         return result;
/*     */       }
/* 542 */       if ((result instanceof CompositeData)) {
/* 543 */         Method fromMethod = targetClass.getMethod("from", new Class[] { CompositeData.class });
/* 544 */         return ReflectionUtils.invokeMethod(fromMethod, null, new Object[] { result });
/*     */       }
/* 546 */       if ((result instanceof CompositeData[])) {
/* 547 */         CompositeData[] array = (CompositeData[])result;
/* 548 */         if (targetClass.isArray()) {
/* 549 */           return convertDataArrayToTargetArray(array, targetClass);
/*     */         }
/* 551 */         if (Collection.class.isAssignableFrom(targetClass)) {
/* 552 */           Class elementType = GenericCollectionTypeResolver.getCollectionParameterType(parameter);
/* 553 */           if (elementType != null)
/* 554 */             return convertDataArrayToTargetCollection(array, targetClass, elementType);
/*     */         }
/*     */       }
/*     */       else {
/* 558 */         if ((result instanceof TabularData)) {
/* 559 */           Method fromMethod = targetClass.getMethod("from", new Class[] { TabularData.class });
/* 560 */           return ReflectionUtils.invokeMethod(fromMethod, null, new Object[] { result });
/*     */         }
/* 562 */         if ((result instanceof TabularData[])) {
/* 563 */           TabularData[] array = (TabularData[])result;
/* 564 */           if (targetClass.isArray()) {
/* 565 */             return convertDataArrayToTargetArray(array, targetClass);
/*     */           }
/* 567 */           if (Collection.class.isAssignableFrom(targetClass)) {
/* 568 */             Class elementType = GenericCollectionTypeResolver.getCollectionParameterType(parameter);
/* 569 */             if (elementType != null)
/* 570 */               return convertDataArrayToTargetCollection(array, targetClass, elementType);
/*     */           }
/*     */         }
/*     */       }
/* 574 */       throw new InvocationFailureException("Incompatible result value [" + result + "] for target type [" + targetClass.getName() + "]");
/*     */     }
/*     */     catch (NoSuchMethodException ex) {
/*     */     }
/* 578 */     throw new InvocationFailureException("Could not obtain 'from(CompositeData)' / 'from(TabularData)' method on target type [" + targetClass.getName() + "] for conversion of MXBean data structure [" + result + "]");
/*     */   }
/*     */ 
/*     */   private Object convertDataArrayToTargetArray(Object[] array, Class targetClass)
/*     */     throws NoSuchMethodException
/*     */   {
/* 585 */     Class targetType = targetClass.getComponentType();
/* 586 */     Method fromMethod = targetType.getMethod("from", new Class[] { array.getClass().getComponentType() });
/* 587 */     Object resultArray = Array.newInstance(targetType, array.length);
/* 588 */     for (int i = 0; i < array.length; i++) {
/* 589 */       Array.set(resultArray, i, ReflectionUtils.invokeMethod(fromMethod, null, new Object[] { array[i] }));
/*     */     }
/* 591 */     return resultArray;
/*     */   }
/*     */ 
/*     */   private Collection convertDataArrayToTargetCollection(Object[] array, Class collectionType, Class elementType)
/*     */     throws NoSuchMethodException
/*     */   {
/* 598 */     Method fromMethod = elementType.getMethod("from", new Class[] { array.getClass().getComponentType() });
/* 599 */     Collection resultColl = CollectionFactory.createCollection(collectionType, Array.getLength(array));
/* 600 */     for (int i = 0; i < array.length; i++) {
/* 601 */       resultColl.add(ReflectionUtils.invokeMethod(fromMethod, null, new Object[] { array[i] }));
/*     */     }
/* 603 */     return resultColl;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 608 */     this.connector.close();
/*     */   }
/*     */ 
/*     */   private static class MethodCacheKey
/*     */   {
/*     */     private final String name;
/*     */     private final Class[] parameterTypes;
/*     */ 
/*     */     public MethodCacheKey(String name, Class[] parameterTypes)
/*     */     {
/* 628 */       this.name = name;
/* 629 */       this.parameterTypes = (parameterTypes != null ? parameterTypes : new Class[0]);
/*     */     }
/*     */ 
/*     */     public boolean equals(Object other)
/*     */     {
/* 634 */       if (other == this) {
/* 635 */         return true;
/*     */       }
/* 637 */       MethodCacheKey otherKey = (MethodCacheKey)other;
/* 638 */       return (this.name.equals(otherKey.name)) && (Arrays.equals(this.parameterTypes, otherKey.parameterTypes));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 643 */       return this.name.hashCode();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.access.MBeanClientInterceptor
 * JD-Core Version:    0.6.1
 */