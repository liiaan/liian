/*    */ package org.springframework.jmx.export.notification;
/*    */ 
/*    */ import org.springframework.jmx.JmxException;
/*    */ 
/*    */ public class UnableToSendNotificationException extends JmxException
/*    */ {
/*    */   public UnableToSendNotificationException(String msg)
/*    */   {
/* 40 */     super(msg);
/*    */   }
/*    */ 
/*    */   public UnableToSendNotificationException(String msg, Throwable cause)
/*    */   {
/* 50 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.notification.UnableToSendNotificationException
 * JD-Core Version:    0.6.1
 */