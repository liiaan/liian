/*    */ package org.springframework.jmx.export;
/*    */ 
/*    */ import java.util.Set;
/*    */ import javax.management.NotificationListener;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.jmx.support.NotificationListenerHolder;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class NotificationListenerBean extends NotificationListenerHolder
/*    */   implements InitializingBean
/*    */ {
/*    */   public NotificationListenerBean()
/*    */   {
/*    */   }
/*    */ 
/*    */   public NotificationListenerBean(NotificationListener notificationListener)
/*    */   {
/* 59 */     Assert.notNull(notificationListener, "NotificationListener must not be null");
/* 60 */     setNotificationListener(notificationListener);
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 65 */     if (getNotificationListener() == null)
/* 66 */       throw new IllegalArgumentException("Property 'notificationListener' is required");
/*    */   }
/*    */ 
/*    */   void replaceObjectName(Object originalName, Object newName)
/*    */   {
/* 71 */     if ((this.mappedObjectNames != null) && (this.mappedObjectNames.contains(originalName))) {
/* 72 */       this.mappedObjectNames.remove(originalName);
/* 73 */       this.mappedObjectNames.add(newName);
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.export.NotificationListenerBean
 * JD-Core Version:    0.6.1
 */