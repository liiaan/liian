/*     */ package org.springframework.jmx.support;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.management.ManagementFactory;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Hashtable;
/*     */ import java.util.List;
/*     */ import javax.management.DynamicMBean;
/*     */ import javax.management.MBeanParameterInfo;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MBeanServerFactory;
/*     */ import javax.management.MXBean;
/*     */ import javax.management.MalformedObjectNameException;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.jmx.MBeanServerNotFoundException;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class JmxUtils
/*     */ {
/*     */   public static final String IDENTITY_OBJECT_NAME_KEY = "identity";
/*     */   private static final String MBEAN_SUFFIX = "MBean";
/*     */   private static final String MXBEAN_SUFFIX = "MXBean";
/*     */   private static final String MXBEAN_ANNOTATION_CLASS_NAME = "javax.management.MXBean";
/*  70 */   private static final boolean mxBeanAnnotationAvailable = ClassUtils.isPresent("javax.management.MXBean", JmxUtils.class.getClassLoader());
/*     */ 
/*  73 */   private static final Log logger = LogFactory.getLog(JmxUtils.class);
/*     */ 
/*     */   public static MBeanServer locateMBeanServer()
/*     */     throws MBeanServerNotFoundException
/*     */   {
/*  86 */     return locateMBeanServer(null);
/*     */   }
/*     */ 
/*     */   public static MBeanServer locateMBeanServer(String agentId)
/*     */     throws MBeanServerNotFoundException
/*     */   {
/* 102 */     MBeanServer server = null;
/*     */ 
/* 105 */     if (!"".equals(agentId)) {
/* 106 */       List servers = MBeanServerFactory.findMBeanServer(agentId);
/* 107 */       if ((servers != null) && (servers.size() > 0))
/*     */       {
/* 109 */         if ((servers.size() > 1) && (logger.isWarnEnabled())) {
/* 110 */           logger.warn("Found more than one MBeanServer instance" + (agentId != null ? " with agent id [" + agentId + "]" : "") + ". Returning first from list.");
/*     */         }
/*     */ 
/* 114 */         server = (MBeanServer)servers.get(0);
/*     */       }
/*     */     }
/*     */ 
/* 118 */     if ((server == null) && (!StringUtils.hasLength(agentId))) {
/*     */       try
/*     */       {
/* 121 */         server = ManagementFactory.getPlatformMBeanServer();
/*     */       }
/*     */       catch (SecurityException ex) {
/* 124 */         throw new MBeanServerNotFoundException("No specific MBeanServer found, and not allowed to obtain the Java platform MBeanServer", ex);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 129 */     if (server == null) {
/* 130 */       throw new MBeanServerNotFoundException("Unable to locate an MBeanServer instance" + (agentId != null ? " with agent id [" + agentId + "]" : ""));
/*     */     }
/*     */ 
/* 135 */     if (logger.isDebugEnabled()) {
/* 136 */       logger.debug("Found MBeanServer: " + server);
/*     */     }
/* 138 */     return server;
/*     */   }
/*     */ 
/*     */   public static Class[] parameterInfoToTypes(MBeanParameterInfo[] paramInfo)
/*     */     throws ClassNotFoundException
/*     */   {
/* 149 */     return parameterInfoToTypes(paramInfo, ClassUtils.getDefaultClassLoader());
/*     */   }
/*     */ 
/*     */   public static Class[] parameterInfoToTypes(MBeanParameterInfo[] paramInfo, ClassLoader classLoader)
/*     */     throws ClassNotFoundException
/*     */   {
/* 163 */     Class[] types = null;
/* 164 */     if ((paramInfo != null) && (paramInfo.length > 0)) {
/* 165 */       types = new Class[paramInfo.length];
/* 166 */       for (int x = 0; x < paramInfo.length; x++) {
/* 167 */         types[x] = ClassUtils.forName(paramInfo[x].getType(), classLoader);
/*     */       }
/*     */     }
/* 170 */     return types;
/*     */   }
/*     */ 
/*     */   public static String[] getMethodSignature(Method method)
/*     */   {
/* 181 */     Class[] types = method.getParameterTypes();
/* 182 */     String[] signature = new String[types.length];
/* 183 */     for (int x = 0; x < types.length; x++) {
/* 184 */       signature[x] = types[x].getName();
/*     */     }
/* 186 */     return signature;
/*     */   }
/*     */ 
/*     */   public static String getAttributeName(PropertyDescriptor property, boolean useStrictCasing)
/*     */   {
/* 200 */     if (useStrictCasing) {
/* 201 */       return StringUtils.capitalize(property.getName());
/*     */     }
/*     */ 
/* 204 */     return property.getName();
/*     */   }
/*     */ 
/*     */   public static ObjectName appendIdentityToObjectName(ObjectName objectName, Object managedResource)
/*     */     throws MalformedObjectNameException
/*     */   {
/* 225 */     Hashtable keyProperties = objectName.getKeyPropertyList();
/* 226 */     keyProperties.put("identity", ObjectUtils.getIdentityHexString(managedResource));
/* 227 */     return ObjectNameManager.getInstance(objectName.getDomain(), keyProperties);
/*     */   }
/*     */ 
/*     */   public static Class<?> getClassToExpose(Object managedBean)
/*     */   {
/* 241 */     return ClassUtils.getUserClass(managedBean);
/*     */   }
/*     */ 
/*     */   public static Class<?> getClassToExpose(Class<?> clazz)
/*     */   {
/* 255 */     return ClassUtils.getUserClass(clazz);
/*     */   }
/*     */ 
/*     */   public static boolean isMBean(Class<?> clazz)
/*     */   {
/* 268 */     return (clazz != null) && ((DynamicMBean.class.isAssignableFrom(clazz)) || (getMBeanInterface(clazz) != null) || (getMXBeanInterface(clazz) != null));
/*     */   }
/*     */ 
/*     */   public static Class<?> getMBeanInterface(Class<?> clazz)
/*     */   {
/* 281 */     if ((clazz == null) || (clazz.getSuperclass() == null)) {
/* 282 */       return null;
/*     */     }
/* 284 */     String mbeanInterfaceName = clazz.getName() + "MBean";
/* 285 */     Class[] implementedInterfaces = clazz.getInterfaces();
/* 286 */     for (Class iface : implementedInterfaces) {
/* 287 */       if (iface.getName().equals(mbeanInterfaceName)) {
/* 288 */         return iface;
/*     */       }
/*     */     }
/* 291 */     return getMBeanInterface(clazz.getSuperclass());
/*     */   }
/*     */ 
/*     */   public static Class<?> getMXBeanInterface(Class<?> clazz)
/*     */   {
/* 302 */     if ((clazz == null) || (clazz.getSuperclass() == null)) {
/* 303 */       return null;
/*     */     }
/* 305 */     Class[] implementedInterfaces = clazz.getInterfaces();
/* 306 */     for (Class iface : implementedInterfaces) {
/* 307 */       boolean isMxBean = iface.getName().endsWith("MXBean");
/* 308 */       if (mxBeanAnnotationAvailable) {
/* 309 */         Boolean checkResult = MXBeanChecker.evaluateMXBeanAnnotation(iface);
/* 310 */         if (checkResult != null) {
/* 311 */           isMxBean = checkResult.booleanValue();
/*     */         }
/*     */       }
/* 314 */       if (isMxBean) {
/* 315 */         return iface;
/*     */       }
/*     */     }
/* 318 */     return getMXBeanInterface(clazz.getSuperclass());
/*     */   }
/*     */ 
/*     */   public static boolean isMXBeanSupportAvailable()
/*     */   {
/* 327 */     return mxBeanAnnotationAvailable;
/*     */   }
/*     */ 
/*     */   private static class MXBeanChecker
/*     */   {
/*     */     public static Boolean evaluateMXBeanAnnotation(Class<?> iface)
/*     */     {
/* 337 */       MXBean mxBean = (MXBean)iface.getAnnotation(MXBean.class);
/* 338 */       return mxBean != null ? Boolean.valueOf(mxBean.value()) : null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.support.JmxUtils
 * JD-Core Version:    0.6.1
 */