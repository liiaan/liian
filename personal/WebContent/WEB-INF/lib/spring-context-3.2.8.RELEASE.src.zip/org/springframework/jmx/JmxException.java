/*    */ package org.springframework.jmx;
/*    */ 
/*    */ import org.springframework.core.NestedRuntimeException;
/*    */ 
/*    */ public class JmxException extends NestedRuntimeException
/*    */ {
/*    */   public JmxException(String msg)
/*    */   {
/* 36 */     super(msg);
/*    */   }
/*    */ 
/*    */   public JmxException(String msg, Throwable cause)
/*    */   {
/* 45 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jmx.JmxException
 * JD-Core Version:    0.6.1
 */