/*     */ package org.springframework.instrument.classloading;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class ResourceOverridingShadowingClassLoader extends ShadowingClassLoader
/*     */ {
/*  38 */   private static final Enumeration<URL> EMPTY_URL_ENUMERATION = new Enumeration() {
/*     */     public boolean hasMoreElements() {
/*  40 */       return false;
/*     */     }
/*     */     public URL nextElement() {
/*  43 */       throw new UnsupportedOperationException("Should not be called. I am empty.");
/*     */     }
/*  38 */   };
/*     */ 
/*  51 */   private Map<String, String> overrides = new HashMap();
/*     */ 
/*     */   public ResourceOverridingShadowingClassLoader(ClassLoader enclosingClassLoader)
/*     */   {
/*  60 */     super(enclosingClassLoader);
/*     */   }
/*     */ 
/*     */   public void override(String oldPath, String newPath)
/*     */   {
/*  71 */     this.overrides.put(oldPath, newPath);
/*     */   }
/*     */ 
/*     */   public void suppress(String oldPath)
/*     */   {
/*  80 */     this.overrides.put(oldPath, null);
/*     */   }
/*     */ 
/*     */   public void copyOverrides(ResourceOverridingShadowingClassLoader other)
/*     */   {
/*  88 */     Assert.notNull(other, "Other ClassLoader must not be null");
/*  89 */     this.overrides.putAll(other.overrides);
/*     */   }
/*     */ 
/*     */   public URL getResource(String requestedPath)
/*     */   {
/*  95 */     if (this.overrides.containsKey(requestedPath)) {
/*  96 */       String overriddenPath = (String)this.overrides.get(requestedPath);
/*  97 */       return overriddenPath != null ? super.getResource(overriddenPath) : null;
/*     */     }
/*     */ 
/* 100 */     return super.getResource(requestedPath);
/*     */   }
/*     */ 
/*     */   public InputStream getResourceAsStream(String requestedPath)
/*     */   {
/* 106 */     if (this.overrides.containsKey(requestedPath)) {
/* 107 */       String overriddenPath = (String)this.overrides.get(requestedPath);
/* 108 */       return overriddenPath != null ? super.getResourceAsStream(overriddenPath) : null;
/*     */     }
/*     */ 
/* 111 */     return super.getResourceAsStream(requestedPath);
/*     */   }
/*     */ 
/*     */   public Enumeration<URL> getResources(String requestedPath)
/*     */     throws IOException
/*     */   {
/* 117 */     if (this.overrides.containsKey(requestedPath)) {
/* 118 */       String overriddenLocation = (String)this.overrides.get(requestedPath);
/* 119 */       return overriddenLocation != null ? super.getResources(overriddenLocation) : EMPTY_URL_ENUMERATION;
/*     */     }
/*     */ 
/* 123 */     return super.getResources(requestedPath);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.ResourceOverridingShadowingClassLoader
 * JD-Core Version:    0.6.1
 */