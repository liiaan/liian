/*    */ package org.springframework.instrument.classloading.weblogic;
/*    */ 
/*    */ import java.lang.instrument.ClassFileTransformer;
/*    */ import org.springframework.instrument.classloading.LoadTimeWeaver;
/*    */ import org.springframework.util.Assert;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ public class WebLogicLoadTimeWeaver
/*    */   implements LoadTimeWeaver
/*    */ {
/*    */   private final WebLogicClassLoaderAdapter classLoader;
/*    */ 
/*    */   public WebLogicLoadTimeWeaver()
/*    */   {
/* 46 */     this(ClassUtils.getDefaultClassLoader());
/*    */   }
/*    */ 
/*    */   public WebLogicLoadTimeWeaver(ClassLoader classLoader)
/*    */   {
/* 56 */     Assert.notNull(classLoader, "ClassLoader must not be null");
/* 57 */     this.classLoader = new WebLogicClassLoaderAdapter(classLoader);
/*    */   }
/*    */ 
/*    */   public void addTransformer(ClassFileTransformer transformer)
/*    */   {
/* 62 */     this.classLoader.addTransformer(transformer);
/*    */   }
/*    */ 
/*    */   public ClassLoader getInstrumentableClassLoader() {
/* 66 */     return this.classLoader.getClassLoader();
/*    */   }
/*    */ 
/*    */   public ClassLoader getThrowawayClassLoader() {
/* 70 */     return this.classLoader.getThrowawayClassLoader();
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.weblogic.WebLogicLoadTimeWeaver
 * JD-Core Version:    0.6.1
 */