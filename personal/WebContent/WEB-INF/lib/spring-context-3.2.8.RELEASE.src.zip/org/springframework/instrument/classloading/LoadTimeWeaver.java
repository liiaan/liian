package org.springframework.instrument.classloading;

import java.lang.instrument.ClassFileTransformer;

public abstract interface LoadTimeWeaver
{
  public abstract void addTransformer(ClassFileTransformer paramClassFileTransformer);

  public abstract ClassLoader getInstrumentableClassLoader();

  public abstract ClassLoader getThrowawayClassLoader();
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.LoadTimeWeaver
 * JD-Core Version:    0.6.1
 */