/*     */ package org.springframework.instrument.classloading.weblogic;
/*     */ 
/*     */ import java.lang.instrument.ClassFileTransformer;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ class WebLogicClassLoaderAdapter
/*     */ {
/*     */   private static final String GENERIC_CLASS_LOADER_NAME = "weblogic.utils.classloaders.GenericClassLoader";
/*     */   private static final String CLASS_PRE_PROCESSOR_NAME = "weblogic.utils.classloaders.ClassPreProcessor";
/*     */   private final ClassLoader classLoader;
/*     */   private final Class wlPreProcessorClass;
/*     */   private final Method addPreProcessorMethod;
/*     */   private final Method getClassFinderMethod;
/*     */   private final Method getParentMethod;
/*     */   private final Constructor wlGenericClassLoaderConstructor;
/*     */ 
/*     */   public WebLogicClassLoaderAdapter(ClassLoader classLoader)
/*     */   {
/*  58 */     Class wlGenericClassLoaderClass = null;
/*     */     try {
/*  60 */       wlGenericClassLoaderClass = classLoader.loadClass("weblogic.utils.classloaders.GenericClassLoader");
/*  61 */       this.wlPreProcessorClass = classLoader.loadClass("weblogic.utils.classloaders.ClassPreProcessor");
/*  62 */       this.addPreProcessorMethod = classLoader.getClass().getMethod("addInstanceClassPreProcessor", new Class[] { this.wlPreProcessorClass });
/*     */ 
/*  64 */       this.getClassFinderMethod = classLoader.getClass().getMethod("getClassFinder", new Class[0]);
/*  65 */       this.getParentMethod = classLoader.getClass().getMethod("getParent", new Class[0]);
/*  66 */       this.wlGenericClassLoaderConstructor = wlGenericClassLoaderClass.getConstructor(new Class[] { this.getClassFinderMethod.getReturnType(), ClassLoader.class });
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*  70 */       throw new IllegalStateException("Could not initialize WebLogic LoadTimeWeaver because WebLogic 10 API classes are not available", ex);
/*     */     }
/*     */ 
/*  73 */     Assert.isInstanceOf(wlGenericClassLoaderClass, classLoader, "ClassLoader must be instance of [" + wlGenericClassLoaderClass.getName() + "]");
/*     */ 
/*  75 */     this.classLoader = classLoader;
/*     */   }
/*     */ 
/*     */   public void addTransformer(ClassFileTransformer transformer)
/*     */   {
/*  80 */     Assert.notNull(transformer, "ClassFileTransformer must not be null");
/*     */     try {
/*  82 */       InvocationHandler adapter = new WebLogicClassPreProcessorAdapter(transformer, this.classLoader);
/*  83 */       Object adapterInstance = Proxy.newProxyInstance(this.wlPreProcessorClass.getClassLoader(), new Class[] { this.wlPreProcessorClass }, adapter);
/*     */ 
/*  85 */       this.addPreProcessorMethod.invoke(this.classLoader, new Object[] { adapterInstance });
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/*  88 */       throw new IllegalStateException("WebLogic addInstanceClassPreProcessor method threw exception", ex.getCause());
/*     */     }
/*     */     catch (Exception ex) {
/*  91 */       throw new IllegalStateException("Could not invoke WebLogic addInstanceClassPreProcessor method", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ClassLoader getClassLoader() {
/*  96 */     return this.classLoader;
/*     */   }
/*     */ 
/*     */   public ClassLoader getThrowawayClassLoader() {
/*     */     try {
/* 101 */       Object classFinder = this.getClassFinderMethod.invoke(this.classLoader, new Object[0]);
/* 102 */       Object parent = this.getParentMethod.invoke(this.classLoader, new Object[0]);
/*     */ 
/* 104 */       return (ClassLoader)this.wlGenericClassLoaderConstructor.newInstance(new Object[] { classFinder, parent });
/*     */     }
/*     */     catch (InvocationTargetException ex) {
/* 107 */       throw new IllegalStateException("WebLogic GenericClassLoader constructor failed", ex.getCause());
/*     */     }
/*     */     catch (Exception ex) {
/* 110 */       throw new IllegalStateException("Could not construct WebLogic GenericClassLoader", ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.weblogic.WebLogicClassLoaderAdapter
 * JD-Core Version:    0.6.1
 */