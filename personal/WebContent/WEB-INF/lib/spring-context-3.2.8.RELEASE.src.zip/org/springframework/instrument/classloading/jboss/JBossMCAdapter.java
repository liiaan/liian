/*     */ package org.springframework.instrument.classloading.jboss;
/*     */ 
/*     */ import java.lang.instrument.ClassFileTransformer;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ class JBossMCAdapter
/*     */   implements JBossClassLoaderAdapter
/*     */ {
/*     */   private static final String TRANSLATOR_NAME = "org.jboss.util.loading.Translator";
/*     */   private static final String POLICY_NAME = "org.jboss.classloader.spi.base.BaseClassLoaderPolicy";
/*     */   private static final String DOMAIN_NAME = "org.jboss.classloader.spi.base.BaseClassLoaderDomain";
/*     */   private static final String DEDICATED_SYSTEM = "org.jboss.classloader.spi.ClassLoaderSystem";
/*     */   private static final String LOADER_NAME = "org.jboss.classloader.spi.base.BaseClassLoader";
/*     */   private static final String GET_POLICY = "getPolicy";
/*     */   private static final String GET_DOMAIN = "getClassLoaderDomain";
/*     */   private static final String GET_SYSTEM = "getClassLoaderSystem";
/*     */   private static final String ADD_TRANSLATOR_NAME = "addTranslator";
/*     */   private static final String SET_TRANSLATOR_NAME = "setTranslator";
/*     */   private final ClassLoader classLoader;
/*     */   private final Class<?> translatorClass;
/*     */   private final Method addTranslator;
/*     */   private final Object target;
/*     */ 
/*     */   JBossMCAdapter(ClassLoader classLoader)
/*     */   {
/*  56 */     Class clazzLoaderType = null;
/*     */     try
/*     */     {
/*  59 */       clazzLoaderType = classLoader.loadClass("org.jboss.classloader.spi.base.BaseClassLoader");
/*     */ 
/*  61 */       ClassLoader clazzLoader = null;
/*     */ 
/*  63 */       for (ClassLoader cl = classLoader; (cl != null) && (clazzLoader == null); cl = cl.getParent()) {
/*  64 */         if (clazzLoaderType.isInstance(cl)) {
/*  65 */           clazzLoader = cl;
/*     */         }
/*     */       }
/*     */ 
/*  69 */       if (clazzLoader == null) {
/*  70 */         throw new IllegalArgumentException(classLoader + " and its parents are not suitable ClassLoaders: " + "A [" + "org.jboss.classloader.spi.base.BaseClassLoader" + "] implementation is required.");
/*     */       }
/*     */ 
/*  74 */       this.classLoader = clazzLoader;
/*     */ 
/*  77 */       classLoader = clazzLoader.getClass().getClassLoader();
/*     */ 
/*  80 */       Method method = clazzLoaderType.getDeclaredMethod("getPolicy", new Class[0]);
/*  81 */       ReflectionUtils.makeAccessible(method);
/*  82 */       Object policy = method.invoke(this.classLoader, new Object[0]);
/*     */ 
/*  84 */       Object addTarget = null;
/*  85 */       Method addMethod = null;
/*     */ 
/*  89 */       this.translatorClass = classLoader.loadClass("org.jboss.util.loading.Translator");
/*  90 */       Class clazz = classLoader.loadClass("org.jboss.classloader.spi.base.BaseClassLoaderPolicy");
/*     */       try {
/*  92 */         addMethod = clazz.getDeclaredMethod("addTranslator", new Class[] { this.translatorClass });
/*  93 */         addTarget = policy;
/*     */       }
/*     */       catch (NoSuchMethodException ex)
/*     */       {
/*     */       }
/*  98 */       if (addMethod == null)
/*     */       {
/* 101 */         method = clazz.getDeclaredMethod("getClassLoaderDomain", new Class[0]);
/* 102 */         ReflectionUtils.makeAccessible(method);
/* 103 */         Object domain = method.invoke(policy, new Object[0]);
/*     */ 
/* 106 */         clazz = classLoader.loadClass("org.jboss.classloader.spi.base.BaseClassLoaderDomain");
/* 107 */         method = clazz.getDeclaredMethod("getClassLoaderSystem", new Class[0]);
/* 108 */         ReflectionUtils.makeAccessible(method);
/* 109 */         Object system = method.invoke(domain, new Object[0]);
/*     */ 
/* 112 */         clazz = classLoader.loadClass("org.jboss.classloader.spi.ClassLoaderSystem");
/* 113 */         Assert.isInstanceOf(clazz, system, "JBoss LoadTimeWeaver requires JBoss loader system of type " + clazz.getName() + " on JBoss 5.0.x");
/*     */ 
/* 117 */         addMethod = clazz.getDeclaredMethod("setTranslator", new Class[] { this.translatorClass });
/* 118 */         addTarget = system;
/*     */       }
/*     */ 
/* 121 */       this.addTranslator = addMethod;
/* 122 */       this.target = addTarget;
/*     */     }
/*     */     catch (Exception ex) {
/* 125 */       throw new IllegalStateException("Could not initialize JBoss LoadTimeWeaver because the JBoss 5 API classes are not available", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addTransformer(ClassFileTransformer transformer)
/*     */   {
/* 131 */     InvocationHandler adapter = new JBossMCTranslatorAdapter(transformer);
/* 132 */     Object adapterInstance = Proxy.newProxyInstance(this.translatorClass.getClassLoader(), new Class[] { this.translatorClass }, adapter);
/*     */     try
/*     */     {
/* 136 */       this.addTranslator.invoke(this.target, new Object[] { adapterInstance });
/*     */     } catch (Exception ex) {
/* 138 */       throw new IllegalStateException("Could not add transformer on JBoss 5/6 classloader " + this.classLoader, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public ClassLoader getInstrumentableClassLoader() {
/* 143 */     return this.classLoader;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.instrument.classloading.jboss.JBossMCAdapter
 * JD-Core Version:    0.6.1
 */