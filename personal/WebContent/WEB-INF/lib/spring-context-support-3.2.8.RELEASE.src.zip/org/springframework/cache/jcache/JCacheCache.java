/*     */ package org.springframework.cache.jcache;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import javax.cache.Status;
/*     */ import org.springframework.cache.Cache.ValueWrapper;
/*     */ import org.springframework.cache.support.SimpleValueWrapper;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class JCacheCache
/*     */   implements org.springframework.cache.Cache
/*     */ {
/*  36 */   private static final Object NULL_HOLDER = new NullHolder(null);
/*     */   private final javax.cache.Cache cache;
/*     */   private final boolean allowNullValues;
/*     */ 
/*     */   public JCacheCache(javax.cache.Cache<?, ?> jcache)
/*     */   {
/*  49 */     this(jcache, true);
/*     */   }
/*     */ 
/*     */   public JCacheCache(javax.cache.Cache<?, ?> jcache, boolean allowNullValues)
/*     */   {
/*  58 */     Assert.notNull(jcache, "Cache must not be null");
/*  59 */     Status status = jcache.getStatus();
/*  60 */     Assert.isTrue(Status.STARTED.equals(status), "A 'started' cache is required - current cache is " + status.toString());
/*     */ 
/*  62 */     this.cache = jcache;
/*  63 */     this.allowNullValues = allowNullValues;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  68 */     return this.cache.getName();
/*     */   }
/*     */ 
/*     */   public javax.cache.Cache<?, ?> getNativeCache() {
/*  72 */     return this.cache;
/*     */   }
/*     */ 
/*     */   public boolean isAllowNullValues() {
/*  76 */     return this.allowNullValues;
/*     */   }
/*     */ 
/*     */   public Cache.ValueWrapper get(Object key)
/*     */   {
/*  81 */     Object value = this.cache.get(key);
/*  82 */     return value != null ? new SimpleValueWrapper(fromStoreValue(value)) : null;
/*     */   }
/*     */ 
/*     */   public void put(Object key, Object value)
/*     */   {
/*  87 */     this.cache.put(key, toStoreValue(value));
/*     */   }
/*     */ 
/*     */   public void evict(Object key)
/*     */   {
/*  92 */     this.cache.remove(key);
/*     */   }
/*     */ 
/*     */   public void clear() {
/*  96 */     this.cache.removeAll();
/*     */   }
/*     */ 
/*     */   protected Object fromStoreValue(Object storeValue)
/*     */   {
/* 107 */     if ((this.allowNullValues) && (storeValue == NULL_HOLDER)) {
/* 108 */       return null;
/*     */     }
/* 110 */     return storeValue;
/*     */   }
/*     */ 
/*     */   protected Object toStoreValue(Object userValue)
/*     */   {
/* 120 */     if ((this.allowNullValues) && (userValue == null)) {
/* 121 */       return NULL_HOLDER;
/*     */     }
/* 123 */     return userValue;
/*     */   }
/*     */ 
/*     */   private static class NullHolder
/*     */     implements Serializable
/*     */   {
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.jcache.JCacheCache
 * JD-Core Version:    0.6.1
 */