/*     */ package org.springframework.cache.jcache;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashSet;
/*     */ import javax.cache.CacheManager;
/*     */ import javax.cache.Status;
/*     */ import org.springframework.cache.transaction.AbstractTransactionSupportingCacheManager;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class JCacheCacheManager extends AbstractTransactionSupportingCacheManager
/*     */ {
/*     */   private CacheManager cacheManager;
/*  39 */   private boolean allowNullValues = true;
/*     */ 
/*     */   public JCacheCacheManager()
/*     */   {
/*     */   }
/*     */ 
/*     */   public JCacheCacheManager(CacheManager cacheManager)
/*     */   {
/*  54 */     this.cacheManager = cacheManager;
/*     */   }
/*     */ 
/*     */   public void setCacheManager(CacheManager cacheManager)
/*     */   {
/*  62 */     this.cacheManager = cacheManager;
/*     */   }
/*     */ 
/*     */   public CacheManager getCacheManager()
/*     */   {
/*  69 */     return this.cacheManager;
/*     */   }
/*     */ 
/*     */   public void setAllowNullValues(boolean allowNullValues)
/*     */   {
/*  79 */     this.allowNullValues = allowNullValues;
/*     */   }
/*     */ 
/*     */   public boolean isAllowNullValues()
/*     */   {
/*  87 */     return this.allowNullValues;
/*     */   }
/*     */ 
/*     */   protected Collection<org.springframework.cache.Cache> loadCaches()
/*     */   {
/*  93 */     Assert.notNull(this.cacheManager, "A backing CacheManager is required");
/*  94 */     Status status = this.cacheManager.getStatus();
/*  95 */     Assert.isTrue(Status.STARTED.equals(status), "A 'started' JCache CacheManager is required - current cache is " + status.toString());
/*     */ 
/*  98 */     Collection caches = new LinkedHashSet();
/*  99 */     for (javax.cache.Cache jcache : this.cacheManager.getCaches()) {
/* 100 */       caches.add(new JCacheCache(jcache, this.allowNullValues));
/*     */     }
/* 102 */     return caches;
/*     */   }
/*     */ 
/*     */   public org.springframework.cache.Cache getCache(String name)
/*     */   {
/* 107 */     org.springframework.cache.Cache cache = super.getCache(name);
/* 108 */     if (cache == null)
/*     */     {
/* 111 */       javax.cache.Cache jcache = this.cacheManager.getCache(name);
/* 112 */       if (jcache != null) {
/* 113 */         addCache(new JCacheCache(jcache, this.allowNullValues));
/* 114 */         cache = super.getCache(name);
/*     */       }
/*     */     }
/* 117 */     return cache;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.jcache.JCacheCacheManager
 * JD-Core Version:    0.6.1
 */