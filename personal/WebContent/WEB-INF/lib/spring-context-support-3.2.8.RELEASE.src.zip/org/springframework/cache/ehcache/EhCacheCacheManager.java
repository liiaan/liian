/*    */ package org.springframework.cache.ehcache;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.LinkedHashSet;
/*    */ import net.sf.ehcache.CacheManager;
/*    */ import net.sf.ehcache.Ehcache;
/*    */ import net.sf.ehcache.Status;
/*    */ import org.springframework.cache.Cache;
/*    */ import org.springframework.cache.transaction.AbstractTransactionSupportingCacheManager;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class EhCacheCacheManager extends AbstractTransactionSupportingCacheManager
/*    */ {
/*    */   private CacheManager cacheManager;
/*    */ 
/*    */   public EhCacheCacheManager()
/*    */   {
/*    */   }
/*    */ 
/*    */   public EhCacheCacheManager(CacheManager cacheManager)
/*    */   {
/* 53 */     this.cacheManager = cacheManager;
/*    */   }
/*    */ 
/*    */   public void setCacheManager(CacheManager cacheManager)
/*    */   {
/* 61 */     this.cacheManager = cacheManager;
/*    */   }
/*    */ 
/*    */   public CacheManager getCacheManager()
/*    */   {
/* 68 */     return this.cacheManager;
/*    */   }
/*    */ 
/*    */   protected Collection<Cache> loadCaches()
/*    */   {
/* 74 */     Assert.notNull(this.cacheManager, "A backing EhCache CacheManager is required");
/* 75 */     Status status = this.cacheManager.getStatus();
/* 76 */     Assert.isTrue(Status.STATUS_ALIVE.equals(status), "An 'alive' EhCache CacheManager is required - current cache is " + status.toString());
/*    */ 
/* 79 */     String[] names = this.cacheManager.getCacheNames();
/* 80 */     Collection caches = new LinkedHashSet(names.length);
/* 81 */     for (String name : names) {
/* 82 */       caches.add(new EhCacheCache(this.cacheManager.getEhcache(name)));
/*    */     }
/* 84 */     return caches;
/*    */   }
/*    */ 
/*    */   public Cache getCache(String name)
/*    */   {
/* 89 */     Cache cache = super.getCache(name);
/* 90 */     if (cache == null)
/*    */     {
/* 93 */       Ehcache ehcache = this.cacheManager.getEhcache(name);
/* 94 */       if (ehcache != null) {
/* 95 */         addCache(new EhCacheCache(ehcache));
/* 96 */         cache = super.getCache(name);
/*    */       }
/*    */     }
/* 99 */     return cache;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.ehcache.EhCacheCacheManager
 * JD-Core Version:    0.6.1
 */