/*    */ package org.springframework.cache.jcache;
/*    */ 
/*    */ import javax.cache.CacheManager;
/*    */ import javax.cache.Caching;
/*    */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*    */ import org.springframework.beans.factory.DisposableBean;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ 
/*    */ public class JCacheManagerFactoryBean
/*    */   implements FactoryBean<CacheManager>, BeanClassLoaderAware, InitializingBean, DisposableBean
/*    */ {
/* 40 */   private String cacheManagerName = "__default__";
/*    */   private ClassLoader beanClassLoader;
/*    */   private CacheManager cacheManager;
/*    */ 
/*    */   public void setCacheManagerName(String cacheManagerName)
/*    */   {
/* 53 */     this.cacheManagerName = cacheManagerName;
/*    */   }
/*    */ 
/*    */   public void setBeanClassLoader(ClassLoader classLoader) {
/* 57 */     this.beanClassLoader = classLoader;
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet() {
/* 61 */     this.cacheManager = (this.beanClassLoader != null ? Caching.getCacheManager(this.beanClassLoader, this.cacheManagerName) : Caching.getCacheManager(this.cacheManagerName));
/*    */   }
/*    */ 
/*    */   public CacheManager getObject()
/*    */   {
/* 68 */     return this.cacheManager;
/*    */   }
/*    */ 
/*    */   public Class<?> getObjectType() {
/* 72 */     return this.cacheManager != null ? this.cacheManager.getClass() : CacheManager.class;
/*    */   }
/*    */ 
/*    */   public boolean isSingleton() {
/* 76 */     return true;
/*    */   }
/*    */ 
/*    */   public void destroy()
/*    */   {
/* 81 */     this.cacheManager.shutdown();
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.jcache.JCacheManagerFactoryBean
 * JD-Core Version:    0.6.1
 */