/*    */ package org.springframework.cache.transaction;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.cache.Cache;
/*    */ import org.springframework.cache.CacheManager;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class TransactionAwareCacheManagerProxy
/*    */   implements CacheManager, InitializingBean
/*    */ {
/*    */   private CacheManager targetCacheManager;
/*    */ 
/*    */   public TransactionAwareCacheManagerProxy()
/*    */   {
/*    */   }
/*    */ 
/*    */   public TransactionAwareCacheManagerProxy(CacheManager targetCacheManager)
/*    */   {
/* 56 */     Assert.notNull(targetCacheManager, "Target CacheManager must not be null");
/* 57 */     this.targetCacheManager = targetCacheManager;
/*    */   }
/*    */ 
/*    */   public void setTargetCacheManager(CacheManager targetCacheManager)
/*    */   {
/* 65 */     this.targetCacheManager = targetCacheManager;
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet() {
/* 69 */     if (this.targetCacheManager == null)
/* 70 */       throw new IllegalStateException("'targetCacheManager' is required");
/*    */   }
/*    */ 
/*    */   public Cache getCache(String name)
/*    */   {
/* 76 */     return new TransactionAwareCacheDecorator(this.targetCacheManager.getCache(name));
/*    */   }
/*    */ 
/*    */   public Collection<String> getCacheNames() {
/* 80 */     return this.targetCacheManager.getCacheNames();
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.transaction.TransactionAwareCacheManagerProxy
 * JD-Core Version:    0.6.1
 */