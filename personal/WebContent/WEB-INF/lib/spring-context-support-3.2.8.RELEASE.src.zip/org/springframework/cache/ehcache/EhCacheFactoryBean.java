/*     */ package org.springframework.cache.ehcache;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Set;
/*     */ import net.sf.ehcache.Cache;
/*     */ import net.sf.ehcache.CacheException;
/*     */ import net.sf.ehcache.CacheManager;
/*     */ import net.sf.ehcache.Ehcache;
/*     */ import net.sf.ehcache.bootstrap.BootstrapCacheLoader;
/*     */ import net.sf.ehcache.constructs.blocking.BlockingCache;
/*     */ import net.sf.ehcache.constructs.blocking.CacheEntryFactory;
/*     */ import net.sf.ehcache.constructs.blocking.SelfPopulatingCache;
/*     */ import net.sf.ehcache.constructs.blocking.UpdatingCacheEntryFactory;
/*     */ import net.sf.ehcache.constructs.blocking.UpdatingSelfPopulatingCache;
/*     */ import net.sf.ehcache.event.CacheEventListener;
/*     */ import net.sf.ehcache.event.RegisteredEventListeners;
/*     */ import net.sf.ehcache.store.MemoryStoreEvictionPolicy;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class EhCacheFactoryBean
/*     */   implements FactoryBean<Ehcache>, BeanNameAware, InitializingBean
/*     */ {
/*  69 */   private static final boolean setStatisticsAvailable = ClassUtils.hasMethod(Ehcache.class, "setStatisticsEnabled", new Class[] { Boolean.TYPE });
/*     */ 
/*  73 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private CacheManager cacheManager;
/*     */   private String cacheName;
/*  79 */   private int maxElementsInMemory = 10000;
/*     */ 
/*  81 */   private int maxElementsOnDisk = 10000000;
/*     */ 
/*  83 */   private MemoryStoreEvictionPolicy memoryStoreEvictionPolicy = MemoryStoreEvictionPolicy.LRU;
/*     */ 
/*  85 */   private boolean overflowToDisk = true;
/*     */ 
/*  87 */   private boolean eternal = false;
/*     */ 
/*  89 */   private int timeToLive = 120;
/*     */ 
/*  91 */   private int timeToIdle = 120;
/*     */ 
/*  93 */   private boolean diskPersistent = false;
/*     */ 
/*  95 */   private int diskExpiryThreadIntervalSeconds = 120;
/*     */ 
/*  97 */   private int diskSpoolBufferSize = 0;
/*     */ 
/*  99 */   private boolean clearOnFlush = true;
/*     */ 
/* 101 */   private boolean blocking = false;
/*     */   private CacheEntryFactory cacheEntryFactory;
/*     */   private BootstrapCacheLoader bootstrapCacheLoader;
/*     */   private Set<CacheEventListener> cacheEventListeners;
/* 109 */   private boolean statisticsEnabled = false;
/*     */ 
/* 111 */   private boolean sampledStatisticsEnabled = false;
/*     */ 
/* 113 */   private boolean disabled = false;
/*     */   private String beanName;
/*     */   private Ehcache cache;
/*     */ 
/*     */   public void setCacheManager(CacheManager cacheManager)
/*     */   {
/* 132 */     this.cacheManager = cacheManager;
/*     */   }
/*     */ 
/*     */   public void setCacheName(String cacheName)
/*     */   {
/* 140 */     this.cacheName = cacheName;
/*     */   }
/*     */ 
/*     */   public void setMaxElementsInMemory(int maxElementsInMemory)
/*     */   {
/* 148 */     this.maxElementsInMemory = maxElementsInMemory;
/*     */   }
/*     */ 
/*     */   public void setMaxElementsOnDisk(int maxElementsOnDisk)
/*     */   {
/* 156 */     this.maxElementsOnDisk = maxElementsOnDisk;
/*     */   }
/*     */ 
/*     */   public void setMemoryStoreEvictionPolicy(MemoryStoreEvictionPolicy memoryStoreEvictionPolicy)
/*     */   {
/* 166 */     Assert.notNull(memoryStoreEvictionPolicy, "memoryStoreEvictionPolicy must not be null");
/* 167 */     this.memoryStoreEvictionPolicy = memoryStoreEvictionPolicy;
/*     */   }
/*     */ 
/*     */   public void setOverflowToDisk(boolean overflowToDisk)
/*     */   {
/* 175 */     this.overflowToDisk = overflowToDisk;
/*     */   }
/*     */ 
/*     */   public void setEternal(boolean eternal)
/*     */   {
/* 183 */     this.eternal = eternal;
/*     */   }
/*     */ 
/*     */   public void setTimeToLive(int timeToLive)
/*     */   {
/* 192 */     this.timeToLive = timeToLive;
/*     */   }
/*     */ 
/*     */   public void setTimeToIdle(int timeToIdle)
/*     */   {
/* 201 */     this.timeToIdle = timeToIdle;
/*     */   }
/*     */ 
/*     */   public void setDiskPersistent(boolean diskPersistent)
/*     */   {
/* 209 */     this.diskPersistent = diskPersistent;
/*     */   }
/*     */ 
/*     */   public void setDiskExpiryThreadIntervalSeconds(int diskExpiryThreadIntervalSeconds)
/*     */   {
/* 217 */     this.diskExpiryThreadIntervalSeconds = diskExpiryThreadIntervalSeconds;
/*     */   }
/*     */ 
/*     */   public void setDiskSpoolBufferSize(int diskSpoolBufferSize)
/*     */   {
/* 225 */     this.diskSpoolBufferSize = diskSpoolBufferSize;
/*     */   }
/*     */ 
/*     */   public void setClearOnFlush(boolean clearOnFlush)
/*     */   {
/* 233 */     this.clearOnFlush = clearOnFlush;
/*     */   }
/*     */ 
/*     */   public void setBlocking(boolean blocking)
/*     */   {
/* 245 */     this.blocking = blocking;
/*     */   }
/*     */ 
/*     */   public void setCacheEntryFactory(CacheEntryFactory cacheEntryFactory)
/*     */   {
/* 263 */     this.cacheEntryFactory = cacheEntryFactory;
/*     */   }
/*     */ 
/*     */   public void setBootstrapCacheLoader(BootstrapCacheLoader bootstrapCacheLoader)
/*     */   {
/* 271 */     this.bootstrapCacheLoader = bootstrapCacheLoader;
/*     */   }
/*     */ 
/*     */   public void setCacheEventListeners(Set<CacheEventListener> cacheEventListeners)
/*     */   {
/* 279 */     this.cacheEventListeners = cacheEventListeners;
/*     */   }
/*     */ 
/*     */   public void setStatisticsEnabled(boolean statisticsEnabled)
/*     */   {
/* 289 */     this.statisticsEnabled = statisticsEnabled;
/*     */   }
/*     */ 
/*     */   public void setSampledStatisticsEnabled(boolean sampledStatisticsEnabled)
/*     */   {
/* 299 */     this.sampledStatisticsEnabled = sampledStatisticsEnabled;
/*     */   }
/*     */ 
/*     */   public void setDisabled(boolean disabled)
/*     */   {
/* 307 */     this.disabled = disabled;
/*     */   }
/*     */ 
/*     */   public void setBeanName(String name) {
/* 311 */     this.beanName = name;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws CacheException, IOException
/*     */   {
/* 317 */     if (this.cacheManager == null) {
/* 318 */       if (this.logger.isDebugEnabled()) {
/* 319 */         this.logger.debug("Using default EhCache CacheManager for cache region '" + this.cacheName + "'");
/*     */       }
/* 321 */       this.cacheManager = CacheManager.getInstance();
/*     */     }
/*     */ 
/* 325 */     if (this.cacheName == null) {
/* 326 */       this.cacheName = this.beanName;
/*     */     }
/*     */ 
/* 329 */     synchronized (this.cacheManager)
/*     */     {
/* 333 */       boolean cacheExists = this.cacheManager.cacheExists(this.cacheName);
/*     */       Ehcache rawCache;
/*     */       Ehcache rawCache;
/* 335 */       if (cacheExists) {
/* 336 */         if (this.logger.isDebugEnabled()) {
/* 337 */           this.logger.debug("Using existing EhCache cache region '" + this.cacheName + "'");
/*     */         }
/* 339 */         rawCache = this.cacheManager.getEhcache(this.cacheName);
/*     */       }
/*     */       else {
/* 342 */         if (this.logger.isDebugEnabled()) {
/* 343 */           this.logger.debug("Creating new EhCache cache region '" + this.cacheName + "'");
/*     */         }
/* 345 */         rawCache = createCache();
/*     */       }
/*     */ 
/* 348 */       if (this.cacheEventListeners != null) {
/* 349 */         for (CacheEventListener listener : this.cacheEventListeners) {
/* 350 */           rawCache.getCacheEventNotificationService().registerListener(listener);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 355 */       if (!cacheExists) {
/* 356 */         this.cacheManager.addCache(rawCache);
/*     */       }
/*     */ 
/* 360 */       if (setStatisticsAvailable) {
/* 361 */         if (this.statisticsEnabled) {
/* 362 */           rawCache.setStatisticsEnabled(true);
/*     */         }
/* 364 */         if (this.sampledStatisticsEnabled) {
/* 365 */           rawCache.setSampledStatisticsEnabled(true);
/*     */         }
/*     */       }
/* 368 */       if (this.disabled) {
/* 369 */         rawCache.setDisabled(true);
/*     */       }
/*     */ 
/* 372 */       Ehcache decoratedCache = decorateCache(rawCache);
/* 373 */       if (decoratedCache != rawCache) {
/* 374 */         this.cacheManager.replaceCacheWithDecoratedCache(rawCache, decoratedCache);
/*     */       }
/* 376 */       this.cache = decoratedCache;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Cache createCache()
/*     */   {
/* 385 */     return !this.clearOnFlush ? new Cache(this.cacheName, this.maxElementsInMemory, this.memoryStoreEvictionPolicy, this.overflowToDisk, null, this.eternal, this.timeToLive, this.timeToIdle, this.diskPersistent, this.diskExpiryThreadIntervalSeconds, null, this.bootstrapCacheLoader, this.maxElementsOnDisk, this.diskSpoolBufferSize, this.clearOnFlush) : new Cache(this.cacheName, this.maxElementsInMemory, this.memoryStoreEvictionPolicy, this.overflowToDisk, null, this.eternal, this.timeToLive, this.timeToIdle, this.diskPersistent, this.diskExpiryThreadIntervalSeconds, null, this.bootstrapCacheLoader, this.maxElementsOnDisk, this.diskSpoolBufferSize);
/*     */   }
/*     */ 
/*     */   protected Ehcache decorateCache(Ehcache cache)
/*     */   {
/* 403 */     if (this.cacheEntryFactory != null) {
/* 404 */       if ((this.cacheEntryFactory instanceof UpdatingCacheEntryFactory)) {
/* 405 */         return new UpdatingSelfPopulatingCache(cache, (UpdatingCacheEntryFactory)this.cacheEntryFactory);
/*     */       }
/*     */ 
/* 408 */       return new SelfPopulatingCache(cache, this.cacheEntryFactory);
/*     */     }
/*     */ 
/* 411 */     if (this.blocking) {
/* 412 */       return new BlockingCache(cache);
/*     */     }
/* 414 */     return cache;
/*     */   }
/*     */ 
/*     */   public Ehcache getObject()
/*     */   {
/* 419 */     return this.cache;
/*     */   }
/*     */ 
/*     */   public Class<? extends Ehcache> getObjectType()
/*     */   {
/* 428 */     if (this.cache != null) {
/* 429 */       return this.cache.getClass();
/*     */     }
/* 431 */     if (this.cacheEntryFactory != null) {
/* 432 */       if ((this.cacheEntryFactory instanceof UpdatingCacheEntryFactory)) {
/* 433 */         return UpdatingSelfPopulatingCache.class;
/*     */       }
/*     */ 
/* 436 */       return SelfPopulatingCache.class;
/*     */     }
/*     */ 
/* 439 */     if (this.blocking) {
/* 440 */       return BlockingCache.class;
/*     */     }
/* 442 */     return Cache.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton() {
/* 446 */     return true;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.ehcache.EhCacheFactoryBean
 * JD-Core Version:    0.6.1
 */