/*    */ package org.springframework.cache.ehcache;
/*    */ 
/*    */ import net.sf.ehcache.Ehcache;
/*    */ import net.sf.ehcache.Element;
/*    */ import net.sf.ehcache.Status;
/*    */ import org.springframework.cache.Cache;
/*    */ import org.springframework.cache.Cache.ValueWrapper;
/*    */ import org.springframework.cache.support.SimpleValueWrapper;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class EhCacheCache
/*    */   implements Cache
/*    */ {
/*    */   private final Ehcache cache;
/*    */ 
/*    */   public EhCacheCache(Ehcache ehcache)
/*    */   {
/* 44 */     Assert.notNull(ehcache, "Ehcache must not be null");
/* 45 */     Status status = ehcache.getStatus();
/* 46 */     Assert.isTrue(Status.STATUS_ALIVE.equals(status), "An 'alive' Ehcache is required - current cache is " + status.toString());
/*    */ 
/* 48 */     this.cache = ehcache;
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 53 */     return this.cache.getName();
/*    */   }
/*    */ 
/*    */   public Ehcache getNativeCache() {
/* 57 */     return this.cache;
/*    */   }
/*    */ 
/*    */   public Cache.ValueWrapper get(Object key) {
/* 61 */     Element element = this.cache.get(key);
/* 62 */     return element != null ? new SimpleValueWrapper(element.getObjectValue()) : null;
/*    */   }
/*    */ 
/*    */   public void put(Object key, Object value) {
/* 66 */     this.cache.put(new Element(key, value));
/*    */   }
/*    */ 
/*    */   public void evict(Object key) {
/* 70 */     this.cache.remove(key);
/*    */   }
/*    */ 
/*    */   public void clear() {
/* 74 */     this.cache.removeAll();
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.ehcache.EhCacheCache
 * JD-Core Version:    0.6.1
 */