/*     */ package org.springframework.cache.ehcache;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Method;
/*     */ import net.sf.ehcache.CacheException;
/*     */ import net.sf.ehcache.CacheManager;
/*     */ import net.sf.ehcache.config.Configuration;
/*     */ import net.sf.ehcache.config.ConfigurationFactory;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class EhCacheManagerFactoryBean
/*     */   implements FactoryBean<CacheManager>, InitializingBean, DisposableBean
/*     */ {
/*  64 */   private static final Method createWithConfiguration = ClassUtils.getMethodIfAvailable(CacheManager.class, "create", new Class[] { Configuration.class });
/*     */ 
/*  67 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private Resource configLocation;
/*  71 */   private boolean shared = false;
/*     */   private String cacheManagerName;
/*     */   private CacheManager cacheManager;
/*     */ 
/*     */   public void setConfigLocation(Resource configLocation)
/*     */   {
/*  86 */     this.configLocation = configLocation;
/*     */   }
/*     */ 
/*     */   public void setShared(boolean shared)
/*     */   {
/*  97 */     this.shared = shared;
/*     */   }
/*     */ 
/*     */   public void setCacheManagerName(String cacheManagerName)
/*     */   {
/* 105 */     this.cacheManagerName = cacheManagerName;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() throws IOException, CacheException
/*     */   {
/* 110 */     this.logger.info("Initializing EhCache CacheManager");
/* 111 */     InputStream is = this.configLocation != null ? this.configLocation.getInputStream() : null;
/*     */     try
/*     */     {
/* 115 */       if (this.cacheManagerName != null) {
/* 116 */         if ((this.shared) && (createWithConfiguration == null))
/*     */         {
/* 119 */           this.cacheManager = (is != null ? CacheManager.create(is) : CacheManager.create());
/* 120 */           this.cacheManager.setName(this.cacheManagerName);
/*     */         }
/*     */         else {
/* 123 */           Configuration configuration = is != null ? ConfigurationFactory.parseConfiguration(is) : ConfigurationFactory.parseConfiguration();
/*     */ 
/* 125 */           configuration.setName(this.cacheManagerName);
/* 126 */           if (this.shared) {
/* 127 */             this.cacheManager = ((CacheManager)ReflectionUtils.invokeMethod(createWithConfiguration, null, new Object[] { configuration }));
/*     */           }
/*     */           else {
/* 130 */             this.cacheManager = new CacheManager(configuration);
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/* 135 */       else if (this.shared) {
/* 136 */         this.cacheManager = (is != null ? CacheManager.create(is) : CacheManager.create());
/*     */       }
/*     */       else
/* 139 */         this.cacheManager = (is != null ? new CacheManager(is) : new CacheManager());
/*     */     }
/*     */     finally
/*     */     {
/* 143 */       if (is != null)
/* 144 */         is.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public CacheManager getObject()
/*     */   {
/* 151 */     return this.cacheManager;
/*     */   }
/*     */ 
/*     */   public Class<? extends CacheManager> getObjectType() {
/* 155 */     return this.cacheManager != null ? this.cacheManager.getClass() : CacheManager.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton() {
/* 159 */     return true;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 164 */     this.logger.info("Shutting down EhCache CacheManager");
/* 165 */     this.cacheManager.shutdown();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.ehcache.EhCacheManagerFactoryBean
 * JD-Core Version:    0.6.1
 */