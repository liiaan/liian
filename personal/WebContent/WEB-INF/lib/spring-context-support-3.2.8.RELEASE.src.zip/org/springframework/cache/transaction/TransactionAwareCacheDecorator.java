/*    */ package org.springframework.cache.transaction;
/*    */ 
/*    */ import org.springframework.cache.Cache;
/*    */ import org.springframework.cache.Cache.ValueWrapper;
/*    */ import org.springframework.transaction.support.TransactionSynchronizationAdapter;
/*    */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class TransactionAwareCacheDecorator
/*    */   implements Cache
/*    */ {
/*    */   private final Cache targetCache;
/*    */ 
/*    */   public TransactionAwareCacheDecorator(Cache targetCache)
/*    */   {
/* 45 */     Assert.notNull(targetCache, "Target Cache must not be null");
/* 46 */     this.targetCache = targetCache;
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 51 */     return this.targetCache.getName();
/*    */   }
/*    */ 
/*    */   public Object getNativeCache() {
/* 55 */     return this.targetCache.getNativeCache();
/*    */   }
/*    */ 
/*    */   public Cache.ValueWrapper get(Object key) {
/* 59 */     return this.targetCache.get(key);
/*    */   }
/*    */ 
/*    */   public void put(final Object key, final Object value) {
/* 63 */     if (TransactionSynchronizationManager.isSynchronizationActive()) {
/* 64 */       TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter()
/*    */       {
/*    */         public void afterCommit() {
/* 67 */           TransactionAwareCacheDecorator.this.targetCache.put(key, value);
/*    */         }
/*    */       });
/*    */     }
/*    */     else
/* 72 */       this.targetCache.put(key, value);
/*    */   }
/*    */ 
/*    */   public void evict(final Object key)
/*    */   {
/* 77 */     if (TransactionSynchronizationManager.isSynchronizationActive()) {
/* 78 */       TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronizationAdapter()
/*    */       {
/*    */         public void afterCommit() {
/* 81 */           TransactionAwareCacheDecorator.this.targetCache.evict(key);
/*    */         }
/*    */       });
/*    */     }
/*    */     else
/* 86 */       this.targetCache.evict(key);
/*    */   }
/*    */ 
/*    */   public void clear()
/*    */   {
/* 91 */     this.targetCache.clear();
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.cache.transaction.TransactionAwareCacheDecorator
 * JD-Core Version:    0.6.1
 */