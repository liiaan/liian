/*    */ package org.springframework.mail;
/*    */ 
/*    */ public class MailPreparationException extends MailException
/*    */ {
/*    */   public MailPreparationException(String msg)
/*    */   {
/* 36 */     super(msg);
/*    */   }
/*    */ 
/*    */   public MailPreparationException(String msg, Throwable cause)
/*    */   {
/* 45 */     super(msg, cause);
/*    */   }
/*    */ 
/*    */   public MailPreparationException(Throwable cause) {
/* 49 */     super("Could not prepare mail", cause);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.mail.MailPreparationException
 * JD-Core Version:    0.6.1
 */