/*     */ package org.springframework.mail;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.util.Collection;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public class MailSendException extends MailException
/*     */ {
/*     */   private final transient Map<Object, Exception> failedMessages;
/*     */   private Exception[] messageExceptions;
/*     */ 
/*     */   public MailSendException(String msg)
/*     */   {
/*  46 */     this(msg, null);
/*     */   }
/*     */ 
/*     */   public MailSendException(String msg, Throwable cause)
/*     */   {
/*  55 */     super(msg, cause);
/*  56 */     this.failedMessages = new LinkedHashMap();
/*     */   }
/*     */ 
/*     */   public MailSendException(String msg, Throwable cause, Map<Object, Exception> failedMessages)
/*     */   {
/*  70 */     super(msg, cause);
/*  71 */     this.failedMessages = new LinkedHashMap(failedMessages);
/*  72 */     this.messageExceptions = ((Exception[])failedMessages.values().toArray(new Exception[failedMessages.size()]));
/*     */   }
/*     */ 
/*     */   public MailSendException(Map<Object, Exception> failedMessages)
/*     */   {
/*  84 */     this(null, null, failedMessages);
/*     */   }
/*     */ 
/*     */   public final Map<Object, Exception> getFailedMessages()
/*     */   {
/* 107 */     return this.failedMessages;
/*     */   }
/*     */ 
/*     */   public final Exception[] getMessageExceptions()
/*     */   {
/* 119 */     return this.messageExceptions != null ? this.messageExceptions : new Exception[0];
/*     */   }
/*     */ 
/*     */   public String getMessage()
/*     */   {
/* 125 */     if (ObjectUtils.isEmpty(this.messageExceptions)) {
/* 126 */       return super.getMessage();
/*     */     }
/*     */ 
/* 129 */     StringBuilder sb = new StringBuilder();
/* 130 */     String baseMessage = super.getMessage();
/* 131 */     if (baseMessage != null) {
/* 132 */       sb.append(baseMessage).append(". ");
/*     */     }
/* 134 */     sb.append("Failed messages: ");
/* 135 */     for (int i = 0; i < this.messageExceptions.length; i++) {
/* 136 */       Exception subEx = this.messageExceptions[i];
/* 137 */       sb.append(subEx.toString());
/* 138 */       if (i < this.messageExceptions.length - 1) {
/* 139 */         sb.append("; ");
/*     */       }
/*     */     }
/* 142 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 148 */     if (ObjectUtils.isEmpty(this.messageExceptions)) {
/* 149 */       return super.toString();
/*     */     }
/*     */ 
/* 152 */     StringBuilder sb = new StringBuilder(super.toString());
/* 153 */     sb.append("; message exceptions (").append(this.messageExceptions.length).append(") are:");
/* 154 */     for (int i = 0; i < this.messageExceptions.length; i++) {
/* 155 */       Exception subEx = this.messageExceptions[i];
/* 156 */       sb.append('\n').append("Failed message ").append(i + 1).append(": ");
/* 157 */       sb.append(subEx);
/*     */     }
/* 159 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public void printStackTrace(PrintStream ps)
/*     */   {
/* 165 */     if (ObjectUtils.isEmpty(this.messageExceptions)) {
/* 166 */       super.printStackTrace(ps);
/*     */     }
/*     */     else {
/* 169 */       ps.println(super.toString() + "; message exception details (" + this.messageExceptions.length + ") are:");
/*     */ 
/* 171 */       for (int i = 0; i < this.messageExceptions.length; i++) {
/* 172 */         Exception subEx = this.messageExceptions[i];
/* 173 */         ps.println("Failed message " + (i + 1) + ":");
/* 174 */         subEx.printStackTrace(ps);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void printStackTrace(PrintWriter pw)
/*     */   {
/* 181 */     if (ObjectUtils.isEmpty(this.messageExceptions)) {
/* 182 */       super.printStackTrace(pw);
/*     */     }
/*     */     else {
/* 185 */       pw.println(super.toString() + "; message exception details (" + this.messageExceptions.length + ") are:");
/*     */ 
/* 187 */       for (int i = 0; i < this.messageExceptions.length; i++) {
/* 188 */         Exception subEx = this.messageExceptions[i];
/* 189 */         pw.println("Failed message " + (i + 1) + ":");
/* 190 */         subEx.printStackTrace(pw);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.mail.MailSendException
 * JD-Core Version:    0.6.1
 */