/*     */ package org.springframework.mail;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.Date;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class SimpleMailMessage
/*     */   implements MailMessage, Serializable
/*     */ {
/*     */   private String from;
/*     */   private String replyTo;
/*     */   private String[] to;
/*     */   private String[] cc;
/*     */   private String[] bcc;
/*     */   private Date sentDate;
/*     */   private String subject;
/*     */   private String text;
/*     */ 
/*     */   public SimpleMailMessage()
/*     */   {
/*     */   }
/*     */ 
/*     */   public SimpleMailMessage(SimpleMailMessage original)
/*     */   {
/*  74 */     Assert.notNull(original, "The 'original' message argument cannot be null");
/*  75 */     this.from = original.getFrom();
/*  76 */     this.replyTo = original.getReplyTo();
/*  77 */     if (original.getTo() != null) {
/*  78 */       this.to = copy(original.getTo());
/*     */     }
/*  80 */     if (original.getCc() != null) {
/*  81 */       this.cc = copy(original.getCc());
/*     */     }
/*  83 */     if (original.getBcc() != null) {
/*  84 */       this.bcc = copy(original.getBcc());
/*     */     }
/*  86 */     this.sentDate = original.getSentDate();
/*  87 */     this.subject = original.getSubject();
/*  88 */     this.text = original.getText();
/*     */   }
/*     */ 
/*     */   public void setFrom(String from)
/*     */   {
/*  93 */     this.from = from;
/*     */   }
/*     */ 
/*     */   public String getFrom() {
/*  97 */     return this.from;
/*     */   }
/*     */ 
/*     */   public void setReplyTo(String replyTo) {
/* 101 */     this.replyTo = replyTo;
/*     */   }
/*     */ 
/*     */   public String getReplyTo() {
/* 105 */     return this.replyTo;
/*     */   }
/*     */ 
/*     */   public void setTo(String to) {
/* 109 */     this.to = new String[] { to };
/*     */   }
/*     */ 
/*     */   public void setTo(String[] to) {
/* 113 */     this.to = to;
/*     */   }
/*     */ 
/*     */   public String[] getTo() {
/* 117 */     return this.to;
/*     */   }
/*     */ 
/*     */   public void setCc(String cc) {
/* 121 */     this.cc = new String[] { cc };
/*     */   }
/*     */ 
/*     */   public void setCc(String[] cc) {
/* 125 */     this.cc = cc;
/*     */   }
/*     */ 
/*     */   public String[] getCc() {
/* 129 */     return this.cc;
/*     */   }
/*     */ 
/*     */   public void setBcc(String bcc) {
/* 133 */     this.bcc = new String[] { bcc };
/*     */   }
/*     */ 
/*     */   public void setBcc(String[] bcc) {
/* 137 */     this.bcc = bcc;
/*     */   }
/*     */ 
/*     */   public String[] getBcc() {
/* 141 */     return this.bcc;
/*     */   }
/*     */ 
/*     */   public void setSentDate(Date sentDate) {
/* 145 */     this.sentDate = sentDate;
/*     */   }
/*     */ 
/*     */   public Date getSentDate() {
/* 149 */     return this.sentDate;
/*     */   }
/*     */ 
/*     */   public void setSubject(String subject) {
/* 153 */     this.subject = subject;
/*     */   }
/*     */ 
/*     */   public String getSubject() {
/* 157 */     return this.subject;
/*     */   }
/*     */ 
/*     */   public void setText(String text) {
/* 161 */     this.text = text;
/*     */   }
/*     */ 
/*     */   public String getText() {
/* 165 */     return this.text;
/*     */   }
/*     */ 
/*     */   public void copyTo(MailMessage target)
/*     */   {
/* 175 */     Assert.notNull(target, "The 'target' message argument cannot be null");
/* 176 */     if (getFrom() != null) {
/* 177 */       target.setFrom(getFrom());
/*     */     }
/* 179 */     if (getReplyTo() != null) {
/* 180 */       target.setReplyTo(getReplyTo());
/*     */     }
/* 182 */     if (getTo() != null) {
/* 183 */       target.setTo(getTo());
/*     */     }
/* 185 */     if (getCc() != null) {
/* 186 */       target.setCc(getCc());
/*     */     }
/* 188 */     if (getBcc() != null) {
/* 189 */       target.setBcc(getBcc());
/*     */     }
/* 191 */     if (getSentDate() != null) {
/* 192 */       target.setSentDate(getSentDate());
/*     */     }
/* 194 */     if (getSubject() != null) {
/* 195 */       target.setSubject(getSubject());
/*     */     }
/* 197 */     if (getText() != null)
/* 198 */       target.setText(getText());
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 205 */     StringBuilder sb = new StringBuilder("SimpleMailMessage: ");
/* 206 */     sb.append("from=").append(this.from).append("; ");
/* 207 */     sb.append("replyTo=").append(this.replyTo).append("; ");
/* 208 */     sb.append("to=").append(StringUtils.arrayToCommaDelimitedString(this.to)).append("; ");
/* 209 */     sb.append("cc=").append(StringUtils.arrayToCommaDelimitedString(this.cc)).append("; ");
/* 210 */     sb.append("bcc=").append(StringUtils.arrayToCommaDelimitedString(this.bcc)).append("; ");
/* 211 */     sb.append("sentDate=").append(this.sentDate).append("; ");
/* 212 */     sb.append("subject=").append(this.subject).append("; ");
/* 213 */     sb.append("text=").append(this.text);
/* 214 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object other)
/*     */   {
/* 219 */     if (this == other) {
/* 220 */       return true;
/*     */     }
/* 222 */     if (!(other instanceof SimpleMailMessage)) {
/* 223 */       return false;
/*     */     }
/* 225 */     SimpleMailMessage otherMessage = (SimpleMailMessage)other;
/* 226 */     return (ObjectUtils.nullSafeEquals(this.from, otherMessage.from)) && (ObjectUtils.nullSafeEquals(this.replyTo, otherMessage.replyTo)) && (Arrays.equals(this.to, otherMessage.to)) && (Arrays.equals(this.cc, otherMessage.cc)) && (Arrays.equals(this.bcc, otherMessage.bcc)) && (ObjectUtils.nullSafeEquals(this.sentDate, otherMessage.sentDate)) && (ObjectUtils.nullSafeEquals(this.subject, otherMessage.subject)) && (ObjectUtils.nullSafeEquals(this.text, otherMessage.text));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 238 */     int hashCode = this.from == null ? 0 : this.from.hashCode();
/* 239 */     hashCode = 29 * hashCode + (this.replyTo == null ? 0 : this.replyTo.hashCode());
/* 240 */     for (int i = 0; (this.to != null) && (i < this.to.length); i++) {
/* 241 */       hashCode = 29 * hashCode + (this.to == null ? 0 : this.to[i].hashCode());
/*     */     }
/* 243 */     for (int i = 0; (this.cc != null) && (i < this.cc.length); i++) {
/* 244 */       hashCode = 29 * hashCode + (this.cc == null ? 0 : this.cc[i].hashCode());
/*     */     }
/* 246 */     for (int i = 0; (this.bcc != null) && (i < this.bcc.length); i++) {
/* 247 */       hashCode = 29 * hashCode + (this.bcc == null ? 0 : this.bcc[i].hashCode());
/*     */     }
/* 249 */     hashCode = 29 * hashCode + (this.sentDate == null ? 0 : this.sentDate.hashCode());
/* 250 */     hashCode = 29 * hashCode + (this.subject == null ? 0 : this.subject.hashCode());
/* 251 */     hashCode = 29 * hashCode + (this.text == null ? 0 : this.text.hashCode());
/* 252 */     return hashCode;
/*     */   }
/*     */ 
/*     */   private static String[] copy(String[] state)
/*     */   {
/* 257 */     String[] copy = new String[state.length];
/* 258 */     System.arraycopy(state, 0, copy, 0, state.length);
/* 259 */     return copy;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.mail.SimpleMailMessage
 * JD-Core Version:    0.6.1
 */