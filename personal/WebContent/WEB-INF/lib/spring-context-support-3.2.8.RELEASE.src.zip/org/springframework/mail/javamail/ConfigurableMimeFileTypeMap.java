/*     */ package org.springframework.mail.javamail;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.activation.FileTypeMap;
/*     */ import javax.activation.MimetypesFileTypeMap;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ 
/*     */ public class ConfigurableMimeFileTypeMap extends FileTypeMap
/*     */   implements InitializingBean
/*     */ {
/*  66 */   private Resource mappingLocation = new ClassPathResource("mime.types", getClass());
/*     */   private String[] mappings;
/*     */   private FileTypeMap fileTypeMap;
/*     */ 
/*     */   public void setMappingLocation(Resource mappingLocation)
/*     */   {
/*  87 */     this.mappingLocation = mappingLocation;
/*     */   }
/*     */ 
/*     */   public void setMappings(String[] mappings)
/*     */   {
/*  97 */     this.mappings = mappings;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 105 */     getFileTypeMap();
/*     */   }
/*     */ 
/*     */   protected final FileTypeMap getFileTypeMap()
/*     */   {
/* 116 */     if (this.fileTypeMap == null) {
/*     */       try {
/* 118 */         this.fileTypeMap = createFileTypeMap(this.mappingLocation, this.mappings);
/*     */       }
/*     */       catch (IOException ex) {
/* 121 */         throw new IllegalStateException("Could not load specified MIME type mapping file: " + this.mappingLocation, ex);
/*     */       }
/*     */     }
/*     */ 
/* 125 */     return this.fileTypeMap;
/*     */   }
/*     */ 
/*     */   protected FileTypeMap createFileTypeMap(Resource mappingLocation, String[] mappings)
/*     */     throws IOException
/*     */   {
/* 142 */     MimetypesFileTypeMap fileTypeMap = null;
/* 143 */     if (mappingLocation != null) {
/* 144 */       InputStream is = mappingLocation.getInputStream();
/*     */       try {
/* 146 */         fileTypeMap = new MimetypesFileTypeMap(is);
/*     */       }
/*     */       finally {
/* 149 */         is.close();
/*     */       }
/*     */     }
/*     */     else {
/* 153 */       fileTypeMap = new MimetypesFileTypeMap();
/*     */     }
/* 155 */     if (mappings != null) {
/* 156 */       for (String mapping : mappings) {
/* 157 */         fileTypeMap.addMimeTypes(mapping);
/*     */       }
/*     */     }
/* 160 */     return fileTypeMap;
/*     */   }
/*     */ 
/*     */   public String getContentType(File file)
/*     */   {
/* 170 */     return getFileTypeMap().getContentType(file);
/*     */   }
/*     */ 
/*     */   public String getContentType(String fileName)
/*     */   {
/* 179 */     return getFileTypeMap().getContentType(fileName);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.mail.javamail.ConfigurableMimeFileTypeMap
 * JD-Core Version:    0.6.1
 */