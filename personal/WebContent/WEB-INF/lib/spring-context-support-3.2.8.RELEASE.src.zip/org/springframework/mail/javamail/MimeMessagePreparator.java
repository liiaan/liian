package org.springframework.mail.javamail;

import javax.mail.internet.MimeMessage;

public abstract interface MimeMessagePreparator
{
  public abstract void prepare(MimeMessage paramMimeMessage)
    throws Exception;
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.mail.javamail.MimeMessagePreparator
 * JD-Core Version:    0.6.1
 */