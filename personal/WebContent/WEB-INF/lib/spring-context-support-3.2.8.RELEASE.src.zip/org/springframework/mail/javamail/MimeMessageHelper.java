/*      */ package org.springframework.mail.javamail;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.util.Date;
/*      */ import javax.activation.DataHandler;
/*      */ import javax.activation.DataSource;
/*      */ import javax.activation.FileDataSource;
/*      */ import javax.activation.FileTypeMap;
/*      */ import javax.mail.BodyPart;
/*      */ import javax.mail.Message.RecipientType;
/*      */ import javax.mail.MessagingException;
/*      */ import javax.mail.internet.AddressException;
/*      */ import javax.mail.internet.InternetAddress;
/*      */ import javax.mail.internet.MimeBodyPart;
/*      */ import javax.mail.internet.MimeMessage;
/*      */ import javax.mail.internet.MimeMultipart;
/*      */ import javax.mail.internet.MimePart;
/*      */ import javax.mail.internet.MimeUtility;
/*      */ import org.springframework.core.io.InputStreamSource;
/*      */ import org.springframework.core.io.Resource;
/*      */ import org.springframework.util.Assert;
/*      */ 
/*      */ public class MimeMessageHelper
/*      */ {
/*      */   public static final int MULTIPART_MODE_NO = 0;
/*      */   public static final int MULTIPART_MODE_MIXED = 1;
/*      */   public static final int MULTIPART_MODE_RELATED = 2;
/*      */   public static final int MULTIPART_MODE_MIXED_RELATED = 3;
/*      */   private static final String MULTIPART_SUBTYPE_MIXED = "mixed";
/*      */   private static final String MULTIPART_SUBTYPE_RELATED = "related";
/*      */   private static final String MULTIPART_SUBTYPE_ALTERNATIVE = "alternative";
/*      */   private static final String CONTENT_TYPE_ALTERNATIVE = "text/alternative";
/*      */   private static final String CONTENT_TYPE_HTML = "text/html";
/*      */   private static final String CONTENT_TYPE_CHARSET_SUFFIX = ";charset=";
/*      */   private static final String HEADER_PRIORITY = "X-Priority";
/*      */   private static final String HEADER_CONTENT_ID = "Content-ID";
/*      */   private final MimeMessage mimeMessage;
/*      */   private MimeMultipart rootMimeMultipart;
/*      */   private MimeMultipart mimeMultipart;
/*      */   private final String encoding;
/*      */   private FileTypeMap fileTypeMap;
/*  173 */   private boolean validateAddresses = false;
/*      */ 
/*      */   public MimeMessageHelper(MimeMessage mimeMessage)
/*      */   {
/*  189 */     this(mimeMessage, null);
/*      */   }
/*      */ 
/*      */   public MimeMessageHelper(MimeMessage mimeMessage, String encoding)
/*      */   {
/*  201 */     this.mimeMessage = mimeMessage;
/*  202 */     this.encoding = (encoding != null ? encoding : getDefaultEncoding(mimeMessage));
/*  203 */     this.fileTypeMap = getDefaultFileTypeMap(mimeMessage);
/*      */   }
/*      */ 
/*      */   public MimeMessageHelper(MimeMessage mimeMessage, boolean multipart)
/*      */     throws MessagingException
/*      */   {
/*  226 */     this(mimeMessage, multipart, null);
/*      */   }
/*      */ 
/*      */   public MimeMessageHelper(MimeMessage mimeMessage, boolean multipart, String encoding)
/*      */     throws MessagingException
/*      */   {
/*  247 */     this(mimeMessage, multipart ? 3 : 0, encoding);
/*      */   }
/*      */ 
/*      */   public MimeMessageHelper(MimeMessage mimeMessage, int multipartMode)
/*      */     throws MessagingException
/*      */   {
/*  269 */     this(mimeMessage, multipartMode, null);
/*      */   }
/*      */ 
/*      */   public MimeMessageHelper(MimeMessage mimeMessage, int multipartMode, String encoding)
/*      */     throws MessagingException
/*      */   {
/*  289 */     this.mimeMessage = mimeMessage;
/*  290 */     createMimeMultiparts(mimeMessage, multipartMode);
/*  291 */     this.encoding = (encoding != null ? encoding : getDefaultEncoding(mimeMessage));
/*  292 */     this.fileTypeMap = getDefaultFileTypeMap(mimeMessage);
/*      */   }
/*      */ 
/*      */   public final MimeMessage getMimeMessage()
/*      */   {
/*  300 */     return this.mimeMessage;
/*      */   }
/*      */ 
/*      */   protected void createMimeMultiparts(MimeMessage mimeMessage, int multipartMode)
/*      */     throws MessagingException
/*      */   {
/*  328 */     switch (multipartMode) {
/*      */     case 0:
/*  330 */       setMimeMultiparts(null, null);
/*  331 */       break;
/*      */     case 1:
/*  333 */       MimeMultipart mixedMultipart = new MimeMultipart("mixed");
/*  334 */       mimeMessage.setContent(mixedMultipart);
/*  335 */       setMimeMultiparts(mixedMultipart, mixedMultipart);
/*  336 */       break;
/*      */     case 2:
/*  338 */       MimeMultipart relatedMultipart = new MimeMultipart("related");
/*  339 */       mimeMessage.setContent(relatedMultipart);
/*  340 */       setMimeMultiparts(relatedMultipart, relatedMultipart);
/*  341 */       break;
/*      */     case 3:
/*  343 */       MimeMultipart rootMixedMultipart = new MimeMultipart("mixed");
/*  344 */       mimeMessage.setContent(rootMixedMultipart);
/*  345 */       MimeMultipart nestedRelatedMultipart = new MimeMultipart("related");
/*  346 */       MimeBodyPart relatedBodyPart = new MimeBodyPart();
/*  347 */       relatedBodyPart.setContent(nestedRelatedMultipart);
/*  348 */       rootMixedMultipart.addBodyPart(relatedBodyPart);
/*  349 */       setMimeMultiparts(rootMixedMultipart, nestedRelatedMultipart);
/*  350 */       break;
/*      */     default:
/*  352 */       throw new IllegalArgumentException("Only multipart modes MIXED_RELATED, RELATED and NO supported");
/*      */     }
/*      */   }
/*      */ 
/*      */   protected final void setMimeMultiparts(MimeMultipart root, MimeMultipart main)
/*      */   {
/*  365 */     this.rootMimeMultipart = root;
/*  366 */     this.mimeMultipart = main;
/*      */   }
/*      */ 
/*      */   public final boolean isMultipart()
/*      */   {
/*  375 */     return this.rootMimeMultipart != null;
/*      */   }
/*      */ 
/*      */   private void checkMultipart()
/*      */     throws IllegalStateException
/*      */   {
/*  382 */     if (!isMultipart())
/*  383 */       throw new IllegalStateException("Not in multipart mode - create an appropriate MimeMessageHelper via a constructor that takes a 'multipart' flag if you need to set alternative texts or add inline elements or attachments.");
/*      */   }
/*      */ 
/*      */   public final MimeMultipart getRootMimeMultipart()
/*      */     throws IllegalStateException
/*      */   {
/*  400 */     checkMultipart();
/*  401 */     return this.rootMimeMultipart;
/*      */   }
/*      */ 
/*      */   public final MimeMultipart getMimeMultipart()
/*      */     throws IllegalStateException
/*      */   {
/*  415 */     checkMultipart();
/*  416 */     return this.mimeMultipart;
/*      */   }
/*      */ 
/*      */   protected String getDefaultEncoding(MimeMessage mimeMessage)
/*      */   {
/*  427 */     if ((mimeMessage instanceof SmartMimeMessage)) {
/*  428 */       return ((SmartMimeMessage)mimeMessage).getDefaultEncoding();
/*      */     }
/*  430 */     return null;
/*      */   }
/*      */ 
/*      */   public String getEncoding()
/*      */   {
/*  437 */     return this.encoding;
/*      */   }
/*      */ 
/*      */   protected FileTypeMap getDefaultFileTypeMap(MimeMessage mimeMessage)
/*      */   {
/*  448 */     if ((mimeMessage instanceof SmartMimeMessage)) {
/*  449 */       FileTypeMap fileTypeMap = ((SmartMimeMessage)mimeMessage).getDefaultFileTypeMap();
/*  450 */       if (fileTypeMap != null) {
/*  451 */         return fileTypeMap;
/*      */       }
/*      */     }
/*  454 */     ConfigurableMimeFileTypeMap fileTypeMap = new ConfigurableMimeFileTypeMap();
/*  455 */     fileTypeMap.afterPropertiesSet();
/*  456 */     return fileTypeMap;
/*      */   }
/*      */ 
/*      */   public void setFileTypeMap(FileTypeMap fileTypeMap)
/*      */   {
/*  474 */     this.fileTypeMap = (fileTypeMap != null ? fileTypeMap : getDefaultFileTypeMap(getMimeMessage()));
/*      */   }
/*      */ 
/*      */   public FileTypeMap getFileTypeMap()
/*      */   {
/*  481 */     return this.fileTypeMap;
/*      */   }
/*      */ 
/*      */   public void setValidateAddresses(boolean validateAddresses)
/*      */   {
/*  494 */     this.validateAddresses = validateAddresses;
/*      */   }
/*      */ 
/*      */   public boolean isValidateAddresses()
/*      */   {
/*  501 */     return this.validateAddresses;
/*      */   }
/*      */ 
/*      */   protected void validateAddress(InternetAddress address)
/*      */     throws AddressException
/*      */   {
/*  517 */     if (isValidateAddresses())
/*  518 */       address.validate();
/*      */   }
/*      */ 
/*      */   protected void validateAddresses(InternetAddress[] addresses)
/*      */     throws AddressException
/*      */   {
/*  530 */     for (InternetAddress address : addresses)
/*  531 */       validateAddress(address);
/*      */   }
/*      */ 
/*      */   public void setFrom(InternetAddress from)
/*      */     throws MessagingException
/*      */   {
/*  537 */     Assert.notNull(from, "From address must not be null");
/*  538 */     validateAddress(from);
/*  539 */     this.mimeMessage.setFrom(from);
/*      */   }
/*      */ 
/*      */   public void setFrom(String from) throws MessagingException {
/*  543 */     Assert.notNull(from, "From address must not be null");
/*  544 */     setFrom(parseAddress(from));
/*      */   }
/*      */ 
/*      */   public void setFrom(String from, String personal) throws MessagingException, UnsupportedEncodingException {
/*  548 */     Assert.notNull(from, "From address must not be null");
/*  549 */     setFrom(getEncoding() != null ? new InternetAddress(from, personal, getEncoding()) : new InternetAddress(from, personal));
/*      */   }
/*      */ 
/*      */   public void setReplyTo(InternetAddress replyTo) throws MessagingException
/*      */   {
/*  554 */     Assert.notNull(replyTo, "Reply-to address must not be null");
/*  555 */     validateAddress(replyTo);
/*  556 */     this.mimeMessage.setReplyTo(new InternetAddress[] { replyTo });
/*      */   }
/*      */ 
/*      */   public void setReplyTo(String replyTo) throws MessagingException {
/*  560 */     Assert.notNull(replyTo, "Reply-to address must not be null");
/*  561 */     setReplyTo(parseAddress(replyTo));
/*      */   }
/*      */ 
/*      */   public void setReplyTo(String replyTo, String personal) throws MessagingException, UnsupportedEncodingException {
/*  565 */     Assert.notNull(replyTo, "Reply-to address must not be null");
/*  566 */     InternetAddress replyToAddress = getEncoding() != null ? new InternetAddress(replyTo, personal, getEncoding()) : new InternetAddress(replyTo, personal);
/*      */ 
/*  568 */     setReplyTo(replyToAddress);
/*      */   }
/*      */ 
/*      */   public void setTo(InternetAddress to) throws MessagingException
/*      */   {
/*  573 */     Assert.notNull(to, "To address must not be null");
/*  574 */     validateAddress(to);
/*  575 */     this.mimeMessage.setRecipient(Message.RecipientType.TO, to);
/*      */   }
/*      */ 
/*      */   public void setTo(InternetAddress[] to) throws MessagingException {
/*  579 */     Assert.notNull(to, "To address array must not be null");
/*  580 */     validateAddresses(to);
/*  581 */     this.mimeMessage.setRecipients(Message.RecipientType.TO, to);
/*      */   }
/*      */ 
/*      */   public void setTo(String to) throws MessagingException {
/*  585 */     Assert.notNull(to, "To address must not be null");
/*  586 */     setTo(parseAddress(to));
/*      */   }
/*      */ 
/*      */   public void setTo(String[] to) throws MessagingException {
/*  590 */     Assert.notNull(to, "To address array must not be null");
/*  591 */     InternetAddress[] addresses = new InternetAddress[to.length];
/*  592 */     for (int i = 0; i < to.length; i++) {
/*  593 */       addresses[i] = parseAddress(to[i]);
/*      */     }
/*  595 */     setTo(addresses);
/*      */   }
/*      */ 
/*      */   public void addTo(InternetAddress to) throws MessagingException {
/*  599 */     Assert.notNull(to, "To address must not be null");
/*  600 */     validateAddress(to);
/*  601 */     this.mimeMessage.addRecipient(Message.RecipientType.TO, to);
/*      */   }
/*      */ 
/*      */   public void addTo(String to) throws MessagingException {
/*  605 */     Assert.notNull(to, "To address must not be null");
/*  606 */     addTo(parseAddress(to));
/*      */   }
/*      */ 
/*      */   public void addTo(String to, String personal) throws MessagingException, UnsupportedEncodingException {
/*  610 */     Assert.notNull(to, "To address must not be null");
/*  611 */     addTo(getEncoding() != null ? new InternetAddress(to, personal, getEncoding()) : new InternetAddress(to, personal));
/*      */   }
/*      */ 
/*      */   public void setCc(InternetAddress cc)
/*      */     throws MessagingException
/*      */   {
/*  618 */     Assert.notNull(cc, "Cc address must not be null");
/*  619 */     validateAddress(cc);
/*  620 */     this.mimeMessage.setRecipient(Message.RecipientType.CC, cc);
/*      */   }
/*      */ 
/*      */   public void setCc(InternetAddress[] cc) throws MessagingException {
/*  624 */     Assert.notNull(cc, "Cc address array must not be null");
/*  625 */     validateAddresses(cc);
/*  626 */     this.mimeMessage.setRecipients(Message.RecipientType.CC, cc);
/*      */   }
/*      */ 
/*      */   public void setCc(String cc) throws MessagingException {
/*  630 */     Assert.notNull(cc, "Cc address must not be null");
/*  631 */     setCc(parseAddress(cc));
/*      */   }
/*      */ 
/*      */   public void setCc(String[] cc) throws MessagingException {
/*  635 */     Assert.notNull(cc, "Cc address array must not be null");
/*  636 */     InternetAddress[] addresses = new InternetAddress[cc.length];
/*  637 */     for (int i = 0; i < cc.length; i++) {
/*  638 */       addresses[i] = parseAddress(cc[i]);
/*      */     }
/*  640 */     setCc(addresses);
/*      */   }
/*      */ 
/*      */   public void addCc(InternetAddress cc) throws MessagingException {
/*  644 */     Assert.notNull(cc, "Cc address must not be null");
/*  645 */     validateAddress(cc);
/*  646 */     this.mimeMessage.addRecipient(Message.RecipientType.CC, cc);
/*      */   }
/*      */ 
/*      */   public void addCc(String cc) throws MessagingException {
/*  650 */     Assert.notNull(cc, "Cc address must not be null");
/*  651 */     addCc(parseAddress(cc));
/*      */   }
/*      */ 
/*      */   public void addCc(String cc, String personal) throws MessagingException, UnsupportedEncodingException {
/*  655 */     Assert.notNull(cc, "Cc address must not be null");
/*  656 */     addCc(getEncoding() != null ? new InternetAddress(cc, personal, getEncoding()) : new InternetAddress(cc, personal));
/*      */   }
/*      */ 
/*      */   public void setBcc(InternetAddress bcc)
/*      */     throws MessagingException
/*      */   {
/*  663 */     Assert.notNull(bcc, "Bcc address must not be null");
/*  664 */     validateAddress(bcc);
/*  665 */     this.mimeMessage.setRecipient(Message.RecipientType.BCC, bcc);
/*      */   }
/*      */ 
/*      */   public void setBcc(InternetAddress[] bcc) throws MessagingException {
/*  669 */     Assert.notNull(bcc, "Bcc address array must not be null");
/*  670 */     validateAddresses(bcc);
/*  671 */     this.mimeMessage.setRecipients(Message.RecipientType.BCC, bcc);
/*      */   }
/*      */ 
/*      */   public void setBcc(String bcc) throws MessagingException {
/*  675 */     Assert.notNull(bcc, "Bcc address must not be null");
/*  676 */     setBcc(parseAddress(bcc));
/*      */   }
/*      */ 
/*      */   public void setBcc(String[] bcc) throws MessagingException {
/*  680 */     Assert.notNull(bcc, "Bcc address array must not be null");
/*  681 */     InternetAddress[] addresses = new InternetAddress[bcc.length];
/*  682 */     for (int i = 0; i < bcc.length; i++) {
/*  683 */       addresses[i] = parseAddress(bcc[i]);
/*      */     }
/*  685 */     setBcc(addresses);
/*      */   }
/*      */ 
/*      */   public void addBcc(InternetAddress bcc) throws MessagingException {
/*  689 */     Assert.notNull(bcc, "Bcc address must not be null");
/*  690 */     validateAddress(bcc);
/*  691 */     this.mimeMessage.addRecipient(Message.RecipientType.BCC, bcc);
/*      */   }
/*      */ 
/*      */   public void addBcc(String bcc) throws MessagingException {
/*  695 */     Assert.notNull(bcc, "Bcc address must not be null");
/*  696 */     addBcc(parseAddress(bcc));
/*      */   }
/*      */ 
/*      */   public void addBcc(String bcc, String personal) throws MessagingException, UnsupportedEncodingException {
/*  700 */     Assert.notNull(bcc, "Bcc address must not be null");
/*  701 */     addBcc(getEncoding() != null ? new InternetAddress(bcc, personal, getEncoding()) : new InternetAddress(bcc, personal));
/*      */   }
/*      */ 
/*      */   private InternetAddress parseAddress(String address)
/*      */     throws MessagingException
/*      */   {
/*  707 */     InternetAddress[] parsed = InternetAddress.parse(address);
/*  708 */     if (parsed.length != 1) {
/*  709 */       throw new AddressException("Illegal address", address);
/*      */     }
/*  711 */     InternetAddress raw = parsed[0];
/*      */     try {
/*  713 */       return getEncoding() != null ? new InternetAddress(raw.getAddress(), raw.getPersonal(), getEncoding()) : raw;
/*      */     }
/*      */     catch (UnsupportedEncodingException ex)
/*      */     {
/*  717 */       throw new MessagingException("Failed to parse embedded personal name to correct encoding", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setPriority(int priority)
/*      */     throws MessagingException
/*      */   {
/*  729 */     this.mimeMessage.setHeader("X-Priority", Integer.toString(priority));
/*      */   }
/*      */ 
/*      */   public void setSentDate(Date sentDate)
/*      */     throws MessagingException
/*      */   {
/*  738 */     Assert.notNull(sentDate, "Sent date must not be null");
/*  739 */     this.mimeMessage.setSentDate(sentDate);
/*      */   }
/*      */ 
/*      */   public void setSubject(String subject)
/*      */     throws MessagingException
/*      */   {
/*  748 */     Assert.notNull(subject, "Subject must not be null");
/*  749 */     if (getEncoding() != null) {
/*  750 */       this.mimeMessage.setSubject(subject, getEncoding());
/*      */     }
/*      */     else
/*  753 */       this.mimeMessage.setSubject(subject);
/*      */   }
/*      */ 
/*      */   public void setText(String text)
/*      */     throws MessagingException
/*      */   {
/*  768 */     setText(text, false);
/*      */   }
/*      */ 
/*      */   public void setText(String text, boolean html)
/*      */     throws MessagingException
/*      */   {
/*  783 */     Assert.notNull(text, "Text must not be null");
/*      */     MimePart partToUse;
/*      */     MimePart partToUse;
/*  785 */     if (isMultipart()) {
/*  786 */       partToUse = getMainPart();
/*      */     }
/*      */     else {
/*  789 */       partToUse = this.mimeMessage;
/*      */     }
/*  791 */     if (html) {
/*  792 */       setHtmlTextToMimePart(partToUse, text);
/*      */     }
/*      */     else
/*  795 */       setPlainTextToMimePart(partToUse, text);
/*      */   }
/*      */ 
/*      */   public void setText(String plainText, String htmlText)
/*      */     throws MessagingException
/*      */   {
/*  809 */     Assert.notNull(plainText, "Plain text must not be null");
/*  810 */     Assert.notNull(htmlText, "HTML text must not be null");
/*      */ 
/*  812 */     MimeMultipart messageBody = new MimeMultipart("alternative");
/*  813 */     getMainPart().setContent(messageBody, "text/alternative");
/*      */ 
/*  816 */     MimeBodyPart plainTextPart = new MimeBodyPart();
/*  817 */     setPlainTextToMimePart(plainTextPart, plainText);
/*  818 */     messageBody.addBodyPart(plainTextPart);
/*      */ 
/*  821 */     MimeBodyPart htmlTextPart = new MimeBodyPart();
/*  822 */     setHtmlTextToMimePart(htmlTextPart, htmlText);
/*  823 */     messageBody.addBodyPart(htmlTextPart);
/*      */   }
/*      */ 
/*      */   private MimeBodyPart getMainPart() throws MessagingException {
/*  827 */     MimeMultipart mimeMultipart = getMimeMultipart();
/*  828 */     MimeBodyPart bodyPart = null;
/*  829 */     for (int i = 0; i < mimeMultipart.getCount(); i++) {
/*  830 */       BodyPart bp = mimeMultipart.getBodyPart(i);
/*  831 */       if (bp.getFileName() == null) {
/*  832 */         bodyPart = (MimeBodyPart)bp;
/*      */       }
/*      */     }
/*  835 */     if (bodyPart == null) {
/*  836 */       MimeBodyPart mimeBodyPart = new MimeBodyPart();
/*  837 */       mimeMultipart.addBodyPart(mimeBodyPart);
/*  838 */       bodyPart = mimeBodyPart;
/*      */     }
/*  840 */     return bodyPart;
/*      */   }
/*      */ 
/*      */   private void setPlainTextToMimePart(MimePart mimePart, String text) throws MessagingException {
/*  844 */     if (getEncoding() != null) {
/*  845 */       mimePart.setText(text, getEncoding());
/*      */     }
/*      */     else
/*  848 */       mimePart.setText(text);
/*      */   }
/*      */ 
/*      */   private void setHtmlTextToMimePart(MimePart mimePart, String text) throws MessagingException
/*      */   {
/*  853 */     if (getEncoding() != null) {
/*  854 */       mimePart.setContent(text, "text/html;charset=" + getEncoding());
/*      */     }
/*      */     else
/*  857 */       mimePart.setContent(text, "text/html");
/*      */   }
/*      */ 
/*      */   public void addInline(String contentId, DataSource dataSource)
/*      */     throws MessagingException
/*      */   {
/*  880 */     Assert.notNull(contentId, "Content ID must not be null");
/*  881 */     Assert.notNull(dataSource, "DataSource must not be null");
/*  882 */     MimeBodyPart mimeBodyPart = new MimeBodyPart();
/*  883 */     mimeBodyPart.setDisposition("inline");
/*      */ 
/*  886 */     mimeBodyPart.setHeader("Content-ID", "<" + contentId + ">");
/*  887 */     mimeBodyPart.setDataHandler(new DataHandler(dataSource));
/*  888 */     getMimeMultipart().addBodyPart(mimeBodyPart);
/*      */   }
/*      */ 
/*      */   public void addInline(String contentId, File file)
/*      */     throws MessagingException
/*      */   {
/*  909 */     Assert.notNull(file, "File must not be null");
/*  910 */     FileDataSource dataSource = new FileDataSource(file);
/*  911 */     dataSource.setFileTypeMap(getFileTypeMap());
/*  912 */     addInline(contentId, dataSource);
/*      */   }
/*      */ 
/*      */   public void addInline(String contentId, Resource resource)
/*      */     throws MessagingException
/*      */   {
/*  936 */     Assert.notNull(resource, "Resource must not be null");
/*  937 */     String contentType = getFileTypeMap().getContentType(resource.getFilename());
/*  938 */     addInline(contentId, resource, contentType);
/*      */   }
/*      */ 
/*      */   public void addInline(String contentId, InputStreamSource inputStreamSource, String contentType)
/*      */     throws MessagingException
/*      */   {
/*  966 */     Assert.notNull(inputStreamSource, "InputStreamSource must not be null");
/*  967 */     if (((inputStreamSource instanceof Resource)) && (((Resource)inputStreamSource).isOpen())) {
/*  968 */       throw new IllegalArgumentException("Passed-in Resource contains an open stream: invalid argument. JavaMail requires an InputStreamSource that creates a fresh stream for every call.");
/*      */     }
/*      */ 
/*  972 */     DataSource dataSource = createDataSource(inputStreamSource, contentType, "inline");
/*  973 */     addInline(contentId, dataSource);
/*      */   }
/*      */ 
/*      */   public void addAttachment(String attachmentFilename, DataSource dataSource)
/*      */     throws MessagingException
/*      */   {
/*  991 */     Assert.notNull(attachmentFilename, "Attachment filename must not be null");
/*  992 */     Assert.notNull(dataSource, "DataSource must not be null");
/*      */     try {
/*  994 */       MimeBodyPart mimeBodyPart = new MimeBodyPart();
/*  995 */       mimeBodyPart.setDisposition("attachment");
/*  996 */       mimeBodyPart.setFileName(MimeUtility.encodeText(attachmentFilename));
/*  997 */       mimeBodyPart.setDataHandler(new DataHandler(dataSource));
/*  998 */       getRootMimeMultipart().addBodyPart(mimeBodyPart);
/*      */     }
/*      */     catch (UnsupportedEncodingException ex) {
/* 1001 */       throw new MessagingException("Failed to encode attachment filename", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void addAttachment(String attachmentFilename, File file)
/*      */     throws MessagingException
/*      */   {
/* 1019 */     Assert.notNull(file, "File must not be null");
/* 1020 */     FileDataSource dataSource = new FileDataSource(file);
/* 1021 */     dataSource.setFileTypeMap(getFileTypeMap());
/* 1022 */     addAttachment(attachmentFilename, dataSource);
/*      */   }
/*      */ 
/*      */   public void addAttachment(String attachmentFilename, InputStreamSource inputStreamSource)
/*      */     throws MessagingException
/*      */   {
/* 1046 */     String contentType = getFileTypeMap().getContentType(attachmentFilename);
/* 1047 */     addAttachment(attachmentFilename, inputStreamSource, contentType);
/*      */   }
/*      */ 
/*      */   public void addAttachment(String attachmentFilename, InputStreamSource inputStreamSource, String contentType)
/*      */     throws MessagingException
/*      */   {
/* 1070 */     Assert.notNull(inputStreamSource, "InputStreamSource must not be null");
/* 1071 */     if (((inputStreamSource instanceof Resource)) && (((Resource)inputStreamSource).isOpen())) {
/* 1072 */       throw new IllegalArgumentException("Passed-in Resource contains an open stream: invalid argument. JavaMail requires an InputStreamSource that creates a fresh stream for every call.");
/*      */     }
/*      */ 
/* 1076 */     DataSource dataSource = createDataSource(inputStreamSource, contentType, attachmentFilename);
/* 1077 */     addAttachment(attachmentFilename, dataSource);
/*      */   }
/*      */ 
/*      */   protected DataSource createDataSource(final InputStreamSource inputStreamSource, final String contentType, final String name)
/*      */   {
/* 1090 */     return new DataSource() {
/*      */       public InputStream getInputStream() throws IOException {
/* 1092 */         return inputStreamSource.getInputStream();
/*      */       }
/*      */       public OutputStream getOutputStream() {
/* 1095 */         throw new UnsupportedOperationException("Read-only javax.activation.DataSource");
/*      */       }
/*      */       public String getContentType() {
/* 1098 */         return contentType;
/*      */       }
/*      */       public String getName() {
/* 1101 */         return name;
/*      */       }
/*      */     };
/*      */   }
/*      */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.mail.javamail.MimeMessageHelper
 * JD-Core Version:    0.6.1
 */