/*     */ package org.springframework.mail.javamail;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import javax.activation.FileTypeMap;
/*     */ import javax.mail.AuthenticationFailedException;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.NoSuchProviderException;
/*     */ import javax.mail.Session;
/*     */ import javax.mail.Transport;
/*     */ import javax.mail.internet.MimeMessage;
/*     */ import org.springframework.mail.MailAuthenticationException;
/*     */ import org.springframework.mail.MailException;
/*     */ import org.springframework.mail.MailParseException;
/*     */ import org.springframework.mail.MailPreparationException;
/*     */ import org.springframework.mail.MailSendException;
/*     */ import org.springframework.mail.SimpleMailMessage;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class JavaMailSenderImpl
/*     */   implements JavaMailSender
/*     */ {
/*     */   public static final String DEFAULT_PROTOCOL = "smtp";
/*     */   public static final int DEFAULT_PORT = -1;
/*     */   private static final String HEADER_MESSAGE_ID = "Message-ID";
/*  80 */   private Properties javaMailProperties = new Properties();
/*     */   private Session session;
/*     */   private String protocol;
/*     */   private String host;
/*  88 */   private int port = -1;
/*     */   private String username;
/*     */   private String password;
/*     */   private String defaultEncoding;
/*     */   private FileTypeMap defaultFileTypeMap;
/*     */ 
/*     */   public JavaMailSenderImpl()
/*     */   {
/* 105 */     ConfigurableMimeFileTypeMap fileTypeMap = new ConfigurableMimeFileTypeMap();
/* 106 */     fileTypeMap.afterPropertiesSet();
/* 107 */     this.defaultFileTypeMap = fileTypeMap;
/*     */   }
/*     */ 
/*     */   public void setJavaMailProperties(Properties javaMailProperties)
/*     */   {
/* 119 */     this.javaMailProperties = javaMailProperties;
/* 120 */     synchronized (this) {
/* 121 */       this.session = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Properties getJavaMailProperties()
/*     */   {
/* 132 */     return this.javaMailProperties;
/*     */   }
/*     */ 
/*     */   public synchronized void setSession(Session session)
/*     */   {
/* 144 */     Assert.notNull(session, "Session must not be null");
/* 145 */     this.session = session;
/*     */   }
/*     */ 
/*     */   public synchronized Session getSession()
/*     */   {
/* 153 */     if (this.session == null) {
/* 154 */       this.session = Session.getInstance(this.javaMailProperties);
/*     */     }
/* 156 */     return this.session;
/*     */   }
/*     */ 
/*     */   public void setProtocol(String protocol)
/*     */   {
/* 163 */     this.protocol = protocol;
/*     */   }
/*     */ 
/*     */   public String getProtocol()
/*     */   {
/* 170 */     return this.protocol;
/*     */   }
/*     */ 
/*     */   public void setHost(String host)
/*     */   {
/* 178 */     this.host = host;
/*     */   }
/*     */ 
/*     */   public String getHost()
/*     */   {
/* 185 */     return this.host;
/*     */   }
/*     */ 
/*     */   public void setPort(int port)
/*     */   {
/* 194 */     this.port = port;
/*     */   }
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 201 */     return this.port;
/*     */   }
/*     */ 
/*     */   public void setUsername(String username)
/*     */   {
/* 216 */     this.username = username;
/*     */   }
/*     */ 
/*     */   public String getUsername()
/*     */   {
/* 223 */     return this.username;
/*     */   }
/*     */ 
/*     */   public void setPassword(String password)
/*     */   {
/* 238 */     this.password = password;
/*     */   }
/*     */ 
/*     */   public String getPassword()
/*     */   {
/* 245 */     return this.password;
/*     */   }
/*     */ 
/*     */   public void setDefaultEncoding(String defaultEncoding)
/*     */   {
/* 254 */     this.defaultEncoding = defaultEncoding;
/*     */   }
/*     */ 
/*     */   public String getDefaultEncoding()
/*     */   {
/* 262 */     return this.defaultEncoding;
/*     */   }
/*     */ 
/*     */   public void setDefaultFileTypeMap(FileTypeMap defaultFileTypeMap)
/*     */   {
/* 279 */     this.defaultFileTypeMap = defaultFileTypeMap;
/*     */   }
/*     */ 
/*     */   public FileTypeMap getDefaultFileTypeMap()
/*     */   {
/* 287 */     return this.defaultFileTypeMap;
/*     */   }
/*     */ 
/*     */   public void send(SimpleMailMessage simpleMessage)
/*     */     throws MailException
/*     */   {
/* 296 */     send(new SimpleMailMessage[] { simpleMessage });
/*     */   }
/*     */ 
/*     */   public void send(SimpleMailMessage[] simpleMessages) throws MailException {
/* 300 */     List mimeMessages = new ArrayList(simpleMessages.length);
/* 301 */     for (SimpleMailMessage simpleMessage : simpleMessages) {
/* 302 */       MimeMailMessage message = new MimeMailMessage(createMimeMessage());
/* 303 */       simpleMessage.copyTo(message);
/* 304 */       mimeMessages.add(message.getMimeMessage());
/*     */     }
/* 306 */     doSend((MimeMessage[])mimeMessages.toArray(new MimeMessage[mimeMessages.size()]), simpleMessages);
/*     */   }
/*     */ 
/*     */   public MimeMessage createMimeMessage()
/*     */   {
/* 323 */     return new SmartMimeMessage(getSession(), getDefaultEncoding(), getDefaultFileTypeMap());
/*     */   }
/*     */ 
/*     */   public MimeMessage createMimeMessage(InputStream contentStream) throws MailException {
/*     */     try {
/* 328 */       return new MimeMessage(getSession(), contentStream);
/*     */     }
/*     */     catch (MessagingException ex) {
/* 331 */       throw new MailParseException("Could not parse raw MIME content", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void send(MimeMessage mimeMessage) throws MailException {
/* 336 */     send(new MimeMessage[] { mimeMessage });
/*     */   }
/*     */ 
/*     */   public void send(MimeMessage[] mimeMessages) throws MailException {
/* 340 */     doSend(mimeMessages, null);
/*     */   }
/*     */ 
/*     */   public void send(MimeMessagePreparator mimeMessagePreparator) throws MailException {
/* 344 */     send(new MimeMessagePreparator[] { mimeMessagePreparator });
/*     */   }
/*     */ 
/*     */   public void send(MimeMessagePreparator[] mimeMessagePreparators) throws MailException {
/*     */     try {
/* 349 */       List mimeMessages = new ArrayList(mimeMessagePreparators.length);
/* 350 */       for (MimeMessagePreparator preparator : mimeMessagePreparators) {
/* 351 */         MimeMessage mimeMessage = createMimeMessage();
/* 352 */         preparator.prepare(mimeMessage);
/* 353 */         mimeMessages.add(mimeMessage);
/*     */       }
/* 355 */       send((MimeMessage[])mimeMessages.toArray(new MimeMessage[mimeMessages.size()]));
/*     */     }
/*     */     catch (MailException ex) {
/* 358 */       throw ex;
/*     */     }
/*     */     catch (MessagingException ex) {
/* 361 */       throw new MailParseException(ex);
/*     */     }
/*     */     catch (IOException ex) {
/* 364 */       throw new MailPreparationException(ex);
/*     */     }
/*     */     catch (Exception ex) {
/* 367 */       throw new MailPreparationException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void doSend(MimeMessage[] mimeMessages, Object[] originalMessages)
/*     */     throws MailException
/*     */   {
/* 384 */     Map failedMessages = new LinkedHashMap();
/*     */     Transport transport;
/*     */     try
/*     */     {
/* 388 */       transport = getTransport(getSession());
/* 389 */       transport.connect(getHost(), getPort(), getUsername(), getPassword());
/*     */     }
/*     */     catch (AuthenticationFailedException ex) {
/* 392 */       throw new MailAuthenticationException(ex);
/*     */     }
/*     */     catch (MessagingException ex)
/*     */     {
/* 396 */       for (int i = 0; i < mimeMessages.length; i++) {
/* 397 */         Object original = originalMessages != null ? originalMessages[i] : mimeMessages[i];
/* 398 */         failedMessages.put(original, ex);
/*     */       }
/* 400 */       throw new MailSendException("Mail server connection failed", ex, failedMessages);
/*     */     }
/*     */     try
/*     */     {
/* 404 */       for (int i = 0; i < mimeMessages.length; i++) {
/* 405 */         MimeMessage mimeMessage = mimeMessages[i];
/*     */         try {
/* 407 */           if (mimeMessage.getSentDate() == null) {
/* 408 */             mimeMessage.setSentDate(new Date());
/*     */           }
/* 410 */           String messageId = mimeMessage.getMessageID();
/* 411 */           mimeMessage.saveChanges();
/* 412 */           if (messageId != null)
/*     */           {
/* 414 */             mimeMessage.setHeader("Message-ID", messageId);
/*     */           }
/* 416 */           transport.sendMessage(mimeMessage, mimeMessage.getAllRecipients());
/*     */         }
/*     */         catch (MessagingException ex) {
/* 419 */           Object original = originalMessages != null ? originalMessages[i] : mimeMessage;
/* 420 */           failedMessages.put(original, ex);
/*     */         }
/*     */       }
/*     */     }
/*     */     finally {
/*     */       try {
/* 426 */         transport.close();
/*     */       }
/*     */       catch (MessagingException ex) {
/* 429 */         if (!failedMessages.isEmpty()) {
/* 430 */           throw new MailSendException("Failed to close server connection after message failures", ex, failedMessages);
/*     */         }
/*     */ 
/* 434 */         throw new MailSendException("Failed to close server connection after message sending", ex);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 439 */     if (!failedMessages.isEmpty())
/* 440 */       throw new MailSendException(failedMessages);
/*     */   }
/*     */ 
/*     */   protected Transport getTransport(Session session)
/*     */     throws NoSuchProviderException
/*     */   {
/* 452 */     String protocol = getProtocol();
/* 453 */     if (protocol == null) {
/* 454 */       protocol = session.getProperty("mail.transport.protocol");
/* 455 */       if (protocol == null) {
/* 456 */         protocol = "smtp";
/*     */       }
/*     */     }
/* 459 */     return session.getTransport(protocol);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.mail.javamail.JavaMailSenderImpl
 * JD-Core Version:    0.6.1
 */