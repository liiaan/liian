package org.springframework.mail;

public abstract interface MailSender
{
  public abstract void send(SimpleMailMessage paramSimpleMailMessage)
    throws MailException;

  public abstract void send(SimpleMailMessage[] paramArrayOfSimpleMailMessage)
    throws MailException;
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.mail.MailSender
 * JD-Core Version:    0.6.1
 */