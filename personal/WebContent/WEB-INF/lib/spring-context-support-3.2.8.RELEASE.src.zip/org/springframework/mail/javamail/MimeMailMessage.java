/*     */ package org.springframework.mail.javamail;
/*     */ 
/*     */ import java.util.Date;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.internet.MimeMessage;
/*     */ import org.springframework.mail.MailMessage;
/*     */ import org.springframework.mail.MailParseException;
/*     */ 
/*     */ public class MimeMailMessage
/*     */   implements MailMessage
/*     */ {
/*     */   private final MimeMessageHelper helper;
/*     */ 
/*     */   public MimeMailMessage(MimeMessageHelper mimeMessageHelper)
/*     */   {
/*  50 */     this.helper = mimeMessageHelper;
/*     */   }
/*     */ 
/*     */   public MimeMailMessage(MimeMessage mimeMessage)
/*     */   {
/*  58 */     this.helper = new MimeMessageHelper(mimeMessage);
/*     */   }
/*     */ 
/*     */   public final MimeMessageHelper getMimeMessageHelper()
/*     */   {
/*  65 */     return this.helper;
/*     */   }
/*     */ 
/*     */   public final MimeMessage getMimeMessage()
/*     */   {
/*  72 */     return this.helper.getMimeMessage();
/*     */   }
/*     */ 
/*     */   public void setFrom(String from) throws MailParseException
/*     */   {
/*     */     try {
/*  78 */       this.helper.setFrom(from);
/*     */     }
/*     */     catch (MessagingException ex) {
/*  81 */       throw new MailParseException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setReplyTo(String replyTo) throws MailParseException {
/*     */     try {
/*  87 */       this.helper.setReplyTo(replyTo);
/*     */     }
/*     */     catch (MessagingException ex) {
/*  90 */       throw new MailParseException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setTo(String to) throws MailParseException {
/*     */     try {
/*  96 */       this.helper.setTo(to);
/*     */     }
/*     */     catch (MessagingException ex) {
/*  99 */       throw new MailParseException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setTo(String[] to) throws MailParseException {
/*     */     try {
/* 105 */       this.helper.setTo(to);
/*     */     }
/*     */     catch (MessagingException ex) {
/* 108 */       throw new MailParseException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setCc(String cc) throws MailParseException {
/*     */     try {
/* 114 */       this.helper.setCc(cc);
/*     */     }
/*     */     catch (MessagingException ex) {
/* 117 */       throw new MailParseException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setCc(String[] cc) throws MailParseException {
/*     */     try {
/* 123 */       this.helper.setCc(cc);
/*     */     }
/*     */     catch (MessagingException ex) {
/* 126 */       throw new MailParseException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setBcc(String bcc) throws MailParseException {
/*     */     try {
/* 132 */       this.helper.setBcc(bcc);
/*     */     }
/*     */     catch (MessagingException ex) {
/* 135 */       throw new MailParseException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setBcc(String[] bcc) throws MailParseException {
/*     */     try {
/* 141 */       this.helper.setBcc(bcc);
/*     */     }
/*     */     catch (MessagingException ex) {
/* 144 */       throw new MailParseException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setSentDate(Date sentDate) throws MailParseException {
/*     */     try {
/* 150 */       this.helper.setSentDate(sentDate);
/*     */     }
/*     */     catch (MessagingException ex) {
/* 153 */       throw new MailParseException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setSubject(String subject) throws MailParseException {
/*     */     try {
/* 159 */       this.helper.setSubject(subject);
/*     */     }
/*     */     catch (MessagingException ex) {
/* 162 */       throw new MailParseException(ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setText(String text) throws MailParseException {
/*     */     try {
/* 168 */       this.helper.setText(text);
/*     */     }
/*     */     catch (MessagingException ex) {
/* 171 */       throw new MailParseException(ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.mail.javamail.MimeMailMessage
 * JD-Core Version:    0.6.1
 */