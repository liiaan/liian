/*    */ package org.springframework.mail.javamail;
/*    */ 
/*    */ import java.beans.PropertyEditorSupport;
/*    */ import javax.mail.internet.AddressException;
/*    */ import javax.mail.internet.InternetAddress;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ public class InternetAddressEditor extends PropertyEditorSupport
/*    */ {
/*    */   public void setAsText(String text)
/*    */     throws IllegalArgumentException
/*    */   {
/* 41 */     if (StringUtils.hasText(text)) {
/*    */       try {
/* 43 */         setValue(new InternetAddress(text));
/*    */       }
/*    */       catch (AddressException ex) {
/* 46 */         throw new IllegalArgumentException("Could not parse mail address: " + ex.getMessage());
/*    */       }
/*    */     }
/*    */     else
/* 50 */       setValue(null);
/*    */   }
/*    */ 
/*    */   public String getAsText()
/*    */   {
/* 56 */     InternetAddress value = (InternetAddress)getValue();
/* 57 */     return value != null ? value.toUnicodeString() : "";
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.mail.javamail.InternetAddressEditor
 * JD-Core Version:    0.6.1
 */