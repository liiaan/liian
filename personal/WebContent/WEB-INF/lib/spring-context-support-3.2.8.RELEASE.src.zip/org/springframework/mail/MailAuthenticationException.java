/*    */ package org.springframework.mail;
/*    */ 
/*    */ public class MailAuthenticationException extends MailException
/*    */ {
/*    */   public MailAuthenticationException(String msg)
/*    */   {
/* 33 */     super(msg);
/*    */   }
/*    */ 
/*    */   public MailAuthenticationException(String msg, Throwable cause)
/*    */   {
/* 42 */     super(msg, cause);
/*    */   }
/*    */ 
/*    */   public MailAuthenticationException(Throwable cause)
/*    */   {
/* 50 */     super("Authentication failed", cause);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.mail.MailAuthenticationException
 * JD-Core Version:    0.6.1
 */