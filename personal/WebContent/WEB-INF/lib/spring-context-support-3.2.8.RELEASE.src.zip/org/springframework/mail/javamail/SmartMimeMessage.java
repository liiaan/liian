/*    */ package org.springframework.mail.javamail;
/*    */ 
/*    */ import javax.activation.FileTypeMap;
/*    */ import javax.mail.Session;
/*    */ import javax.mail.internet.MimeMessage;
/*    */ 
/*    */ class SmartMimeMessage extends MimeMessage
/*    */ {
/*    */   private final String defaultEncoding;
/*    */   private final FileTypeMap defaultFileTypeMap;
/*    */ 
/*    */   public SmartMimeMessage(Session session, String defaultEncoding, FileTypeMap defaultFileTypeMap)
/*    */   {
/* 52 */     super(session);
/* 53 */     this.defaultEncoding = defaultEncoding;
/* 54 */     this.defaultFileTypeMap = defaultFileTypeMap;
/*    */   }
/*    */ 
/*    */   public final String getDefaultEncoding()
/*    */   {
/* 62 */     return this.defaultEncoding;
/*    */   }
/*    */ 
/*    */   public final FileTypeMap getDefaultFileTypeMap()
/*    */   {
/* 69 */     return this.defaultFileTypeMap;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.mail.javamail.SmartMimeMessage
 * JD-Core Version:    0.6.1
 */