/*    */ package org.springframework.mail;
/*    */ 
/*    */ public class MailParseException extends MailException
/*    */ {
/*    */   public MailParseException(String msg)
/*    */   {
/* 33 */     super(msg);
/*    */   }
/*    */ 
/*    */   public MailParseException(String msg, Throwable cause)
/*    */   {
/* 42 */     super(msg, cause);
/*    */   }
/*    */ 
/*    */   public MailParseException(Throwable cause)
/*    */   {
/* 50 */     super("Could not parse mail", cause);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.mail.MailParseException
 * JD-Core Version:    0.6.1
 */