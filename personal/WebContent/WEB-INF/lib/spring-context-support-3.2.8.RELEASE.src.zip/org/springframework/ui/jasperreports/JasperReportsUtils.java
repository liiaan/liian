/*     */ package org.springframework.ui.jasperreports;
/*     */ 
/*     */ import java.io.OutputStream;
/*     */ import java.io.Writer;
/*     */ import java.util.Collection;
/*     */ import java.util.Map;
/*     */ import net.sf.jasperreports.engine.JRDataSource;
/*     */ import net.sf.jasperreports.engine.JRException;
/*     */ import net.sf.jasperreports.engine.JRExporter;
/*     */ import net.sf.jasperreports.engine.JRExporterParameter;
/*     */ import net.sf.jasperreports.engine.JasperFillManager;
/*     */ import net.sf.jasperreports.engine.JasperPrint;
/*     */ import net.sf.jasperreports.engine.JasperReport;
/*     */ import net.sf.jasperreports.engine.data.JRBeanArrayDataSource;
/*     */ import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
/*     */ import net.sf.jasperreports.engine.export.JRCsvExporter;
/*     */ import net.sf.jasperreports.engine.export.JRHtmlExporter;
/*     */ import net.sf.jasperreports.engine.export.JRPdfExporter;
/*     */ import net.sf.jasperreports.engine.export.JRXlsExporter;
/*     */ 
/*     */ public abstract class JasperReportsUtils
/*     */ {
/*     */   public static JRDataSource convertReportData(Object value)
/*     */     throws IllegalArgumentException
/*     */   {
/*  62 */     if ((value instanceof JRDataSource)) {
/*  63 */       return (JRDataSource)value;
/*     */     }
/*  65 */     if ((value instanceof Collection)) {
/*  66 */       return new JRBeanCollectionDataSource((Collection)value);
/*     */     }
/*  68 */     if ((value instanceof Object[])) {
/*  69 */       return new JRBeanArrayDataSource((Object[])value);
/*     */     }
/*     */ 
/*  72 */     throw new IllegalArgumentException("Value [" + value + "] cannot be converted to a JRDataSource");
/*     */   }
/*     */ 
/*     */   public static void render(JRExporter exporter, JasperPrint print, Writer writer)
/*     */     throws JRException
/*     */   {
/*  90 */     exporter.setParameter(JRExporterParameter.JASPER_PRINT, print);
/*  91 */     exporter.setParameter(JRExporterParameter.OUTPUT_WRITER, writer);
/*  92 */     exporter.exportReport();
/*     */   }
/*     */ 
/*     */   public static void render(JRExporter exporter, JasperPrint print, OutputStream outputStream)
/*     */     throws JRException
/*     */   {
/* 109 */     exporter.setParameter(JRExporterParameter.JASPER_PRINT, print);
/* 110 */     exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, outputStream);
/* 111 */     exporter.exportReport();
/*     */   }
/*     */ 
/*     */   public static void renderAsCsv(JasperReport report, Map<String, Object> parameters, Object reportData, Writer writer)
/*     */     throws JRException
/*     */   {
/* 128 */     JasperPrint print = JasperFillManager.fillReport(report, parameters, convertReportData(reportData));
/* 129 */     render(new JRCsvExporter(), print, writer);
/*     */   }
/*     */ 
/*     */   public static void renderAsCsv(JasperReport report, Map<String, Object> parameters, Object reportData, Writer writer, Map<JRExporterParameter, Object> exporterParameters)
/*     */     throws JRException
/*     */   {
/* 147 */     JasperPrint print = JasperFillManager.fillReport(report, parameters, convertReportData(reportData));
/* 148 */     JRCsvExporter exporter = new JRCsvExporter();
/* 149 */     exporter.setParameters(exporterParameters);
/* 150 */     render(exporter, print, writer);
/*     */   }
/*     */ 
/*     */   public static void renderAsHtml(JasperReport report, Map<String, Object> parameters, Object reportData, Writer writer)
/*     */     throws JRException
/*     */   {
/* 167 */     JasperPrint print = JasperFillManager.fillReport(report, parameters, convertReportData(reportData));
/* 168 */     render(new JRHtmlExporter(), print, writer);
/*     */   }
/*     */ 
/*     */   public static void renderAsHtml(JasperReport report, Map<String, Object> parameters, Object reportData, Writer writer, Map<JRExporterParameter, Object> exporterParameters)
/*     */     throws JRException
/*     */   {
/* 186 */     JasperPrint print = JasperFillManager.fillReport(report, parameters, convertReportData(reportData));
/* 187 */     JRHtmlExporter exporter = new JRHtmlExporter();
/* 188 */     exporter.setParameters(exporterParameters);
/* 189 */     render(exporter, print, writer);
/*     */   }
/*     */ 
/*     */   public static void renderAsPdf(JasperReport report, Map<String, Object> parameters, Object reportData, OutputStream stream)
/*     */     throws JRException
/*     */   {
/* 206 */     JasperPrint print = JasperFillManager.fillReport(report, parameters, convertReportData(reportData));
/* 207 */     render(new JRPdfExporter(), print, stream);
/*     */   }
/*     */ 
/*     */   public static void renderAsPdf(JasperReport report, Map<String, Object> parameters, Object reportData, OutputStream stream, Map<JRExporterParameter, Object> exporterParameters)
/*     */     throws JRException
/*     */   {
/* 225 */     JasperPrint print = JasperFillManager.fillReport(report, parameters, convertReportData(reportData));
/* 226 */     JRPdfExporter exporter = new JRPdfExporter();
/* 227 */     exporter.setParameters(exporterParameters);
/* 228 */     render(exporter, print, stream);
/*     */   }
/*     */ 
/*     */   public static void renderAsXls(JasperReport report, Map<String, Object> parameters, Object reportData, OutputStream stream)
/*     */     throws JRException
/*     */   {
/* 245 */     JasperPrint print = JasperFillManager.fillReport(report, parameters, convertReportData(reportData));
/* 246 */     render(new JRXlsExporter(), print, stream);
/*     */   }
/*     */ 
/*     */   public static void renderAsXls(JasperReport report, Map<String, Object> parameters, Object reportData, OutputStream stream, Map<JRExporterParameter, Object> exporterParameters)
/*     */     throws JRException
/*     */   {
/* 264 */     JasperPrint print = JasperFillManager.fillReport(report, parameters, convertReportData(reportData));
/* 265 */     JRXlsExporter exporter = new JRXlsExporter();
/* 266 */     exporter.setParameters(exporterParameters);
/* 267 */     render(exporter, print, stream);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.ui.jasperreports.JasperReportsUtils
 * JD-Core Version:    0.6.1
 */