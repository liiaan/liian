/*     */ package org.springframework.ui.freemarker;
/*     */ 
/*     */ import freemarker.cache.FileTemplateLoader;
/*     */ import freemarker.cache.MultiTemplateLoader;
/*     */ import freemarker.cache.TemplateLoader;
/*     */ import freemarker.template.Configuration;
/*     */ import freemarker.template.SimpleHash;
/*     */ import freemarker.template.TemplateException;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.PropertiesLoaderUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ public class FreeMarkerConfigurationFactory
/*     */ {
/*  78 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private Resource configLocation;
/*     */   private Properties freemarkerSettings;
/*     */   private Map<String, Object> freemarkerVariables;
/*     */   private String defaultEncoding;
/*  88 */   private final List<TemplateLoader> templateLoaders = new ArrayList();
/*     */   private List<TemplateLoader> preTemplateLoaders;
/*     */   private List<TemplateLoader> postTemplateLoaders;
/*     */   private String[] templateLoaderPaths;
/*  96 */   private ResourceLoader resourceLoader = new DefaultResourceLoader();
/*     */ 
/*  98 */   private boolean preferFileSystemAccess = true;
/*     */ 
/*     */   public void setConfigLocation(Resource resource)
/*     */   {
/* 108 */     this.configLocation = resource;
/*     */   }
/*     */ 
/*     */   public void setFreemarkerSettings(Properties settings)
/*     */   {
/* 117 */     this.freemarkerSettings = settings;
/*     */   }
/*     */ 
/*     */   public void setFreemarkerVariables(Map<String, Object> variables)
/*     */   {
/* 126 */     this.freemarkerVariables = variables;
/*     */   }
/*     */ 
/*     */   public void setDefaultEncoding(String defaultEncoding)
/*     */   {
/* 138 */     this.defaultEncoding = defaultEncoding;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setTemplateLoaders(TemplateLoader[] templateLoaders)
/*     */   {
/* 152 */     if (templateLoaders != null)
/* 153 */       this.templateLoaders.addAll(Arrays.asList(templateLoaders));
/*     */   }
/*     */ 
/*     */   public void setPreTemplateLoaders(TemplateLoader[] preTemplateLoaders)
/*     */   {
/* 169 */     this.preTemplateLoaders = Arrays.asList(preTemplateLoaders);
/*     */   }
/*     */ 
/*     */   public void setPostTemplateLoaders(TemplateLoader[] postTemplateLoaders)
/*     */   {
/* 184 */     this.postTemplateLoaders = Arrays.asList(postTemplateLoaders);
/*     */   }
/*     */ 
/*     */   public void setTemplateLoaderPath(String templateLoaderPath)
/*     */   {
/* 193 */     this.templateLoaderPaths = new String[] { templateLoaderPath };
/*     */   }
/*     */ 
/*     */   public void setTemplateLoaderPaths(String[] templateLoaderPaths)
/*     */   {
/* 216 */     this.templateLoaderPaths = templateLoaderPaths;
/*     */   }
/*     */ 
/*     */   public void setResourceLoader(ResourceLoader resourceLoader)
/*     */   {
/* 226 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */   protected ResourceLoader getResourceLoader()
/*     */   {
/* 233 */     return this.resourceLoader;
/*     */   }
/*     */ 
/*     */   public void setPreferFileSystemAccess(boolean preferFileSystemAccess)
/*     */   {
/* 249 */     this.preferFileSystemAccess = preferFileSystemAccess;
/*     */   }
/*     */ 
/*     */   protected boolean isPreferFileSystemAccess()
/*     */   {
/* 256 */     return this.preferFileSystemAccess;
/*     */   }
/*     */ 
/*     */   public Configuration createConfiguration()
/*     */     throws IOException, TemplateException
/*     */   {
/* 267 */     Configuration config = newConfiguration();
/* 268 */     Properties props = new Properties();
/*     */ 
/* 271 */     if (this.configLocation != null) {
/* 272 */       if (this.logger.isInfoEnabled()) {
/* 273 */         this.logger.info("Loading FreeMarker configuration from " + this.configLocation);
/*     */       }
/* 275 */       PropertiesLoaderUtils.fillProperties(props, this.configLocation);
/*     */     }
/*     */ 
/* 279 */     if (this.freemarkerSettings != null) {
/* 280 */       props.putAll(this.freemarkerSettings);
/*     */     }
/*     */ 
/* 285 */     if (!props.isEmpty()) {
/* 286 */       config.setSettings(props);
/*     */     }
/*     */ 
/* 289 */     if (!CollectionUtils.isEmpty(this.freemarkerVariables)) {
/* 290 */       config.setAllSharedVariables(new SimpleHash(this.freemarkerVariables, config.getObjectWrapper()));
/*     */     }
/*     */ 
/* 293 */     if (this.defaultEncoding != null) {
/* 294 */       config.setDefaultEncoding(this.defaultEncoding);
/*     */     }
/*     */ 
/* 297 */     List templateLoaders = new LinkedList(this.templateLoaders);
/*     */ 
/* 300 */     if (this.preTemplateLoaders != null) {
/* 301 */       templateLoaders.addAll(this.preTemplateLoaders);
/*     */     }
/*     */ 
/* 305 */     if (this.templateLoaderPaths != null) {
/* 306 */       for (String path : this.templateLoaderPaths) {
/* 307 */         templateLoaders.add(getTemplateLoaderForPath(path));
/*     */       }
/*     */     }
/* 310 */     postProcessTemplateLoaders(templateLoaders);
/*     */ 
/* 313 */     if (this.postTemplateLoaders != null) {
/* 314 */       templateLoaders.addAll(this.postTemplateLoaders);
/*     */     }
/*     */ 
/* 317 */     TemplateLoader loader = getAggregateTemplateLoader(templateLoaders);
/* 318 */     if (loader != null) {
/* 319 */       config.setTemplateLoader(loader);
/*     */     }
/*     */ 
/* 322 */     postProcessConfiguration(config);
/* 323 */     return config;
/*     */   }
/*     */ 
/*     */   protected Configuration newConfiguration()
/*     */     throws IOException, TemplateException
/*     */   {
/* 336 */     return new Configuration();
/*     */   }
/*     */ 
/*     */   protected TemplateLoader getTemplateLoaderForPath(String templateLoaderPath)
/*     */   {
/* 349 */     if (isPreferFileSystemAccess())
/*     */     {
/*     */       try
/*     */       {
/* 353 */         Resource path = getResourceLoader().getResource(templateLoaderPath);
/* 354 */         File file = path.getFile();
/* 355 */         if (this.logger.isDebugEnabled()) {
/* 356 */           this.logger.debug("Template loader path [" + path + "] resolved to file path [" + file.getAbsolutePath() + "]");
/*     */         }
/*     */ 
/* 359 */         return new FileTemplateLoader(file);
/*     */       }
/*     */       catch (IOException ex) {
/* 362 */         if (this.logger.isDebugEnabled()) {
/* 363 */           this.logger.debug("Cannot resolve template loader path [" + templateLoaderPath + "] to [java.io.File]: using SpringTemplateLoader as fallback", ex);
/*     */         }
/*     */ 
/* 366 */         return new SpringTemplateLoader(getResourceLoader(), templateLoaderPath);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 371 */     this.logger.debug("File system access not preferred: using SpringTemplateLoader");
/* 372 */     return new SpringTemplateLoader(getResourceLoader(), templateLoaderPath);
/*     */   }
/*     */ 
/*     */   protected void postProcessTemplateLoaders(List<TemplateLoader> templateLoaders)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected TemplateLoader getAggregateTemplateLoader(List<TemplateLoader> templateLoaders)
/*     */   {
/* 400 */     int loaderCount = templateLoaders.size();
/* 401 */     switch (loaderCount) {
/*     */     case 0:
/* 403 */       this.logger.info("No FreeMarker TemplateLoaders specified");
/* 404 */       return null;
/*     */     case 1:
/* 406 */       return (TemplateLoader)templateLoaders.get(0);
/*     */     }
/* 408 */     TemplateLoader[] loaders = (TemplateLoader[])templateLoaders.toArray(new TemplateLoader[loaderCount]);
/* 409 */     return new MultiTemplateLoader(loaders);
/*     */   }
/*     */ 
/*     */   protected void postProcessConfiguration(Configuration config)
/*     */     throws IOException, TemplateException
/*     */   {
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.ui.freemarker.FreeMarkerConfigurationFactory
 * JD-Core Version:    0.6.1
 */