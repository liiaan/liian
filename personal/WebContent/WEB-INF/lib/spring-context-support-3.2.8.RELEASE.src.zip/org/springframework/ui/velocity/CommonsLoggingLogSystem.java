/*    */ package org.springframework.ui.velocity;
/*    */ 
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.apache.velocity.app.VelocityEngine;
/*    */ import org.apache.velocity.runtime.RuntimeServices;
/*    */ import org.apache.velocity.runtime.log.LogSystem;
/*    */ 
/*    */ @Deprecated
/*    */ public class CommonsLoggingLogSystem
/*    */   implements LogSystem
/*    */ {
/* 41 */   private static final Log logger = LogFactory.getLog(VelocityEngine.class);
/*    */ 
/*    */   public void init(RuntimeServices runtimeServices) {
/*    */   }
/*    */ 
/*    */   public void logVelocityMessage(int type, String msg) {
/* 47 */     switch (type) {
/*    */     case 3:
/* 49 */       logger.error(msg);
/* 50 */       break;
/*    */     case 2:
/* 52 */       logger.warn(msg);
/* 53 */       break;
/*    */     case 1:
/* 55 */       logger.info(msg);
/* 56 */       break;
/*    */     case 0:
/* 58 */       logger.debug(msg);
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.ui.velocity.CommonsLoggingLogSystem
 * JD-Core Version:    0.6.1
 */