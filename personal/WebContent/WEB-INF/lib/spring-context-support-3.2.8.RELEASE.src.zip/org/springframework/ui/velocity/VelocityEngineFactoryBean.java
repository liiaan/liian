/*    */ package org.springframework.ui.velocity;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.apache.velocity.app.VelocityEngine;
/*    */ import org.apache.velocity.exception.VelocityException;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.context.ResourceLoaderAware;
/*    */ 
/*    */ public class VelocityEngineFactoryBean extends VelocityEngineFactory
/*    */   implements FactoryBean<VelocityEngine>, InitializingBean, ResourceLoaderAware
/*    */ {
/*    */   private VelocityEngine velocityEngine;
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */     throws IOException, VelocityException
/*    */   {
/* 57 */     this.velocityEngine = createVelocityEngine();
/*    */   }
/*    */ 
/*    */   public VelocityEngine getObject()
/*    */   {
/* 62 */     return this.velocityEngine;
/*    */   }
/*    */ 
/*    */   public Class<? extends VelocityEngine> getObjectType() {
/* 66 */     return VelocityEngine.class;
/*    */   }
/*    */ 
/*    */   public boolean isSingleton() {
/* 70 */     return true;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.ui.velocity.VelocityEngineFactoryBean
 * JD-Core Version:    0.6.1
 */