/*    */ package org.springframework.ui.freemarker;
/*    */ 
/*    */ import freemarker.template.Template;
/*    */ import freemarker.template.TemplateException;
/*    */ import java.io.IOException;
/*    */ import java.io.StringWriter;
/*    */ 
/*    */ public abstract class FreeMarkerTemplateUtils
/*    */ {
/*    */   public static String processTemplateIntoString(Template template, Object model)
/*    */     throws IOException, TemplateException
/*    */   {
/* 48 */     StringWriter result = new StringWriter();
/* 49 */     template.process(model, result);
/* 50 */     return result.toString();
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.ui.freemarker.FreeMarkerTemplateUtils
 * JD-Core Version:    0.6.1
 */