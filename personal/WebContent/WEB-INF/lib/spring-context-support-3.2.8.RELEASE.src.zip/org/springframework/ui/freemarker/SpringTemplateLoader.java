/*    */ package org.springframework.ui.freemarker;
/*    */ 
/*    */ import freemarker.cache.TemplateLoader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.Reader;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ 
/*    */ public class SpringTemplateLoader
/*    */   implements TemplateLoader
/*    */ {
/* 42 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */   private final ResourceLoader resourceLoader;
/*    */   private final String templateLoaderPath;
/*    */ 
/*    */   public SpringTemplateLoader(ResourceLoader resourceLoader, String templateLoaderPath)
/*    */   {
/* 55 */     this.resourceLoader = resourceLoader;
/* 56 */     if (!templateLoaderPath.endsWith("/")) {
/* 57 */       templateLoaderPath = templateLoaderPath + "/";
/*    */     }
/* 59 */     this.templateLoaderPath = templateLoaderPath;
/* 60 */     if (this.logger.isInfoEnabled())
/* 61 */       this.logger.info("SpringTemplateLoader for FreeMarker: using resource loader [" + this.resourceLoader + "] and template loader path [" + this.templateLoaderPath + "]");
/*    */   }
/*    */ 
/*    */   public Object findTemplateSource(String name)
/*    */     throws IOException
/*    */   {
/* 67 */     if (this.logger.isDebugEnabled()) {
/* 68 */       this.logger.debug("Looking for FreeMarker template with name [" + name + "]");
/*    */     }
/* 70 */     Resource resource = this.resourceLoader.getResource(this.templateLoaderPath + name);
/* 71 */     return resource.exists() ? resource : null;
/*    */   }
/*    */ 
/*    */   public Reader getReader(Object templateSource, String encoding) throws IOException {
/* 75 */     Resource resource = (Resource)templateSource;
/*    */     try {
/* 77 */       return new InputStreamReader(resource.getInputStream(), encoding);
/*    */     }
/*    */     catch (IOException ex) {
/* 80 */       if (this.logger.isDebugEnabled()) {
/* 81 */         this.logger.debug("Could not find FreeMarker template: " + resource);
/*    */       }
/* 83 */       throw ex;
/*    */     }
/*    */   }
/*    */ 
/*    */   public long getLastModified(Object templateSource)
/*    */   {
/* 89 */     Resource resource = (Resource)templateSource;
/*    */     try {
/* 91 */       return resource.lastModified();
/*    */     }
/*    */     catch (IOException ex) {
/* 94 */       if (this.logger.isDebugEnabled()) {
/* 95 */         this.logger.debug("Could not obtain last-modified timestamp for FreeMarker template in " + resource + ": " + ex);
/*    */       }
/*    */     }
/* 98 */     return -1L;
/*    */   }
/*    */ 
/*    */   public void closeTemplateSource(Object templateSource)
/*    */     throws IOException
/*    */   {
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.ui.freemarker.SpringTemplateLoader
 * JD-Core Version:    0.6.1
 */