/*     */ package org.springframework.ui.velocity;
/*     */ 
/*     */ import java.io.StringWriter;
/*     */ import java.io.Writer;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.velocity.VelocityContext;
/*     */ import org.apache.velocity.app.VelocityEngine;
/*     */ import org.apache.velocity.exception.VelocityException;
/*     */ 
/*     */ public abstract class VelocityEngineUtils
/*     */ {
/*  38 */   private static final Log logger = LogFactory.getLog(VelocityEngineUtils.class);
/*     */ 
/*     */   @Deprecated
/*     */   public static void mergeTemplate(VelocityEngine velocityEngine, String templateLocation, Map<String, Object> model, Writer writer)
/*     */     throws VelocityException
/*     */   {
/*     */     try
/*     */     {
/*  58 */       VelocityContext velocityContext = new VelocityContext(model);
/*  59 */       velocityEngine.mergeTemplate(templateLocation, velocityContext, writer);
/*     */     }
/*     */     catch (VelocityException ex) {
/*  62 */       throw ex;
/*     */     }
/*     */     catch (RuntimeException ex) {
/*  65 */       throw ex;
/*     */     }
/*     */     catch (Exception ex) {
/*  68 */       logger.error("Why does VelocityEngine throw a generic checked exception, after all?", ex);
/*  69 */       throw new VelocityException(ex.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void mergeTemplate(VelocityEngine velocityEngine, String templateLocation, String encoding, Map<String, Object> model, Writer writer)
/*     */     throws VelocityException
/*     */   {
/*     */     try
/*     */     {
/*  88 */       VelocityContext velocityContext = new VelocityContext(model);
/*  89 */       velocityEngine.mergeTemplate(templateLocation, encoding, velocityContext, writer);
/*     */     }
/*     */     catch (VelocityException ex) {
/*  92 */       throw ex;
/*     */     }
/*     */     catch (RuntimeException ex) {
/*  95 */       throw ex;
/*     */     }
/*     */     catch (Exception ex) {
/*  98 */       logger.error("Why does VelocityEngine throw a generic checked exception, after all?", ex);
/*  99 */       throw new VelocityException(ex.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public static String mergeTemplateIntoString(VelocityEngine velocityEngine, String templateLocation, Map<String, Object> model)
/*     */     throws VelocityException
/*     */   {
/* 120 */     StringWriter result = new StringWriter();
/* 121 */     mergeTemplate(velocityEngine, templateLocation, model, result);
/* 122 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public static String mergeTemplateIntoString(VelocityEngine velocityEngine, String templateLocation, String encoding, Map<String, Object> model)
/*     */     throws VelocityException
/*     */   {
/* 140 */     StringWriter result = new StringWriter();
/* 141 */     mergeTemplate(velocityEngine, templateLocation, encoding, model, result);
/* 142 */     return result.toString();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.ui.velocity.VelocityEngineUtils
 * JD-Core Version:    0.6.1
 */