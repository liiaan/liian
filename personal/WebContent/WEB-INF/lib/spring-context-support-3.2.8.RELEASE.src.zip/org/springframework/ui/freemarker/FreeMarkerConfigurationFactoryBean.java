/*    */ package org.springframework.ui.freemarker;
/*    */ 
/*    */ import freemarker.template.Configuration;
/*    */ import freemarker.template.TemplateException;
/*    */ import java.io.IOException;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.context.ResourceLoaderAware;
/*    */ 
/*    */ public class FreeMarkerConfigurationFactoryBean extends FreeMarkerConfigurationFactory
/*    */   implements FactoryBean<Configuration>, InitializingBean, ResourceLoaderAware
/*    */ {
/*    */   private Configuration configuration;
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */     throws IOException, TemplateException
/*    */   {
/* 60 */     this.configuration = createConfiguration();
/*    */   }
/*    */ 
/*    */   public Configuration getObject()
/*    */   {
/* 65 */     return this.configuration;
/*    */   }
/*    */ 
/*    */   public Class<? extends Configuration> getObjectType() {
/* 69 */     return Configuration.class;
/*    */   }
/*    */ 
/*    */   public boolean isSingleton() {
/* 73 */     return true;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.ui.freemarker.FreeMarkerConfigurationFactoryBean
 * JD-Core Version:    0.6.1
 */