/*     */ package org.springframework.ui.velocity;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Arrays;
/*     */ import org.apache.commons.collections.ExtendedProperties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.velocity.exception.ResourceNotFoundException;
/*     */ import org.apache.velocity.runtime.RuntimeServices;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class SpringResourceLoader extends org.apache.velocity.runtime.resource.loader.ResourceLoader
/*     */ {
/*     */   public static final String NAME = "spring";
/*     */   public static final String SPRING_RESOURCE_LOADER_CLASS = "spring.resource.loader.class";
/*     */   public static final String SPRING_RESOURCE_LOADER_CACHE = "spring.resource.loader.cache";
/*     */   public static final String SPRING_RESOURCE_LOADER = "spring.resource.loader";
/*     */   public static final String SPRING_RESOURCE_LOADER_PATH = "spring.resource.loader.path";
/*  64 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private org.springframework.core.io.ResourceLoader resourceLoader;
/*     */   private String[] resourceLoaderPaths;
/*     */ 
/*     */   public void init(ExtendedProperties configuration)
/*     */   {
/*  73 */     this.resourceLoader = ((org.springframework.core.io.ResourceLoader)this.rsvc.getApplicationAttribute("spring.resource.loader"));
/*     */ 
/*  75 */     String resourceLoaderPath = (String)this.rsvc.getApplicationAttribute("spring.resource.loader.path");
/*  76 */     if (this.resourceLoader == null) {
/*  77 */       throw new IllegalArgumentException("'resourceLoader' application attribute must be present for SpringResourceLoader");
/*     */     }
/*     */ 
/*  80 */     if (resourceLoaderPath == null) {
/*  81 */       throw new IllegalArgumentException("'resourceLoaderPath' application attribute must be present for SpringResourceLoader");
/*     */     }
/*     */ 
/*  84 */     this.resourceLoaderPaths = StringUtils.commaDelimitedListToStringArray(resourceLoaderPath);
/*  85 */     for (int i = 0; i < this.resourceLoaderPaths.length; i++) {
/*  86 */       String path = this.resourceLoaderPaths[i];
/*  87 */       if (!path.endsWith("/")) {
/*  88 */         this.resourceLoaderPaths[i] = (path + "/");
/*     */       }
/*     */     }
/*  91 */     if (this.logger.isInfoEnabled())
/*  92 */       this.logger.info("SpringResourceLoader for Velocity: using resource loader [" + this.resourceLoader + "] and resource loader paths " + Arrays.asList(this.resourceLoaderPaths));
/*     */   }
/*     */ 
/*     */   public InputStream getResourceStream(String source)
/*     */     throws ResourceNotFoundException
/*     */   {
/*  99 */     if (this.logger.isDebugEnabled()) {
/* 100 */       this.logger.debug("Looking for Velocity resource with name [" + source + "]");
/*     */     }
/* 102 */     for (String resourceLoaderPath : this.resourceLoaderPaths) {
/* 103 */       org.springframework.core.io.Resource resource = this.resourceLoader.getResource(resourceLoaderPath + source);
/*     */       try
/*     */       {
/* 106 */         return resource.getInputStream();
/*     */       }
/*     */       catch (IOException ex) {
/* 109 */         if (this.logger.isDebugEnabled()) {
/* 110 */           this.logger.debug("Could not find Velocity resource: " + resource);
/*     */         }
/*     */       }
/*     */     }
/* 114 */     throw new ResourceNotFoundException("Could not find resource [" + source + "] in Spring resource loader path");
/*     */   }
/*     */ 
/*     */   public boolean isSourceModified(org.apache.velocity.runtime.resource.Resource resource)
/*     */   {
/* 120 */     return false;
/*     */   }
/*     */ 
/*     */   public long getLastModified(org.apache.velocity.runtime.resource.Resource resource)
/*     */   {
/* 125 */     return 0L;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.ui.velocity.SpringResourceLoader
 * JD-Core Version:    0.6.1
 */