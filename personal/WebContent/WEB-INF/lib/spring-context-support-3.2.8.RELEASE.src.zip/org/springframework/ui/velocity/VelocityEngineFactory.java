/*     */ package org.springframework.ui.velocity;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.velocity.app.VelocityEngine;
/*     */ import org.apache.velocity.exception.VelocityException;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.PropertiesLoaderUtils;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class VelocityEngineFactory
/*     */ {
/*  75 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private Resource configLocation;
/*  79 */   private final Map<String, Object> velocityProperties = new HashMap();
/*     */   private String resourceLoaderPath;
/*  83 */   private ResourceLoader resourceLoader = new DefaultResourceLoader();
/*     */ 
/*  85 */   private boolean preferFileSystemAccess = true;
/*     */ 
/*  87 */   private boolean overrideLogging = true;
/*     */ 
/*     */   public void setConfigLocation(Resource configLocation)
/*     */   {
/*  97 */     this.configLocation = configLocation;
/*     */   }
/*     */ 
/*     */   public void setVelocityProperties(Properties velocityProperties)
/*     */   {
/* 113 */     CollectionUtils.mergePropertiesIntoMap(velocityProperties, this.velocityProperties);
/*     */   }
/*     */ 
/*     */   public void setVelocityPropertiesMap(Map<String, Object> velocityPropertiesMap)
/*     */   {
/* 122 */     if (velocityPropertiesMap != null)
/* 123 */       this.velocityProperties.putAll(velocityPropertiesMap);
/*     */   }
/*     */ 
/*     */   public void setResourceLoaderPath(String resourceLoaderPath)
/*     */   {
/* 155 */     this.resourceLoaderPath = resourceLoaderPath;
/*     */   }
/*     */ 
/*     */   public void setResourceLoader(ResourceLoader resourceLoader)
/*     */   {
/* 166 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */   protected ResourceLoader getResourceLoader()
/*     */   {
/* 173 */     return this.resourceLoader;
/*     */   }
/*     */ 
/*     */   public void setPreferFileSystemAccess(boolean preferFileSystemAccess)
/*     */   {
/* 189 */     this.preferFileSystemAccess = preferFileSystemAccess;
/*     */   }
/*     */ 
/*     */   protected boolean isPreferFileSystemAccess()
/*     */   {
/* 196 */     return this.preferFileSystemAccess;
/*     */   }
/*     */ 
/*     */   public void setOverrideLogging(boolean overrideLogging)
/*     */   {
/* 205 */     this.overrideLogging = overrideLogging;
/*     */   }
/*     */ 
/*     */   public VelocityEngine createVelocityEngine()
/*     */     throws IOException, VelocityException
/*     */   {
/* 216 */     VelocityEngine velocityEngine = newVelocityEngine();
/* 217 */     Map props = new HashMap();
/*     */ 
/* 220 */     if (this.configLocation != null) {
/* 221 */       if (this.logger.isInfoEnabled()) {
/* 222 */         this.logger.info("Loading Velocity config from [" + this.configLocation + "]");
/*     */       }
/* 224 */       CollectionUtils.mergePropertiesIntoMap(PropertiesLoaderUtils.loadProperties(this.configLocation), props);
/*     */     }
/*     */ 
/* 228 */     if (!this.velocityProperties.isEmpty()) {
/* 229 */       props.putAll(this.velocityProperties);
/*     */     }
/*     */ 
/* 233 */     if (this.resourceLoaderPath != null) {
/* 234 */       initVelocityResourceLoader(velocityEngine, this.resourceLoaderPath);
/*     */     }
/*     */ 
/* 238 */     if (this.overrideLogging) {
/* 239 */       velocityEngine.setProperty("runtime.log.logsystem", new CommonsLoggingLogSystem());
/*     */     }
/*     */ 
/* 243 */     for (Map.Entry entry : props.entrySet()) {
/* 244 */       velocityEngine.setProperty((String)entry.getKey(), entry.getValue());
/*     */     }
/*     */ 
/* 247 */     postProcessVelocityEngine(velocityEngine);
/*     */     try
/*     */     {
/* 251 */       velocityEngine.init();
/*     */     }
/*     */     catch (IOException ex) {
/* 254 */       throw ex;
/*     */     }
/*     */     catch (VelocityException ex) {
/* 257 */       throw ex;
/*     */     }
/*     */     catch (RuntimeException ex) {
/* 260 */       throw ex;
/*     */     }
/*     */     catch (Exception ex) {
/* 263 */       this.logger.error("Why does VelocityEngine throw a generic checked exception, after all?", ex);
/* 264 */       throw new VelocityException(ex.toString());
/*     */     }
/*     */ 
/* 267 */     return velocityEngine;
/*     */   }
/*     */ 
/*     */   protected VelocityEngine newVelocityEngine()
/*     */     throws IOException, VelocityException
/*     */   {
/* 280 */     return new VelocityEngine();
/*     */   }
/*     */ 
/*     */   protected void initVelocityResourceLoader(VelocityEngine velocityEngine, String resourceLoaderPath)
/*     */   {
/* 295 */     if (isPreferFileSystemAccess())
/*     */     {
/*     */       try
/*     */       {
/* 299 */         StringBuilder resolvedPath = new StringBuilder();
/* 300 */         String[] paths = StringUtils.commaDelimitedListToStringArray(resourceLoaderPath);
/* 301 */         for (int i = 0; i < paths.length; i++) {
/* 302 */           String path = paths[i];
/* 303 */           Resource resource = getResourceLoader().getResource(path);
/* 304 */           File file = resource.getFile();
/* 305 */           if (this.logger.isDebugEnabled()) {
/* 306 */             this.logger.debug("Resource loader path [" + path + "] resolved to file [" + file.getAbsolutePath() + "]");
/*     */           }
/* 308 */           resolvedPath.append(file.getAbsolutePath());
/* 309 */           if (i < paths.length - 1) {
/* 310 */             resolvedPath.append(',');
/*     */           }
/*     */         }
/* 313 */         velocityEngine.setProperty("resource.loader", "file");
/* 314 */         velocityEngine.setProperty("file.resource.loader.cache", "true");
/* 315 */         velocityEngine.setProperty("file.resource.loader.path", resolvedPath.toString());
/*     */       }
/*     */       catch (IOException ex) {
/* 318 */         if (this.logger.isDebugEnabled()) {
/* 319 */           this.logger.debug("Cannot resolve resource loader path [" + resourceLoaderPath + "] to [java.io.File]: using SpringResourceLoader", ex);
/*     */         }
/*     */ 
/* 322 */         initSpringResourceLoader(velocityEngine, resourceLoaderPath);
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 328 */       if (this.logger.isDebugEnabled()) {
/* 329 */         this.logger.debug("File system access not preferred: using SpringResourceLoader");
/*     */       }
/* 331 */       initSpringResourceLoader(velocityEngine, resourceLoaderPath);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void initSpringResourceLoader(VelocityEngine velocityEngine, String resourceLoaderPath)
/*     */   {
/* 344 */     velocityEngine.setProperty("resource.loader", "spring");
/*     */ 
/* 346 */     velocityEngine.setProperty("spring.resource.loader.class", SpringResourceLoader.class.getName());
/*     */ 
/* 348 */     velocityEngine.setProperty("spring.resource.loader.cache", "true");
/*     */ 
/* 350 */     velocityEngine.setApplicationAttribute("spring.resource.loader", getResourceLoader());
/*     */ 
/* 352 */     velocityEngine.setApplicationAttribute("spring.resource.loader.path", resourceLoaderPath);
/*     */   }
/*     */ 
/*     */   protected void postProcessVelocityEngine(VelocityEngine velocityEngine)
/*     */     throws IOException, VelocityException
/*     */   {
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.ui.velocity.VelocityEngineFactory
 * JD-Core Version:    0.6.1
 */