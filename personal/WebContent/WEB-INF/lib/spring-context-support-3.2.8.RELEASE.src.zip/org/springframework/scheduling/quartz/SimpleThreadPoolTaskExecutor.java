/*    */ package org.springframework.scheduling.quartz;
/*    */ 
/*    */ import java.util.concurrent.Callable;
/*    */ import java.util.concurrent.Future;
/*    */ import java.util.concurrent.FutureTask;
/*    */ import org.quartz.SchedulerConfigException;
/*    */ import org.quartz.simpl.SimpleThreadPool;
/*    */ import org.springframework.beans.factory.DisposableBean;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.scheduling.SchedulingException;
/*    */ import org.springframework.scheduling.SchedulingTaskExecutor;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class SimpleThreadPoolTaskExecutor extends SimpleThreadPool
/*    */   implements SchedulingTaskExecutor, InitializingBean, DisposableBean
/*    */ {
/* 50 */   private boolean waitForJobsToCompleteOnShutdown = false;
/*    */ 
/*    */   public void setWaitForJobsToCompleteOnShutdown(boolean waitForJobsToCompleteOnShutdown)
/*    */   {
/* 59 */     this.waitForJobsToCompleteOnShutdown = waitForJobsToCompleteOnShutdown;
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet() throws SchedulerConfigException {
/* 63 */     initialize();
/*    */   }
/*    */ 
/*    */   public void execute(Runnable task)
/*    */   {
/* 68 */     Assert.notNull(task, "Runnable must not be null");
/* 69 */     if (!runInThread(task))
/* 70 */       throw new SchedulingException("Quartz SimpleThreadPool already shut down");
/*    */   }
/*    */ 
/*    */   public void execute(Runnable task, long startTimeout)
/*    */   {
/* 75 */     execute(task);
/*    */   }
/*    */ 
/*    */   public Future<?> submit(Runnable task) {
/* 79 */     FutureTask future = new FutureTask(task, null);
/* 80 */     execute(future);
/* 81 */     return future;
/*    */   }
/*    */ 
/*    */   public <T> Future<T> submit(Callable<T> task) {
/* 85 */     FutureTask future = new FutureTask(task);
/* 86 */     execute(future);
/* 87 */     return future;
/*    */   }
/*    */ 
/*    */   public boolean prefersShortLivedTasks()
/*    */   {
/* 94 */     return true;
/*    */   }
/*    */ 
/*    */   public void destroy()
/*    */   {
/* 99 */     shutdown(this.waitForJobsToCompleteOnShutdown);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.quartz.SimpleThreadPoolTaskExecutor
 * JD-Core Version:    0.6.1
 */