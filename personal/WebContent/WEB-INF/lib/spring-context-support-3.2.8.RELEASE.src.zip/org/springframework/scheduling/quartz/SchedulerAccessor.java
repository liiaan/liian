/*     */ package org.springframework.scheduling.quartz;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.quartz.Calendar;
/*     */ import org.quartz.JobDetail;
/*     */ import org.quartz.JobListener;
/*     */ import org.quartz.ObjectAlreadyExistsException;
/*     */ import org.quartz.Scheduler;
/*     */ import org.quartz.SchedulerException;
/*     */ import org.quartz.SchedulerListener;
/*     */ import org.quartz.Trigger;
/*     */ import org.quartz.TriggerListener;
/*     */ import org.quartz.spi.ClassLoadHelper;
/*     */ import org.springframework.context.ResourceLoaderAware;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.transaction.PlatformTransactionManager;
/*     */ import org.springframework.transaction.TransactionException;
/*     */ import org.springframework.transaction.TransactionStatus;
/*     */ import org.springframework.transaction.support.DefaultTransactionDefinition;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public abstract class SchedulerAccessor
/*     */   implements ResourceLoaderAware
/*     */ {
/*     */   private static Class<?> jobKeyClass;
/*     */   private static Class<?> triggerKeyClass;
/*  79 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*  81 */   private boolean overwriteExistingJobs = false;
/*     */   private String[] jobSchedulingDataLocations;
/*     */   private List<JobDetail> jobDetails;
/*     */   private Map<String, Calendar> calendars;
/*     */   private List<Trigger> triggers;
/*     */   private SchedulerListener[] schedulerListeners;
/*     */   private JobListener[] globalJobListeners;
/*     */   private JobListener[] jobListeners;
/*     */   private TriggerListener[] globalTriggerListeners;
/*     */   private TriggerListener[] triggerListeners;
/*     */   private PlatformTransactionManager transactionManager;
/*     */   protected ResourceLoader resourceLoader;
/*     */ 
/*     */   public void setOverwriteExistingJobs(boolean overwriteExistingJobs)
/*     */   {
/* 112 */     this.overwriteExistingJobs = overwriteExistingJobs;
/*     */   }
/*     */ 
/*     */   public void setJobSchedulingDataLocation(String jobSchedulingDataLocation)
/*     */   {
/* 123 */     this.jobSchedulingDataLocations = new String[] { jobSchedulingDataLocation };
/*     */   }
/*     */ 
/*     */   public void setJobSchedulingDataLocations(String[] jobSchedulingDataLocations)
/*     */   {
/* 134 */     this.jobSchedulingDataLocations = jobSchedulingDataLocations;
/*     */   }
/*     */ 
/*     */   public void setJobDetails(JobDetail[] jobDetails)
/*     */   {
/* 151 */     this.jobDetails = new ArrayList(Arrays.asList(jobDetails));
/*     */   }
/*     */ 
/*     */   public void setCalendars(Map<String, Calendar> calendars)
/*     */   {
/* 162 */     this.calendars = calendars;
/*     */   }
/*     */ 
/*     */   public void setTriggers(Trigger[] triggers)
/*     */   {
/* 179 */     this.triggers = Arrays.asList(triggers);
/*     */   }
/*     */ 
/*     */   public void setSchedulerListeners(SchedulerListener[] schedulerListeners)
/*     */   {
/* 187 */     this.schedulerListeners = schedulerListeners;
/*     */   }
/*     */ 
/*     */   public void setGlobalJobListeners(JobListener[] globalJobListeners)
/*     */   {
/* 195 */     this.globalJobListeners = globalJobListeners;
/*     */   }
/*     */ 
/*     */   public void setJobListeners(JobListener[] jobListeners)
/*     */   {
/* 208 */     this.jobListeners = jobListeners;
/*     */   }
/*     */ 
/*     */   public void setGlobalTriggerListeners(TriggerListener[] globalTriggerListeners)
/*     */   {
/* 216 */     this.globalTriggerListeners = globalTriggerListeners;
/*     */   }
/*     */ 
/*     */   public void setTriggerListeners(TriggerListener[] triggerListeners)
/*     */   {
/* 230 */     this.triggerListeners = triggerListeners;
/*     */   }
/*     */ 
/*     */   public void setTransactionManager(PlatformTransactionManager transactionManager)
/*     */   {
/* 240 */     this.transactionManager = transactionManager;
/*     */   }
/*     */ 
/*     */   public void setResourceLoader(ResourceLoader resourceLoader) {
/* 244 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */   protected void registerJobsAndTriggers()
/*     */     throws SchedulerException
/*     */   {
/* 252 */     TransactionStatus transactionStatus = null;
/* 253 */     if (this.transactionManager != null) {
/* 254 */       transactionStatus = this.transactionManager.getTransaction(new DefaultTransactionDefinition());
/*     */     }
/*     */     try
/*     */     {
/* 258 */       if (this.jobSchedulingDataLocations != null) { ClassLoadHelper clh = new ResourceLoaderClassLoadHelper(this.resourceLoader);
/* 260 */         clh.initialize();
/*     */         Object dataProcessor;
/*     */         Method processFileAndScheduleJobs;
/*     */         String[] arr$;
/*     */         int len$;
/*     */         int i$;
/*     */         try { Class dataProcessorClass = getClass().getClassLoader().loadClass("org.quartz.xml.XMLSchedulingDataProcessor");
/* 264 */           this.logger.debug("Using Quartz 1.8 XMLSchedulingDataProcessor");
/* 265 */           Object dataProcessor = dataProcessorClass.getConstructor(new Class[] { ClassLoadHelper.class }).newInstance(new Object[] { clh });
/* 266 */           Method processFileAndScheduleJobs = dataProcessorClass.getMethod("processFileAndScheduleJobs", new Class[] { String.class, Scheduler.class });
/* 267 */           for (String location : this.jobSchedulingDataLocations) {
/* 268 */             processFileAndScheduleJobs.invoke(dataProcessor, new Object[] { location, getScheduler() });
/*     */           }
/*     */         }
/*     */         catch (ClassNotFoundException ex)
/*     */         {
/* 273 */           Class dataProcessorClass = getClass().getClassLoader().loadClass("org.quartz.xml.JobSchedulingDataProcessor");
/* 274 */           this.logger.debug("Using Quartz 1.6 JobSchedulingDataProcessor");
/* 275 */           dataProcessor = dataProcessorClass.getConstructor(new Class[] { ClassLoadHelper.class, Boolean.TYPE, Boolean.TYPE }).newInstance(new Object[] { clh, Boolean.valueOf(true), Boolean.valueOf(true) });
/* 276 */           processFileAndScheduleJobs = dataProcessorClass.getMethod("processFileAndScheduleJobs", new Class[] { String.class, Scheduler.class, Boolean.TYPE });
/* 277 */           arr$ = this.jobSchedulingDataLocations; len$ = arr$.length; i$ = 0; } for (; i$ < len$; i$++) { String location = arr$[i$];
/* 278 */           processFileAndScheduleJobs.invoke(dataProcessor, new Object[] { location, getScheduler(), Boolean.valueOf(this.overwriteExistingJobs) });
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 284 */       if (this.jobDetails != null) {
/* 285 */         for (JobDetail jobDetail : this.jobDetails) {
/* 286 */           addJobToScheduler(jobDetail);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 291 */         this.jobDetails = new LinkedList();
/*     */       }
/*     */ 
/* 295 */       if (this.calendars != null) {
/* 296 */         for (String calendarName : this.calendars.keySet()) {
/* 297 */           Calendar calendar = (Calendar)this.calendars.get(calendarName);
/* 298 */           getScheduler().addCalendar(calendarName, calendar, true, true);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 303 */       if (this.triggers != null) {
/* 304 */         for (Trigger trigger : this.triggers) {
/* 305 */           addTriggerToScheduler(trigger);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 311 */       if (transactionStatus != null) {
/*     */         try {
/* 313 */           this.transactionManager.rollback(transactionStatus);
/*     */         }
/*     */         catch (TransactionException tex) {
/* 316 */           this.logger.error("Job registration exception overridden by rollback exception", ex);
/* 317 */           throw tex;
/*     */         }
/*     */       }
/* 320 */       if ((ex instanceof SchedulerException)) {
/* 321 */         throw ((SchedulerException)ex);
/*     */       }
/* 323 */       if ((ex instanceof Exception)) {
/* 324 */         throw new SchedulerException("Registration of jobs and triggers failed: " + ex.getMessage(), ex);
/*     */       }
/* 326 */       throw new SchedulerException("Registration of jobs and triggers failed: " + ex.getMessage());
/*     */     }
/*     */ 
/* 329 */     if (transactionStatus != null)
/* 330 */       this.transactionManager.commit(transactionStatus);
/*     */   }
/*     */ 
/*     */   private boolean addJobToScheduler(JobDetail jobDetail)
/*     */     throws SchedulerException
/*     */   {
/* 343 */     if ((this.overwriteExistingJobs) || (!jobDetailExists(jobDetail))) {
/* 344 */       getScheduler().addJob(jobDetail, true);
/* 345 */       return true;
/*     */     }
/*     */ 
/* 348 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean addTriggerToScheduler(Trigger trigger)
/*     */     throws SchedulerException
/*     */   {
/* 361 */     boolean triggerExists = triggerExists(trigger);
/* 362 */     if ((!triggerExists) || (this.overwriteExistingJobs))
/*     */     {
/* 364 */       JobDetail jobDetail = findJobDetail(trigger);
/* 365 */       if (jobDetail != null)
/*     */       {
/* 367 */         if ((!this.jobDetails.contains(jobDetail)) && (addJobToScheduler(jobDetail))) {
/* 368 */           this.jobDetails.add(jobDetail);
/*     */         }
/*     */       }
/* 371 */       if (!triggerExists) {
/*     */         try {
/* 373 */           getScheduler().scheduleJob(trigger);
/*     */         }
/*     */         catch (ObjectAlreadyExistsException ex) {
/* 376 */           if (this.logger.isDebugEnabled()) {
/* 377 */             this.logger.debug("Unexpectedly found existing trigger, assumably due to cluster race condition: " + ex.getMessage() + " - can safely be ignored");
/*     */           }
/*     */ 
/* 380 */           if (this.overwriteExistingJobs) {
/* 381 */             rescheduleJob(trigger);
/*     */           }
/*     */         }
/*     */       }
/*     */       else {
/* 386 */         rescheduleJob(trigger);
/*     */       }
/* 388 */       return true;
/*     */     }
/*     */ 
/* 391 */     return false;
/*     */   }
/*     */ 
/*     */   private JobDetail findJobDetail(Trigger trigger)
/*     */   {
/* 396 */     if ((trigger instanceof JobDetailAwareTrigger)) {
/* 397 */       return ((JobDetailAwareTrigger)trigger).getJobDetail();
/*     */     }
/*     */     try
/*     */     {
/* 401 */       Map jobDataMap = (Map)ReflectionUtils.invokeMethod(Trigger.class.getMethod("getJobDataMap", new Class[0]), trigger);
/*     */ 
/* 403 */       return (JobDetail)jobDataMap.remove("jobDetail");
/*     */     }
/*     */     catch (NoSuchMethodException ex) {
/* 406 */       throw new IllegalStateException("Inconsistent Quartz API: " + ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean jobDetailExists(JobDetail jobDetail)
/*     */     throws SchedulerException
/*     */   {
/* 414 */     if (jobKeyClass != null) {
/*     */       try {
/* 416 */         Method getJobDetail = Scheduler.class.getMethod("getJobDetail", new Class[] { jobKeyClass });
/* 417 */         Object key = ReflectionUtils.invokeMethod(JobDetail.class.getMethod("getKey", new Class[0]), jobDetail);
/* 418 */         return ReflectionUtils.invokeMethod(getJobDetail, getScheduler(), new Object[] { key }) != null;
/*     */       }
/*     */       catch (NoSuchMethodException ex) {
/* 421 */         throw new IllegalStateException("Inconsistent Quartz 2.0 API: " + ex);
/*     */       }
/*     */     }
/*     */ 
/* 425 */     return getScheduler().getJobDetail(jobDetail.getName(), jobDetail.getGroup()) != null;
/*     */   }
/*     */ 
/*     */   private boolean triggerExists(Trigger trigger)
/*     */     throws SchedulerException
/*     */   {
/* 431 */     if (triggerKeyClass != null) {
/*     */       try {
/* 433 */         Method getTrigger = Scheduler.class.getMethod("getTrigger", new Class[] { triggerKeyClass });
/* 434 */         Object key = ReflectionUtils.invokeMethod(Trigger.class.getMethod("getKey", new Class[0]), trigger);
/* 435 */         return ReflectionUtils.invokeMethod(getTrigger, getScheduler(), new Object[] { key }) != null;
/*     */       }
/*     */       catch (NoSuchMethodException ex) {
/* 438 */         throw new IllegalStateException("Inconsistent Quartz 2.0 API: " + ex);
/*     */       }
/*     */     }
/*     */ 
/* 442 */     return getScheduler().getTrigger(trigger.getName(), trigger.getGroup()) != null;
/*     */   }
/*     */ 
/*     */   private void rescheduleJob(Trigger trigger)
/*     */     throws SchedulerException
/*     */   {
/* 448 */     if (triggerKeyClass != null) {
/*     */       try {
/* 450 */         Method rescheduleJob = Scheduler.class.getMethod("rescheduleJob", new Class[] { triggerKeyClass, Trigger.class });
/* 451 */         Object key = ReflectionUtils.invokeMethod(Trigger.class.getMethod("getKey", new Class[0]), trigger);
/* 452 */         ReflectionUtils.invokeMethod(rescheduleJob, getScheduler(), new Object[] { key, trigger });
/*     */       }
/*     */       catch (NoSuchMethodException ex) {
/* 455 */         throw new IllegalStateException("Inconsistent Quartz 2.0 API: " + ex);
/*     */       }
/*     */     }
/*     */     else
/* 459 */       getScheduler().rescheduleJob(trigger.getName(), trigger.getGroup(), trigger);
/*     */   }
/*     */ 
/*     */   protected void registerListeners()
/*     */     throws SchedulerException
/*     */   {
/*     */     Object target;
/*     */     boolean quartz2;
/*     */     try
/*     */     {
/* 471 */       Method getListenerManager = Scheduler.class.getMethod("getListenerManager", new Class[0]);
/* 472 */       target = ReflectionUtils.invokeMethod(getListenerManager, getScheduler());
/* 473 */       quartz2 = true;
/*     */     }
/*     */     catch (NoSuchMethodException ex) {
/* 476 */       target = getScheduler();
/* 477 */       quartz2 = false;
/*     */     }
/* 479 */     Class targetClass = target.getClass();
/*     */     try
/*     */     {
/* 482 */       if (this.schedulerListeners != null) {
/* 483 */         Method addSchedulerListener = targetClass.getMethod("addSchedulerListener", new Class[] { SchedulerListener.class });
/* 484 */         for (SchedulerListener listener : this.schedulerListeners) {
/* 485 */           ReflectionUtils.invokeMethod(addSchedulerListener, target, new Object[] { listener });
/*     */         }
/*     */       }
/* 488 */       if (this.globalJobListeners != null)
/*     */       {
/*     */         Method addJobListener;
/*     */         Method addJobListener;
/* 490 */         if (quartz2)
/*     */         {
/* 493 */           addJobListener = targetClass.getMethod("addJobListener", new Class[] { JobListener.class, List.class });
/*     */         }
/*     */         else {
/* 496 */           addJobListener = targetClass.getMethod("addGlobalJobListener", new Class[] { JobListener.class });
/*     */         }
/* 498 */         for (JobListener listener : this.globalJobListeners) {
/* 499 */           if (quartz2) {
/* 500 */             List emptyMatchers = new LinkedList();
/* 501 */             ReflectionUtils.invokeMethod(addJobListener, target, new Object[] { listener, emptyMatchers });
/*     */           }
/*     */           else {
/* 504 */             ReflectionUtils.invokeMethod(addJobListener, target, new Object[] { listener });
/*     */           }
/*     */         }
/*     */       }
/* 508 */       if (this.jobListeners != null) {
/* 509 */         for (JobListener listener : this.jobListeners) {
/* 510 */           if (quartz2) {
/* 511 */             throw new IllegalStateException("Non-global JobListeners not supported on Quartz 2 - manually register a Matcher against the Quartz ListenerManager instead");
/*     */           }
/*     */ 
/* 514 */           getScheduler().addJobListener(listener);
/*     */         }
/*     */       }
/* 517 */       if (this.globalTriggerListeners != null)
/*     */       {
/*     */         Method addTriggerListener;
/*     */         Method addTriggerListener;
/* 519 */         if (quartz2)
/*     */         {
/* 522 */           addTriggerListener = targetClass.getMethod("addTriggerListener", new Class[] { TriggerListener.class, List.class });
/*     */         }
/*     */         else {
/* 525 */           addTriggerListener = targetClass.getMethod("addGlobalTriggerListener", new Class[] { TriggerListener.class });
/*     */         }
/* 527 */         for (TriggerListener listener : this.globalTriggerListeners) {
/* 528 */           if (quartz2) {
/* 529 */             List emptyMatchers = new LinkedList();
/* 530 */             ReflectionUtils.invokeMethod(addTriggerListener, target, new Object[] { listener, emptyMatchers });
/*     */           }
/*     */           else {
/* 533 */             ReflectionUtils.invokeMethod(addTriggerListener, target, new Object[] { listener });
/*     */           }
/*     */         }
/*     */       }
/* 537 */       if (this.triggerListeners != null)
/* 538 */         for (TriggerListener listener : this.triggerListeners) {
/* 539 */           if (quartz2) {
/* 540 */             throw new IllegalStateException("Non-global TriggerListeners not supported on Quartz 2 - manually register a Matcher against the Quartz ListenerManager instead");
/*     */           }
/*     */ 
/* 543 */           getScheduler().addTriggerListener(listener);
/*     */         }
/*     */     }
/*     */     catch (NoSuchMethodException ex)
/*     */     {
/* 548 */       throw new IllegalStateException("Expected Quartz API not present: " + ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected abstract Scheduler getScheduler();
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  69 */       jobKeyClass = Class.forName("org.quartz.JobKey");
/*  70 */       triggerKeyClass = Class.forName("org.quartz.TriggerKey");
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/*  73 */       jobKeyClass = null;
/*  74 */       triggerKeyClass = null;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.quartz.SchedulerAccessor
 * JD-Core Version:    0.6.1
 */