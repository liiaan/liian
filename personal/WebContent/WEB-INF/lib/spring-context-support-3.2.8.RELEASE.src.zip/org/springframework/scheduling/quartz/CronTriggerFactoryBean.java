/*     */ package org.springframework.scheduling.quartz;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import org.quartz.CronTrigger;
/*     */ import org.quartz.JobDataMap;
/*     */ import org.quartz.JobDetail;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.BeanWrapperImpl;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.Constants;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class CronTriggerFactoryBean
/*     */   implements FactoryBean<CronTrigger>, BeanNameAware, InitializingBean
/*     */ {
/*  68 */   private static final Constants constants = new Constants(CronTrigger.class);
/*     */   private String name;
/*     */   private String group;
/*     */   private JobDetail jobDetail;
/*  77 */   private JobDataMap jobDataMap = new JobDataMap();
/*     */   private Date startTime;
/*  81 */   private long startDelay = 0L;
/*     */   private String cronExpression;
/*     */   private TimeZone timeZone;
/*     */   private String calendarName;
/*     */   private int priority;
/*     */   private int misfireInstruction;
/*     */   private String description;
/*     */   private String beanName;
/*     */   private CronTrigger cronTrigger;
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 104 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public void setGroup(String group)
/*     */   {
/* 111 */     this.group = group;
/*     */   }
/*     */ 
/*     */   public void setJobDetail(JobDetail jobDetail)
/*     */   {
/* 118 */     this.jobDetail = jobDetail;
/*     */   }
/*     */ 
/*     */   public void setJobDataMap(JobDataMap jobDataMap)
/*     */   {
/* 126 */     this.jobDataMap = jobDataMap;
/*     */   }
/*     */ 
/*     */   public JobDataMap getJobDataMap()
/*     */   {
/* 133 */     return this.jobDataMap;
/*     */   }
/*     */ 
/*     */   public void setJobDataAsMap(Map<String, ?> jobDataAsMap)
/*     */   {
/* 145 */     this.jobDataMap.putAll(jobDataAsMap);
/*     */   }
/*     */ 
/*     */   public void setStartTime(Date startTime)
/*     */   {
/* 154 */     this.startTime = startTime;
/*     */   }
/*     */ 
/*     */   public void setStartDelay(long startDelay)
/*     */   {
/* 163 */     Assert.isTrue(startDelay >= 0L, "Start delay cannot be negative");
/* 164 */     this.startDelay = startDelay;
/*     */   }
/*     */ 
/*     */   public void setCronExpression(String cronExpression)
/*     */   {
/* 171 */     this.cronExpression = cronExpression;
/*     */   }
/*     */ 
/*     */   public void setTimeZone(TimeZone timeZone)
/*     */   {
/* 178 */     this.timeZone = timeZone;
/*     */   }
/*     */ 
/*     */   public void setCalendarName(String calendarName)
/*     */   {
/* 185 */     this.calendarName = calendarName;
/*     */   }
/*     */ 
/*     */   public void setPriority(int priority)
/*     */   {
/* 192 */     this.priority = priority;
/*     */   }
/*     */ 
/*     */   public void setMisfireInstruction(int misfireInstruction)
/*     */   {
/* 199 */     this.misfireInstruction = misfireInstruction;
/*     */   }
/*     */ 
/*     */   public void setMisfireInstructionName(String constantName)
/*     */   {
/* 211 */     this.misfireInstruction = constants.asNumber(constantName).intValue();
/*     */   }
/*     */ 
/*     */   public void setDescription(String description)
/*     */   {
/* 218 */     this.description = description;
/*     */   }
/*     */ 
/*     */   public void setBeanName(String beanName) {
/* 222 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 227 */     if (this.name == null) {
/* 228 */       this.name = this.beanName;
/*     */     }
/* 230 */     if (this.group == null) {
/* 231 */       this.group = "DEFAULT";
/*     */     }
/* 233 */     if (this.jobDetail != null) {
/* 234 */       this.jobDataMap.put("jobDetail", this.jobDetail);
/*     */     }
/* 236 */     if ((this.startDelay > 0L) || (this.startTime == null)) {
/* 237 */       this.startTime = new Date(System.currentTimeMillis() + this.startDelay);
/*     */     }
/* 239 */     if (this.timeZone == null) {
/* 240 */       this.timeZone = TimeZone.getDefault();
/*     */     }
/*     */ 
/*     */     Class cronTriggerClass;
/*     */     Method jobKeyMethod;
/*     */     try
/*     */     {
/* 262 */       cronTriggerClass = getClass().getClassLoader().loadClass("org.quartz.impl.triggers.CronTriggerImpl");
/* 263 */       jobKeyMethod = JobDetail.class.getMethod("getKey", new Class[0]);
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 266 */       cronTriggerClass = CronTrigger.class;
/* 267 */       jobKeyMethod = null;
/*     */     }
/*     */     catch (NoSuchMethodException ex) {
/* 270 */       throw new IllegalStateException("Incompatible Quartz version");
/*     */     }
/* 272 */     BeanWrapper bw = new BeanWrapperImpl(cronTriggerClass);
/* 273 */     MutablePropertyValues pvs = new MutablePropertyValues();
/* 274 */     pvs.add("name", this.name);
/* 275 */     pvs.add("group", this.group);
/* 276 */     if (jobKeyMethod != null) {
/* 277 */       pvs.add("jobKey", ReflectionUtils.invokeMethod(jobKeyMethod, this.jobDetail));
/*     */     }
/*     */     else {
/* 280 */       pvs.add("jobName", this.jobDetail.getName());
/* 281 */       pvs.add("jobGroup", this.jobDetail.getGroup());
/*     */     }
/* 283 */     pvs.add("jobDataMap", this.jobDataMap);
/* 284 */     pvs.add("startTime", this.startTime);
/* 285 */     pvs.add("cronExpression", this.cronExpression);
/* 286 */     pvs.add("timeZone", this.timeZone);
/* 287 */     pvs.add("calendarName", this.calendarName);
/* 288 */     pvs.add("priority", Integer.valueOf(this.priority));
/* 289 */     pvs.add("misfireInstruction", Integer.valueOf(this.misfireInstruction));
/* 290 */     pvs.add("description", this.description);
/* 291 */     bw.setPropertyValues(pvs);
/* 292 */     this.cronTrigger = ((CronTrigger)bw.getWrappedInstance());
/*     */   }
/*     */ 
/*     */   public CronTrigger getObject()
/*     */   {
/* 297 */     return this.cronTrigger;
/*     */   }
/*     */ 
/*     */   public Class<?> getObjectType() {
/* 301 */     return CronTrigger.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton() {
/* 305 */     return true;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.quartz.CronTriggerFactoryBean
 * JD-Core Version:    0.6.1
 */