/*     */ package org.springframework.scheduling.commonj;
/*     */ 
/*     */ import commonj.timers.TimerListener;
/*     */ 
/*     */ public class ScheduledTimerListener
/*     */ {
/*     */   private TimerListener timerListener;
/*  45 */   private long delay = 0L;
/*     */ 
/*  47 */   private long period = -1L;
/*     */ 
/*  49 */   private boolean fixedRate = false;
/*     */ 
/*     */   public ScheduledTimerListener()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ScheduledTimerListener(TimerListener timerListener)
/*     */   {
/*  69 */     this.timerListener = timerListener;
/*     */   }
/*     */ 
/*     */   public ScheduledTimerListener(TimerListener timerListener, long delay)
/*     */   {
/*  79 */     this.timerListener = timerListener;
/*  80 */     this.delay = delay;
/*     */   }
/*     */ 
/*     */   public ScheduledTimerListener(TimerListener timerListener, long delay, long period, boolean fixedRate)
/*     */   {
/*  91 */     this.timerListener = timerListener;
/*  92 */     this.delay = delay;
/*  93 */     this.period = period;
/*  94 */     this.fixedRate = fixedRate;
/*     */   }
/*     */ 
/*     */   public ScheduledTimerListener(Runnable timerTask)
/*     */   {
/* 103 */     setRunnable(timerTask);
/*     */   }
/*     */ 
/*     */   public ScheduledTimerListener(Runnable timerTask, long delay)
/*     */   {
/* 113 */     setRunnable(timerTask);
/* 114 */     this.delay = delay;
/*     */   }
/*     */ 
/*     */   public ScheduledTimerListener(Runnable timerTask, long delay, long period, boolean fixedRate)
/*     */   {
/* 125 */     setRunnable(timerTask);
/* 126 */     this.delay = delay;
/* 127 */     this.period = period;
/* 128 */     this.fixedRate = fixedRate;
/*     */   }
/*     */ 
/*     */   public void setRunnable(Runnable timerTask)
/*     */   {
/* 137 */     this.timerListener = new DelegatingTimerListener(timerTask);
/*     */   }
/*     */ 
/*     */   public void setTimerListener(TimerListener timerListener)
/*     */   {
/* 144 */     this.timerListener = timerListener;
/*     */   }
/*     */ 
/*     */   public TimerListener getTimerListener()
/*     */   {
/* 151 */     return this.timerListener;
/*     */   }
/*     */ 
/*     */   public void setDelay(long delay)
/*     */   {
/* 162 */     this.delay = delay;
/*     */   }
/*     */ 
/*     */   public long getDelay()
/*     */   {
/* 169 */     return this.delay;
/*     */   }
/*     */ 
/*     */   public void setPeriod(long period)
/*     */   {
/* 188 */     this.period = period;
/*     */   }
/*     */ 
/*     */   public long getPeriod()
/*     */   {
/* 195 */     return this.period;
/*     */   }
/*     */ 
/*     */   public boolean isOneTimeTask()
/*     */   {
/* 204 */     return this.period < 0L;
/*     */   }
/*     */ 
/*     */   public void setFixedRate(boolean fixedRate)
/*     */   {
/* 215 */     this.fixedRate = fixedRate;
/*     */   }
/*     */ 
/*     */   public boolean isFixedRate()
/*     */   {
/* 222 */     return this.fixedRate;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.commonj.ScheduledTimerListener
 * JD-Core Version:    0.6.1
 */