/*     */ package org.springframework.scheduling.quartz;
/*     */ 
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ import java.util.TimeZone;
/*     */ import org.quartz.CronTrigger;
/*     */ import org.quartz.JobDataMap;
/*     */ import org.quartz.JobDetail;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.Constants;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class CronTriggerBean extends CronTrigger
/*     */   implements JobDetailAwareTrigger, BeanNameAware, InitializingBean
/*     */ {
/*  69 */   private static final Constants constants = new Constants(CronTrigger.class);
/*     */   private JobDetail jobDetail;
/*     */   private String beanName;
/*  76 */   private long startDelay = 0L;
/*     */ 
/*     */   public void setJobDataAsMap(Map<String, ?> jobDataAsMap)
/*     */   {
/*  88 */     getJobDataMap().putAll(jobDataAsMap);
/*     */   }
/*     */ 
/*     */   public void setMisfireInstructionName(String constantName)
/*     */   {
/* 100 */     setMisfireInstruction(constants.asNumber(constantName).intValue());
/*     */   }
/*     */ 
/*     */   public void setTriggerListenerNames(String[] names)
/*     */   {
/* 112 */     for (String name : names)
/* 113 */       addTriggerListener(name);
/*     */   }
/*     */ 
/*     */   public void setStartDelay(long startDelay)
/*     */   {
/* 126 */     Assert.state(startDelay >= 0L, "Start delay cannot be negative.");
/* 127 */     this.startDelay = startDelay;
/*     */   }
/*     */ 
/*     */   public void setJobDetail(JobDetail jobDetail)
/*     */   {
/* 139 */     this.jobDetail = jobDetail;
/*     */   }
/*     */ 
/*     */   public JobDetail getJobDetail() {
/* 143 */     return this.jobDetail;
/*     */   }
/*     */ 
/*     */   public void setBeanName(String beanName) {
/* 147 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws Exception
/*     */   {
/* 156 */     if (getName() == null) {
/* 157 */       setName(this.beanName);
/*     */     }
/* 159 */     if (getGroup() == null) {
/* 160 */       setGroup("DEFAULT");
/*     */     }
/* 162 */     if ((this.startDelay > 0L) || (getStartTime() == null)) {
/* 163 */       setStartTime(new Date(System.currentTimeMillis() + this.startDelay));
/*     */     }
/* 165 */     if (getTimeZone() == null) {
/* 166 */       setTimeZone(TimeZone.getDefault());
/*     */     }
/* 168 */     if (this.jobDetail != null) {
/* 169 */       setJobName(this.jobDetail.getName());
/* 170 */       setJobGroup(this.jobDetail.getGroup());
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.quartz.CronTriggerBean
 * JD-Core Version:    0.6.1
 */