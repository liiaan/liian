/*    */ package org.springframework.scheduling.commonj;
/*    */ 
/*    */ import commonj.timers.Timer;
/*    */ import commonj.timers.TimerListener;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class DelegatingTimerListener
/*    */   implements TimerListener
/*    */ {
/*    */   private final Runnable runnable;
/*    */ 
/*    */   public DelegatingTimerListener(Runnable runnable)
/*    */   {
/* 42 */     Assert.notNull(runnable, "Runnable is required");
/* 43 */     this.runnable = runnable;
/*    */   }
/*    */ 
/*    */   public void timerExpired(Timer timer)
/*    */   {
/* 51 */     this.runnable.run();
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.commonj.DelegatingTimerListener
 * JD-Core Version:    0.6.1
 */