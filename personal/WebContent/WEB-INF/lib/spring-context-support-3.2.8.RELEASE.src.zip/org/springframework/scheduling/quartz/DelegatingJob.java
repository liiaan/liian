/*    */ package org.springframework.scheduling.quartz;
/*    */ 
/*    */ import org.quartz.Job;
/*    */ import org.quartz.JobExecutionContext;
/*    */ import org.quartz.JobExecutionException;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class DelegatingJob
/*    */   implements Job
/*    */ {
/*    */   private final Runnable delegate;
/*    */ 
/*    */   public DelegatingJob(Runnable delegate)
/*    */   {
/* 48 */     Assert.notNull(delegate, "Delegate must not be null");
/* 49 */     this.delegate = delegate;
/*    */   }
/*    */ 
/*    */   public final Runnable getDelegate()
/*    */   {
/* 56 */     return this.delegate;
/*    */   }
/*    */ 
/*    */   public void execute(JobExecutionContext context)
/*    */     throws JobExecutionException
/*    */   {
/* 64 */     this.delegate.run();
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.quartz.DelegatingJob
 * JD-Core Version:    0.6.1
 */