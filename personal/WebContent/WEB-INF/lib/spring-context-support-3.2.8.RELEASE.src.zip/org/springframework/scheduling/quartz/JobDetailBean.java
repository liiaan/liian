/*     */ package org.springframework.scheduling.quartz;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.quartz.Job;
/*     */ import org.quartz.JobDataMap;
/*     */ import org.quartz.JobDetail;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ 
/*     */ public class JobDetailBean extends JobDetail
/*     */   implements BeanNameAware, ApplicationContextAware, InitializingBean
/*     */ {
/*     */   private Class<?> actualJobClass;
/*     */   private String beanName;
/*     */   private ApplicationContext applicationContext;
/*     */   private String applicationContextJobDataKey;
/*     */ 
/*     */   public void setJobClass(Class jobClass)
/*     */   {
/*  71 */     if ((jobClass != null) && (!Job.class.isAssignableFrom(jobClass))) {
/*  72 */       super.setJobClass(DelegatingJob.class);
/*  73 */       this.actualJobClass = jobClass;
/*     */     }
/*     */     else {
/*  76 */       super.setJobClass(jobClass);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Class getJobClass()
/*     */   {
/*  86 */     return this.actualJobClass != null ? this.actualJobClass : super.getJobClass();
/*     */   }
/*     */ 
/*     */   public void setJobDataAsMap(Map<String, ?> jobDataAsMap)
/*     */   {
/* 101 */     getJobDataMap().putAll(jobDataAsMap);
/*     */   }
/*     */ 
/*     */   public void setJobListenerNames(String[] names)
/*     */   {
/* 113 */     for (String name : names)
/* 114 */       addJobListener(name);
/*     */   }
/*     */ 
/*     */   public void setBeanName(String beanName)
/*     */   {
/* 119 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */   public void setApplicationContext(ApplicationContext applicationContext) {
/* 123 */     this.applicationContext = applicationContext;
/*     */   }
/*     */ 
/*     */   public void setApplicationContextJobDataKey(String applicationContextJobDataKey)
/*     */   {
/* 143 */     this.applicationContextJobDataKey = applicationContextJobDataKey;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 148 */     if (getName() == null) {
/* 149 */       setName(this.beanName);
/*     */     }
/* 151 */     if (getGroup() == null) {
/* 152 */       setGroup("DEFAULT");
/*     */     }
/* 154 */     if (this.applicationContextJobDataKey != null) {
/* 155 */       if (this.applicationContext == null) {
/* 156 */         throw new IllegalStateException("JobDetailBean needs to be set up in an ApplicationContext to be able to handle an 'applicationContextJobDataKey'");
/*     */       }
/*     */ 
/* 160 */       getJobDataMap().put(this.applicationContextJobDataKey, this.applicationContext);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.quartz.JobDetailBean
 * JD-Core Version:    0.6.1
 */