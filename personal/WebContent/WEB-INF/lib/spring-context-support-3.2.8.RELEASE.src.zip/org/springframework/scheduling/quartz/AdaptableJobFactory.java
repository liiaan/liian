/*    */ package org.springframework.scheduling.quartz;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.quartz.Job;
/*    */ import org.quartz.Scheduler;
/*    */ import org.quartz.SchedulerException;
/*    */ import org.quartz.spi.JobFactory;
/*    */ import org.quartz.spi.TriggerFiredBundle;
/*    */ import org.springframework.util.ReflectionUtils;
/*    */ 
/*    */ public class AdaptableJobFactory
/*    */   implements JobFactory
/*    */ {
/*    */   public Job newJob(TriggerFiredBundle bundle, Scheduler scheduler)
/*    */     throws SchedulerException
/*    */   {
/* 47 */     return newJob(bundle);
/*    */   }
/*    */ 
/*    */   public Job newJob(TriggerFiredBundle bundle)
/*    */     throws SchedulerException
/*    */   {
/*    */     try
/*    */     {
/* 55 */       Object jobObject = createJobInstance(bundle);
/* 56 */       return adaptJob(jobObject);
/*    */     }
/*    */     catch (Exception ex) {
/* 59 */       throw new SchedulerException("Job instantiation failed", ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   protected Object createJobInstance(TriggerFiredBundle bundle)
/*    */     throws Exception
/*    */   {
/* 73 */     Method getJobDetail = bundle.getClass().getMethod("getJobDetail", new Class[0]);
/* 74 */     Object jobDetail = ReflectionUtils.invokeMethod(getJobDetail, bundle);
/* 75 */     Method getJobClass = jobDetail.getClass().getMethod("getJobClass", new Class[0]);
/* 76 */     Class jobClass = (Class)ReflectionUtils.invokeMethod(getJobClass, jobDetail);
/* 77 */     return jobClass.newInstance();
/*    */   }
/*    */ 
/*    */   protected Job adaptJob(Object jobObject)
/*    */     throws Exception
/*    */   {
/* 90 */     if ((jobObject instanceof Job)) {
/* 91 */       return (Job)jobObject;
/*    */     }
/* 93 */     if ((jobObject instanceof Runnable)) {
/* 94 */       return new DelegatingJob((Runnable)jobObject);
/*    */     }
/*    */ 
/* 97 */     throw new IllegalArgumentException("Unable to execute job class [" + jobObject.getClass().getName() + "]: only [org.quartz.Job] and [java.lang.Runnable] supported.");
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.quartz.AdaptableJobFactory
 * JD-Core Version:    0.6.1
 */