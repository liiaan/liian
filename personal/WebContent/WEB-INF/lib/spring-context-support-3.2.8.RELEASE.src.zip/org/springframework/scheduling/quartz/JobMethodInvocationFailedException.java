/*    */ package org.springframework.scheduling.quartz;
/*    */ 
/*    */ import org.springframework.core.NestedRuntimeException;
/*    */ import org.springframework.util.MethodInvoker;
/*    */ 
/*    */ public class JobMethodInvocationFailedException extends NestedRuntimeException
/*    */ {
/*    */   public JobMethodInvocationFailedException(MethodInvoker methodInvoker, Throwable cause)
/*    */   {
/* 40 */     super("Invocation of method '" + methodInvoker.getTargetMethod() + "' on target class [" + methodInvoker.getTargetClass() + "] failed", cause);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.quartz.JobMethodInvocationFailedException
 * JD-Core Version:    0.6.1
 */