/*     */ package org.springframework.scheduling.commonj;
/*     */ 
/*     */ import commonj.timers.Timer;
/*     */ import commonj.timers.TimerManager;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import javax.naming.NamingException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.Lifecycle;
/*     */ 
/*     */ public class TimerManagerFactoryBean extends TimerManagerAccessor
/*     */   implements FactoryBean<TimerManager>, InitializingBean, DisposableBean, Lifecycle
/*     */ {
/*     */   private ScheduledTimerListener[] scheduledTimerListeners;
/*  59 */   private final List<Timer> timers = new LinkedList();
/*     */ 
/*     */   public void setScheduledTimerListeners(ScheduledTimerListener[] scheduledTimerListeners)
/*     */   {
/*  71 */     this.scheduledTimerListeners = scheduledTimerListeners;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws NamingException
/*     */   {
/*  80 */     super.afterPropertiesSet();
/*  81 */     if (this.scheduledTimerListeners != null) {
/*  82 */       TimerManager timerManager = getTimerManager();
/*  83 */       for (ScheduledTimerListener scheduledTask : this.scheduledTimerListeners)
/*     */       {
/*     */         Timer timer;
/*     */         Timer timer;
/*  85 */         if (scheduledTask.isOneTimeTask()) {
/*  86 */           timer = timerManager.schedule(scheduledTask.getTimerListener(), scheduledTask.getDelay());
/*     */         }
/*     */         else
/*     */         {
/*     */           Timer timer;
/*  89 */           if (scheduledTask.isFixedRate()) {
/*  90 */             timer = timerManager.scheduleAtFixedRate(scheduledTask.getTimerListener(), scheduledTask.getDelay(), scheduledTask.getPeriod());
/*     */           }
/*     */           else
/*     */           {
/*  94 */             timer = timerManager.schedule(scheduledTask.getTimerListener(), scheduledTask.getDelay(), scheduledTask.getPeriod());
/*     */           }
/*     */         }
/*     */ 
/*  98 */         this.timers.add(timer);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public TimerManager getObject()
/*     */   {
/* 109 */     return getTimerManager();
/*     */   }
/*     */ 
/*     */   public Class<? extends TimerManager> getObjectType() {
/* 113 */     TimerManager timerManager = getTimerManager();
/* 114 */     return timerManager != null ? timerManager.getClass() : TimerManager.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton() {
/* 118 */     return true;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 135 */     for (Timer timer : this.timers) {
/*     */       try {
/* 137 */         timer.cancel();
/*     */       }
/*     */       catch (Throwable ex) {
/* 140 */         this.logger.warn("Could not cancel CommonJ Timer", ex);
/*     */       }
/*     */     }
/* 143 */     this.timers.clear();
/*     */ 
/* 146 */     super.destroy();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.commonj.TimerManagerFactoryBean
 * JD-Core Version:    0.6.1
 */