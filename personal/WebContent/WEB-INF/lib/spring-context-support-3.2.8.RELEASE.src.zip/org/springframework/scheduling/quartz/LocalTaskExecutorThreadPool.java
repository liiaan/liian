/*    */ package org.springframework.scheduling.quartz;
/*    */ 
/*    */ import java.util.concurrent.Executor;
/*    */ import java.util.concurrent.RejectedExecutionException;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.quartz.SchedulerConfigException;
/*    */ import org.quartz.spi.ThreadPool;
/*    */ 
/*    */ public class LocalTaskExecutorThreadPool
/*    */   implements ThreadPool
/*    */ {
/* 38 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */   private Executor taskExecutor;
/*    */ 
/*    */   public void setInstanceId(String schedInstId)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void setInstanceName(String schedName)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void initialize()
/*    */     throws SchedulerConfigException
/*    */   {
/* 52 */     this.taskExecutor = SchedulerFactoryBean.getConfigTimeTaskExecutor();
/* 53 */     if (this.taskExecutor == null)
/* 54 */       throw new SchedulerConfigException("No local TaskExecutor found for configuration - 'taskExecutor' property must be set on SchedulerFactoryBean");
/*    */   }
/*    */ 
/*    */   public void shutdown(boolean waitForJobsToComplete)
/*    */   {
/*    */   }
/*    */ 
/*    */   public int getPoolSize()
/*    */   {
/* 64 */     return -1;
/*    */   }
/*    */ 
/*    */   public boolean runInThread(Runnable runnable)
/*    */   {
/* 69 */     if (runnable == null)
/* 70 */       return false;
/*    */     try
/*    */     {
/* 73 */       this.taskExecutor.execute(runnable);
/* 74 */       return true;
/*    */     }
/*    */     catch (RejectedExecutionException ex) {
/* 77 */       this.logger.error("Task has been rejected by TaskExecutor", ex);
/* 78 */     }return false;
/*    */   }
/*    */ 
/*    */   public int blockForAvailableThreads()
/*    */   {
/* 88 */     return 1;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.quartz.LocalTaskExecutorThreadPool
 * JD-Core Version:    0.6.1
 */