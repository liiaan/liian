/*     */ package org.springframework.scheduling.quartz;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Map;
/*     */ import org.quartz.Job;
/*     */ import org.quartz.JobExecutionContext;
/*     */ import org.quartz.JobExecutionException;
/*     */ import org.quartz.Scheduler;
/*     */ import org.quartz.SchedulerException;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.PropertyAccessorFactory;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public abstract class QuartzJobBean
/*     */   implements Job
/*     */ {
/*     */   private static final Method getSchedulerMethod;
/*     */   private static final Method getMergedJobDataMapMethod;
/*     */ 
/*     */   public final void execute(JobExecutionContext context)
/*     */     throws JobExecutionException
/*     */   {
/*     */     try
/*     */     {
/* 101 */       Scheduler scheduler = (Scheduler)ReflectionUtils.invokeMethod(getSchedulerMethod, context);
/* 102 */       Map mergedJobDataMap = (Map)ReflectionUtils.invokeMethod(getMergedJobDataMapMethod, context);
/*     */ 
/* 104 */       BeanWrapper bw = PropertyAccessorFactory.forBeanPropertyAccess(this);
/* 105 */       MutablePropertyValues pvs = new MutablePropertyValues();
/* 106 */       pvs.addPropertyValues(scheduler.getContext());
/* 107 */       pvs.addPropertyValues(mergedJobDataMap);
/* 108 */       bw.setPropertyValues(pvs, true);
/*     */     }
/*     */     catch (SchedulerException ex) {
/* 111 */       throw new JobExecutionException(ex);
/*     */     }
/* 113 */     executeInternal(context);
/*     */   }
/*     */ 
/*     */   protected abstract void executeInternal(JobExecutionContext paramJobExecutionContext)
/*     */     throws JobExecutionException;
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  82 */       Class jobExecutionContextClass = QuartzJobBean.class.getClassLoader().loadClass("org.quartz.JobExecutionContext");
/*     */ 
/*  84 */       getSchedulerMethod = jobExecutionContextClass.getMethod("getScheduler", new Class[0]);
/*  85 */       getMergedJobDataMapMethod = jobExecutionContextClass.getMethod("getMergedJobDataMap", new Class[0]);
/*     */     }
/*     */     catch (Exception ex) {
/*  88 */       throw new IllegalStateException("Incompatible Quartz API: " + ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.quartz.QuartzJobBean
 * JD-Core Version:    0.6.1
 */