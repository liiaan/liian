/*     */ package org.springframework.scheduling.quartz;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.quartz.spi.ClassLoadHelper;
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ 
/*     */ public class ResourceLoaderClassLoadHelper
/*     */   implements ClassLoadHelper
/*     */ {
/*  43 */   protected static final Log logger = LogFactory.getLog(ResourceLoaderClassLoadHelper.class);
/*     */   private ResourceLoader resourceLoader;
/*     */ 
/*     */   public ResourceLoaderClassLoadHelper()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ResourceLoaderClassLoadHelper(ResourceLoader resourceLoader)
/*     */   {
/*  61 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */   public void initialize()
/*     */   {
/*  66 */     if (this.resourceLoader == null) {
/*  67 */       this.resourceLoader = SchedulerFactoryBean.getConfigTimeResourceLoader();
/*  68 */       if (this.resourceLoader == null)
/*  69 */         this.resourceLoader = new DefaultResourceLoader();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Class loadClass(String name) throws ClassNotFoundException
/*     */   {
/*  75 */     return this.resourceLoader.getClassLoader().loadClass(name);
/*     */   }
/*     */ 
/*     */   public <T> Class<? extends T> loadClass(String name, Class<T> clazz) throws ClassNotFoundException
/*     */   {
/*  80 */     return loadClass(name);
/*     */   }
/*     */ 
/*     */   public URL getResource(String name) {
/*  84 */     Resource resource = this.resourceLoader.getResource(name);
/*     */     try {
/*  86 */       return resource.getURL();
/*     */     }
/*     */     catch (FileNotFoundException ex) {
/*  89 */       return null;
/*     */     }
/*     */     catch (IOException ex) {
/*  92 */       logger.warn("Could not load " + resource);
/*  93 */     }return null;
/*     */   }
/*     */ 
/*     */   public InputStream getResourceAsStream(String name)
/*     */   {
/*  98 */     Resource resource = this.resourceLoader.getResource(name);
/*     */     try {
/* 100 */       return resource.getInputStream();
/*     */     }
/*     */     catch (FileNotFoundException ex) {
/* 103 */       return null;
/*     */     }
/*     */     catch (IOException ex) {
/* 106 */       logger.warn("Could not load " + resource);
/* 107 */     }return null;
/*     */   }
/*     */ 
/*     */   public ClassLoader getClassLoader()
/*     */   {
/* 112 */     return this.resourceLoader.getClassLoader();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.quartz.ResourceLoaderClassLoadHelper
 * JD-Core Version:    0.6.1
 */