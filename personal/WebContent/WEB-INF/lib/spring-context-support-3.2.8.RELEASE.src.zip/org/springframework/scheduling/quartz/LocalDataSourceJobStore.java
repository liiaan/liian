/*     */ package org.springframework.scheduling.quartz;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import javax.sql.DataSource;
/*     */ import org.quartz.SchedulerConfigException;
/*     */ import org.quartz.impl.jdbcjobstore.JobStoreCMT;
/*     */ import org.quartz.impl.jdbcjobstore.SimpleSemaphore;
/*     */ import org.quartz.spi.ClassLoadHelper;
/*     */ import org.quartz.spi.SchedulerSignaler;
/*     */ import org.quartz.utils.ConnectionProvider;
/*     */ import org.quartz.utils.DBConnectionManager;
/*     */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.jdbc.support.MetaDataAccessException;
/*     */ 
/*     */ public class LocalDataSourceJobStore extends JobStoreCMT
/*     */ {
/*     */   public static final String TX_DATA_SOURCE_PREFIX = "springTxDataSource.";
/*     */   public static final String NON_TX_DATA_SOURCE_PREFIX = "springNonTxDataSource.";
/*     */   private DataSource dataSource;
/*     */ 
/*     */   public void initialize(ClassLoadHelper loadHelper, SchedulerSignaler signaler)
/*     */     throws SchedulerConfigException
/*     */   {
/*  88 */     this.dataSource = SchedulerFactoryBean.getConfigTimeDataSource();
/*  89 */     if (this.dataSource == null) {
/*  90 */       throw new SchedulerConfigException("No local DataSource found for configuration - 'dataSource' property must be set on SchedulerFactoryBean");
/*     */     }
/*     */ 
/*  96 */     setDataSource("springTxDataSource." + getInstanceName());
/*  97 */     setDontSetAutoCommitFalse(true);
/*     */ 
/* 100 */     DBConnectionManager.getInstance().addConnectionProvider("springTxDataSource." + getInstanceName(), new ConnectionProvider()
/*     */     {
/*     */       public Connection getConnection()
/*     */         throws SQLException
/*     */       {
/* 105 */         return DataSourceUtils.doGetConnection(LocalDataSourceJobStore.this.dataSource);
/*     */       }
/*     */ 
/*     */       public void shutdown()
/*     */       {
/*     */       }
/*     */ 
/*     */       public void initialize()
/*     */       {
/*     */       }
/*     */     });
/* 119 */     DataSource nonTxDataSource = SchedulerFactoryBean.getConfigTimeNonTransactionalDataSource();
/* 120 */     final DataSource nonTxDataSourceToUse = nonTxDataSource != null ? nonTxDataSource : this.dataSource;
/*     */ 
/* 123 */     setNonManagedTXDataSource("springNonTxDataSource." + getInstanceName());
/*     */ 
/* 126 */     DBConnectionManager.getInstance().addConnectionProvider("springNonTxDataSource." + getInstanceName(), new ConnectionProvider()
/*     */     {
/*     */       public Connection getConnection()
/*     */         throws SQLException
/*     */       {
/* 131 */         return nonTxDataSourceToUse.getConnection();
/*     */       }
/*     */ 
/*     */       public void shutdown()
/*     */       {
/*     */       }
/*     */ 
/*     */       public void initialize()
/*     */       {
/*     */       }
/*     */     });
/*     */     try
/*     */     {
/* 145 */       String productName = JdbcUtils.extractDatabaseMetaData(this.dataSource, "getDatabaseProductName").toString();
/* 146 */       productName = JdbcUtils.commonDatabaseName(productName);
/* 147 */       if ((productName != null) && (productName.toLowerCase().contains("hsql"))) {
/* 148 */         setUseDBLocks(false);
/* 149 */         setLockHandler(new SimpleSemaphore());
/*     */       }
/*     */     }
/*     */     catch (MetaDataAccessException ex) {
/* 153 */       logWarnIfNonZero(1, "Could not detect database type. Assuming locks can be taken.");
/*     */     }
/*     */ 
/* 156 */     super.initialize(loadHelper, signaler);
/*     */   }
/*     */ 
/*     */   protected void closeConnection(Connection con)
/*     */   {
/* 163 */     DataSourceUtils.releaseConnection(con, this.dataSource);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.quartz.LocalDataSourceJobStore
 * JD-Core Version:    0.6.1
 */