/*     */ package org.springframework.scheduling.quartz;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ import org.quartz.JobDataMap;
/*     */ import org.quartz.JobDetail;
/*     */ import org.quartz.SimpleTrigger;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.Constants;
/*     */ 
/*     */ public class SimpleTriggerBean extends SimpleTrigger
/*     */   implements JobDetailAwareTrigger, BeanNameAware, InitializingBean
/*     */ {
/*  68 */   private static final Constants constants = new Constants(SimpleTrigger.class);
/*     */ 
/*  71 */   private long startDelay = 0L;
/*     */   private JobDetail jobDetail;
/*     */   private String beanName;
/*     */ 
/*     */   public SimpleTriggerBean()
/*     */   {
/*  79 */     setRepeatCount(-1);
/*     */   }
/*     */ 
/*     */   public void setJobDataAsMap(Map<String, ?> jobDataAsMap)
/*     */   {
/*  91 */     getJobDataMap().putAll(jobDataAsMap);
/*     */   }
/*     */ 
/*     */   public void setMisfireInstructionName(String constantName)
/*     */   {
/* 106 */     setMisfireInstruction(constants.asNumber(constantName).intValue());
/*     */   }
/*     */ 
/*     */   public void setTriggerListenerNames(String[] names)
/*     */   {
/* 118 */     for (String name : names)
/* 119 */       addTriggerListener(name);
/*     */   }
/*     */ 
/*     */   public void setStartDelay(long startDelay)
/*     */   {
/* 132 */     this.startDelay = startDelay;
/*     */   }
/*     */ 
/*     */   public void setJobDetail(JobDetail jobDetail)
/*     */   {
/* 144 */     this.jobDetail = jobDetail;
/*     */   }
/*     */ 
/*     */   public JobDetail getJobDetail() {
/* 148 */     return this.jobDetail;
/*     */   }
/*     */ 
/*     */   public void setBeanName(String beanName) {
/* 152 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws ParseException
/*     */   {
/* 161 */     if (getName() == null) {
/* 162 */       setName(this.beanName);
/*     */     }
/* 164 */     if (getGroup() == null) {
/* 165 */       setGroup("DEFAULT");
/*     */     }
/* 167 */     if ((this.startDelay > 0L) || (getStartTime() == null)) {
/* 168 */       setStartTime(new Date(System.currentTimeMillis() + this.startDelay));
/*     */     }
/* 170 */     if (this.jobDetail != null) {
/* 171 */       setJobName(this.jobDetail.getName());
/* 172 */       setJobGroup(this.jobDetail.getGroup());
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.quartz.SimpleTriggerBean
 * JD-Core Version:    0.6.1
 */