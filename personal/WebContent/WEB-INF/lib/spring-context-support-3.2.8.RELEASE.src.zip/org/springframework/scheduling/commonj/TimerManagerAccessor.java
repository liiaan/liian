/*     */ package org.springframework.scheduling.commonj;
/*     */ 
/*     */ import commonj.timers.TimerManager;
/*     */ import javax.naming.NamingException;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.Lifecycle;
/*     */ import org.springframework.jndi.JndiLocatorSupport;
/*     */ 
/*     */ public abstract class TimerManagerAccessor extends JndiLocatorSupport
/*     */   implements InitializingBean, DisposableBean, Lifecycle
/*     */ {
/*     */   private TimerManager timerManager;
/*     */   private String timerManagerName;
/*  43 */   private boolean shared = false;
/*     */ 
/*     */   public void setTimerManager(TimerManager timerManager)
/*     */   {
/*  55 */     this.timerManager = timerManager;
/*     */   }
/*     */ 
/*     */   public void setTimerManagerName(String timerManagerName)
/*     */   {
/*  66 */     this.timerManagerName = timerManagerName;
/*     */   }
/*     */ 
/*     */   public void setShared(boolean shared)
/*     */   {
/*  94 */     this.shared = shared;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() throws NamingException
/*     */   {
/*  99 */     if (this.timerManager == null) {
/* 100 */       if (this.timerManagerName == null) {
/* 101 */         throw new IllegalArgumentException("Either 'timerManager' or 'timerManagerName' must be specified");
/*     */       }
/* 103 */       this.timerManager = ((TimerManager)lookup(this.timerManagerName, TimerManager.class));
/*     */     }
/*     */   }
/*     */ 
/*     */   protected final TimerManager getTimerManager() {
/* 108 */     return this.timerManager;
/*     */   }
/*     */ 
/*     */   public void start()
/*     */   {
/* 121 */     if (!this.shared)
/* 122 */       this.timerManager.resume();
/*     */   }
/*     */ 
/*     */   public void stop()
/*     */   {
/* 131 */     if (!this.shared)
/* 132 */       this.timerManager.suspend();
/*     */   }
/*     */ 
/*     */   public boolean isRunning()
/*     */   {
/* 143 */     return (!this.timerManager.isSuspending()) && (!this.timerManager.isStopping());
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 157 */     if (!this.shared)
/*     */     {
/* 159 */       this.timerManager.stop();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.commonj.TimerManagerAccessor
 * JD-Core Version:    0.6.1
 */