/*     */ package org.springframework.scheduling.quartz;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.Executor;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.quartz.Scheduler;
/*     */ import org.quartz.SchedulerContext;
/*     */ import org.quartz.SchedulerException;
/*     */ import org.quartz.SchedulerFactory;
/*     */ import org.quartz.impl.RemoteScheduler;
/*     */ import org.quartz.impl.SchedulerRepository;
/*     */ import org.quartz.impl.StdSchedulerFactory;
/*     */ import org.quartz.simpl.SimpleThreadPool;
/*     */ import org.quartz.spi.JobFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ import org.springframework.context.SmartLifecycle;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.core.io.support.PropertiesLoaderUtils;
/*     */ import org.springframework.scheduling.SchedulingException;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.CollectionUtils;
/*     */ 
/*     */ public class SchedulerFactoryBean extends SchedulerAccessor
/*     */   implements FactoryBean<Scheduler>, BeanNameAware, ApplicationContextAware, InitializingBean, DisposableBean, SmartLifecycle
/*     */ {
/*     */   public static final String PROP_THREAD_COUNT = "org.quartz.threadPool.threadCount";
/*     */   public static final int DEFAULT_THREAD_COUNT = 10;
/*  96 */   private static final ThreadLocal<ResourceLoader> configTimeResourceLoaderHolder = new ThreadLocal();
/*     */ 
/*  99 */   private static final ThreadLocal<Executor> configTimeTaskExecutorHolder = new ThreadLocal();
/*     */ 
/* 102 */   private static final ThreadLocal<DataSource> configTimeDataSourceHolder = new ThreadLocal();
/*     */ 
/* 105 */   private static final ThreadLocal<DataSource> configTimeNonTransactionalDataSourceHolder = new ThreadLocal();
/*     */ 
/* 161 */   private Class<? extends SchedulerFactory> schedulerFactoryClass = StdSchedulerFactory.class;
/*     */   private String schedulerName;
/*     */   private Resource configLocation;
/*     */   private Properties quartzProperties;
/*     */   private Executor taskExecutor;
/*     */   private DataSource dataSource;
/*     */   private DataSource nonTransactionalDataSource;
/*     */   private Map<String, ?> schedulerContextMap;
/*     */   private ApplicationContext applicationContext;
/*     */   private String applicationContextSchedulerContextKey;
/*     */   private JobFactory jobFactory;
/* 185 */   private boolean jobFactorySet = false;
/*     */ 
/* 188 */   private boolean autoStartup = true;
/*     */ 
/* 190 */   private int startupDelay = 0;
/*     */ 
/* 192 */   private int phase = 2147483647;
/*     */ 
/* 194 */   private boolean exposeSchedulerInRepository = false;
/*     */ 
/* 196 */   private boolean waitForJobsToCompleteOnShutdown = false;
/*     */   private Scheduler scheduler;
/*     */ 
/*     */   public static ResourceLoader getConfigTimeResourceLoader()
/*     */   {
/* 118 */     return (ResourceLoader)configTimeResourceLoaderHolder.get();
/*     */   }
/*     */ 
/*     */   public static Executor getConfigTimeTaskExecutor()
/*     */   {
/* 131 */     return (Executor)configTimeTaskExecutorHolder.get();
/*     */   }
/*     */ 
/*     */   public static DataSource getConfigTimeDataSource()
/*     */   {
/* 144 */     return (DataSource)configTimeDataSourceHolder.get();
/*     */   }
/*     */ 
/*     */   public static DataSource getConfigTimeNonTransactionalDataSource()
/*     */   {
/* 157 */     return (DataSource)configTimeNonTransactionalDataSourceHolder.get();
/*     */   }
/*     */ 
/*     */   public void setSchedulerFactoryClass(Class<? extends SchedulerFactory> schedulerFactoryClass)
/*     */   {
/* 213 */     Assert.isAssignable(SchedulerFactory.class, schedulerFactoryClass);
/* 214 */     this.schedulerFactoryClass = schedulerFactoryClass;
/*     */   }
/*     */ 
/*     */   public void setSchedulerName(String schedulerName)
/*     */   {
/* 225 */     this.schedulerName = schedulerName;
/*     */   }
/*     */ 
/*     */   public void setConfigLocation(Resource configLocation)
/*     */   {
/* 236 */     this.configLocation = configLocation;
/*     */   }
/*     */ 
/*     */   public void setQuartzProperties(Properties quartzProperties)
/*     */   {
/* 246 */     this.quartzProperties = quartzProperties;
/*     */   }
/*     */ 
/*     */   public void setTaskExecutor(Executor taskExecutor)
/*     */   {
/* 263 */     this.taskExecutor = taskExecutor;
/*     */   }
/*     */ 
/*     */   public void setDataSource(DataSource dataSource)
/*     */   {
/* 287 */     this.dataSource = dataSource;
/*     */   }
/*     */ 
/*     */   public void setNonTransactionalDataSource(DataSource nonTransactionalDataSource)
/*     */   {
/* 301 */     this.nonTransactionalDataSource = nonTransactionalDataSource;
/*     */   }
/*     */ 
/*     */   public void setSchedulerContextAsMap(Map<String, ?> schedulerContextAsMap)
/*     */   {
/* 316 */     this.schedulerContextMap = schedulerContextAsMap;
/*     */   }
/*     */ 
/*     */   public void setApplicationContextSchedulerContextKey(String applicationContextSchedulerContextKey)
/*     */   {
/* 336 */     this.applicationContextSchedulerContextKey = applicationContextSchedulerContextKey;
/*     */   }
/*     */ 
/*     */   public void setJobFactory(JobFactory jobFactory)
/*     */   {
/* 353 */     this.jobFactory = jobFactory;
/* 354 */     this.jobFactorySet = true;
/*     */   }
/*     */ 
/*     */   public void setAutoStartup(boolean autoStartup)
/*     */   {
/* 363 */     this.autoStartup = autoStartup;
/*     */   }
/*     */ 
/*     */   public boolean isAutoStartup()
/*     */   {
/* 372 */     return this.autoStartup;
/*     */   }
/*     */ 
/*     */   public void setPhase(int phase)
/*     */   {
/* 383 */     this.phase = phase;
/*     */   }
/*     */ 
/*     */   public int getPhase()
/*     */   {
/* 390 */     return this.phase;
/*     */   }
/*     */ 
/*     */   public void setStartupDelay(int startupDelay)
/*     */   {
/* 401 */     this.startupDelay = startupDelay;
/*     */   }
/*     */ 
/*     */   public void setExposeSchedulerInRepository(boolean exposeSchedulerInRepository)
/*     */   {
/* 414 */     this.exposeSchedulerInRepository = exposeSchedulerInRepository;
/*     */   }
/*     */ 
/*     */   public void setWaitForJobsToCompleteOnShutdown(boolean waitForJobsToCompleteOnShutdown)
/*     */   {
/* 424 */     this.waitForJobsToCompleteOnShutdown = waitForJobsToCompleteOnShutdown;
/*     */   }
/*     */ 
/*     */   public void setBeanName(String name)
/*     */   {
/* 429 */     if (this.schedulerName == null)
/* 430 */       this.schedulerName = name;
/*     */   }
/*     */ 
/*     */   public void setApplicationContext(ApplicationContext applicationContext)
/*     */   {
/* 435 */     this.applicationContext = applicationContext;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */     throws Exception
/*     */   {
/* 444 */     if ((this.dataSource == null) && (this.nonTransactionalDataSource != null)) {
/* 445 */       this.dataSource = this.nonTransactionalDataSource;
/*     */     }
/*     */ 
/* 448 */     if ((this.applicationContext != null) && (this.resourceLoader == null)) {
/* 449 */       this.resourceLoader = this.applicationContext;
/*     */     }
/*     */ 
/* 453 */     SchedulerFactory schedulerFactory = (SchedulerFactory)BeanUtils.instantiateClass(this.schedulerFactoryClass);
/* 454 */     initSchedulerFactory(schedulerFactory);
/*     */ 
/* 456 */     if (this.resourceLoader != null)
/*     */     {
/* 458 */       configTimeResourceLoaderHolder.set(this.resourceLoader);
/*     */     }
/* 460 */     if (this.taskExecutor != null)
/*     */     {
/* 462 */       configTimeTaskExecutorHolder.set(this.taskExecutor);
/*     */     }
/* 464 */     if (this.dataSource != null)
/*     */     {
/* 466 */       configTimeDataSourceHolder.set(this.dataSource);
/*     */     }
/* 468 */     if (this.nonTransactionalDataSource != null)
/*     */     {
/* 470 */       configTimeNonTransactionalDataSourceHolder.set(this.nonTransactionalDataSource);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 476 */       this.scheduler = createScheduler(schedulerFactory, this.schedulerName);
/* 477 */       populateSchedulerContext();
/*     */ 
/* 479 */       if ((!this.jobFactorySet) && (!(this.scheduler instanceof RemoteScheduler)))
/*     */       {
/* 482 */         this.jobFactory = new AdaptableJobFactory();
/*     */       }
/* 484 */       if (this.jobFactory != null) {
/* 485 */         if ((this.jobFactory instanceof SchedulerContextAware)) {
/* 486 */           ((SchedulerContextAware)this.jobFactory).setSchedulerContext(this.scheduler.getContext());
/*     */         }
/* 488 */         this.scheduler.setJobFactory(this.jobFactory);
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 493 */       if (this.resourceLoader != null) {
/* 494 */         configTimeResourceLoaderHolder.remove();
/*     */       }
/* 496 */       if (this.taskExecutor != null) {
/* 497 */         configTimeTaskExecutorHolder.remove();
/*     */       }
/* 499 */       if (this.dataSource != null) {
/* 500 */         configTimeDataSourceHolder.remove();
/*     */       }
/* 502 */       if (this.nonTransactionalDataSource != null) {
/* 503 */         configTimeNonTransactionalDataSourceHolder.remove();
/*     */       }
/*     */     }
/*     */ 
/* 507 */     registerListeners();
/* 508 */     registerJobsAndTriggers();
/*     */   }
/*     */ 
/*     */   private void initSchedulerFactory(SchedulerFactory schedulerFactory)
/*     */     throws SchedulerException, IOException
/*     */   {
/* 517 */     if (!(schedulerFactory instanceof StdSchedulerFactory)) {
/* 518 */       if ((this.configLocation != null) || (this.quartzProperties != null) || (this.taskExecutor != null) || (this.dataSource != null))
/*     */       {
/* 520 */         throw new IllegalArgumentException("StdSchedulerFactory required for applying Quartz properties: " + schedulerFactory);
/*     */       }
/*     */ 
/* 524 */       return;
/*     */     }
/*     */ 
/* 527 */     Properties mergedProps = new Properties();
/*     */ 
/* 529 */     if (this.resourceLoader != null) {
/* 530 */       mergedProps.setProperty("org.quartz.scheduler.classLoadHelper.class", ResourceLoaderClassLoadHelper.class.getName());
/*     */     }
/*     */ 
/* 534 */     if (this.taskExecutor != null) {
/* 535 */       mergedProps.setProperty("org.quartz.threadPool.class", LocalTaskExecutorThreadPool.class.getName());
/*     */     }
/*     */     else
/*     */     {
/* 541 */       mergedProps.setProperty("org.quartz.threadPool.class", SimpleThreadPool.class.getName());
/* 542 */       mergedProps.setProperty("org.quartz.threadPool.threadCount", Integer.toString(10));
/*     */     }
/*     */ 
/* 545 */     if (this.configLocation != null) {
/* 546 */       if (this.logger.isInfoEnabled()) {
/* 547 */         this.logger.info("Loading Quartz config from [" + this.configLocation + "]");
/*     */       }
/* 549 */       PropertiesLoaderUtils.fillProperties(mergedProps, this.configLocation);
/*     */     }
/*     */ 
/* 552 */     CollectionUtils.mergePropertiesIntoMap(this.quartzProperties, mergedProps);
/*     */ 
/* 554 */     if (this.dataSource != null) {
/* 555 */       mergedProps.put("org.quartz.jobStore.class", LocalDataSourceJobStore.class.getName());
/*     */     }
/*     */ 
/* 559 */     if (this.schedulerName != null) {
/* 560 */       mergedProps.put("org.quartz.scheduler.instanceName", this.schedulerName);
/*     */     }
/*     */ 
/* 563 */     ((StdSchedulerFactory)schedulerFactory).initialize(mergedProps);
/*     */   }
/*     */ 
/*     */   protected Scheduler createScheduler(SchedulerFactory schedulerFactory, String schedulerName)
/*     */     throws SchedulerException
/*     */   {
/* 582 */     Thread currentThread = Thread.currentThread();
/* 583 */     ClassLoader threadContextClassLoader = currentThread.getContextClassLoader();
/* 584 */     boolean overrideClassLoader = (this.resourceLoader != null) && (!this.resourceLoader.getClassLoader().equals(threadContextClassLoader));
/*     */ 
/* 586 */     if (overrideClassLoader)
/* 587 */       currentThread.setContextClassLoader(this.resourceLoader.getClassLoader());
/*     */     try
/*     */     {
/* 590 */       SchedulerRepository repository = SchedulerRepository.getInstance();
/* 591 */       synchronized (repository) {
/* 592 */         Scheduler existingScheduler = schedulerName != null ? repository.lookup(schedulerName) : null;
/* 593 */         Scheduler newScheduler = schedulerFactory.getScheduler();
/* 594 */         if (newScheduler == existingScheduler) {
/* 595 */           throw new IllegalStateException("Active Scheduler of name '" + schedulerName + "' already registered " + "in Quartz SchedulerRepository. Cannot create a new Spring-managed Scheduler of the same name!");
/*     */         }
/*     */ 
/* 598 */         if (!this.exposeSchedulerInRepository)
/*     */         {
/* 600 */           SchedulerRepository.getInstance().remove(newScheduler.getSchedulerName());
/*     */         }
/* 602 */         return newScheduler;
/*     */       }
/*     */     }
/*     */     finally {
/* 606 */       if (overrideClassLoader)
/*     */       {
/* 608 */         currentThread.setContextClassLoader(threadContextClassLoader);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void populateSchedulerContext()
/*     */     throws SchedulerException
/*     */   {
/* 619 */     if (this.schedulerContextMap != null) {
/* 620 */       this.scheduler.getContext().putAll(this.schedulerContextMap);
/*     */     }
/*     */ 
/* 624 */     if (this.applicationContextSchedulerContextKey != null) {
/* 625 */       if (this.applicationContext == null) {
/* 626 */         throw new IllegalStateException("SchedulerFactoryBean needs to be set up in an ApplicationContext to be able to handle an 'applicationContextSchedulerContextKey'");
/*     */       }
/*     */ 
/* 630 */       this.scheduler.getContext().put(this.applicationContextSchedulerContextKey, this.applicationContext);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void startScheduler(final Scheduler scheduler, final int startupDelay)
/*     */     throws SchedulerException
/*     */   {
/* 642 */     if (startupDelay <= 0) {
/* 643 */       this.logger.info("Starting Quartz Scheduler now");
/* 644 */       scheduler.start();
/*     */     }
/*     */     else {
/* 647 */       if (this.logger.isInfoEnabled()) {
/* 648 */         this.logger.info("Will start Quartz Scheduler [" + scheduler.getSchedulerName() + "] in " + startupDelay + " seconds");
/*     */       }
/*     */ 
/* 651 */       Thread schedulerThread = new Thread()
/*     */       {
/*     */         public void run() {
/*     */           try {
/* 655 */             Thread.sleep(startupDelay * 1000);
/*     */           }
/*     */           catch (InterruptedException ex)
/*     */           {
/*     */           }
/* 660 */           if (SchedulerFactoryBean.this.logger.isInfoEnabled())
/* 661 */             SchedulerFactoryBean.this.logger.info("Starting Quartz Scheduler now, after delay of " + startupDelay + " seconds");
/*     */           try
/*     */           {
/* 664 */             scheduler.start();
/*     */           }
/*     */           catch (SchedulerException ex) {
/* 667 */             throw new SchedulingException("Could not start Quartz Scheduler after delay", ex);
/*     */           }
/*     */         }
/*     */       };
/* 671 */       schedulerThread.setName("Quartz Scheduler [" + scheduler.getSchedulerName() + "]");
/* 672 */       schedulerThread.setDaemon(true);
/* 673 */       schedulerThread.start();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Scheduler getScheduler()
/*     */   {
/* 684 */     return this.scheduler;
/*     */   }
/*     */ 
/*     */   public Scheduler getObject() {
/* 688 */     return this.scheduler;
/*     */   }
/*     */ 
/*     */   public Class<? extends Scheduler> getObjectType() {
/* 692 */     return this.scheduler != null ? this.scheduler.getClass() : Scheduler.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton() {
/* 696 */     return true;
/*     */   }
/*     */ 
/*     */   public void start()
/*     */     throws SchedulingException
/*     */   {
/* 705 */     if (this.scheduler != null)
/*     */       try {
/* 707 */         startScheduler(this.scheduler, this.startupDelay);
/*     */       }
/*     */       catch (SchedulerException ex) {
/* 710 */         throw new SchedulingException("Could not start Quartz Scheduler", ex);
/*     */       }
/*     */   }
/*     */ 
/*     */   public void stop() throws SchedulingException
/*     */   {
/* 716 */     if (this.scheduler != null)
/*     */       try {
/* 718 */         this.scheduler.standby();
/*     */       }
/*     */       catch (SchedulerException ex) {
/* 721 */         throw new SchedulingException("Could not stop Quartz Scheduler", ex);
/*     */       }
/*     */   }
/*     */ 
/*     */   public void stop(Runnable callback) throws SchedulingException
/*     */   {
/* 727 */     stop();
/* 728 */     callback.run();
/*     */   }
/*     */ 
/*     */   public boolean isRunning() throws SchedulingException {
/* 732 */     if (this.scheduler != null) {
/*     */       try {
/* 734 */         return !this.scheduler.isInStandbyMode();
/*     */       }
/*     */       catch (SchedulerException ex) {
/* 737 */         return false;
/*     */       }
/*     */     }
/* 740 */     return false;
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */     throws SchedulerException
/*     */   {
/* 753 */     this.logger.info("Shutting down Quartz Scheduler");
/* 754 */     this.scheduler.shutdown(this.waitForJobsToCompleteOnShutdown);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.quartz.SchedulerFactoryBean
 * JD-Core Version:    0.6.1
 */