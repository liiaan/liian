/*     */ package org.springframework.scheduling.quartz;
/*     */ 
/*     */ import org.quartz.Scheduler;
/*     */ import org.quartz.SchedulerException;
/*     */ import org.quartz.impl.SchedulerRepository;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.factory.ListableBeanFactory;
/*     */ 
/*     */ public class SchedulerAccessorBean extends SchedulerAccessor
/*     */   implements BeanFactoryAware, InitializingBean
/*     */ {
/*     */   private String schedulerName;
/*     */   private Scheduler scheduler;
/*     */   private BeanFactory beanFactory;
/*     */ 
/*     */   public void setSchedulerName(String schedulerName)
/*     */   {
/*  58 */     this.schedulerName = schedulerName;
/*     */   }
/*     */ 
/*     */   public void setScheduler(Scheduler scheduler)
/*     */   {
/*  65 */     this.scheduler = scheduler;
/*     */   }
/*     */ 
/*     */   public Scheduler getScheduler()
/*     */   {
/*  73 */     return this.scheduler;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory) {
/*  77 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() throws SchedulerException
/*     */   {
/*  82 */     if (this.scheduler == null) {
/*  83 */       if (this.schedulerName != null) {
/*  84 */         this.scheduler = findScheduler(this.schedulerName);
/*     */       }
/*     */       else {
/*  87 */         throw new IllegalStateException("No Scheduler specified");
/*     */       }
/*     */     }
/*  90 */     registerListeners();
/*  91 */     registerJobsAndTriggers();
/*     */   }
/*     */ 
/*     */   protected Scheduler findScheduler(String schedulerName) throws SchedulerException {
/*  95 */     if ((this.beanFactory instanceof ListableBeanFactory)) {
/*  96 */       ListableBeanFactory lbf = (ListableBeanFactory)this.beanFactory;
/*  97 */       String[] beanNames = lbf.getBeanNamesForType(Scheduler.class);
/*  98 */       for (String beanName : beanNames) {
/*  99 */         Scheduler schedulerBean = (Scheduler)lbf.getBean(beanName);
/* 100 */         if (schedulerName.equals(schedulerBean.getSchedulerName())) {
/* 101 */           return schedulerBean;
/*     */         }
/*     */       }
/*     */     }
/* 105 */     Scheduler schedulerInRepo = SchedulerRepository.getInstance().lookup(schedulerName);
/* 106 */     if (schedulerInRepo == null) {
/* 107 */       throw new IllegalStateException("No Scheduler named '" + schedulerName + "' found");
/*     */     }
/* 109 */     return schedulerInRepo;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.quartz.SchedulerAccessorBean
 * JD-Core Version:    0.6.1
 */