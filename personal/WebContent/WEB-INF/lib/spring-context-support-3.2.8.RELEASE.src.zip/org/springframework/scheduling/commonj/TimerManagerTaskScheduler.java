/*     */ package org.springframework.scheduling.commonj;
/*     */ 
/*     */ import commonj.timers.Timer;
/*     */ import commonj.timers.TimerListener;
/*     */ import commonj.timers.TimerManager;
/*     */ import java.util.Date;
/*     */ import java.util.concurrent.Delayed;
/*     */ import java.util.concurrent.FutureTask;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.springframework.scheduling.TaskScheduler;
/*     */ import org.springframework.scheduling.Trigger;
/*     */ import org.springframework.scheduling.support.SimpleTriggerContext;
/*     */ import org.springframework.scheduling.support.TaskUtils;
/*     */ import org.springframework.util.ErrorHandler;
/*     */ 
/*     */ public class TimerManagerTaskScheduler extends TimerManagerAccessor
/*     */   implements TaskScheduler
/*     */ {
/*     */   private volatile ErrorHandler errorHandler;
/*     */ 
/*     */   public void setErrorHandler(ErrorHandler errorHandler)
/*     */   {
/*  51 */     this.errorHandler = errorHandler;
/*     */   }
/*     */ 
/*     */   public ScheduledFuture schedule(Runnable task, Trigger trigger)
/*     */   {
/*  56 */     return new ReschedulingTimerListener(errorHandlingTask(task, true), trigger).schedule();
/*     */   }
/*     */ 
/*     */   public ScheduledFuture schedule(Runnable task, Date startTime) {
/*  60 */     TimerScheduledFuture futureTask = new TimerScheduledFuture(errorHandlingTask(task, false));
/*  61 */     Timer timer = getTimerManager().schedule(futureTask, startTime);
/*  62 */     futureTask.setTimer(timer);
/*  63 */     return futureTask;
/*     */   }
/*     */ 
/*     */   public ScheduledFuture scheduleAtFixedRate(Runnable task, Date startTime, long period) {
/*  67 */     TimerScheduledFuture futureTask = new TimerScheduledFuture(errorHandlingTask(task, true));
/*  68 */     Timer timer = getTimerManager().scheduleAtFixedRate(futureTask, startTime, period);
/*  69 */     futureTask.setTimer(timer);
/*  70 */     return futureTask;
/*     */   }
/*     */ 
/*     */   public ScheduledFuture scheduleAtFixedRate(Runnable task, long period) {
/*  74 */     TimerScheduledFuture futureTask = new TimerScheduledFuture(errorHandlingTask(task, true));
/*  75 */     Timer timer = getTimerManager().scheduleAtFixedRate(futureTask, 0L, period);
/*  76 */     futureTask.setTimer(timer);
/*  77 */     return futureTask;
/*     */   }
/*     */ 
/*     */   public ScheduledFuture scheduleWithFixedDelay(Runnable task, Date startTime, long delay) {
/*  81 */     TimerScheduledFuture futureTask = new TimerScheduledFuture(errorHandlingTask(task, true));
/*  82 */     Timer timer = getTimerManager().schedule(futureTask, startTime, delay);
/*  83 */     futureTask.setTimer(timer);
/*  84 */     return futureTask;
/*     */   }
/*     */ 
/*     */   public ScheduledFuture scheduleWithFixedDelay(Runnable task, long delay) {
/*  88 */     TimerScheduledFuture futureTask = new TimerScheduledFuture(errorHandlingTask(task, true));
/*  89 */     Timer timer = getTimerManager().schedule(futureTask, 0L, delay);
/*  90 */     futureTask.setTimer(timer);
/*  91 */     return futureTask;
/*     */   }
/*     */ 
/*     */   private Runnable errorHandlingTask(Runnable delegate, boolean isRepeatingTask) {
/*  95 */     return TaskUtils.decorateTaskWithErrorHandler(delegate, this.errorHandler, isRepeatingTask);
/*     */   }
/*     */ 
/*     */   private class ReschedulingTimerListener extends TimerManagerTaskScheduler.TimerScheduledFuture
/*     */   {
/*     */     private final Trigger trigger;
/* 149 */     private final SimpleTriggerContext triggerContext = new SimpleTriggerContext();
/*     */     private volatile Date scheduledExecutionTime;
/*     */ 
/*     */     public ReschedulingTimerListener(Runnable runnable, Trigger trigger)
/*     */     {
/* 154 */       super();
/* 155 */       this.trigger = trigger;
/*     */     }
/*     */ 
/*     */     public ScheduledFuture schedule() {
/* 159 */       this.scheduledExecutionTime = this.trigger.nextExecutionTime(this.triggerContext);
/* 160 */       if (this.scheduledExecutionTime == null) {
/* 161 */         return null;
/*     */       }
/* 163 */       setTimer(TimerManagerTaskScheduler.this.getTimerManager().schedule(this, this.scheduledExecutionTime));
/* 164 */       return this;
/*     */     }
/*     */ 
/*     */     public void timerExpired(Timer timer)
/*     */     {
/* 169 */       Date actualExecutionTime = new Date();
/* 170 */       super.timerExpired(timer);
/* 171 */       Date completionTime = new Date();
/* 172 */       this.triggerContext.update(this.scheduledExecutionTime, actualExecutionTime, completionTime);
/* 173 */       if (!this.cancelled)
/* 174 */         schedule();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class TimerScheduledFuture extends FutureTask<Object>
/*     */     implements TimerListener, ScheduledFuture<Object>
/*     */   {
/*     */     protected transient Timer timer;
/* 106 */     protected transient boolean cancelled = false;
/*     */ 
/*     */     public TimerScheduledFuture(Runnable runnable) {
/* 109 */       super(null);
/*     */     }
/*     */ 
/*     */     public void setTimer(Timer timer) {
/* 113 */       this.timer = timer;
/*     */     }
/*     */ 
/*     */     public void timerExpired(Timer timer) {
/* 117 */       runAndReset();
/*     */     }
/*     */ 
/*     */     public boolean cancel(boolean mayInterruptIfRunning)
/*     */     {
/* 122 */       boolean result = super.cancel(mayInterruptIfRunning);
/* 123 */       this.timer.cancel();
/* 124 */       this.cancelled = true;
/* 125 */       return result;
/*     */     }
/*     */ 
/*     */     public long getDelay(TimeUnit unit) {
/* 129 */       return unit.convert(System.currentTimeMillis() - this.timer.getScheduledExecutionTime(), TimeUnit.MILLISECONDS);
/*     */     }
/*     */ 
/*     */     public int compareTo(Delayed other) {
/* 133 */       if (this == other) {
/* 134 */         return 0;
/*     */       }
/* 136 */       long diff = getDelay(TimeUnit.MILLISECONDS) - other.getDelay(TimeUnit.MILLISECONDS);
/* 137 */       return diff < 0L ? -1 : diff == 0L ? 0 : 1;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.commonj.TimerManagerTaskScheduler
 * JD-Core Version:    0.6.1
 */