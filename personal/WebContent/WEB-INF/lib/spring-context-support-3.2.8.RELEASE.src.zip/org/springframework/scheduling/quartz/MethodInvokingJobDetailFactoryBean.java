/*     */ package org.springframework.scheduling.quartz;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.quartz.JobDataMap;
/*     */ import org.quartz.JobDetail;
/*     */ import org.quartz.JobExecutionContext;
/*     */ import org.quartz.JobExecutionException;
/*     */ import org.quartz.StatefulJob;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.PropertyAccessorFactory;
/*     */ import org.springframework.beans.factory.BeanClassLoaderAware;
/*     */ import org.springframework.beans.factory.BeanFactory;
/*     */ import org.springframework.beans.factory.BeanFactoryAware;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.beans.support.ArgumentConvertingMethodInvoker;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ import org.springframework.util.MethodInvoker;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class MethodInvokingJobDetailFactoryBean extends ArgumentConvertingMethodInvoker
/*     */   implements FactoryBean<JobDetail>, BeanNameAware, BeanClassLoaderAware, BeanFactoryAware, InitializingBean
/*     */ {
/*     */   private static Class<?> jobDetailImplClass;
/*     */   private static Method setResultMethod;
/*     */   private String name;
/*     */   private String group;
/*     */   private boolean concurrent;
/*     */   private String targetBeanName;
/*     */   private String[] jobListenerNames;
/*     */   private String beanName;
/*     */   private ClassLoader beanClassLoader;
/*     */   private BeanFactory beanFactory;
/*     */   private JobDetail jobDetail;
/*     */ 
/*     */   public MethodInvokingJobDetailFactoryBean()
/*     */   {
/* 107 */     this.group = "DEFAULT";
/*     */ 
/* 109 */     this.concurrent = true;
/*     */ 
/* 117 */     this.beanClassLoader = ClassUtils.getDefaultClassLoader();
/*     */   }
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 130 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public void setGroup(String group)
/*     */   {
/* 140 */     this.group = group;
/*     */   }
/*     */ 
/*     */   public void setConcurrent(boolean concurrent)
/*     */   {
/* 152 */     this.concurrent = concurrent;
/*     */   }
/*     */ 
/*     */   public void setTargetBeanName(String targetBeanName)
/*     */   {
/* 164 */     this.targetBeanName = targetBeanName;
/*     */   }
/*     */ 
/*     */   public void setJobListenerNames(String[] names)
/*     */   {
/* 176 */     this.jobListenerNames = names;
/*     */   }
/*     */ 
/*     */   public void setBeanName(String beanName) {
/* 180 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */   public void setBeanClassLoader(ClassLoader classLoader) {
/* 184 */     this.beanClassLoader = classLoader;
/*     */   }
/*     */ 
/*     */   public void setBeanFactory(BeanFactory beanFactory) {
/* 188 */     this.beanFactory = beanFactory;
/*     */   }
/*     */ 
/*     */   protected Class<?> resolveClassName(String className) throws ClassNotFoundException
/*     */   {
/* 193 */     return ClassUtils.forName(className, this.beanClassLoader);
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() throws ClassNotFoundException, NoSuchMethodException
/*     */   {
/* 198 */     prepare();
/*     */ 
/* 201 */     String name = this.name != null ? this.name : this.beanName;
/*     */ 
/* 204 */     Class jobClass = this.concurrent ? MethodInvokingJob.class : StatefulMethodInvokingJob.class;
/*     */ 
/* 207 */     if (jobDetailImplClass != null)
/*     */     {
/* 209 */       this.jobDetail = ((JobDetail)BeanUtils.instantiate(jobDetailImplClass));
/* 210 */       BeanWrapper bw = PropertyAccessorFactory.forBeanPropertyAccess(this.jobDetail);
/* 211 */       bw.setPropertyValue("name", name);
/* 212 */       bw.setPropertyValue("group", this.group);
/* 213 */       bw.setPropertyValue("jobClass", jobClass);
/* 214 */       bw.setPropertyValue("durability", Boolean.valueOf(true));
/* 215 */       ((JobDataMap)bw.getPropertyValue("jobDataMap")).put("methodInvoker", this);
/*     */     }
/*     */     else
/*     */     {
/* 219 */       this.jobDetail = new JobDetail(name, this.group, jobClass);
/* 220 */       this.jobDetail.setVolatility(true);
/* 221 */       this.jobDetail.setDurability(true);
/* 222 */       this.jobDetail.getJobDataMap().put("methodInvoker", this);
/*     */     }
/*     */ 
/* 226 */     if (this.jobListenerNames != null) {
/* 227 */       for (String jobListenerName : this.jobListenerNames) {
/* 228 */         if (jobDetailImplClass != null) {
/* 229 */           throw new IllegalStateException("Non-global JobListeners not supported on Quartz 2 - manually register a Matcher against the Quartz ListenerManager instead");
/*     */         }
/*     */ 
/* 232 */         this.jobDetail.addJobListener(jobListenerName);
/*     */       }
/*     */     }
/*     */ 
/* 236 */     postProcessJobDetail(this.jobDetail);
/*     */   }
/*     */ 
/*     */   protected void postProcessJobDetail(JobDetail jobDetail)
/*     */   {
/*     */   }
/*     */ 
/*     */   public Class<?> getTargetClass()
/*     */   {
/* 253 */     Class targetClass = super.getTargetClass();
/* 254 */     if ((targetClass == null) && (this.targetBeanName != null)) {
/* 255 */       Assert.state(this.beanFactory != null, "BeanFactory must be set when using 'targetBeanName'");
/* 256 */       targetClass = this.beanFactory.getType(this.targetBeanName);
/*     */     }
/* 258 */     return targetClass;
/*     */   }
/*     */ 
/*     */   public Object getTargetObject()
/*     */   {
/* 266 */     Object targetObject = super.getTargetObject();
/* 267 */     if ((targetObject == null) && (this.targetBeanName != null)) {
/* 268 */       Assert.state(this.beanFactory != null, "BeanFactory must be set when using 'targetBeanName'");
/* 269 */       targetObject = this.beanFactory.getBean(this.targetBeanName);
/*     */     }
/* 271 */     return targetObject;
/*     */   }
/*     */ 
/*     */   public JobDetail getObject()
/*     */   {
/* 276 */     return this.jobDetail;
/*     */   }
/*     */ 
/*     */   public Class<? extends JobDetail> getObjectType() {
/* 280 */     return this.jobDetail != null ? this.jobDetail.getClass() : JobDetail.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton() {
/* 284 */     return true;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  89 */       jobDetailImplClass = Class.forName("org.quartz.impl.JobDetailImpl");
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/*  92 */       jobDetailImplClass = null;
/*     */     }
/*     */     try {
/*  95 */       Class jobExecutionContextClass = QuartzJobBean.class.getClassLoader().loadClass("org.quartz.JobExecutionContext");
/*     */ 
/*  97 */       setResultMethod = jobExecutionContextClass.getMethod("setResult", new Class[] { Object.class });
/*     */     }
/*     */     catch (Exception ex) {
/* 100 */       throw new IllegalStateException("Incompatible Quartz API: " + ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class StatefulMethodInvokingJob extends MethodInvokingJobDetailFactoryBean.MethodInvokingJob
/*     */     implements StatefulJob
/*     */   {
/*     */   }
/*     */ 
/*     */   public static class MethodInvokingJob extends QuartzJobBean
/*     */   {
/* 294 */     protected static final Log logger = LogFactory.getLog(MethodInvokingJob.class);
/*     */     private MethodInvoker methodInvoker;
/*     */ 
/*     */     public void setMethodInvoker(MethodInvoker methodInvoker)
/*     */     {
/* 302 */       this.methodInvoker = methodInvoker;
/*     */     }
/*     */ 
/*     */     protected void executeInternal(JobExecutionContext context)
/*     */       throws JobExecutionException
/*     */     {
/*     */       try
/*     */       {
/* 311 */         ReflectionUtils.invokeMethod(MethodInvokingJobDetailFactoryBean.setResultMethod, context, new Object[] { this.methodInvoker.invoke() });
/*     */       }
/*     */       catch (InvocationTargetException ex) {
/* 314 */         if ((ex.getTargetException() instanceof JobExecutionException))
/*     */         {
/* 316 */           throw ((JobExecutionException)ex.getTargetException());
/*     */         }
/*     */ 
/* 320 */         throw new JobMethodInvocationFailedException(this.methodInvoker, ex.getTargetException());
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 325 */         throw new JobMethodInvocationFailedException(this.methodInvoker, ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.quartz.MethodInvokingJobDetailFactoryBean
 * JD-Core Version:    0.6.1
 */