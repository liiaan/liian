/*     */ package org.springframework.scheduling.quartz;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Date;
/*     */ import java.util.Map;
/*     */ import org.quartz.JobDataMap;
/*     */ import org.quartz.JobDetail;
/*     */ import org.quartz.SimpleTrigger;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.BeanWrapperImpl;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.Constants;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class SimpleTriggerFactoryBean
/*     */   implements FactoryBean<SimpleTrigger>, BeanNameAware, InitializingBean
/*     */ {
/*  67 */   private static final Constants constants = new Constants(SimpleTrigger.class);
/*     */   private String name;
/*     */   private String group;
/*     */   private JobDetail jobDetail;
/*  76 */   private JobDataMap jobDataMap = new JobDataMap();
/*     */   private Date startTime;
/*     */   private long startDelay;
/*     */   private long repeatInterval;
/*  84 */   private int repeatCount = -1;
/*     */   private int priority;
/*     */   private int misfireInstruction;
/*     */   private String description;
/*     */   private String beanName;
/*     */   private SimpleTrigger simpleTrigger;
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 101 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public void setGroup(String group)
/*     */   {
/* 108 */     this.group = group;
/*     */   }
/*     */ 
/*     */   public void setJobDetail(JobDetail jobDetail)
/*     */   {
/* 115 */     this.jobDetail = jobDetail;
/*     */   }
/*     */ 
/*     */   public void setJobDataMap(JobDataMap jobDataMap)
/*     */   {
/* 123 */     this.jobDataMap = jobDataMap;
/*     */   }
/*     */ 
/*     */   public JobDataMap getJobDataMap()
/*     */   {
/* 130 */     return this.jobDataMap;
/*     */   }
/*     */ 
/*     */   public void setJobDataAsMap(Map<String, ?> jobDataAsMap)
/*     */   {
/* 142 */     this.jobDataMap.putAll(jobDataAsMap);
/*     */   }
/*     */ 
/*     */   public void setStartTime(Date startTime)
/*     */   {
/* 151 */     this.startTime = startTime;
/*     */   }
/*     */ 
/*     */   public void setStartDelay(long startDelay)
/*     */   {
/* 161 */     Assert.isTrue(startDelay >= 0L, "Start delay cannot be negative");
/* 162 */     this.startDelay = startDelay;
/*     */   }
/*     */ 
/*     */   public void setRepeatInterval(long repeatInterval)
/*     */   {
/* 169 */     this.repeatInterval = repeatInterval;
/*     */   }
/*     */ 
/*     */   public void setRepeatCount(int repeatCount)
/*     */   {
/* 177 */     this.repeatCount = repeatCount;
/*     */   }
/*     */ 
/*     */   public void setPriority(int priority)
/*     */   {
/* 184 */     this.priority = priority;
/*     */   }
/*     */ 
/*     */   public void setMisfireInstruction(int misfireInstruction)
/*     */   {
/* 191 */     this.misfireInstruction = misfireInstruction;
/*     */   }
/*     */ 
/*     */   public void setMisfireInstructionName(String constantName)
/*     */   {
/* 206 */     this.misfireInstruction = constants.asNumber(constantName).intValue();
/*     */   }
/*     */ 
/*     */   public void setDescription(String description)
/*     */   {
/* 213 */     this.description = description;
/*     */   }
/*     */ 
/*     */   public void setBeanName(String beanName) {
/* 217 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 222 */     if (this.name == null) {
/* 223 */       this.name = this.beanName;
/*     */     }
/* 225 */     if (this.group == null) {
/* 226 */       this.group = "DEFAULT";
/*     */     }
/* 228 */     if (this.jobDetail != null) {
/* 229 */       this.jobDataMap.put("jobDetail", this.jobDetail);
/*     */     }
/* 231 */     if ((this.startDelay > 0L) || (this.startTime == null)) {
/* 232 */       this.startTime = new Date(System.currentTimeMillis() + this.startDelay);
/*     */     }
/*     */ 
/*     */     Class simpleTriggerClass;
/*     */     Method jobKeyMethod;
/*     */     try
/*     */     {
/* 253 */       simpleTriggerClass = getClass().getClassLoader().loadClass("org.quartz.impl.triggers.SimpleTriggerImpl");
/* 254 */       jobKeyMethod = JobDetail.class.getMethod("getKey", new Class[0]);
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 257 */       simpleTriggerClass = SimpleTrigger.class;
/* 258 */       jobKeyMethod = null;
/*     */     }
/*     */     catch (NoSuchMethodException ex) {
/* 261 */       throw new IllegalStateException("Incompatible Quartz version");
/*     */     }
/* 263 */     BeanWrapper bw = new BeanWrapperImpl(simpleTriggerClass);
/* 264 */     MutablePropertyValues pvs = new MutablePropertyValues();
/* 265 */     pvs.add("name", this.name);
/* 266 */     pvs.add("group", this.group);
/* 267 */     if (jobKeyMethod != null) {
/* 268 */       pvs.add("jobKey", ReflectionUtils.invokeMethod(jobKeyMethod, this.jobDetail));
/*     */     }
/*     */     else {
/* 271 */       pvs.add("jobName", this.jobDetail.getName());
/* 272 */       pvs.add("jobGroup", this.jobDetail.getGroup());
/*     */     }
/* 274 */     pvs.add("jobDataMap", this.jobDataMap);
/* 275 */     pvs.add("startTime", this.startTime);
/* 276 */     pvs.add("repeatInterval", Long.valueOf(this.repeatInterval));
/* 277 */     pvs.add("repeatCount", Integer.valueOf(this.repeatCount));
/* 278 */     pvs.add("priority", Integer.valueOf(this.priority));
/* 279 */     pvs.add("misfireInstruction", Integer.valueOf(this.misfireInstruction));
/* 280 */     pvs.add("description", this.description);
/* 281 */     bw.setPropertyValues(pvs);
/* 282 */     this.simpleTrigger = ((SimpleTrigger)bw.getWrappedInstance());
/*     */   }
/*     */ 
/*     */   public SimpleTrigger getObject()
/*     */   {
/* 287 */     return this.simpleTrigger;
/*     */   }
/*     */ 
/*     */   public Class<?> getObjectType() {
/* 291 */     return SimpleTrigger.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton() {
/* 295 */     return true;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.quartz.SimpleTriggerFactoryBean
 * JD-Core Version:    0.6.1
 */