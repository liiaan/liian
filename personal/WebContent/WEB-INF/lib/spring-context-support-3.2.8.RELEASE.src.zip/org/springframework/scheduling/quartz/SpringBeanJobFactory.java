/*     */ package org.springframework.scheduling.quartz;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import org.quartz.JobDataMap;
/*     */ import org.quartz.SchedulerContext;
/*     */ import org.quartz.spi.TriggerFiredBundle;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.PropertyAccessorFactory;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class SpringBeanJobFactory extends AdaptableJobFactory
/*     */   implements SchedulerContextAware
/*     */ {
/*     */   private String[] ignoredUnknownProperties;
/*     */   private SchedulerContext schedulerContext;
/*     */ 
/*     */   public void setIgnoredUnknownProperties(String[] ignoredUnknownProperties)
/*     */   {
/*  63 */     this.ignoredUnknownProperties = ignoredUnknownProperties;
/*     */   }
/*     */ 
/*     */   public void setSchedulerContext(SchedulerContext schedulerContext) {
/*  67 */     this.schedulerContext = schedulerContext;
/*     */   }
/*     */ 
/*     */   protected Object createJobInstance(TriggerFiredBundle bundle)
/*     */     throws Exception
/*     */   {
/*  77 */     Object job = super.createJobInstance(bundle);
/*  78 */     BeanWrapper bw = PropertyAccessorFactory.forBeanPropertyAccess(job);
/*  79 */     if (isEligibleForPropertyPopulation(bw.getWrappedInstance())) {
/*  80 */       MutablePropertyValues pvs = new MutablePropertyValues();
/*  81 */       if (this.schedulerContext != null) {
/*  82 */         pvs.addPropertyValues(this.schedulerContext);
/*     */       }
/*  84 */       pvs.addPropertyValues(getJobDetailDataMap(bundle));
/*  85 */       pvs.addPropertyValues(getTriggerDataMap(bundle));
/*  86 */       if (this.ignoredUnknownProperties != null) {
/*  87 */         for (String propName : this.ignoredUnknownProperties) {
/*  88 */           if ((pvs.contains(propName)) && (!bw.isWritableProperty(propName))) {
/*  89 */             pvs.removePropertyValue(propName);
/*     */           }
/*     */         }
/*  92 */         bw.setPropertyValues(pvs);
/*     */       }
/*     */       else {
/*  95 */         bw.setPropertyValues(pvs, true);
/*     */       }
/*     */     }
/*  98 */     return job;
/*     */   }
/*     */ 
/*     */   protected boolean isEligibleForPropertyPopulation(Object jobObject)
/*     */   {
/* 110 */     return !(jobObject instanceof QuartzJobBean);
/*     */   }
/*     */ 
/*     */   private JobDataMap getJobDetailDataMap(TriggerFiredBundle bundle) throws Exception
/*     */   {
/* 115 */     Method getJobDetail = bundle.getClass().getMethod("getJobDetail", new Class[0]);
/* 116 */     Object jobDetail = ReflectionUtils.invokeMethod(getJobDetail, bundle);
/* 117 */     Method getJobDataMap = jobDetail.getClass().getMethod("getJobDataMap", new Class[0]);
/* 118 */     return (JobDataMap)ReflectionUtils.invokeMethod(getJobDataMap, jobDetail);
/*     */   }
/*     */ 
/*     */   private JobDataMap getTriggerDataMap(TriggerFiredBundle bundle) throws Exception
/*     */   {
/* 123 */     Method getTrigger = bundle.getClass().getMethod("getTrigger", new Class[0]);
/* 124 */     Object trigger = ReflectionUtils.invokeMethod(getTrigger, bundle);
/* 125 */     Method getJobDataMap = trigger.getClass().getMethod("getJobDataMap", new Class[0]);
/* 126 */     return (JobDataMap)ReflectionUtils.invokeMethod(getJobDataMap, trigger);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.quartz.SpringBeanJobFactory
 * JD-Core Version:    0.6.1
 */