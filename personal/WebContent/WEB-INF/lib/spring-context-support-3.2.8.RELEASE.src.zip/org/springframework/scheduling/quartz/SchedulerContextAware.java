package org.springframework.scheduling.quartz;

import org.quartz.SchedulerContext;
import org.springframework.beans.factory.Aware;

public abstract interface SchedulerContextAware extends Aware
{
  public abstract void setSchedulerContext(SchedulerContext paramSchedulerContext);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.quartz.SchedulerContextAware
 * JD-Core Version:    0.6.1
 */