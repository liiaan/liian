package org.springframework.scheduling.quartz;

import org.quartz.JobDetail;

public abstract interface JobDetailAwareTrigger
{
  public static final String JOB_DETAIL_KEY = "jobDetail";

  public abstract JobDetail getJobDetail();
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.quartz.JobDetailAwareTrigger
 * JD-Core Version:    0.6.1
 */