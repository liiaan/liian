/*     */ package org.springframework.scheduling.commonj;
/*     */ 
/*     */ import commonj.work.Work;
/*     */ import commonj.work.WorkException;
/*     */ import commonj.work.WorkItem;
/*     */ import commonj.work.WorkListener;
/*     */ import commonj.work.WorkManager;
/*     */ import commonj.work.WorkRejectedException;
/*     */ import java.util.Collection;
/*     */ import java.util.concurrent.Callable;
/*     */ import java.util.concurrent.Future;
/*     */ import java.util.concurrent.FutureTask;
/*     */ import javax.naming.NamingException;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.core.task.TaskRejectedException;
/*     */ import org.springframework.jndi.JndiLocatorSupport;
/*     */ import org.springframework.scheduling.SchedulingException;
/*     */ import org.springframework.scheduling.SchedulingTaskExecutor;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class WorkManagerTaskExecutor extends JndiLocatorSupport
/*     */   implements SchedulingTaskExecutor, WorkManager, InitializingBean
/*     */ {
/*     */   private WorkManager workManager;
/*     */   private String workManagerName;
/*     */   private WorkListener workListener;
/*     */ 
/*     */   public void setWorkManager(WorkManager workManager)
/*     */   {
/*  84 */     this.workManager = workManager;
/*     */   }
/*     */ 
/*     */   public void setWorkManagerName(String workManagerName)
/*     */   {
/*  95 */     this.workManagerName = workManagerName;
/*     */   }
/*     */ 
/*     */   public void setWorkListener(WorkListener workListener)
/*     */   {
/* 104 */     this.workListener = workListener;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() throws NamingException {
/* 108 */     if (this.workManager == null) {
/* 109 */       if (this.workManagerName == null) {
/* 110 */         throw new IllegalArgumentException("Either 'workManager' or 'workManagerName' must be specified");
/*     */       }
/* 112 */       this.workManager = ((WorkManager)lookup(this.workManagerName, WorkManager.class));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task)
/*     */   {
/* 122 */     Assert.state(this.workManager != null, "No WorkManager specified");
/* 123 */     Work work = new DelegatingWork(task);
/*     */     try {
/* 125 */       if (this.workListener != null) {
/* 126 */         this.workManager.schedule(work, this.workListener);
/*     */       }
/*     */       else
/* 129 */         this.workManager.schedule(work);
/*     */     }
/*     */     catch (WorkRejectedException ex)
/*     */     {
/* 133 */       throw new TaskRejectedException("CommonJ WorkManager did not accept task: " + task, ex);
/*     */     }
/*     */     catch (WorkException ex) {
/* 136 */       throw new SchedulingException("Could not schedule task on CommonJ WorkManager", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void execute(Runnable task, long startTimeout) {
/* 141 */     execute(task);
/*     */   }
/*     */ 
/*     */   public Future<?> submit(Runnable task) {
/* 145 */     FutureTask future = new FutureTask(task, null);
/* 146 */     execute(future);
/* 147 */     return future;
/*     */   }
/*     */ 
/*     */   public <T> Future<T> submit(Callable<T> task) {
/* 151 */     FutureTask future = new FutureTask(task);
/* 152 */     execute(future);
/* 153 */     return future;
/*     */   }
/*     */ 
/*     */   public boolean prefersShortLivedTasks()
/*     */   {
/* 160 */     return true;
/*     */   }
/*     */ 
/*     */   public WorkItem schedule(Work work)
/*     */     throws WorkException, IllegalArgumentException
/*     */   {
/* 169 */     return this.workManager.schedule(work);
/*     */   }
/*     */ 
/*     */   public WorkItem schedule(Work work, WorkListener workListener) throws WorkException {
/* 173 */     return this.workManager.schedule(work, workListener);
/*     */   }
/*     */ 
/*     */   public boolean waitForAll(Collection workItems, long timeout) throws InterruptedException {
/* 177 */     return this.workManager.waitForAll(workItems, timeout);
/*     */   }
/*     */ 
/*     */   public Collection waitForAny(Collection workItems, long timeout) throws InterruptedException {
/* 181 */     return this.workManager.waitForAny(workItems, timeout);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.commonj.WorkManagerTaskExecutor
 * JD-Core Version:    0.6.1
 */