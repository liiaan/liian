/*    */ package org.springframework.scheduling.commonj;
/*    */ 
/*    */ import commonj.work.Work;
/*    */ import org.springframework.scheduling.SchedulingAwareRunnable;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class DelegatingWork
/*    */   implements Work
/*    */ {
/*    */   private final Runnable delegate;
/*    */ 
/*    */   public DelegatingWork(Runnable delegate)
/*    */   {
/* 45 */     Assert.notNull(delegate, "Delegate must not be null");
/* 46 */     this.delegate = delegate;
/*    */   }
/*    */ 
/*    */   public final Runnable getDelegate()
/*    */   {
/* 53 */     return this.delegate;
/*    */   }
/*    */ 
/*    */   public void run()
/*    */   {
/* 61 */     this.delegate.run();
/*    */   }
/*    */ 
/*    */   public boolean isDaemon()
/*    */   {
/* 70 */     return ((this.delegate instanceof SchedulingAwareRunnable)) && (((SchedulingAwareRunnable)this.delegate).isLongLived());
/*    */   }
/*    */ 
/*    */   public void release()
/*    */   {
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.commonj.DelegatingWork
 * JD-Core Version:    0.6.1
 */