/*     */ package org.springframework.scheduling.quartz;
/*     */ 
/*     */ import java.util.Map;
/*     */ import org.quartz.JobDataMap;
/*     */ import org.quartz.JobDetail;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.BeanWrapperImpl;
/*     */ import org.springframework.beans.MutablePropertyValues;
/*     */ import org.springframework.beans.factory.BeanNameAware;
/*     */ import org.springframework.beans.factory.FactoryBean;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.context.ApplicationContext;
/*     */ import org.springframework.context.ApplicationContextAware;
/*     */ 
/*     */ public class JobDetailFactoryBean
/*     */   implements FactoryBean<JobDetail>, BeanNameAware, ApplicationContextAware, InitializingBean
/*     */ {
/*     */   private String name;
/*     */   private String group;
/*     */   private Class jobClass;
/*  61 */   private JobDataMap jobDataMap = new JobDataMap();
/*     */ 
/*  63 */   private boolean durability = false;
/*     */ 
/*  65 */   private boolean requestsRecovery = false;
/*     */   private String description;
/*     */   private String beanName;
/*     */   private ApplicationContext applicationContext;
/*     */   private String applicationContextJobDataKey;
/*     */   private JobDetail jobDetail;
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/*  82 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public void setGroup(String group)
/*     */   {
/*  89 */     this.group = group;
/*     */   }
/*     */ 
/*     */   public void setJobClass(Class jobClass)
/*     */   {
/*  96 */     this.jobClass = jobClass;
/*     */   }
/*     */ 
/*     */   public void setJobDataMap(JobDataMap jobDataMap)
/*     */   {
/* 104 */     this.jobDataMap = jobDataMap;
/*     */   }
/*     */ 
/*     */   public JobDataMap getJobDataMap()
/*     */   {
/* 111 */     return this.jobDataMap;
/*     */   }
/*     */ 
/*     */   public void setJobDataAsMap(Map<String, ?> jobDataAsMap)
/*     */   {
/* 126 */     getJobDataMap().putAll(jobDataAsMap);
/*     */   }
/*     */ 
/*     */   public void setDurability(boolean durability)
/*     */   {
/* 134 */     this.durability = durability;
/*     */   }
/*     */ 
/*     */   public void setRequestsRecovery(boolean requestsRecovery)
/*     */   {
/* 142 */     this.requestsRecovery = requestsRecovery;
/*     */   }
/*     */ 
/*     */   public void setDescription(String description)
/*     */   {
/* 149 */     this.description = description;
/*     */   }
/*     */ 
/*     */   public void setBeanName(String beanName) {
/* 153 */     this.beanName = beanName;
/*     */   }
/*     */ 
/*     */   public void setApplicationContext(ApplicationContext applicationContext) {
/* 157 */     this.applicationContext = applicationContext;
/*     */   }
/*     */ 
/*     */   public void setApplicationContextJobDataKey(String applicationContextJobDataKey)
/*     */   {
/* 177 */     this.applicationContextJobDataKey = applicationContextJobDataKey;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 182 */     if (this.name == null) {
/* 183 */       this.name = this.beanName;
/*     */     }
/* 185 */     if (this.group == null) {
/* 186 */       this.group = "DEFAULT";
/*     */     }
/* 188 */     if (this.applicationContextJobDataKey != null) {
/* 189 */       if (this.applicationContext == null) {
/* 190 */         throw new IllegalStateException("JobDetailBean needs to be set up in an ApplicationContext to be able to handle an 'applicationContextJobDataKey'");
/*     */       }
/*     */ 
/* 194 */       getJobDataMap().put(this.applicationContextJobDataKey, this.applicationContext);
/*     */     }
/*     */ 
/*     */     Class jobDetailClass;
/*     */     try
/*     */     {
/* 210 */       jobDetailClass = getClass().getClassLoader().loadClass("org.quartz.impl.JobDetailImpl");
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 213 */       jobDetailClass = JobDetail.class;
/*     */     }
/* 215 */     BeanWrapper bw = new BeanWrapperImpl(jobDetailClass);
/* 216 */     MutablePropertyValues pvs = new MutablePropertyValues();
/* 217 */     pvs.add("name", this.name);
/* 218 */     pvs.add("group", this.group);
/* 219 */     pvs.add("jobClass", this.jobClass);
/* 220 */     pvs.add("jobDataMap", this.jobDataMap);
/* 221 */     pvs.add("durability", Boolean.valueOf(this.durability));
/* 222 */     pvs.add("requestsRecovery", Boolean.valueOf(this.requestsRecovery));
/* 223 */     pvs.add("description", this.description);
/* 224 */     bw.setPropertyValues(pvs);
/* 225 */     this.jobDetail = ((JobDetail)bw.getWrappedInstance());
/*     */   }
/*     */ 
/*     */   public JobDetail getObject()
/*     */   {
/* 230 */     return this.jobDetail;
/*     */   }
/*     */ 
/*     */   public Class<?> getObjectType() {
/* 234 */     return JobDetail.class;
/*     */   }
/*     */ 
/*     */   public boolean isSingleton() {
/* 238 */     return true;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\spring-context-support-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.scheduling.quartz.JobDetailFactoryBean
 * JD-Core Version:    0.6.1
 */