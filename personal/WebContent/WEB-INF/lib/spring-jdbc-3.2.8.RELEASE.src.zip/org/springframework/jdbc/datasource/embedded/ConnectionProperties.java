package org.springframework.jdbc.datasource.embedded;

import java.sql.Driver;

public abstract interface ConnectionProperties
{
  public abstract void setDriverClass(Class<? extends Driver> paramClass);

  public abstract void setUrl(String paramString);

  public abstract void setUsername(String paramString);

  public abstract void setPassword(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.embedded.ConnectionProperties
 * JD-Core Version:    0.6.1
 */