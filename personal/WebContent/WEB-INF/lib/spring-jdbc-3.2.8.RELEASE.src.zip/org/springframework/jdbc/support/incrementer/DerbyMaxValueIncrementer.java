/*     */ package org.springframework.jdbc.support.incrementer;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ 
/*     */ public class DerbyMaxValueIncrementer extends AbstractColumnMaxValueIncrementer
/*     */ {
/*     */   private static final String DEFAULT_DUMMY_NAME = "dummy";
/*  72 */   private String dummyName = "dummy";
/*     */   private long[] valueCache;
/*  78 */   private int nextValueIndex = -1;
/*     */ 
/*     */   public DerbyMaxValueIncrementer()
/*     */   {
/*     */   }
/*     */ 
/*     */   public DerbyMaxValueIncrementer(DataSource dataSource, String incrementerName, String columnName)
/*     */   {
/*  97 */     super(dataSource, incrementerName, columnName);
/*  98 */     this.dummyName = "dummy";
/*     */   }
/*     */ 
/*     */   public DerbyMaxValueIncrementer(DataSource dataSource, String incrementerName, String columnName, String dummyName)
/*     */   {
/* 109 */     super(dataSource, incrementerName, columnName);
/* 110 */     this.dummyName = dummyName;
/*     */   }
/*     */ 
/*     */   public void setDummyName(String dummyName)
/*     */   {
/* 118 */     this.dummyName = dummyName;
/*     */   }
/*     */ 
/*     */   public String getDummyName()
/*     */   {
/* 125 */     return this.dummyName;
/*     */   }
/*     */ 
/*     */   protected synchronized long getNextKey()
/*     */     throws DataAccessException
/*     */   {
/* 131 */     if ((this.nextValueIndex < 0) || (this.nextValueIndex >= getCacheSize()))
/*     */     {
/* 137 */       Connection con = DataSourceUtils.getConnection(getDataSource());
/* 138 */       Statement stmt = null;
/*     */       try {
/* 140 */         stmt = con.createStatement();
/* 141 */         DataSourceUtils.applyTransactionTimeout(stmt, getDataSource());
/* 142 */         this.valueCache = new long[getCacheSize()];
/* 143 */         this.nextValueIndex = 0;
/* 144 */         for (int i = 0; i < getCacheSize(); i++) {
/* 145 */           stmt.executeUpdate("insert into " + getIncrementerName() + " (" + getDummyName() + ") values(null)");
/* 146 */           ResultSet rs = stmt.executeQuery("select IDENTITY_VAL_LOCAL() from " + getIncrementerName());
/*     */           try {
/* 148 */             if (!rs.next()) {
/* 149 */               throw new DataAccessResourceFailureException("IDENTITY_VAL_LOCAL() failed after executing an update");
/*     */             }
/* 151 */             this.valueCache[i] = rs.getLong(1);
/*     */           }
/*     */           finally {
/* 154 */             JdbcUtils.closeResultSet(rs);
/*     */           }
/*     */         }
/* 157 */         long maxValue = this.valueCache[(this.valueCache.length - 1)];
/* 158 */         stmt.executeUpdate("delete from " + getIncrementerName() + " where " + getColumnName() + " < " + maxValue);
/*     */       }
/*     */       catch (SQLException ex) {
/* 161 */         throw new DataAccessResourceFailureException("Could not obtain IDENTITY value", ex);
/*     */       }
/*     */       finally {
/* 164 */         JdbcUtils.closeStatement(stmt);
/* 165 */         DataSourceUtils.releaseConnection(con, getDataSource());
/*     */       }
/*     */     }
/* 168 */     return this.valueCache[(this.nextValueIndex++)];
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.incrementer.DerbyMaxValueIncrementer
 * JD-Core Version:    0.6.1
 */