/*    */ package org.springframework.jdbc.support.lob;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.sql.Blob;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ class PassThroughBlob
/*    */   implements Blob
/*    */ {
/*    */   private byte[] content;
/*    */   private InputStream binaryStream;
/*    */   private long contentLength;
/*    */ 
/*    */   public PassThroughBlob(byte[] content)
/*    */   {
/* 42 */     this.content = content;
/* 43 */     this.contentLength = content.length;
/*    */   }
/*    */ 
/*    */   public PassThroughBlob(InputStream binaryStream, long contentLength) {
/* 47 */     this.binaryStream = binaryStream;
/* 48 */     this.contentLength = contentLength;
/*    */   }
/*    */ 
/*    */   public long length() throws SQLException
/*    */   {
/* 53 */     return this.contentLength;
/*    */   }
/*    */ 
/*    */   public InputStream getBinaryStream() throws SQLException {
/* 57 */     return this.content != null ? new ByteArrayInputStream(this.content) : this.binaryStream;
/*    */   }
/*    */ 
/*    */   public InputStream getBinaryStream(long pos, long length) throws SQLException
/*    */   {
/* 62 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public OutputStream setBinaryStream(long pos) throws SQLException {
/* 66 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public byte[] getBytes(long pos, int length) throws SQLException {
/* 70 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public int setBytes(long pos, byte[] bytes) throws SQLException {
/* 74 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public int setBytes(long pos, byte[] bytes, int offset, int len) throws SQLException {
/* 78 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public long position(byte[] pattern, long start) throws SQLException {
/* 82 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public long position(Blob pattern, long start) throws SQLException {
/* 86 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public void truncate(long len) throws SQLException {
/* 90 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public void free()
/*    */     throws SQLException
/*    */   {
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.lob.PassThroughBlob
 * JD-Core Version:    0.6.1
 */