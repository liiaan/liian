package org.springframework.jdbc.core;

import java.sql.ResultSet;
import java.sql.SQLException;

public abstract interface RowMapper<T>
{
  public abstract T mapRow(ResultSet paramResultSet, int paramInt)
    throws SQLException;
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.RowMapper
 * JD-Core Version:    0.6.1
 */