/*    */ package org.springframework.jdbc.core.metadata;
/*    */ 
/*    */ import java.sql.DatabaseMetaData;
/*    */ import java.sql.SQLException;
/*    */ import org.apache.commons.logging.Log;
/*    */ 
/*    */ public class DerbyTableMetaDataProvider extends GenericTableMetaDataProvider
/*    */ {
/* 32 */   private boolean supportsGeneratedKeysOverride = false;
/*    */ 
/*    */   public DerbyTableMetaDataProvider(DatabaseMetaData databaseMetaData) throws SQLException {
/* 35 */     super(databaseMetaData);
/*    */   }
/*    */ 
/*    */   public void initializeWithMetaData(DatabaseMetaData databaseMetaData) throws SQLException
/*    */   {
/* 40 */     super.initializeWithMetaData(databaseMetaData);
/* 41 */     if (!databaseMetaData.supportsGetGeneratedKeys()) {
/* 42 */       logger.warn("Overriding supportsGetGeneratedKeys from DatabaseMetaData to 'true'; it was reported as 'false' by " + databaseMetaData.getDriverName() + " " + databaseMetaData.getDriverVersion());
/*    */ 
/* 44 */       this.supportsGeneratedKeysOverride = true;
/*    */     }
/*    */   }
/*    */ 
/*    */   public boolean isGetGeneratedKeysSupported()
/*    */   {
/* 50 */     boolean derbysAnswer = super.isGetGeneratedKeysSupported();
/* 51 */     if (!derbysAnswer) {
/* 52 */       return this.supportsGeneratedKeysOverride;
/*    */     }
/* 54 */     return derbysAnswer;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.DerbyTableMetaDataProvider
 * JD-Core Version:    0.6.1
 */