package org.springframework.jdbc.core;

public abstract interface InterruptibleBatchPreparedStatementSetter extends BatchPreparedStatementSetter
{
  public abstract boolean isBatchExhausted(int paramInt);
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.InterruptibleBatchPreparedStatementSetter
 * JD-Core Version:    0.6.1
 */