package org.springframework.jdbc.core;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public abstract interface PreparedStatementCreator
{
  public abstract PreparedStatement createPreparedStatement(Connection paramConnection)
    throws SQLException;
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.PreparedStatementCreator
 * JD-Core Version:    0.6.1
 */