/*    */ package org.springframework.jdbc.support.incrementer;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ public class PostgreSQLSequenceMaxValueIncrementer extends AbstractSequenceMaxValueIncrementer
/*    */ {
/*    */   public PostgreSQLSequenceMaxValueIncrementer()
/*    */   {
/*    */   }
/*    */ 
/*    */   public PostgreSQLSequenceMaxValueIncrementer(DataSource dataSource, String incrementerName)
/*    */   {
/* 43 */     super(dataSource, incrementerName);
/*    */   }
/*    */ 
/*    */   protected String getSequenceQuery()
/*    */   {
/* 49 */     return "select nextval('" + getIncrementerName() + "')";
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.incrementer.PostgreSQLSequenceMaxValueIncrementer
 * JD-Core Version:    0.6.1
 */