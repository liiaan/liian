package org.springframework.jdbc.core.simple;

import org.springframework.jdbc.core.RowMapper;

public abstract interface ParameterizedRowMapper<T> extends RowMapper<T>
{
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.simple.ParameterizedRowMapper
 * JD-Core Version:    0.6.1
 */