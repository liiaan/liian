/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class AbstractDriverBasedDataSource extends AbstractDataSource
/*     */ {
/*     */   private String url;
/*     */   private String username;
/*     */   private String password;
/*     */   private Properties connectionProperties;
/*     */ 
/*     */   public void setUrl(String url)
/*     */   {
/*  50 */     Assert.hasText(url, "Property 'url' must not be empty");
/*  51 */     this.url = url.trim();
/*     */   }
/*     */ 
/*     */   public String getUrl()
/*     */   {
/*  58 */     return this.url;
/*     */   }
/*     */ 
/*     */   public void setUsername(String username)
/*     */   {
/*  66 */     this.username = username;
/*     */   }
/*     */ 
/*     */   public String getUsername()
/*     */   {
/*  73 */     return this.username;
/*     */   }
/*     */ 
/*     */   public void setPassword(String password)
/*     */   {
/*  81 */     this.password = password;
/*     */   }
/*     */ 
/*     */   public String getPassword()
/*     */   {
/*  88 */     return this.password;
/*     */   }
/*     */ 
/*     */   public void setConnectionProperties(Properties connectionProperties)
/*     */   {
/* 100 */     this.connectionProperties = connectionProperties;
/*     */   }
/*     */ 
/*     */   public Properties getConnectionProperties()
/*     */   {
/* 107 */     return this.connectionProperties;
/*     */   }
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws SQLException
/*     */   {
/* 119 */     return getConnectionFromDriver(getUsername(), getPassword());
/*     */   }
/*     */ 
/*     */   public Connection getConnection(String username, String password)
/*     */     throws SQLException
/*     */   {
/* 128 */     return getConnectionFromDriver(username, password);
/*     */   }
/*     */ 
/*     */   protected Connection getConnectionFromDriver(String username, String password)
/*     */     throws SQLException
/*     */   {
/* 142 */     Properties mergedProps = new Properties();
/* 143 */     Properties connProps = getConnectionProperties();
/* 144 */     if (connProps != null) {
/* 145 */       mergedProps.putAll(connProps);
/*     */     }
/* 147 */     if (username != null) {
/* 148 */       mergedProps.setProperty("user", username);
/*     */     }
/* 150 */     if (password != null) {
/* 151 */       mergedProps.setProperty("password", password);
/*     */     }
/* 153 */     return getConnectionFromDriver(mergedProps);
/*     */   }
/*     */ 
/*     */   protected abstract Connection getConnectionFromDriver(Properties paramProperties)
/*     */     throws SQLException;
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.AbstractDriverBasedDataSource
 * JD-Core Version:    0.6.1
 */