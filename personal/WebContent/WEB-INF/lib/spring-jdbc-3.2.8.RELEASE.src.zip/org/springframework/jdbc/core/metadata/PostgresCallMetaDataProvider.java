/*    */ package org.springframework.jdbc.core.metadata;
/*    */ 
/*    */ import java.sql.DatabaseMetaData;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.jdbc.core.ColumnMapRowMapper;
/*    */ import org.springframework.jdbc.core.SqlOutParameter;
/*    */ import org.springframework.jdbc.core.SqlParameter;
/*    */ 
/*    */ public class PostgresCallMetaDataProvider extends GenericCallMetaDataProvider
/*    */ {
/*    */   private static final String RETURN_VALUE_NAME = "returnValue";
/*    */ 
/*    */   public PostgresCallMetaDataProvider(DatabaseMetaData databaseMetaData)
/*    */     throws SQLException
/*    */   {
/* 40 */     super(databaseMetaData);
/*    */   }
/*    */ 
/*    */   public boolean isReturnResultSetSupported()
/*    */   {
/* 46 */     return false;
/*    */   }
/*    */ 
/*    */   public boolean isRefCursorSupported()
/*    */   {
/* 51 */     return true;
/*    */   }
/*    */ 
/*    */   public int getRefCursorSqlType()
/*    */   {
/* 56 */     return 1111;
/*    */   }
/*    */ 
/*    */   public String metaDataSchemaNameToUse(String schemaName)
/*    */   {
/* 62 */     return schemaName == null ? "public" : super.metaDataSchemaNameToUse(schemaName);
/*    */   }
/*    */ 
/*    */   public SqlParameter createDefaultOutParameter(String parameterName, CallParameterMetaData meta)
/*    */   {
/* 67 */     if ((meta.getSqlType() == 1111) && ("refcursor".equals(meta.getTypeName()))) {
/* 68 */       return new SqlOutParameter(parameterName, getRefCursorSqlType(), new ColumnMapRowMapper());
/*    */     }
/*    */ 
/* 71 */     return super.createDefaultOutParameter(parameterName, meta);
/*    */   }
/*    */ 
/*    */   public boolean byPassReturnParameter(String parameterName)
/*    */   {
/* 77 */     return ("returnValue".equals(parameterName)) || (super.byPassReturnParameter(parameterName));
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.PostgresCallMetaDataProvider
 * JD-Core Version:    0.6.1
 */