/*    */ package org.springframework.jdbc;
/*    */ 
/*    */ import org.springframework.dao.IncorrectUpdateSemanticsDataAccessException;
/*    */ 
/*    */ public class JdbcUpdateAffectedIncorrectNumberOfRowsException extends IncorrectUpdateSemanticsDataAccessException
/*    */ {
/*    */   private int expected;
/*    */   private int actual;
/*    */ 
/*    */   public JdbcUpdateAffectedIncorrectNumberOfRowsException(String sql, int expected, int actual)
/*    */   {
/* 46 */     super("SQL update '" + sql + "' affected " + actual + " rows, not " + expected + " as expected");
/* 47 */     this.expected = expected;
/* 48 */     this.actual = actual;
/*    */   }
/*    */ 
/*    */   public int getExpectedRowsAffected()
/*    */   {
/* 56 */     return this.expected;
/*    */   }
/*    */ 
/*    */   public int getActualRowsAffected()
/*    */   {
/* 63 */     return this.actual;
/*    */   }
/*    */ 
/*    */   public boolean wasDataUpdated()
/*    */   {
/* 68 */     return getActualRowsAffected() > 0;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.JdbcUpdateAffectedIncorrectNumberOfRowsException
 * JD-Core Version:    0.6.1
 */