/*    */ package org.springframework.jdbc.core.metadata;
/*    */ 
/*    */ import java.sql.DatabaseMetaData;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ public class DerbyCallMetaDataProvider extends GenericCallMetaDataProvider
/*    */ {
/*    */   public DerbyCallMetaDataProvider(DatabaseMetaData databaseMetaData)
/*    */     throws SQLException
/*    */   {
/* 33 */     super(databaseMetaData);
/*    */   }
/*    */ 
/*    */   public String metaDataSchemaNameToUse(String schemaName)
/*    */   {
/* 38 */     if (schemaName != null) {
/* 39 */       return super.metaDataSchemaNameToUse(schemaName);
/*    */     }
/*    */ 
/* 42 */     String userName = getUserName();
/* 43 */     return userName != null ? userName.toUpperCase() : null;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.DerbyCallMetaDataProvider
 * JD-Core Version:    0.6.1
 */