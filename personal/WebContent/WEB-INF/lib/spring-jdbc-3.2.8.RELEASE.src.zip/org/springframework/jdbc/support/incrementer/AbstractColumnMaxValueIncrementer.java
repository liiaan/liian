/*    */ package org.springframework.jdbc.support.incrementer;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public abstract class AbstractColumnMaxValueIncrementer extends AbstractDataFieldMaxValueIncrementer
/*    */ {
/*    */   private String columnName;
/* 37 */   private int cacheSize = 1;
/*    */ 
/*    */   public AbstractColumnMaxValueIncrementer()
/*    */   {
/*    */   }
/*    */ 
/*    */   public AbstractColumnMaxValueIncrementer(DataSource dataSource, String incrementerName, String columnName)
/*    */   {
/* 56 */     super(dataSource, incrementerName);
/* 57 */     Assert.notNull(columnName, "Column name must not be null");
/* 58 */     this.columnName = columnName;
/*    */   }
/*    */ 
/*    */   public void setColumnName(String columnName)
/*    */   {
/* 66 */     this.columnName = columnName;
/*    */   }
/*    */ 
/*    */   public String getColumnName()
/*    */   {
/* 73 */     return this.columnName;
/*    */   }
/*    */ 
/*    */   public void setCacheSize(int cacheSize)
/*    */   {
/* 80 */     this.cacheSize = cacheSize;
/*    */   }
/*    */ 
/*    */   public int getCacheSize()
/*    */   {
/* 87 */     return this.cacheSize;
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 92 */     super.afterPropertiesSet();
/* 93 */     if (this.columnName == null)
/* 94 */       throw new IllegalArgumentException("Property 'columnName' is required");
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.incrementer.AbstractColumnMaxValueIncrementer
 * JD-Core Version:    0.6.1
 */