/*     */ package org.springframework.jdbc.support;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.jdbc.UncategorizedSQLException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class AbstractFallbackSQLExceptionTranslator
/*     */   implements SQLExceptionTranslator
/*     */ {
/*  38 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private SQLExceptionTranslator fallbackTranslator;
/*     */ 
/*     */   public void setFallbackTranslator(SQLExceptionTranslator fallback)
/*     */   {
/*  48 */     this.fallbackTranslator = fallback;
/*     */   }
/*     */ 
/*     */   public SQLExceptionTranslator getFallbackTranslator()
/*     */   {
/*  55 */     return this.fallbackTranslator;
/*     */   }
/*     */ 
/*     */   public DataAccessException translate(String task, String sql, SQLException ex)
/*     */   {
/*  64 */     Assert.notNull(ex, "Cannot translate a null SQLException");
/*  65 */     if (task == null) {
/*  66 */       task = "";
/*     */     }
/*  68 */     if (sql == null) {
/*  69 */       sql = "";
/*     */     }
/*     */ 
/*  72 */     DataAccessException dex = doTranslate(task, sql, ex);
/*  73 */     if (dex != null)
/*     */     {
/*  75 */       return dex;
/*     */     }
/*     */ 
/*  78 */     SQLExceptionTranslator fallback = getFallbackTranslator();
/*  79 */     if (fallback != null) {
/*  80 */       return fallback.translate(task, sql, ex);
/*     */     }
/*     */ 
/*  83 */     return new UncategorizedSQLException(task, sql, ex);
/*     */   }
/*     */ 
/*     */   protected abstract DataAccessException doTranslate(String paramString1, String paramString2, SQLException paramSQLException);
/*     */ 
/*     */   protected String buildMessage(String task, String sql, SQLException ex)
/*     */   {
/* 110 */     return task + "; SQL [" + sql + "]; " + ex.getMessage();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.AbstractFallbackSQLExceptionTranslator
 * JD-Core Version:    0.6.1
 */