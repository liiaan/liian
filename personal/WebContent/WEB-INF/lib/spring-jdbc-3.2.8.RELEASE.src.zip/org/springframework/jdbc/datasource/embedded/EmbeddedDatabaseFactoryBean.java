/*    */ package org.springframework.jdbc.datasource.embedded;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.beans.factory.DisposableBean;
/*    */ import org.springframework.beans.factory.FactoryBean;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ import org.springframework.jdbc.datasource.init.DatabasePopulator;
/*    */ import org.springframework.jdbc.datasource.init.DatabasePopulatorUtils;
/*    */ 
/*    */ public class EmbeddedDatabaseFactoryBean extends EmbeddedDatabaseFactory
/*    */   implements FactoryBean<DataSource>, InitializingBean, DisposableBean
/*    */ {
/*    */   private DatabasePopulator databaseCleaner;
/*    */ 
/*    */   public void setDatabaseCleaner(DatabasePopulator databaseCleaner)
/*    */   {
/* 54 */     this.databaseCleaner = databaseCleaner;
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet() {
/* 58 */     initDatabase();
/*    */   }
/*    */ 
/*    */   public void destroy() {
/* 62 */     if (this.databaseCleaner != null) {
/* 63 */       DatabasePopulatorUtils.execute(this.databaseCleaner, getDataSource());
/*    */     }
/* 65 */     shutdownDatabase();
/*    */   }
/*    */ 
/*    */   public DataSource getObject()
/*    */   {
/* 70 */     return getDataSource();
/*    */   }
/*    */ 
/*    */   public Class<? extends DataSource> getObjectType() {
/* 74 */     return DataSource.class;
/*    */   }
/*    */ 
/*    */   public boolean isSingleton() {
/* 78 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseFactoryBean
 * JD-Core Version:    0.6.1
 */