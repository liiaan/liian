package org.springframework.jdbc.core;

import java.sql.CallableStatement;
import java.sql.SQLException;
import org.springframework.dao.DataAccessException;

public abstract interface CallableStatementCallback<T>
{
  public abstract T doInCallableStatement(CallableStatement paramCallableStatement)
    throws SQLException, DataAccessException;
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.CallableStatementCallback
 * JD-Core Version:    0.6.1
 */