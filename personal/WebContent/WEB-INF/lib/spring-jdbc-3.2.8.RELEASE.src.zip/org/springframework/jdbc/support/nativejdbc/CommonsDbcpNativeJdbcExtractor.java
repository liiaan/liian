/*     */ package org.springframework.jdbc.support.nativejdbc;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class CommonsDbcpNativeJdbcExtractor extends NativeJdbcExtractorAdapter
/*     */ {
/*     */   private static final String GET_INNERMOST_DELEGATE_METHOD_NAME = "getInnermostDelegate";
/*     */ 
/*     */   private static Object getInnermostDelegate(Object obj)
/*     */     throws SQLException
/*     */   {
/*  62 */     if (obj == null)
/*  63 */       return null;
/*     */     try
/*     */     {
/*  66 */       Class classToAnalyze = obj.getClass();
/*  67 */       while (!Modifier.isPublic(classToAnalyze.getModifiers())) {
/*  68 */         classToAnalyze = classToAnalyze.getSuperclass();
/*  69 */         if (classToAnalyze == null)
/*     */         {
/*  71 */           return obj;
/*     */         }
/*     */       }
/*  74 */       Method getInnermostDelegate = classToAnalyze.getMethod("getInnermostDelegate", (Class[])null);
/*  75 */       Object delegate = ReflectionUtils.invokeJdbcMethod(getInnermostDelegate, obj);
/*  76 */       return delegate != null ? delegate : obj;
/*     */     }
/*     */     catch (NoSuchMethodException ex) {
/*  79 */       return obj;
/*     */     }
/*     */     catch (SecurityException ex) {
/*  82 */       throw new IllegalStateException("Commons DBCP getInnermostDelegate method is not accessible: " + ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Connection doGetNativeConnection(Connection con)
/*     */     throws SQLException
/*     */   {
/*  89 */     return (Connection)getInnermostDelegate(con);
/*     */   }
/*     */ 
/*     */   public Statement getNativeStatement(Statement stmt) throws SQLException
/*     */   {
/*  94 */     return (Statement)getInnermostDelegate(stmt);
/*     */   }
/*     */ 
/*     */   public PreparedStatement getNativePreparedStatement(PreparedStatement ps) throws SQLException
/*     */   {
/*  99 */     return (PreparedStatement)getNativeStatement(ps);
/*     */   }
/*     */ 
/*     */   public CallableStatement getNativeCallableStatement(CallableStatement cs) throws SQLException
/*     */   {
/* 104 */     return (CallableStatement)getNativeStatement(cs);
/*     */   }
/*     */ 
/*     */   public ResultSet getNativeResultSet(ResultSet rs) throws SQLException
/*     */   {
/* 109 */     return (ResultSet)getInnermostDelegate(rs);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.nativejdbc.CommonsDbcpNativeJdbcExtractor
 * JD-Core Version:    0.6.1
 */