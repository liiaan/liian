/*     */ package org.springframework.jdbc.core.simple;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.jdbc.core.BatchUpdateUtils;
/*     */ import org.springframework.jdbc.core.JdbcOperations;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
/*     */ import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ @Deprecated
/*     */ public class SimpleJdbcTemplate
/*     */   implements SimpleJdbcOperations
/*     */ {
/*     */   private final NamedParameterJdbcOperations namedParameterJdbcOperations;
/*     */ 
/*     */   public SimpleJdbcTemplate(DataSource dataSource)
/*     */   {
/*  70 */     this.namedParameterJdbcOperations = new NamedParameterJdbcTemplate(dataSource);
/*     */   }
/*     */ 
/*     */   public SimpleJdbcTemplate(JdbcOperations classicJdbcTemplate)
/*     */   {
/*  78 */     this.namedParameterJdbcOperations = new NamedParameterJdbcTemplate(classicJdbcTemplate);
/*     */   }
/*     */ 
/*     */   public SimpleJdbcTemplate(NamedParameterJdbcOperations namedParameterJdbcTemplate)
/*     */   {
/*  86 */     this.namedParameterJdbcOperations = namedParameterJdbcTemplate;
/*     */   }
/*     */ 
/*     */   public JdbcOperations getJdbcOperations()
/*     */   {
/*  95 */     return this.namedParameterJdbcOperations.getJdbcOperations();
/*     */   }
/*     */ 
/*     */   public NamedParameterJdbcOperations getNamedParameterJdbcOperations()
/*     */   {
/* 103 */     return this.namedParameterJdbcOperations;
/*     */   }
/*     */ 
/*     */   public int queryForInt(String sql, Map<String, ?> args) throws DataAccessException
/*     */   {
/* 108 */     return getNamedParameterJdbcOperations().queryForInt(sql, args);
/*     */   }
/*     */ 
/*     */   public int queryForInt(String sql, SqlParameterSource args) throws DataAccessException {
/* 112 */     return getNamedParameterJdbcOperations().queryForInt(sql, args);
/*     */   }
/*     */ 
/*     */   public int queryForInt(String sql, Object[] args) throws DataAccessException {
/* 116 */     return ObjectUtils.isEmpty(args) ? getJdbcOperations().queryForInt(sql) : getJdbcOperations().queryForInt(sql, getArguments(args));
/*     */   }
/*     */ 
/*     */   public long queryForLong(String sql, Map<String, ?> args)
/*     */     throws DataAccessException
/*     */   {
/* 122 */     return getNamedParameterJdbcOperations().queryForLong(sql, args);
/*     */   }
/*     */ 
/*     */   public long queryForLong(String sql, SqlParameterSource args) throws DataAccessException {
/* 126 */     return getNamedParameterJdbcOperations().queryForLong(sql, args);
/*     */   }
/*     */ 
/*     */   public long queryForLong(String sql, Object[] args) throws DataAccessException {
/* 130 */     return ObjectUtils.isEmpty(args) ? getJdbcOperations().queryForLong(sql) : getJdbcOperations().queryForLong(sql, getArguments(args));
/*     */   }
/*     */ 
/*     */   public <T> T queryForObject(String sql, Class<T> requiredType, Map<String, ?> args)
/*     */     throws DataAccessException
/*     */   {
/* 136 */     return getNamedParameterJdbcOperations().queryForObject(sql, args, requiredType);
/*     */   }
/*     */ 
/*     */   public <T> T queryForObject(String sql, Class<T> requiredType, SqlParameterSource args) throws DataAccessException
/*     */   {
/* 141 */     return getNamedParameterJdbcOperations().queryForObject(sql, args, requiredType);
/*     */   }
/*     */ 
/*     */   public <T> T queryForObject(String sql, Class<T> requiredType, Object[] args) throws DataAccessException {
/* 145 */     return ObjectUtils.isEmpty(args) ? getJdbcOperations().queryForObject(sql, requiredType) : getJdbcOperations().queryForObject(sql, getArguments(args), requiredType);
/*     */   }
/*     */ 
/*     */   public <T> T queryForObject(String sql, RowMapper<T> rm, Map<String, ?> args)
/*     */     throws DataAccessException
/*     */   {
/* 151 */     return getNamedParameterJdbcOperations().queryForObject(sql, args, rm);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public <T> T queryForObject(String sql, ParameterizedRowMapper<T> rm, Map<String, ?> args) throws DataAccessException {
/* 156 */     return queryForObject(sql, rm, args);
/*     */   }
/*     */ 
/*     */   public <T> T queryForObject(String sql, RowMapper<T> rm, SqlParameterSource args) throws DataAccessException
/*     */   {
/* 161 */     return getNamedParameterJdbcOperations().queryForObject(sql, args, rm);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public <T> T queryForObject(String sql, ParameterizedRowMapper<T> rm, SqlParameterSource args) throws DataAccessException
/*     */   {
/* 167 */     return queryForObject(sql, rm, args);
/*     */   }
/*     */ 
/*     */   public <T> T queryForObject(String sql, RowMapper<T> rm, Object[] args) throws DataAccessException {
/* 171 */     return ObjectUtils.isEmpty(args) ? getJdbcOperations().queryForObject(sql, rm) : getJdbcOperations().queryForObject(sql, getArguments(args), rm);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public <T> T queryForObject(String sql, ParameterizedRowMapper<T> rm, Object[] args)
/*     */     throws DataAccessException
/*     */   {
/* 178 */     return queryForObject(sql, rm, args);
/*     */   }
/*     */ 
/*     */   public <T> List<T> query(String sql, RowMapper<T> rm, Map<String, ?> args) throws DataAccessException {
/* 182 */     return getNamedParameterJdbcOperations().query(sql, args, rm);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public <T> List<T> query(String sql, ParameterizedRowMapper<T> rm, Map<String, ?> args) throws DataAccessException {
/* 187 */     return query(sql, rm, args);
/*     */   }
/*     */ 
/*     */   public <T> List<T> query(String sql, RowMapper<T> rm, SqlParameterSource args) throws DataAccessException
/*     */   {
/* 192 */     return getNamedParameterJdbcOperations().query(sql, args, rm);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public <T> List<T> query(String sql, ParameterizedRowMapper<T> rm, SqlParameterSource args) throws DataAccessException
/*     */   {
/* 198 */     return query(sql, rm, args);
/*     */   }
/*     */ 
/*     */   public <T> List<T> query(String sql, RowMapper<T> rm, Object[] args) throws DataAccessException {
/* 202 */     return ObjectUtils.isEmpty(args) ? getJdbcOperations().query(sql, rm) : getJdbcOperations().query(sql, getArguments(args), rm);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public <T> List<T> query(String sql, ParameterizedRowMapper<T> rm, Object[] args)
/*     */     throws DataAccessException
/*     */   {
/* 209 */     return query(sql, rm, args);
/*     */   }
/*     */ 
/*     */   public Map<String, Object> queryForMap(String sql, Map<String, ?> args) throws DataAccessException {
/* 213 */     return getNamedParameterJdbcOperations().queryForMap(sql, args);
/*     */   }
/*     */ 
/*     */   public Map<String, Object> queryForMap(String sql, SqlParameterSource args) throws DataAccessException
/*     */   {
/* 218 */     return getNamedParameterJdbcOperations().queryForMap(sql, args);
/*     */   }
/*     */ 
/*     */   public Map<String, Object> queryForMap(String sql, Object[] args) throws DataAccessException {
/* 222 */     return ObjectUtils.isEmpty(args) ? getJdbcOperations().queryForMap(sql) : getJdbcOperations().queryForMap(sql, getArguments(args));
/*     */   }
/*     */ 
/*     */   public List<Map<String, Object>> queryForList(String sql, Map<String, ?> args)
/*     */     throws DataAccessException
/*     */   {
/* 228 */     return getNamedParameterJdbcOperations().queryForList(sql, args);
/*     */   }
/*     */ 
/*     */   public List<Map<String, Object>> queryForList(String sql, SqlParameterSource args) throws DataAccessException
/*     */   {
/* 233 */     return getNamedParameterJdbcOperations().queryForList(sql, args);
/*     */   }
/*     */ 
/*     */   public List<Map<String, Object>> queryForList(String sql, Object[] args) throws DataAccessException {
/* 237 */     return ObjectUtils.isEmpty(args) ? getJdbcOperations().queryForList(sql) : getJdbcOperations().queryForList(sql, getArguments(args));
/*     */   }
/*     */ 
/*     */   public int update(String sql, Map<String, ?> args)
/*     */     throws DataAccessException
/*     */   {
/* 243 */     return getNamedParameterJdbcOperations().update(sql, args);
/*     */   }
/*     */ 
/*     */   public int update(String sql, SqlParameterSource args) throws DataAccessException {
/* 247 */     return getNamedParameterJdbcOperations().update(sql, args);
/*     */   }
/*     */ 
/*     */   public int update(String sql, Object[] args) throws DataAccessException {
/* 251 */     return ObjectUtils.isEmpty(args) ? getJdbcOperations().update(sql) : getJdbcOperations().update(sql, getArguments(args));
/*     */   }
/*     */ 
/*     */   public int[] batchUpdate(String sql, List<Object[]> batchArgs)
/*     */   {
/* 257 */     return batchUpdate(sql, batchArgs, new int[0]);
/*     */   }
/*     */ 
/*     */   public int[] batchUpdate(String sql, List<Object[]> batchArgs, int[] argTypes) {
/* 261 */     return BatchUpdateUtils.executeBatchUpdate(sql, batchArgs, argTypes, getJdbcOperations());
/*     */   }
/*     */ 
/*     */   public int[] batchUpdate(String sql, Map<String, ?>[] batchValues) {
/* 265 */     return getNamedParameterJdbcOperations().batchUpdate(sql, batchValues);
/*     */   }
/*     */ 
/*     */   public int[] batchUpdate(String sql, SqlParameterSource[] batchArgs) {
/* 269 */     return getNamedParameterJdbcOperations().batchUpdate(sql, batchArgs);
/*     */   }
/*     */ 
/*     */   private Object[] getArguments(Object[] varArgs)
/*     */   {
/* 278 */     if ((varArgs.length == 1) && ((varArgs[0] instanceof Object[]))) {
/* 279 */       return (Object[])varArgs[0];
/*     */     }
/*     */ 
/* 282 */     return varArgs;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.simple.SimpleJdbcTemplate
 * JD-Core Version:    0.6.1
 */