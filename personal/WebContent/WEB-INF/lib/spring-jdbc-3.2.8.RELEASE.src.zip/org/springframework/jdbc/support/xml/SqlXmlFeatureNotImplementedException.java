/*    */ package org.springframework.jdbc.support.xml;
/*    */ 
/*    */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*    */ 
/*    */ public class SqlXmlFeatureNotImplementedException extends InvalidDataAccessApiUsageException
/*    */ {
/*    */   public SqlXmlFeatureNotImplementedException(String msg)
/*    */   {
/* 36 */     super(msg);
/*    */   }
/*    */ 
/*    */   public SqlXmlFeatureNotImplementedException(String msg, Throwable cause)
/*    */   {
/* 45 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.xml.SqlXmlFeatureNotImplementedException
 * JD-Core Version:    0.6.1
 */