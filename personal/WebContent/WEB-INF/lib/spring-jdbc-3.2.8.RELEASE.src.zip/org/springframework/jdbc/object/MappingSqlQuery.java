/*    */ package org.springframework.jdbc.object;
/*    */ 
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import java.util.Map;
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ public abstract class MappingSqlQuery<T> extends MappingSqlQueryWithParameters<T>
/*    */ {
/*    */   public MappingSqlQuery()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MappingSqlQuery(DataSource ds, String sql)
/*    */   {
/* 52 */     super(ds, sql);
/*    */   }
/*    */ 
/*    */   protected final T mapRow(ResultSet rs, int rowNum, Object[] parameters, Map context)
/*    */     throws SQLException
/*    */   {
/* 65 */     return mapRow(rs, rowNum);
/*    */   }
/*    */ 
/*    */   protected abstract T mapRow(ResultSet paramResultSet, int paramInt)
/*    */     throws SQLException;
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.object.MappingSqlQuery
 * JD-Core Version:    0.6.1
 */