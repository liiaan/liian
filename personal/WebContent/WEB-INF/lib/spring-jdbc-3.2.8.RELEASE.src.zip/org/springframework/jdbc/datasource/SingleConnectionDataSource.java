/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.DisposableBean;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ObjectUtils;
/*     */ 
/*     */ public class SingleConnectionDataSource extends DriverManagerDataSource
/*     */   implements SmartDataSource, DisposableBean
/*     */ {
/*     */   private boolean suppressClose;
/*     */   private Boolean autoCommit;
/*     */   private Connection target;
/*     */   private Connection connection;
/*  74 */   private final Object connectionMonitor = new Object();
/*     */ 
/*     */   public SingleConnectionDataSource()
/*     */   {
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public SingleConnectionDataSource(String driverClassName, String url, String username, String password, boolean suppressClose)
/*     */   {
/* 101 */     super(driverClassName, url, username, password);
/* 102 */     this.suppressClose = suppressClose;
/*     */   }
/*     */ 
/*     */   public SingleConnectionDataSource(String url, String username, String password, boolean suppressClose)
/*     */   {
/* 116 */     super(url, username, password);
/* 117 */     this.suppressClose = suppressClose;
/*     */   }
/*     */ 
/*     */   public SingleConnectionDataSource(String url, boolean suppressClose)
/*     */   {
/* 129 */     super(url);
/* 130 */     this.suppressClose = suppressClose;
/*     */   }
/*     */ 
/*     */   public SingleConnectionDataSource(Connection target, boolean suppressClose)
/*     */   {
/* 142 */     Assert.notNull(target, "Connection must not be null");
/* 143 */     this.target = target;
/* 144 */     this.suppressClose = suppressClose;
/* 145 */     this.connection = (suppressClose ? getCloseSuppressingConnectionProxy(target) : target);
/*     */   }
/*     */ 
/*     */   public void setSuppressClose(boolean suppressClose)
/*     */   {
/* 154 */     this.suppressClose = suppressClose;
/*     */   }
/*     */ 
/*     */   protected boolean isSuppressClose()
/*     */   {
/* 162 */     return this.suppressClose;
/*     */   }
/*     */ 
/*     */   public void setAutoCommit(boolean autoCommit)
/*     */   {
/* 169 */     this.autoCommit = Boolean.valueOf(autoCommit);
/*     */   }
/*     */ 
/*     */   protected Boolean getAutoCommitValue()
/*     */   {
/* 177 */     return this.autoCommit;
/*     */   }
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws SQLException
/*     */   {
/* 183 */     synchronized (this.connectionMonitor) {
/* 184 */       if (this.connection == null)
/*     */       {
/* 186 */         initConnection();
/*     */       }
/* 188 */       if (this.connection.isClosed()) {
/* 189 */         throw new SQLException("Connection was closed in SingleConnectionDataSource. Check that user code checks shouldClose() before closing Connections, or set 'suppressClose' to 'true'");
/*     */       }
/*     */ 
/* 193 */       return this.connection;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Connection getConnection(String username, String password)
/*     */     throws SQLException
/*     */   {
/* 204 */     if ((ObjectUtils.nullSafeEquals(username, getUsername())) && (ObjectUtils.nullSafeEquals(password, getPassword())))
/*     */     {
/* 206 */       return getConnection();
/*     */     }
/*     */ 
/* 209 */     throw new SQLException("SingleConnectionDataSource does not support custom username and password");
/*     */   }
/*     */ 
/*     */   public boolean shouldClose(Connection con)
/*     */   {
/* 217 */     synchronized (this.connectionMonitor) {
/* 218 */       return (con != this.connection) && (con != this.target);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void destroy()
/*     */   {
/* 229 */     synchronized (this.connectionMonitor) {
/* 230 */       closeConnection();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void initConnection()
/*     */     throws SQLException
/*     */   {
/* 239 */     if (getUrl() == null) {
/* 240 */       throw new IllegalStateException("'url' property is required for lazily initializing a Connection");
/*     */     }
/* 242 */     synchronized (this.connectionMonitor) {
/* 243 */       closeConnection();
/* 244 */       this.target = getConnectionFromDriver(getUsername(), getPassword());
/* 245 */       prepareConnection(this.target);
/* 246 */       if (this.logger.isInfoEnabled()) {
/* 247 */         this.logger.info("Established shared JDBC Connection: " + this.target);
/*     */       }
/* 249 */       this.connection = (isSuppressClose() ? getCloseSuppressingConnectionProxy(this.target) : this.target);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void resetConnection()
/*     */   {
/* 257 */     synchronized (this.connectionMonitor) {
/* 258 */       closeConnection();
/* 259 */       this.target = null;
/* 260 */       this.connection = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void prepareConnection(Connection con)
/*     */     throws SQLException
/*     */   {
/* 272 */     Boolean autoCommit = getAutoCommitValue();
/* 273 */     if ((autoCommit != null) && (con.getAutoCommit() != autoCommit.booleanValue()))
/* 274 */       con.setAutoCommit(autoCommit.booleanValue());
/*     */   }
/*     */ 
/*     */   private void closeConnection()
/*     */   {
/* 282 */     if (this.target != null)
/*     */       try {
/* 284 */         this.target.close();
/*     */       }
/*     */       catch (Throwable ex) {
/* 287 */         this.logger.warn("Could not close shared JDBC Connection", ex);
/*     */       }
/*     */   }
/*     */ 
/*     */   protected Connection getCloseSuppressingConnectionProxy(Connection target)
/*     */   {
/* 299 */     return (Connection)Proxy.newProxyInstance(ConnectionProxy.class.getClassLoader(), new Class[] { ConnectionProxy.class }, new CloseSuppressingInvocationHandler(target));
/*     */   }
/*     */ 
/*     */   private static class CloseSuppressingInvocationHandler
/*     */     implements InvocationHandler
/*     */   {
/*     */     private final Connection target;
/*     */ 
/*     */     public CloseSuppressingInvocationHandler(Connection target)
/*     */     {
/* 314 */       this.target = target;
/*     */     }
/*     */ 
/*     */     public Object invoke(Object proxy, Method method, Object[] args)
/*     */       throws Throwable
/*     */     {
/* 320 */       if (method.getName().equals("equals"))
/*     */       {
/* 322 */         return Boolean.valueOf(proxy == args[0]);
/*     */       }
/* 324 */       if (method.getName().equals("hashCode"))
/*     */       {
/* 326 */         return Integer.valueOf(System.identityHashCode(proxy));
/*     */       }
/* 328 */       if (method.getName().equals("unwrap")) {
/* 329 */         if (((Class)args[0]).isInstance(proxy)) {
/* 330 */           return proxy;
/*     */         }
/*     */       }
/* 333 */       else if (method.getName().equals("isWrapperFor")) {
/* 334 */         if (((Class)args[0]).isInstance(proxy))
/* 335 */           return Boolean.valueOf(true);
/*     */       }
/*     */       else {
/* 338 */         if (method.getName().equals("close"))
/*     */         {
/* 340 */           return null;
/*     */         }
/* 342 */         if (method.getName().equals("isClosed")) {
/* 343 */           return Boolean.valueOf(false);
/*     */         }
/* 345 */         if (method.getName().equals("getTargetConnection"))
/*     */         {
/* 347 */           return this.target;
/*     */         }
/*     */       }
/*     */       try
/*     */       {
/* 352 */         return method.invoke(this.target, args);
/*     */       }
/*     */       catch (InvocationTargetException ex) {
/* 355 */         throw ex.getTargetException();
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.SingleConnectionDataSource
 * JD-Core Version:    0.6.1
 */