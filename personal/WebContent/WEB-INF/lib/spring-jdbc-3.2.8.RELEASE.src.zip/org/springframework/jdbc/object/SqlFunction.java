/*     */ package org.springframework.jdbc.object;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.TypeMismatchDataAccessException;
/*     */ import org.springframework.jdbc.core.SingleColumnRowMapper;
/*     */ 
/*     */ public class SqlFunction<T> extends MappingSqlQuery<T>
/*     */ {
/*  52 */   private final SingleColumnRowMapper<T> rowMapper = new SingleColumnRowMapper();
/*     */ 
/*     */   public SqlFunction()
/*     */   {
/*  64 */     setRowsExpected(1);
/*     */   }
/*     */ 
/*     */   public SqlFunction(DataSource ds, String sql)
/*     */   {
/*  74 */     setRowsExpected(1);
/*  75 */     setDataSource(ds);
/*  76 */     setSql(sql);
/*     */   }
/*     */ 
/*     */   public SqlFunction(DataSource ds, String sql, int[] types)
/*     */   {
/*  88 */     setRowsExpected(1);
/*  89 */     setDataSource(ds);
/*  90 */     setSql(sql);
/*  91 */     setTypes(types);
/*     */   }
/*     */ 
/*     */   public SqlFunction(DataSource ds, String sql, int[] types, Class<T> resultType)
/*     */   {
/* 105 */     setRowsExpected(1);
/* 106 */     setDataSource(ds);
/* 107 */     setSql(sql);
/* 108 */     setTypes(types);
/* 109 */     setResultType(resultType);
/*     */   }
/*     */ 
/*     */   public void setResultType(Class<T> resultType)
/*     */   {
/* 119 */     this.rowMapper.setRequiredType(resultType);
/*     */   }
/*     */ 
/*     */   protected T mapRow(ResultSet rs, int rowNum)
/*     */     throws SQLException
/*     */   {
/* 130 */     return this.rowMapper.mapRow(rs, rowNum);
/*     */   }
/*     */ 
/*     */   public int run()
/*     */   {
/* 139 */     return run(new Object[0]);
/*     */   }
/*     */ 
/*     */   public int run(int parameter)
/*     */   {
/* 148 */     return run(new Object[] { Integer.valueOf(parameter) });
/*     */   }
/*     */ 
/*     */   public int run(Object[] parameters)
/*     */   {
/* 159 */     Object obj = super.findObject(parameters);
/* 160 */     if (!(obj instanceof Number)) {
/* 161 */       throw new TypeMismatchDataAccessException("Couldn't convert result object [" + obj + "] to int");
/*     */     }
/* 163 */     return ((Number)obj).intValue();
/*     */   }
/*     */ 
/*     */   public Object runGeneric()
/*     */   {
/* 172 */     return findObject((Object[])null);
/*     */   }
/*     */ 
/*     */   public Object runGeneric(int parameter)
/*     */   {
/* 181 */     return findObject(parameter);
/*     */   }
/*     */ 
/*     */   public Object runGeneric(Object[] parameters)
/*     */   {
/* 193 */     return findObject(parameters);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.object.SqlFunction
 * JD-Core Version:    0.6.1
 */