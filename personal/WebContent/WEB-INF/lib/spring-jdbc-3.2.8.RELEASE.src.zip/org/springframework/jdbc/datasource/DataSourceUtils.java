/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.jdbc.CannotGetJdbcConnectionException;
/*     */ import org.springframework.transaction.TransactionDefinition;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationAdapter;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class DataSourceUtils
/*     */ {
/*     */   public static final int CONNECTION_SYNCHRONIZATION_ORDER = 1000;
/*  58 */   private static final Log logger = LogFactory.getLog(DataSourceUtils.class);
/*     */ 
/*     */   public static Connection getConnection(DataSource dataSource)
/*     */     throws CannotGetJdbcConnectionException
/*     */   {
/*     */     try
/*     */     {
/*  77 */       return doGetConnection(dataSource);
/*     */     }
/*     */     catch (SQLException ex) {
/*  80 */       throw new CannotGetJdbcConnectionException("Could not get JDBC Connection", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Connection doGetConnection(DataSource dataSource)
/*     */     throws SQLException
/*     */   {
/*  97 */     Assert.notNull(dataSource, "No DataSource specified");
/*     */ 
/*  99 */     ConnectionHolder conHolder = (ConnectionHolder)TransactionSynchronizationManager.getResource(dataSource);
/* 100 */     if ((conHolder != null) && ((conHolder.hasConnection()) || (conHolder.isSynchronizedWithTransaction()))) {
/* 101 */       conHolder.requested();
/* 102 */       if (!conHolder.hasConnection()) {
/* 103 */         logger.debug("Fetching resumed JDBC Connection from DataSource");
/* 104 */         conHolder.setConnection(dataSource.getConnection());
/*     */       }
/* 106 */       return conHolder.getConnection();
/*     */     }
/*     */ 
/* 110 */     logger.debug("Fetching JDBC Connection from DataSource");
/* 111 */     Connection con = dataSource.getConnection();
/*     */ 
/* 113 */     if (TransactionSynchronizationManager.isSynchronizationActive()) {
/* 114 */       logger.debug("Registering transaction synchronization for JDBC Connection");
/*     */ 
/* 117 */       ConnectionHolder holderToUse = conHolder;
/* 118 */       if (holderToUse == null) {
/* 119 */         holderToUse = new ConnectionHolder(con);
/*     */       }
/*     */       else {
/* 122 */         holderToUse.setConnection(con);
/*     */       }
/* 124 */       holderToUse.requested();
/* 125 */       TransactionSynchronizationManager.registerSynchronization(new ConnectionSynchronization(holderToUse, dataSource));
/*     */ 
/* 127 */       holderToUse.setSynchronizedWithTransaction(true);
/* 128 */       if (holderToUse != conHolder) {
/* 129 */         TransactionSynchronizationManager.bindResource(dataSource, holderToUse);
/*     */       }
/*     */     }
/*     */ 
/* 133 */     return con;
/*     */   }
/*     */ 
/*     */   public static Integer prepareConnectionForTransaction(Connection con, TransactionDefinition definition)
/*     */     throws SQLException
/*     */   {
/* 147 */     Assert.notNull(con, "No Connection specified");
/*     */ 
/* 150 */     if ((definition != null) && (definition.isReadOnly())) {
/*     */       try {
/* 152 */         if (logger.isDebugEnabled()) {
/* 153 */           logger.debug("Setting JDBC Connection [" + con + "] read-only");
/*     */         }
/* 155 */         con.setReadOnly(true);
/*     */       }
/*     */       catch (SQLException ex) {
/* 158 */         Throwable exToCheck = ex;
/* 159 */         while (exToCheck != null) {
/* 160 */           if (exToCheck.getClass().getSimpleName().contains("Timeout"))
/*     */           {
/* 162 */             throw ex;
/*     */           }
/* 164 */           exToCheck = exToCheck.getCause();
/*     */         }
/*     */ 
/* 167 */         logger.debug("Could not set JDBC Connection read-only", ex);
/*     */       }
/*     */       catch (RuntimeException ex) {
/* 170 */         Throwable exToCheck = ex;
/* 171 */         while (exToCheck != null) {
/* 172 */           if (exToCheck.getClass().getSimpleName().contains("Timeout"))
/*     */           {
/* 174 */             throw ex;
/*     */           }
/* 176 */           exToCheck = exToCheck.getCause();
/*     */         }
/*     */ 
/* 179 */         logger.debug("Could not set JDBC Connection read-only", ex);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 184 */     Integer previousIsolationLevel = null;
/* 185 */     if ((definition != null) && (definition.getIsolationLevel() != -1)) {
/* 186 */       if (logger.isDebugEnabled()) {
/* 187 */         logger.debug("Changing isolation level of JDBC Connection [" + con + "] to " + definition.getIsolationLevel());
/*     */       }
/*     */ 
/* 190 */       int currentIsolation = con.getTransactionIsolation();
/* 191 */       if (currentIsolation != definition.getIsolationLevel()) {
/* 192 */         previousIsolationLevel = Integer.valueOf(currentIsolation);
/* 193 */         con.setTransactionIsolation(definition.getIsolationLevel());
/*     */       }
/*     */     }
/*     */ 
/* 197 */     return previousIsolationLevel;
/*     */   }
/*     */ 
/*     */   public static void resetConnectionAfterTransaction(Connection con, Integer previousIsolationLevel)
/*     */   {
/* 208 */     Assert.notNull(con, "No Connection specified");
/*     */     try
/*     */     {
/* 211 */       if (previousIsolationLevel != null) {
/* 212 */         if (logger.isDebugEnabled()) {
/* 213 */           logger.debug("Resetting isolation level of JDBC Connection [" + con + "] to " + previousIsolationLevel);
/*     */         }
/*     */ 
/* 216 */         con.setTransactionIsolation(previousIsolationLevel.intValue());
/*     */       }
/*     */ 
/* 220 */       if (con.isReadOnly()) {
/* 221 */         if (logger.isDebugEnabled()) {
/* 222 */           logger.debug("Resetting read-only flag of JDBC Connection [" + con + "]");
/*     */         }
/* 224 */         con.setReadOnly(false);
/*     */       }
/*     */     }
/*     */     catch (Throwable ex) {
/* 228 */       logger.debug("Could not reset JDBC Connection after transaction", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static boolean isConnectionTransactional(Connection con, DataSource dataSource)
/*     */   {
/* 241 */     if (dataSource == null) {
/* 242 */       return false;
/*     */     }
/* 244 */     ConnectionHolder conHolder = (ConnectionHolder)TransactionSynchronizationManager.getResource(dataSource);
/* 245 */     return (conHolder != null) && (connectionEquals(conHolder, con));
/*     */   }
/*     */ 
/*     */   public static void applyTransactionTimeout(Statement stmt, DataSource dataSource)
/*     */     throws SQLException
/*     */   {
/* 257 */     applyTimeout(stmt, dataSource, 0);
/*     */   }
/*     */ 
/*     */   public static void applyTimeout(Statement stmt, DataSource dataSource, int timeout)
/*     */     throws SQLException
/*     */   {
/* 270 */     Assert.notNull(stmt, "No Statement specified");
/* 271 */     Assert.notNull(dataSource, "No DataSource specified");
/* 272 */     ConnectionHolder holder = (ConnectionHolder)TransactionSynchronizationManager.getResource(dataSource);
/* 273 */     if ((holder != null) && (holder.hasTimeout()))
/*     */     {
/* 275 */       stmt.setQueryTimeout(holder.getTimeToLiveInSeconds());
/*     */     }
/* 277 */     else if (timeout > 0)
/*     */     {
/* 279 */       stmt.setQueryTimeout(timeout);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void releaseConnection(Connection con, DataSource dataSource)
/*     */   {
/*     */     try
/*     */     {
/* 294 */       doReleaseConnection(con, dataSource);
/*     */     }
/*     */     catch (SQLException ex) {
/* 297 */       logger.debug("Could not close JDBC Connection", ex);
/*     */     }
/*     */     catch (Throwable ex) {
/* 300 */       logger.debug("Unexpected exception on closing JDBC Connection", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void doReleaseConnection(Connection con, DataSource dataSource)
/*     */     throws SQLException
/*     */   {
/* 316 */     if (con == null) {
/* 317 */       return;
/*     */     }
/* 319 */     if (dataSource != null) {
/* 320 */       ConnectionHolder conHolder = (ConnectionHolder)TransactionSynchronizationManager.getResource(dataSource);
/* 321 */       if ((conHolder != null) && (connectionEquals(conHolder, con)))
/*     */       {
/* 323 */         conHolder.released();
/* 324 */         return;
/*     */       }
/*     */     }
/* 327 */     logger.debug("Returning JDBC Connection to DataSource");
/* 328 */     doCloseConnection(con, dataSource);
/*     */   }
/*     */ 
/*     */   public static void doCloseConnection(Connection con, DataSource dataSource)
/*     */     throws SQLException
/*     */   {
/* 340 */     if ((!(dataSource instanceof SmartDataSource)) || (((SmartDataSource)dataSource).shouldClose(con)))
/* 341 */       con.close();
/*     */   }
/*     */ 
/*     */   private static boolean connectionEquals(ConnectionHolder conHolder, Connection passedInCon)
/*     */   {
/* 356 */     if (!conHolder.hasConnection()) {
/* 357 */       return false;
/*     */     }
/* 359 */     Connection heldCon = conHolder.getConnection();
/*     */ 
/* 362 */     return (heldCon == passedInCon) || (heldCon.equals(passedInCon)) || (getTargetConnection(heldCon).equals(passedInCon));
/*     */   }
/*     */ 
/*     */   public static Connection getTargetConnection(Connection con)
/*     */   {
/* 375 */     Connection conToUse = con;
/* 376 */     while ((conToUse instanceof ConnectionProxy)) {
/* 377 */       conToUse = ((ConnectionProxy)conToUse).getTargetConnection();
/*     */     }
/* 379 */     return conToUse;
/*     */   }
/*     */ 
/*     */   private static int getConnectionSynchronizationOrder(DataSource dataSource)
/*     */   {
/* 391 */     int order = 1000;
/* 392 */     DataSource currDs = dataSource;
/* 393 */     while ((currDs instanceof DelegatingDataSource)) {
/* 394 */       order--;
/* 395 */       currDs = ((DelegatingDataSource)currDs).getTargetDataSource();
/*     */     }
/* 397 */     return order;
/*     */   }
/*     */ 
/*     */   private static class ConnectionSynchronization extends TransactionSynchronizationAdapter
/*     */   {
/*     */     private final ConnectionHolder connectionHolder;
/*     */     private final DataSource dataSource;
/*     */     private int order;
/* 414 */     private boolean holderActive = true;
/*     */ 
/*     */     public ConnectionSynchronization(ConnectionHolder connectionHolder, DataSource dataSource) {
/* 417 */       this.connectionHolder = connectionHolder;
/* 418 */       this.dataSource = dataSource;
/* 419 */       this.order = DataSourceUtils.getConnectionSynchronizationOrder(dataSource);
/*     */     }
/*     */ 
/*     */     public int getOrder()
/*     */     {
/* 424 */       return this.order;
/*     */     }
/*     */ 
/*     */     public void suspend()
/*     */     {
/* 429 */       if (this.holderActive) {
/* 430 */         TransactionSynchronizationManager.unbindResource(this.dataSource);
/* 431 */         if ((this.connectionHolder.hasConnection()) && (!this.connectionHolder.isOpen()))
/*     */         {
/* 436 */           DataSourceUtils.releaseConnection(this.connectionHolder.getConnection(), this.dataSource);
/* 437 */           this.connectionHolder.setConnection(null);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     public void resume()
/*     */     {
/* 444 */       if (this.holderActive)
/* 445 */         TransactionSynchronizationManager.bindResource(this.dataSource, this.connectionHolder);
/*     */     }
/*     */ 
/*     */     public void beforeCompletion()
/*     */     {
/* 456 */       if (!this.connectionHolder.isOpen()) {
/* 457 */         TransactionSynchronizationManager.unbindResource(this.dataSource);
/* 458 */         this.holderActive = false;
/* 459 */         if (this.connectionHolder.hasConnection())
/* 460 */           DataSourceUtils.releaseConnection(this.connectionHolder.getConnection(), this.dataSource);
/*     */       }
/*     */     }
/*     */ 
/*     */     public void afterCompletion(int status)
/*     */     {
/* 470 */       if (this.holderActive)
/*     */       {
/* 473 */         TransactionSynchronizationManager.unbindResourceIfPossible(this.dataSource);
/* 474 */         this.holderActive = false;
/* 475 */         if (this.connectionHolder.hasConnection()) {
/* 476 */           DataSourceUtils.releaseConnection(this.connectionHolder.getConnection(), this.dataSource);
/*     */ 
/* 478 */           this.connectionHolder.setConnection(null);
/*     */         }
/*     */       }
/* 481 */       this.connectionHolder.reset();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.DataSourceUtils
 * JD-Core Version:    0.6.1
 */