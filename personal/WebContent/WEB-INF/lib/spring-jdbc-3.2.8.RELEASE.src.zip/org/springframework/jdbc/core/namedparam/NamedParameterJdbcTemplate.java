/*     */ package org.springframework.jdbc.core.namedparam;
/*     */ 
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.support.DataAccessUtils;
/*     */ import org.springframework.jdbc.core.ColumnMapRowMapper;
/*     */ import org.springframework.jdbc.core.JdbcOperations;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.PreparedStatementCallback;
/*     */ import org.springframework.jdbc.core.PreparedStatementCreator;
/*     */ import org.springframework.jdbc.core.PreparedStatementCreatorFactory;
/*     */ import org.springframework.jdbc.core.ResultSetExtractor;
/*     */ import org.springframework.jdbc.core.RowCallbackHandler;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ import org.springframework.jdbc.core.SingleColumnRowMapper;
/*     */ import org.springframework.jdbc.core.SqlRowSetResultSetExtractor;
/*     */ import org.springframework.jdbc.support.KeyHolder;
/*     */ import org.springframework.jdbc.support.rowset.SqlRowSet;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class NamedParameterJdbcTemplate
/*     */   implements NamedParameterJdbcOperations
/*     */ {
/*     */   public static final int DEFAULT_CACHE_LIMIT = 256;
/*     */   private final JdbcOperations classicJdbcTemplate;
/*  70 */   private volatile int cacheLimit = 256;
/*     */ 
/*  73 */   private final Map<String, ParsedSql> parsedSqlCache = new LinkedHashMap(256, 0.75F, true)
/*     */   {
/*     */     protected boolean removeEldestEntry(Map.Entry<String, ParsedSql> eldest)
/*     */     {
/*  78 */       return size() > NamedParameterJdbcTemplate.this.getCacheLimit();
/*     */     }
/*  73 */   };
/*     */ 
/*     */   public NamedParameterJdbcTemplate(DataSource dataSource)
/*     */   {
/*  89 */     Assert.notNull(dataSource, "DataSource must not be null");
/*  90 */     this.classicJdbcTemplate = new JdbcTemplate(dataSource);
/*     */   }
/*     */ 
/*     */   public NamedParameterJdbcTemplate(JdbcOperations classicJdbcTemplate)
/*     */   {
/*  99 */     Assert.notNull(classicJdbcTemplate, "JdbcTemplate must not be null");
/* 100 */     this.classicJdbcTemplate = classicJdbcTemplate;
/*     */   }
/*     */ 
/*     */   public JdbcOperations getJdbcOperations()
/*     */   {
/* 109 */     return this.classicJdbcTemplate;
/*     */   }
/*     */ 
/*     */   public void setCacheLimit(int cacheLimit)
/*     */   {
/* 117 */     this.cacheLimit = cacheLimit;
/*     */   }
/*     */ 
/*     */   public int getCacheLimit()
/*     */   {
/* 124 */     return this.cacheLimit;
/*     */   }
/*     */ 
/*     */   public <T> T execute(String sql, SqlParameterSource paramSource, PreparedStatementCallback<T> action)
/*     */     throws DataAccessException
/*     */   {
/* 131 */     return getJdbcOperations().execute(getPreparedStatementCreator(sql, paramSource), action);
/*     */   }
/*     */ 
/*     */   public <T> T execute(String sql, Map<String, ?> paramMap, PreparedStatementCallback<T> action)
/*     */     throws DataAccessException
/*     */   {
/* 137 */     return execute(sql, new MapSqlParameterSource(paramMap), action);
/*     */   }
/*     */ 
/*     */   public <T> T execute(String sql, PreparedStatementCallback<T> action) throws DataAccessException {
/* 141 */     return execute(sql, EmptySqlParameterSource.INSTANCE, action);
/*     */   }
/*     */ 
/*     */   public <T> T query(String sql, SqlParameterSource paramSource, ResultSetExtractor<T> rse)
/*     */     throws DataAccessException
/*     */   {
/* 147 */     return getJdbcOperations().query(getPreparedStatementCreator(sql, paramSource), rse);
/*     */   }
/*     */ 
/*     */   public <T> T query(String sql, Map<String, ?> paramMap, ResultSetExtractor<T> rse)
/*     */     throws DataAccessException
/*     */   {
/* 153 */     return query(sql, new MapSqlParameterSource(paramMap), rse);
/*     */   }
/*     */ 
/*     */   public <T> T query(String sql, ResultSetExtractor<T> rse) throws DataAccessException {
/* 157 */     return query(sql, EmptySqlParameterSource.INSTANCE, rse);
/*     */   }
/*     */ 
/*     */   public void query(String sql, SqlParameterSource paramSource, RowCallbackHandler rch)
/*     */     throws DataAccessException
/*     */   {
/* 163 */     getJdbcOperations().query(getPreparedStatementCreator(sql, paramSource), rch);
/*     */   }
/*     */ 
/*     */   public void query(String sql, Map<String, ?> paramMap, RowCallbackHandler rch)
/*     */     throws DataAccessException
/*     */   {
/* 169 */     query(sql, new MapSqlParameterSource(paramMap), rch);
/*     */   }
/*     */ 
/*     */   public void query(String sql, RowCallbackHandler rch) throws DataAccessException {
/* 173 */     query(sql, EmptySqlParameterSource.INSTANCE, rch);
/*     */   }
/*     */ 
/*     */   public <T> List<T> query(String sql, SqlParameterSource paramSource, RowMapper<T> rowMapper)
/*     */     throws DataAccessException
/*     */   {
/* 179 */     return getJdbcOperations().query(getPreparedStatementCreator(sql, paramSource), rowMapper);
/*     */   }
/*     */ 
/*     */   public <T> List<T> query(String sql, Map<String, ?> paramMap, RowMapper<T> rowMapper)
/*     */     throws DataAccessException
/*     */   {
/* 185 */     return query(sql, new MapSqlParameterSource(paramMap), rowMapper);
/*     */   }
/*     */ 
/*     */   public <T> List<T> query(String sql, RowMapper<T> rowMapper) throws DataAccessException {
/* 189 */     return query(sql, EmptySqlParameterSource.INSTANCE, rowMapper);
/*     */   }
/*     */ 
/*     */   public <T> T queryForObject(String sql, SqlParameterSource paramSource, RowMapper<T> rowMapper)
/*     */     throws DataAccessException
/*     */   {
/* 195 */     List results = getJdbcOperations().query(getPreparedStatementCreator(sql, paramSource), rowMapper);
/* 196 */     return DataAccessUtils.requiredSingleResult(results);
/*     */   }
/*     */ 
/*     */   public <T> T queryForObject(String sql, Map<String, ?> paramMap, RowMapper<T> rowMapper)
/*     */     throws DataAccessException
/*     */   {
/* 202 */     return queryForObject(sql, new MapSqlParameterSource(paramMap), rowMapper);
/*     */   }
/*     */ 
/*     */   public <T> T queryForObject(String sql, SqlParameterSource paramSource, Class<T> requiredType)
/*     */     throws DataAccessException
/*     */   {
/* 208 */     return queryForObject(sql, paramSource, new SingleColumnRowMapper(requiredType));
/*     */   }
/*     */ 
/*     */   public <T> T queryForObject(String sql, Map<String, ?> paramMap, Class<T> requiredType)
/*     */     throws DataAccessException
/*     */   {
/* 214 */     return queryForObject(sql, paramMap, new SingleColumnRowMapper(requiredType));
/*     */   }
/*     */ 
/*     */   public Map<String, Object> queryForMap(String sql, SqlParameterSource paramSource) throws DataAccessException {
/* 218 */     return (Map)queryForObject(sql, paramSource, new ColumnMapRowMapper());
/*     */   }
/*     */ 
/*     */   public Map<String, Object> queryForMap(String sql, Map<String, ?> paramMap) throws DataAccessException {
/* 222 */     return (Map)queryForObject(sql, paramMap, new ColumnMapRowMapper());
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public long queryForLong(String sql, SqlParameterSource paramSource) throws DataAccessException {
/* 227 */     Number number = (Number)queryForObject(sql, paramSource, Long.class);
/* 228 */     return number != null ? number.longValue() : 0L;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public long queryForLong(String sql, Map<String, ?> paramMap) throws DataAccessException {
/* 233 */     return queryForLong(sql, new MapSqlParameterSource(paramMap));
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public int queryForInt(String sql, SqlParameterSource paramSource) throws DataAccessException {
/* 238 */     Number number = (Number)queryForObject(sql, paramSource, Integer.class);
/* 239 */     return number != null ? number.intValue() : 0;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public int queryForInt(String sql, Map<String, ?> paramMap) throws DataAccessException {
/* 244 */     return queryForInt(sql, new MapSqlParameterSource(paramMap));
/*     */   }
/*     */ 
/*     */   public <T> List<T> queryForList(String sql, SqlParameterSource paramSource, Class<T> elementType)
/*     */     throws DataAccessException
/*     */   {
/* 250 */     return query(sql, paramSource, new SingleColumnRowMapper(elementType));
/*     */   }
/*     */ 
/*     */   public <T> List<T> queryForList(String sql, Map<String, ?> paramMap, Class<T> elementType)
/*     */     throws DataAccessException
/*     */   {
/* 256 */     return queryForList(sql, new MapSqlParameterSource(paramMap), elementType);
/*     */   }
/*     */ 
/*     */   public List<Map<String, Object>> queryForList(String sql, SqlParameterSource paramSource)
/*     */     throws DataAccessException
/*     */   {
/* 262 */     return query(sql, paramSource, new ColumnMapRowMapper());
/*     */   }
/*     */ 
/*     */   public List<Map<String, Object>> queryForList(String sql, Map<String, ?> paramMap)
/*     */     throws DataAccessException
/*     */   {
/* 268 */     return queryForList(sql, new MapSqlParameterSource(paramMap));
/*     */   }
/*     */ 
/*     */   public SqlRowSet queryForRowSet(String sql, SqlParameterSource paramSource) throws DataAccessException {
/* 272 */     return (SqlRowSet)getJdbcOperations().query(getPreparedStatementCreator(sql, paramSource), new SqlRowSetResultSetExtractor());
/*     */   }
/*     */ 
/*     */   public SqlRowSet queryForRowSet(String sql, Map<String, ?> paramMap) throws DataAccessException
/*     */   {
/* 277 */     return queryForRowSet(sql, new MapSqlParameterSource(paramMap));
/*     */   }
/*     */ 
/*     */   public int update(String sql, SqlParameterSource paramSource) throws DataAccessException {
/* 281 */     return getJdbcOperations().update(getPreparedStatementCreator(sql, paramSource));
/*     */   }
/*     */ 
/*     */   public int update(String sql, Map<String, ?> paramMap) throws DataAccessException {
/* 285 */     return update(sql, new MapSqlParameterSource(paramMap));
/*     */   }
/*     */ 
/*     */   public int update(String sql, SqlParameterSource paramSource, KeyHolder generatedKeyHolder)
/*     */     throws DataAccessException
/*     */   {
/* 291 */     return update(sql, paramSource, generatedKeyHolder, null);
/*     */   }
/*     */ 
/*     */   public int update(String sql, SqlParameterSource paramSource, KeyHolder generatedKeyHolder, String[] keyColumnNames)
/*     */     throws DataAccessException
/*     */   {
/* 298 */     ParsedSql parsedSql = getParsedSql(sql);
/* 299 */     String sqlToUse = NamedParameterUtils.substituteNamedParameters(parsedSql, paramSource);
/* 300 */     Object[] params = NamedParameterUtils.buildValueArray(parsedSql, paramSource, null);
/* 301 */     List declaredParameters = NamedParameterUtils.buildSqlParameterList(parsedSql, paramSource);
/* 302 */     PreparedStatementCreatorFactory pscf = new PreparedStatementCreatorFactory(sqlToUse, declaredParameters);
/* 303 */     if (keyColumnNames != null) {
/* 304 */       pscf.setGeneratedKeysColumnNames(keyColumnNames);
/*     */     }
/*     */     else {
/* 307 */       pscf.setReturnGeneratedKeys(true);
/*     */     }
/* 309 */     return getJdbcOperations().update(pscf.newPreparedStatementCreator(params), generatedKeyHolder);
/*     */   }
/*     */ 
/*     */   public int[] batchUpdate(String sql, Map<String, ?>[] batchValues) {
/* 313 */     SqlParameterSource[] batchArgs = new SqlParameterSource[batchValues.length];
/* 314 */     int i = 0;
/* 315 */     for (Map values : batchValues) {
/* 316 */       batchArgs[i] = new MapSqlParameterSource(values);
/* 317 */       i++;
/*     */     }
/* 319 */     return batchUpdate(sql, batchArgs);
/*     */   }
/*     */ 
/*     */   public int[] batchUpdate(String sql, SqlParameterSource[] batchArgs) {
/* 323 */     ParsedSql parsedSql = getParsedSql(sql);
/* 324 */     return NamedParameterBatchUpdateUtils.executeBatchUpdateWithNamedParameters(parsedSql, batchArgs, getJdbcOperations());
/*     */   }
/*     */ 
/*     */   protected PreparedStatementCreator getPreparedStatementCreator(String sql, SqlParameterSource paramSource)
/*     */   {
/* 335 */     ParsedSql parsedSql = getParsedSql(sql);
/* 336 */     String sqlToUse = NamedParameterUtils.substituteNamedParameters(parsedSql, paramSource);
/* 337 */     Object[] params = NamedParameterUtils.buildValueArray(parsedSql, paramSource, null);
/* 338 */     List declaredParameters = NamedParameterUtils.buildSqlParameterList(parsedSql, paramSource);
/* 339 */     PreparedStatementCreatorFactory pscf = new PreparedStatementCreatorFactory(sqlToUse, declaredParameters);
/* 340 */     return pscf.newPreparedStatementCreator(params);
/*     */   }
/*     */ 
/*     */   protected ParsedSql getParsedSql(String sql)
/*     */   {
/* 351 */     if (getCacheLimit() <= 0) {
/* 352 */       return NamedParameterUtils.parseSqlStatement(sql);
/*     */     }
/* 354 */     synchronized (this.parsedSqlCache) {
/* 355 */       ParsedSql parsedSql = (ParsedSql)this.parsedSqlCache.get(sql);
/* 356 */       if (parsedSql == null) {
/* 357 */         parsedSql = NamedParameterUtils.parseSqlStatement(sql);
/* 358 */         this.parsedSqlCache.put(sql, parsedSql);
/*     */       }
/* 360 */       return parsedSql;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate
 * JD-Core Version:    0.6.1
 */