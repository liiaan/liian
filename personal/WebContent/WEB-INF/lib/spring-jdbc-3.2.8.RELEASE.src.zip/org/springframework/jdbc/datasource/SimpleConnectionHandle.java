/*    */ package org.springframework.jdbc.datasource;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class SimpleConnectionHandle
/*    */   implements ConnectionHandle
/*    */ {
/*    */   private final Connection connection;
/*    */ 
/*    */   public SimpleConnectionHandle(Connection connection)
/*    */   {
/* 40 */     Assert.notNull(connection, "Connection must not be null");
/* 41 */     this.connection = connection;
/*    */   }
/*    */ 
/*    */   public Connection getConnection()
/*    */   {
/* 48 */     return this.connection;
/*    */   }
/*    */ 
/*    */   public void releaseConnection(Connection con)
/*    */   {
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 61 */     return "SimpleConnectionHandle: " + this.connection;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.SimpleConnectionHandle
 * JD-Core Version:    0.6.1
 */