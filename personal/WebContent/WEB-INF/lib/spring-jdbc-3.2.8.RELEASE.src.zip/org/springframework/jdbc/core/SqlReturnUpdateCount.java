/*    */ package org.springframework.jdbc.core;
/*    */ 
/*    */ public class SqlReturnUpdateCount extends SqlParameter
/*    */ {
/*    */   public SqlReturnUpdateCount(String name)
/*    */   {
/* 20 */     super(name, 4);
/*    */   }
/*    */ 
/*    */   public boolean isInputValueProvided()
/*    */   {
/* 31 */     return false;
/*    */   }
/*    */ 
/*    */   public boolean isResultsParameter()
/*    */   {
/* 41 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.SqlReturnUpdateCount
 * JD-Core Version:    0.6.1
 */