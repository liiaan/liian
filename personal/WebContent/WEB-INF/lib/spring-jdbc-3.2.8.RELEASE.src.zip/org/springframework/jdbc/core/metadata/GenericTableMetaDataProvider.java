/*     */ package org.springframework.jdbc.core.metadata;
/*     */ 
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.jdbc.support.nativejdbc.NativeJdbcExtractor;
/*     */ 
/*     */ public class GenericTableMetaDataProvider
/*     */   implements TableMetaDataProvider
/*     */ {
/*  45 */   protected static final Log logger = LogFactory.getLog(TableMetaDataProvider.class);
/*     */ 
/*  48 */   private boolean tableColumnMetaDataUsed = false;
/*     */   private String databaseVersion;
/*     */   private String userName;
/*  57 */   private boolean storesUpperCaseIdentifiers = true;
/*     */ 
/*  60 */   private boolean storesLowerCaseIdentifiers = false;
/*     */ 
/*  63 */   private boolean getGeneratedKeysSupported = true;
/*     */ 
/*  66 */   private boolean generatedKeysColumnNameArraySupported = true;
/*     */ 
/*  69 */   private List<String> productsNotSupportingGeneratedKeysColumnNameArray = Arrays.asList(new String[] { "Apache Derby", "HSQL Database Engine" });
/*     */ 
/*  73 */   private List<TableParameterMetaData> insertParameterMetaData = new ArrayList();
/*     */   private NativeJdbcExtractor nativeJdbcExtractor;
/*     */ 
/*     */   protected GenericTableMetaDataProvider(DatabaseMetaData databaseMetaData)
/*     */     throws SQLException
/*     */   {
/*  84 */     this.userName = databaseMetaData.getUserName();
/*     */   }
/*     */ 
/*     */   public void setStoresUpperCaseIdentifiers(boolean storesUpperCaseIdentifiers)
/*     */   {
/*  92 */     this.storesUpperCaseIdentifiers = storesUpperCaseIdentifiers;
/*     */   }
/*     */ 
/*     */   public boolean isStoresUpperCaseIdentifiers()
/*     */   {
/*  99 */     return this.storesUpperCaseIdentifiers;
/*     */   }
/*     */ 
/*     */   public void setStoresLowerCaseIdentifiers(boolean storesLowerCaseIdentifiers)
/*     */   {
/* 106 */     this.storesLowerCaseIdentifiers = storesLowerCaseIdentifiers;
/*     */   }
/*     */ 
/*     */   public boolean isStoresLowerCaseIdentifiers()
/*     */   {
/* 113 */     return this.storesLowerCaseIdentifiers;
/*     */   }
/*     */ 
/*     */   public boolean isTableColumnMetaDataUsed() {
/* 117 */     return this.tableColumnMetaDataUsed;
/*     */   }
/*     */ 
/*     */   public List<TableParameterMetaData> getTableParameterMetaData() {
/* 121 */     return this.insertParameterMetaData;
/*     */   }
/*     */ 
/*     */   public boolean isGetGeneratedKeysSupported() {
/* 125 */     return this.getGeneratedKeysSupported;
/*     */   }
/*     */ 
/*     */   public boolean isGetGeneratedKeysSimulated() {
/* 129 */     return false;
/*     */   }
/*     */ 
/*     */   public String getSimpleQueryForGetGeneratedKey(String tableName, String keyColumnName) {
/* 133 */     return null;
/*     */   }
/*     */ 
/*     */   public void setGetGeneratedKeysSupported(boolean getGeneratedKeysSupported)
/*     */   {
/* 140 */     this.getGeneratedKeysSupported = getGeneratedKeysSupported;
/*     */   }
/*     */ 
/*     */   public void setGeneratedKeysColumnNameArraySupported(boolean generatedKeysColumnNameArraySupported)
/*     */   {
/* 147 */     this.generatedKeysColumnNameArraySupported = generatedKeysColumnNameArraySupported;
/*     */   }
/*     */ 
/*     */   public boolean isGeneratedKeysColumnNameArraySupported() {
/* 151 */     return this.generatedKeysColumnNameArraySupported;
/*     */   }
/*     */ 
/*     */   public void setNativeJdbcExtractor(NativeJdbcExtractor nativeJdbcExtractor) {
/* 155 */     this.nativeJdbcExtractor = nativeJdbcExtractor;
/*     */   }
/*     */ 
/*     */   protected NativeJdbcExtractor getNativeJdbcExtractor() {
/* 159 */     return this.nativeJdbcExtractor;
/*     */   }
/*     */ 
/*     */   public void initializeWithMetaData(DatabaseMetaData databaseMetaData) throws SQLException
/*     */   {
/*     */     try {
/* 165 */       if (databaseMetaData.supportsGetGeneratedKeys()) {
/* 166 */         logger.debug("GetGeneratedKeys is supported");
/* 167 */         setGetGeneratedKeysSupported(true);
/*     */       }
/*     */       else {
/* 170 */         logger.debug("GetGeneratedKeys is not supported");
/* 171 */         setGetGeneratedKeysSupported(false);
/*     */       }
/*     */     }
/*     */     catch (SQLException se) {
/* 175 */       logger.warn("Error retrieving 'DatabaseMetaData.getGeneratedKeys' - " + se.getMessage());
/*     */     }
/*     */     try {
/* 178 */       String databaseProductName = databaseMetaData.getDatabaseProductName();
/* 179 */       if (this.productsNotSupportingGeneratedKeysColumnNameArray.contains(databaseProductName)) {
/* 180 */         logger.debug("GeneratedKeysColumnNameArray is not supported for " + databaseProductName);
/* 181 */         setGeneratedKeysColumnNameArraySupported(false);
/*     */       }
/* 184 */       else if (isGetGeneratedKeysSupported()) {
/* 185 */         logger.debug("GeneratedKeysColumnNameArray is supported for " + databaseProductName);
/* 186 */         setGeneratedKeysColumnNameArraySupported(true);
/*     */       }
/*     */       else {
/* 189 */         setGeneratedKeysColumnNameArraySupported(false);
/*     */       }
/*     */     }
/*     */     catch (SQLException se)
/*     */     {
/* 194 */       logger.warn("Error retrieving 'DatabaseMetaData.getDatabaseProductName' - " + se.getMessage());
/*     */     }
/*     */     try {
/* 197 */       this.databaseVersion = databaseMetaData.getDatabaseProductVersion();
/*     */     }
/*     */     catch (SQLException se) {
/* 200 */       logger.warn("Error retrieving 'DatabaseMetaData.getDatabaseProductVersion' - " + se.getMessage());
/*     */     }
/*     */     try {
/* 203 */       setStoresUpperCaseIdentifiers(databaseMetaData.storesUpperCaseIdentifiers());
/*     */     }
/*     */     catch (SQLException se) {
/* 206 */       logger.warn("Error retrieving 'DatabaseMetaData.storesUpperCaseIdentifiers' - " + se.getMessage());
/*     */     }
/*     */     try {
/* 209 */       setStoresLowerCaseIdentifiers(databaseMetaData.storesLowerCaseIdentifiers());
/*     */     }
/*     */     catch (SQLException se) {
/* 212 */       logger.warn("Error retrieving 'DatabaseMetaData.storesLowerCaseIdentifiers' - " + se.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void initializeWithTableColumnMetaData(DatabaseMetaData databaseMetaData, String catalogName, String schemaName, String tableName)
/*     */     throws SQLException
/*     */   {
/* 220 */     this.tableColumnMetaDataUsed = true;
/* 221 */     locateTableAndProcessMetaData(databaseMetaData, catalogName, schemaName, tableName);
/*     */   }
/*     */ 
/*     */   public String tableNameToUse(String tableName) {
/* 225 */     if (tableName == null) {
/* 226 */       return null;
/*     */     }
/* 228 */     if (isStoresUpperCaseIdentifiers()) {
/* 229 */       return tableName.toUpperCase();
/*     */     }
/* 231 */     if (isStoresLowerCaseIdentifiers()) {
/* 232 */       return tableName.toLowerCase();
/*     */     }
/*     */ 
/* 235 */     return tableName;
/*     */   }
/*     */ 
/*     */   public String catalogNameToUse(String catalogName)
/*     */   {
/* 240 */     if (catalogName == null) {
/* 241 */       return null;
/*     */     }
/* 243 */     if (isStoresUpperCaseIdentifiers()) {
/* 244 */       return catalogName.toUpperCase();
/*     */     }
/* 246 */     if (isStoresLowerCaseIdentifiers()) {
/* 247 */       return catalogName.toLowerCase();
/*     */     }
/*     */ 
/* 250 */     return catalogName;
/*     */   }
/*     */ 
/*     */   public String schemaNameToUse(String schemaName)
/*     */   {
/* 255 */     if (schemaName == null) {
/* 256 */       return null;
/*     */     }
/* 258 */     if (isStoresUpperCaseIdentifiers()) {
/* 259 */       return schemaName.toUpperCase();
/*     */     }
/* 261 */     if (isStoresLowerCaseIdentifiers()) {
/* 262 */       return schemaName.toLowerCase();
/*     */     }
/*     */ 
/* 265 */     return schemaName;
/*     */   }
/*     */ 
/*     */   public String metaDataCatalogNameToUse(String catalogName)
/*     */   {
/* 270 */     return catalogNameToUse(catalogName);
/*     */   }
/*     */ 
/*     */   public String metaDataSchemaNameToUse(String schemaName) {
/* 274 */     if (schemaName == null) {
/* 275 */       return schemaNameToUse(getDefaultSchema());
/*     */     }
/* 277 */     return schemaNameToUse(schemaName);
/*     */   }
/*     */ 
/*     */   protected String getDefaultSchema()
/*     */   {
/* 284 */     return this.userName;
/*     */   }
/*     */ 
/*     */   protected String getDatabaseVersion()
/*     */   {
/* 291 */     return this.databaseVersion;
/*     */   }
/*     */ 
/*     */   private void locateTableAndProcessMetaData(DatabaseMetaData databaseMetaData, String catalogName, String schemaName, String tableName)
/*     */   {
/* 300 */     Map tableMeta = new HashMap();
/* 301 */     ResultSet tables = null;
/*     */     try {
/* 303 */       tables = databaseMetaData.getTables(catalogNameToUse(catalogName), schemaNameToUse(schemaName), tableNameToUse(tableName), null);
/*     */ 
/* 308 */       while ((tables != null) && (tables.next())) {
/* 309 */         TableMetaData tmd = new TableMetaData(null);
/* 310 */         tmd.setCatalogName(tables.getString("TABLE_CAT"));
/* 311 */         tmd.setSchemaName(tables.getString("TABLE_SCHEM"));
/* 312 */         tmd.setTableName(tables.getString("TABLE_NAME"));
/* 313 */         if (tmd.getSchemaName() == null) {
/* 314 */           tableMeta.put(this.userName != null ? this.userName.toUpperCase() : "", tmd);
/*     */         }
/*     */         else
/* 317 */           tableMeta.put(tmd.getSchemaName().toUpperCase(), tmd);
/*     */       }
/*     */     }
/*     */     catch (SQLException se)
/*     */     {
/* 322 */       logger.warn("Error while accessing table meta data results" + se.getMessage());
/*     */     }
/*     */     finally {
/* 325 */       if (tables != null) {
/*     */         try {
/* 327 */           tables.close();
/*     */         } catch (SQLException e) {
/* 329 */           logger.warn("Error while closing table meta data reults" + e.getMessage());
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 334 */     if (tableMeta.size() < 1) {
/* 335 */       logger.warn("Unable to locate table meta data for '" + tableName + "' -- column names must be provided");
/*     */     }
/*     */     else
/*     */     {
/*     */       TableMetaData tmd;
/* 339 */       if (schemaName == null) {
/* 340 */         TableMetaData tmd = (TableMetaData)tableMeta.get(getDefaultSchema());
/* 341 */         if (tmd == null) {
/* 342 */           tmd = (TableMetaData)tableMeta.get(this.userName != null ? this.userName.toUpperCase() : "");
/*     */         }
/* 344 */         if (tmd == null) {
/* 345 */           tmd = (TableMetaData)tableMeta.get("PUBLIC");
/*     */         }
/* 347 */         if (tmd == null) {
/* 348 */           tmd = (TableMetaData)tableMeta.get("DBO");
/*     */         }
/* 350 */         if (tmd == null) {
/* 351 */           throw new DataAccessResourceFailureException("Unable to locate table meta data for '" + tableName + "' in the default schema");
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 356 */         tmd = (TableMetaData)tableMeta.get(schemaName.toUpperCase());
/* 357 */         if (tmd == null) {
/* 358 */           throw new DataAccessResourceFailureException("Unable to locate table meta data for '" + tableName + "' in the '" + schemaName + "' schema");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 363 */       processTableColumns(databaseMetaData, tmd);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void processTableColumns(DatabaseMetaData databaseMetaData, TableMetaData tmd)
/*     */   {
/* 371 */     ResultSet tableColumns = null;
/* 372 */     String metaDataCatalogName = metaDataCatalogNameToUse(tmd.getCatalogName());
/* 373 */     String metaDataSchemaName = metaDataSchemaNameToUse(tmd.getSchemaName());
/* 374 */     String metaDataTableName = tableNameToUse(tmd.getTableName());
/* 375 */     if (logger.isDebugEnabled()) {
/* 376 */       logger.debug("Retrieving metadata for " + metaDataCatalogName + "/" + metaDataSchemaName + "/" + metaDataTableName);
/*     */     }
/*     */     try
/*     */     {
/* 380 */       tableColumns = databaseMetaData.getColumns(metaDataCatalogName, metaDataSchemaName, metaDataTableName, null);
/*     */ 
/* 385 */       while (tableColumns.next()) {
/* 386 */         String columnName = tableColumns.getString("COLUMN_NAME");
/* 387 */         int dataType = tableColumns.getInt("DATA_TYPE");
/* 388 */         if (dataType == 3) {
/* 389 */           String typeName = tableColumns.getString("TYPE_NAME");
/* 390 */           int decimalDigits = tableColumns.getInt("DECIMAL_DIGITS");
/*     */ 
/* 394 */           if (("NUMBER".equals(typeName)) && (decimalDigits == 0)) {
/* 395 */             dataType = 2;
/* 396 */             if (logger.isDebugEnabled()) {
/* 397 */               logger.debug("Overriding metadata: " + columnName + " now using NUMERIC instead of DECIMAL");
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 404 */         boolean nullable = tableColumns.getBoolean("NULLABLE");
/* 405 */         TableParameterMetaData meta = new TableParameterMetaData(columnName, dataType, nullable);
/*     */ 
/* 410 */         this.insertParameterMetaData.add(meta);
/* 411 */         if (logger.isDebugEnabled()) {
/* 412 */           logger.debug("Retrieved metadata: " + meta.getParameterName() + " " + meta.getSqlType() + " " + meta.isNullable());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (SQLException se)
/*     */     {
/* 421 */       logger.warn("Error while retrieving metadata for table columns: " + se.getMessage());
/*     */     }
/*     */     finally {
/*     */       try {
/* 425 */         if (tableColumns != null)
/* 426 */           tableColumns.close();
/*     */       }
/*     */       catch (SQLException se) {
/* 429 */         logger.warn("Problem closing ResultSet for table column metadata " + se.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class TableMetaData
/*     */   {
/*     */     private String catalogName;
/*     */     private String schemaName;
/*     */     private String tableName;
/*     */ 
/*     */     public void setCatalogName(String catalogName)
/*     */     {
/* 449 */       this.catalogName = catalogName;
/*     */     }
/*     */ 
/*     */     public String getCatalogName() {
/* 453 */       return this.catalogName;
/*     */     }
/*     */ 
/*     */     public void setSchemaName(String schemaName) {
/* 457 */       this.schemaName = schemaName;
/*     */     }
/*     */ 
/*     */     public String getSchemaName() {
/* 461 */       return this.schemaName;
/*     */     }
/*     */ 
/*     */     public void setTableName(String tableName) {
/* 465 */       this.tableName = tableName;
/*     */     }
/*     */ 
/*     */     public String getTableName() {
/* 469 */       return this.tableName;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.GenericTableMetaDataProvider
 * JD-Core Version:    0.6.1
 */