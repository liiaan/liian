/*     */ package org.springframework.jdbc.datasource.lookup;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class MapDataSourceLookup
/*     */   implements DataSourceLookup
/*     */ {
/*  39 */   private final Map<String, DataSource> dataSources = new HashMap(4);
/*     */ 
/*     */   public MapDataSourceLookup()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MapDataSourceLookup(Map<String, DataSource> dataSources)
/*     */   {
/*  54 */     setDataSources(dataSources);
/*     */   }
/*     */ 
/*     */   public MapDataSourceLookup(String dataSourceName, DataSource dataSource)
/*     */   {
/*  63 */     addDataSource(dataSourceName, dataSource);
/*     */   }
/*     */ 
/*     */   public void setDataSources(Map<String, DataSource> dataSources)
/*     */   {
/*  75 */     if (dataSources != null)
/*  76 */       this.dataSources.putAll(dataSources);
/*     */   }
/*     */ 
/*     */   public Map<String, DataSource> getDataSources()
/*     */   {
/*  86 */     return Collections.unmodifiableMap(this.dataSources);
/*     */   }
/*     */ 
/*     */   public void addDataSource(String dataSourceName, DataSource dataSource)
/*     */   {
/*  96 */     Assert.notNull(dataSourceName, "DataSource name must not be null");
/*  97 */     Assert.notNull(dataSource, "DataSource must not be null");
/*  98 */     this.dataSources.put(dataSourceName, dataSource);
/*     */   }
/*     */ 
/*     */   public DataSource getDataSource(String dataSourceName) throws DataSourceLookupFailureException {
/* 102 */     Assert.notNull(dataSourceName, "DataSource name must not be null");
/* 103 */     DataSource dataSource = (DataSource)this.dataSources.get(dataSourceName);
/* 104 */     if (dataSource == null) {
/* 105 */       throw new DataSourceLookupFailureException("No DataSource with name '" + dataSourceName + "' registered");
/*     */     }
/*     */ 
/* 108 */     return dataSource;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.lookup.MapDataSourceLookup
 * JD-Core Version:    0.6.1
 */