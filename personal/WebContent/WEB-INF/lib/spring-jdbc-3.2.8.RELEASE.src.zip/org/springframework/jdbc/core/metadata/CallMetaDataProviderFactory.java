/*     */ package org.springframework.jdbc.core.metadata;
/*     */ 
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.jdbc.support.DatabaseMetaDataCallback;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.jdbc.support.MetaDataAccessException;
/*     */ 
/*     */ public class CallMetaDataProviderFactory
/*     */ {
/*  43 */   private static final Log logger = LogFactory.getLog(CallMetaDataProviderFactory.class);
/*     */ 
/*  46 */   public static final List<String> supportedDatabaseProductsForProcedures = Arrays.asList(new String[] { "Apache Derby", "DB2", "MySQL", "Microsoft SQL Server", "Oracle", "PostgreSQL", "Sybase" });
/*     */ 
/*  56 */   public static final List<String> supportedDatabaseProductsForFunctions = Arrays.asList(new String[] { "MySQL", "Microsoft SQL Server", "Oracle", "PostgreSQL" });
/*     */ 
/*     */   public static CallMetaDataProvider createMetaDataProvider(DataSource dataSource, CallMetaDataContext context)
/*     */   {
/*     */     try
/*     */     {
/*  71 */       return (CallMetaDataProvider)JdbcUtils.extractDatabaseMetaData(dataSource, new DatabaseMetaDataCallback() {
/*     */         public Object processMetaData(DatabaseMetaData databaseMetaData) throws SQLException, MetaDataAccessException {
/*  73 */           String databaseProductName = JdbcUtils.commonDatabaseName(databaseMetaData.getDatabaseProductName());
/*  74 */           boolean accessProcedureColumnMetaData = this.val$context.isAccessCallParameterMetaData();
/*  75 */           if (this.val$context.isFunction()) {
/*  76 */             if (!CallMetaDataProviderFactory.supportedDatabaseProductsForFunctions.contains(databaseProductName)) {
/*  77 */               if (CallMetaDataProviderFactory.logger.isWarnEnabled()) {
/*  78 */                 CallMetaDataProviderFactory.logger.warn(databaseProductName + " is not one of the databases fully supported for function calls " + "-- supported are: " + CallMetaDataProviderFactory.supportedDatabaseProductsForFunctions);
/*     */               }
/*     */ 
/*  81 */               if (accessProcedureColumnMetaData) {
/*  82 */                 CallMetaDataProviderFactory.logger.warn("Metadata processing disabled - you must specify all parameters explicitly");
/*  83 */                 accessProcedureColumnMetaData = false;
/*     */               }
/*     */             }
/*     */ 
/*     */           }
/*  88 */           else if (!CallMetaDataProviderFactory.supportedDatabaseProductsForProcedures.contains(databaseProductName)) {
/*  89 */             if (CallMetaDataProviderFactory.logger.isWarnEnabled()) {
/*  90 */               CallMetaDataProviderFactory.logger.warn(databaseProductName + " is not one of the databases fully supported for procedure calls " + "-- supported are: " + CallMetaDataProviderFactory.supportedDatabaseProductsForProcedures);
/*     */             }
/*     */ 
/*  93 */             if (accessProcedureColumnMetaData) {
/*  94 */               CallMetaDataProviderFactory.logger.warn("Metadata processing disabled - you must specify all parameters explicitly");
/*  95 */               accessProcedureColumnMetaData = false;
/*     */             }
/*     */           }
/*     */           CallMetaDataProvider provider;
/*     */           CallMetaDataProvider provider;
/* 101 */           if ("Oracle".equals(databaseProductName)) {
/* 102 */             provider = new OracleCallMetaDataProvider(databaseMetaData);
/*     */           }
/*     */           else
/*     */           {
/*     */             CallMetaDataProvider provider;
/* 104 */             if ("DB2".equals(databaseProductName)) {
/* 105 */               provider = new Db2CallMetaDataProvider(databaseMetaData);
/*     */             }
/*     */             else
/*     */             {
/*     */               CallMetaDataProvider provider;
/* 107 */               if ("Apache Derby".equals(databaseProductName)) {
/* 108 */                 provider = new DerbyCallMetaDataProvider(databaseMetaData);
/*     */               }
/*     */               else
/*     */               {
/*     */                 CallMetaDataProvider provider;
/* 110 */                 if ("PostgreSQL".equals(databaseProductName)) {
/* 111 */                   provider = new PostgresCallMetaDataProvider(databaseMetaData);
/*     */                 }
/*     */                 else
/*     */                 {
/*     */                   CallMetaDataProvider provider;
/* 113 */                   if ("Sybase".equals(databaseProductName)) {
/* 114 */                     provider = new SybaseCallMetaDataProvider(databaseMetaData);
/*     */                   }
/*     */                   else
/*     */                   {
/*     */                     CallMetaDataProvider provider;
/* 116 */                     if ("Microsoft SQL Server".equals(databaseProductName)) {
/* 117 */                       provider = new SqlServerCallMetaDataProvider(databaseMetaData);
/*     */                     }
/*     */                     else
/* 120 */                       provider = new GenericCallMetaDataProvider(databaseMetaData); 
/*     */                   }
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/* 122 */           if (CallMetaDataProviderFactory.logger.isDebugEnabled()) {
/* 123 */             CallMetaDataProviderFactory.logger.debug("Using " + provider.getClass().getName());
/*     */           }
/* 125 */           provider.initializeWithMetaData(databaseMetaData);
/* 126 */           if (accessProcedureColumnMetaData) {
/* 127 */             provider.initializeWithProcedureColumnMetaData(databaseMetaData, this.val$context.getCatalogName(), this.val$context.getSchemaName(), this.val$context.getProcedureName());
/*     */           }
/*     */ 
/* 130 */           return provider;
/*     */         }
/*     */       });
/*     */     }
/*     */     catch (MetaDataAccessException ex) {
/* 135 */       throw new DataAccessResourceFailureException("Error retreiving database metadata", ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.CallMetaDataProviderFactory
 * JD-Core Version:    0.6.1
 */