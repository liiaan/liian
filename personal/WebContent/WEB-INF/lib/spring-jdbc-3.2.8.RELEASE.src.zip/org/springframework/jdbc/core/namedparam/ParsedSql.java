/*     */ package org.springframework.jdbc.core.namedparam;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class ParsedSql
/*     */ {
/*     */   private String originalSql;
/*  33 */   private List<String> parameterNames = new ArrayList();
/*     */ 
/*  35 */   private List<int[]> parameterIndexes = new ArrayList();
/*     */   private int namedParameterCount;
/*     */   private int unnamedParameterCount;
/*     */   private int totalParameterCount;
/*     */ 
/*     */   ParsedSql(String originalSql)
/*     */   {
/*  49 */     this.originalSql = originalSql;
/*     */   }
/*     */ 
/*     */   String getOriginalSql()
/*     */   {
/*  56 */     return this.originalSql;
/*     */   }
/*     */ 
/*     */   void addNamedParameter(String parameterName, int startIndex, int endIndex)
/*     */   {
/*  67 */     this.parameterNames.add(parameterName);
/*  68 */     this.parameterIndexes.add(new int[] { startIndex, endIndex });
/*     */   }
/*     */ 
/*     */   List<String> getParameterNames()
/*     */   {
/*  76 */     return this.parameterNames;
/*     */   }
/*     */ 
/*     */   int[] getParameterIndexes(int parameterPosition)
/*     */   {
/*  87 */     return (int[])this.parameterIndexes.get(parameterPosition);
/*     */   }
/*     */ 
/*     */   void setNamedParameterCount(int namedParameterCount)
/*     */   {
/*  95 */     this.namedParameterCount = namedParameterCount;
/*     */   }
/*     */ 
/*     */   int getNamedParameterCount()
/*     */   {
/* 103 */     return this.namedParameterCount;
/*     */   }
/*     */ 
/*     */   void setUnnamedParameterCount(int unnamedParameterCount)
/*     */   {
/* 110 */     this.unnamedParameterCount = unnamedParameterCount;
/*     */   }
/*     */ 
/*     */   int getUnnamedParameterCount()
/*     */   {
/* 117 */     return this.unnamedParameterCount;
/*     */   }
/*     */ 
/*     */   void setTotalParameterCount(int totalParameterCount)
/*     */   {
/* 125 */     this.totalParameterCount = totalParameterCount;
/*     */   }
/*     */ 
/*     */   int getTotalParameterCount()
/*     */   {
/* 133 */     return this.totalParameterCount;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 142 */     return this.originalSql;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.namedparam.ParsedSql
 * JD-Core Version:    0.6.1
 */