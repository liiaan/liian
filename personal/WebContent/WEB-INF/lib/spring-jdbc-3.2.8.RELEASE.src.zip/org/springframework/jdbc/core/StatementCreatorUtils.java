/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import java.io.StringWriter;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.ParameterMetaData;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Arrays;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.SpringProperties;
/*     */ import org.springframework.jdbc.support.SqlValue;
/*     */ 
/*     */ public abstract class StatementCreatorUtils
/*     */ {
/*     */   public static final String IGNORE_GETPARAMETERTYPE_PROPERTY_NAME = "spring.jdbc.getParameterType.ignore";
/*  78 */   static final boolean shouldIgnoreGetParameterType = SpringProperties.getFlag("spring.jdbc.getParameterType.ignore");
/*     */ 
/*  81 */   static final Map<String, Boolean> driversWithNoSupportForGetParameterType = new ConcurrentHashMap(1);
/*     */ 
/*  84 */   private static final Log logger = LogFactory.getLog(StatementCreatorUtils.class);
/*     */ 
/*  86 */   private static final Map<Class<?>, Integer> javaTypeToSqlTypeMap = new HashMap(32);
/*     */ 
/*     */   public static int javaTypeToSqlParameterType(Class<?> javaType)
/*     */   {
/* 121 */     Integer sqlType = (Integer)javaTypeToSqlTypeMap.get(javaType);
/* 122 */     if (sqlType != null) {
/* 123 */       return sqlType.intValue();
/*     */     }
/* 125 */     if (Number.class.isAssignableFrom(javaType)) {
/* 126 */       return 2;
/*     */     }
/* 128 */     if (isStringValue(javaType)) {
/* 129 */       return 12;
/*     */     }
/* 131 */     if ((isDateValue(javaType)) || (Calendar.class.isAssignableFrom(javaType))) {
/* 132 */       return 93;
/*     */     }
/* 134 */     return -2147483648;
/*     */   }
/*     */ 
/*     */   public static void setParameterValue(PreparedStatement ps, int paramIndex, SqlParameter param, Object inValue)
/*     */     throws SQLException
/*     */   {
/* 149 */     setParameterValueInternal(ps, paramIndex, param.getSqlType(), param.getTypeName(), param.getScale(), inValue);
/*     */   }
/*     */ 
/*     */   public static void setParameterValue(PreparedStatement ps, int paramIndex, int sqlType, Object inValue)
/*     */     throws SQLException
/*     */   {
/* 165 */     setParameterValueInternal(ps, paramIndex, sqlType, null, null, inValue);
/*     */   }
/*     */ 
/*     */   public static void setParameterValue(PreparedStatement ps, int paramIndex, int sqlType, String typeName, Object inValue)
/*     */     throws SQLException
/*     */   {
/* 183 */     setParameterValueInternal(ps, paramIndex, sqlType, typeName, null, inValue);
/*     */   }
/*     */ 
/*     */   private static void setParameterValueInternal(PreparedStatement ps, int paramIndex, int sqlType, String typeName, Integer scale, Object inValue)
/*     */     throws SQLException
/*     */   {
/* 203 */     String typeNameToUse = typeName;
/* 204 */     int sqlTypeToUse = sqlType;
/* 205 */     Object inValueToUse = inValue;
/*     */ 
/* 208 */     if ((inValue instanceof SqlParameterValue)) {
/* 209 */       SqlParameterValue parameterValue = (SqlParameterValue)inValue;
/* 210 */       if (logger.isDebugEnabled()) {
/* 211 */         logger.debug("Overriding type info with runtime info from SqlParameterValue: column index " + paramIndex + ", SQL type " + parameterValue.getSqlType() + ", type name " + parameterValue.getTypeName());
/*     */       }
/*     */ 
/* 214 */       if (parameterValue.getSqlType() != -2147483648) {
/* 215 */         sqlTypeToUse = parameterValue.getSqlType();
/*     */       }
/* 217 */       if (parameterValue.getTypeName() != null) {
/* 218 */         typeNameToUse = parameterValue.getTypeName();
/*     */       }
/* 220 */       inValueToUse = parameterValue.getValue();
/*     */     }
/*     */ 
/* 223 */     if (logger.isTraceEnabled()) {
/* 224 */       logger.trace("Setting SQL statement parameter value: column index " + paramIndex + ", parameter value [" + inValueToUse + "], value class [" + (inValueToUse != null ? inValueToUse.getClass().getName() : "null") + "], SQL type " + (sqlTypeToUse == -2147483648 ? "unknown" : Integer.toString(sqlTypeToUse)));
/*     */     }
/*     */ 
/* 230 */     if (inValueToUse == null) {
/* 231 */       setNull(ps, paramIndex, sqlTypeToUse, typeNameToUse);
/*     */     }
/*     */     else
/* 234 */       setValue(ps, paramIndex, sqlTypeToUse, typeNameToUse, scale, inValueToUse);
/*     */   }
/*     */ 
/*     */   private static void setNull(PreparedStatement ps, int paramIndex, int sqlType, String typeName)
/*     */     throws SQLException
/*     */   {
/* 243 */     if (sqlType == -2147483648) {
/* 244 */       boolean useSetObject = false;
/* 245 */       Integer sqlTypeToUse = null;
/* 246 */       DatabaseMetaData dbmd = null;
/* 247 */       String jdbcDriverName = null;
/* 248 */       boolean checkGetParameterType = !shouldIgnoreGetParameterType;
/* 249 */       if ((checkGetParameterType) && (!driversWithNoSupportForGetParameterType.isEmpty())) {
/*     */         try {
/* 251 */           dbmd = ps.getConnection().getMetaData();
/* 252 */           jdbcDriverName = dbmd.getDriverName();
/* 253 */           checkGetParameterType = !driversWithNoSupportForGetParameterType.containsKey(jdbcDriverName);
/*     */         }
/*     */         catch (Throwable ex) {
/* 256 */           logger.debug("Could not check connection metadata", ex);
/*     */         }
/*     */       }
/* 259 */       if (checkGetParameterType) {
/*     */         try {
/* 261 */           sqlTypeToUse = Integer.valueOf(ps.getParameterMetaData().getParameterType(paramIndex));
/*     */         }
/*     */         catch (Throwable ex) {
/* 264 */           if (logger.isDebugEnabled()) {
/* 265 */             logger.debug("JDBC 3.0 getParameterType call not supported - using fallback method instead: " + ex);
/*     */           }
/*     */         }
/*     */       }
/* 269 */       if (sqlTypeToUse == null)
/*     */       {
/* 271 */         sqlTypeToUse = Integer.valueOf(0);
/*     */         try {
/* 273 */           if (dbmd == null) {
/* 274 */             dbmd = ps.getConnection().getMetaData();
/*     */           }
/* 276 */           if (jdbcDriverName == null) {
/* 277 */             jdbcDriverName = dbmd.getDriverName();
/*     */           }
/* 279 */           if (checkGetParameterType) {
/* 280 */             driversWithNoSupportForGetParameterType.put(jdbcDriverName, Boolean.TRUE);
/*     */           }
/* 282 */           String databaseProductName = dbmd.getDatabaseProductName();
/* 283 */           if ((databaseProductName.startsWith("Informix")) || (jdbcDriverName.startsWith("Microsoft SQL Server")))
/*     */           {
/* 285 */             useSetObject = true;
/*     */           }
/* 287 */           else if ((databaseProductName.startsWith("DB2")) || (jdbcDriverName.startsWith("jConnect")) || (jdbcDriverName.startsWith("SQLServer")) || (jdbcDriverName.startsWith("Apache Derby")))
/*     */           {
/* 291 */             sqlTypeToUse = Integer.valueOf(12);
/*     */           }
/*     */         }
/*     */         catch (Throwable ex) {
/* 295 */           logger.debug("Could not check connection metadata", ex);
/*     */         }
/*     */       }
/* 298 */       if (useSetObject) {
/* 299 */         ps.setObject(paramIndex, null);
/*     */       }
/*     */       else {
/* 302 */         ps.setNull(paramIndex, sqlTypeToUse.intValue());
/*     */       }
/*     */     }
/* 305 */     else if (typeName != null) {
/* 306 */       ps.setNull(paramIndex, sqlType, typeName);
/*     */     }
/*     */     else {
/* 309 */       ps.setNull(paramIndex, sqlType);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void setValue(PreparedStatement ps, int paramIndex, int sqlType, String typeName, Integer scale, Object inValue)
/*     */     throws SQLException
/*     */   {
/* 316 */     if ((inValue instanceof SqlTypeValue)) {
/* 317 */       ((SqlTypeValue)inValue).setTypeValue(ps, paramIndex, sqlType, typeName);
/*     */     }
/* 319 */     else if ((inValue instanceof SqlValue)) {
/* 320 */       ((SqlValue)inValue).setValue(ps, paramIndex);
/*     */     }
/* 322 */     else if ((sqlType == 12) || (sqlType == -1) || ((sqlType == 2005) && (isStringValue(inValue.getClass()))))
/*     */     {
/* 324 */       ps.setString(paramIndex, inValue.toString());
/*     */     }
/* 326 */     else if ((sqlType == 3) || (sqlType == 2)) {
/* 327 */       if ((inValue instanceof BigDecimal)) {
/* 328 */         ps.setBigDecimal(paramIndex, (BigDecimal)inValue);
/*     */       }
/* 330 */       else if (scale != null) {
/* 331 */         ps.setObject(paramIndex, inValue, sqlType, scale.intValue());
/*     */       }
/*     */       else {
/* 334 */         ps.setObject(paramIndex, inValue, sqlType);
/*     */       }
/*     */     }
/* 337 */     else if (sqlType == 91) {
/* 338 */       if ((inValue instanceof java.util.Date)) {
/* 339 */         if ((inValue instanceof java.sql.Date)) {
/* 340 */           ps.setDate(paramIndex, (java.sql.Date)inValue);
/*     */         }
/*     */         else {
/* 343 */           ps.setDate(paramIndex, new java.sql.Date(((java.util.Date)inValue).getTime()));
/*     */         }
/*     */       }
/* 346 */       else if ((inValue instanceof Calendar)) {
/* 347 */         Calendar cal = (Calendar)inValue;
/* 348 */         ps.setDate(paramIndex, new java.sql.Date(cal.getTime().getTime()), cal);
/*     */       }
/*     */       else {
/* 351 */         ps.setObject(paramIndex, inValue, 91);
/*     */       }
/*     */     }
/* 354 */     else if (sqlType == 92) {
/* 355 */       if ((inValue instanceof java.util.Date)) {
/* 356 */         if ((inValue instanceof Time)) {
/* 357 */           ps.setTime(paramIndex, (Time)inValue);
/*     */         }
/*     */         else {
/* 360 */           ps.setTime(paramIndex, new Time(((java.util.Date)inValue).getTime()));
/*     */         }
/*     */       }
/* 363 */       else if ((inValue instanceof Calendar)) {
/* 364 */         Calendar cal = (Calendar)inValue;
/* 365 */         ps.setTime(paramIndex, new Time(cal.getTime().getTime()), cal);
/*     */       }
/*     */       else {
/* 368 */         ps.setObject(paramIndex, inValue, 92);
/*     */       }
/*     */     }
/* 371 */     else if (sqlType == 93) {
/* 372 */       if ((inValue instanceof java.util.Date)) {
/* 373 */         if ((inValue instanceof Timestamp)) {
/* 374 */           ps.setTimestamp(paramIndex, (Timestamp)inValue);
/*     */         }
/*     */         else {
/* 377 */           ps.setTimestamp(paramIndex, new Timestamp(((java.util.Date)inValue).getTime()));
/*     */         }
/*     */       }
/* 380 */       else if ((inValue instanceof Calendar)) {
/* 381 */         Calendar cal = (Calendar)inValue;
/* 382 */         ps.setTimestamp(paramIndex, new Timestamp(cal.getTime().getTime()), cal);
/*     */       }
/*     */       else {
/* 385 */         ps.setObject(paramIndex, inValue, 93);
/*     */       }
/*     */     }
/* 388 */     else if (sqlType == -2147483648) {
/* 389 */       if (isStringValue(inValue.getClass())) {
/* 390 */         ps.setString(paramIndex, inValue.toString());
/*     */       }
/* 392 */       else if (isDateValue(inValue.getClass())) {
/* 393 */         ps.setTimestamp(paramIndex, new Timestamp(((java.util.Date)inValue).getTime()));
/*     */       }
/* 395 */       else if ((inValue instanceof Calendar)) {
/* 396 */         Calendar cal = (Calendar)inValue;
/* 397 */         ps.setTimestamp(paramIndex, new Timestamp(cal.getTime().getTime()), cal);
/*     */       }
/*     */       else
/*     */       {
/* 401 */         ps.setObject(paramIndex, inValue);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 406 */       ps.setObject(paramIndex, inValue, sqlType);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static boolean isStringValue(Class<?> inValueType)
/*     */   {
/* 415 */     return (CharSequence.class.isAssignableFrom(inValueType)) || (StringWriter.class.isAssignableFrom(inValueType));
/*     */   }
/*     */ 
/*     */   private static boolean isDateValue(Class<?> inValueType)
/*     */   {
/* 424 */     return (java.util.Date.class.isAssignableFrom(inValueType)) && (!java.sql.Date.class.isAssignableFrom(inValueType)) && (!Time.class.isAssignableFrom(inValueType)) && (!Timestamp.class.isAssignableFrom(inValueType));
/*     */   }
/*     */ 
/*     */   public static void cleanupParameters(Object[] paramValues)
/*     */   {
/* 438 */     if (paramValues != null)
/* 439 */       cleanupParameters(Arrays.asList(paramValues));
/*     */   }
/*     */ 
/*     */   public static void cleanupParameters(Collection<?> paramValues)
/*     */   {
/*     */     Iterator i$;
/* 451 */     if (paramValues != null)
/* 452 */       for (i$ = paramValues.iterator(); i$.hasNext(); ) { Object inValue = i$.next();
/* 453 */         if ((inValue instanceof DisposableSqlTypeValue)) {
/* 454 */           ((DisposableSqlTypeValue)inValue).cleanup();
/*     */         }
/* 456 */         else if ((inValue instanceof SqlValue))
/* 457 */           ((SqlValue)inValue).cleanup();
/*     */       }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  93 */     javaTypeToSqlTypeMap.put(Byte.TYPE, Integer.valueOf(-6));
/*  94 */     javaTypeToSqlTypeMap.put(Byte.class, Integer.valueOf(-6));
/*  95 */     javaTypeToSqlTypeMap.put(Short.TYPE, Integer.valueOf(5));
/*  96 */     javaTypeToSqlTypeMap.put(Short.class, Integer.valueOf(5));
/*  97 */     javaTypeToSqlTypeMap.put(Integer.TYPE, Integer.valueOf(4));
/*  98 */     javaTypeToSqlTypeMap.put(Integer.class, Integer.valueOf(4));
/*  99 */     javaTypeToSqlTypeMap.put(Long.TYPE, Integer.valueOf(-5));
/* 100 */     javaTypeToSqlTypeMap.put(Long.class, Integer.valueOf(-5));
/* 101 */     javaTypeToSqlTypeMap.put(BigInteger.class, Integer.valueOf(-5));
/* 102 */     javaTypeToSqlTypeMap.put(Float.TYPE, Integer.valueOf(6));
/* 103 */     javaTypeToSqlTypeMap.put(Float.class, Integer.valueOf(6));
/* 104 */     javaTypeToSqlTypeMap.put(Double.TYPE, Integer.valueOf(8));
/* 105 */     javaTypeToSqlTypeMap.put(Double.class, Integer.valueOf(8));
/* 106 */     javaTypeToSqlTypeMap.put(BigDecimal.class, Integer.valueOf(3));
/* 107 */     javaTypeToSqlTypeMap.put(java.sql.Date.class, Integer.valueOf(91));
/* 108 */     javaTypeToSqlTypeMap.put(Time.class, Integer.valueOf(92));
/* 109 */     javaTypeToSqlTypeMap.put(Timestamp.class, Integer.valueOf(93));
/* 110 */     javaTypeToSqlTypeMap.put(Blob.class, Integer.valueOf(2004));
/* 111 */     javaTypeToSqlTypeMap.put(Clob.class, Integer.valueOf(2005));
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.StatementCreatorUtils
 * JD-Core Version:    0.6.1
 */