/*    */ package org.springframework.jdbc.support.incrementer;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ public class HsqlSequenceMaxValueIncrementer extends AbstractSequenceMaxValueIncrementer
/*    */ {
/*    */   public HsqlSequenceMaxValueIncrementer()
/*    */   {
/*    */   }
/*    */ 
/*    */   public HsqlSequenceMaxValueIncrementer(DataSource dataSource, String incrementerName)
/*    */   {
/* 48 */     super(dataSource, incrementerName);
/*    */   }
/*    */ 
/*    */   protected String getSequenceQuery()
/*    */   {
/* 54 */     return "call next value for " + getIncrementerName();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.incrementer.HsqlSequenceMaxValueIncrementer
 * JD-Core Version:    0.6.1
 */