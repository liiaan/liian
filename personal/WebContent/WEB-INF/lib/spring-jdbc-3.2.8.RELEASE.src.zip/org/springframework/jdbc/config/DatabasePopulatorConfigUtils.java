/*    */ package org.springframework.jdbc.config;
/*    */ 
/*    */ import java.util.List;
/*    */ import org.springframework.beans.factory.config.BeanDefinition;
/*    */ import org.springframework.beans.factory.config.TypedStringValue;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.support.ManagedList;
/*    */ import org.springframework.jdbc.datasource.init.CompositeDatabasePopulator;
/*    */ import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.springframework.util.xml.DomUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ class DatabasePopulatorConfigUtils
/*    */ {
/*    */   public static void setDatabasePopulator(Element element, BeanDefinitionBuilder builder)
/*    */   {
/* 39 */     List scripts = DomUtils.getChildElementsByTagName(element, "script");
/* 40 */     if (scripts.size() > 0) {
/* 41 */       builder.addPropertyValue("databasePopulator", createDatabasePopulator(element, scripts, "INIT"));
/* 42 */       builder.addPropertyValue("databaseCleaner", createDatabasePopulator(element, scripts, "DESTROY"));
/*    */     }
/*    */   }
/*    */ 
/*    */   private static BeanDefinition createDatabasePopulator(Element element, List<Element> scripts, String execution) {
/* 47 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(CompositeDatabasePopulator.class);
/*    */ 
/* 49 */     boolean ignoreFailedDrops = element.getAttribute("ignore-failures").equals("DROPS");
/* 50 */     boolean continueOnError = element.getAttribute("ignore-failures").equals("ALL");
/*    */ 
/* 52 */     ManagedList delegates = new ManagedList();
/* 53 */     for (Element scriptElement : scripts) {
/* 54 */       String executionAttr = scriptElement.getAttribute("execution");
/* 55 */       if (!StringUtils.hasText(executionAttr)) {
/* 56 */         executionAttr = "INIT";
/*    */       }
/* 58 */       if (execution.equals(executionAttr))
/*    */       {
/* 61 */         BeanDefinitionBuilder delegate = BeanDefinitionBuilder.genericBeanDefinition(ResourceDatabasePopulator.class);
/* 62 */         delegate.addPropertyValue("ignoreFailedDrops", Boolean.valueOf(ignoreFailedDrops));
/* 63 */         delegate.addPropertyValue("continueOnError", Boolean.valueOf(continueOnError));
/*    */ 
/* 66 */         BeanDefinitionBuilder resourcesFactory = BeanDefinitionBuilder.genericBeanDefinition(SortedResourcesFactoryBean.class);
/* 67 */         resourcesFactory.addConstructorArgValue(new TypedStringValue(scriptElement.getAttribute("location")));
/* 68 */         delegate.addPropertyValue("scripts", resourcesFactory.getBeanDefinition());
/* 69 */         if (StringUtils.hasLength(scriptElement.getAttribute("encoding"))) {
/* 70 */           delegate.addPropertyValue("sqlScriptEncoding", new TypedStringValue(scriptElement.getAttribute("encoding")));
/*    */         }
/* 72 */         if (StringUtils.hasLength(scriptElement.getAttribute("separator"))) {
/* 73 */           delegate.addPropertyValue("separator", new TypedStringValue(scriptElement.getAttribute("separator")));
/*    */         }
/* 75 */         delegates.add(delegate.getBeanDefinition());
/*    */       }
/*    */     }
/* 77 */     builder.addPropertyValue("populators", delegates);
/*    */ 
/* 79 */     return builder.getBeanDefinition();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.config.DatabasePopulatorConfigUtils
 * JD-Core Version:    0.6.1
 */