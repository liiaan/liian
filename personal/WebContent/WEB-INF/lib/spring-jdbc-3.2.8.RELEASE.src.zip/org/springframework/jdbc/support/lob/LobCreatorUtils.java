/*    */ package org.springframework.jdbc.support.lob;
/*    */ 
/*    */ import javax.transaction.Transaction;
/*    */ import javax.transaction.TransactionManager;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.transaction.TransactionSystemException;
/*    */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*    */ 
/*    */ public abstract class LobCreatorUtils
/*    */ {
/* 42 */   private static final Log logger = LogFactory.getLog(LobCreatorUtils.class);
/*    */ 
/*    */   public static void registerTransactionSynchronization(LobCreator lobCreator, TransactionManager jtaTransactionManager)
/*    */     throws IllegalStateException
/*    */   {
/* 58 */     if (TransactionSynchronizationManager.isSynchronizationActive()) {
/* 59 */       logger.debug("Registering Spring transaction synchronization for LobCreator");
/* 60 */       TransactionSynchronizationManager.registerSynchronization(new SpringLobCreatorSynchronization(lobCreator));
/*    */     }
/*    */     else
/*    */     {
/* 64 */       if (jtaTransactionManager != null) {
/*    */         try {
/* 66 */           int jtaStatus = jtaTransactionManager.getStatus();
/* 67 */           if ((jtaStatus == 0) || (jtaStatus == 1)) {
/* 68 */             logger.debug("Registering JTA transaction synchronization for LobCreator");
/* 69 */             jtaTransactionManager.getTransaction().registerSynchronization(new JtaLobCreatorSynchronization(lobCreator));
/*    */ 
/* 71 */             return;
/*    */           }
/*    */         }
/*    */         catch (Throwable ex) {
/* 75 */           throw new TransactionSystemException("Could not register synchronization with JTA TransactionManager", ex);
/*    */         }
/*    */       }
/*    */ 
/* 79 */       throw new IllegalStateException("Active Spring transaction synchronization or active JTA transaction with specified [javax.transaction.TransactionManager] required");
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.lob.LobCreatorUtils
 * JD-Core Version:    0.6.1
 */