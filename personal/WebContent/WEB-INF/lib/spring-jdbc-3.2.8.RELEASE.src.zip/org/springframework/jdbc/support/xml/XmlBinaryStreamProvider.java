package org.springframework.jdbc.support.xml;

import java.io.IOException;
import java.io.OutputStream;

public abstract interface XmlBinaryStreamProvider
{
  public abstract void provideXml(OutputStream paramOutputStream)
    throws IOException;
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.xml.XmlBinaryStreamProvider
 * JD-Core Version:    0.6.1
 */