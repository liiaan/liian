/*    */ package org.springframework.jdbc.datasource.embedded;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Statement;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ abstract class AbstractEmbeddedDatabaseConfigurer
/*    */   implements EmbeddedDatabaseConfigurer
/*    */ {
/* 36 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */ 
/*    */   public void shutdown(DataSource dataSource, String databaseName) {
/*    */     try {
/* 40 */       Connection connection = dataSource.getConnection();
/* 41 */       Statement stmt = connection.createStatement();
/* 42 */       stmt.execute("SHUTDOWN");
/*    */     }
/*    */     catch (SQLException ex) {
/* 45 */       if (this.logger.isWarnEnabled())
/* 46 */         this.logger.warn("Could not shutdown embedded database", ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.embedded.AbstractEmbeddedDatabaseConfigurer
 * JD-Core Version:    0.6.1
 */