package org.springframework.jdbc.datasource;

import java.sql.Connection;

public abstract interface ConnectionHandle
{
  public abstract Connection getConnection();

  public abstract void releaseConnection(Connection paramConnection);
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.ConnectionHandle
 * JD-Core Version:    0.6.1
 */