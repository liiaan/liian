/*     */ package org.springframework.jdbc.support;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.jdbc.CannotGetJdbcConnectionException;
/*     */ 
/*     */ public class DatabaseStartupValidator
/*     */   implements InitializingBean
/*     */ {
/*     */   public static final int DEFAULT_INTERVAL = 1;
/*     */   public static final int DEFAULT_TIMEOUT = 60;
/*  49 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private DataSource dataSource;
/*     */   private String validationQuery;
/*  55 */   private int interval = 1;
/*     */ 
/*  57 */   private int timeout = 60;
/*     */ 
/*     */   public void setDataSource(DataSource dataSource)
/*     */   {
/*  64 */     this.dataSource = dataSource;
/*     */   }
/*     */ 
/*     */   public void setValidationQuery(String validationQuery)
/*     */   {
/*  71 */     this.validationQuery = validationQuery;
/*     */   }
/*     */ 
/*     */   public void setInterval(int interval)
/*     */   {
/*  79 */     this.interval = interval;
/*     */   }
/*     */ 
/*     */   public void setTimeout(int timeout)
/*     */   {
/*  87 */     this.timeout = timeout;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/*  97 */     if (this.dataSource == null) {
/*  98 */       throw new IllegalArgumentException("dataSource is required");
/*     */     }
/* 100 */     if (this.validationQuery == null) {
/* 101 */       throw new IllegalArgumentException("validationQuery is required");
/*     */     }
/*     */     try
/*     */     {
/* 105 */       boolean validated = false;
/* 106 */       long beginTime = System.currentTimeMillis();
/* 107 */       long deadLine = beginTime + this.timeout * 1000;
/* 108 */       SQLException latestEx = null;
/*     */ 
/* 110 */       while ((!validated) && (System.currentTimeMillis() < deadLine)) {
/* 111 */         Connection con = null;
/* 112 */         Statement stmt = null;
/*     */         try {
/* 114 */           con = this.dataSource.getConnection();
/* 115 */           stmt = con.createStatement();
/* 116 */           stmt.execute(this.validationQuery);
/* 117 */           validated = true;
/*     */         }
/*     */         catch (SQLException ex) {
/* 120 */           latestEx = ex;
/* 121 */           this.logger.debug("Validation query [" + this.validationQuery + "] threw exception", ex);
/* 122 */           float rest = (float)(deadLine - System.currentTimeMillis()) / 1000.0F;
/* 123 */           if (rest > this.interval) {
/* 124 */             this.logger.warn("Database has not started up yet - retrying in " + this.interval + " seconds (timeout in " + rest + " seconds)");
/*     */           }
/*     */         }
/*     */         finally
/*     */         {
/* 129 */           JdbcUtils.closeStatement(stmt);
/* 130 */           JdbcUtils.closeConnection(con);
/*     */         }
/*     */ 
/* 133 */         if (!validated) {
/* 134 */           Thread.sleep(this.interval * 1000);
/*     */         }
/*     */       }
/*     */ 
/* 138 */       if (!validated) {
/* 139 */         throw new CannotGetJdbcConnectionException("Database has not started up within " + this.timeout + " seconds", latestEx);
/*     */       }
/*     */ 
/* 143 */       float duration = (float)((System.currentTimeMillis() - beginTime) / 1000L);
/* 144 */       if (this.logger.isInfoEnabled()) {
/* 145 */         this.logger.info("Database startup detected after " + duration + " seconds");
/*     */       }
/*     */     }
/*     */     catch (InterruptedException ex)
/*     */     {
/* 150 */       Thread.currentThread().interrupt();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.DatabaseStartupValidator
 * JD-Core Version:    0.6.1
 */