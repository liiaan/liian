/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import org.springframework.dao.TypeMismatchDataAccessException;
/*     */ import org.springframework.jdbc.IncorrectResultSetColumnCountException;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.util.NumberUtils;
/*     */ 
/*     */ public class SingleColumnRowMapper<T>
/*     */   implements RowMapper<T>
/*     */ {
/*     */   private Class<T> requiredType;
/*     */ 
/*     */   public SingleColumnRowMapper()
/*     */   {
/*     */   }
/*     */ 
/*     */   public SingleColumnRowMapper(Class<T> requiredType)
/*     */   {
/*  59 */     this.requiredType = requiredType;
/*     */   }
/*     */ 
/*     */   public void setRequiredType(Class<T> requiredType)
/*     */   {
/*  68 */     this.requiredType = requiredType;
/*     */   }
/*     */ 
/*     */   public T mapRow(ResultSet rs, int rowNum)
/*     */     throws SQLException
/*     */   {
/*  84 */     ResultSetMetaData rsmd = rs.getMetaData();
/*  85 */     int nrOfColumns = rsmd.getColumnCount();
/*  86 */     if (nrOfColumns != 1) {
/*  87 */       throw new IncorrectResultSetColumnCountException(1, nrOfColumns);
/*     */     }
/*     */ 
/*  91 */     Object result = getColumnValue(rs, 1, this.requiredType);
/*  92 */     if ((result != null) && (this.requiredType != null) && (!this.requiredType.isInstance(result))) {
/*     */       try
/*     */       {
/*  95 */         return convertValueToRequiredType(result, this.requiredType);
/*     */       }
/*     */       catch (IllegalArgumentException ex) {
/*  98 */         throw new TypeMismatchDataAccessException("Type mismatch affecting row number " + rowNum + " and column type '" + rsmd.getColumnTypeName(1) + "': " + ex.getMessage());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 103 */     return result;
/*     */   }
/*     */ 
/*     */   protected Object getColumnValue(ResultSet rs, int index, Class requiredType)
/*     */     throws SQLException
/*     */   {
/* 124 */     if (requiredType != null) {
/* 125 */       return JdbcUtils.getResultSetValue(rs, index, requiredType);
/*     */     }
/*     */ 
/* 129 */     return getColumnValue(rs, index);
/*     */   }
/*     */ 
/*     */   protected Object getColumnValue(ResultSet rs, int index)
/*     */     throws SQLException
/*     */   {
/* 148 */     return JdbcUtils.getResultSetValue(rs, index);
/*     */   }
/*     */ 
/*     */   protected Object convertValueToRequiredType(Object value, Class requiredType)
/*     */   {
/* 167 */     if (String.class.equals(requiredType)) {
/* 168 */       return value.toString();
/*     */     }
/* 170 */     if (Number.class.isAssignableFrom(requiredType)) {
/* 171 */       if ((value instanceof Number))
/*     */       {
/* 173 */         return NumberUtils.convertNumberToTargetClass((Number)value, requiredType);
/*     */       }
/*     */ 
/* 177 */       return NumberUtils.parseNumber(value.toString(), requiredType);
/*     */     }
/*     */ 
/* 181 */     throw new IllegalArgumentException("Value [" + value + "] is of type [" + value.getClass().getName() + "] and cannot be converted to required type [" + requiredType.getName() + "]");
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.SingleColumnRowMapper
 * JD-Core Version:    0.6.1
 */