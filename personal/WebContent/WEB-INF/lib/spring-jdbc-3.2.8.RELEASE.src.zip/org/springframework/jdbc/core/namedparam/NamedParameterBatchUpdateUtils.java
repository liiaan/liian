/*    */ package org.springframework.jdbc.core.namedparam;
/*    */ 
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.jdbc.core.BatchPreparedStatementSetter;
/*    */ import org.springframework.jdbc.core.BatchUpdateUtils;
/*    */ import org.springframework.jdbc.core.JdbcOperations;
/*    */ 
/*    */ public class NamedParameterBatchUpdateUtils extends BatchUpdateUtils
/*    */ {
/*    */   public static int[] executeBatchUpdateWithNamedParameters(ParsedSql parsedSql, final SqlParameterSource[] batchArgs, JdbcOperations jdbcOperations)
/*    */   {
/* 36 */     if (batchArgs.length <= 0) {
/* 37 */       return new int[] { 0 };
/*    */     }
/* 39 */     String sqlToUse = NamedParameterUtils.substituteNamedParameters(parsedSql, batchArgs[0]);
/* 40 */     return jdbcOperations.batchUpdate(sqlToUse, new BatchPreparedStatementSetter()
/*    */     {
/*    */       public void setValues(PreparedStatement ps, int i)
/*    */         throws SQLException
/*    */       {
/* 45 */         Object[] values = NamedParameterUtils.buildValueArray(this.val$parsedSql, batchArgs[i], null);
/* 46 */         int[] columnTypes = NamedParameterUtils.buildSqlTypeArray(this.val$parsedSql, batchArgs[i]);
/* 47 */         NamedParameterBatchUpdateUtils.setStatementParameters(values, ps, columnTypes);
/*    */       }
/*    */ 
/*    */       public int getBatchSize() {
/* 51 */         return batchArgs.length;
/*    */       }
/*    */     });
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.namedparam.NamedParameterBatchUpdateUtils
 * JD-Core Version:    0.6.1
 */