package org.springframework.jdbc.datasource.lookup;

import javax.sql.DataSource;

public abstract interface DataSourceLookup
{
  public abstract DataSource getDataSource(String paramString)
    throws DataSourceLookupFailureException;
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.lookup.DataSourceLookup
 * JD-Core Version:    0.6.1
 */