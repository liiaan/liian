/*    */ package org.springframework.jdbc.support.incrementer;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ public class OracleSequenceMaxValueIncrementer extends AbstractSequenceMaxValueIncrementer
/*    */ {
/*    */   public OracleSequenceMaxValueIncrementer()
/*    */   {
/*    */   }
/*    */ 
/*    */   public OracleSequenceMaxValueIncrementer(DataSource dataSource, String incrementerName)
/*    */   {
/* 44 */     super(dataSource, incrementerName);
/*    */   }
/*    */ 
/*    */   protected String getSequenceQuery()
/*    */   {
/* 50 */     return "select " + getIncrementerName() + ".nextval from dual";
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.incrementer.OracleSequenceMaxValueIncrementer
 * JD-Core Version:    0.6.1
 */