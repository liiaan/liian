/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class WebSphereDataSourceAdapter extends IsolationLevelDataSourceAdapter
/*     */ {
/*  70 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private Class wsDataSourceClass;
/*     */   private Method newJdbcConnSpecMethod;
/*     */   private Method wsDataSourceGetConnectionMethod;
/*     */   private Method setTransactionIsolationMethod;
/*     */   private Method setReadOnlyMethod;
/*     */   private Method setUserNameMethod;
/*     */   private Method setPasswordMethod;
/*     */ 
/*     */   public WebSphereDataSourceAdapter()
/*     */   {
/*     */     try
/*     */     {
/*  93 */       this.wsDataSourceClass = getClass().getClassLoader().loadClass("com.ibm.websphere.rsadapter.WSDataSource");
/*  94 */       Class jdbcConnSpecClass = getClass().getClassLoader().loadClass("com.ibm.websphere.rsadapter.JDBCConnectionSpec");
/*  95 */       Class wsrraFactoryClass = getClass().getClassLoader().loadClass("com.ibm.websphere.rsadapter.WSRRAFactory");
/*  96 */       this.newJdbcConnSpecMethod = wsrraFactoryClass.getMethod("createJDBCConnectionSpec", (Class[])null);
/*  97 */       this.wsDataSourceGetConnectionMethod = this.wsDataSourceClass.getMethod("getConnection", new Class[] { jdbcConnSpecClass });
/*     */ 
/*  99 */       this.setTransactionIsolationMethod = jdbcConnSpecClass.getMethod("setTransactionIsolation", new Class[] { Integer.TYPE });
/*     */ 
/* 101 */       this.setReadOnlyMethod = jdbcConnSpecClass.getMethod("setReadOnly", new Class[] { Boolean.class });
/* 102 */       this.setUserNameMethod = jdbcConnSpecClass.getMethod("setUserName", new Class[] { String.class });
/* 103 */       this.setPasswordMethod = jdbcConnSpecClass.getMethod("setPassword", new Class[] { String.class });
/*     */     }
/*     */     catch (Exception ex) {
/* 106 */       throw new IllegalStateException("Could not initialize WebSphereDataSourceAdapter because WebSphere API classes are not available: " + ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 117 */     super.afterPropertiesSet();
/*     */ 
/* 119 */     if (!this.wsDataSourceClass.isInstance(getTargetDataSource()))
/* 120 */       throw new IllegalStateException("Specified 'targetDataSource' is not a WebSphere WSDataSource: " + getTargetDataSource());
/*     */   }
/*     */ 
/*     */   protected Connection doGetConnection(String username, String password)
/*     */     throws SQLException
/*     */   {
/* 135 */     Object connSpec = createConnectionSpec(getCurrentIsolationLevel(), getCurrentReadOnlyFlag(), username, password);
/*     */ 
/* 137 */     if (this.logger.isDebugEnabled()) {
/* 138 */       this.logger.debug("Obtaining JDBC Connection from WebSphere DataSource [" + getTargetDataSource() + "], using ConnectionSpec [" + connSpec + "]");
/*     */     }
/*     */ 
/* 142 */     return (Connection)ReflectionUtils.invokeJdbcMethod(this.wsDataSourceGetConnectionMethod, getTargetDataSource(), new Object[] { connSpec });
/*     */   }
/*     */ 
/*     */   protected Object createConnectionSpec(Integer isolationLevel, Boolean readOnlyFlag, String username, String password)
/*     */     throws SQLException
/*     */   {
/* 162 */     Object connSpec = ReflectionUtils.invokeJdbcMethod(this.newJdbcConnSpecMethod, null);
/* 163 */     if (isolationLevel != null) {
/* 164 */       ReflectionUtils.invokeJdbcMethod(this.setTransactionIsolationMethod, connSpec, new Object[] { isolationLevel });
/*     */     }
/* 166 */     if (readOnlyFlag != null) {
/* 167 */       ReflectionUtils.invokeJdbcMethod(this.setReadOnlyMethod, connSpec, new Object[] { readOnlyFlag });
/*     */     }
/*     */ 
/* 171 */     if (StringUtils.hasLength(username)) {
/* 172 */       ReflectionUtils.invokeJdbcMethod(this.setUserNameMethod, connSpec, new Object[] { username });
/* 173 */       ReflectionUtils.invokeJdbcMethod(this.setPasswordMethod, connSpec, new Object[] { password });
/*     */     }
/* 175 */     return connSpec;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.WebSphereDataSourceAdapter
 * JD-Core Version:    0.6.1
 */