/*    */ package org.springframework.jdbc.core.metadata;
/*    */ 
/*    */ import java.sql.DatabaseMetaData;
/*    */ import java.sql.SQLException;
/*    */ import org.apache.commons.logging.Log;
/*    */ 
/*    */ public class PostgresTableMetaDataProvider extends GenericTableMetaDataProvider
/*    */ {
/*    */   public PostgresTableMetaDataProvider(DatabaseMetaData databaseMetaData)
/*    */     throws SQLException
/*    */   {
/* 32 */     super(databaseMetaData);
/*    */   }
/*    */ 
/*    */   public boolean isGetGeneratedKeysSimulated()
/*    */   {
/* 37 */     if (getDatabaseVersion().compareTo("8.2.0") >= 0) {
/* 38 */       return true;
/*    */     }
/*    */ 
/* 41 */     logger.warn("PostgreSQL does not support getGeneratedKeys or INSERT ... RETURNING in version " + getDatabaseVersion());
/* 42 */     return false;
/*    */   }
/*    */ 
/*    */   public String getSimpleQueryForGetGeneratedKey(String tableName, String keyColumnName)
/*    */   {
/* 48 */     return "RETURNING " + keyColumnName;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.PostgresTableMetaDataProvider
 * JD-Core Version:    0.6.1
 */