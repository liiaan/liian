/*    */ package org.springframework.jdbc.core.support;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.jdbc.core.SqlTypeValue;
/*    */ 
/*    */ public abstract class AbstractSqlTypeValue
/*    */   implements SqlTypeValue
/*    */ {
/*    */   public final void setTypeValue(PreparedStatement ps, int paramIndex, int sqlType, String typeName)
/*    */     throws SQLException
/*    */   {
/* 58 */     Object value = createTypeValue(ps.getConnection(), sqlType, typeName);
/* 59 */     if (sqlType == -2147483648) {
/* 60 */       ps.setObject(paramIndex, value);
/*    */     }
/*    */     else
/* 63 */       ps.setObject(paramIndex, value, sqlType);
/*    */   }
/*    */ 
/*    */   protected abstract Object createTypeValue(Connection paramConnection, int paramInt, String paramString)
/*    */     throws SQLException;
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.support.AbstractSqlTypeValue
 * JD-Core Version:    0.6.1
 */