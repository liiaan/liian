/*    */ package org.springframework.jdbc.datasource.embedded;
/*    */ 
/*    */ import java.sql.Driver;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ final class HsqlEmbeddedDatabaseConfigurer extends AbstractEmbeddedDatabaseConfigurer
/*    */ {
/*    */   private static HsqlEmbeddedDatabaseConfigurer INSTANCE;
/*    */   private final Class<? extends Driver> driverClass;
/*    */ 
/*    */   public static synchronized HsqlEmbeddedDatabaseConfigurer getInstance()
/*    */     throws ClassNotFoundException
/*    */   {
/* 44 */     if (INSTANCE == null) {
/* 45 */       INSTANCE = new HsqlEmbeddedDatabaseConfigurer(ClassUtils.forName("org.hsqldb.jdbcDriver", HsqlEmbeddedDatabaseConfigurer.class.getClassLoader()));
/*    */     }
/*    */ 
/* 48 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */   private HsqlEmbeddedDatabaseConfigurer(Class<? extends Driver> driverClass) {
/* 52 */     this.driverClass = driverClass;
/*    */   }
/*    */ 
/*    */   public void configureConnectionProperties(ConnectionProperties properties, String databaseName) {
/* 56 */     properties.setDriverClass(this.driverClass);
/* 57 */     properties.setUrl("jdbc:hsqldb:mem:" + databaseName);
/* 58 */     properties.setUsername("sa");
/* 59 */     properties.setPassword("");
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.embedded.HsqlEmbeddedDatabaseConfigurer
 * JD-Core Version:    0.6.1
 */