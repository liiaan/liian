/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class TransactionAwareDataSourceProxy extends DelegatingDataSource
/*     */ {
/*  82 */   private boolean reobtainTransactionalConnections = false;
/*     */ 
/*     */   public TransactionAwareDataSourceProxy()
/*     */   {
/*     */   }
/*     */ 
/*     */   public TransactionAwareDataSourceProxy(DataSource targetDataSource)
/*     */   {
/*  97 */     super(targetDataSource);
/*     */   }
/*     */ 
/*     */   public void setReobtainTransactionalConnections(boolean reobtainTransactionalConnections)
/*     */   {
/* 110 */     this.reobtainTransactionalConnections = reobtainTransactionalConnections;
/*     */   }
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws SQLException
/*     */   {
/* 125 */     DataSource ds = getTargetDataSource();
/* 126 */     Assert.state(ds != null, "'targetDataSource' is required");
/* 127 */     return getTransactionAwareConnectionProxy(ds);
/*     */   }
/*     */ 
/*     */   protected Connection getTransactionAwareConnectionProxy(DataSource targetDataSource)
/*     */   {
/* 139 */     return (Connection)Proxy.newProxyInstance(ConnectionProxy.class.getClassLoader(), new Class[] { ConnectionProxy.class }, new TransactionAwareInvocationHandler(targetDataSource));
/*     */   }
/*     */ 
/*     */   protected boolean shouldObtainFixedConnection(DataSource targetDataSource)
/*     */   {
/* 156 */     return (!TransactionSynchronizationManager.isSynchronizationActive()) || (!this.reobtainTransactionalConnections);
/*     */   }
/*     */ 
/*     */   private class TransactionAwareInvocationHandler
/*     */     implements InvocationHandler
/*     */   {
/*     */     private final DataSource targetDataSource;
/*     */     private Connection target;
/* 171 */     private boolean closed = false;
/*     */ 
/*     */     public TransactionAwareInvocationHandler(DataSource targetDataSource) {
/* 174 */       this.targetDataSource = targetDataSource;
/*     */     }
/*     */ 
/*     */     public Object invoke(Object proxy, Method method, Object[] args)
/*     */       throws Throwable
/*     */     {
/* 180 */       if (method.getName().equals("equals"))
/*     */       {
/* 182 */         return Boolean.valueOf(proxy == args[0]);
/*     */       }
/* 184 */       if (method.getName().equals("hashCode"))
/*     */       {
/* 186 */         return Integer.valueOf(System.identityHashCode(proxy));
/*     */       }
/* 188 */       if (method.getName().equals("toString"))
/*     */       {
/* 190 */         StringBuilder sb = new StringBuilder("Transaction-aware proxy for target Connection ");
/* 191 */         if (this.target != null) {
/* 192 */           sb.append("[").append(this.target.toString()).append("]");
/*     */         }
/*     */         else {
/* 195 */           sb.append(" from DataSource [").append(this.targetDataSource).append("]");
/*     */         }
/* 197 */         return sb.toString();
/*     */       }
/* 199 */       if (method.getName().equals("unwrap")) {
/* 200 */         if (((Class)args[0]).isInstance(proxy)) {
/* 201 */           return proxy;
/*     */         }
/*     */       }
/* 204 */       else if (method.getName().equals("isWrapperFor")) {
/* 205 */         if (((Class)args[0]).isInstance(proxy))
/* 206 */           return Boolean.valueOf(true);
/*     */       }
/*     */       else {
/* 209 */         if (method.getName().equals("close"))
/*     */         {
/* 211 */           DataSourceUtils.doReleaseConnection(this.target, this.targetDataSource);
/* 212 */           this.closed = true;
/* 213 */           return null;
/*     */         }
/* 215 */         if (method.getName().equals("isClosed")) {
/* 216 */           return Boolean.valueOf(this.closed);
/*     */         }
/*     */       }
/* 219 */       if (this.target == null) {
/* 220 */         if (this.closed) {
/* 221 */           throw new SQLException("Connection handle already closed");
/*     */         }
/* 223 */         if (TransactionAwareDataSourceProxy.this.shouldObtainFixedConnection(this.targetDataSource)) {
/* 224 */           this.target = DataSourceUtils.doGetConnection(this.targetDataSource);
/*     */         }
/*     */       }
/* 227 */       Connection actualTarget = this.target;
/* 228 */       if (actualTarget == null) {
/* 229 */         actualTarget = DataSourceUtils.doGetConnection(this.targetDataSource);
/*     */       }
/*     */ 
/* 232 */       if (method.getName().equals("getTargetConnection"))
/*     */       {
/* 234 */         return actualTarget;
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 239 */         Object retVal = method.invoke(actualTarget, args);
/*     */ 
/* 243 */         if ((retVal instanceof Statement)) {
/* 244 */           DataSourceUtils.applyTransactionTimeout((Statement)retVal, this.targetDataSource);
/*     */         }
/*     */ 
/* 247 */         return retVal;
/*     */       }
/*     */       catch (InvocationTargetException ex) {
/* 250 */         throw ex.getTargetException();
/*     */       }
/*     */       finally {
/* 253 */         if (actualTarget != this.target)
/* 254 */           DataSourceUtils.doReleaseConnection(actualTarget, this.targetDataSource);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.TransactionAwareDataSourceProxy
 * JD-Core Version:    0.6.1
 */