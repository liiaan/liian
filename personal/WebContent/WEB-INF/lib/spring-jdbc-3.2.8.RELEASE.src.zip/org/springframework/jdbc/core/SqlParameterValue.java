/*    */ package org.springframework.jdbc.core;
/*    */ 
/*    */ public class SqlParameterValue extends SqlParameter
/*    */ {
/*    */   private final Object value;
/*    */ 
/*    */   public SqlParameterValue(int sqlType, Object value)
/*    */   {
/* 48 */     super(sqlType);
/* 49 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public SqlParameterValue(int sqlType, String typeName, Object value)
/*    */   {
/* 59 */     super(sqlType, typeName);
/* 60 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public SqlParameterValue(int sqlType, int scale, Object value)
/*    */   {
/* 71 */     super(sqlType, scale);
/* 72 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public SqlParameterValue(SqlParameter declaredParam, Object value)
/*    */   {
/* 81 */     super(declaredParam);
/* 82 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public Object getValue()
/*    */   {
/* 90 */     return this.value;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.SqlParameterValue
 * JD-Core Version:    0.6.1
 */