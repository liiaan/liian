/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.Savepoint;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.transaction.CannotCreateTransactionException;
/*     */ import org.springframework.transaction.NestedTransactionNotSupportedException;
/*     */ import org.springframework.transaction.SavepointManager;
/*     */ import org.springframework.transaction.TransactionException;
/*     */ import org.springframework.transaction.TransactionSystemException;
/*     */ import org.springframework.transaction.TransactionUsageException;
/*     */ import org.springframework.transaction.support.SmartTransactionObject;
/*     */ 
/*     */ public abstract class JdbcTransactionObjectSupport
/*     */   implements SavepointManager, SmartTransactionObject
/*     */ {
/*  52 */   private static final Log logger = LogFactory.getLog(JdbcTransactionObjectSupport.class);
/*     */   private ConnectionHolder connectionHolder;
/*     */   private Integer previousIsolationLevel;
/*  59 */   private boolean savepointAllowed = false;
/*     */ 
/*     */   public void setConnectionHolder(ConnectionHolder connectionHolder)
/*     */   {
/*  63 */     this.connectionHolder = connectionHolder;
/*     */   }
/*     */ 
/*     */   public ConnectionHolder getConnectionHolder() {
/*  67 */     return this.connectionHolder;
/*     */   }
/*     */ 
/*     */   public boolean hasConnectionHolder() {
/*  71 */     return this.connectionHolder != null;
/*     */   }
/*     */ 
/*     */   public void setPreviousIsolationLevel(Integer previousIsolationLevel) {
/*  75 */     this.previousIsolationLevel = previousIsolationLevel;
/*     */   }
/*     */ 
/*     */   public Integer getPreviousIsolationLevel() {
/*  79 */     return this.previousIsolationLevel;
/*     */   }
/*     */ 
/*     */   public void setSavepointAllowed(boolean savepointAllowed) {
/*  83 */     this.savepointAllowed = savepointAllowed;
/*     */   }
/*     */ 
/*     */   public boolean isSavepointAllowed() {
/*  87 */     return this.savepointAllowed;
/*     */   }
/*     */ 
/*     */   public void flush()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Object createSavepoint()
/*     */     throws TransactionException
/*     */   {
/* 104 */     ConnectionHolder conHolder = getConnectionHolderForSavepoint();
/*     */     try {
/* 106 */       if (!conHolder.supportsSavepoints()) {
/* 107 */         throw new NestedTransactionNotSupportedException("Cannot create a nested transaction because savepoints are not supported by your JDBC driver");
/*     */       }
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 112 */       throw new NestedTransactionNotSupportedException("Cannot create a nested transaction because your JDBC driver is not a JDBC 3.0 driver", ex);
/*     */     }
/*     */     try
/*     */     {
/* 116 */       return conHolder.createSavepoint();
/*     */     }
/*     */     catch (Throwable ex) {
/* 119 */       throw new CannotCreateTransactionException("Could not create JDBC savepoint", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void rollbackToSavepoint(Object savepoint)
/*     */     throws TransactionException
/*     */   {
/*     */     try
/*     */     {
/* 129 */       getConnectionHolderForSavepoint().getConnection().rollback((Savepoint)savepoint);
/*     */     }
/*     */     catch (Throwable ex) {
/* 132 */       throw new TransactionSystemException("Could not roll back to JDBC savepoint", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void releaseSavepoint(Object savepoint)
/*     */     throws TransactionException
/*     */   {
/*     */     try
/*     */     {
/* 142 */       getConnectionHolderForSavepoint().getConnection().releaseSavepoint((Savepoint)savepoint);
/*     */     }
/*     */     catch (Throwable ex) {
/* 145 */       logger.debug("Could not explicitly release JDBC savepoint", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected ConnectionHolder getConnectionHolderForSavepoint() throws TransactionException {
/* 150 */     if (!isSavepointAllowed()) {
/* 151 */       throw new NestedTransactionNotSupportedException("Transaction manager does not allow nested transactions");
/*     */     }
/*     */ 
/* 154 */     if (!hasConnectionHolder()) {
/* 155 */       throw new TransactionUsageException("Cannot create nested transaction if not exposing a JDBC transaction");
/*     */     }
/*     */ 
/* 158 */     return getConnectionHolder();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.JdbcTransactionObjectSupport
 * JD-Core Version:    0.6.1
 */