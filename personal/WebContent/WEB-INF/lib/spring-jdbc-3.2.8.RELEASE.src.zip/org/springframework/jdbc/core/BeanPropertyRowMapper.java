/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.NotWritablePropertyException;
/*     */ import org.springframework.beans.PropertyAccessorFactory;
/*     */ import org.springframework.beans.TypeMismatchException;
/*     */ import org.springframework.dao.DataRetrievalFailureException;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class BeanPropertyRowMapper<T>
/*     */   implements RowMapper<T>
/*     */ {
/*  75 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private Class<T> mappedClass;
/*  81 */   private boolean checkFullyPopulated = false;
/*     */ 
/*  84 */   private boolean primitivesDefaultedForNullValue = false;
/*     */   private Map<String, PropertyDescriptor> mappedFields;
/*     */   private Set<String> mappedProperties;
/*     */ 
/*     */   public BeanPropertyRowMapper()
/*     */   {
/*     */   }
/*     */ 
/*     */   public BeanPropertyRowMapper(Class<T> mappedClass)
/*     */   {
/* 109 */     initialize(mappedClass);
/*     */   }
/*     */ 
/*     */   public BeanPropertyRowMapper(Class<T> mappedClass, boolean checkFullyPopulated)
/*     */   {
/* 119 */     initialize(mappedClass);
/* 120 */     this.checkFullyPopulated = checkFullyPopulated;
/*     */   }
/*     */ 
/*     */   public void setMappedClass(Class<T> mappedClass)
/*     */   {
/* 128 */     if (this.mappedClass == null) {
/* 129 */       initialize(mappedClass);
/*     */     }
/* 132 */     else if (!this.mappedClass.equals(mappedClass))
/* 133 */       throw new InvalidDataAccessApiUsageException("The mapped class can not be reassigned to map to " + mappedClass + " since it is already providing mapping for " + this.mappedClass);
/*     */   }
/*     */ 
/*     */   protected void initialize(Class<T> mappedClass)
/*     */   {
/* 144 */     this.mappedClass = mappedClass;
/* 145 */     this.mappedFields = new HashMap();
/* 146 */     this.mappedProperties = new HashSet();
/* 147 */     PropertyDescriptor[] pds = BeanUtils.getPropertyDescriptors(mappedClass);
/* 148 */     for (PropertyDescriptor pd : pds)
/* 149 */       if (pd.getWriteMethod() != null) {
/* 150 */         this.mappedFields.put(pd.getName().toLowerCase(), pd);
/* 151 */         String underscoredName = underscoreName(pd.getName());
/* 152 */         if (!pd.getName().toLowerCase().equals(underscoredName)) {
/* 153 */           this.mappedFields.put(underscoredName, pd);
/*     */         }
/* 155 */         this.mappedProperties.add(pd.getName());
/*     */       }
/*     */   }
/*     */ 
/*     */   private String underscoreName(String name)
/*     */   {
/* 167 */     if (!StringUtils.hasLength(name)) {
/* 168 */       return "";
/*     */     }
/* 170 */     StringBuilder result = new StringBuilder();
/* 171 */     result.append(name.substring(0, 1).toLowerCase());
/* 172 */     for (int i = 1; i < name.length(); i++) {
/* 173 */       String s = name.substring(i, i + 1);
/* 174 */       String slc = s.toLowerCase();
/* 175 */       if (!s.equals(slc)) {
/* 176 */         result.append("_").append(slc);
/*     */       }
/*     */       else {
/* 179 */         result.append(s);
/*     */       }
/*     */     }
/* 182 */     return result.toString();
/*     */   }
/*     */ 
/*     */   public final Class<T> getMappedClass()
/*     */   {
/* 189 */     return this.mappedClass;
/*     */   }
/*     */ 
/*     */   public void setCheckFullyPopulated(boolean checkFullyPopulated)
/*     */   {
/* 199 */     this.checkFullyPopulated = checkFullyPopulated;
/*     */   }
/*     */ 
/*     */   public boolean isCheckFullyPopulated()
/*     */   {
/* 207 */     return this.checkFullyPopulated;
/*     */   }
/*     */ 
/*     */   public void setPrimitivesDefaultedForNullValue(boolean primitivesDefaultedForNullValue)
/*     */   {
/* 216 */     this.primitivesDefaultedForNullValue = primitivesDefaultedForNullValue;
/*     */   }
/*     */ 
/*     */   public boolean isPrimitivesDefaultedForNullValue()
/*     */   {
/* 224 */     return this.primitivesDefaultedForNullValue;
/*     */   }
/*     */ 
/*     */   public T mapRow(ResultSet rs, int rowNumber)
/*     */     throws SQLException
/*     */   {
/* 234 */     Assert.state(this.mappedClass != null, "Mapped class was not specified");
/* 235 */     Object mappedObject = BeanUtils.instantiate(this.mappedClass);
/* 236 */     BeanWrapper bw = PropertyAccessorFactory.forBeanPropertyAccess(mappedObject);
/* 237 */     initBeanWrapper(bw);
/*     */ 
/* 239 */     ResultSetMetaData rsmd = rs.getMetaData();
/* 240 */     int columnCount = rsmd.getColumnCount();
/* 241 */     Set populatedProperties = isCheckFullyPopulated() ? new HashSet() : null;
/*     */ 
/* 243 */     for (int index = 1; index <= columnCount; index++) {
/* 244 */       String column = JdbcUtils.lookupColumnName(rsmd, index);
/* 245 */       PropertyDescriptor pd = (PropertyDescriptor)this.mappedFields.get(column.replaceAll(" ", "").toLowerCase());
/* 246 */       if (pd != null) {
/*     */         try {
/* 248 */           Object value = getColumnValue(rs, index, pd);
/* 249 */           if ((this.logger.isDebugEnabled()) && (rowNumber == 0)) {
/* 250 */             this.logger.debug("Mapping column '" + column + "' to property '" + pd.getName() + "' of type " + pd.getPropertyType());
/*     */           }
/*     */           try
/*     */           {
/* 254 */             bw.setPropertyValue(pd.getName(), value);
/*     */           }
/*     */           catch (TypeMismatchException e) {
/* 257 */             if ((value == null) && (this.primitivesDefaultedForNullValue)) {
/* 258 */               this.logger.debug("Intercepted TypeMismatchException for row " + rowNumber + " and column '" + column + "' with value " + value + " when setting property '" + pd.getName() + "' of type " + pd.getPropertyType() + " on object: " + mappedObject);
/*     */             }
/*     */             else
/*     */             {
/* 264 */               throw e;
/*     */             }
/*     */           }
/* 267 */           if (populatedProperties != null)
/* 268 */             populatedProperties.add(pd.getName());
/*     */         }
/*     */         catch (NotWritablePropertyException ex)
/*     */         {
/* 272 */           throw new DataRetrievalFailureException("Unable to map column " + column + " to property " + pd.getName(), ex);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 278 */     if ((populatedProperties != null) && (!populatedProperties.equals(this.mappedProperties))) {
/* 279 */       throw new InvalidDataAccessApiUsageException("Given ResultSet does not contain all fields necessary to populate object of class [" + this.mappedClass + "]: " + this.mappedProperties);
/*     */     }
/*     */ 
/* 283 */     return mappedObject;
/*     */   }
/*     */ 
/*     */   protected void initBeanWrapper(BeanWrapper bw)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected Object getColumnValue(ResultSet rs, int index, PropertyDescriptor pd)
/*     */     throws SQLException
/*     */   {
/* 310 */     return JdbcUtils.getResultSetValue(rs, index, pd.getPropertyType());
/*     */   }
/*     */ 
/*     */   public static <T> BeanPropertyRowMapper<T> newInstance(Class<T> mappedClass)
/*     */   {
/* 320 */     BeanPropertyRowMapper newInstance = new BeanPropertyRowMapper();
/* 321 */     newInstance.setMappedClass(mappedClass);
/* 322 */     return newInstance;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.BeanPropertyRowMapper
 * JD-Core Version:    0.6.1
 */