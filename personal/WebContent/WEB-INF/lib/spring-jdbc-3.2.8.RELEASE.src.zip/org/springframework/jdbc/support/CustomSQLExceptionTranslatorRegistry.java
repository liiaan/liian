/*    */ package org.springframework.jdbc.support;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public class CustomSQLExceptionTranslatorRegistry
/*    */ {
/* 36 */   private static final Log logger = LogFactory.getLog(CustomSQLExceptionTranslatorRegistry.class);
/*    */ 
/* 41 */   private static final CustomSQLExceptionTranslatorRegistry instance = new CustomSQLExceptionTranslatorRegistry();
/*    */ 
/* 57 */   private final Map<String, SQLExceptionTranslator> translatorMap = new HashMap();
/*    */ 
/*    */   public static CustomSQLExceptionTranslatorRegistry getInstance()
/*    */   {
/* 48 */     return instance;
/*    */   }
/*    */ 
/*    */   public void registerTranslator(String dbName, SQLExceptionTranslator translator)
/*    */   {
/* 73 */     SQLExceptionTranslator replaced = (SQLExceptionTranslator)this.translatorMap.put(dbName, translator);
/* 74 */     if (replaced != null) {
/* 75 */       logger.warn("Replacing custom translator [" + replaced + "] for database '" + dbName + "' with [" + translator + "]");
/*    */     }
/*    */     else
/*    */     {
/* 79 */       logger.info("Adding custom translator of type [" + translator.getClass().getName() + "] for database '" + dbName + "'");
/*    */     }
/*    */   }
/*    */ 
/*    */   public SQLExceptionTranslator findTranslatorForDatabase(String dbName)
/*    */   {
/* 90 */     return (SQLExceptionTranslator)this.translatorMap.get(dbName);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.CustomSQLExceptionTranslatorRegistry
 * JD-Core Version:    0.6.1
 */