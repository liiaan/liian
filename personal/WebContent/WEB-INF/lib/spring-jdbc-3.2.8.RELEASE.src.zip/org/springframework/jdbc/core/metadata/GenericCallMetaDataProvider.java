/*     */ package org.springframework.jdbc.core.metadata;
/*     */ 
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.jdbc.core.SqlInOutParameter;
/*     */ import org.springframework.jdbc.core.SqlOutParameter;
/*     */ import org.springframework.jdbc.core.SqlParameter;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class GenericCallMetaDataProvider
/*     */   implements CallMetaDataProvider
/*     */ {
/*  45 */   protected static final Log logger = LogFactory.getLog(CallMetaDataProvider.class);
/*     */ 
/*  47 */   private boolean procedureColumnMetaDataUsed = false;
/*     */   private String userName;
/*  51 */   private boolean supportsCatalogsInProcedureCalls = true;
/*     */ 
/*  53 */   private boolean supportsSchemasInProcedureCalls = true;
/*     */ 
/*  55 */   private boolean storesUpperCaseIdentifiers = true;
/*     */ 
/*  57 */   private boolean storesLowerCaseIdentifiers = false;
/*     */ 
/*  59 */   private List<CallParameterMetaData> callParameterMetaData = new ArrayList();
/*     */ 
/*     */   protected GenericCallMetaDataProvider(DatabaseMetaData databaseMetaData)
/*     */     throws SQLException
/*     */   {
/*  67 */     this.userName = databaseMetaData.getUserName();
/*     */   }
/*     */ 
/*     */   public void initializeWithMetaData(DatabaseMetaData databaseMetaData) throws SQLException
/*     */   {
/*     */     try {
/*  73 */       setSupportsCatalogsInProcedureCalls(databaseMetaData.supportsCatalogsInProcedureCalls());
/*     */     }
/*     */     catch (SQLException se) {
/*  76 */       logger.warn("Error retrieving 'DatabaseMetaData.supportsCatalogsInProcedureCalls' - " + se.getMessage());
/*     */     }
/*     */     try {
/*  79 */       setSupportsSchemasInProcedureCalls(databaseMetaData.supportsSchemasInProcedureCalls());
/*     */     }
/*     */     catch (SQLException se) {
/*  82 */       logger.warn("Error retrieving 'DatabaseMetaData.supportsSchemasInProcedureCalls' - " + se.getMessage());
/*     */     }
/*     */     try {
/*  85 */       setStoresUpperCaseIdentifiers(databaseMetaData.storesUpperCaseIdentifiers());
/*     */     }
/*     */     catch (SQLException se) {
/*  88 */       logger.warn("Error retrieving 'DatabaseMetaData.storesUpperCaseIdentifiers' - " + se.getMessage());
/*     */     }
/*     */     try {
/*  91 */       setStoresLowerCaseIdentifiers(databaseMetaData.storesLowerCaseIdentifiers());
/*     */     }
/*     */     catch (SQLException se) {
/*  94 */       logger.warn("Error retrieving 'DatabaseMetaData.storesLowerCaseIdentifiers' - " + se.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void initializeWithProcedureColumnMetaData(DatabaseMetaData databaseMetaData, String catalogName, String schemaName, String procedureName)
/*     */     throws SQLException
/*     */   {
/* 101 */     this.procedureColumnMetaDataUsed = true;
/* 102 */     processProcedureColumns(databaseMetaData, catalogName, schemaName, procedureName);
/*     */   }
/*     */ 
/*     */   public List<CallParameterMetaData> getCallParameterMetaData() {
/* 106 */     return this.callParameterMetaData;
/*     */   }
/*     */ 
/*     */   public String procedureNameToUse(String procedureName) {
/* 110 */     if (procedureName == null) {
/* 111 */       return null;
/*     */     }
/* 113 */     if (isStoresUpperCaseIdentifiers()) {
/* 114 */       return procedureName.toUpperCase();
/*     */     }
/* 116 */     if (isStoresLowerCaseIdentifiers()) {
/* 117 */       return procedureName.toLowerCase();
/*     */     }
/*     */ 
/* 120 */     return procedureName;
/*     */   }
/*     */ 
/*     */   public String catalogNameToUse(String catalogName)
/*     */   {
/* 125 */     if (catalogName == null) {
/* 126 */       return null;
/*     */     }
/* 128 */     if (isStoresUpperCaseIdentifiers()) {
/* 129 */       return catalogName.toUpperCase();
/*     */     }
/* 131 */     if (isStoresLowerCaseIdentifiers()) {
/* 132 */       return catalogName.toLowerCase();
/*     */     }
/*     */ 
/* 135 */     return catalogName;
/*     */   }
/*     */ 
/*     */   public String schemaNameToUse(String schemaName)
/*     */   {
/* 140 */     if (schemaName == null) {
/* 141 */       return null;
/*     */     }
/* 143 */     if (isStoresUpperCaseIdentifiers()) {
/* 144 */       return schemaName.toUpperCase();
/*     */     }
/* 146 */     if (isStoresLowerCaseIdentifiers()) {
/* 147 */       return schemaName.toLowerCase();
/*     */     }
/*     */ 
/* 150 */     return schemaName;
/*     */   }
/*     */ 
/*     */   public String metaDataCatalogNameToUse(String catalogName)
/*     */   {
/* 155 */     if (isSupportsCatalogsInProcedureCalls()) {
/* 156 */       return catalogNameToUse(catalogName);
/*     */     }
/*     */ 
/* 159 */     return null;
/*     */   }
/*     */ 
/*     */   public String metaDataSchemaNameToUse(String schemaName)
/*     */   {
/* 164 */     if (isSupportsSchemasInProcedureCalls()) {
/* 165 */       return schemaNameToUse(schemaName);
/*     */     }
/*     */ 
/* 168 */     return null;
/*     */   }
/*     */ 
/*     */   public String parameterNameToUse(String parameterName)
/*     */   {
/* 173 */     if (parameterName == null) {
/* 174 */       return null;
/*     */     }
/* 176 */     if (isStoresUpperCaseIdentifiers()) {
/* 177 */       return parameterName.toUpperCase();
/*     */     }
/* 179 */     if (isStoresLowerCaseIdentifiers()) {
/* 180 */       return parameterName.toLowerCase();
/*     */     }
/*     */ 
/* 183 */     return parameterName;
/*     */   }
/*     */ 
/*     */   public boolean byPassReturnParameter(String parameterName)
/*     */   {
/* 188 */     return false;
/*     */   }
/*     */ 
/*     */   public SqlParameter createDefaultOutParameter(String parameterName, CallParameterMetaData meta) {
/* 192 */     return new SqlOutParameter(parameterName, meta.getSqlType());
/*     */   }
/*     */ 
/*     */   public SqlParameter createDefaultInOutParameter(String parameterName, CallParameterMetaData meta) {
/* 196 */     return new SqlInOutParameter(parameterName, meta.getSqlType());
/*     */   }
/*     */ 
/*     */   public SqlParameter createDefaultInParameter(String parameterName, CallParameterMetaData meta) {
/* 200 */     return new SqlParameter(parameterName, meta.getSqlType());
/*     */   }
/*     */ 
/*     */   public String getUserName() {
/* 204 */     return this.userName;
/*     */   }
/*     */ 
/*     */   public boolean isReturnResultSetSupported() {
/* 208 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isRefCursorSupported() {
/* 212 */     return false;
/*     */   }
/*     */ 
/*     */   public int getRefCursorSqlType() {
/* 216 */     return 1111;
/*     */   }
/*     */ 
/*     */   public boolean isProcedureColumnMetaDataUsed() {
/* 220 */     return this.procedureColumnMetaDataUsed;
/*     */   }
/*     */ 
/*     */   protected void setSupportsCatalogsInProcedureCalls(boolean supportsCatalogsInProcedureCalls)
/*     */   {
/* 228 */     this.supportsCatalogsInProcedureCalls = supportsCatalogsInProcedureCalls;
/*     */   }
/*     */ 
/*     */   public boolean isSupportsCatalogsInProcedureCalls()
/*     */   {
/* 235 */     return this.supportsCatalogsInProcedureCalls;
/*     */   }
/*     */ 
/*     */   protected void setSupportsSchemasInProcedureCalls(boolean supportsSchemasInProcedureCalls)
/*     */   {
/* 242 */     this.supportsSchemasInProcedureCalls = supportsSchemasInProcedureCalls;
/*     */   }
/*     */ 
/*     */   public boolean isSupportsSchemasInProcedureCalls()
/*     */   {
/* 249 */     return this.supportsSchemasInProcedureCalls;
/*     */   }
/*     */ 
/*     */   protected void setStoresUpperCaseIdentifiers(boolean storesUpperCaseIdentifiers)
/*     */   {
/* 256 */     this.storesUpperCaseIdentifiers = storesUpperCaseIdentifiers;
/*     */   }
/*     */ 
/*     */   protected boolean isStoresUpperCaseIdentifiers()
/*     */   {
/* 263 */     return this.storesUpperCaseIdentifiers;
/*     */   }
/*     */ 
/*     */   protected void setStoresLowerCaseIdentifiers(boolean storesLowerCaseIdentifiers)
/*     */   {
/* 270 */     this.storesLowerCaseIdentifiers = storesLowerCaseIdentifiers;
/*     */   }
/*     */ 
/*     */   protected boolean isStoresLowerCaseIdentifiers()
/*     */   {
/* 277 */     return this.storesLowerCaseIdentifiers;
/*     */   }
/*     */ 
/*     */   private void processProcedureColumns(DatabaseMetaData databaseMetaData, String catalogName, String schemaName, String procedureName)
/*     */   {
/* 285 */     ResultSet procs = null;
/* 286 */     String metaDataCatalogName = metaDataCatalogNameToUse(catalogName);
/* 287 */     String metaDataSchemaName = metaDataSchemaNameToUse(schemaName);
/* 288 */     String metaDataProcedureName = procedureNameToUse(procedureName);
/* 289 */     if (logger.isDebugEnabled()) {
/* 290 */       logger.debug("Retrieving metadata for " + metaDataCatalogName + "/" + metaDataSchemaName + "/" + metaDataProcedureName);
/*     */     }
/*     */     try
/*     */     {
/* 294 */       procs = databaseMetaData.getProcedures(metaDataCatalogName, metaDataSchemaName, metaDataProcedureName);
/* 295 */       List found = new ArrayList();
/* 296 */       while (procs.next()) {
/* 297 */         found.add(procs.getString("PROCEDURE_CAT") + "." + procs.getString("PROCEDURE_SCHEM") + "." + procs.getString("PROCEDURE_NAME"));
/*     */       }
/*     */ 
/* 300 */       procs.close();
/* 301 */       if (found.size() > 1) {
/* 302 */         throw new InvalidDataAccessApiUsageException("Unable to determine the correct call signature - multiple procedures/functions/signatures for " + metaDataProcedureName + " found " + found);
/*     */       }
/*     */ 
/* 305 */       if ((found.size() < 1) && 
/* 306 */         (metaDataProcedureName.contains(".")) && (!StringUtils.hasText(metaDataCatalogName))) {
/* 307 */         String packageName = metaDataProcedureName.substring(0, metaDataProcedureName.indexOf("."));
/* 308 */         throw new InvalidDataAccessApiUsageException("Unable to determine the correct call signature for " + metaDataProcedureName + " - package name should be specified separately using " + "'.withCatalogName(\"" + packageName + "\")'");
/*     */       }
/*     */ 
/* 314 */       procs = databaseMetaData.getProcedureColumns(metaDataCatalogName, metaDataSchemaName, metaDataProcedureName, null);
/*     */ 
/* 316 */       while (procs.next()) {
/* 317 */         String columnName = procs.getString("COLUMN_NAME");
/* 318 */         int columnType = procs.getInt("COLUMN_TYPE");
/* 319 */         if ((columnName == null) && ((columnType == 1) || (columnType == 2) || (columnType == 4)))
/*     */         {
/* 323 */           if (logger.isDebugEnabled()) {
/* 324 */             logger.debug("Skipping metadata for: " + columnName + " " + columnType + " " + procs.getInt("DATA_TYPE") + " " + procs.getString("TYPE_NAME") + " " + procs.getBoolean("NULLABLE") + " (probably a member of a collection)");
/*     */           }
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 335 */           CallParameterMetaData meta = new CallParameterMetaData(columnName, columnType, procs.getInt("DATA_TYPE"), procs.getString("TYPE_NAME"), procs.getBoolean("NULLABLE"));
/*     */ 
/* 338 */           this.callParameterMetaData.add(meta);
/* 339 */           if (logger.isDebugEnabled()) {
/* 340 */             logger.debug("Retrieved metadata: " + meta.getParameterName() + " " + meta.getParameterType() + " " + meta.getSqlType() + " " + meta.getTypeName() + " " + meta.isNullable());
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (SQLException ex)
/*     */     {
/* 349 */       logger.warn("Error while retrieving metadata for procedure columns: " + ex);
/*     */     }
/*     */     finally {
/*     */       try {
/* 353 */         if (procs != null)
/* 354 */           procs.close();
/*     */       }
/*     */       catch (SQLException ex)
/*     */       {
/* 358 */         logger.warn("Problem closing ResultSet for procedure column metadata: " + ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.GenericCallMetaDataProvider
 * JD-Core Version:    0.6.1
 */