/*     */ package org.springframework.jdbc.datasource.lookup;
/*     */ 
/*     */ import org.springframework.core.Constants;
/*     */ import org.springframework.transaction.TransactionDefinition;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ 
/*     */ public class IsolationLevelDataSourceRouter extends AbstractRoutingDataSource
/*     */ {
/*  95 */   private static final Constants constants = new Constants(TransactionDefinition.class);
/*     */ 
/*     */   protected Object resolveSpecifiedLookupKey(Object lookupKey)
/*     */   {
/* 105 */     if ((lookupKey instanceof Integer)) {
/* 106 */       return lookupKey;
/*     */     }
/* 108 */     if ((lookupKey instanceof String)) {
/* 109 */       String constantName = (String)lookupKey;
/* 110 */       if (!constantName.startsWith("ISOLATION_")) {
/* 111 */         throw new IllegalArgumentException("Only isolation constants allowed");
/*     */       }
/* 113 */       return constants.asNumber(constantName);
/*     */     }
/*     */ 
/* 116 */     throw new IllegalArgumentException("Invalid lookup key - needs to be isolation level Integer or isolation level name String: " + lookupKey);
/*     */   }
/*     */ 
/*     */   protected Object determineCurrentLookupKey()
/*     */   {
/* 123 */     return TransactionSynchronizationManager.getCurrentTransactionIsolationLevel();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.lookup.IsolationLevelDataSourceRouter
 * JD-Core Version:    0.6.1
 */