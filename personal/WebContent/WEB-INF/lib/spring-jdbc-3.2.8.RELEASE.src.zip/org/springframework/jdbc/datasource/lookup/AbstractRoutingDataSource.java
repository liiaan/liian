/*     */ package org.springframework.jdbc.datasource.lookup;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.jdbc.datasource.AbstractDataSource;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class AbstractRoutingDataSource extends AbstractDataSource
/*     */   implements InitializingBean
/*     */ {
/*     */   private Map<Object, Object> targetDataSources;
/*     */   private Object defaultTargetDataSource;
/*  46 */   private boolean lenientFallback = true;
/*     */ 
/*  48 */   private DataSourceLookup dataSourceLookup = new JndiDataSourceLookup();
/*     */   private Map<Object, DataSource> resolvedDataSources;
/*     */   private DataSource resolvedDefaultDataSource;
/*     */ 
/*     */   public void setTargetDataSources(Map<Object, Object> targetDataSources)
/*     */   {
/*  66 */     this.targetDataSources = targetDataSources;
/*     */   }
/*     */ 
/*     */   public void setDefaultTargetDataSource(Object defaultTargetDataSource)
/*     */   {
/*  79 */     this.defaultTargetDataSource = defaultTargetDataSource;
/*     */   }
/*     */ 
/*     */   public void setLenientFallback(boolean lenientFallback)
/*     */   {
/*  96 */     this.lenientFallback = lenientFallback;
/*     */   }
/*     */ 
/*     */   public void setDataSourceLookup(DataSourceLookup dataSourceLookup)
/*     */   {
/* 106 */     this.dataSourceLookup = (dataSourceLookup != null ? dataSourceLookup : new JndiDataSourceLookup());
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 111 */     if (this.targetDataSources == null) {
/* 112 */       throw new IllegalArgumentException("Property 'targetDataSources' is required");
/*     */     }
/* 114 */     this.resolvedDataSources = new HashMap(this.targetDataSources.size());
/* 115 */     for (Map.Entry entry : this.targetDataSources.entrySet()) {
/* 116 */       Object lookupKey = resolveSpecifiedLookupKey(entry.getKey());
/* 117 */       DataSource dataSource = resolveSpecifiedDataSource(entry.getValue());
/* 118 */       this.resolvedDataSources.put(lookupKey, dataSource);
/*     */     }
/* 120 */     if (this.defaultTargetDataSource != null)
/* 121 */       this.resolvedDefaultDataSource = resolveSpecifiedDataSource(this.defaultTargetDataSource);
/*     */   }
/*     */ 
/*     */   protected Object resolveSpecifiedLookupKey(Object lookupKey)
/*     */   {
/* 135 */     return lookupKey;
/*     */   }
/*     */ 
/*     */   protected DataSource resolveSpecifiedDataSource(Object dataSource)
/*     */     throws IllegalArgumentException
/*     */   {
/* 148 */     if ((dataSource instanceof DataSource)) {
/* 149 */       return (DataSource)dataSource;
/*     */     }
/* 151 */     if ((dataSource instanceof String)) {
/* 152 */       return this.dataSourceLookup.getDataSource((String)dataSource);
/*     */     }
/*     */ 
/* 155 */     throw new IllegalArgumentException("Illegal data source value - only [javax.sql.DataSource] and String supported: " + dataSource);
/*     */   }
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws SQLException
/*     */   {
/* 162 */     return determineTargetDataSource().getConnection();
/*     */   }
/*     */ 
/*     */   public Connection getConnection(String username, String password) throws SQLException {
/* 166 */     return determineTargetDataSource().getConnection(username, password);
/*     */   }
/*     */ 
/*     */   public <T> T unwrap(Class<T> iface)
/*     */     throws SQLException
/*     */   {
/* 172 */     if (iface.isInstance(this)) {
/* 173 */       return this;
/*     */     }
/* 175 */     return determineTargetDataSource().unwrap(iface);
/*     */   }
/*     */ 
/*     */   public boolean isWrapperFor(Class<?> iface) throws SQLException
/*     */   {
/* 180 */     return (iface.isInstance(this)) || (determineTargetDataSource().isWrapperFor(iface));
/*     */   }
/*     */ 
/*     */   protected DataSource determineTargetDataSource()
/*     */   {
/* 192 */     Assert.notNull(this.resolvedDataSources, "DataSource router not initialized");
/* 193 */     Object lookupKey = determineCurrentLookupKey();
/* 194 */     DataSource dataSource = (DataSource)this.resolvedDataSources.get(lookupKey);
/* 195 */     if ((dataSource == null) && ((this.lenientFallback) || (lookupKey == null))) {
/* 196 */       dataSource = this.resolvedDefaultDataSource;
/*     */     }
/* 198 */     if (dataSource == null) {
/* 199 */       throw new IllegalStateException("Cannot determine target DataSource for lookup key [" + lookupKey + "]");
/*     */     }
/* 201 */     return dataSource;
/*     */   }
/*     */ 
/*     */   protected abstract Object determineCurrentLookupKey();
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource
 * JD-Core Version:    0.6.1
 */