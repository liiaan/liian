/*    */ package org.springframework.jdbc.support;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ 
/*    */ public class CustomSQLExceptionTranslatorRegistrar
/*    */   implements InitializingBean
/*    */ {
/* 38 */   private final Map<String, SQLExceptionTranslator> translators = new HashMap();
/*    */ 
/*    */   public void setTranslators(Map<String, SQLExceptionTranslator> translators)
/*    */   {
/* 48 */     this.translators.putAll(translators);
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet() {
/* 52 */     for (String dbName : this.translators.keySet())
/* 53 */       CustomSQLExceptionTranslatorRegistry.getInstance().registerTranslator(dbName, (SQLExceptionTranslator)this.translators.get(dbName));
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.CustomSQLExceptionTranslatorRegistrar
 * JD-Core Version:    0.6.1
 */