/*    */ package org.springframework.jdbc.datasource.embedded;
/*    */ 
/*    */ import java.sql.Driver;
/*    */ import org.springframework.util.ClassUtils;
/*    */ 
/*    */ final class H2EmbeddedDatabaseConfigurer extends AbstractEmbeddedDatabaseConfigurer
/*    */ {
/*    */   private static H2EmbeddedDatabaseConfigurer INSTANCE;
/*    */   private final Class<? extends Driver> driverClass;
/*    */ 
/*    */   public static synchronized H2EmbeddedDatabaseConfigurer getInstance()
/*    */     throws ClassNotFoundException
/*    */   {
/* 44 */     if (INSTANCE == null) {
/* 45 */       INSTANCE = new H2EmbeddedDatabaseConfigurer(ClassUtils.forName("org.h2.Driver", H2EmbeddedDatabaseConfigurer.class.getClassLoader()));
/*    */     }
/*    */ 
/* 48 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */   private H2EmbeddedDatabaseConfigurer(Class<? extends Driver> driverClass) {
/* 52 */     this.driverClass = driverClass;
/*    */   }
/*    */ 
/*    */   public void configureConnectionProperties(ConnectionProperties properties, String databaseName) {
/* 56 */     properties.setDriverClass(this.driverClass);
/* 57 */     properties.setUrl(String.format("jdbc:h2:mem:%s;DB_CLOSE_DELAY=-1", new Object[] { databaseName }));
/* 58 */     properties.setUsername("sa");
/* 59 */     properties.setPassword("");
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.embedded.H2EmbeddedDatabaseConfigurer
 * JD-Core Version:    0.6.1
 */