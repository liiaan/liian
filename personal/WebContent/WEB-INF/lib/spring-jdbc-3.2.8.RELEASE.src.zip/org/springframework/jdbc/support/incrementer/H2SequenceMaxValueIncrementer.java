/*    */ package org.springframework.jdbc.support.incrementer;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ public class H2SequenceMaxValueIncrementer extends AbstractSequenceMaxValueIncrementer
/*    */ {
/*    */   public H2SequenceMaxValueIncrementer()
/*    */   {
/*    */   }
/*    */ 
/*    */   public H2SequenceMaxValueIncrementer(DataSource dataSource, String incrementerName)
/*    */   {
/* 43 */     super(dataSource, incrementerName);
/*    */   }
/*    */ 
/*    */   protected String getSequenceQuery()
/*    */   {
/* 49 */     return "select " + getIncrementerName() + ".nextval from dual";
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.incrementer.H2SequenceMaxValueIncrementer
 * JD-Core Version:    0.6.1
 */