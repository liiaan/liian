/*     */ package org.springframework.jdbc.support.nativejdbc;
/*     */ 
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ 
/*     */ public class Jdbc4NativeJdbcExtractor extends NativeJdbcExtractorAdapter
/*     */ {
/*  49 */   private Class<? extends Connection> connectionType = Connection.class;
/*     */ 
/*  51 */   private Class<? extends Statement> statementType = Statement.class;
/*     */ 
/*  53 */   private Class<? extends PreparedStatement> preparedStatementType = PreparedStatement.class;
/*     */ 
/*  55 */   private Class<? extends CallableStatement> callableStatementType = CallableStatement.class;
/*     */ 
/*  57 */   private Class<? extends ResultSet> resultSetType = ResultSet.class;
/*     */ 
/*     */   public void setConnectionType(Class<? extends Connection> connectionType)
/*     */   {
/*  64 */     this.connectionType = connectionType;
/*     */   }
/*     */ 
/*     */   public void setStatementType(Class<? extends Statement> statementType)
/*     */   {
/*  71 */     this.statementType = statementType;
/*     */   }
/*     */ 
/*     */   public void setPreparedStatementType(Class<? extends PreparedStatement> preparedStatementType)
/*     */   {
/*  78 */     this.preparedStatementType = preparedStatementType;
/*     */   }
/*     */ 
/*     */   public void setCallableStatementType(Class<? extends CallableStatement> callableStatementType)
/*     */   {
/*  85 */     this.callableStatementType = callableStatementType;
/*     */   }
/*     */ 
/*     */   public void setResultSetType(Class<? extends ResultSet> resultSetType)
/*     */   {
/*  92 */     this.resultSetType = resultSetType;
/*     */   }
/*     */ 
/*     */   protected Connection doGetNativeConnection(Connection con)
/*     */     throws SQLException
/*     */   {
/*  98 */     return (Connection)con.unwrap(this.connectionType);
/*     */   }
/*     */ 
/*     */   public Statement getNativeStatement(Statement stmt) throws SQLException
/*     */   {
/* 103 */     return (Statement)stmt.unwrap(this.statementType);
/*     */   }
/*     */ 
/*     */   public PreparedStatement getNativePreparedStatement(PreparedStatement ps) throws SQLException
/*     */   {
/* 108 */     return (PreparedStatement)ps.unwrap(this.preparedStatementType);
/*     */   }
/*     */ 
/*     */   public CallableStatement getNativeCallableStatement(CallableStatement cs) throws SQLException
/*     */   {
/* 113 */     return (CallableStatement)cs.unwrap(this.callableStatementType);
/*     */   }
/*     */ 
/*     */   public ResultSet getNativeResultSet(ResultSet rs) throws SQLException
/*     */   {
/* 118 */     return (ResultSet)rs.unwrap(this.resultSetType);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.nativejdbc.Jdbc4NativeJdbcExtractor
 * JD-Core Version:    0.6.1
 */