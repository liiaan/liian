/*     */ package org.springframework.jdbc.core.namedparam;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import org.springframework.jdbc.core.SqlParameterValue;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class MapSqlParameterSource extends AbstractSqlParameterSource
/*     */ {
/*  46 */   private final Map<String, Object> values = new HashMap();
/*     */ 
/*     */   public MapSqlParameterSource()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MapSqlParameterSource(String paramName, Object value)
/*     */   {
/*  65 */     addValue(paramName, value);
/*     */   }
/*     */ 
/*     */   public MapSqlParameterSource(Map<String, ?> values)
/*     */   {
/*  73 */     addValues(values);
/*     */   }
/*     */ 
/*     */   public MapSqlParameterSource addValue(String paramName, Object value)
/*     */   {
/*  85 */     Assert.notNull(paramName, "Parameter name must not be null");
/*  86 */     this.values.put(paramName, value);
/*  87 */     if ((value instanceof SqlParameterValue)) {
/*  88 */       registerSqlType(paramName, ((SqlParameterValue)value).getSqlType());
/*     */     }
/*  90 */     return this;
/*     */   }
/*     */ 
/*     */   public MapSqlParameterSource addValue(String paramName, Object value, int sqlType)
/*     */   {
/* 102 */     Assert.notNull(paramName, "Parameter name must not be null");
/* 103 */     this.values.put(paramName, value);
/* 104 */     registerSqlType(paramName, sqlType);
/* 105 */     return this;
/*     */   }
/*     */ 
/*     */   public MapSqlParameterSource addValue(String paramName, Object value, int sqlType, String typeName)
/*     */   {
/* 118 */     Assert.notNull(paramName, "Parameter name must not be null");
/* 119 */     this.values.put(paramName, value);
/* 120 */     registerSqlType(paramName, sqlType);
/* 121 */     registerTypeName(paramName, typeName);
/* 122 */     return this;
/*     */   }
/*     */ 
/*     */   public MapSqlParameterSource addValues(Map<String, ?> values)
/*     */   {
/* 132 */     if (values != null) {
/* 133 */       for (Map.Entry entry : values.entrySet()) {
/* 134 */         this.values.put(entry.getKey(), entry.getValue());
/* 135 */         if ((entry.getValue() instanceof SqlParameterValue)) {
/* 136 */           SqlParameterValue value = (SqlParameterValue)entry.getValue();
/* 137 */           registerSqlType((String)entry.getKey(), value.getSqlType());
/*     */         }
/*     */       }
/*     */     }
/* 141 */     return this;
/*     */   }
/*     */ 
/*     */   public Map<String, Object> getValues()
/*     */   {
/* 148 */     return Collections.unmodifiableMap(this.values);
/*     */   }
/*     */ 
/*     */   public boolean hasValue(String paramName)
/*     */   {
/* 153 */     return this.values.containsKey(paramName);
/*     */   }
/*     */ 
/*     */   public Object getValue(String paramName) {
/* 157 */     if (!hasValue(paramName)) {
/* 158 */       throw new IllegalArgumentException("No value registered for key '" + paramName + "'");
/*     */     }
/* 160 */     return this.values.get(paramName);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.namedparam.MapSqlParameterSource
 * JD-Core Version:    0.6.1
 */