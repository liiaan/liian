package org.springframework.jdbc.datasource;

import java.sql.Connection;

public abstract interface ConnectionProxy extends Connection
{
  public abstract Connection getTargetConnection();
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.ConnectionProxy
 * JD-Core Version:    0.6.1
 */