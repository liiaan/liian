/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ public class SqlInOutParameter extends SqlOutParameter
/*     */ {
/*     */   public SqlInOutParameter(String name, int sqlType)
/*     */   {
/*  39 */     super(name, sqlType);
/*     */   }
/*     */ 
/*     */   public SqlInOutParameter(String name, int sqlType, int scale)
/*     */   {
/*  50 */     super(name, sqlType, scale);
/*     */   }
/*     */ 
/*     */   public SqlInOutParameter(String name, int sqlType, String typeName)
/*     */   {
/*  60 */     super(name, sqlType, typeName);
/*     */   }
/*     */ 
/*     */   public SqlInOutParameter(String name, int sqlType, String typeName, SqlReturnType sqlReturnType)
/*     */   {
/*  71 */     super(name, sqlType, typeName, sqlReturnType);
/*     */   }
/*     */ 
/*     */   public SqlInOutParameter(String name, int sqlType, ResultSetExtractor rse)
/*     */   {
/*  81 */     super(name, sqlType, rse);
/*     */   }
/*     */ 
/*     */   public SqlInOutParameter(String name, int sqlType, RowCallbackHandler rch)
/*     */   {
/*  91 */     super(name, sqlType, rch);
/*     */   }
/*     */ 
/*     */   public SqlInOutParameter(String name, int sqlType, RowMapper rm)
/*     */   {
/* 101 */     super(name, sqlType, rm);
/*     */   }
/*     */ 
/*     */   public boolean isInputValueProvided()
/*     */   {
/* 110 */     return true;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.SqlInOutParameter
 * JD-Core Version:    0.6.1
 */