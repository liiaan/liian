/*     */ package org.springframework.jdbc.core.support;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.beans.factory.support.BeanDefinitionRegistry;
/*     */ import org.springframework.beans.factory.support.PropertiesBeanDefinitionReader;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.RowCallbackHandler;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class JdbcBeanDefinitionReader
/*     */ {
/*     */   private final PropertiesBeanDefinitionReader propReader;
/*     */   private JdbcTemplate jdbcTemplate;
/*     */ 
/*     */   public JdbcBeanDefinitionReader(BeanDefinitionRegistry beanFactory)
/*     */   {
/*  63 */     this.propReader = new PropertiesBeanDefinitionReader(beanFactory);
/*     */   }
/*     */ 
/*     */   public JdbcBeanDefinitionReader(PropertiesBeanDefinitionReader beanDefinitionReader)
/*     */   {
/*  74 */     Assert.notNull(beanDefinitionReader, "Bean definition reader must not be null");
/*  75 */     this.propReader = beanDefinitionReader;
/*     */   }
/*     */ 
/*     */   public void setDataSource(DataSource dataSource)
/*     */   {
/*  84 */     this.jdbcTemplate = new JdbcTemplate(dataSource);
/*     */   }
/*     */ 
/*     */   public void setJdbcTemplate(JdbcTemplate jdbcTemplate)
/*     */   {
/*  92 */     Assert.notNull(jdbcTemplate, "JdbcTemplate must not be null");
/*  93 */     this.jdbcTemplate = jdbcTemplate;
/*     */   }
/*     */ 
/*     */   public void loadBeanDefinitions(String sql)
/*     */   {
/* 107 */     Assert.notNull(this.jdbcTemplate, "Not fully configured - specify DataSource or JdbcTemplate");
/* 108 */     final Properties props = new Properties();
/* 109 */     this.jdbcTemplate.query(sql, new RowCallbackHandler() {
/*     */       public void processRow(ResultSet rs) throws SQLException {
/* 111 */         String beanName = rs.getString(1);
/* 112 */         String property = rs.getString(2);
/* 113 */         String value = rs.getString(3);
/*     */ 
/* 115 */         props.setProperty(beanName + "." + property, value);
/*     */       }
/*     */     });
/* 118 */     this.propReader.registerBeanDefinitions(props);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.support.JdbcBeanDefinitionReader
 * JD-Core Version:    0.6.1
 */