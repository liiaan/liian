/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ 
/*     */ public class ArgumentTypePreparedStatementSetter
/*     */   implements PreparedStatementSetter, ParameterDisposer
/*     */ {
/*     */   private final Object[] args;
/*     */   private final int[] argTypes;
/*     */ 
/*     */   public ArgumentTypePreparedStatementSetter(Object[] args, int[] argTypes)
/*     */   {
/*  46 */     if (((args != null) && (argTypes == null)) || ((args == null) && (argTypes != null)) || ((args != null) && (args.length != argTypes.length)))
/*     */     {
/*  48 */       throw new InvalidDataAccessApiUsageException("args and argTypes parameters must match");
/*     */     }
/*  50 */     this.args = args;
/*  51 */     this.argTypes = argTypes;
/*     */   }
/*     */ 
/*     */   public void setValues(PreparedStatement ps) throws SQLException
/*     */   {
/*  56 */     int parameterPosition = 1;
/*  57 */     if (this.args != null)
/*  58 */       for (int i = 0; i < this.args.length; i++) {
/*  59 */         Object arg = this.args[i];
/*     */         Iterator i$;
/*  60 */         if (((arg instanceof Collection)) && (this.argTypes[i] != 2003)) {
/*  61 */           Collection entries = (Collection)arg;
/*  62 */           for (i$ = entries.iterator(); i$.hasNext(); ) { Object entry = i$.next();
/*  63 */             if ((entry instanceof Object[])) {
/*  64 */               Object[] valueArray = (Object[])entry;
/*  65 */               for (Object argValue : valueArray) {
/*  66 */                 doSetValue(ps, parameterPosition, this.argTypes[i], argValue);
/*  67 */                 parameterPosition++;
/*     */               }
/*     */             }
/*     */             else {
/*  71 */               doSetValue(ps, parameterPosition, this.argTypes[i], entry);
/*  72 */               parameterPosition++;
/*     */             } }
/*     */         }
/*     */         else
/*     */         {
/*  77 */           doSetValue(ps, parameterPosition, this.argTypes[i], arg);
/*  78 */           parameterPosition++;
/*     */         }
/*     */       }
/*     */   }
/*     */ 
/*     */   protected void doSetValue(PreparedStatement ps, int parameterPosition, int argType, Object argValue)
/*     */     throws SQLException
/*     */   {
/*  96 */     StatementCreatorUtils.setParameterValue(ps, parameterPosition, argType, argValue);
/*     */   }
/*     */ 
/*     */   public void cleanupParameters() {
/* 100 */     StatementCreatorUtils.cleanupParameters(this.args);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.ArgumentTypePreparedStatementSetter
 * JD-Core Version:    0.6.1
 */