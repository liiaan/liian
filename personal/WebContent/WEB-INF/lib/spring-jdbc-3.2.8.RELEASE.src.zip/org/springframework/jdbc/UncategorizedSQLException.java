/*    */ package org.springframework.jdbc;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.dao.UncategorizedDataAccessException;
/*    */ 
/*    */ public class UncategorizedSQLException extends UncategorizedDataAccessException
/*    */ {
/*    */   private final String sql;
/*    */ 
/*    */   public UncategorizedSQLException(String task, String sql, SQLException ex)
/*    */   {
/* 44 */     super(task + "; uncategorized SQLException for SQL [" + sql + "]; SQL state [" + ex.getSQLState() + "]; error code [" + ex.getErrorCode() + "]; " + ex.getMessage(), ex);
/*    */ 
/* 46 */     this.sql = sql;
/*    */   }
/*    */ 
/*    */   public SQLException getSQLException()
/*    */   {
/* 54 */     return (SQLException)getCause();
/*    */   }
/*    */ 
/*    */   public String getSql()
/*    */   {
/* 61 */     return this.sql;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.UncategorizedSQLException
 * JD-Core Version:    0.6.1
 */