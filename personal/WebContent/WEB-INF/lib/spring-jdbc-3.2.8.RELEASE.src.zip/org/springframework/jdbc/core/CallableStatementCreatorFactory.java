/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.jdbc.support.nativejdbc.NativeJdbcExtractor;
/*     */ 
/*     */ public class CallableStatementCreatorFactory
/*     */ {
/*     */   private final String callString;
/*     */   private final List<SqlParameter> declaredParameters;
/*  48 */   private int resultSetType = 1003;
/*     */ 
/*  50 */   private boolean updatableResults = false;
/*     */   private NativeJdbcExtractor nativeJdbcExtractor;
/*     */ 
/*     */   public CallableStatementCreatorFactory(String callString)
/*     */   {
/*  60 */     this.callString = callString;
/*  61 */     this.declaredParameters = new LinkedList();
/*     */   }
/*     */ 
/*     */   public CallableStatementCreatorFactory(String callString, List<SqlParameter> declaredParameters)
/*     */   {
/*  70 */     this.callString = callString;
/*  71 */     this.declaredParameters = declaredParameters;
/*     */   }
/*     */ 
/*     */   public void addParameter(SqlParameter param)
/*     */   {
/*  81 */     this.declaredParameters.add(param);
/*     */   }
/*     */ 
/*     */   public void setResultSetType(int resultSetType)
/*     */   {
/*  93 */     this.resultSetType = resultSetType;
/*     */   }
/*     */ 
/*     */   public void setUpdatableResults(boolean updatableResults)
/*     */   {
/* 100 */     this.updatableResults = updatableResults;
/*     */   }
/*     */ 
/*     */   public void setNativeJdbcExtractor(NativeJdbcExtractor nativeJdbcExtractor)
/*     */   {
/* 107 */     this.nativeJdbcExtractor = nativeJdbcExtractor;
/*     */   }
/*     */ 
/*     */   public CallableStatementCreator newCallableStatementCreator(Map<String, ?> params)
/*     */   {
/* 116 */     return new CallableStatementCreatorImpl(params != null ? params : new HashMap());
/*     */   }
/*     */ 
/*     */   public CallableStatementCreator newCallableStatementCreator(ParameterMapper inParamMapper)
/*     */   {
/* 124 */     return new CallableStatementCreatorImpl(inParamMapper);
/*     */   }
/*     */ 
/*     */   private class CallableStatementCreatorImpl
/*     */     implements CallableStatementCreator, SqlProvider, ParameterDisposer
/*     */   {
/*     */     private ParameterMapper inParameterMapper;
/*     */     private Map<String, ?> inParameters;
/*     */ 
/*     */     public CallableStatementCreatorImpl(ParameterMapper inParamMapper)
/*     */     {
/* 142 */       this.inParameterMapper = inParamMapper;
/*     */     }
/*     */ 
/*     */     public CallableStatementCreatorImpl()
/*     */     {
/* 150 */       this.inParameters = inParams;
/*     */     }
/*     */ 
/*     */     public CallableStatement createCallableStatement(Connection con) throws SQLException
/*     */     {
/* 155 */       if (this.inParameterMapper != null) {
/* 156 */         this.inParameters = this.inParameterMapper.createMap(con);
/*     */       }
/* 159 */       else if (this.inParameters == null) {
/* 160 */         throw new InvalidDataAccessApiUsageException("A ParameterMapper or a Map of parameters must be provided");
/*     */       }
/*     */ 
/* 165 */       CallableStatement cs = null;
/* 166 */       if ((CallableStatementCreatorFactory.this.resultSetType == 1003) && (!CallableStatementCreatorFactory.this.updatableResults)) {
/* 167 */         cs = con.prepareCall(CallableStatementCreatorFactory.this.callString);
/*     */       }
/*     */       else {
/* 170 */         cs = con.prepareCall(CallableStatementCreatorFactory.this.callString, CallableStatementCreatorFactory.this.resultSetType, CallableStatementCreatorFactory.this.updatableResults ? 1008 : 1007);
/*     */       }
/*     */ 
/* 175 */       CallableStatement csToUse = cs;
/* 176 */       if (CallableStatementCreatorFactory.this.nativeJdbcExtractor != null) {
/* 177 */         csToUse = CallableStatementCreatorFactory.this.nativeJdbcExtractor.getNativeCallableStatement(cs);
/*     */       }
/*     */ 
/* 180 */       int sqlColIndx = 1;
/* 181 */       for (SqlParameter declaredParam : CallableStatementCreatorFactory.this.declaredParameters) {
/* 182 */         if (!declaredParam.isResultsParameter())
/*     */         {
/* 185 */           Object inValue = this.inParameters.get(declaredParam.getName());
/* 186 */           if ((declaredParam instanceof ResultSetSupportingSqlParameter))
/*     */           {
/* 189 */             if ((declaredParam instanceof SqlOutParameter)) {
/* 190 */               if (declaredParam.getTypeName() != null) {
/* 191 */                 cs.registerOutParameter(sqlColIndx, declaredParam.getSqlType(), declaredParam.getTypeName());
/*     */               }
/* 194 */               else if (declaredParam.getScale() != null) {
/* 195 */                 cs.registerOutParameter(sqlColIndx, declaredParam.getSqlType(), declaredParam.getScale().intValue());
/*     */               }
/*     */               else {
/* 198 */                 cs.registerOutParameter(sqlColIndx, declaredParam.getSqlType());
/*     */               }
/*     */ 
/* 201 */               if (declaredParam.isInputValueProvided()) {
/* 202 */                 StatementCreatorUtils.setParameterValue(csToUse, sqlColIndx, declaredParam, inValue);
/*     */               }
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 208 */             if (!this.inParameters.containsKey(declaredParam.getName())) {
/* 209 */               throw new InvalidDataAccessApiUsageException("Required input parameter '" + declaredParam.getName() + "' is missing");
/*     */             }
/*     */ 
/* 212 */             StatementCreatorUtils.setParameterValue(csToUse, sqlColIndx, declaredParam, inValue);
/*     */           }
/* 214 */           sqlColIndx++;
/*     */         }
/*     */       }
/*     */ 
/* 218 */       return cs;
/*     */     }
/*     */ 
/*     */     public String getSql() {
/* 222 */       return CallableStatementCreatorFactory.this.callString;
/*     */     }
/*     */ 
/*     */     public void cleanupParameters() {
/* 226 */       if (this.inParameters != null)
/* 227 */         StatementCreatorUtils.cleanupParameters(this.inParameters.values());
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 233 */       StringBuilder sb = new StringBuilder();
/* 234 */       sb.append("CallableStatementCreatorFactory.CallableStatementCreatorImpl: sql=[");
/* 235 */       sb.append(CallableStatementCreatorFactory.this.callString).append("]; parameters=").append(this.inParameters);
/* 236 */       return sb.toString();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.CallableStatementCreatorFactory
 * JD-Core Version:    0.6.1
 */