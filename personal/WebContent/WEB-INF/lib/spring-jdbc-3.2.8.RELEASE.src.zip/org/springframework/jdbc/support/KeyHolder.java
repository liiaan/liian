package org.springframework.jdbc.support;

import java.util.List;
import java.util.Map;
import org.springframework.dao.InvalidDataAccessApiUsageException;

public abstract interface KeyHolder
{
  public abstract Number getKey()
    throws InvalidDataAccessApiUsageException;

  public abstract Map<String, Object> getKeys()
    throws InvalidDataAccessApiUsageException;

  public abstract List<Map<String, Object>> getKeyList();
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.KeyHolder
 * JD-Core Version:    0.6.1
 */