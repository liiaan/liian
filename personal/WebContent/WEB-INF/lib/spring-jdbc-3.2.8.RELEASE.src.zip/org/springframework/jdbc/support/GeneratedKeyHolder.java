/*    */ package org.springframework.jdbc.support;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedList;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import org.springframework.dao.DataRetrievalFailureException;
/*    */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*    */ 
/*    */ public class GeneratedKeyHolder
/*    */   implements KeyHolder
/*    */ {
/*    */   private final List<Map<String, Object>> keyList;
/*    */ 
/*    */   public GeneratedKeyHolder()
/*    */   {
/* 48 */     this.keyList = new LinkedList();
/*    */   }
/*    */ 
/*    */   public GeneratedKeyHolder(List<Map<String, Object>> keyList)
/*    */   {
/* 56 */     this.keyList = keyList;
/*    */   }
/*    */ 
/*    */   public Number getKey() throws InvalidDataAccessApiUsageException, DataRetrievalFailureException
/*    */   {
/* 61 */     if (this.keyList.size() == 0) {
/* 62 */       return null;
/*    */     }
/* 64 */     if ((this.keyList.size() > 1) || (((Map)this.keyList.get(0)).size() > 1)) {
/* 65 */       throw new InvalidDataAccessApiUsageException("The getKey method should only be used when a single key is returned.  The current key entry contains multiple keys: " + this.keyList);
/*    */     }
/*    */ 
/* 69 */     Iterator keyIter = ((Map)this.keyList.get(0)).values().iterator();
/* 70 */     if (keyIter.hasNext()) {
/* 71 */       Object key = keyIter.next();
/* 72 */       if (!(key instanceof Number)) {
/* 73 */         throw new DataRetrievalFailureException("The generated key is not of a supported numeric type. Unable to cast [" + (key != null ? key.getClass().getName() : null) + "] to [" + Number.class.getName() + "]");
/*    */       }
/*    */ 
/* 78 */       return (Number)key;
/*    */     }
/*    */ 
/* 81 */     throw new DataRetrievalFailureException("Unable to retrieve the generated key. Check that the table has an identity column enabled.");
/*    */   }
/*    */ 
/*    */   public Map<String, Object> getKeys()
/*    */     throws InvalidDataAccessApiUsageException
/*    */   {
/* 87 */     if (this.keyList.size() == 0) {
/* 88 */       return null;
/*    */     }
/* 90 */     if (this.keyList.size() > 1) {
/* 91 */       throw new InvalidDataAccessApiUsageException("The getKeys method should only be used when keys for a single row are returned.  The current key list contains keys for multiple rows: " + this.keyList);
/*    */     }
/*    */ 
/* 94 */     return (Map)this.keyList.get(0);
/*    */   }
/*    */ 
/*    */   public List<Map<String, Object>> getKeyList() {
/* 98 */     return this.keyList;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.GeneratedKeyHolder
 * JD-Core Version:    0.6.1
 */