/*    */ package org.springframework.jdbc.datasource.lookup;
/*    */ 
/*    */ import javax.naming.NamingException;
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.jndi.JndiLocatorSupport;
/*    */ 
/*    */ public class JndiDataSourceLookup extends JndiLocatorSupport
/*    */   implements DataSourceLookup
/*    */ {
/*    */   public JndiDataSourceLookup()
/*    */   {
/* 39 */     setResourceRef(true);
/*    */   }
/*    */ 
/*    */   public DataSource getDataSource(String dataSourceName) throws DataSourceLookupFailureException {
/*    */     try {
/* 44 */       return (DataSource)lookup(dataSourceName, DataSource.class);
/*    */     }
/*    */     catch (NamingException ex) {
/* 47 */       throw new DataSourceLookupFailureException("Failed to look up JNDI DataSource with name '" + dataSourceName + "'", ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup
 * JD-Core Version:    0.6.1
 */