/*     */ package org.springframework.jdbc.object;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.jdbc.core.CallableStatementCreator;
/*     */ import org.springframework.jdbc.core.CallableStatementCreatorFactory;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.ParameterMapper;
/*     */ import org.springframework.jdbc.core.SqlParameter;
/*     */ 
/*     */ public abstract class SqlCall extends RdbmsOperation
/*     */ {
/*     */   private CallableStatementCreatorFactory callableStatementFactory;
/*  51 */   private boolean function = false;
/*     */ 
/*  57 */   private boolean sqlReadyForUse = false;
/*     */   private String callString;
/*     */ 
/*     */   public SqlCall()
/*     */   {
/*     */   }
/*     */ 
/*     */   public SqlCall(DataSource ds, String sql)
/*     */   {
/*  86 */     setDataSource(ds);
/*  87 */     setSql(sql);
/*     */   }
/*     */ 
/*     */   public void setFunction(boolean function)
/*     */   {
/*  95 */     this.function = function;
/*     */   }
/*     */ 
/*     */   public boolean isFunction()
/*     */   {
/* 102 */     return this.function;
/*     */   }
/*     */ 
/*     */   public void setSqlReadyForUse(boolean sqlReadyForUse)
/*     */   {
/* 109 */     this.sqlReadyForUse = sqlReadyForUse;
/*     */   }
/*     */ 
/*     */   public boolean isSqlReadyForUse()
/*     */   {
/* 116 */     return this.sqlReadyForUse;
/*     */   }
/*     */ 
/*     */   protected final void compileInternal()
/*     */   {
/* 127 */     if (isSqlReadyForUse()) {
/* 128 */       this.callString = getSql();
/*     */     }
/*     */     else {
/* 131 */       List parameters = getDeclaredParameters();
/* 132 */       int parameterCount = 0;
/* 133 */       if (isFunction()) {
/* 134 */         this.callString = ("{? = call " + getSql() + "(");
/* 135 */         parameterCount = -1;
/*     */       }
/*     */       else {
/* 138 */         this.callString = ("{call " + getSql() + "(");
/*     */       }
/* 140 */       for (SqlParameter parameter : parameters) {
/* 141 */         if (!parameter.isResultsParameter()) {
/* 142 */           if (parameterCount > 0) {
/* 143 */             this.callString += ", ";
/*     */           }
/* 145 */           if (parameterCount >= 0) {
/* 146 */             this.callString += "?";
/*     */           }
/* 148 */           parameterCount++;
/*     */         }
/*     */       }
/* 151 */       this.callString += ")}";
/*     */     }
/* 153 */     if (this.logger.isDebugEnabled()) {
/* 154 */       this.logger.debug("Compiled stored procedure. Call string is [" + getCallString() + "]");
/*     */     }
/*     */ 
/* 157 */     this.callableStatementFactory = new CallableStatementCreatorFactory(getCallString(), getDeclaredParameters());
/* 158 */     this.callableStatementFactory.setResultSetType(getResultSetType());
/* 159 */     this.callableStatementFactory.setUpdatableResults(isUpdatableResults());
/* 160 */     this.callableStatementFactory.setNativeJdbcExtractor(getJdbcTemplate().getNativeJdbcExtractor());
/*     */ 
/* 162 */     onCompileInternal();
/*     */   }
/*     */ 
/*     */   protected void onCompileInternal()
/*     */   {
/*     */   }
/*     */ 
/*     */   public String getCallString()
/*     */   {
/* 176 */     return this.callString;
/*     */   }
/*     */ 
/*     */   protected CallableStatementCreator newCallableStatementCreator(Map<String, ?> inParams)
/*     */   {
/* 185 */     return this.callableStatementFactory.newCallableStatementCreator(inParams);
/*     */   }
/*     */ 
/*     */   protected CallableStatementCreator newCallableStatementCreator(ParameterMapper inParamMapper)
/*     */   {
/* 194 */     return this.callableStatementFactory.newCallableStatementCreator(inParamMapper);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.object.SqlCall
 * JD-Core Version:    0.6.1
 */