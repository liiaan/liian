/*    */ package org.springframework.jdbc.core.metadata;
/*    */ 
/*    */ import java.sql.DatabaseMetaData;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ public class HsqlTableMetaDataProvider extends GenericTableMetaDataProvider
/*    */ {
/*    */   public HsqlTableMetaDataProvider(DatabaseMetaData databaseMetaData)
/*    */     throws SQLException
/*    */   {
/* 32 */     super(databaseMetaData);
/*    */   }
/*    */ 
/*    */   public boolean isGetGeneratedKeysSimulated()
/*    */   {
/* 37 */     return true;
/*    */   }
/*    */ 
/*    */   public String getSimpleQueryForGetGeneratedKey(String tableName, String keyColumnName)
/*    */   {
/* 42 */     return "select max(identity()) from " + tableName;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.HsqlTableMetaDataProvider
 * JD-Core Version:    0.6.1
 */