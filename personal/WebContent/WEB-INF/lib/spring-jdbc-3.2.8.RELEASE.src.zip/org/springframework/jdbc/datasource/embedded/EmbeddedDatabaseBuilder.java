/*     */ package org.springframework.jdbc.datasource.embedded;
/*     */ 
/*     */ import org.springframework.core.io.DefaultResourceLoader;
/*     */ import org.springframework.core.io.ResourceLoader;
/*     */ import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
/*     */ 
/*     */ public class EmbeddedDatabaseBuilder
/*     */ {
/*     */   private final EmbeddedDatabaseFactory databaseFactory;
/*     */   private final ResourceDatabasePopulator databasePopulator;
/*     */   private final ResourceLoader resourceLoader;
/*     */ 
/*     */   public EmbeddedDatabaseBuilder()
/*     */   {
/*  52 */     this(new DefaultResourceLoader());
/*     */   }
/*     */ 
/*     */   public EmbeddedDatabaseBuilder(ResourceLoader resourceLoader)
/*     */   {
/*  60 */     this.databaseFactory = new EmbeddedDatabaseFactory();
/*  61 */     this.databasePopulator = new ResourceDatabasePopulator();
/*  62 */     this.databaseFactory.setDatabasePopulator(this.databasePopulator);
/*  63 */     this.resourceLoader = resourceLoader;
/*     */   }
/*     */ 
/*     */   public EmbeddedDatabaseBuilder setName(String databaseName)
/*     */   {
/*  74 */     this.databaseFactory.setDatabaseName(databaseName);
/*  75 */     return this;
/*     */   }
/*     */ 
/*     */   public EmbeddedDatabaseBuilder setType(EmbeddedDatabaseType databaseType)
/*     */   {
/*  85 */     this.databaseFactory.setDatabaseType(databaseType);
/*  86 */     return this;
/*     */   }
/*     */ 
/*     */   public EmbeddedDatabaseBuilder addScript(String sqlResource)
/*     */   {
/*  95 */     this.databasePopulator.addScript(this.resourceLoader.getResource(sqlResource));
/*  96 */     return this;
/*     */   }
/*     */ 
/*     */   public EmbeddedDatabaseBuilder addDefaultScripts()
/*     */   {
/* 106 */     addScript("schema.sql");
/* 107 */     addScript("data.sql");
/* 108 */     return this;
/*     */   }
/*     */ 
/*     */   public EmbeddedDatabase build()
/*     */   {
/* 116 */     return this.databaseFactory.getDatabase();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder
 * JD-Core Version:    0.6.1
 */