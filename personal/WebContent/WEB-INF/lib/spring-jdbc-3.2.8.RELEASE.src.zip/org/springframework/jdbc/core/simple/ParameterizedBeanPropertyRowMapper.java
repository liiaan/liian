/*    */ package org.springframework.jdbc.core.simple;
/*    */ 
/*    */ import org.springframework.jdbc.core.BeanPropertyRowMapper;
/*    */ 
/*    */ public class ParameterizedBeanPropertyRowMapper<T> extends BeanPropertyRowMapper<T>
/*    */   implements ParameterizedRowMapper<T>
/*    */ {
/*    */   public static <T> ParameterizedBeanPropertyRowMapper<T> newInstance(Class<T> mappedClass)
/*    */   {
/* 62 */     ParameterizedBeanPropertyRowMapper newInstance = new ParameterizedBeanPropertyRowMapper();
/* 63 */     newInstance.setMappedClass(mappedClass);
/* 64 */     return newInstance;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.simple.ParameterizedBeanPropertyRowMapper
 * JD-Core Version:    0.6.1
 */