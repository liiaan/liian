/*    */ package org.springframework.jdbc.datasource.init;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ 
/*    */ public class CompositeDatabasePopulator
/*    */   implements DatabasePopulator
/*    */ {
/* 34 */   private List<DatabasePopulator> populators = new ArrayList();
/*    */ 
/*    */   public void setPopulators(DatabasePopulator[] populators)
/*    */   {
/* 41 */     this.populators.clear();
/* 42 */     this.populators.addAll(Arrays.asList(populators));
/*    */   }
/*    */ 
/*    */   public void addPopulators(DatabasePopulator[] populators)
/*    */   {
/* 49 */     this.populators.addAll(Arrays.asList(populators));
/*    */   }
/*    */ 
/*    */   public void populate(Connection connection) throws SQLException
/*    */   {
/* 54 */     for (DatabasePopulator populator : this.populators)
/* 55 */       populator.populate(connection);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.init.CompositeDatabasePopulator
 * JD-Core Version:    0.6.1
 */