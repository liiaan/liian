/*     */ package org.springframework.jdbc.support.lob;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.lang.reflect.Field;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.jdbc.support.nativejdbc.NativeJdbcExtractor;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ 
/*     */ @Deprecated
/*     */ public class OracleLobHandler extends AbstractLobHandler
/*     */ {
/*     */   private static final String BLOB_CLASS_NAME = "oracle.sql.BLOB";
/*     */   private static final String CLOB_CLASS_NAME = "oracle.sql.CLOB";
/*     */   private static final String DURATION_SESSION_FIELD_NAME = "DURATION_SESSION";
/*     */   private static final String MODE_READWRITE_FIELD_NAME = "MODE_READWRITE";
/*     */   private static final String MODE_READONLY_FIELD_NAME = "MODE_READONLY";
/*     */   protected final Log logger;
/*     */   private NativeJdbcExtractor nativeJdbcExtractor;
/*     */   private Boolean cache;
/*     */   private Boolean releaseResourcesAfterRead;
/*     */   private Class blobClass;
/*     */   private Class clobClass;
/*     */   private final Map<Class, Integer> durationSessionConstants;
/*     */   private final Map<Class, Integer> modeReadWriteConstants;
/*     */   private final Map<Class, Integer> modeReadOnlyConstants;
/*     */ 
/*     */   public OracleLobHandler()
/*     */   {
/* 106 */     this.logger = LogFactory.getLog(getClass());
/*     */ 
/* 110 */     this.cache = Boolean.TRUE;
/*     */ 
/* 112 */     this.releaseResourcesAfterRead = Boolean.FALSE;
/*     */ 
/* 118 */     this.durationSessionConstants = new HashMap(2);
/*     */ 
/* 120 */     this.modeReadWriteConstants = new HashMap(2);
/*     */ 
/* 122 */     this.modeReadOnlyConstants = new HashMap(2);
/*     */   }
/*     */ 
/*     */   public void setNativeJdbcExtractor(NativeJdbcExtractor nativeJdbcExtractor)
/*     */   {
/* 144 */     this.nativeJdbcExtractor = nativeJdbcExtractor;
/*     */   }
/*     */ 
/*     */   public void setCache(boolean cache)
/*     */   {
/* 158 */     this.cache = Boolean.valueOf(cache);
/*     */   }
/*     */ 
/*     */   public void setReleaseResourcesAfterRead(boolean releaseResources)
/*     */   {
/* 180 */     this.releaseResourcesAfterRead = Boolean.valueOf(releaseResources);
/*     */   }
/*     */ 
/*     */   protected synchronized void initOracleDriverClasses(Connection con)
/*     */   {
/* 201 */     if (this.blobClass == null)
/*     */       try
/*     */       {
/* 204 */         this.blobClass = con.getClass().getClassLoader().loadClass("oracle.sql.BLOB");
/* 205 */         this.durationSessionConstants.put(this.blobClass, Integer.valueOf(this.blobClass.getField("DURATION_SESSION").getInt(null)));
/*     */ 
/* 207 */         this.modeReadWriteConstants.put(this.blobClass, Integer.valueOf(this.blobClass.getField("MODE_READWRITE").getInt(null)));
/*     */ 
/* 209 */         this.modeReadOnlyConstants.put(this.blobClass, Integer.valueOf(this.blobClass.getField("MODE_READONLY").getInt(null)));
/*     */ 
/* 213 */         this.clobClass = con.getClass().getClassLoader().loadClass("oracle.sql.CLOB");
/* 214 */         this.durationSessionConstants.put(this.clobClass, Integer.valueOf(this.clobClass.getField("DURATION_SESSION").getInt(null)));
/*     */ 
/* 216 */         this.modeReadWriteConstants.put(this.clobClass, Integer.valueOf(this.clobClass.getField("MODE_READWRITE").getInt(null)));
/*     */ 
/* 218 */         this.modeReadOnlyConstants.put(this.clobClass, Integer.valueOf(this.clobClass.getField("MODE_READONLY").getInt(null)));
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 222 */         throw new InvalidDataAccessApiUsageException("Couldn't initialize OracleLobHandler because Oracle driver classes are not available. Note that OracleLobHandler requires Oracle JDBC driver 9i or higher!", ex);
/*     */       }
/*     */   }
/*     */ 
/*     */   public byte[] getBlobAsBytes(ResultSet rs, int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 231 */     this.logger.debug("Returning Oracle BLOB as bytes");
/* 232 */     Blob blob = rs.getBlob(columnIndex);
/* 233 */     initializeResourcesBeforeRead(rs.getStatement().getConnection(), blob);
/* 234 */     byte[] retVal = blob != null ? blob.getBytes(1L, (int)blob.length()) : null;
/* 235 */     releaseResourcesAfterRead(rs.getStatement().getConnection(), blob);
/* 236 */     return retVal;
/*     */   }
/*     */ 
/*     */   public InputStream getBlobAsBinaryStream(ResultSet rs, int columnIndex) throws SQLException {
/* 240 */     this.logger.debug("Returning Oracle BLOB as binary stream");
/* 241 */     Blob blob = rs.getBlob(columnIndex);
/* 242 */     initializeResourcesBeforeRead(rs.getStatement().getConnection(), blob);
/* 243 */     InputStream retVal = blob != null ? blob.getBinaryStream() : null;
/* 244 */     releaseResourcesAfterRead(rs.getStatement().getConnection(), blob);
/* 245 */     return retVal;
/*     */   }
/*     */ 
/*     */   public String getClobAsString(ResultSet rs, int columnIndex) throws SQLException {
/* 249 */     this.logger.debug("Returning Oracle CLOB as string");
/* 250 */     Clob clob = rs.getClob(columnIndex);
/* 251 */     initializeResourcesBeforeRead(rs.getStatement().getConnection(), clob);
/* 252 */     String retVal = clob != null ? clob.getSubString(1L, (int)clob.length()) : null;
/* 253 */     releaseResourcesAfterRead(rs.getStatement().getConnection(), clob);
/* 254 */     return retVal;
/*     */   }
/*     */ 
/*     */   public InputStream getClobAsAsciiStream(ResultSet rs, int columnIndex) throws SQLException {
/* 258 */     this.logger.debug("Returning Oracle CLOB as ASCII stream");
/* 259 */     Clob clob = rs.getClob(columnIndex);
/* 260 */     initializeResourcesBeforeRead(rs.getStatement().getConnection(), clob);
/* 261 */     InputStream retVal = clob != null ? clob.getAsciiStream() : null;
/* 262 */     releaseResourcesAfterRead(rs.getStatement().getConnection(), clob);
/* 263 */     return retVal;
/*     */   }
/*     */ 
/*     */   public Reader getClobAsCharacterStream(ResultSet rs, int columnIndex) throws SQLException {
/* 267 */     this.logger.debug("Returning Oracle CLOB as character stream");
/* 268 */     Clob clob = rs.getClob(columnIndex);
/* 269 */     initializeResourcesBeforeRead(rs.getStatement().getConnection(), clob);
/* 270 */     Reader retVal = clob != null ? clob.getCharacterStream() : null;
/* 271 */     releaseResourcesAfterRead(rs.getStatement().getConnection(), clob);
/* 272 */     return retVal;
/*     */   }
/*     */ 
/*     */   public LobCreator getLobCreator() {
/* 276 */     return new OracleLobCreator();
/*     */   }
/*     */ 
/*     */   protected void initializeResourcesBeforeRead(Connection con, Object lob)
/*     */   {
/* 289 */     if (this.releaseResourcesAfterRead.booleanValue()) {
/* 290 */       initOracleDriverClasses(con);
/*     */       try
/*     */       {
/* 295 */         Method isTemporary = lob.getClass().getMethod("isTemporary", new Class[0]);
/* 296 */         Boolean temporary = (Boolean)isTemporary.invoke(lob, new Object[0]);
/* 297 */         if (!temporary.booleanValue())
/*     */         {
/* 301 */           Method open = lob.getClass().getMethod("open", new Class[] { Integer.TYPE });
/* 302 */           open.invoke(lob, new Object[] { this.modeReadOnlyConstants.get(lob.getClass()) });
/*     */         }
/*     */       }
/*     */       catch (InvocationTargetException ex) {
/* 306 */         this.logger.error("Could not open Oracle LOB", ex.getTargetException());
/*     */       }
/*     */       catch (Exception ex) {
/* 309 */         throw new DataAccessResourceFailureException("Could not open Oracle LOB", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void releaseResourcesAfterRead(Connection con, Object lob)
/*     */   {
/* 327 */     if (this.releaseResourcesAfterRead.booleanValue()) {
/* 328 */       initOracleDriverClasses(con);
/* 329 */       Boolean temporary = Boolean.FALSE;
/*     */       try
/*     */       {
/* 334 */         Method isTemporary = lob.getClass().getMethod("isTemporary", new Class[0]);
/* 335 */         temporary = (Boolean)isTemporary.invoke(lob, new Object[0]);
/* 336 */         if (temporary.booleanValue())
/*     */         {
/* 340 */           Method freeTemporary = lob.getClass().getMethod("freeTemporary", new Class[0]);
/* 341 */           freeTemporary.invoke(lob, new Object[0]);
/*     */         }
/*     */         else
/*     */         {
/* 347 */           Method isOpen = lob.getClass().getMethod("isOpen", new Class[0]);
/* 348 */           Boolean open = (Boolean)isOpen.invoke(lob, new Object[0]);
/* 349 */           if (open.booleanValue())
/*     */           {
/* 353 */             Method close = lob.getClass().getMethod("close", new Class[0]);
/* 354 */             close.invoke(lob, new Object[0]);
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (InvocationTargetException ex) {
/* 359 */         if (temporary.booleanValue()) {
/* 360 */           this.logger.error("Could not free Oracle LOB", ex.getTargetException());
/*     */         }
/*     */         else
/* 363 */           this.logger.error("Could not close Oracle LOB", ex.getTargetException());
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 367 */         if (temporary.booleanValue()) {
/* 368 */           throw new DataAccessResourceFailureException("Could not free Oracle LOB", ex);
/*     */         }
/*     */ 
/* 371 */         throw new DataAccessResourceFailureException("Could not close Oracle LOB", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static abstract interface LobCallback
/*     */   {
/*     */     public abstract void populateLob(Object paramObject)
/*     */       throws Exception;
/*     */   }
/*     */ 
/*     */   protected class OracleLobCreator
/*     */     implements LobCreator
/*     */   {
/* 385 */     private final List<Object> temporaryLobs = new LinkedList();
/*     */ 
/*     */     protected OracleLobCreator() {
/*     */     }
/*     */     public void setBlobAsBytes(PreparedStatement ps, int paramIndex, final byte[] content) throws SQLException {
/* 390 */       if (content != null) {
/* 391 */         Blob blob = (Blob)createLob(ps, false, new OracleLobHandler.LobCallback() {
/*     */           public void populateLob(Object lob) throws Exception {
/* 393 */             Method methodToInvoke = lob.getClass().getMethod("getBinaryOutputStream", new Class[0]);
/* 394 */             OutputStream out = (OutputStream)methodToInvoke.invoke(lob, new Object[0]);
/* 395 */             FileCopyUtils.copy(content, out);
/*     */           }
/*     */         });
/* 398 */         ps.setBlob(paramIndex, blob);
/* 399 */         if (OracleLobHandler.this.logger.isDebugEnabled())
/* 400 */           OracleLobHandler.this.logger.debug("Set bytes for Oracle BLOB with length " + blob.length());
/*     */       }
/*     */       else
/*     */       {
/* 404 */         ps.setBlob(paramIndex, (Blob)null);
/* 405 */         OracleLobHandler.this.logger.debug("Set Oracle BLOB to null");
/*     */       }
/*     */     }
/*     */ 
/*     */     public void setBlobAsBinaryStream(PreparedStatement ps, int paramIndex, final InputStream binaryStream, int contentLength)
/*     */       throws SQLException
/*     */     {
/* 413 */       if (binaryStream != null) {
/* 414 */         Blob blob = (Blob)createLob(ps, false, new OracleLobHandler.LobCallback() {
/*     */           public void populateLob(Object lob) throws Exception {
/* 416 */             Method methodToInvoke = lob.getClass().getMethod("getBinaryOutputStream", (Class[])null);
/* 417 */             OutputStream out = (OutputStream)methodToInvoke.invoke(lob, (Object[])null);
/* 418 */             FileCopyUtils.copy(binaryStream, out);
/*     */           }
/*     */         });
/* 421 */         ps.setBlob(paramIndex, blob);
/* 422 */         if (OracleLobHandler.this.logger.isDebugEnabled())
/* 423 */           OracleLobHandler.this.logger.debug("Set binary stream for Oracle BLOB with length " + blob.length());
/*     */       }
/*     */       else
/*     */       {
/* 427 */         ps.setBlob(paramIndex, (Blob)null);
/* 428 */         OracleLobHandler.this.logger.debug("Set Oracle BLOB to null");
/*     */       }
/*     */     }
/*     */ 
/*     */     public void setClobAsString(PreparedStatement ps, int paramIndex, final String content)
/*     */       throws SQLException
/*     */     {
/* 435 */       if (content != null) {
/* 436 */         Clob clob = (Clob)createLob(ps, true, new OracleLobHandler.LobCallback() {
/*     */           public void populateLob(Object lob) throws Exception {
/* 438 */             Method methodToInvoke = lob.getClass().getMethod("getCharacterOutputStream", (Class[])null);
/* 439 */             Writer writer = (Writer)methodToInvoke.invoke(lob, (Object[])null);
/* 440 */             FileCopyUtils.copy(content, writer);
/*     */           }
/*     */         });
/* 443 */         ps.setClob(paramIndex, clob);
/* 444 */         if (OracleLobHandler.this.logger.isDebugEnabled())
/* 445 */           OracleLobHandler.this.logger.debug("Set string for Oracle CLOB with length " + clob.length());
/*     */       }
/*     */       else
/*     */       {
/* 449 */         ps.setClob(paramIndex, (Clob)null);
/* 450 */         OracleLobHandler.this.logger.debug("Set Oracle CLOB to null");
/*     */       }
/*     */     }
/*     */ 
/*     */     public void setClobAsAsciiStream(PreparedStatement ps, int paramIndex, final InputStream asciiStream, int contentLength)
/*     */       throws SQLException
/*     */     {
/* 458 */       if (asciiStream != null) {
/* 459 */         Clob clob = (Clob)createLob(ps, true, new OracleLobHandler.LobCallback() {
/*     */           public void populateLob(Object lob) throws Exception {
/* 461 */             Method methodToInvoke = lob.getClass().getMethod("getAsciiOutputStream", (Class[])null);
/* 462 */             OutputStream out = (OutputStream)methodToInvoke.invoke(lob, (Object[])null);
/* 463 */             FileCopyUtils.copy(asciiStream, out);
/*     */           }
/*     */         });
/* 466 */         ps.setClob(paramIndex, clob);
/* 467 */         if (OracleLobHandler.this.logger.isDebugEnabled())
/* 468 */           OracleLobHandler.this.logger.debug("Set ASCII stream for Oracle CLOB with length " + clob.length());
/*     */       }
/*     */       else
/*     */       {
/* 472 */         ps.setClob(paramIndex, (Clob)null);
/* 473 */         OracleLobHandler.this.logger.debug("Set Oracle CLOB to null");
/*     */       }
/*     */     }
/*     */ 
/*     */     public void setClobAsCharacterStream(PreparedStatement ps, int paramIndex, final Reader characterStream, int contentLength)
/*     */       throws SQLException
/*     */     {
/* 481 */       if (characterStream != null) {
/* 482 */         Clob clob = (Clob)createLob(ps, true, new OracleLobHandler.LobCallback() {
/*     */           public void populateLob(Object lob) throws Exception {
/* 484 */             Method methodToInvoke = lob.getClass().getMethod("getCharacterOutputStream", (Class[])null);
/* 485 */             Writer writer = (Writer)methodToInvoke.invoke(lob, (Object[])null);
/* 486 */             FileCopyUtils.copy(characterStream, writer);
/*     */           }
/*     */         });
/* 489 */         ps.setClob(paramIndex, clob);
/* 490 */         if (OracleLobHandler.this.logger.isDebugEnabled())
/* 491 */           OracleLobHandler.this.logger.debug("Set character stream for Oracle CLOB with length " + clob.length());
/*     */       }
/*     */       else
/*     */       {
/* 495 */         ps.setClob(paramIndex, (Clob)null);
/* 496 */         OracleLobHandler.this.logger.debug("Set Oracle CLOB to null");
/*     */       }
/*     */     }
/*     */ 
/*     */     protected Object createLob(PreparedStatement ps, boolean clob, OracleLobHandler.LobCallback callback)
/*     */       throws SQLException
/*     */     {
/* 507 */       Connection con = null;
/*     */       try {
/* 509 */         con = getOracleConnection(ps);
/* 510 */         OracleLobHandler.this.initOracleDriverClasses(con);
/* 511 */         Object lob = prepareLob(con, clob ? OracleLobHandler.this.clobClass : OracleLobHandler.this.blobClass);
/* 512 */         callback.populateLob(lob);
/* 513 */         lob.getClass().getMethod("close", (Class[])null).invoke(lob, (Object[])null);
/* 514 */         this.temporaryLobs.add(lob);
/* 515 */         if (OracleLobHandler.this.logger.isDebugEnabled()) {
/* 516 */           OracleLobHandler.this.logger.debug("Created new Oracle " + (clob ? "CLOB" : "BLOB"));
/*     */         }
/* 518 */         return lob;
/*     */       }
/*     */       catch (SQLException ex) {
/* 521 */         throw ex;
/*     */       }
/*     */       catch (InvocationTargetException ex) {
/* 524 */         if ((ex.getTargetException() instanceof SQLException)) {
/* 525 */           throw ((SQLException)ex.getTargetException());
/*     */         }
/* 527 */         if ((con != null) && ((ex.getTargetException() instanceof ClassCastException))) {
/* 528 */           throw new InvalidDataAccessApiUsageException("OracleLobCreator needs to work on [oracle.jdbc.OracleConnection], not on [" + con.getClass().getName() + "]: specify a corresponding NativeJdbcExtractor", ex.getTargetException());
/*     */         }
/*     */ 
/* 534 */         throw new DataAccessResourceFailureException("Could not create Oracle LOB", ex.getTargetException());
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/* 539 */         throw new DataAccessResourceFailureException("Could not create Oracle LOB", ex);
/*     */       }
/*     */     }
/*     */ 
/*     */     protected Connection getOracleConnection(PreparedStatement ps)
/*     */       throws SQLException, ClassNotFoundException
/*     */     {
/* 549 */       return OracleLobHandler.this.nativeJdbcExtractor != null ? OracleLobHandler.this.nativeJdbcExtractor.getNativeConnectionFromStatement(ps) : ps.getConnection();
/*     */     }
/*     */ 
/*     */     protected Object prepareLob(Connection con, Class lobClass)
/*     */       throws Exception
/*     */     {
/* 562 */       Method createTemporary = lobClass.getMethod("createTemporary", new Class[] { Connection.class, Boolean.TYPE, Integer.TYPE });
/*     */ 
/* 564 */       Object lob = createTemporary.invoke(null, new Object[] { con, OracleLobHandler.this.cache, OracleLobHandler.this.durationSessionConstants.get(lobClass) });
/* 565 */       Method open = lobClass.getMethod("open", new Class[] { Integer.TYPE });
/* 566 */       open.invoke(lob, new Object[] { OracleLobHandler.this.modeReadWriteConstants.get(lobClass) });
/* 567 */       return lob;
/*     */     }
/*     */ 
/*     */     public void close()
/*     */     {
/*     */       try
/*     */       {
/* 575 */         for (it = this.temporaryLobs.iterator(); it.hasNext(); )
/*     */         {
/* 580 */           Object lob = it.next();
/* 581 */           Method freeTemporary = lob.getClass().getMethod("freeTemporary", new Class[0]);
/* 582 */           freeTemporary.invoke(lob, new Object[0]);
/* 583 */           it.remove();
/*     */         }
/*     */       }
/*     */       catch (InvocationTargetException ex)
/*     */       {
/*     */         Iterator it;
/* 587 */         OracleLobHandler.this.logger.error("Could not free Oracle LOB", ex.getTargetException());
/*     */       }
/*     */       catch (Exception ex) {
/* 590 */         throw new DataAccessResourceFailureException("Could not free Oracle LOB", ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.lob.OracleLobHandler
 * JD-Core Version:    0.6.1
 */