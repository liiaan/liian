/*    */ package org.springframework.jdbc.core;
/*    */ 
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ public class ArgumentPreparedStatementSetter
/*    */   implements PreparedStatementSetter, ParameterDisposer
/*    */ {
/*    */   private final Object[] args;
/*    */ 
/*    */   public ArgumentPreparedStatementSetter(Object[] args)
/*    */   {
/* 38 */     this.args = args;
/*    */   }
/*    */ 
/*    */   public void setValues(PreparedStatement ps) throws SQLException
/*    */   {
/* 43 */     if (this.args != null)
/* 44 */       for (int i = 0; i < this.args.length; i++) {
/* 45 */         Object arg = this.args[i];
/* 46 */         doSetValue(ps, i + 1, arg);
/*    */       }
/*    */   }
/*    */ 
/*    */   protected void doSetValue(PreparedStatement ps, int parameterPosition, Object argValue)
/*    */     throws SQLException
/*    */   {
/* 60 */     if ((argValue instanceof SqlParameterValue)) {
/* 61 */       SqlParameterValue paramValue = (SqlParameterValue)argValue;
/* 62 */       StatementCreatorUtils.setParameterValue(ps, parameterPosition, paramValue, paramValue.getValue());
/*    */     }
/*    */     else {
/* 65 */       StatementCreatorUtils.setParameterValue(ps, parameterPosition, -2147483648, argValue);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void cleanupParameters() {
/* 70 */     StatementCreatorUtils.cleanupParameters(this.args);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.ArgumentPreparedStatementSetter
 * JD-Core Version:    0.6.1
 */