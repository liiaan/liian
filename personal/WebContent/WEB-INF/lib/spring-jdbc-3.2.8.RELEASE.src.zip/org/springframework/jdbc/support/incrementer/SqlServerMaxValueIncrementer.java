/*     */ package org.springframework.jdbc.support.incrementer;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ 
/*     */ public class SqlServerMaxValueIncrementer extends AbstractColumnMaxValueIncrementer
/*     */ {
/*     */   private long[] valueCache;
/*  53 */   private int nextValueIndex = -1;
/*     */ 
/*     */   public SqlServerMaxValueIncrementer()
/*     */   {
/*     */   }
/*     */ 
/*     */   public SqlServerMaxValueIncrementer(DataSource dataSource, String incrementerName, String columnName)
/*     */   {
/*  72 */     super(dataSource, incrementerName, columnName);
/*     */   }
/*     */ 
/*     */   protected synchronized long getNextKey()
/*     */     throws DataAccessException
/*     */   {
/*  78 */     if ((this.nextValueIndex < 0) || (this.nextValueIndex >= getCacheSize()))
/*     */     {
/*  84 */       Connection con = DataSourceUtils.getConnection(getDataSource());
/*  85 */       Statement stmt = null;
/*     */       try {
/*  87 */         stmt = con.createStatement();
/*  88 */         DataSourceUtils.applyTransactionTimeout(stmt, getDataSource());
/*  89 */         this.valueCache = new long[getCacheSize()];
/*  90 */         this.nextValueIndex = 0;
/*  91 */         for (int i = 0; i < getCacheSize(); i++) {
/*  92 */           stmt.executeUpdate("insert into " + getIncrementerName() + " default values");
/*  93 */           ResultSet rs = stmt.executeQuery("select @@identity");
/*     */           try {
/*  95 */             if (!rs.next()) {
/*  96 */               throw new DataAccessResourceFailureException("@@identity failed after executing an update");
/*     */             }
/*  98 */             this.valueCache[i] = rs.getLong(1);
/*     */           }
/*     */           finally {
/* 101 */             JdbcUtils.closeResultSet(rs);
/*     */           }
/*     */         }
/* 104 */         long maxValue = this.valueCache[(this.valueCache.length - 1)];
/* 105 */         stmt.executeUpdate("delete from " + getIncrementerName() + " where " + getColumnName() + " < " + maxValue);
/*     */       }
/*     */       catch (SQLException ex) {
/* 108 */         throw new DataAccessResourceFailureException("Could not increment identity", ex);
/*     */       }
/*     */       finally {
/* 111 */         JdbcUtils.closeStatement(stmt);
/* 112 */         DataSourceUtils.releaseConnection(con, getDataSource());
/*     */       }
/*     */     }
/* 115 */     return this.valueCache[(this.nextValueIndex++)];
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.incrementer.SqlServerMaxValueIncrementer
 * JD-Core Version:    0.6.1
 */