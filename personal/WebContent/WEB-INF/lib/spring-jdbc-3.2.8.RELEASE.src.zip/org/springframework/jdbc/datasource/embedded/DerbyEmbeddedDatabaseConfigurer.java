/*    */ package org.springframework.jdbc.datasource.embedded;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.sql.SQLException;
/*    */ import java.util.Properties;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.apache.derby.impl.io.VFMemoryStorageFactory;
/*    */ import org.apache.derby.jdbc.EmbeddedDriver;
/*    */ 
/*    */ final class DerbyEmbeddedDatabaseConfigurer
/*    */   implements EmbeddedDatabaseConfigurer
/*    */ {
/* 39 */   private static final Log logger = LogFactory.getLog(DerbyEmbeddedDatabaseConfigurer.class);
/*    */   private static final String URL_TEMPLATE = "jdbc:derby:memory:%s;%s";
/*    */   private static final String SHUTDOWN_CODE = "08006";
/* 46 */   private static final boolean IS_AT_LEAST_DOT_SIX = new EmbeddedDriver().getMinorVersion() >= 6;
/*    */ 
/* 48 */   private static final String SHUTDOWN_COMMAND = String.format("%s=true", new Object[] { IS_AT_LEAST_DOT_SIX ? "drop" : "shutdown" });
/*    */   private static DerbyEmbeddedDatabaseConfigurer INSTANCE;
/*    */ 
/*    */   public static synchronized DerbyEmbeddedDatabaseConfigurer getInstance()
/*    */     throws ClassNotFoundException
/*    */   {
/* 60 */     if (INSTANCE == null)
/*    */     {
/* 62 */       System.setProperty("derby.stream.error.method", OutputStreamFactory.class.getName() + ".getNoopOutputStream");
/*    */ 
/* 64 */       INSTANCE = new DerbyEmbeddedDatabaseConfigurer();
/*    */     }
/* 66 */     return INSTANCE;
/*    */   }
/*    */ 
/*    */   public void configureConnectionProperties(ConnectionProperties properties, String databaseName)
/*    */   {
/* 73 */     properties.setDriverClass(EmbeddedDriver.class);
/* 74 */     properties.setUrl(String.format("jdbc:derby:memory:%s;%s", new Object[] { databaseName, "create=true" }));
/* 75 */     properties.setUsername("sa");
/* 76 */     properties.setPassword("");
/*    */   }
/*    */ 
/*    */   public void shutdown(DataSource dataSource, String databaseName) {
/*    */     try {
/* 81 */       new EmbeddedDriver().connect(String.format("jdbc:derby:memory:%s;%s", new Object[] { databaseName, SHUTDOWN_COMMAND }), new Properties());
/*    */     }
/*    */     catch (SQLException ex)
/*    */     {
/* 85 */       if (!"08006".equals(ex.getSQLState())) {
/* 86 */         logger.warn("Could not shutdown in-memory Derby database", ex);
/* 87 */         return;
/*    */       }
/* 89 */       if (!IS_AT_LEAST_DOT_SIX)
/*    */       {
/*    */         try
/*    */         {
/* 93 */           VFMemoryStorageFactory.purgeDatabase(new File(databaseName).getCanonicalPath());
/*    */         }
/*    */         catch (IOException ex2) {
/* 96 */           logger.warn("Could not purge in-memory Derby database", ex2);
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.embedded.DerbyEmbeddedDatabaseConfigurer
 * JD-Core Version:    0.6.1
 */