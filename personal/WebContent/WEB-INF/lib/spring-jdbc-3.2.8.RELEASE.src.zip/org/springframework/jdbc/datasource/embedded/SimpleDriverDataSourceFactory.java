/*    */ package org.springframework.jdbc.datasource.embedded;
/*    */ 
/*    */ import java.sql.Driver;
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.jdbc.datasource.SimpleDriverDataSource;
/*    */ 
/*    */ final class SimpleDriverDataSourceFactory
/*    */   implements DataSourceFactory
/*    */ {
/* 34 */   private final SimpleDriverDataSource dataSource = new SimpleDriverDataSource();
/*    */ 
/*    */   public ConnectionProperties getConnectionProperties() {
/* 37 */     return new ConnectionProperties() {
/*    */       public void setDriverClass(Class<? extends Driver> driverClass) {
/* 39 */         SimpleDriverDataSourceFactory.this.dataSource.setDriverClass(driverClass);
/*    */       }
/*    */ 
/*    */       public void setUrl(String url) {
/* 43 */         SimpleDriverDataSourceFactory.this.dataSource.setUrl(url);
/*    */       }
/*    */ 
/*    */       public void setUsername(String username) {
/* 47 */         SimpleDriverDataSourceFactory.this.dataSource.setUsername(username);
/*    */       }
/*    */ 
/*    */       public void setPassword(String password) {
/* 51 */         SimpleDriverDataSourceFactory.this.dataSource.setPassword(password);
/*    */       }
/*    */     };
/*    */   }
/*    */ 
/*    */   public DataSource getDataSource() {
/* 57 */     return this.dataSource;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.embedded.SimpleDriverDataSourceFactory
 * JD-Core Version:    0.6.1
 */