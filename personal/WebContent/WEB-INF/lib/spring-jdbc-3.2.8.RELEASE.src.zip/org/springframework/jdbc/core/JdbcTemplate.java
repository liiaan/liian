/*      */ package org.springframework.jdbc.core;
/*      */ 
/*      */ import java.lang.reflect.InvocationHandler;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Proxy;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import javax.sql.DataSource;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.springframework.dao.DataAccessException;
/*      */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*      */ import org.springframework.dao.support.DataAccessUtils;
/*      */ import org.springframework.jdbc.SQLWarningException;
/*      */ import org.springframework.jdbc.datasource.ConnectionProxy;
/*      */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*      */ import org.springframework.jdbc.support.JdbcAccessor;
/*      */ import org.springframework.jdbc.support.JdbcUtils;
/*      */ import org.springframework.jdbc.support.KeyHolder;
/*      */ import org.springframework.jdbc.support.SQLExceptionTranslator;
/*      */ import org.springframework.jdbc.support.nativejdbc.NativeJdbcExtractor;
/*      */ import org.springframework.jdbc.support.rowset.SqlRowSet;
/*      */ import org.springframework.util.Assert;
/*      */ import org.springframework.util.LinkedCaseInsensitiveMap;
/*      */ 
/*      */ public class JdbcTemplate extends JdbcAccessor
/*      */   implements JdbcOperations
/*      */ {
/*      */   private static final String RETURN_RESULT_SET_PREFIX = "#result-set-";
/*      */   private static final String RETURN_UPDATE_COUNT_PREFIX = "#update-count-";
/*      */   private NativeJdbcExtractor nativeJdbcExtractor;
/*  107 */   private boolean ignoreWarnings = true;
/*      */ 
/*  113 */   private int fetchSize = 0;
/*      */ 
/*  119 */   private int maxRows = 0;
/*      */ 
/*  125 */   private int queryTimeout = 0;
/*      */ 
/*  132 */   private boolean skipResultsProcessing = false;
/*      */ 
/*  140 */   private boolean skipUndeclaredResults = false;
/*      */ 
/*  147 */   private boolean resultsMapCaseInsensitive = false;
/*      */ 
/*      */   public JdbcTemplate()
/*      */   {
/*      */   }
/*      */ 
/*      */   public JdbcTemplate(DataSource dataSource)
/*      */   {
/*  164 */     setDataSource(dataSource);
/*  165 */     afterPropertiesSet();
/*      */   }
/*      */ 
/*      */   public JdbcTemplate(DataSource dataSource, boolean lazyInit)
/*      */   {
/*  176 */     setDataSource(dataSource);
/*  177 */     setLazyInit(lazyInit);
/*  178 */     afterPropertiesSet();
/*      */   }
/*      */ 
/*      */   public void setNativeJdbcExtractor(NativeJdbcExtractor extractor)
/*      */   {
/*  189 */     this.nativeJdbcExtractor = extractor;
/*      */   }
/*      */ 
/*      */   public NativeJdbcExtractor getNativeJdbcExtractor()
/*      */   {
/*  196 */     return this.nativeJdbcExtractor;
/*      */   }
/*      */ 
/*      */   public void setIgnoreWarnings(boolean ignoreWarnings)
/*      */   {
/*  208 */     this.ignoreWarnings = ignoreWarnings;
/*      */   }
/*      */ 
/*      */   public boolean isIgnoreWarnings()
/*      */   {
/*  215 */     return this.ignoreWarnings;
/*      */   }
/*      */ 
/*      */   public void setFetchSize(int fetchSize)
/*      */   {
/*  227 */     this.fetchSize = fetchSize;
/*      */   }
/*      */ 
/*      */   public int getFetchSize()
/*      */   {
/*  234 */     return this.fetchSize;
/*      */   }
/*      */ 
/*      */   public void setMaxRows(int maxRows)
/*      */   {
/*  247 */     this.maxRows = maxRows;
/*      */   }
/*      */ 
/*      */   public int getMaxRows()
/*      */   {
/*  254 */     return this.maxRows;
/*      */   }
/*      */ 
/*      */   public void setQueryTimeout(int queryTimeout)
/*      */   {
/*  266 */     this.queryTimeout = queryTimeout;
/*      */   }
/*      */ 
/*      */   public int getQueryTimeout()
/*      */   {
/*  273 */     return this.queryTimeout;
/*      */   }
/*      */ 
/*      */   public void setSkipResultsProcessing(boolean skipResultsProcessing)
/*      */   {
/*  283 */     this.skipResultsProcessing = skipResultsProcessing;
/*      */   }
/*      */ 
/*      */   public boolean isSkipResultsProcessing()
/*      */   {
/*  290 */     return this.skipResultsProcessing;
/*      */   }
/*      */ 
/*      */   public void setSkipUndeclaredResults(boolean skipUndeclaredResults)
/*      */   {
/*  297 */     this.skipUndeclaredResults = skipUndeclaredResults;
/*      */   }
/*      */ 
/*      */   public boolean isSkipUndeclaredResults()
/*      */   {
/*  304 */     return this.skipUndeclaredResults;
/*      */   }
/*      */ 
/*      */   public void setResultsMapCaseInsensitive(boolean resultsMapCaseInsensitive)
/*      */   {
/*  312 */     this.resultsMapCaseInsensitive = resultsMapCaseInsensitive;
/*      */   }
/*      */ 
/*      */   public boolean isResultsMapCaseInsensitive()
/*      */   {
/*  320 */     return this.resultsMapCaseInsensitive;
/*      */   }
/*      */ 
/*      */   public <T> T execute(ConnectionCallback<T> action)
/*      */     throws DataAccessException
/*      */   {
/*  329 */     Assert.notNull(action, "Callback object must not be null");
/*      */ 
/*  331 */     Connection con = DataSourceUtils.getConnection(getDataSource());
/*      */     try {
/*  333 */       Connection conToUse = con;
/*  334 */       if (this.nativeJdbcExtractor != null)
/*      */       {
/*  336 */         conToUse = this.nativeJdbcExtractor.getNativeConnection(con);
/*      */       }
/*      */       else
/*      */       {
/*  340 */         conToUse = createConnectionProxy(con);
/*      */       }
/*  342 */       return action.doInConnection(conToUse);
/*      */     }
/*      */     catch (SQLException ex)
/*      */     {
/*  347 */       DataSourceUtils.releaseConnection(con, getDataSource());
/*  348 */       con = null;
/*  349 */       throw getExceptionTranslator().translate("ConnectionCallback", getSql(action), ex);
/*      */     }
/*      */     finally {
/*  352 */       DataSourceUtils.releaseConnection(con, getDataSource());
/*      */     }
/*      */   }
/*      */ 
/*      */   protected Connection createConnectionProxy(Connection con)
/*      */   {
/*  368 */     return (Connection)Proxy.newProxyInstance(ConnectionProxy.class.getClassLoader(), new Class[] { ConnectionProxy.class }, new CloseSuppressingInvocationHandler(con));
/*      */   }
/*      */ 
/*      */   public <T> T execute(StatementCallback<T> action)
/*      */     throws DataAccessException
/*      */   {
/*  380 */     Assert.notNull(action, "Callback object must not be null");
/*      */ 
/*  382 */     Connection con = DataSourceUtils.getConnection(getDataSource());
/*  383 */     Statement stmt = null;
/*      */     try {
/*  385 */       Connection conToUse = con;
/*  386 */       if ((this.nativeJdbcExtractor != null) && (this.nativeJdbcExtractor.isNativeConnectionNecessaryForNativeStatements()))
/*      */       {
/*  388 */         conToUse = this.nativeJdbcExtractor.getNativeConnection(con);
/*      */       }
/*  390 */       stmt = conToUse.createStatement();
/*  391 */       applyStatementSettings(stmt);
/*  392 */       Statement stmtToUse = stmt;
/*  393 */       if (this.nativeJdbcExtractor != null) {
/*  394 */         stmtToUse = this.nativeJdbcExtractor.getNativeStatement(stmt);
/*      */       }
/*  396 */       Object result = action.doInStatement(stmtToUse);
/*  397 */       handleWarnings(stmt);
/*  398 */       return result;
/*      */     }
/*      */     catch (SQLException ex)
/*      */     {
/*  403 */       JdbcUtils.closeStatement(stmt);
/*  404 */       stmt = null;
/*  405 */       DataSourceUtils.releaseConnection(con, getDataSource());
/*  406 */       con = null;
/*  407 */       throw getExceptionTranslator().translate("StatementCallback", getSql(action), ex);
/*      */     }
/*      */     finally {
/*  410 */       JdbcUtils.closeStatement(stmt);
/*  411 */       DataSourceUtils.releaseConnection(con, getDataSource());
/*      */     }
/*      */   }
/*      */ 
/*      */   public void execute(final String sql) throws DataAccessException {
/*  416 */     if (this.logger.isDebugEnabled()) {
/*  417 */       this.logger.debug("Executing SQL statement [" + sql + "]");
/*      */     }
/*      */ 
/*  428 */     execute(new StatementCallback()
/*      */     {
/*      */       public Object doInStatement(Statement stmt)
/*      */         throws SQLException
/*      */       {
/*  421 */         stmt.execute(sql);
/*  422 */         return null;
/*      */       }
/*      */       public String getSql() {
/*  425 */         return sql;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public <T> T query(final String sql, final ResultSetExtractor<T> rse) throws DataAccessException
/*      */   {
/*  432 */     Assert.notNull(sql, "SQL must not be null");
/*  433 */     Assert.notNull(rse, "ResultSetExtractor must not be null");
/*  434 */     if (this.logger.isDebugEnabled()) {
/*  435 */       this.logger.debug("Executing SQL query [" + sql + "]");
/*      */     }
/*      */ 
/*  456 */     return execute(new StatementCallback()
/*      */     {
/*      */       public T doInStatement(Statement stmt)
/*      */         throws SQLException
/*      */       {
/*  439 */         ResultSet rs = null;
/*      */         try {
/*  441 */           rs = stmt.executeQuery(sql);
/*  442 */           ResultSet rsToUse = rs;
/*  443 */           if (this.this$0.nativeJdbcExtractor != null) {
/*  444 */             rsToUse = this.this$0.nativeJdbcExtractor.getNativeResultSet(rs);
/*      */           }
/*  446 */           return rse.extractData(rsToUse);
/*      */         }
/*      */         finally {
/*  449 */           JdbcUtils.closeResultSet(rs);
/*      */         }
/*      */       }
/*      */ 
/*  453 */       public String getSql() { return sql; }
/*      */     });
/*      */   }
/*      */ 
/*      */   public void query(String sql, RowCallbackHandler rch)
/*      */     throws DataAccessException
/*      */   {
/*  460 */     query(sql, new RowCallbackHandlerResultSetExtractor(rch));
/*      */   }
/*      */ 
/*      */   public <T> List<T> query(String sql, RowMapper<T> rowMapper) throws DataAccessException {
/*  464 */     return (List)query(sql, new RowMapperResultSetExtractor(rowMapper));
/*      */   }
/*      */ 
/*      */   public Map<String, Object> queryForMap(String sql) throws DataAccessException {
/*  468 */     return (Map)queryForObject(sql, getColumnMapRowMapper());
/*      */   }
/*      */ 
/*      */   public <T> T queryForObject(String sql, RowMapper<T> rowMapper) throws DataAccessException {
/*  472 */     List results = query(sql, rowMapper);
/*  473 */     return DataAccessUtils.requiredSingleResult(results);
/*      */   }
/*      */ 
/*      */   public <T> T queryForObject(String sql, Class<T> requiredType) throws DataAccessException {
/*  477 */     return queryForObject(sql, getSingleColumnRowMapper(requiredType));
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public long queryForLong(String sql) throws DataAccessException {
/*  482 */     Number number = (Number)queryForObject(sql, Long.class);
/*  483 */     return number != null ? number.longValue() : 0L;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public int queryForInt(String sql) throws DataAccessException {
/*  488 */     Number number = (Number)queryForObject(sql, Integer.class);
/*  489 */     return number != null ? number.intValue() : 0;
/*      */   }
/*      */ 
/*      */   public <T> List<T> queryForList(String sql, Class<T> elementType) throws DataAccessException {
/*  493 */     return query(sql, getSingleColumnRowMapper(elementType));
/*      */   }
/*      */ 
/*      */   public List<Map<String, Object>> queryForList(String sql) throws DataAccessException {
/*  497 */     return query(sql, getColumnMapRowMapper());
/*      */   }
/*      */ 
/*      */   public SqlRowSet queryForRowSet(String sql) throws DataAccessException {
/*  501 */     return (SqlRowSet)query(sql, new SqlRowSetResultSetExtractor());
/*      */   }
/*      */ 
/*      */   public int update(final String sql) throws DataAccessException {
/*  505 */     Assert.notNull(sql, "SQL must not be null");
/*  506 */     if (this.logger.isDebugEnabled()) {
/*  507 */       this.logger.debug("Executing SQL update [" + sql + "]");
/*      */     }
/*      */ 
/*  521 */     return ((Integer)execute(new StatementCallback()
/*      */     {
/*      */       public Integer doInStatement(Statement stmt)
/*      */         throws SQLException
/*      */       {
/*  511 */         int rows = stmt.executeUpdate(sql);
/*  512 */         if (this.this$0.logger.isDebugEnabled()) {
/*  513 */           this.this$0.logger.debug("SQL update affected " + rows + " rows");
/*      */         }
/*  515 */         return Integer.valueOf(rows);
/*      */       }
/*      */       public String getSql() {
/*  518 */         return sql;
/*      */       }
/*      */     })).intValue();
/*      */   }
/*      */ 
/*      */   public int[] batchUpdate(final String[] sql) throws DataAccessException {
/*  525 */     Assert.notEmpty(sql, "SQL array must not be empty");
/*  526 */     if (this.logger.isDebugEnabled()) {
/*  527 */       this.logger.debug("Executing SQL batch update of " + sql.length + " statements");
/*      */     }
/*      */ 
/*  557 */     return (int[])execute(new StatementCallback()
/*      */     {
/*      */       private String currSql;
/*      */ 
/*      */       public int[] doInStatement(Statement stmt)
/*      */         throws SQLException, DataAccessException
/*      */       {
/*  532 */         int[] rowsAffected = new int[sql.length];
/*  533 */         if (JdbcUtils.supportsBatchUpdates(stmt.getConnection())) {
/*  534 */           for (String sqlStmt : sql) {
/*  535 */             this.currSql = sqlStmt;
/*  536 */             stmt.addBatch(sqlStmt);
/*      */           }
/*  538 */           rowsAffected = stmt.executeBatch();
/*      */         }
/*      */         else {
/*  541 */           for (int i = 0; i < sql.length; i++) {
/*  542 */             this.currSql = sql[i];
/*  543 */             if (!stmt.execute(sql[i])) {
/*  544 */               rowsAffected[i] = stmt.getUpdateCount();
/*      */             }
/*      */             else {
/*  547 */               throw new InvalidDataAccessApiUsageException("Invalid batch SQL statement: " + sql[i]);
/*      */             }
/*      */           }
/*      */         }
/*  551 */         return rowsAffected;
/*      */       }
/*      */       public String getSql() {
/*  554 */         return this.currSql;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public <T> T execute(PreparedStatementCreator psc, PreparedStatementCallback<T> action)
/*      */     throws DataAccessException
/*      */   {
/*  568 */     Assert.notNull(psc, "PreparedStatementCreator must not be null");
/*  569 */     Assert.notNull(action, "Callback object must not be null");
/*  570 */     if (this.logger.isDebugEnabled()) {
/*  571 */       String sql = getSql(psc);
/*  572 */       this.logger.debug("Executing prepared SQL statement" + (sql != null ? " [" + sql + "]" : ""));
/*      */     }
/*      */ 
/*  575 */     Connection con = DataSourceUtils.getConnection(getDataSource());
/*  576 */     PreparedStatement ps = null;
/*      */     try {
/*  578 */       Connection conToUse = con;
/*  579 */       if ((this.nativeJdbcExtractor != null) && (this.nativeJdbcExtractor.isNativeConnectionNecessaryForNativePreparedStatements()))
/*      */       {
/*  581 */         conToUse = this.nativeJdbcExtractor.getNativeConnection(con);
/*      */       }
/*  583 */       ps = psc.createPreparedStatement(conToUse);
/*  584 */       applyStatementSettings(ps);
/*  585 */       PreparedStatement psToUse = ps;
/*  586 */       if (this.nativeJdbcExtractor != null) {
/*  587 */         psToUse = this.nativeJdbcExtractor.getNativePreparedStatement(ps);
/*      */       }
/*  589 */       Object result = action.doInPreparedStatement(psToUse);
/*  590 */       handleWarnings(ps);
/*  591 */       return result;
/*      */     }
/*      */     catch (SQLException ex)
/*      */     {
/*  596 */       if ((psc instanceof ParameterDisposer)) {
/*  597 */         ((ParameterDisposer)psc).cleanupParameters();
/*      */       }
/*  599 */       String sql = getSql(psc);
/*  600 */       psc = null;
/*  601 */       JdbcUtils.closeStatement(ps);
/*  602 */       ps = null;
/*  603 */       DataSourceUtils.releaseConnection(con, getDataSource());
/*  604 */       con = null;
/*  605 */       throw getExceptionTranslator().translate("PreparedStatementCallback", sql, ex);
/*      */     }
/*      */     finally {
/*  608 */       if ((psc instanceof ParameterDisposer)) {
/*  609 */         ((ParameterDisposer)psc).cleanupParameters();
/*      */       }
/*  611 */       JdbcUtils.closeStatement(ps);
/*  612 */       DataSourceUtils.releaseConnection(con, getDataSource());
/*      */     }
/*      */   }
/*      */ 
/*      */   public <T> T execute(String sql, PreparedStatementCallback<T> action) throws DataAccessException {
/*  617 */     return execute(new SimplePreparedStatementCreator(sql), action);
/*      */   }
/*      */ 
/*      */   public <T> T query(PreparedStatementCreator psc, final PreparedStatementSetter pss, final ResultSetExtractor<T> rse)
/*      */     throws DataAccessException
/*      */   {
/*  636 */     Assert.notNull(rse, "ResultSetExtractor must not be null");
/*  637 */     this.logger.debug("Executing prepared SQL query");
/*      */ 
/*  639 */     return execute(psc, new PreparedStatementCallback() {
/*      */       public T doInPreparedStatement(PreparedStatement ps) throws SQLException {
/*  641 */         ResultSet rs = null;
/*      */         try {
/*  643 */           if (pss != null) {
/*  644 */             pss.setValues(ps);
/*      */           }
/*  646 */           rs = ps.executeQuery();
/*  647 */           ResultSet rsToUse = rs;
/*  648 */           if (JdbcTemplate.this.nativeJdbcExtractor != null) {
/*  649 */             rsToUse = JdbcTemplate.this.nativeJdbcExtractor.getNativeResultSet(rs);
/*      */           }
/*  651 */           return rse.extractData(rsToUse);
/*      */         }
/*      */         finally {
/*  654 */           JdbcUtils.closeResultSet(rs);
/*  655 */           if ((pss instanceof ParameterDisposer))
/*  656 */             ((ParameterDisposer)pss).cleanupParameters();
/*      */         }
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public <T> T query(PreparedStatementCreator psc, ResultSetExtractor<T> rse) throws DataAccessException
/*      */   {
/*  664 */     return query(psc, null, rse);
/*      */   }
/*      */ 
/*      */   public <T> T query(String sql, PreparedStatementSetter pss, ResultSetExtractor<T> rse) throws DataAccessException {
/*  668 */     return query(new SimplePreparedStatementCreator(sql), pss, rse);
/*      */   }
/*      */ 
/*      */   public <T> T query(String sql, Object[] args, int[] argTypes, ResultSetExtractor<T> rse) throws DataAccessException {
/*  672 */     return query(sql, newArgTypePreparedStatementSetter(args, argTypes), rse);
/*      */   }
/*      */ 
/*      */   public <T> T query(String sql, Object[] args, ResultSetExtractor<T> rse) throws DataAccessException {
/*  676 */     return query(sql, newArgPreparedStatementSetter(args), rse);
/*      */   }
/*      */ 
/*      */   public <T> T query(String sql, ResultSetExtractor<T> rse, Object[] args) throws DataAccessException {
/*  680 */     return query(sql, newArgPreparedStatementSetter(args), rse);
/*      */   }
/*      */ 
/*      */   public void query(PreparedStatementCreator psc, RowCallbackHandler rch) throws DataAccessException {
/*  684 */     query(psc, new RowCallbackHandlerResultSetExtractor(rch));
/*      */   }
/*      */ 
/*      */   public void query(String sql, PreparedStatementSetter pss, RowCallbackHandler rch) throws DataAccessException {
/*  688 */     query(sql, pss, new RowCallbackHandlerResultSetExtractor(rch));
/*      */   }
/*      */ 
/*      */   public void query(String sql, Object[] args, int[] argTypes, RowCallbackHandler rch) throws DataAccessException {
/*  692 */     query(sql, newArgTypePreparedStatementSetter(args, argTypes), rch);
/*      */   }
/*      */ 
/*      */   public void query(String sql, Object[] args, RowCallbackHandler rch) throws DataAccessException {
/*  696 */     query(sql, newArgPreparedStatementSetter(args), rch);
/*      */   }
/*      */ 
/*      */   public void query(String sql, RowCallbackHandler rch, Object[] args) throws DataAccessException {
/*  700 */     query(sql, newArgPreparedStatementSetter(args), rch);
/*      */   }
/*      */ 
/*      */   public <T> List<T> query(PreparedStatementCreator psc, RowMapper<T> rowMapper) throws DataAccessException {
/*  704 */     return (List)query(psc, new RowMapperResultSetExtractor(rowMapper));
/*      */   }
/*      */ 
/*      */   public <T> List<T> query(String sql, PreparedStatementSetter pss, RowMapper<T> rowMapper) throws DataAccessException {
/*  708 */     return (List)query(sql, pss, new RowMapperResultSetExtractor(rowMapper));
/*      */   }
/*      */ 
/*      */   public <T> List<T> query(String sql, Object[] args, int[] argTypes, RowMapper<T> rowMapper) throws DataAccessException {
/*  712 */     return (List)query(sql, args, argTypes, new RowMapperResultSetExtractor(rowMapper));
/*      */   }
/*      */ 
/*      */   public <T> List<T> query(String sql, Object[] args, RowMapper<T> rowMapper) throws DataAccessException {
/*  716 */     return (List)query(sql, args, new RowMapperResultSetExtractor(rowMapper));
/*      */   }
/*      */ 
/*      */   public <T> List<T> query(String sql, RowMapper<T> rowMapper, Object[] args) throws DataAccessException {
/*  720 */     return (List)query(sql, args, new RowMapperResultSetExtractor(rowMapper));
/*      */   }
/*      */ 
/*      */   public <T> T queryForObject(String sql, Object[] args, int[] argTypes, RowMapper<T> rowMapper)
/*      */     throws DataAccessException
/*      */   {
/*  726 */     List results = (List)query(sql, args, argTypes, new RowMapperResultSetExtractor(rowMapper, 1));
/*  727 */     return DataAccessUtils.requiredSingleResult(results);
/*      */   }
/*      */ 
/*      */   public <T> T queryForObject(String sql, Object[] args, RowMapper<T> rowMapper) throws DataAccessException {
/*  731 */     List results = (List)query(sql, args, new RowMapperResultSetExtractor(rowMapper, 1));
/*  732 */     return DataAccessUtils.requiredSingleResult(results);
/*      */   }
/*      */ 
/*      */   public <T> T queryForObject(String sql, RowMapper<T> rowMapper, Object[] args) throws DataAccessException {
/*  736 */     List results = (List)query(sql, args, new RowMapperResultSetExtractor(rowMapper, 1));
/*  737 */     return DataAccessUtils.requiredSingleResult(results);
/*      */   }
/*      */ 
/*      */   public <T> T queryForObject(String sql, Object[] args, int[] argTypes, Class<T> requiredType)
/*      */     throws DataAccessException
/*      */   {
/*  743 */     return queryForObject(sql, args, argTypes, getSingleColumnRowMapper(requiredType));
/*      */   }
/*      */ 
/*      */   public <T> T queryForObject(String sql, Object[] args, Class<T> requiredType) throws DataAccessException {
/*  747 */     return queryForObject(sql, args, getSingleColumnRowMapper(requiredType));
/*      */   }
/*      */ 
/*      */   public <T> T queryForObject(String sql, Class<T> requiredType, Object[] args) throws DataAccessException {
/*  751 */     return queryForObject(sql, args, getSingleColumnRowMapper(requiredType));
/*      */   }
/*      */ 
/*      */   public Map<String, Object> queryForMap(String sql, Object[] args, int[] argTypes) throws DataAccessException {
/*  755 */     return (Map)queryForObject(sql, args, argTypes, getColumnMapRowMapper());
/*      */   }
/*      */ 
/*      */   public Map<String, Object> queryForMap(String sql, Object[] args) throws DataAccessException {
/*  759 */     return (Map)queryForObject(sql, args, getColumnMapRowMapper());
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public long queryForLong(String sql, Object[] args, int[] argTypes) throws DataAccessException {
/*  764 */     Number number = (Number)queryForObject(sql, args, argTypes, Long.class);
/*  765 */     return number != null ? number.longValue() : 0L;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public long queryForLong(String sql, Object[] args) throws DataAccessException {
/*  770 */     Number number = (Number)queryForObject(sql, args, Long.class);
/*  771 */     return number != null ? number.longValue() : 0L;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public int queryForInt(String sql, Object[] args, int[] argTypes) throws DataAccessException {
/*  776 */     Number number = (Number)queryForObject(sql, args, argTypes, Integer.class);
/*  777 */     return number != null ? number.intValue() : 0;
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public int queryForInt(String sql, Object[] args) throws DataAccessException {
/*  782 */     Number number = (Number)queryForObject(sql, args, Integer.class);
/*  783 */     return number != null ? number.intValue() : 0;
/*      */   }
/*      */ 
/*      */   public <T> List<T> queryForList(String sql, Object[] args, int[] argTypes, Class<T> elementType) throws DataAccessException {
/*  787 */     return query(sql, args, argTypes, getSingleColumnRowMapper(elementType));
/*      */   }
/*      */ 
/*      */   public <T> List<T> queryForList(String sql, Object[] args, Class<T> elementType) throws DataAccessException {
/*  791 */     return query(sql, args, getSingleColumnRowMapper(elementType));
/*      */   }
/*      */ 
/*      */   public <T> List<T> queryForList(String sql, Class<T> elementType, Object[] args) throws DataAccessException {
/*  795 */     return query(sql, args, getSingleColumnRowMapper(elementType));
/*      */   }
/*      */ 
/*      */   public List<Map<String, Object>> queryForList(String sql, Object[] args, int[] argTypes) throws DataAccessException {
/*  799 */     return query(sql, args, argTypes, getColumnMapRowMapper());
/*      */   }
/*      */ 
/*      */   public List<Map<String, Object>> queryForList(String sql, Object[] args) throws DataAccessException {
/*  803 */     return query(sql, args, getColumnMapRowMapper());
/*      */   }
/*      */ 
/*      */   public SqlRowSet queryForRowSet(String sql, Object[] args, int[] argTypes) throws DataAccessException {
/*  807 */     return (SqlRowSet)query(sql, args, argTypes, new SqlRowSetResultSetExtractor());
/*      */   }
/*      */ 
/*      */   public SqlRowSet queryForRowSet(String sql, Object[] args) throws DataAccessException {
/*  811 */     return (SqlRowSet)query(sql, args, new SqlRowSetResultSetExtractor());
/*      */   }
/*      */ 
/*      */   protected int update(PreparedStatementCreator psc, final PreparedStatementSetter pss)
/*      */     throws DataAccessException
/*      */   {
/*  817 */     this.logger.debug("Executing prepared SQL update");
/*  818 */     return ((Integer)execute(psc, new PreparedStatementCallback() {
/*      */       public Integer doInPreparedStatement(PreparedStatement ps) throws SQLException {
/*      */         try {
/*  821 */           if (pss != null) {
/*  822 */             pss.setValues(ps);
/*      */           }
/*  824 */           int rows = ps.executeUpdate();
/*  825 */           if (JdbcTemplate.this.logger.isDebugEnabled()) {
/*  826 */             JdbcTemplate.this.logger.debug("SQL update affected " + rows + " rows");
/*      */           }
/*  828 */           return Integer.valueOf(rows);
/*      */         }
/*      */         finally {
/*  831 */           if ((pss instanceof ParameterDisposer))
/*  832 */             ((ParameterDisposer)pss).cleanupParameters();
/*      */         }
/*      */       }
/*      */     })).intValue();
/*      */   }
/*      */ 
/*      */   public int update(PreparedStatementCreator psc)
/*      */     throws DataAccessException
/*      */   {
/*  840 */     return update(psc, (PreparedStatementSetter)null);
/*      */   }
/*      */ 
/*      */   public int update(PreparedStatementCreator psc, final KeyHolder generatedKeyHolder)
/*      */     throws DataAccessException
/*      */   {
/*  846 */     Assert.notNull(generatedKeyHolder, "KeyHolder must not be null");
/*  847 */     this.logger.debug("Executing SQL update and returning generated keys");
/*      */ 
/*  849 */     return ((Integer)execute(psc, new PreparedStatementCallback() {
/*      */       public Integer doInPreparedStatement(PreparedStatement ps) throws SQLException {
/*  851 */         int rows = ps.executeUpdate();
/*  852 */         List generatedKeys = generatedKeyHolder.getKeyList();
/*  853 */         generatedKeys.clear();
/*  854 */         ResultSet keys = ps.getGeneratedKeys();
/*  855 */         if (keys != null) {
/*      */           try {
/*  857 */             RowMapperResultSetExtractor rse = new RowMapperResultSetExtractor(JdbcTemplate.this.getColumnMapRowMapper(), 1);
/*      */ 
/*  859 */             generatedKeys.addAll(rse.extractData(keys));
/*      */           }
/*      */           finally {
/*  862 */             JdbcUtils.closeResultSet(keys);
/*      */           }
/*      */         }
/*  865 */         if (JdbcTemplate.this.logger.isDebugEnabled()) {
/*  866 */           JdbcTemplate.this.logger.debug("SQL update affected " + rows + " rows and returned " + generatedKeys.size() + " keys");
/*      */         }
/*  868 */         return Integer.valueOf(rows);
/*      */       }
/*      */     })).intValue();
/*      */   }
/*      */ 
/*      */   public int update(String sql, PreparedStatementSetter pss)
/*      */     throws DataAccessException
/*      */   {
/*  874 */     return update(new SimplePreparedStatementCreator(sql), pss);
/*      */   }
/*      */ 
/*      */   public int update(String sql, Object[] args, int[] argTypes) throws DataAccessException {
/*  878 */     return update(sql, newArgTypePreparedStatementSetter(args, argTypes));
/*      */   }
/*      */ 
/*      */   public int update(String sql, Object[] args) throws DataAccessException {
/*  882 */     return update(sql, newArgPreparedStatementSetter(args));
/*      */   }
/*      */ 
/*      */   public int[] batchUpdate(String sql, final BatchPreparedStatementSetter pss) throws DataAccessException {
/*  886 */     if (this.logger.isDebugEnabled()) {
/*  887 */       this.logger.debug("Executing SQL batch update [" + sql + "]");
/*      */     }
/*      */ 
/*  890 */     return (int[])execute(sql, new PreparedStatementCallback() {
/*      */       public int[] doInPreparedStatement(PreparedStatement ps) throws SQLException {
/*      */         try {
/*  893 */           int batchSize = pss.getBatchSize();
/*  894 */           InterruptibleBatchPreparedStatementSetter ipss = (pss instanceof InterruptibleBatchPreparedStatementSetter) ? (InterruptibleBatchPreparedStatementSetter)pss : null;
/*      */ 
/*  897 */           if (JdbcUtils.supportsBatchUpdates(ps.getConnection())) {
/*  898 */             for (int i = 0; i < batchSize; i++) {
/*  899 */               pss.setValues(ps, i);
/*  900 */               if ((ipss != null) && (ipss.isBatchExhausted(i))) {
/*      */                 break;
/*      */               }
/*  903 */               ps.addBatch();
/*      */             }
/*  905 */             return ps.executeBatch();
/*      */           }
/*      */ 
/*  908 */           List rowsAffected = new ArrayList();
/*  909 */           for (int i = 0; i < batchSize; i++) {
/*  910 */             pss.setValues(ps, i);
/*  911 */             if ((ipss != null) && (ipss.isBatchExhausted(i))) {
/*      */               break;
/*      */             }
/*  914 */             rowsAffected.add(Integer.valueOf(ps.executeUpdate()));
/*      */           }
/*  916 */           int[] rowsAffectedArray = new int[rowsAffected.size()];
/*  917 */           for (int i = 0; i < rowsAffectedArray.length; i++) {
/*  918 */             rowsAffectedArray[i] = ((Integer)rowsAffected.get(i)).intValue();
/*      */           }
/*  920 */           return rowsAffectedArray;
/*      */         }
/*      */         finally
/*      */         {
/*  924 */           if ((pss instanceof ParameterDisposer))
/*  925 */             ((ParameterDisposer)pss).cleanupParameters();
/*      */         }
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public int[] batchUpdate(String sql, List<Object[]> batchArgs) throws DataAccessException
/*      */   {
/*  933 */     return batchUpdate(sql, batchArgs, new int[0]);
/*      */   }
/*      */ 
/*      */   public int[] batchUpdate(String sql, List<Object[]> batchArgs, int[] argTypes) throws DataAccessException {
/*  937 */     return BatchUpdateUtils.executeBatchUpdate(sql, batchArgs, argTypes, this);
/*      */   }
/*      */ 
/*      */   public <T> int[][] batchUpdate(String sql, final Collection<T> batchArgs, final int batchSize, final ParameterizedPreparedStatementSetter<T> pss)
/*      */     throws DataAccessException
/*      */   {
/*  943 */     if (this.logger.isDebugEnabled()) {
/*  944 */       this.logger.debug("Executing SQL batch update [" + sql + "] with a batch size of " + batchSize);
/*      */     }
/*  946 */     return (int[][])execute(sql, new PreparedStatementCallback() {
/*      */       public int[][] doInPreparedStatement(PreparedStatement ps) throws SQLException {
/*  948 */         List rowsAffected = new ArrayList();
/*      */         try {
/*  950 */           boolean batchSupported = true;
/*  951 */           if (!JdbcUtils.supportsBatchUpdates(ps.getConnection())) {
/*  952 */             batchSupported = false;
/*  953 */             JdbcTemplate.this.logger.warn("JDBC Driver does not support Batch updates; resorting to single statement execution");
/*      */           }
/*  955 */           int n = 0;
/*  956 */           for (Iterator i$ = batchArgs.iterator(); i$.hasNext(); ) { Object obj = i$.next();
/*  957 */             pss.setValues(ps, obj);
/*  958 */             n++;
/*  959 */             if (batchSupported) {
/*  960 */               ps.addBatch();
/*  961 */               if ((n % batchSize == 0) || (n == batchArgs.size())) {
/*  962 */                 if (JdbcTemplate.this.logger.isDebugEnabled()) {
/*  963 */                   int batchIdx = n % batchSize == 0 ? n / batchSize : n / batchSize + 1;
/*  964 */                   int items = n - (n % batchSize == 0 ? n / batchSize - 1 : n / batchSize) * batchSize;
/*  965 */                   JdbcTemplate.this.logger.debug("Sending SQL batch update #" + batchIdx + " with " + items + " items");
/*      */                 }
/*  967 */                 rowsAffected.add(ps.executeBatch());
/*      */               }
/*      */             }
/*      */             else {
/*  971 */               int i = ps.executeUpdate();
/*  972 */               rowsAffected.add(new int[] { i });
/*      */             }
/*      */           }
/*  975 */           int[][] result = new int[rowsAffected.size()][];
/*  976 */           for (int i = 0; i < result.length; i++) {
/*  977 */             result[i] = ((int[])rowsAffected.get(i));
/*      */           }
/*  979 */           return result;
/*      */         } finally {
/*  981 */           if ((pss instanceof ParameterDisposer))
/*  982 */             ((ParameterDisposer)pss).cleanupParameters();
/*      */         }
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public <T> T execute(CallableStatementCreator csc, CallableStatementCallback<T> action)
/*      */     throws DataAccessException
/*      */   {
/*  996 */     Assert.notNull(csc, "CallableStatementCreator must not be null");
/*  997 */     Assert.notNull(action, "Callback object must not be null");
/*  998 */     if (this.logger.isDebugEnabled()) {
/*  999 */       String sql = getSql(csc);
/* 1000 */       this.logger.debug("Calling stored procedure" + (sql != null ? " [" + sql + "]" : ""));
/*      */     }
/*      */ 
/* 1003 */     Connection con = DataSourceUtils.getConnection(getDataSource());
/* 1004 */     CallableStatement cs = null;
/*      */     try {
/* 1006 */       Connection conToUse = con;
/* 1007 */       if (this.nativeJdbcExtractor != null) {
/* 1008 */         conToUse = this.nativeJdbcExtractor.getNativeConnection(con);
/*      */       }
/* 1010 */       cs = csc.createCallableStatement(conToUse);
/* 1011 */       applyStatementSettings(cs);
/* 1012 */       CallableStatement csToUse = cs;
/* 1013 */       if (this.nativeJdbcExtractor != null) {
/* 1014 */         csToUse = this.nativeJdbcExtractor.getNativeCallableStatement(cs);
/*      */       }
/* 1016 */       Object result = action.doInCallableStatement(csToUse);
/* 1017 */       handleWarnings(cs);
/* 1018 */       return result;
/*      */     }
/*      */     catch (SQLException ex)
/*      */     {
/* 1023 */       if ((csc instanceof ParameterDisposer)) {
/* 1024 */         ((ParameterDisposer)csc).cleanupParameters();
/*      */       }
/* 1026 */       String sql = getSql(csc);
/* 1027 */       csc = null;
/* 1028 */       JdbcUtils.closeStatement(cs);
/* 1029 */       cs = null;
/* 1030 */       DataSourceUtils.releaseConnection(con, getDataSource());
/* 1031 */       con = null;
/* 1032 */       throw getExceptionTranslator().translate("CallableStatementCallback", sql, ex);
/*      */     }
/*      */     finally {
/* 1035 */       if ((csc instanceof ParameterDisposer)) {
/* 1036 */         ((ParameterDisposer)csc).cleanupParameters();
/*      */       }
/* 1038 */       JdbcUtils.closeStatement(cs);
/* 1039 */       DataSourceUtils.releaseConnection(con, getDataSource());
/*      */     }
/*      */   }
/*      */ 
/*      */   public <T> T execute(String callString, CallableStatementCallback<T> action) throws DataAccessException {
/* 1044 */     return execute(new SimpleCallableStatementCreator(callString), action);
/*      */   }
/*      */ 
/*      */   public Map<String, Object> call(CallableStatementCreator csc, List<SqlParameter> declaredParameters)
/*      */     throws DataAccessException
/*      */   {
/* 1050 */     final List updateCountParameters = new ArrayList();
/* 1051 */     final List resultSetParameters = new ArrayList();
/* 1052 */     final List callParameters = new ArrayList();
/* 1053 */     for (SqlParameter parameter : declaredParameters) {
/* 1054 */       if (parameter.isResultsParameter()) {
/* 1055 */         if ((parameter instanceof SqlReturnResultSet)) {
/* 1056 */           resultSetParameters.add(parameter);
/*      */         }
/*      */         else {
/* 1059 */           updateCountParameters.add(parameter);
/*      */         }
/*      */       }
/*      */       else {
/* 1063 */         callParameters.add(parameter);
/*      */       }
/*      */     }
/* 1066 */     return (Map)execute(csc, new CallableStatementCallback() {
/*      */       public Map<String, Object> doInCallableStatement(CallableStatement cs) throws SQLException {
/* 1068 */         boolean retVal = cs.execute();
/* 1069 */         int updateCount = cs.getUpdateCount();
/* 1070 */         if (JdbcTemplate.this.logger.isDebugEnabled()) {
/* 1071 */           JdbcTemplate.this.logger.debug("CallableStatement.execute() returned '" + retVal + "'");
/* 1072 */           JdbcTemplate.this.logger.debug("CallableStatement.getUpdateCount() returned " + updateCount);
/*      */         }
/* 1074 */         Map returnedResults = JdbcTemplate.this.createResultsMap();
/* 1075 */         if ((retVal) || (updateCount != -1)) {
/* 1076 */           returnedResults.putAll(JdbcTemplate.this.extractReturnedResults(cs, updateCountParameters, resultSetParameters, updateCount));
/*      */         }
/* 1078 */         returnedResults.putAll(JdbcTemplate.this.extractOutputParameters(cs, callParameters));
/* 1079 */         return returnedResults;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   protected Map<String, Object> extractReturnedResults(CallableStatement cs, List<SqlParameter> updateCountParameters, List<SqlParameter> resultSetParameters, int updateCount)
/*      */     throws SQLException
/*      */   {
/* 1095 */     Map returnedResults = new HashMap();
/* 1096 */     int rsIndex = 0;
/* 1097 */     int updateIndex = 0;
/*      */ 
/* 1099 */     if (!this.skipResultsProcessing) {
/*      */       boolean moreResults;
/*      */       do { if (updateCount == -1) {
/* 1102 */           if ((resultSetParameters != null) && (resultSetParameters.size() > rsIndex)) {
/* 1103 */             SqlReturnResultSet declaredRsParam = (SqlReturnResultSet)resultSetParameters.get(rsIndex);
/* 1104 */             returnedResults.putAll(processResultSet(cs.getResultSet(), declaredRsParam));
/* 1105 */             rsIndex++;
/*      */           }
/* 1108 */           else if (!this.skipUndeclaredResults) {
/* 1109 */             String rsName = "#result-set-" + (rsIndex + 1);
/* 1110 */             SqlReturnResultSet undeclaredRsParam = new SqlReturnResultSet(rsName, new ColumnMapRowMapper());
/* 1111 */             if (this.logger.isDebugEnabled()) {
/* 1112 */               this.logger.debug("Added default SqlReturnResultSet parameter named '" + rsName + "'");
/*      */             }
/* 1114 */             returnedResults.putAll(processResultSet(cs.getResultSet(), undeclaredRsParam));
/* 1115 */             rsIndex++;
/*      */           }
/*      */ 
/*      */         }
/* 1120 */         else if ((updateCountParameters != null) && (updateCountParameters.size() > updateIndex)) {
/* 1121 */           SqlReturnUpdateCount ucParam = (SqlReturnUpdateCount)updateCountParameters.get(updateIndex);
/* 1122 */           String declaredUcName = ucParam.getName();
/* 1123 */           returnedResults.put(declaredUcName, Integer.valueOf(updateCount));
/* 1124 */           updateIndex++;
/*      */         }
/* 1127 */         else if (!this.skipUndeclaredResults) {
/* 1128 */           String undeclaredName = "#update-count-" + (updateIndex + 1);
/* 1129 */           if (this.logger.isDebugEnabled()) {
/* 1130 */             this.logger.debug("Added default SqlReturnUpdateCount parameter named '" + undeclaredName + "'");
/*      */           }
/* 1132 */           returnedResults.put(undeclaredName, Integer.valueOf(updateCount));
/* 1133 */           updateIndex++;
/*      */         }
/*      */ 
/* 1137 */         moreResults = cs.getMoreResults();
/* 1138 */         updateCount = cs.getUpdateCount();
/* 1139 */         if (this.logger.isDebugEnabled()) {
/* 1140 */           this.logger.debug("CallableStatement.getUpdateCount() returned " + updateCount);
/*      */         }
/*      */       }
/* 1143 */       while ((moreResults) || (updateCount != -1));
/*      */     }
/* 1145 */     return returnedResults;
/*      */   }
/*      */ 
/*      */   protected Map<String, Object> extractOutputParameters(CallableStatement cs, List<SqlParameter> parameters)
/*      */     throws SQLException
/*      */   {
/* 1157 */     Map returnedResults = new HashMap();
/* 1158 */     int sqlColIndex = 1;
/* 1159 */     for (SqlParameter param : parameters) {
/* 1160 */       if ((param instanceof SqlOutParameter)) {
/* 1161 */         SqlOutParameter outParam = (SqlOutParameter)param;
/* 1162 */         if (outParam.isReturnTypeSupported()) {
/* 1163 */           Object out = outParam.getSqlReturnType().getTypeValue(cs, sqlColIndex, outParam.getSqlType(), outParam.getTypeName());
/*      */ 
/* 1165 */           returnedResults.put(outParam.getName(), out);
/*      */         }
/*      */         else {
/* 1168 */           Object out = cs.getObject(sqlColIndex);
/* 1169 */           if ((out instanceof ResultSet)) {
/* 1170 */             if (outParam.isResultSetSupported()) {
/* 1171 */               returnedResults.putAll(processResultSet((ResultSet)out, outParam));
/*      */             }
/*      */             else {
/* 1174 */               String rsName = outParam.getName();
/* 1175 */               SqlReturnResultSet rsParam = new SqlReturnResultSet(rsName, new ColumnMapRowMapper());
/* 1176 */               returnedResults.putAll(processResultSet((ResultSet)out, rsParam));
/* 1177 */               if (this.logger.isDebugEnabled()) {
/* 1178 */                 this.logger.debug("Added default SqlReturnResultSet parameter named '" + rsName + "'");
/*      */               }
/*      */             }
/*      */           }
/*      */           else {
/* 1183 */             returnedResults.put(outParam.getName(), out);
/*      */           }
/*      */         }
/*      */       }
/* 1187 */       if (!param.isResultsParameter()) {
/* 1188 */         sqlColIndex++;
/*      */       }
/*      */     }
/* 1191 */     return returnedResults;
/*      */   }
/*      */ 
/*      */   protected Map<String, Object> processResultSet(ResultSet rs, ResultSetSupportingSqlParameter param)
/*      */     throws SQLException
/*      */   {
/* 1202 */     if (rs == null) {
/* 1203 */       return Collections.emptyMap();
/*      */     }
/* 1205 */     Map returnedResults = new HashMap();
/*      */     try {
/* 1207 */       ResultSet rsToUse = rs;
/* 1208 */       if (this.nativeJdbcExtractor != null) {
/* 1209 */         rsToUse = this.nativeJdbcExtractor.getNativeResultSet(rs);
/*      */       }
/* 1211 */       if (param.getRowMapper() != null) {
/* 1212 */         RowMapper rowMapper = param.getRowMapper();
/* 1213 */         Object result = new RowMapperResultSetExtractor(rowMapper).extractData(rsToUse);
/* 1214 */         returnedResults.put(param.getName(), result);
/*      */       }
/* 1216 */       else if (param.getRowCallbackHandler() != null) {
/* 1217 */         RowCallbackHandler rch = param.getRowCallbackHandler();
/* 1218 */         new RowCallbackHandlerResultSetExtractor(rch).extractData(rsToUse);
/* 1219 */         returnedResults.put(param.getName(), "ResultSet returned from stored procedure was processed");
/*      */       }
/* 1221 */       else if (param.getResultSetExtractor() != null) {
/* 1222 */         Object result = param.getResultSetExtractor().extractData(rsToUse);
/* 1223 */         returnedResults.put(param.getName(), result);
/*      */       }
/*      */     }
/*      */     finally {
/* 1227 */       JdbcUtils.closeResultSet(rs);
/*      */     }
/* 1229 */     return returnedResults;
/*      */   }
/*      */ 
/*      */   protected RowMapper<Map<String, Object>> getColumnMapRowMapper()
/*      */   {
/* 1243 */     return new ColumnMapRowMapper();
/*      */   }
/*      */ 
/*      */   protected <T> RowMapper<T> getSingleColumnRowMapper(Class<T> requiredType)
/*      */   {
/* 1253 */     return new SingleColumnRowMapper(requiredType);
/*      */   }
/*      */ 
/*      */   protected Map<String, Object> createResultsMap()
/*      */   {
/* 1264 */     if (isResultsMapCaseInsensitive()) {
/* 1265 */       return new LinkedCaseInsensitiveMap();
/*      */     }
/*      */ 
/* 1268 */     return new LinkedHashMap();
/*      */   }
/*      */ 
/*      */   protected void applyStatementSettings(Statement stmt)
/*      */     throws SQLException
/*      */   {
/* 1283 */     int fetchSize = getFetchSize();
/* 1284 */     if (fetchSize > 0) {
/* 1285 */       stmt.setFetchSize(fetchSize);
/*      */     }
/* 1287 */     int maxRows = getMaxRows();
/* 1288 */     if (maxRows > 0) {
/* 1289 */       stmt.setMaxRows(maxRows);
/*      */     }
/* 1291 */     DataSourceUtils.applyTimeout(stmt, getDataSource(), getQueryTimeout());
/*      */   }
/*      */ 
/*      */   protected PreparedStatementSetter newArgPreparedStatementSetter(Object[] args)
/*      */   {
/* 1302 */     return new ArgumentPreparedStatementSetter(args);
/*      */   }
/*      */ 
/*      */   protected PreparedStatementSetter newArgTypePreparedStatementSetter(Object[] args, int[] argTypes)
/*      */   {
/* 1314 */     return new ArgumentTypePreparedStatementSetter(args, argTypes);
/*      */   }
/*      */ 
/*      */   protected void handleWarnings(Statement stmt)
/*      */     throws SQLException
/*      */   {
/* 1325 */     if (isIgnoreWarnings()) {
/* 1326 */       if (this.logger.isDebugEnabled()) {
/* 1327 */         SQLWarning warningToLog = stmt.getWarnings();
/* 1328 */         while (warningToLog != null) {
/* 1329 */           this.logger.debug("SQLWarning ignored: SQL state '" + warningToLog.getSQLState() + "', error code '" + warningToLog.getErrorCode() + "', message [" + warningToLog.getMessage() + "]");
/*      */ 
/* 1331 */           warningToLog = warningToLog.getNextWarning();
/*      */         }
/*      */       }
/*      */     }
/*      */     else
/* 1336 */       handleWarnings(stmt.getWarnings());
/*      */   }
/*      */ 
/*      */   protected void handleWarnings(SQLWarning warning)
/*      */     throws SQLWarningException
/*      */   {
/* 1347 */     if (warning != null)
/* 1348 */       throw new SQLWarningException("Warning not ignored", warning);
/*      */   }
/*      */ 
/*      */   private static String getSql(Object sqlProvider)
/*      */   {
/* 1359 */     if ((sqlProvider instanceof SqlProvider)) {
/* 1360 */       return ((SqlProvider)sqlProvider).getSql();
/*      */     }
/*      */ 
/* 1363 */     return null;
/*      */   }
/*      */ 
/*      */   private static class RowCallbackHandlerResultSetExtractor
/*      */     implements ResultSetExtractor<Object>
/*      */   {
/*      */     private final RowCallbackHandler rch;
/*      */ 
/*      */     public RowCallbackHandlerResultSetExtractor(RowCallbackHandler rch)
/*      */     {
/* 1488 */       this.rch = rch;
/*      */     }
/*      */ 
/*      */     public Object extractData(ResultSet rs) throws SQLException {
/* 1492 */       while (rs.next()) {
/* 1493 */         this.rch.processRow(rs);
/*      */       }
/* 1495 */       return null;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SimpleCallableStatementCreator
/*      */     implements CallableStatementCreator, SqlProvider
/*      */   {
/*      */     private final String callString;
/*      */ 
/*      */     public SimpleCallableStatementCreator(String callString)
/*      */     {
/* 1464 */       Assert.notNull(callString, "Call string must not be null");
/* 1465 */       this.callString = callString;
/*      */     }
/*      */ 
/*      */     public CallableStatement createCallableStatement(Connection con) throws SQLException {
/* 1469 */       return con.prepareCall(this.callString);
/*      */     }
/*      */ 
/*      */     public String getSql() {
/* 1473 */       return this.callString;
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SimplePreparedStatementCreator
/*      */     implements PreparedStatementCreator, SqlProvider
/*      */   {
/*      */     private final String sql;
/*      */ 
/*      */     public SimplePreparedStatementCreator(String sql)
/*      */     {
/* 1442 */       Assert.notNull(sql, "SQL must not be null");
/* 1443 */       this.sql = sql;
/*      */     }
/*      */ 
/*      */     public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
/* 1447 */       return con.prepareStatement(this.sql);
/*      */     }
/*      */ 
/*      */     public String getSql() {
/* 1451 */       return this.sql;
/*      */     }
/*      */   }
/*      */ 
/*      */   private class CloseSuppressingInvocationHandler
/*      */     implements InvocationHandler
/*      */   {
/*      */     private final Connection target;
/*      */ 
/*      */     public CloseSuppressingInvocationHandler(Connection target)
/*      */     {
/* 1378 */       this.target = target;
/*      */     }
/*      */ 
/*      */     public Object invoke(Object proxy, Method method, Object[] args)
/*      */       throws Throwable
/*      */     {
/* 1385 */       if (method.getName().equals("equals"))
/*      */       {
/* 1387 */         return Boolean.valueOf(proxy == args[0]);
/*      */       }
/* 1389 */       if (method.getName().equals("hashCode"))
/*      */       {
/* 1391 */         return Integer.valueOf(System.identityHashCode(proxy));
/*      */       }
/* 1393 */       if (method.getName().equals("unwrap")) {
/* 1394 */         if (((Class)args[0]).isInstance(proxy)) {
/* 1395 */           return proxy;
/*      */         }
/*      */       }
/* 1398 */       else if (method.getName().equals("isWrapperFor")) {
/* 1399 */         if (((Class)args[0]).isInstance(proxy))
/* 1400 */           return Boolean.valueOf(true);
/*      */       }
/*      */       else {
/* 1403 */         if (method.getName().equals("close"))
/*      */         {
/* 1405 */           return null;
/*      */         }
/* 1407 */         if (method.getName().equals("isClosed")) {
/* 1408 */           return Boolean.valueOf(false);
/*      */         }
/* 1410 */         if (method.getName().equals("getTargetConnection"))
/*      */         {
/* 1412 */           return this.target;
/*      */         }
/*      */       }
/*      */       try
/*      */       {
/* 1417 */         Object retVal = method.invoke(this.target, args);
/*      */ 
/* 1421 */         if ((retVal instanceof Statement)) {
/* 1422 */           JdbcTemplate.this.applyStatementSettings((Statement)retVal);
/*      */         }
/*      */ 
/* 1425 */         return retVal;
/*      */       }
/*      */       catch (InvocationTargetException ex) {
/* 1428 */         throw ex.getTargetException();
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.JdbcTemplate
 * JD-Core Version:    0.6.1
 */