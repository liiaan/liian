/*    */ package org.springframework.jdbc.datasource.init;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.beans.factory.DisposableBean;
/*    */ import org.springframework.beans.factory.InitializingBean;
/*    */ 
/*    */ public class DataSourceInitializer
/*    */   implements InitializingBean, DisposableBean
/*    */ {
/*    */   private DataSource dataSource;
/*    */   private DatabasePopulator databasePopulator;
/*    */   private DatabasePopulator databaseCleaner;
/* 39 */   private boolean enabled = true;
/*    */ 
/*    */   public void setDataSource(DataSource dataSource)
/*    */   {
/* 48 */     this.dataSource = dataSource;
/*    */   }
/*    */ 
/*    */   public void setDatabasePopulator(DatabasePopulator databasePopulator)
/*    */   {
/* 57 */     this.databasePopulator = databasePopulator;
/*    */   }
/*    */ 
/*    */   public void setDatabaseCleaner(DatabasePopulator databaseCleaner)
/*    */   {
/* 66 */     this.databaseCleaner = databaseCleaner;
/*    */   }
/*    */ 
/*    */   public void setEnabled(boolean enabled)
/*    */   {
/* 74 */     this.enabled = enabled;
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 82 */     if ((this.databasePopulator != null) && (this.enabled))
/* 83 */       DatabasePopulatorUtils.execute(this.databasePopulator, this.dataSource);
/*    */   }
/*    */ 
/*    */   public void destroy()
/*    */   {
/* 91 */     if ((this.databaseCleaner != null) && (this.enabled))
/* 92 */       DatabasePopulatorUtils.execute(this.databaseCleaner, this.dataSource);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.init.DataSourceInitializer
 * JD-Core Version:    0.6.1
 */