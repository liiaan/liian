/*     */ package org.springframework.jdbc.support.lob;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ 
/*     */ public class TemporaryLobCreator
/*     */   implements LobCreator
/*     */ {
/*  51 */   protected static final Log logger = LogFactory.getLog(TemporaryLobCreator.class);
/*     */ 
/*  53 */   private final Set<Blob> temporaryBlobs = new LinkedHashSet(1);
/*     */ 
/*  55 */   private final Set<Clob> temporaryClobs = new LinkedHashSet(1);
/*     */ 
/*     */   public void setBlobAsBytes(PreparedStatement ps, int paramIndex, byte[] content)
/*     */     throws SQLException
/*     */   {
/*  61 */     Blob blob = ps.getConnection().createBlob();
/*  62 */     blob.setBytes(1L, content);
/*     */ 
/*  64 */     this.temporaryBlobs.add(blob);
/*  65 */     ps.setBlob(paramIndex, blob);
/*     */ 
/*  67 */     if (logger.isDebugEnabled())
/*  68 */       logger.debug(content != null ? "Copied bytes into temporary BLOB with length " + content.length : "Set BLOB to null");
/*     */   }
/*     */ 
/*     */   public void setBlobAsBinaryStream(PreparedStatement ps, int paramIndex, InputStream binaryStream, int contentLength)
/*     */     throws SQLException
/*     */   {
/*  77 */     Blob blob = ps.getConnection().createBlob();
/*     */     try {
/*  79 */       FileCopyUtils.copy(binaryStream, blob.setBinaryStream(1L));
/*     */     }
/*     */     catch (IOException ex) {
/*  82 */       throw new DataAccessResourceFailureException("Could not copy into LOB stream", ex);
/*     */     }
/*     */ 
/*  85 */     this.temporaryBlobs.add(blob);
/*  86 */     ps.setBlob(paramIndex, blob);
/*     */ 
/*  88 */     if (logger.isDebugEnabled())
/*  89 */       logger.debug(binaryStream != null ? "Copied binary stream into temporary BLOB with length " + contentLength : "Set BLOB to null");
/*     */   }
/*     */ 
/*     */   public void setClobAsString(PreparedStatement ps, int paramIndex, String content)
/*     */     throws SQLException
/*     */   {
/*  98 */     Clob clob = ps.getConnection().createClob();
/*  99 */     clob.setString(1L, content);
/*     */ 
/* 101 */     this.temporaryClobs.add(clob);
/* 102 */     ps.setClob(paramIndex, clob);
/*     */ 
/* 104 */     if (logger.isDebugEnabled())
/* 105 */       logger.debug(content != null ? "Copied string into temporary CLOB with length " + content.length() : "Set CLOB to null");
/*     */   }
/*     */ 
/*     */   public void setClobAsAsciiStream(PreparedStatement ps, int paramIndex, InputStream asciiStream, int contentLength)
/*     */     throws SQLException
/*     */   {
/* 114 */     Clob clob = ps.getConnection().createClob();
/*     */     try {
/* 116 */       FileCopyUtils.copy(asciiStream, clob.setAsciiStream(1L));
/*     */     }
/*     */     catch (IOException ex) {
/* 119 */       throw new DataAccessResourceFailureException("Could not copy into LOB stream", ex);
/*     */     }
/*     */ 
/* 122 */     this.temporaryClobs.add(clob);
/* 123 */     ps.setClob(paramIndex, clob);
/*     */ 
/* 125 */     if (logger.isDebugEnabled())
/* 126 */       logger.debug(asciiStream != null ? "Copied ASCII stream into temporary CLOB with length " + contentLength : "Set CLOB to null");
/*     */   }
/*     */ 
/*     */   public void setClobAsCharacterStream(PreparedStatement ps, int paramIndex, Reader characterStream, int contentLength)
/*     */     throws SQLException
/*     */   {
/* 136 */     Clob clob = ps.getConnection().createClob();
/*     */     try {
/* 138 */       FileCopyUtils.copy(characterStream, clob.setCharacterStream(1L));
/*     */     }
/*     */     catch (IOException ex) {
/* 141 */       throw new DataAccessResourceFailureException("Could not copy into LOB stream", ex);
/*     */     }
/*     */ 
/* 144 */     this.temporaryClobs.add(clob);
/* 145 */     ps.setClob(paramIndex, clob);
/*     */ 
/* 147 */     if (logger.isDebugEnabled())
/* 148 */       logger.debug(characterStream != null ? "Copied character stream into temporary CLOB with length " + contentLength : "Set CLOB to null");
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/*     */     try
/*     */     {
/* 156 */       for (Blob blob : this.temporaryBlobs) {
/* 157 */         blob.free();
/*     */       }
/* 159 */       for (Clob clob : this.temporaryClobs)
/* 160 */         clob.free();
/*     */     }
/*     */     catch (SQLException ex)
/*     */     {
/* 164 */       logger.error("Could not free LOB", ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.lob.TemporaryLobCreator
 * JD-Core Version:    0.6.1
 */