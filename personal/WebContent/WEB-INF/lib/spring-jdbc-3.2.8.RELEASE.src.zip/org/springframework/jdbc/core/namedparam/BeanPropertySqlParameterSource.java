/*     */ package org.springframework.jdbc.core.namedparam;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.springframework.beans.BeanWrapper;
/*     */ import org.springframework.beans.NotReadablePropertyException;
/*     */ import org.springframework.beans.PropertyAccessorFactory;
/*     */ import org.springframework.jdbc.core.StatementCreatorUtils;
/*     */ 
/*     */ public class BeanPropertySqlParameterSource extends AbstractSqlParameterSource
/*     */ {
/*     */   private final BeanWrapper beanWrapper;
/*     */   private String[] propertyNames;
/*     */ 
/*     */   public BeanPropertySqlParameterSource(Object object)
/*     */   {
/*  54 */     this.beanWrapper = PropertyAccessorFactory.forBeanPropertyAccess(object);
/*     */   }
/*     */ 
/*     */   public boolean hasValue(String paramName)
/*     */   {
/*  59 */     return this.beanWrapper.isReadableProperty(paramName);
/*     */   }
/*     */ 
/*     */   public Object getValue(String paramName) throws IllegalArgumentException {
/*     */     try {
/*  64 */       return this.beanWrapper.getPropertyValue(paramName);
/*     */     }
/*     */     catch (NotReadablePropertyException ex) {
/*  67 */       throw new IllegalArgumentException(ex.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public String[] getReadablePropertyNames()
/*     */   {
/*  77 */     if (this.propertyNames == null) {
/*  78 */       List names = new ArrayList();
/*  79 */       PropertyDescriptor[] props = this.beanWrapper.getPropertyDescriptors();
/*  80 */       for (PropertyDescriptor pd : props) {
/*  81 */         if (this.beanWrapper.isReadableProperty(pd.getName())) {
/*  82 */           names.add(pd.getName());
/*     */         }
/*     */       }
/*  85 */       this.propertyNames = ((String[])names.toArray(new String[names.size()]));
/*     */     }
/*  87 */     return this.propertyNames;
/*     */   }
/*     */ 
/*     */   public int getSqlType(String paramName)
/*     */   {
/*  96 */     int sqlType = super.getSqlType(paramName);
/*  97 */     if (sqlType != -2147483648) {
/*  98 */       return sqlType;
/*     */     }
/* 100 */     Class propType = this.beanWrapper.getPropertyType(paramName);
/* 101 */     return StatementCreatorUtils.javaTypeToSqlParameterType(propType);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource
 * JD-Core Version:    0.6.1
 */