package org.springframework.jdbc.datasource.embedded;

import javax.sql.DataSource;

public abstract interface DataSourceFactory
{
  public abstract ConnectionProperties getConnectionProperties();

  public abstract DataSource getDataSource();
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.embedded.DataSourceFactory
 * JD-Core Version:    0.6.1
 */