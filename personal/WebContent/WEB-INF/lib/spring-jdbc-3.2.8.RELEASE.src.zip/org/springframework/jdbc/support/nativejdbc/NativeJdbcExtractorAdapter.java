/*     */ package org.springframework.jdbc.support.nativejdbc;
/*     */ 
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*     */ 
/*     */ public abstract class NativeJdbcExtractorAdapter
/*     */   implements NativeJdbcExtractor
/*     */ {
/*     */   public boolean isNativeConnectionNecessaryForNativeStatements()
/*     */   {
/*  65 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isNativeConnectionNecessaryForNativePreparedStatements()
/*     */   {
/*  72 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isNativeConnectionNecessaryForNativeCallableStatements()
/*     */   {
/*  79 */     return false;
/*     */   }
/*     */ 
/*     */   public Connection getNativeConnection(Connection con)
/*     */     throws SQLException
/*     */   {
/*  95 */     if (con == null) {
/*  96 */       return null;
/*     */     }
/*  98 */     Connection targetCon = DataSourceUtils.getTargetConnection(con);
/*  99 */     Connection nativeCon = doGetNativeConnection(targetCon);
/* 100 */     if (nativeCon == targetCon)
/*     */     {
/* 104 */       DatabaseMetaData metaData = targetCon.getMetaData();
/*     */ 
/* 107 */       if (metaData != null) {
/* 108 */         Connection metaCon = metaData.getConnection();
/* 109 */         if ((metaCon != null) && (metaCon != targetCon))
/*     */         {
/* 112 */           nativeCon = doGetNativeConnection(metaCon);
/*     */         }
/*     */       }
/*     */     }
/* 116 */     return nativeCon;
/*     */   }
/*     */ 
/*     */   protected Connection doGetNativeConnection(Connection con)
/*     */     throws SQLException
/*     */   {
/* 123 */     return con;
/*     */   }
/*     */ 
/*     */   public Connection getNativeConnectionFromStatement(Statement stmt)
/*     */     throws SQLException
/*     */   {
/* 132 */     if (stmt == null) {
/* 133 */       return null;
/*     */     }
/* 135 */     return getNativeConnection(stmt.getConnection());
/*     */   }
/*     */ 
/*     */   public Statement getNativeStatement(Statement stmt)
/*     */     throws SQLException
/*     */   {
/* 142 */     return stmt;
/*     */   }
/*     */ 
/*     */   public PreparedStatement getNativePreparedStatement(PreparedStatement ps)
/*     */     throws SQLException
/*     */   {
/* 149 */     return ps;
/*     */   }
/*     */ 
/*     */   public CallableStatement getNativeCallableStatement(CallableStatement cs)
/*     */     throws SQLException
/*     */   {
/* 156 */     return cs;
/*     */   }
/*     */ 
/*     */   public ResultSet getNativeResultSet(ResultSet rs)
/*     */     throws SQLException
/*     */   {
/* 163 */     return rs;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.nativejdbc.NativeJdbcExtractorAdapter
 * JD-Core Version:    0.6.1
 */