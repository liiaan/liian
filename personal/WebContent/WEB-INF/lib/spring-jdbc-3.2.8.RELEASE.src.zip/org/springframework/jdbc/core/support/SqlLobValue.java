/*     */ package org.springframework.jdbc.core.support;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import org.springframework.jdbc.core.DisposableSqlTypeValue;
/*     */ import org.springframework.jdbc.support.lob.DefaultLobHandler;
/*     */ import org.springframework.jdbc.support.lob.LobCreator;
/*     */ import org.springframework.jdbc.support.lob.LobHandler;
/*     */ 
/*     */ public class SqlLobValue
/*     */   implements DisposableSqlTypeValue
/*     */ {
/*     */   private final Object content;
/*     */   private final int length;
/*     */   private final LobCreator lobCreator;
/*     */ 
/*     */   public SqlLobValue(byte[] bytes)
/*     */   {
/*  86 */     this(bytes, new DefaultLobHandler());
/*     */   }
/*     */ 
/*     */   public SqlLobValue(byte[] bytes, LobHandler lobHandler)
/*     */   {
/*  95 */     this.content = bytes;
/*  96 */     this.length = (bytes != null ? bytes.length : 0);
/*  97 */     this.lobCreator = lobHandler.getLobCreator();
/*     */   }
/*     */ 
/*     */   public SqlLobValue(String content)
/*     */   {
/* 107 */     this(content, new DefaultLobHandler());
/*     */   }
/*     */ 
/*     */   public SqlLobValue(String content, LobHandler lobHandler)
/*     */   {
/* 116 */     this.content = content;
/* 117 */     this.length = (content != null ? content.length() : 0);
/* 118 */     this.lobCreator = lobHandler.getLobCreator();
/*     */   }
/*     */ 
/*     */   public SqlLobValue(InputStream stream, int length)
/*     */   {
/* 129 */     this(stream, length, new DefaultLobHandler());
/*     */   }
/*     */ 
/*     */   public SqlLobValue(InputStream stream, int length, LobHandler lobHandler)
/*     */   {
/* 139 */     this.content = stream;
/* 140 */     this.length = length;
/* 141 */     this.lobCreator = lobHandler.getLobCreator();
/*     */   }
/*     */ 
/*     */   public SqlLobValue(Reader reader, int length)
/*     */   {
/* 152 */     this(reader, length, new DefaultLobHandler());
/*     */   }
/*     */ 
/*     */   public SqlLobValue(Reader reader, int length, LobHandler lobHandler)
/*     */   {
/* 162 */     this.content = reader;
/* 163 */     this.length = length;
/* 164 */     this.lobCreator = lobHandler.getLobCreator();
/*     */   }
/*     */ 
/*     */   public void setTypeValue(PreparedStatement ps, int paramIndex, int sqlType, String typeName)
/*     */     throws SQLException
/*     */   {
/* 173 */     if (sqlType == 2004) {
/* 174 */       if (((this.content instanceof byte[])) || (this.content == null)) {
/* 175 */         this.lobCreator.setBlobAsBytes(ps, paramIndex, (byte[])this.content);
/*     */       }
/* 177 */       else if ((this.content instanceof String)) {
/* 178 */         this.lobCreator.setBlobAsBytes(ps, paramIndex, ((String)this.content).getBytes());
/*     */       }
/* 180 */       else if ((this.content instanceof InputStream)) {
/* 181 */         this.lobCreator.setBlobAsBinaryStream(ps, paramIndex, (InputStream)this.content, this.length);
/*     */       }
/*     */       else {
/* 184 */         throw new IllegalArgumentException("Content type [" + this.content.getClass().getName() + "] not supported for BLOB columns");
/*     */       }
/*     */ 
/*     */     }
/* 188 */     else if (sqlType == 2005) {
/* 189 */       if (((this.content instanceof String)) || (this.content == null)) {
/* 190 */         this.lobCreator.setClobAsString(ps, paramIndex, (String)this.content);
/*     */       }
/* 192 */       else if ((this.content instanceof InputStream)) {
/* 193 */         this.lobCreator.setClobAsAsciiStream(ps, paramIndex, (InputStream)this.content, this.length);
/*     */       }
/* 195 */       else if ((this.content instanceof Reader)) {
/* 196 */         this.lobCreator.setClobAsCharacterStream(ps, paramIndex, (Reader)this.content, this.length);
/*     */       }
/*     */       else {
/* 199 */         throw new IllegalArgumentException("Content type [" + this.content.getClass().getName() + "] not supported for CLOB columns");
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 204 */       throw new IllegalArgumentException("SqlLobValue only supports SQL types BLOB and CLOB");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void cleanup()
/*     */   {
/* 212 */     this.lobCreator.close();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.support.SqlLobValue
 * JD-Core Version:    0.6.1
 */