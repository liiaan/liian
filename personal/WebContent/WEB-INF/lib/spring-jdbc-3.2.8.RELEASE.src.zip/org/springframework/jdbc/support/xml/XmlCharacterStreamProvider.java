package org.springframework.jdbc.support.xml;

import java.io.IOException;
import java.io.Writer;

public abstract interface XmlCharacterStreamProvider
{
  public abstract void provideXml(Writer paramWriter)
    throws IOException;
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.xml.XmlCharacterStreamProvider
 * JD-Core Version:    0.6.1
 */