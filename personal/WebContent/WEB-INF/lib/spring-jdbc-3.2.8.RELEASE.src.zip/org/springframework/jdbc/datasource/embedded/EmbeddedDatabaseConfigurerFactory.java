/*    */ package org.springframework.jdbc.datasource.embedded;
/*    */ 
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ final class EmbeddedDatabaseConfigurerFactory
/*    */ {
/*    */   public static EmbeddedDatabaseConfigurer getConfigurer(EmbeddedDatabaseType type)
/*    */     throws IllegalStateException
/*    */   {
/* 32 */     Assert.notNull(type, "EmbeddedDatabaseType is required");
/*    */     try {
/* 34 */       switch (1.$SwitchMap$org$springframework$jdbc$datasource$embedded$EmbeddedDatabaseType[type.ordinal()]) {
/*    */       case 1:
/* 36 */         return HsqlEmbeddedDatabaseConfigurer.getInstance();
/*    */       case 2:
/* 38 */         return H2EmbeddedDatabaseConfigurer.getInstance();
/*    */       case 3:
/* 40 */         return DerbyEmbeddedDatabaseConfigurer.getInstance();
/*    */       }
/* 42 */       throw new UnsupportedOperationException("Other embedded database types not yet supported");
/*    */     }
/*    */     catch (ClassNotFoundException ex)
/*    */     {
/* 46 */       throw new IllegalStateException("Driver for test database type [" + type + "] is not available in the classpath", ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseConfigurerFactory
 * JD-Core Version:    0.6.1
 */