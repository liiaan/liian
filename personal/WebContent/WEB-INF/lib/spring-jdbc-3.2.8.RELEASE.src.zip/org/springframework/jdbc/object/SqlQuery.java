/*     */ package org.springframework.jdbc.object;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.support.DataAccessUtils;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
/*     */ import org.springframework.jdbc.core.namedparam.NamedParameterUtils;
/*     */ import org.springframework.jdbc.core.namedparam.ParsedSql;
/*     */ 
/*     */ public abstract class SqlQuery<T> extends SqlOperation
/*     */ {
/*  58 */   private int rowsExpected = 0;
/*     */ 
/*     */   public SqlQuery()
/*     */   {
/*     */   }
/*     */ 
/*     */   public SqlQuery(DataSource ds, String sql)
/*     */   {
/*  76 */     setDataSource(ds);
/*  77 */     setSql(sql);
/*     */   }
/*     */ 
/*     */   public void setRowsExpected(int rowsExpected)
/*     */   {
/*  87 */     this.rowsExpected = rowsExpected;
/*     */   }
/*     */ 
/*     */   public int getRowsExpected()
/*     */   {
/*  94 */     return this.rowsExpected;
/*     */   }
/*     */ 
/*     */   public List<T> execute(Object[] params, Map context)
/*     */     throws DataAccessException
/*     */   {
/* 110 */     validateParameters(params);
/* 111 */     RowMapper rowMapper = newRowMapper(params, context);
/* 112 */     return getJdbcTemplate().query(newPreparedStatementCreator(params), rowMapper);
/*     */   }
/*     */ 
/*     */   public List<T> execute(Object[] params)
/*     */     throws DataAccessException
/*     */   {
/* 122 */     return execute(params, null);
/*     */   }
/*     */ 
/*     */   public List<T> execute(Map context)
/*     */     throws DataAccessException
/*     */   {
/* 130 */     return execute((Object[])null, context);
/*     */   }
/*     */ 
/*     */   public List<T> execute()
/*     */     throws DataAccessException
/*     */   {
/* 137 */     return execute((Object[])null);
/*     */   }
/*     */ 
/*     */   public List<T> execute(int p1, Map context)
/*     */     throws DataAccessException
/*     */   {
/* 146 */     return execute(new Object[] { Integer.valueOf(p1) }, context);
/*     */   }
/*     */ 
/*     */   public List<T> execute(int p1)
/*     */     throws DataAccessException
/*     */   {
/* 154 */     return execute(p1, null);
/*     */   }
/*     */ 
/*     */   public List<T> execute(int p1, int p2, Map context)
/*     */     throws DataAccessException
/*     */   {
/* 164 */     return execute(new Object[] { Integer.valueOf(p1), Integer.valueOf(p2) }, context);
/*     */   }
/*     */ 
/*     */   public List<T> execute(int p1, int p2)
/*     */     throws DataAccessException
/*     */   {
/* 173 */     return execute(p1, p2, null);
/*     */   }
/*     */ 
/*     */   public List<T> execute(long p1, Map context)
/*     */     throws DataAccessException
/*     */   {
/* 182 */     return execute(new Object[] { Long.valueOf(p1) }, context);
/*     */   }
/*     */ 
/*     */   public List<T> execute(long p1)
/*     */     throws DataAccessException
/*     */   {
/* 190 */     return execute(p1, null);
/*     */   }
/*     */ 
/*     */   public List<T> execute(String p1, Map context)
/*     */     throws DataAccessException
/*     */   {
/* 199 */     return execute(new Object[] { p1 }, context);
/*     */   }
/*     */ 
/*     */   public List<T> execute(String p1)
/*     */     throws DataAccessException
/*     */   {
/* 207 */     return execute(p1, null);
/*     */   }
/*     */ 
/*     */   public List<T> executeByNamedParam(Map<String, ?> paramMap, Map context)
/*     */     throws DataAccessException
/*     */   {
/* 223 */     validateNamedParameters(paramMap);
/* 224 */     ParsedSql parsedSql = getParsedSql();
/* 225 */     MapSqlParameterSource paramSource = new MapSqlParameterSource(paramMap);
/* 226 */     String sqlToUse = NamedParameterUtils.substituteNamedParameters(parsedSql, paramSource);
/* 227 */     Object[] params = NamedParameterUtils.buildValueArray(parsedSql, paramSource, getDeclaredParameters());
/* 228 */     RowMapper rowMapper = newRowMapper(params, context);
/* 229 */     return getJdbcTemplate().query(newPreparedStatementCreator(sqlToUse, params), rowMapper);
/*     */   }
/*     */ 
/*     */   public List<T> executeByNamedParam(Map<String, ?> paramMap)
/*     */     throws DataAccessException
/*     */   {
/* 239 */     return executeByNamedParam(paramMap, null);
/*     */   }
/*     */ 
/*     */   public T findObject(Object[] params, Map context)
/*     */     throws DataAccessException
/*     */   {
/* 252 */     List results = execute(params, context);
/* 253 */     return DataAccessUtils.singleResult(results);
/*     */   }
/*     */ 
/*     */   public T findObject(Object[] params)
/*     */     throws DataAccessException
/*     */   {
/* 260 */     return findObject(params, null);
/*     */   }
/*     */ 
/*     */   public T findObject(int p1, Map context)
/*     */     throws DataAccessException
/*     */   {
/* 268 */     return findObject(new Object[] { Integer.valueOf(p1) }, context);
/*     */   }
/*     */ 
/*     */   public T findObject(int p1)
/*     */     throws DataAccessException
/*     */   {
/* 275 */     return findObject(p1, null);
/*     */   }
/*     */ 
/*     */   public T findObject(int p1, int p2, Map context)
/*     */     throws DataAccessException
/*     */   {
/* 283 */     return findObject(new Object[] { Integer.valueOf(p1), Integer.valueOf(p2) }, context);
/*     */   }
/*     */ 
/*     */   public T findObject(int p1, int p2)
/*     */     throws DataAccessException
/*     */   {
/* 290 */     return findObject(p1, p2, null);
/*     */   }
/*     */ 
/*     */   public T findObject(long p1, Map context)
/*     */     throws DataAccessException
/*     */   {
/* 298 */     return findObject(new Object[] { Long.valueOf(p1) }, context);
/*     */   }
/*     */ 
/*     */   public T findObject(long p1)
/*     */     throws DataAccessException
/*     */   {
/* 305 */     return findObject(p1, null);
/*     */   }
/*     */ 
/*     */   public T findObject(String p1, Map context)
/*     */     throws DataAccessException
/*     */   {
/* 313 */     return findObject(new Object[] { p1 }, context);
/*     */   }
/*     */ 
/*     */   public T findObject(String p1)
/*     */     throws DataAccessException
/*     */   {
/* 320 */     return findObject(p1, null);
/*     */   }
/*     */ 
/*     */   public T findObjectByNamedParam(Map<String, ?> paramMap, Map context)
/*     */     throws DataAccessException
/*     */   {
/* 335 */     List results = executeByNamedParam(paramMap, context);
/* 336 */     return DataAccessUtils.singleResult(results);
/*     */   }
/*     */ 
/*     */   public T findObjectByNamedParam(Map<String, ?> paramMap)
/*     */     throws DataAccessException
/*     */   {
/* 346 */     return findObjectByNamedParam(paramMap, null);
/*     */   }
/*     */ 
/*     */   protected abstract RowMapper<T> newRowMapper(Object[] paramArrayOfObject, Map paramMap);
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.object.SqlQuery
 * JD-Core Version:    0.6.1
 */