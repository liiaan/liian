/*    */ package org.springframework.jdbc.support.lob;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.Reader;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ public abstract class AbstractLobHandler
/*    */   implements LobHandler
/*    */ {
/*    */   public byte[] getBlobAsBytes(ResultSet rs, String columnName)
/*    */     throws SQLException
/*    */   {
/* 37 */     return getBlobAsBytes(rs, rs.findColumn(columnName));
/*    */   }
/*    */ 
/*    */   public InputStream getBlobAsBinaryStream(ResultSet rs, String columnName) throws SQLException {
/* 41 */     return getBlobAsBinaryStream(rs, rs.findColumn(columnName));
/*    */   }
/*    */ 
/*    */   public String getClobAsString(ResultSet rs, String columnName) throws SQLException {
/* 45 */     return getClobAsString(rs, rs.findColumn(columnName));
/*    */   }
/*    */ 
/*    */   public InputStream getClobAsAsciiStream(ResultSet rs, String columnName) throws SQLException {
/* 49 */     return getClobAsAsciiStream(rs, rs.findColumn(columnName));
/*    */   }
/*    */ 
/*    */   public Reader getClobAsCharacterStream(ResultSet rs, String columnName) throws SQLException {
/* 53 */     return getClobAsCharacterStream(rs, rs.findColumn(columnName));
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.lob.AbstractLobHandler
 * JD-Core Version:    0.6.1
 */