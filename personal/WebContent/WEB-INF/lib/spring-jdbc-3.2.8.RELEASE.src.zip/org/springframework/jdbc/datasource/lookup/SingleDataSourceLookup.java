/*    */ package org.springframework.jdbc.datasource.lookup;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class SingleDataSourceLookup
/*    */   implements DataSourceLookup
/*    */ {
/*    */   private final DataSource dataSource;
/*    */ 
/*    */   public SingleDataSourceLookup(DataSource dataSource)
/*    */   {
/* 40 */     Assert.notNull(dataSource, "DataSource must not be null");
/* 41 */     this.dataSource = dataSource;
/*    */   }
/*    */ 
/*    */   public DataSource getDataSource(String dataSourceName)
/*    */   {
/* 46 */     return this.dataSource;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.lookup.SingleDataSourceLookup
 * JD-Core Version:    0.6.1
 */