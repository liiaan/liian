package org.springframework.jdbc.core;

import java.sql.ResultSet;
import java.sql.SQLException;

public abstract interface RowCallbackHandler
{
  public abstract void processRow(ResultSet paramResultSet)
    throws SQLException;
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.RowCallbackHandler
 * JD-Core Version:    0.6.1
 */