/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ public class SqlOutParameter extends ResultSetSupportingSqlParameter
/*     */ {
/*     */   private SqlReturnType sqlReturnType;
/*     */ 
/*     */   public SqlOutParameter(String name, int sqlType)
/*     */   {
/*  44 */     super(name, sqlType);
/*     */   }
/*     */ 
/*     */   public SqlOutParameter(String name, int sqlType, int scale)
/*     */   {
/*  55 */     super(name, sqlType, scale);
/*     */   }
/*     */ 
/*     */   public SqlOutParameter(String name, int sqlType, String typeName)
/*     */   {
/*  65 */     super(name, sqlType, typeName);
/*     */   }
/*     */ 
/*     */   public SqlOutParameter(String name, int sqlType, String typeName, SqlReturnType sqlReturnType)
/*     */   {
/*  76 */     super(name, sqlType, typeName);
/*  77 */     this.sqlReturnType = sqlReturnType;
/*     */   }
/*     */ 
/*     */   public SqlOutParameter(String name, int sqlType, ResultSetExtractor rse)
/*     */   {
/*  87 */     super(name, sqlType, rse);
/*     */   }
/*     */ 
/*     */   public SqlOutParameter(String name, int sqlType, RowCallbackHandler rch)
/*     */   {
/*  97 */     super(name, sqlType, rch);
/*     */   }
/*     */ 
/*     */   public SqlOutParameter(String name, int sqlType, RowMapper rm)
/*     */   {
/* 107 */     super(name, sqlType, rm);
/*     */   }
/*     */ 
/*     */   public SqlReturnType getSqlReturnType()
/*     */   {
/* 115 */     return this.sqlReturnType;
/*     */   }
/*     */ 
/*     */   public boolean isReturnTypeSupported()
/*     */   {
/* 122 */     return this.sqlReturnType != null;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.SqlOutParameter
 * JD-Core Version:    0.6.1
 */