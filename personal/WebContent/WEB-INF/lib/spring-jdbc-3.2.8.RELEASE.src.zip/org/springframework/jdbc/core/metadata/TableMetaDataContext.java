/*     */ package org.springframework.jdbc.core.metadata;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.jdbc.support.nativejdbc.NativeJdbcExtractor;
/*     */ 
/*     */ public class TableMetaDataContext
/*     */ {
/*  48 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private String tableName;
/*     */   private String catalogName;
/*     */   private String schemaName;
/*  60 */   private List<String> tableColumns = new ArrayList();
/*     */ 
/*  63 */   private boolean accessTableColumnMetaData = true;
/*     */ 
/*  66 */   private boolean overrideIncludeSynonymsDefault = false;
/*     */   private TableMetaDataProvider metaDataProvider;
/*  72 */   private boolean generatedKeyColumnsUsed = false;
/*     */   NativeJdbcExtractor nativeJdbcExtractor;
/*     */ 
/*     */   public void setTableName(String tableName)
/*     */   {
/*  82 */     this.tableName = tableName;
/*     */   }
/*     */ 
/*     */   public String getTableName()
/*     */   {
/*  89 */     return this.tableName;
/*     */   }
/*     */ 
/*     */   public void setCatalogName(String catalogName)
/*     */   {
/*  96 */     this.catalogName = catalogName;
/*     */   }
/*     */ 
/*     */   public String getCatalogName()
/*     */   {
/* 103 */     return this.catalogName;
/*     */   }
/*     */ 
/*     */   public void setSchemaName(String schemaName)
/*     */   {
/* 110 */     this.schemaName = schemaName;
/*     */   }
/*     */ 
/*     */   public String getSchemaName()
/*     */   {
/* 117 */     return this.schemaName;
/*     */   }
/*     */ 
/*     */   public void setAccessTableColumnMetaData(boolean accessTableColumnMetaData)
/*     */   {
/* 124 */     this.accessTableColumnMetaData = accessTableColumnMetaData;
/*     */   }
/*     */ 
/*     */   public boolean isAccessTableColumnMetaData()
/*     */   {
/* 131 */     return this.accessTableColumnMetaData;
/*     */   }
/*     */ 
/*     */   public void setOverrideIncludeSynonymsDefault(boolean override)
/*     */   {
/* 139 */     this.overrideIncludeSynonymsDefault = override;
/*     */   }
/*     */ 
/*     */   public boolean isOverrideIncludeSynonymsDefault()
/*     */   {
/* 146 */     return this.overrideIncludeSynonymsDefault;
/*     */   }
/*     */ 
/*     */   public List<String> getTableColumns()
/*     */   {
/* 153 */     return this.tableColumns;
/*     */   }
/*     */ 
/*     */   public boolean isGetGeneratedKeysSupported()
/*     */   {
/* 161 */     return this.metaDataProvider.isGetGeneratedKeysSupported();
/*     */   }
/*     */ 
/*     */   public boolean isGetGeneratedKeysSimulated()
/*     */   {
/* 170 */     return this.metaDataProvider.isGetGeneratedKeysSimulated();
/*     */   }
/*     */ 
/*     */   public String getSimulationQueryForGetGeneratedKey(String tableName, String keyColumnName)
/*     */   {
/* 179 */     return this.metaDataProvider.getSimpleQueryForGetGeneratedKey(tableName, keyColumnName);
/*     */   }
/*     */ 
/*     */   public boolean isGeneratedKeysColumnNameArraySupported()
/*     */   {
/* 187 */     return this.metaDataProvider.isGeneratedKeysColumnNameArraySupported();
/*     */   }
/*     */ 
/*     */   public void setNativeJdbcExtractor(NativeJdbcExtractor nativeJdbcExtractor)
/*     */   {
/* 194 */     this.nativeJdbcExtractor = nativeJdbcExtractor;
/*     */   }
/*     */ 
/*     */   public void processMetaData(DataSource dataSource, List<String> declaredColumns, String[] generatedKeyNames)
/*     */   {
/* 205 */     this.metaDataProvider = TableMetaDataProviderFactory.createMetaDataProvider(dataSource, this, this.nativeJdbcExtractor);
/* 206 */     this.tableColumns = reconcileColumnsToUse(declaredColumns, generatedKeyNames);
/*     */   }
/*     */ 
/*     */   protected List<String> reconcileColumnsToUse(List<String> declaredColumns, String[] generatedKeyNames)
/*     */   {
/* 215 */     if (generatedKeyNames.length > 0) {
/* 216 */       this.generatedKeyColumnsUsed = true;
/*     */     }
/* 218 */     if (declaredColumns.size() > 0) {
/* 219 */       return new ArrayList(declaredColumns);
/*     */     }
/* 221 */     Set keys = new HashSet(generatedKeyNames.length);
/* 222 */     for (String key : generatedKeyNames) {
/* 223 */       keys.add(key.toUpperCase());
/*     */     }
/* 225 */     List columns = new ArrayList();
/* 226 */     for (TableParameterMetaData meta : this.metaDataProvider.getTableParameterMetaData()) {
/* 227 */       if (!keys.contains(meta.getParameterName().toUpperCase())) {
/* 228 */         columns.add(meta.getParameterName());
/*     */       }
/*     */     }
/* 231 */     return columns;
/*     */   }
/*     */ 
/*     */   public List<Object> matchInParameterValuesWithInsertColumns(SqlParameterSource parameterSource)
/*     */   {
/* 239 */     List values = new ArrayList();
/*     */ 
/* 242 */     Map caseInsensitiveParameterNames = SqlParameterSourceUtils.extractCaseInsensitiveParameterNames(parameterSource);
/*     */ 
/* 244 */     for (String column : this.tableColumns) {
/* 245 */       if (parameterSource.hasValue(column)) {
/* 246 */         values.add(SqlParameterSourceUtils.getTypedValue(parameterSource, column));
/*     */       }
/*     */       else {
/* 249 */         String lowerCaseName = column.toLowerCase();
/* 250 */         if (parameterSource.hasValue(lowerCaseName)) {
/* 251 */           values.add(SqlParameterSourceUtils.getTypedValue(parameterSource, lowerCaseName));
/*     */         }
/*     */         else {
/* 254 */           String propertyName = JdbcUtils.convertUnderscoreNameToPropertyName(column);
/* 255 */           if (parameterSource.hasValue(propertyName)) {
/* 256 */             values.add(SqlParameterSourceUtils.getTypedValue(parameterSource, propertyName));
/*     */           }
/* 259 */           else if (caseInsensitiveParameterNames.containsKey(lowerCaseName)) {
/* 260 */             values.add(SqlParameterSourceUtils.getTypedValue(parameterSource, (String)caseInsensitiveParameterNames.get(lowerCaseName)));
/*     */           }
/*     */           else
/*     */           {
/* 265 */             values.add(null);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 271 */     return values;
/*     */   }
/*     */ 
/*     */   public List<Object> matchInParameterValuesWithInsertColumns(Map<String, Object> inParameters)
/*     */   {
/* 279 */     List values = new ArrayList();
/* 280 */     Map source = new HashMap();
/* 281 */     for (String key : inParameters.keySet()) {
/* 282 */       source.put(key.toLowerCase(), inParameters.get(key));
/*     */     }
/* 284 */     for (String column : this.tableColumns) {
/* 285 */       values.add(source.get(column.toLowerCase()));
/*     */     }
/* 287 */     return values;
/*     */   }
/*     */ 
/*     */   public String createInsertString(String[] generatedKeyNames)
/*     */   {
/* 296 */     HashSet keys = new HashSet(generatedKeyNames.length);
/* 297 */     for (String key : generatedKeyNames) {
/* 298 */       keys.add(key.toUpperCase());
/*     */     }
/* 300 */     StringBuilder insertStatement = new StringBuilder();
/* 301 */     insertStatement.append("INSERT INTO ");
/* 302 */     if (getSchemaName() != null) {
/* 303 */       insertStatement.append(getSchemaName());
/* 304 */       insertStatement.append(".");
/*     */     }
/* 306 */     insertStatement.append(getTableName());
/* 307 */     insertStatement.append(" (");
/* 308 */     int columnCount = 0;
/* 309 */     for (String columnName : getTableColumns()) {
/* 310 */       if (!keys.contains(columnName.toUpperCase())) {
/* 311 */         columnCount++;
/* 312 */         if (columnCount > 1) {
/* 313 */           insertStatement.append(", ");
/*     */         }
/* 315 */         insertStatement.append(columnName);
/*     */       }
/*     */     }
/* 318 */     insertStatement.append(") VALUES(");
/* 319 */     if (columnCount < 1) {
/* 320 */       if (this.generatedKeyColumnsUsed) {
/* 321 */         this.logger.info("Unable to locate non-key columns for table '" + getTableName() + "' so an empty insert statement is generated");
/*     */       }
/*     */       else
/*     */       {
/* 325 */         throw new InvalidDataAccessApiUsageException("Unable to locate columns for table '" + getTableName() + "' so an insert statement can't be generated");
/*     */       }
/*     */     }
/*     */ 
/* 329 */     for (int i = 0; i < columnCount; i++) {
/* 330 */       if (i > 0) {
/* 331 */         insertStatement.append(", ");
/*     */       }
/* 333 */       insertStatement.append("?");
/*     */     }
/* 335 */     insertStatement.append(")");
/* 336 */     return insertStatement.toString();
/*     */   }
/*     */ 
/*     */   public int[] createInsertTypes()
/*     */   {
/* 344 */     int[] types = new int[getTableColumns().size()];
/* 345 */     List parameters = this.metaDataProvider.getTableParameterMetaData();
/* 346 */     Map parameterMap = new HashMap(parameters.size());
/* 347 */     for (TableParameterMetaData tpmd : parameters) {
/* 348 */       parameterMap.put(tpmd.getParameterName().toUpperCase(), tpmd);
/*     */     }
/* 350 */     int typeIndx = 0;
/* 351 */     for (String column : getTableColumns()) {
/* 352 */       if (column == null) {
/* 353 */         types[typeIndx] = -2147483648;
/*     */       }
/*     */       else {
/* 356 */         TableParameterMetaData tpmd = (TableParameterMetaData)parameterMap.get(column.toUpperCase());
/* 357 */         if (tpmd != null) {
/* 358 */           types[typeIndx] = tpmd.getSqlType();
/*     */         }
/*     */         else {
/* 361 */           types[typeIndx] = -2147483648;
/*     */         }
/*     */       }
/* 364 */       typeIndx++;
/*     */     }
/* 366 */     return types;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.TableMetaDataContext
 * JD-Core Version:    0.6.1
 */