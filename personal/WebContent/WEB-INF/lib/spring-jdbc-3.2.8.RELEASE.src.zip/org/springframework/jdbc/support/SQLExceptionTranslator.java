package org.springframework.jdbc.support;

import java.sql.SQLException;
import org.springframework.dao.DataAccessException;

public abstract interface SQLExceptionTranslator
{
  public abstract DataAccessException translate(String paramString1, String paramString2, SQLException paramSQLException);
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.SQLExceptionTranslator
 * JD-Core Version:    0.6.1
 */