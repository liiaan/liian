/*     */ package org.springframework.jdbc.support;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.dao.ConcurrencyFailureException;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.dao.DataIntegrityViolationException;
/*     */ import org.springframework.dao.TransientDataAccessResourceException;
/*     */ import org.springframework.jdbc.BadSqlGrammarException;
/*     */ 
/*     */ public class SQLStateSQLExceptionTranslator extends AbstractFallbackSQLExceptionTranslator
/*     */ {
/*  47 */   private static final Set<String> BAD_SQL_GRAMMAR_CODES = new HashSet(8);
/*     */ 
/*  49 */   private static final Set<String> DATA_INTEGRITY_VIOLATION_CODES = new HashSet(8);
/*     */ 
/*  51 */   private static final Set<String> DATA_ACCESS_RESOURCE_FAILURE_CODES = new HashSet(8);
/*     */ 
/*  53 */   private static final Set<String> TRANSIENT_DATA_ACCESS_RESOURCE_CODES = new HashSet(8);
/*     */ 
/*  55 */   private static final Set<String> CONCURRENCY_FAILURE_CODES = new HashSet(4);
/*     */ 
/*     */   protected DataAccessException doTranslate(String task, String sql, SQLException ex)
/*     */   {
/*  90 */     String sqlState = getSqlState(ex);
/*  91 */     if ((sqlState != null) && (sqlState.length() >= 2)) {
/*  92 */       String classCode = sqlState.substring(0, 2);
/*  93 */       if (this.logger.isDebugEnabled()) {
/*  94 */         this.logger.debug("Extracted SQL state class '" + classCode + "' from value '" + sqlState + "'");
/*     */       }
/*  96 */       if (BAD_SQL_GRAMMAR_CODES.contains(classCode)) {
/*  97 */         return new BadSqlGrammarException(task, sql, ex);
/*     */       }
/*  99 */       if (DATA_INTEGRITY_VIOLATION_CODES.contains(classCode)) {
/* 100 */         return new DataIntegrityViolationException(buildMessage(task, sql, ex), ex);
/*     */       }
/* 102 */       if (DATA_ACCESS_RESOURCE_FAILURE_CODES.contains(classCode)) {
/* 103 */         return new DataAccessResourceFailureException(buildMessage(task, sql, ex), ex);
/*     */       }
/* 105 */       if (TRANSIENT_DATA_ACCESS_RESOURCE_CODES.contains(classCode)) {
/* 106 */         return new TransientDataAccessResourceException(buildMessage(task, sql, ex), ex);
/*     */       }
/* 108 */       if (CONCURRENCY_FAILURE_CODES.contains(classCode)) {
/* 109 */         return new ConcurrencyFailureException(buildMessage(task, sql, ex), ex);
/*     */       }
/*     */     }
/* 112 */     return null;
/*     */   }
/*     */ 
/*     */   private String getSqlState(SQLException ex)
/*     */   {
/* 124 */     String sqlState = ex.getSQLState();
/* 125 */     if (sqlState == null) {
/* 126 */       SQLException nestedEx = ex.getNextException();
/* 127 */       if (nestedEx != null) {
/* 128 */         sqlState = nestedEx.getSQLState();
/*     */       }
/*     */     }
/* 131 */     return sqlState;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  59 */     BAD_SQL_GRAMMAR_CODES.add("07");
/*  60 */     BAD_SQL_GRAMMAR_CODES.add("21");
/*  61 */     BAD_SQL_GRAMMAR_CODES.add("2A");
/*  62 */     BAD_SQL_GRAMMAR_CODES.add("37");
/*  63 */     BAD_SQL_GRAMMAR_CODES.add("42");
/*  64 */     BAD_SQL_GRAMMAR_CODES.add("65");
/*     */ 
/*  66 */     DATA_INTEGRITY_VIOLATION_CODES.add("01");
/*  67 */     DATA_INTEGRITY_VIOLATION_CODES.add("02");
/*  68 */     DATA_INTEGRITY_VIOLATION_CODES.add("22");
/*  69 */     DATA_INTEGRITY_VIOLATION_CODES.add("23");
/*  70 */     DATA_INTEGRITY_VIOLATION_CODES.add("27");
/*  71 */     DATA_INTEGRITY_VIOLATION_CODES.add("44");
/*     */ 
/*  73 */     DATA_ACCESS_RESOURCE_FAILURE_CODES.add("08");
/*  74 */     DATA_ACCESS_RESOURCE_FAILURE_CODES.add("53");
/*  75 */     DATA_ACCESS_RESOURCE_FAILURE_CODES.add("54");
/*  76 */     DATA_ACCESS_RESOURCE_FAILURE_CODES.add("57");
/*  77 */     DATA_ACCESS_RESOURCE_FAILURE_CODES.add("58");
/*     */ 
/*  79 */     TRANSIENT_DATA_ACCESS_RESOURCE_CODES.add("JW");
/*  80 */     TRANSIENT_DATA_ACCESS_RESOURCE_CODES.add("JZ");
/*  81 */     TRANSIENT_DATA_ACCESS_RESOURCE_CODES.add("S1");
/*     */ 
/*  83 */     CONCURRENCY_FAILURE_CODES.add("40");
/*  84 */     CONCURRENCY_FAILURE_CODES.add("61");
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.SQLStateSQLExceptionTranslator
 * JD-Core Version:    0.6.1
 */