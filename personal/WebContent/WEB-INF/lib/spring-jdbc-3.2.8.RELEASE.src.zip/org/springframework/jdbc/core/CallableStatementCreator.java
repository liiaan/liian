package org.springframework.jdbc.core;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public abstract interface CallableStatementCreator
{
  public abstract CallableStatement createCallableStatement(Connection paramConnection)
    throws SQLException;
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.CallableStatementCreator
 * JD-Core Version:    0.6.1
 */