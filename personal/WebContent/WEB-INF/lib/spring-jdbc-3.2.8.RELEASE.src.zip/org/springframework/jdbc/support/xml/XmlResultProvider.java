package org.springframework.jdbc.support.xml;

import javax.xml.transform.Result;

public abstract interface XmlResultProvider
{
  public abstract void provideXml(Result paramResult);
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.xml.XmlResultProvider
 * JD-Core Version:    0.6.1
 */