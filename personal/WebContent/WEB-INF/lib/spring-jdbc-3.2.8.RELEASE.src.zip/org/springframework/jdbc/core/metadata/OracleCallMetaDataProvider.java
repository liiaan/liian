/*    */ package org.springframework.jdbc.core.metadata;
/*    */ 
/*    */ import java.sql.DatabaseMetaData;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.jdbc.core.ColumnMapRowMapper;
/*    */ import org.springframework.jdbc.core.SqlOutParameter;
/*    */ import org.springframework.jdbc.core.SqlParameter;
/*    */ 
/*    */ public class OracleCallMetaDataProvider extends GenericCallMetaDataProvider
/*    */ {
/*    */   private static final String REF_CURSOR_NAME = "REF CURSOR";
/*    */ 
/*    */   public OracleCallMetaDataProvider(DatabaseMetaData databaseMetaData)
/*    */     throws SQLException
/*    */   {
/* 40 */     super(databaseMetaData);
/*    */   }
/*    */ 
/*    */   public boolean isReturnResultSetSupported()
/*    */   {
/* 46 */     return false;
/*    */   }
/*    */ 
/*    */   public boolean isRefCursorSupported()
/*    */   {
/* 51 */     return true;
/*    */   }
/*    */ 
/*    */   public int getRefCursorSqlType()
/*    */   {
/* 56 */     return -10;
/*    */   }
/*    */ 
/*    */   public String metaDataCatalogNameToUse(String catalogName)
/*    */   {
/* 62 */     return catalogName == null ? "" : catalogNameToUse(catalogName);
/*    */   }
/*    */ 
/*    */   public String metaDataSchemaNameToUse(String schemaName)
/*    */   {
/* 68 */     return schemaName == null ? getUserName() : super.metaDataSchemaNameToUse(schemaName);
/*    */   }
/*    */ 
/*    */   public SqlParameter createDefaultOutParameter(String parameterName, CallParameterMetaData meta)
/*    */   {
/* 73 */     if ((meta.getSqlType() == 1111) && ("REF CURSOR".equals(meta.getTypeName()))) {
/* 74 */       return new SqlOutParameter(parameterName, getRefCursorSqlType(), new ColumnMapRowMapper());
/*    */     }
/*    */ 
/* 77 */     return super.createDefaultOutParameter(parameterName, meta);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.OracleCallMetaDataProvider
 * JD-Core Version:    0.6.1
 */