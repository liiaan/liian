/*    */ package org.springframework.jdbc.support.incrementer;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ public class SybaseAnywhereMaxValueIncrementer extends SybaseMaxValueIncrementer
/*    */ {
/*    */   public SybaseAnywhereMaxValueIncrementer()
/*    */   {
/*    */   }
/*    */ 
/*    */   public SybaseAnywhereMaxValueIncrementer(DataSource dataSource, String incrementerName, String columnName)
/*    */   {
/* 73 */     super(dataSource, incrementerName, columnName);
/*    */   }
/*    */ 
/*    */   protected String getIncrementStatement()
/*    */   {
/* 78 */     return "insert into " + getIncrementerName() + " values(DEFAULT)";
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.incrementer.SybaseAnywhereMaxValueIncrementer
 * JD-Core Version:    0.6.1
 */