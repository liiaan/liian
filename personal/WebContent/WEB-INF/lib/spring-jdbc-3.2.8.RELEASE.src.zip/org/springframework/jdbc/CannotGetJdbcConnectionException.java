/*    */ package org.springframework.jdbc;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.dao.DataAccessResourceFailureException;
/*    */ 
/*    */ public class CannotGetJdbcConnectionException extends DataAccessResourceFailureException
/*    */ {
/*    */   public CannotGetJdbcConnectionException(String msg, SQLException ex)
/*    */   {
/* 37 */     super(msg, ex);
/*    */   }
/*    */ 
/*    */   @Deprecated
/*    */   public CannotGetJdbcConnectionException(String msg, ClassNotFoundException ex)
/*    */   {
/* 49 */     super(msg, ex);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.CannotGetJdbcConnectionException
 * JD-Core Version:    0.6.1
 */