/*    */ package org.springframework.jdbc.core.metadata;
/*    */ 
/*    */ import java.sql.DatabaseMetaData;
/*    */ import java.sql.SQLException;
/*    */ import org.apache.commons.logging.Log;
/*    */ 
/*    */ public class Db2CallMetaDataProvider extends GenericCallMetaDataProvider
/*    */ {
/*    */   public Db2CallMetaDataProvider(DatabaseMetaData databaseMetaData)
/*    */     throws SQLException
/*    */   {
/* 33 */     super(databaseMetaData);
/*    */   }
/*    */ 
/*    */   public void initializeWithMetaData(DatabaseMetaData databaseMetaData) throws SQLException
/*    */   {
/*    */     try
/*    */     {
/* 40 */       setSupportsCatalogsInProcedureCalls(databaseMetaData.supportsCatalogsInProcedureCalls());
/*    */     }
/*    */     catch (SQLException se) {
/* 43 */       logger.debug("Error retrieving 'DatabaseMetaData.supportsCatalogsInProcedureCalls' - " + se.getMessage());
/*    */     }
/*    */     try {
/* 46 */       setSupportsSchemasInProcedureCalls(databaseMetaData.supportsSchemasInProcedureCalls());
/*    */     }
/*    */     catch (SQLException se) {
/* 49 */       logger.debug("Error retrieving 'DatabaseMetaData.supportsSchemasInProcedureCalls' - " + se.getMessage());
/*    */     }
/*    */     try {
/* 52 */       setStoresUpperCaseIdentifiers(databaseMetaData.storesUpperCaseIdentifiers());
/*    */     }
/*    */     catch (SQLException se) {
/* 55 */       logger.debug("Error retrieving 'DatabaseMetaData.storesUpperCaseIdentifiers' - " + se.getMessage());
/*    */     }
/*    */     try {
/* 58 */       setStoresLowerCaseIdentifiers(databaseMetaData.storesLowerCaseIdentifiers());
/*    */     }
/*    */     catch (SQLException se) {
/* 61 */       logger.debug("Error retrieving 'DatabaseMetaData.storesLowerCaseIdentifiers' - " + se.getMessage());
/*    */     }
/*    */   }
/*    */ 
/*    */   public String metaDataSchemaNameToUse(String schemaName)
/*    */   {
/* 67 */     if (schemaName != null) {
/* 68 */       return super.metaDataSchemaNameToUse(schemaName);
/*    */     }
/*    */ 
/* 71 */     String userName = getUserName();
/* 72 */     return userName != null ? userName.toUpperCase() : null;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.Db2CallMetaDataProvider
 * JD-Core Version:    0.6.1
 */