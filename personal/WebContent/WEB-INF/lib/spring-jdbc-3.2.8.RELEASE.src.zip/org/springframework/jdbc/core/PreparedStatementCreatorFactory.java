/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.dao.InvalidDataAccessResourceUsageException;
/*     */ import org.springframework.jdbc.support.nativejdbc.NativeJdbcExtractor;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class PreparedStatementCreatorFactory
/*     */ {
/*     */   private final String sql;
/*     */   private final List<SqlParameter> declaredParameters;
/*  54 */   private int resultSetType = 1003;
/*     */ 
/*  56 */   private boolean updatableResults = false;
/*     */ 
/*  58 */   private boolean returnGeneratedKeys = false;
/*     */ 
/*  60 */   private String[] generatedKeysColumnNames = null;
/*     */   private NativeJdbcExtractor nativeJdbcExtractor;
/*     */ 
/*     */   public PreparedStatementCreatorFactory(String sql)
/*     */   {
/*  70 */     this.sql = sql;
/*  71 */     this.declaredParameters = new LinkedList();
/*     */   }
/*     */ 
/*     */   public PreparedStatementCreatorFactory(String sql, int[] types)
/*     */   {
/*  80 */     this.sql = sql;
/*  81 */     this.declaredParameters = SqlParameter.sqlTypesToAnonymousParameterList(types);
/*     */   }
/*     */ 
/*     */   public PreparedStatementCreatorFactory(String sql, List<SqlParameter> declaredParameters)
/*     */   {
/*  91 */     this.sql = sql;
/*  92 */     this.declaredParameters = declaredParameters;
/*     */   }
/*     */ 
/*     */   public void addParameter(SqlParameter param)
/*     */   {
/* 102 */     this.declaredParameters.add(param);
/*     */   }
/*     */ 
/*     */   public void setResultSetType(int resultSetType)
/*     */   {
/* 113 */     this.resultSetType = resultSetType;
/*     */   }
/*     */ 
/*     */   public void setUpdatableResults(boolean updatableResults)
/*     */   {
/* 120 */     this.updatableResults = updatableResults;
/*     */   }
/*     */ 
/*     */   public void setReturnGeneratedKeys(boolean returnGeneratedKeys)
/*     */   {
/* 127 */     this.returnGeneratedKeys = returnGeneratedKeys;
/*     */   }
/*     */ 
/*     */   public void setGeneratedKeysColumnNames(String[] names)
/*     */   {
/* 134 */     this.generatedKeysColumnNames = names;
/*     */   }
/*     */ 
/*     */   public void setNativeJdbcExtractor(NativeJdbcExtractor nativeJdbcExtractor)
/*     */   {
/* 141 */     this.nativeJdbcExtractor = nativeJdbcExtractor;
/*     */   }
/*     */ 
/*     */   public PreparedStatementSetter newPreparedStatementSetter(List<?> params)
/*     */   {
/* 150 */     return new PreparedStatementCreatorImpl(params != null ? params : Collections.emptyList());
/*     */   }
/*     */ 
/*     */   public PreparedStatementSetter newPreparedStatementSetter(Object[] params)
/*     */   {
/* 158 */     return new PreparedStatementCreatorImpl(params != null ? Arrays.asList(params) : Collections.emptyList());
/*     */   }
/*     */ 
/*     */   public PreparedStatementCreator newPreparedStatementCreator(List<?> params)
/*     */   {
/* 166 */     return new PreparedStatementCreatorImpl(params != null ? params : Collections.emptyList());
/*     */   }
/*     */ 
/*     */   public PreparedStatementCreator newPreparedStatementCreator(Object[] params)
/*     */   {
/* 174 */     return new PreparedStatementCreatorImpl(params != null ? Arrays.asList(params) : Collections.emptyList());
/*     */   }
/*     */ 
/*     */   public PreparedStatementCreator newPreparedStatementCreator(String sqlToUse, Object[] params)
/*     */   {
/* 184 */     return new PreparedStatementCreatorImpl(sqlToUse, params != null ? Arrays.asList(params) : Collections.emptyList());
/*     */   }
/*     */ 
/*     */   private class PreparedStatementCreatorImpl
/*     */     implements PreparedStatementCreator, PreparedStatementSetter, SqlProvider, ParameterDisposer
/*     */   {
/*     */     private final String actualSql;
/*     */     private final List parameters;
/*     */ 
/*     */     public PreparedStatementCreatorImpl()
/*     */     {
/* 200 */       this(PreparedStatementCreatorFactory.this.sql, parameters);
/*     */     }
/*     */ 
/*     */     public PreparedStatementCreatorImpl(String actualSql, List parameters) {
/* 204 */       this.actualSql = actualSql;
/* 205 */       Assert.notNull(parameters, "Parameters List must not be null");
/* 206 */       this.parameters = parameters;
/* 207 */       if (this.parameters.size() != PreparedStatementCreatorFactory.this.declaredParameters.size())
/*     */       {
/* 209 */         Set names = new HashSet();
/* 210 */         for (int i = 0; i < parameters.size(); i++) {
/* 211 */           Object param = parameters.get(i);
/* 212 */           if ((param instanceof SqlParameterValue)) {
/* 213 */             names.add(((SqlParameterValue)param).getName());
/*     */           }
/*     */           else {
/* 216 */             names.add("Parameter #" + i);
/*     */           }
/*     */         }
/* 219 */         if (names.size() != PreparedStatementCreatorFactory.this.declaredParameters.size())
/* 220 */           throw new InvalidDataAccessApiUsageException("SQL [" + PreparedStatementCreatorFactory.this.sql + "]: given " + names.size() + " parameters but expected " + PreparedStatementCreatorFactory.this.declaredParameters.size());
/*     */       }
/*     */     }
/*     */ 
/*     */     public PreparedStatement createPreparedStatement(Connection con)
/*     */       throws SQLException
/*     */     {
/*     */       PreparedStatement ps;
/*     */       PreparedStatement ps;
/* 229 */       if ((PreparedStatementCreatorFactory.this.generatedKeysColumnNames != null) || (PreparedStatementCreatorFactory.this.returnGeneratedKeys)) {
/*     */         try
/*     */         {
/*     */           PreparedStatement ps;
/* 231 */           if (PreparedStatementCreatorFactory.this.generatedKeysColumnNames != null) {
/* 232 */             ps = con.prepareStatement(this.actualSql, PreparedStatementCreatorFactory.this.generatedKeysColumnNames);
/*     */           }
/*     */           else
/* 235 */             ps = con.prepareStatement(this.actualSql, 1);
/*     */         }
/*     */         catch (AbstractMethodError err)
/*     */         {
/* 239 */           throw new InvalidDataAccessResourceUsageException("Your JDBC driver is not compliant with JDBC 3.0 - it does not support retrieval of auto-generated keys", err);
/*     */         }
/*     */ 
/*     */       }
/* 244 */       else if ((PreparedStatementCreatorFactory.this.resultSetType == 1003) && (!PreparedStatementCreatorFactory.this.updatableResults)) {
/* 245 */         ps = con.prepareStatement(this.actualSql);
/*     */       }
/*     */       else {
/* 248 */         ps = con.prepareStatement(this.actualSql, PreparedStatementCreatorFactory.this.resultSetType, PreparedStatementCreatorFactory.this.updatableResults ? 1008 : 1007);
/*     */       }
/*     */ 
/* 251 */       setValues(ps);
/* 252 */       return ps;
/*     */     }
/*     */ 
/*     */     public void setValues(PreparedStatement ps) throws SQLException
/*     */     {
/* 257 */       PreparedStatement psToUse = ps;
/* 258 */       if (PreparedStatementCreatorFactory.this.nativeJdbcExtractor != null) {
/* 259 */         psToUse = PreparedStatementCreatorFactory.this.nativeJdbcExtractor.getNativePreparedStatement(ps);
/*     */       }
/*     */ 
/* 263 */       int sqlColIndx = 1;
/* 264 */       for (int i = 0; i < this.parameters.size(); i++) {
/* 265 */         Object in = this.parameters.get(i);
/*     */         SqlParameter declaredParameter;
/*     */         SqlParameter declaredParameter;
/* 269 */         if ((in instanceof SqlParameterValue)) {
/* 270 */           SqlParameterValue paramValue = (SqlParameterValue)in;
/* 271 */           in = paramValue.getValue();
/* 272 */           declaredParameter = paramValue;
/*     */         }
/*     */         else {
/* 275 */           if (PreparedStatementCreatorFactory.this.declaredParameters.size() <= i) {
/* 276 */             throw new InvalidDataAccessApiUsageException("SQL [" + PreparedStatementCreatorFactory.this.sql + "]: unable to access parameter number " + (i + 1) + " given only " + PreparedStatementCreatorFactory.this.declaredParameters.size() + " parameters");
/*     */           }
/*     */ 
/* 281 */           declaredParameter = (SqlParameter)PreparedStatementCreatorFactory.this.declaredParameters.get(i);
/*     */         }
/*     */         Iterator i$;
/* 283 */         if (((in instanceof Collection)) && (declaredParameter.getSqlType() != 2003)) {
/* 284 */           Collection entries = (Collection)in;
/* 285 */           for (i$ = entries.iterator(); i$.hasNext(); ) { Object entry = i$.next();
/* 286 */             if ((entry instanceof Object[])) {
/* 287 */               Object[] valueArray = (Object[])entry;
/* 288 */               for (Object argValue : valueArray)
/* 289 */                 StatementCreatorUtils.setParameterValue(psToUse, sqlColIndx++, declaredParameter, argValue);
/*     */             }
/*     */             else
/*     */             {
/* 293 */               StatementCreatorUtils.setParameterValue(psToUse, sqlColIndx++, declaredParameter, entry);
/*     */             } }
/*     */         }
/*     */         else
/*     */         {
/* 298 */           StatementCreatorUtils.setParameterValue(psToUse, sqlColIndx++, declaredParameter, in);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     public String getSql() {
/* 304 */       return PreparedStatementCreatorFactory.this.sql;
/*     */     }
/*     */ 
/*     */     public void cleanupParameters() {
/* 308 */       StatementCreatorUtils.cleanupParameters(this.parameters);
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 313 */       StringBuilder sb = new StringBuilder();
/* 314 */       sb.append("PreparedStatementCreatorFactory.PreparedStatementCreatorImpl: sql=[");
/* 315 */       sb.append(PreparedStatementCreatorFactory.this.sql).append("]; parameters=").append(this.parameters);
/* 316 */       return sb.toString();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.PreparedStatementCreatorFactory
 * JD-Core Version:    0.6.1
 */