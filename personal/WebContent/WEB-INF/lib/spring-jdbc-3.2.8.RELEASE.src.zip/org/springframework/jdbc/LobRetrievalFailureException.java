/*    */ package org.springframework.jdbc;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import org.springframework.dao.DataRetrievalFailureException;
/*    */ 
/*    */ public class LobRetrievalFailureException extends DataRetrievalFailureException
/*    */ {
/*    */   public LobRetrievalFailureException(String msg)
/*    */   {
/* 37 */     super(msg);
/*    */   }
/*    */ 
/*    */   public LobRetrievalFailureException(String msg, IOException ex)
/*    */   {
/* 46 */     super(msg, ex);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.LobRetrievalFailureException
 * JD-Core Version:    0.6.1
 */