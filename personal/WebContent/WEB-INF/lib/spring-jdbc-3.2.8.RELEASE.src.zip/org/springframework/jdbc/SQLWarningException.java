/*    */ package org.springframework.jdbc;
/*    */ 
/*    */ import java.sql.SQLWarning;
/*    */ import org.springframework.dao.UncategorizedDataAccessException;
/*    */ 
/*    */ public class SQLWarningException extends UncategorizedDataAccessException
/*    */ {
/*    */   public SQLWarningException(String msg, SQLWarning ex)
/*    */   {
/* 44 */     super(msg, ex);
/*    */   }
/*    */ 
/*    */   public SQLWarning SQLWarning()
/*    */   {
/* 51 */     return (SQLWarning)getCause();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.SQLWarningException
 * JD-Core Version:    0.6.1
 */