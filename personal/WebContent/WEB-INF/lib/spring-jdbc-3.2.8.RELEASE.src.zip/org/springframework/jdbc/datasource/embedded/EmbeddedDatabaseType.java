/*    */ package org.springframework.jdbc.datasource.embedded;
/*    */ 
/*    */ public enum EmbeddedDatabaseType
/*    */ {
/* 29 */   HSQL, 
/*    */ 
/* 32 */   H2, 
/*    */ 
/* 35 */   DERBY;
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType
 * JD-Core Version:    0.6.1
 */