/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ 
/*     */ public class RowCountCallbackHandler
/*     */   implements RowCallbackHandler
/*     */ {
/*     */   private int rowCount;
/*     */   private int columnCount;
/*     */   private int[] columnTypes;
/*     */   private String[] columnNames;
/*     */ 
/*     */   public final void processRow(ResultSet rs)
/*     */     throws SQLException
/*     */   {
/*  73 */     if (this.rowCount == 0) {
/*  74 */       ResultSetMetaData rsmd = rs.getMetaData();
/*  75 */       this.columnCount = rsmd.getColumnCount();
/*  76 */       this.columnTypes = new int[this.columnCount];
/*  77 */       this.columnNames = new String[this.columnCount];
/*  78 */       for (int i = 0; i < this.columnCount; i++) {
/*  79 */         this.columnTypes[i] = rsmd.getColumnType(i + 1);
/*  80 */         this.columnNames[i] = JdbcUtils.lookupColumnName(rsmd, i + 1);
/*     */       }
/*     */     }
/*     */ 
/*  84 */     processRow(rs, this.rowCount++);
/*     */   }
/*     */ 
/*     */   protected void processRow(ResultSet rs, int rowNum)
/*     */     throws SQLException
/*     */   {
/*     */   }
/*     */ 
/*     */   public final int[] getColumnTypes()
/*     */   {
/* 105 */     return this.columnTypes;
/*     */   }
/*     */ 
/*     */   public final String[] getColumnNames()
/*     */   {
/* 115 */     return this.columnNames;
/*     */   }
/*     */ 
/*     */   public final int getRowCount()
/*     */   {
/* 124 */     return this.rowCount;
/*     */   }
/*     */ 
/*     */   public final int getColumnCount()
/*     */   {
/* 134 */     return this.columnCount;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.RowCountCallbackHandler
 * JD-Core Version:    0.6.1
 */