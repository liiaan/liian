package org.springframework.jdbc.datasource.init;

import java.sql.Connection;
import java.sql.SQLException;

public abstract interface DatabasePopulator
{
  public abstract void populate(Connection paramConnection)
    throws SQLException;
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.init.DatabasePopulator
 * JD-Core Version:    0.6.1
 */