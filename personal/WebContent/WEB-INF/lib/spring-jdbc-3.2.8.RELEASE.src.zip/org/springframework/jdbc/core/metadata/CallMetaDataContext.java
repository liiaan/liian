/*     */ package org.springframework.jdbc.core.metadata;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ import org.springframework.jdbc.core.SqlOutParameter;
/*     */ import org.springframework.jdbc.core.SqlParameter;
/*     */ import org.springframework.jdbc.core.SqlParameterValue;
/*     */ import org.springframework.jdbc.core.SqlReturnResultSet;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class CallMetaDataContext
/*     */ {
/*  54 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private String procedureName;
/*     */   private String catalogName;
/*     */   private String schemaName;
/*  66 */   private List<SqlParameter> callParameters = new ArrayList();
/*     */ 
/*  69 */   private String defaultFunctionReturnName = "return";
/*     */ 
/*  72 */   private String actualFunctionReturnName = null;
/*     */ 
/*  75 */   private Set<String> limitedInParameterNames = new HashSet();
/*     */ 
/*  78 */   private List<String> outParameterNames = new ArrayList();
/*     */ 
/*  81 */   private boolean accessCallParameterMetaData = true;
/*     */   private boolean function;
/*     */   private boolean returnValueRequired;
/*     */   private CallMetaDataProvider metaDataProvider;
/*     */ 
/*     */   public void setFunctionReturnName(String functionReturnName)
/*     */   {
/*  97 */     this.actualFunctionReturnName = functionReturnName;
/*     */   }
/*     */ 
/*     */   public String getFunctionReturnName()
/*     */   {
/* 104 */     return this.actualFunctionReturnName != null ? this.actualFunctionReturnName : this.defaultFunctionReturnName;
/*     */   }
/*     */ 
/*     */   public void setLimitedInParameterNames(Set<String> limitedInParameterNames)
/*     */   {
/* 111 */     this.limitedInParameterNames = limitedInParameterNames;
/*     */   }
/*     */ 
/*     */   public Set<String> getLimitedInParameterNames()
/*     */   {
/* 118 */     return this.limitedInParameterNames;
/*     */   }
/*     */ 
/*     */   public void setOutParameterNames(List<String> outParameterNames)
/*     */   {
/* 125 */     this.outParameterNames = outParameterNames;
/*     */   }
/*     */ 
/*     */   public List<String> getOutParameterNames()
/*     */   {
/* 132 */     return this.outParameterNames;
/*     */   }
/*     */ 
/*     */   public void setProcedureName(String procedureName)
/*     */   {
/* 139 */     this.procedureName = procedureName;
/*     */   }
/*     */ 
/*     */   public String getProcedureName()
/*     */   {
/* 146 */     return this.procedureName;
/*     */   }
/*     */ 
/*     */   public void setCatalogName(String catalogName)
/*     */   {
/* 153 */     this.catalogName = catalogName;
/*     */   }
/*     */ 
/*     */   public String getCatalogName()
/*     */   {
/* 160 */     return this.catalogName;
/*     */   }
/*     */ 
/*     */   public void setSchemaName(String schemaName)
/*     */   {
/* 167 */     this.schemaName = schemaName;
/*     */   }
/*     */ 
/*     */   public String getSchemaName()
/*     */   {
/* 174 */     return this.schemaName;
/*     */   }
/*     */ 
/*     */   public void setFunction(boolean function)
/*     */   {
/* 181 */     this.function = function;
/*     */   }
/*     */ 
/*     */   public boolean isFunction()
/*     */   {
/* 188 */     return this.function;
/*     */   }
/*     */ 
/*     */   public void setReturnValueRequired(boolean returnValueRequired)
/*     */   {
/* 195 */     this.returnValueRequired = returnValueRequired;
/*     */   }
/*     */ 
/*     */   public boolean isReturnValueRequired()
/*     */   {
/* 202 */     return this.returnValueRequired;
/*     */   }
/*     */ 
/*     */   public void setAccessCallParameterMetaData(boolean accessCallParameterMetaData)
/*     */   {
/* 209 */     this.accessCallParameterMetaData = accessCallParameterMetaData;
/*     */   }
/*     */ 
/*     */   public boolean isAccessCallParameterMetaData()
/*     */   {
/* 216 */     return this.accessCallParameterMetaData;
/*     */   }
/*     */ 
/*     */   public SqlParameter createReturnResultSetParameter(String parameterName, RowMapper rowMapper)
/*     */   {
/* 228 */     if (this.metaDataProvider.isReturnResultSetSupported()) {
/* 229 */       return new SqlReturnResultSet(parameterName, rowMapper);
/*     */     }
/*     */ 
/* 232 */     if (this.metaDataProvider.isRefCursorSupported()) {
/* 233 */       return new SqlOutParameter(parameterName, this.metaDataProvider.getRefCursorSqlType(), rowMapper);
/*     */     }
/*     */ 
/* 236 */     throw new InvalidDataAccessApiUsageException("Return of a ResultSet from a stored procedure is not supported.");
/*     */   }
/*     */ 
/*     */   public String getScalarOutParameterName()
/*     */   {
/* 246 */     if (isFunction()) {
/* 247 */       return getFunctionReturnName();
/*     */     }
/*     */ 
/* 250 */     if (this.outParameterNames.size() > 1) {
/* 251 */       this.logger.warn("Accessing single output value when procedure has more than one output parameter");
/*     */     }
/* 253 */     return this.outParameterNames.size() > 0 ? (String)this.outParameterNames.get(0) : null;
/*     */   }
/*     */ 
/*     */   public List<SqlParameter> getCallParameters()
/*     */   {
/* 261 */     return this.callParameters;
/*     */   }
/*     */ 
/*     */   public void initializeMetaData(DataSource dataSource)
/*     */   {
/* 269 */     this.metaDataProvider = CallMetaDataProviderFactory.createMetaDataProvider(dataSource, this);
/*     */   }
/*     */ 
/*     */   public void processParameters(List<SqlParameter> parameters)
/*     */   {
/* 279 */     this.callParameters = reconcileParameters(parameters);
/*     */   }
/*     */ 
/*     */   protected List<SqlParameter> reconcileParameters(List<SqlParameter> parameters)
/*     */   {
/* 286 */     List declaredReturnParameters = new ArrayList();
/* 287 */     Map declaredParameters = new LinkedHashMap();
/* 288 */     boolean returnDeclared = false;
/* 289 */     List outParameterNames = new ArrayList();
/* 290 */     List metaDataParameterNames = new ArrayList();
/*     */ 
/* 293 */     for (CallParameterMetaData meta : this.metaDataProvider.getCallParameterMetaData()) {
/* 294 */       if (meta.getParameterType() != 5) {
/* 295 */         metaDataParameterNames.add(meta.getParameterName().toLowerCase());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 300 */     for (SqlParameter parameter : parameters) {
/* 301 */       if (parameter.isResultsParameter()) {
/* 302 */         declaredReturnParameters.add(parameter);
/*     */       }
/*     */       else {
/* 305 */         String parameterNameToMatch = this.metaDataProvider.parameterNameToUse(parameter.getName()).toLowerCase();
/* 306 */         declaredParameters.put(parameterNameToMatch, parameter);
/* 307 */         if ((parameter instanceof SqlOutParameter)) {
/* 308 */           outParameterNames.add(parameter.getName());
/* 309 */           if ((isFunction()) && (!metaDataParameterNames.contains(parameterNameToMatch)) && 
/* 310 */             (!returnDeclared)) {
/* 311 */             if (this.logger.isDebugEnabled()) {
/* 312 */               this.logger.debug("Using declared out parameter '" + parameter.getName() + "' for function return value");
/*     */             }
/* 314 */             setFunctionReturnName(parameter.getName());
/* 315 */             returnDeclared = true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 321 */     setOutParameterNames(outParameterNames);
/*     */ 
/* 323 */     List workParameters = new ArrayList();
/* 324 */     workParameters.addAll(declaredReturnParameters);
/*     */ 
/* 326 */     if (!this.metaDataProvider.isProcedureColumnMetaDataUsed()) {
/* 327 */       workParameters.addAll(declaredParameters.values());
/* 328 */       return workParameters;
/*     */     }
/*     */ 
/* 331 */     Map limitedInParamNamesMap = new HashMap(this.limitedInParameterNames.size());
/* 332 */     for (String limitedParameterName : this.limitedInParameterNames) {
/* 333 */       limitedInParamNamesMap.put(this.metaDataProvider.parameterNameToUse(limitedParameterName).toLowerCase(), limitedParameterName);
/*     */     }
/*     */ 
/* 337 */     for (CallParameterMetaData meta : this.metaDataProvider.getCallParameterMetaData()) {
/* 338 */       String parNameToCheck = null;
/* 339 */       if (meta.getParameterName() != null) {
/* 340 */         parNameToCheck = this.metaDataProvider.parameterNameToUse(meta.getParameterName()).toLowerCase();
/*     */       }
/* 342 */       String parNameToUse = this.metaDataProvider.parameterNameToUse(meta.getParameterName());
/* 343 */       if ((declaredParameters.containsKey(parNameToCheck)) || ((meta.getParameterType() == 5) && (returnDeclared)))
/*     */       {
/*     */         SqlParameter parameter;
/* 346 */         if (meta.getParameterType() == 5) {
/* 347 */           SqlParameter parameter = (SqlParameter)declaredParameters.get(getFunctionReturnName());
/* 348 */           if ((parameter == null) && (getOutParameterNames().size() > 0)) {
/* 349 */             parameter = (SqlParameter)declaredParameters.get(((String)getOutParameterNames().get(0)).toLowerCase());
/*     */           }
/* 351 */           if (parameter == null) {
/* 352 */             throw new InvalidDataAccessApiUsageException("Unable to locate declared parameter for function return value -  add a SqlOutParameter with name \"" + getFunctionReturnName() + "\"");
/*     */           }
/*     */ 
/* 357 */           setFunctionReturnName(parameter.getName());
/*     */         }
/*     */         else
/*     */         {
/* 361 */           parameter = (SqlParameter)declaredParameters.get(parNameToCheck);
/*     */         }
/* 363 */         if (parameter != null) {
/* 364 */           workParameters.add(parameter);
/* 365 */           if (this.logger.isDebugEnabled()) {
/* 366 */             this.logger.debug("Using declared parameter for: " + (parNameToUse == null ? getFunctionReturnName() : parNameToUse));
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/* 372 */       else if (meta.getParameterType() == 5) {
/* 373 */         if ((!isFunction()) && (!isReturnValueRequired()) && (this.metaDataProvider.byPassReturnParameter(meta.getParameterName())))
/*     */         {
/* 375 */           if (this.logger.isDebugEnabled())
/* 376 */             this.logger.debug("Bypassing metadata return parameter for: " + meta.getParameterName());
/*     */         }
/*     */         else
/*     */         {
/* 380 */           String returnNameToUse = StringUtils.hasLength(meta.getParameterName()) ? parNameToUse : getFunctionReturnName();
/*     */ 
/* 382 */           workParameters.add(this.metaDataProvider.createDefaultOutParameter(returnNameToUse, meta));
/* 383 */           if (isFunction()) {
/* 384 */             setFunctionReturnName(returnNameToUse);
/* 385 */             outParameterNames.add(returnNameToUse);
/*     */           }
/* 387 */           if (this.logger.isDebugEnabled()) {
/* 388 */             this.logger.debug("Added metadata return parameter for: " + returnNameToUse);
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/* 393 */       else if (meta.getParameterType() == 4) {
/* 394 */         workParameters.add(this.metaDataProvider.createDefaultOutParameter(parNameToUse, meta));
/* 395 */         outParameterNames.add(parNameToUse);
/* 396 */         if (this.logger.isDebugEnabled()) {
/* 397 */           this.logger.debug("Added metadata out parameter for: " + parNameToUse);
/*     */         }
/*     */       }
/* 400 */       else if (meta.getParameterType() == 2) {
/* 401 */         workParameters.add(this.metaDataProvider.createDefaultInOutParameter(parNameToUse, meta));
/* 402 */         outParameterNames.add(parNameToUse);
/* 403 */         if (this.logger.isDebugEnabled()) {
/* 404 */           this.logger.debug("Added metadata in out parameter for: " + parNameToUse);
/*     */         }
/*     */ 
/*     */       }
/* 408 */       else if ((this.limitedInParameterNames.isEmpty()) || (limitedInParamNamesMap.containsKey(parNameToUse.toLowerCase())))
/*     */       {
/* 410 */         workParameters.add(this.metaDataProvider.createDefaultInParameter(parNameToUse, meta));
/* 411 */         if (this.logger.isDebugEnabled()) {
/* 412 */           this.logger.debug("Added metadata in parameter for: " + parNameToUse);
/*     */         }
/*     */ 
/*     */       }
/* 416 */       else if (this.logger.isDebugEnabled()) {
/* 417 */         this.logger.debug("Limited set of parameters " + limitedInParamNamesMap.keySet() + " skipped parameter for: " + parNameToUse);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 426 */     return workParameters;
/*     */   }
/*     */ 
/*     */   public Map<String, Object> matchInParameterValuesWithCallParameters(SqlParameterSource parameterSource)
/*     */   {
/* 437 */     Map caseInsensitiveParameterNames = SqlParameterSourceUtils.extractCaseInsensitiveParameterNames(parameterSource);
/*     */ 
/* 440 */     Map callParameterNames = new HashMap(this.callParameters.size());
/* 441 */     Map matchedParameters = new HashMap(this.callParameters.size());
/* 442 */     for (SqlParameter parameter : this.callParameters) {
/* 443 */       if (parameter.isInputValueProvided()) {
/* 444 */         String parameterName = parameter.getName();
/* 445 */         String parameterNameToMatch = this.metaDataProvider.parameterNameToUse(parameterName);
/* 446 */         if (parameterNameToMatch != null) {
/* 447 */           callParameterNames.put(parameterNameToMatch.toLowerCase(), parameterName);
/*     */         }
/* 449 */         if (parameterName != null) {
/* 450 */           if (parameterSource.hasValue(parameterName)) {
/* 451 */             matchedParameters.put(parameterName, SqlParameterSourceUtils.getTypedValue(parameterSource, parameterName));
/*     */           }
/*     */           else {
/* 454 */             String lowerCaseName = parameterName.toLowerCase();
/* 455 */             if (parameterSource.hasValue(lowerCaseName)) {
/* 456 */               matchedParameters.put(parameterName, SqlParameterSourceUtils.getTypedValue(parameterSource, lowerCaseName));
/*     */             }
/*     */             else {
/* 459 */               String englishLowerCaseName = parameterName.toLowerCase(Locale.ENGLISH);
/* 460 */               if (parameterSource.hasValue(englishLowerCaseName)) {
/* 461 */                 matchedParameters.put(parameterName, SqlParameterSourceUtils.getTypedValue(parameterSource, englishLowerCaseName));
/*     */               }
/*     */               else {
/* 464 */                 String propertyName = JdbcUtils.convertUnderscoreNameToPropertyName(parameterName);
/* 465 */                 if (parameterSource.hasValue(propertyName)) {
/* 466 */                   matchedParameters.put(parameterName, SqlParameterSourceUtils.getTypedValue(parameterSource, propertyName));
/*     */                 }
/* 469 */                 else if (caseInsensitiveParameterNames.containsKey(lowerCaseName)) {
/* 470 */                   String sourceName = (String)caseInsensitiveParameterNames.get(lowerCaseName);
/* 471 */                   matchedParameters.put(parameterName, SqlParameterSourceUtils.getTypedValue(parameterSource, sourceName));
/*     */                 }
/*     */                 else {
/* 474 */                   this.logger.warn("Unable to locate the corresponding parameter value for '" + parameterName + "' within the parameter values provided: " + caseInsensitiveParameterNames.values());
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 485 */     if (this.logger.isDebugEnabled()) {
/* 486 */       this.logger.debug("Matching " + caseInsensitiveParameterNames.values() + " with " + callParameterNames.values());
/* 487 */       this.logger.debug("Found match for " + matchedParameters.keySet());
/*     */     }
/* 489 */     return matchedParameters;
/*     */   }
/*     */ 
/*     */   public Map<String, ?> matchInParameterValuesWithCallParameters(Map<String, ?> inParameters)
/*     */   {
/* 498 */     if (!this.metaDataProvider.isProcedureColumnMetaDataUsed()) {
/* 499 */       return inParameters;
/*     */     }
/* 501 */     Map callParameterNames = new HashMap(this.callParameters.size());
/* 502 */     for (SqlParameter parameter : this.callParameters) {
/* 503 */       if (parameter.isInputValueProvided()) {
/* 504 */         String parameterName = parameter.getName();
/* 505 */         String parameterNameToMatch = this.metaDataProvider.parameterNameToUse(parameterName);
/* 506 */         if (parameterNameToMatch != null) {
/* 507 */           callParameterNames.put(parameterNameToMatch.toLowerCase(), parameterName);
/*     */         }
/*     */       }
/*     */     }
/* 511 */     Map matchedParameters = new HashMap(inParameters.size());
/* 512 */     for (String parameterName : inParameters.keySet()) {
/* 513 */       String parameterNameToMatch = this.metaDataProvider.parameterNameToUse(parameterName);
/* 514 */       String callParameterName = (String)callParameterNames.get(parameterNameToMatch.toLowerCase());
/* 515 */       if (callParameterName == null) {
/* 516 */         if (this.logger.isDebugEnabled()) {
/* 517 */           Object value = inParameters.get(parameterName);
/* 518 */           if ((value instanceof SqlParameterValue)) {
/* 519 */             value = ((SqlParameterValue)value).getValue();
/*     */           }
/* 521 */           if (value != null) {
/* 522 */             this.logger.debug("Unable to locate the corresponding IN or IN-OUT parameter for \"" + parameterName + "\" in the parameters used: " + callParameterNames.keySet());
/*     */           }
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 528 */         matchedParameters.put(callParameterName, inParameters.get(parameterName));
/*     */       }
/*     */     }
/* 531 */     if (matchedParameters.size() < callParameterNames.size()) {
/* 532 */       for (String parameterName : callParameterNames.keySet()) {
/* 533 */         String parameterNameToMatch = this.metaDataProvider.parameterNameToUse(parameterName);
/* 534 */         String callParameterName = (String)callParameterNames.get(parameterNameToMatch.toLowerCase());
/* 535 */         if (!matchedParameters.containsKey(callParameterName)) {
/* 536 */           this.logger.warn("Unable to locate the corresponding parameter value for '" + parameterName + "' within the parameter values provided: " + inParameters.keySet());
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 541 */     if (this.logger.isDebugEnabled()) {
/* 542 */       this.logger.debug("Matching " + inParameters.keySet() + " with " + callParameterNames.values());
/* 543 */       this.logger.debug("Found match for " + matchedParameters.keySet());
/*     */     }
/* 545 */     return matchedParameters;
/*     */   }
/*     */ 
/*     */   public Map<String, ?> matchInParameterValuesWithCallParameters(Object[] parameterValues) {
/* 549 */     Map matchedParameters = new HashMap(parameterValues.length);
/* 550 */     int i = 0;
/* 551 */     for (SqlParameter parameter : this.callParameters) {
/* 552 */       if (parameter.isInputValueProvided()) {
/* 553 */         String parameterName = parameter.getName();
/* 554 */         matchedParameters.put(parameterName, parameterValues[(i++)]);
/*     */       }
/*     */     }
/* 557 */     return matchedParameters;
/*     */   }
/*     */ 
/*     */   public String createCallString()
/*     */   {
/* 566 */     int parameterCount = 0;
/*     */     String catalogNameToUse;
/*     */     String catalogNameToUse;
/*     */     String schemaNameToUse;
/* 572 */     if ((this.metaDataProvider.isSupportsSchemasInProcedureCalls()) && (!this.metaDataProvider.isSupportsCatalogsInProcedureCalls()))
/*     */     {
/* 574 */       String schemaNameToUse = this.metaDataProvider.catalogNameToUse(getCatalogName());
/* 575 */       catalogNameToUse = this.metaDataProvider.schemaNameToUse(getSchemaName());
/*     */     }
/*     */     else {
/* 578 */       catalogNameToUse = this.metaDataProvider.catalogNameToUse(getCatalogName());
/* 579 */       schemaNameToUse = this.metaDataProvider.schemaNameToUse(getSchemaName());
/*     */     }
/* 581 */     String procedureNameToUse = this.metaDataProvider.procedureNameToUse(getProcedureName());
/* 582 */     if ((isFunction()) || (isReturnValueRequired())) {
/* 583 */       String callString = "{? = call " + (StringUtils.hasLength(catalogNameToUse) ? catalogNameToUse + "." : "") + (StringUtils.hasLength(schemaNameToUse) ? schemaNameToUse + "." : "") + procedureNameToUse + "(";
/*     */ 
/* 587 */       parameterCount = -1;
/*     */     }
/*     */     else {
/* 590 */       callString = "{call " + (StringUtils.hasLength(catalogNameToUse) ? catalogNameToUse + "." : "") + (StringUtils.hasLength(schemaNameToUse) ? schemaNameToUse + "." : "") + procedureNameToUse + "(";
/*     */     }
/*     */ 
/* 595 */     for (SqlParameter parameter : this.callParameters) {
/* 596 */       if (!parameter.isResultsParameter()) {
/* 597 */         if (parameterCount > 0) {
/* 598 */           callString = callString + ", ";
/*     */         }
/* 600 */         if (parameterCount >= 0) {
/* 601 */           callString = callString + "?";
/*     */         }
/* 603 */         parameterCount++;
/*     */       }
/*     */     }
/* 606 */     String callString = callString + ")}";
/*     */ 
/* 608 */     return callString;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.CallMetaDataContext
 * JD-Core Version:    0.6.1
 */