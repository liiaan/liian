package org.springframework.jdbc.core;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public abstract interface PreparedStatementSetter
{
  public abstract void setValues(PreparedStatement paramPreparedStatement)
    throws SQLException;
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.PreparedStatementSetter
 * JD-Core Version:    0.6.1
 */