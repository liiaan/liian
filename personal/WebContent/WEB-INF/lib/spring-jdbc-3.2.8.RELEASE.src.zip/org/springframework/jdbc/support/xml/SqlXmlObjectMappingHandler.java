package org.springframework.jdbc.support.xml;

import java.sql.ResultSet;
import java.sql.SQLException;

public abstract interface SqlXmlObjectMappingHandler extends SqlXmlHandler
{
  public abstract Object getXmlAsObject(ResultSet paramResultSet, String paramString)
    throws SQLException;

  public abstract Object getXmlAsObject(ResultSet paramResultSet, int paramInt)
    throws SQLException;

  public abstract SqlXmlValue newMarshallingSqlXmlValue(Object paramObject);
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.xml.SqlXmlObjectMappingHandler
 * JD-Core Version:    0.6.1
 */