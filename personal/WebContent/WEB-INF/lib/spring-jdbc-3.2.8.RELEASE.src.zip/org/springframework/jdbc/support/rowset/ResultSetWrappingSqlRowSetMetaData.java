/*     */ package org.springframework.jdbc.support.rowset;
/*     */ 
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import org.springframework.jdbc.InvalidResultSetAccessException;
/*     */ 
/*     */ public class ResultSetWrappingSqlRowSetMetaData
/*     */   implements SqlRowSetMetaData
/*     */ {
/*     */   private final ResultSetMetaData resultSetMetaData;
/*     */   private String[] columnNames;
/*     */ 
/*     */   public ResultSetWrappingSqlRowSetMetaData(ResultSetMetaData resultSetMetaData)
/*     */   {
/*  54 */     this.resultSetMetaData = resultSetMetaData;
/*     */   }
/*     */ 
/*     */   public String getCatalogName(int column) throws InvalidResultSetAccessException
/*     */   {
/*     */     try {
/*  60 */       return this.resultSetMetaData.getCatalogName(column);
/*     */     }
/*     */     catch (SQLException se) {
/*  63 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getColumnClassName(int column) throws InvalidResultSetAccessException {
/*     */     try {
/*  69 */       return this.resultSetMetaData.getColumnClassName(column);
/*     */     }
/*     */     catch (SQLException se) {
/*  72 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getColumnCount() throws InvalidResultSetAccessException {
/*     */     try {
/*  78 */       return this.resultSetMetaData.getColumnCount();
/*     */     }
/*     */     catch (SQLException se) {
/*  81 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String[] getColumnNames() throws InvalidResultSetAccessException {
/*  86 */     if (this.columnNames == null) {
/*  87 */       this.columnNames = new String[getColumnCount()];
/*  88 */       for (int i = 0; i < getColumnCount(); i++) {
/*  89 */         this.columnNames[i] = getColumnName(i + 1);
/*     */       }
/*     */     }
/*  92 */     return this.columnNames;
/*     */   }
/*     */ 
/*     */   public int getColumnDisplaySize(int column) throws InvalidResultSetAccessException {
/*     */     try {
/*  97 */       return this.resultSetMetaData.getColumnDisplaySize(column);
/*     */     }
/*     */     catch (SQLException se) {
/* 100 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getColumnLabel(int column) throws InvalidResultSetAccessException {
/*     */     try {
/* 106 */       return this.resultSetMetaData.getColumnLabel(column);
/*     */     }
/*     */     catch (SQLException se) {
/* 109 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getColumnName(int column) throws InvalidResultSetAccessException {
/*     */     try {
/* 115 */       return this.resultSetMetaData.getColumnName(column);
/*     */     }
/*     */     catch (SQLException se) {
/* 118 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getColumnType(int column) throws InvalidResultSetAccessException {
/*     */     try {
/* 124 */       return this.resultSetMetaData.getColumnType(column);
/*     */     }
/*     */     catch (SQLException se) {
/* 127 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getColumnTypeName(int column) throws InvalidResultSetAccessException {
/*     */     try {
/* 133 */       return this.resultSetMetaData.getColumnTypeName(column);
/*     */     }
/*     */     catch (SQLException se) {
/* 136 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getPrecision(int column) throws InvalidResultSetAccessException {
/*     */     try {
/* 142 */       return this.resultSetMetaData.getPrecision(column);
/*     */     }
/*     */     catch (SQLException se) {
/* 145 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getScale(int column) throws InvalidResultSetAccessException {
/*     */     try {
/* 151 */       return this.resultSetMetaData.getScale(column);
/*     */     }
/*     */     catch (SQLException se) {
/* 154 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getSchemaName(int column) throws InvalidResultSetAccessException {
/*     */     try {
/* 160 */       return this.resultSetMetaData.getSchemaName(column);
/*     */     }
/*     */     catch (SQLException se) {
/* 163 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getTableName(int column) throws InvalidResultSetAccessException {
/*     */     try {
/* 169 */       return this.resultSetMetaData.getTableName(column);
/*     */     }
/*     */     catch (SQLException se) {
/* 172 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isCaseSensitive(int column) throws InvalidResultSetAccessException {
/*     */     try {
/* 178 */       return this.resultSetMetaData.isCaseSensitive(column);
/*     */     }
/*     */     catch (SQLException se) {
/* 181 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isCurrency(int column) throws InvalidResultSetAccessException {
/*     */     try {
/* 187 */       return this.resultSetMetaData.isCurrency(column);
/*     */     }
/*     */     catch (SQLException se) {
/* 190 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isSigned(int column) throws InvalidResultSetAccessException {
/*     */     try {
/* 196 */       return this.resultSetMetaData.isSigned(column);
/*     */     }
/*     */     catch (SQLException se) {
/* 199 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.rowset.ResultSetWrappingSqlRowSetMetaData
 * JD-Core Version:    0.6.1
 */