/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Savepoint;
/*     */ import org.springframework.transaction.support.ResourceHolderSupport;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class ConnectionHolder extends ResourceHolderSupport
/*     */ {
/*     */   public static final String SAVEPOINT_NAME_PREFIX = "SAVEPOINT_";
/*     */   private ConnectionHandle connectionHandle;
/*     */   private Connection currentConnection;
/*  50 */   private boolean transactionActive = false;
/*     */   private Boolean savepointsSupported;
/*  54 */   private int savepointCounter = 0;
/*     */ 
/*     */   public ConnectionHolder(ConnectionHandle connectionHandle)
/*     */   {
/*  62 */     Assert.notNull(connectionHandle, "ConnectionHandle must not be null");
/*  63 */     this.connectionHandle = connectionHandle;
/*     */   }
/*     */ 
/*     */   public ConnectionHolder(Connection connection)
/*     */   {
/*  75 */     this.connectionHandle = new SimpleConnectionHandle(connection);
/*     */   }
/*     */ 
/*     */   public ConnectionHolder(Connection connection, boolean transactionActive)
/*     */   {
/*  87 */     this(connection);
/*  88 */     this.transactionActive = transactionActive;
/*     */   }
/*     */ 
/*     */   public ConnectionHandle getConnectionHandle()
/*     */   {
/*  96 */     return this.connectionHandle;
/*     */   }
/*     */ 
/*     */   protected boolean hasConnection()
/*     */   {
/* 103 */     return this.connectionHandle != null;
/*     */   }
/*     */ 
/*     */   protected void setTransactionActive(boolean transactionActive)
/*     */   {
/* 111 */     this.transactionActive = transactionActive;
/*     */   }
/*     */ 
/*     */   protected boolean isTransactionActive()
/*     */   {
/* 118 */     return this.transactionActive;
/*     */   }
/*     */ 
/*     */   protected void setConnection(Connection connection)
/*     */   {
/* 129 */     if (this.currentConnection != null) {
/* 130 */       this.connectionHandle.releaseConnection(this.currentConnection);
/* 131 */       this.currentConnection = null;
/*     */     }
/* 133 */     if (connection != null) {
/* 134 */       this.connectionHandle = new SimpleConnectionHandle(connection);
/*     */     }
/*     */     else
/* 137 */       this.connectionHandle = null;
/*     */   }
/*     */ 
/*     */   public Connection getConnection()
/*     */   {
/* 150 */     Assert.notNull(this.connectionHandle, "Active Connection is required");
/* 151 */     if (this.currentConnection == null) {
/* 152 */       this.currentConnection = this.connectionHandle.getConnection();
/*     */     }
/* 154 */     return this.currentConnection;
/*     */   }
/*     */ 
/*     */   public boolean supportsSavepoints()
/*     */     throws SQLException
/*     */   {
/* 163 */     if (this.savepointsSupported == null) {
/* 164 */       this.savepointsSupported = new Boolean(getConnection().getMetaData().supportsSavepoints());
/*     */     }
/* 166 */     return this.savepointsSupported.booleanValue();
/*     */   }
/*     */ 
/*     */   public Savepoint createSavepoint()
/*     */     throws SQLException
/*     */   {
/* 176 */     this.savepointCounter += 1;
/* 177 */     return getConnection().setSavepoint("SAVEPOINT_" + this.savepointCounter);
/*     */   }
/*     */ 
/*     */   public void released()
/*     */   {
/* 191 */     super.released();
/* 192 */     if ((!isOpen()) && (this.currentConnection != null)) {
/* 193 */       this.connectionHandle.releaseConnection(this.currentConnection);
/* 194 */       this.currentConnection = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 201 */     super.clear();
/* 202 */     this.transactionActive = false;
/* 203 */     this.savepointsSupported = null;
/* 204 */     this.savepointCounter = 0;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.ConnectionHolder
 * JD-Core Version:    0.6.1
 */