/*    */ package org.springframework.jdbc.core;
/*    */ 
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.ResultSetMetaData;
/*    */ import java.sql.SQLException;
/*    */ import java.util.Map;
/*    */ import org.springframework.jdbc.support.JdbcUtils;
/*    */ import org.springframework.util.LinkedCaseInsensitiveMap;
/*    */ 
/*    */ public class ColumnMapRowMapper
/*    */   implements RowMapper<Map<String, Object>>
/*    */ {
/*    */   public Map<String, Object> mapRow(ResultSet rs, int rowNum)
/*    */     throws SQLException
/*    */   {
/* 51 */     ResultSetMetaData rsmd = rs.getMetaData();
/* 52 */     int columnCount = rsmd.getColumnCount();
/* 53 */     Map mapOfColValues = createColumnMap(columnCount);
/* 54 */     for (int i = 1; i <= columnCount; i++) {
/* 55 */       String key = getColumnKey(JdbcUtils.lookupColumnName(rsmd, i));
/* 56 */       Object obj = getColumnValue(rs, i);
/* 57 */       mapOfColValues.put(key, obj);
/*    */     }
/* 59 */     return mapOfColValues;
/*    */   }
/*    */ 
/*    */   protected Map<String, Object> createColumnMap(int columnCount)
/*    */   {
/* 71 */     return new LinkedCaseInsensitiveMap(columnCount);
/*    */   }
/*    */ 
/*    */   protected String getColumnKey(String columnName)
/*    */   {
/* 81 */     return columnName;
/*    */   }
/*    */ 
/*    */   protected Object getColumnValue(ResultSet rs, int index)
/*    */     throws SQLException
/*    */   {
/* 95 */     return JdbcUtils.getResultSetValue(rs, index);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.ColumnMapRowMapper
 * JD-Core Version:    0.6.1
 */