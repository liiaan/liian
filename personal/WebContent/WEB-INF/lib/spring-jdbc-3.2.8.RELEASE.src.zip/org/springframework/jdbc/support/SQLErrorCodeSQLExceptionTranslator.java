/*     */ package org.springframework.jdbc.support;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.sql.BatchUpdateException;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Arrays;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.core.JdkVersion;
/*     */ import org.springframework.dao.CannotAcquireLockException;
/*     */ import org.springframework.dao.CannotSerializeTransactionException;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.dao.DataIntegrityViolationException;
/*     */ import org.springframework.dao.DeadlockLoserDataAccessException;
/*     */ import org.springframework.dao.DuplicateKeyException;
/*     */ import org.springframework.dao.PermissionDeniedDataAccessException;
/*     */ import org.springframework.dao.TransientDataAccessResourceException;
/*     */ import org.springframework.jdbc.BadSqlGrammarException;
/*     */ import org.springframework.jdbc.InvalidResultSetAccessException;
/*     */ 
/*     */ public class SQLErrorCodeSQLExceptionTranslator extends AbstractFallbackSQLExceptionTranslator
/*     */ {
/*     */   private static final int MESSAGE_ONLY_CONSTRUCTOR = 1;
/*     */   private static final int MESSAGE_THROWABLE_CONSTRUCTOR = 2;
/*     */   private static final int MESSAGE_SQLEX_CONSTRUCTOR = 3;
/*     */   private static final int MESSAGE_SQL_THROWABLE_CONSTRUCTOR = 4;
/*     */   private static final int MESSAGE_SQL_SQLEX_CONSTRUCTOR = 5;
/*     */   private SQLErrorCodes sqlErrorCodes;
/*     */ 
/*     */   public SQLErrorCodeSQLExceptionTranslator()
/*     */   {
/*  85 */     if (JdkVersion.getMajorJavaVersion() >= 3) {
/*  86 */       setFallbackTranslator(new SQLExceptionSubclassTranslator());
/*     */     }
/*     */     else
/*  89 */       setFallbackTranslator(new SQLStateSQLExceptionTranslator());
/*     */   }
/*     */ 
/*     */   public SQLErrorCodeSQLExceptionTranslator(DataSource dataSource)
/*     */   {
/* 102 */     this();
/* 103 */     setDataSource(dataSource);
/*     */   }
/*     */ 
/*     */   public SQLErrorCodeSQLExceptionTranslator(String dbName)
/*     */   {
/* 115 */     this();
/* 116 */     setDatabaseProductName(dbName);
/*     */   }
/*     */ 
/*     */   public SQLErrorCodeSQLExceptionTranslator(SQLErrorCodes sec)
/*     */   {
/* 125 */     this();
/* 126 */     this.sqlErrorCodes = sec;
/*     */   }
/*     */ 
/*     */   public void setDataSource(DataSource dataSource)
/*     */   {
/* 140 */     this.sqlErrorCodes = SQLErrorCodesFactory.getInstance().getErrorCodes(dataSource);
/*     */   }
/*     */ 
/*     */   public void setDatabaseProductName(String dbName)
/*     */   {
/* 152 */     this.sqlErrorCodes = SQLErrorCodesFactory.getInstance().getErrorCodes(dbName);
/*     */   }
/*     */ 
/*     */   public void setSqlErrorCodes(SQLErrorCodes sec)
/*     */   {
/* 160 */     this.sqlErrorCodes = sec;
/*     */   }
/*     */ 
/*     */   public SQLErrorCodes getSqlErrorCodes()
/*     */   {
/* 169 */     return this.sqlErrorCodes;
/*     */   }
/*     */ 
/*     */   protected DataAccessException doTranslate(String task, String sql, SQLException ex)
/*     */   {
/* 175 */     SQLException sqlEx = ex;
/* 176 */     if (((sqlEx instanceof BatchUpdateException)) && (sqlEx.getNextException() != null)) {
/* 177 */       SQLException nestedSqlEx = sqlEx.getNextException();
/* 178 */       if ((nestedSqlEx.getErrorCode() > 0) || (nestedSqlEx.getSQLState() != null)) {
/* 179 */         this.logger.debug("Using nested SQLException from the BatchUpdateException");
/* 180 */         sqlEx = nestedSqlEx;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 185 */     DataAccessException dex = customTranslate(task, sql, sqlEx);
/* 186 */     if (dex != null) {
/* 187 */       return dex;
/*     */     }
/*     */ 
/* 191 */     if (this.sqlErrorCodes != null) {
/* 192 */       SQLExceptionTranslator customTranslator = this.sqlErrorCodes.getCustomSqlExceptionTranslator();
/* 193 */       if (customTranslator != null) {
/* 194 */         DataAccessException customDex = customTranslator.translate(task, sql, sqlEx);
/* 195 */         if (customDex != null) {
/* 196 */           return customDex;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 202 */     if (this.sqlErrorCodes != null)
/*     */     {
/*     */       String errorCode;
/*     */       String errorCode;
/* 204 */       if (this.sqlErrorCodes.isUseSqlStateForTranslation()) {
/* 205 */         errorCode = sqlEx.getSQLState();
/*     */       }
/*     */       else
/*     */       {
/* 210 */         SQLException current = sqlEx;
/* 211 */         while ((current.getErrorCode() == 0) && ((current.getCause() instanceof SQLException))) {
/* 212 */           current = (SQLException)current.getCause();
/*     */         }
/* 214 */         errorCode = Integer.toString(current.getErrorCode());
/*     */       }
/*     */ 
/* 217 */       if (errorCode != null)
/*     */       {
/* 219 */         CustomSQLErrorCodesTranslation[] customTranslations = this.sqlErrorCodes.getCustomTranslations();
/* 220 */         if (customTranslations != null) {
/* 221 */           for (CustomSQLErrorCodesTranslation customTranslation : customTranslations) {
/* 222 */             if ((Arrays.binarySearch(customTranslation.getErrorCodes(), errorCode) >= 0) && 
/* 223 */               (customTranslation.getExceptionClass() != null)) {
/* 224 */               DataAccessException customException = createCustomException(task, sql, sqlEx, customTranslation.getExceptionClass());
/*     */ 
/* 226 */               if (customException != null) {
/* 227 */                 logTranslation(task, sql, sqlEx, true);
/* 228 */                 return customException;
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 235 */         if (Arrays.binarySearch(this.sqlErrorCodes.getBadSqlGrammarCodes(), errorCode) >= 0) {
/* 236 */           logTranslation(task, sql, sqlEx, false);
/* 237 */           return new BadSqlGrammarException(task, sql, sqlEx);
/*     */         }
/* 239 */         if (Arrays.binarySearch(this.sqlErrorCodes.getInvalidResultSetAccessCodes(), errorCode) >= 0) {
/* 240 */           logTranslation(task, sql, sqlEx, false);
/* 241 */           return new InvalidResultSetAccessException(task, sql, sqlEx);
/*     */         }
/* 243 */         if (Arrays.binarySearch(this.sqlErrorCodes.getDuplicateKeyCodes(), errorCode) >= 0) {
/* 244 */           logTranslation(task, sql, sqlEx, false);
/* 245 */           return new DuplicateKeyException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */         }
/* 247 */         if (Arrays.binarySearch(this.sqlErrorCodes.getDataIntegrityViolationCodes(), errorCode) >= 0) {
/* 248 */           logTranslation(task, sql, sqlEx, false);
/* 249 */           return new DataIntegrityViolationException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */         }
/* 251 */         if (Arrays.binarySearch(this.sqlErrorCodes.getPermissionDeniedCodes(), errorCode) >= 0) {
/* 252 */           logTranslation(task, sql, sqlEx, false);
/* 253 */           return new PermissionDeniedDataAccessException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */         }
/* 255 */         if (Arrays.binarySearch(this.sqlErrorCodes.getDataAccessResourceFailureCodes(), errorCode) >= 0) {
/* 256 */           logTranslation(task, sql, sqlEx, false);
/* 257 */           return new DataAccessResourceFailureException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */         }
/* 259 */         if (Arrays.binarySearch(this.sqlErrorCodes.getTransientDataAccessResourceCodes(), errorCode) >= 0) {
/* 260 */           logTranslation(task, sql, sqlEx, false);
/* 261 */           return new TransientDataAccessResourceException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */         }
/* 263 */         if (Arrays.binarySearch(this.sqlErrorCodes.getCannotAcquireLockCodes(), errorCode) >= 0) {
/* 264 */           logTranslation(task, sql, sqlEx, false);
/* 265 */           return new CannotAcquireLockException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */         }
/* 267 */         if (Arrays.binarySearch(this.sqlErrorCodes.getDeadlockLoserCodes(), errorCode) >= 0) {
/* 268 */           logTranslation(task, sql, sqlEx, false);
/* 269 */           return new DeadlockLoserDataAccessException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */         }
/* 271 */         if (Arrays.binarySearch(this.sqlErrorCodes.getCannotSerializeTransactionCodes(), errorCode) >= 0) {
/* 272 */           logTranslation(task, sql, sqlEx, false);
/* 273 */           return new CannotSerializeTransactionException(buildMessage(task, sql, sqlEx), sqlEx);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 279 */     if (this.logger.isDebugEnabled())
/*     */     {
/*     */       String codes;
/*     */       String codes;
/* 281 */       if ((this.sqlErrorCodes != null) && (this.sqlErrorCodes.isUseSqlStateForTranslation())) {
/* 282 */         codes = "SQL state '" + sqlEx.getSQLState() + "', error code '" + sqlEx.getErrorCode();
/*     */       }
/*     */       else {
/* 285 */         codes = "Error code '" + sqlEx.getErrorCode() + "'";
/*     */       }
/* 287 */       this.logger.debug("Unable to translate SQLException with " + codes + ", will now try the fallback translator");
/*     */     }
/*     */ 
/* 290 */     return null;
/*     */   }
/*     */ 
/*     */   protected DataAccessException customTranslate(String task, String sql, SQLException sqlEx)
/*     */   {
/* 305 */     return null;
/*     */   }
/*     */ 
/*     */   protected DataAccessException createCustomException(String task, String sql, SQLException sqlEx, Class exceptionClass)
/*     */   {
/*     */     try
/*     */     {
/* 326 */       int constructorType = 0;
/* 327 */       Constructor[] constructors = exceptionClass.getConstructors();
/* 328 */       for (Constructor constructor : constructors) {
/* 329 */         Class[] parameterTypes = constructor.getParameterTypes();
/* 330 */         if ((parameterTypes.length == 1) && (parameterTypes[0].equals(String.class)) && 
/* 331 */           (constructorType < 1)) {
/* 332 */           constructorType = 1;
/*     */         }
/* 334 */         if ((parameterTypes.length == 2) && (parameterTypes[0].equals(String.class)) && (parameterTypes[1].equals(Throwable.class)))
/*     */         {
/* 336 */           if (constructorType < 2)
/* 337 */             constructorType = 2;
/*     */         }
/* 339 */         if ((parameterTypes.length == 2) && (parameterTypes[0].equals(String.class)) && (parameterTypes[1].equals(SQLException.class)))
/*     */         {
/* 341 */           if (constructorType < 3)
/* 342 */             constructorType = 3;
/*     */         }
/* 344 */         if ((parameterTypes.length == 3) && (parameterTypes[0].equals(String.class)) && (parameterTypes[1].equals(String.class)) && (parameterTypes[2].equals(Throwable.class)))
/*     */         {
/* 346 */           if (constructorType < 4)
/* 347 */             constructorType = 4;
/*     */         }
/* 349 */         if ((parameterTypes.length == 3) && (parameterTypes[0].equals(String.class)) && (parameterTypes[1].equals(String.class)) && (parameterTypes[2].equals(SQLException.class)))
/*     */         {
/* 351 */           if (constructorType < 5)
/* 352 */             constructorType = 5;
/*     */         }
/*     */       }
/*     */       Constructor exceptionConstructor;
/* 358 */       switch (constructorType) {
/*     */       case 5:
/* 360 */         Class[] messageAndSqlAndSqlExArgsClass = { String.class, String.class, SQLException.class };
/* 361 */         Object[] messageAndSqlAndSqlExArgs = { task, sql, sqlEx };
/* 362 */         exceptionConstructor = exceptionClass.getConstructor(messageAndSqlAndSqlExArgsClass);
/* 363 */         return (DataAccessException)exceptionConstructor.newInstance(messageAndSqlAndSqlExArgs);
/*     */       case 4:
/* 365 */         Class[] messageAndSqlAndThrowableArgsClass = { String.class, String.class, Throwable.class };
/* 366 */         Object[] messageAndSqlAndThrowableArgs = { task, sql, sqlEx };
/* 367 */         exceptionConstructor = exceptionClass.getConstructor(messageAndSqlAndThrowableArgsClass);
/* 368 */         return (DataAccessException)exceptionConstructor.newInstance(messageAndSqlAndThrowableArgs);
/*     */       case 3:
/* 370 */         Class[] messageAndSqlExArgsClass = { String.class, SQLException.class };
/* 371 */         Object[] messageAndSqlExArgs = { task + ": " + sqlEx.getMessage(), sqlEx };
/* 372 */         exceptionConstructor = exceptionClass.getConstructor(messageAndSqlExArgsClass);
/* 373 */         return (DataAccessException)exceptionConstructor.newInstance(messageAndSqlExArgs);
/*     */       case 2:
/* 375 */         Class[] messageAndThrowableArgsClass = { String.class, Throwable.class };
/* 376 */         Object[] messageAndThrowableArgs = { task + ": " + sqlEx.getMessage(), sqlEx };
/* 377 */         exceptionConstructor = exceptionClass.getConstructor(messageAndThrowableArgsClass);
/* 378 */         return (DataAccessException)exceptionConstructor.newInstance(messageAndThrowableArgs);
/*     */       case 1:
/* 380 */         Class[] messageOnlyArgsClass = { String.class };
/* 381 */         Object[] messageOnlyArgs = { task + ": " + sqlEx.getMessage() };
/* 382 */         exceptionConstructor = exceptionClass.getConstructor(messageOnlyArgsClass);
/* 383 */         return (DataAccessException)exceptionConstructor.newInstance(messageOnlyArgs);
/*     */       }
/* 385 */       if (this.logger.isWarnEnabled()) {
/* 386 */         this.logger.warn("Unable to find appropriate constructor of custom exception class [" + exceptionClass.getName() + "]");
/*     */       }
/*     */ 
/* 389 */       return null;
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 393 */       if (this.logger.isWarnEnabled())
/* 394 */         this.logger.warn("Unable to instantiate custom exception class [" + exceptionClass.getName() + "]", ex);
/*     */     }
/* 396 */     return null;
/*     */   }
/*     */ 
/*     */   private void logTranslation(String task, String sql, SQLException sqlEx, boolean custom)
/*     */   {
/* 401 */     if (this.logger.isDebugEnabled()) {
/* 402 */       String intro = custom ? "Custom translation of" : "Translating";
/* 403 */       this.logger.debug(intro + " SQLException with SQL state '" + sqlEx.getSQLState() + "', error code '" + sqlEx.getErrorCode() + "', message [" + sqlEx.getMessage() + "]; SQL was [" + sql + "] for task [" + task + "]");
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.SQLErrorCodeSQLExceptionTranslator
 * JD-Core Version:    0.6.1
 */