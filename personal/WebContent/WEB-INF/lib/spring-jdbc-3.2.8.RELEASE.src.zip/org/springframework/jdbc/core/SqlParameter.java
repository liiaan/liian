/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class SqlParameter
/*     */ {
/*     */   private String name;
/*     */   private final int sqlType;
/*     */   private String typeName;
/*     */   private Integer scale;
/*     */ 
/*     */   public SqlParameter(int sqlType)
/*     */   {
/*  56 */     this.sqlType = sqlType;
/*     */   }
/*     */ 
/*     */   public SqlParameter(int sqlType, String typeName)
/*     */   {
/*  65 */     this.sqlType = sqlType;
/*  66 */     this.typeName = typeName;
/*     */   }
/*     */ 
/*     */   public SqlParameter(int sqlType, int scale)
/*     */   {
/*  76 */     this.sqlType = sqlType;
/*  77 */     this.scale = Integer.valueOf(scale);
/*     */   }
/*     */ 
/*     */   public SqlParameter(String name, int sqlType)
/*     */   {
/*  86 */     this.name = name;
/*  87 */     this.sqlType = sqlType;
/*     */   }
/*     */ 
/*     */   public SqlParameter(String name, int sqlType, String typeName)
/*     */   {
/*  97 */     this.name = name;
/*  98 */     this.sqlType = sqlType;
/*  99 */     this.typeName = typeName;
/*     */   }
/*     */ 
/*     */   public SqlParameter(String name, int sqlType, int scale)
/*     */   {
/* 110 */     this.name = name;
/* 111 */     this.sqlType = sqlType;
/* 112 */     this.scale = Integer.valueOf(scale);
/*     */   }
/*     */ 
/*     */   public SqlParameter(SqlParameter otherParam)
/*     */   {
/* 120 */     Assert.notNull(otherParam, "SqlParameter object must not be null");
/* 121 */     this.name = otherParam.name;
/* 122 */     this.sqlType = otherParam.sqlType;
/* 123 */     this.typeName = otherParam.typeName;
/* 124 */     this.scale = otherParam.scale;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 132 */     return this.name;
/*     */   }
/*     */ 
/*     */   public int getSqlType()
/*     */   {
/* 139 */     return this.sqlType;
/*     */   }
/*     */ 
/*     */   public String getTypeName()
/*     */   {
/* 146 */     return this.typeName;
/*     */   }
/*     */ 
/*     */   public Integer getScale()
/*     */   {
/* 153 */     return this.scale;
/*     */   }
/*     */ 
/*     */   public boolean isInputValueProvided()
/*     */   {
/* 163 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isResultsParameter()
/*     */   {
/* 172 */     return false;
/*     */   }
/*     */ 
/*     */   public static List<SqlParameter> sqlTypesToAnonymousParameterList(int[] types)
/*     */   {
/* 181 */     List result = new LinkedList();
/* 182 */     if (types != null) {
/* 183 */       for (int type : types) {
/* 184 */         result.add(new SqlParameter(type));
/*     */       }
/*     */     }
/* 187 */     return result;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.SqlParameter
 * JD-Core Version:    0.6.1
 */