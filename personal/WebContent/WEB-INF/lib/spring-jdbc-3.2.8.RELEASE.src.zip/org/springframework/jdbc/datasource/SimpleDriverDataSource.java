/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.Driver;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.BeanUtils;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class SimpleDriverDataSource extends AbstractDriverBasedDataSource
/*     */ {
/*     */   private Driver driver;
/*     */ 
/*     */   public SimpleDriverDataSource()
/*     */   {
/*     */   }
/*     */ 
/*     */   public SimpleDriverDataSource(Driver driver, String url)
/*     */   {
/*  71 */     setDriver(driver);
/*  72 */     setUrl(url);
/*     */   }
/*     */ 
/*     */   public SimpleDriverDataSource(Driver driver, String url, String username, String password)
/*     */   {
/*  84 */     setDriver(driver);
/*  85 */     setUrl(url);
/*  86 */     setUsername(username);
/*  87 */     setPassword(password);
/*     */   }
/*     */ 
/*     */   public SimpleDriverDataSource(Driver driver, String url, Properties conProps)
/*     */   {
/*  98 */     setDriver(driver);
/*  99 */     setUrl(url);
/* 100 */     setConnectionProperties(conProps);
/*     */   }
/*     */ 
/*     */   public void setDriverClass(Class<? extends Driver> driverClass)
/*     */   {
/* 111 */     this.driver = ((Driver)BeanUtils.instantiateClass(driverClass));
/*     */   }
/*     */ 
/*     */   public void setDriver(Driver driver)
/*     */   {
/* 121 */     this.driver = driver;
/*     */   }
/*     */ 
/*     */   public Driver getDriver()
/*     */   {
/* 128 */     return this.driver;
/*     */   }
/*     */ 
/*     */   protected Connection getConnectionFromDriver(Properties props)
/*     */     throws SQLException
/*     */   {
/* 134 */     Driver driver = getDriver();
/* 135 */     String url = getUrl();
/* 136 */     Assert.notNull(driver, "Driver must not be null");
/* 137 */     if (this.logger.isDebugEnabled()) {
/* 138 */       this.logger.debug("Creating new JDBC Driver Connection to [" + url + "]");
/*     */     }
/* 140 */     return driver.connect(url, props);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.SimpleDriverDataSource
 * JD-Core Version:    0.6.1
 */