/*     */ package org.springframework.jdbc.object;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.SqlParameter;
/*     */ 
/*     */ public abstract class RdbmsOperation
/*     */   implements InitializingBean
/*     */ {
/*  62 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */ 
/*  65 */   private JdbcTemplate jdbcTemplate = new JdbcTemplate();
/*     */ 
/*  67 */   private int resultSetType = 1003;
/*     */ 
/*  69 */   private boolean updatableResults = false;
/*     */ 
/*  71 */   private boolean returnGeneratedKeys = false;
/*     */ 
/*  73 */   private String[] generatedKeysColumnNames = null;
/*     */   private String sql;
/*  77 */   private final List<SqlParameter> declaredParameters = new LinkedList();
/*     */   private boolean compiled;
/*     */ 
/*     */   public void setJdbcTemplate(JdbcTemplate jdbcTemplate)
/*     */   {
/*  94 */     if (jdbcTemplate == null) {
/*  95 */       throw new IllegalArgumentException("jdbcTemplate must not be null");
/*     */     }
/*  97 */     this.jdbcTemplate = jdbcTemplate;
/*     */   }
/*     */ 
/*     */   public JdbcTemplate getJdbcTemplate()
/*     */   {
/* 104 */     return this.jdbcTemplate;
/*     */   }
/*     */ 
/*     */   public void setDataSource(DataSource dataSource)
/*     */   {
/* 112 */     this.jdbcTemplate.setDataSource(dataSource);
/*     */   }
/*     */ 
/*     */   public void setFetchSize(int fetchSize)
/*     */   {
/* 124 */     this.jdbcTemplate.setFetchSize(fetchSize);
/*     */   }
/*     */ 
/*     */   public void setMaxRows(int maxRows)
/*     */   {
/* 135 */     this.jdbcTemplate.setMaxRows(maxRows);
/*     */   }
/*     */ 
/*     */   public void setQueryTimeout(int queryTimeout)
/*     */   {
/* 146 */     this.jdbcTemplate.setQueryTimeout(queryTimeout);
/*     */   }
/*     */ 
/*     */   public void setResultSetType(int resultSetType)
/*     */   {
/* 158 */     this.resultSetType = resultSetType;
/*     */   }
/*     */ 
/*     */   public int getResultSetType()
/*     */   {
/* 165 */     return this.resultSetType;
/*     */   }
/*     */ 
/*     */   public void setUpdatableResults(boolean updatableResults)
/*     */   {
/* 174 */     if (isCompiled()) {
/* 175 */       throw new InvalidDataAccessApiUsageException("The updateableResults flag must be set before the operation is compiled");
/*     */     }
/*     */ 
/* 178 */     this.updatableResults = updatableResults;
/*     */   }
/*     */ 
/*     */   public boolean isUpdatableResults()
/*     */   {
/* 185 */     return this.updatableResults;
/*     */   }
/*     */ 
/*     */   public void setReturnGeneratedKeys(boolean returnGeneratedKeys)
/*     */   {
/* 194 */     if (isCompiled()) {
/* 195 */       throw new InvalidDataAccessApiUsageException("The returnGeneratedKeys flag must be set before the operation is compiled");
/*     */     }
/*     */ 
/* 198 */     this.returnGeneratedKeys = returnGeneratedKeys;
/*     */   }
/*     */ 
/*     */   public boolean isReturnGeneratedKeys()
/*     */   {
/* 206 */     return this.returnGeneratedKeys;
/*     */   }
/*     */ 
/*     */   public void setGeneratedKeysColumnNames(String[] names)
/*     */   {
/* 214 */     if (isCompiled()) {
/* 215 */       throw new InvalidDataAccessApiUsageException("The column names for the generated keys must be set before the operation is compiled");
/*     */     }
/*     */ 
/* 218 */     this.generatedKeysColumnNames = names;
/*     */   }
/*     */ 
/*     */   public String[] getGeneratedKeysColumnNames()
/*     */   {
/* 225 */     return this.generatedKeysColumnNames;
/*     */   }
/*     */ 
/*     */   public void setSql(String sql)
/*     */   {
/* 232 */     this.sql = sql;
/*     */   }
/*     */ 
/*     */   public String getSql()
/*     */   {
/* 241 */     return this.sql;
/*     */   }
/*     */ 
/*     */   public void setTypes(int[] types)
/*     */     throws InvalidDataAccessApiUsageException
/*     */   {
/* 254 */     if (isCompiled()) {
/* 255 */       throw new InvalidDataAccessApiUsageException("Cannot add parameters once query is compiled");
/*     */     }
/* 257 */     if (types != null)
/* 258 */       for (int type : types)
/* 259 */         declareParameter(new SqlParameter(type));
/*     */   }
/*     */ 
/*     */   public void declareParameter(SqlParameter param)
/*     */     throws InvalidDataAccessApiUsageException
/*     */   {
/* 277 */     if (isCompiled()) {
/* 278 */       throw new InvalidDataAccessApiUsageException("Cannot add parameters once the query is compiled");
/*     */     }
/* 280 */     this.declaredParameters.add(param);
/*     */   }
/*     */ 
/*     */   public void setParameters(SqlParameter[] parameters)
/*     */   {
/* 291 */     if (isCompiled()) {
/* 292 */       throw new InvalidDataAccessApiUsageException("Cannot add parameters once the query is compiled");
/*     */     }
/* 294 */     for (int i = 0; i < parameters.length; i++)
/* 295 */       if (parameters[i] != null) {
/* 296 */         this.declaredParameters.add(parameters[i]);
/*     */       }
/*     */       else
/* 299 */         throw new InvalidDataAccessApiUsageException("Cannot add parameter at index " + i + " from " + Arrays.asList(parameters) + " since it is 'null'");
/*     */   }
/*     */ 
/*     */   protected List<SqlParameter> getDeclaredParameters()
/*     */   {
/* 309 */     return this.declaredParameters;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 317 */     compile();
/*     */   }
/*     */ 
/*     */   public final void compile()
/*     */     throws InvalidDataAccessApiUsageException
/*     */   {
/* 327 */     if (!isCompiled()) {
/* 328 */       if (getSql() == null) {
/* 329 */         throw new InvalidDataAccessApiUsageException("Property 'sql' is required");
/*     */       }
/*     */       try
/*     */       {
/* 333 */         this.jdbcTemplate.afterPropertiesSet();
/*     */       }
/*     */       catch (IllegalArgumentException ex) {
/* 336 */         throw new InvalidDataAccessApiUsageException(ex.getMessage());
/*     */       }
/*     */ 
/* 339 */       compileInternal();
/* 340 */       this.compiled = true;
/*     */ 
/* 342 */       if (this.logger.isDebugEnabled())
/* 343 */         this.logger.debug("RdbmsOperation with SQL [" + getSql() + "] compiled");
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isCompiled()
/*     */   {
/* 355 */     return this.compiled;
/*     */   }
/*     */ 
/*     */   protected void checkCompiled()
/*     */   {
/* 365 */     if (!isCompiled()) {
/* 366 */       this.logger.debug("SQL operation not compiled before execution - invoking compile");
/* 367 */       compile();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void validateParameters(Object[] parameters)
/*     */     throws InvalidDataAccessApiUsageException
/*     */   {
/* 379 */     checkCompiled();
/* 380 */     int declaredInParameters = 0;
/* 381 */     for (SqlParameter param : this.declaredParameters) {
/* 382 */       if (param.isInputValueProvided()) {
/* 383 */         if ((!supportsLobParameters()) && ((param.getSqlType() == 2004) || (param.getSqlType() == 2005)))
/*     */         {
/* 385 */           throw new InvalidDataAccessApiUsageException("BLOB or CLOB parameters are not allowed for this kind of operation");
/*     */         }
/*     */ 
/* 388 */         declaredInParameters++;
/*     */       }
/*     */     }
/* 391 */     validateParameterCount(parameters != null ? parameters.length : 0, declaredInParameters);
/*     */   }
/*     */ 
/*     */   protected void validateNamedParameters(Map<String, ?> parameters)
/*     */     throws InvalidDataAccessApiUsageException
/*     */   {
/* 402 */     checkCompiled();
/* 403 */     Map paramsToUse = parameters != null ? parameters : Collections.emptyMap();
/* 404 */     int declaredInParameters = 0;
/* 405 */     for (SqlParameter param : this.declaredParameters) {
/* 406 */       if (param.isInputValueProvided()) {
/* 407 */         if ((!supportsLobParameters()) && ((param.getSqlType() == 2004) || (param.getSqlType() == 2005)))
/*     */         {
/* 409 */           throw new InvalidDataAccessApiUsageException("BLOB or CLOB parameters are not allowed for this kind of operation");
/*     */         }
/*     */ 
/* 412 */         if ((param.getName() != null) && (!paramsToUse.containsKey(param.getName()))) {
/* 413 */           throw new InvalidDataAccessApiUsageException("The parameter named '" + param.getName() + "' was not among the parameters supplied: " + paramsToUse.keySet());
/*     */         }
/*     */ 
/* 416 */         declaredInParameters++;
/*     */       }
/*     */     }
/* 419 */     validateParameterCount(paramsToUse.size(), declaredInParameters);
/*     */   }
/*     */ 
/*     */   private void validateParameterCount(int suppliedParamCount, int declaredInParamCount)
/*     */   {
/* 428 */     if (suppliedParamCount < declaredInParamCount) {
/* 429 */       throw new InvalidDataAccessApiUsageException(suppliedParamCount + " parameters were supplied, but " + declaredInParamCount + " in parameters were declared in class [" + getClass().getName() + "]");
/*     */     }
/*     */ 
/* 432 */     if ((suppliedParamCount > this.declaredParameters.size()) && (!allowsUnusedParameters()))
/* 433 */       throw new InvalidDataAccessApiUsageException(suppliedParamCount + " parameters were supplied, but " + declaredInParamCount + " parameters were declared in class [" + getClass().getName() + "]");
/*     */   }
/*     */ 
/*     */   protected abstract void compileInternal()
/*     */     throws InvalidDataAccessApiUsageException;
/*     */ 
/*     */   protected boolean supportsLobParameters()
/*     */   {
/* 453 */     return true;
/*     */   }
/*     */ 
/*     */   protected boolean allowsUnusedParameters()
/*     */   {
/* 463 */     return false;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.object.RdbmsOperation
 * JD-Core Version:    0.6.1
 */