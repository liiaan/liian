/*     */ package org.springframework.jdbc.support;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.jdbc.CannotGetJdbcConnectionException;
/*     */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*     */ 
/*     */ public abstract class JdbcUtils
/*     */ {
/*     */   public static final int TYPE_UNKNOWN = -2147483648;
/*  56 */   private static final Log logger = LogFactory.getLog(JdbcUtils.class);
/*     */ 
/*     */   public static void closeConnection(Connection con)
/*     */   {
/*  65 */     if (con != null)
/*     */       try {
/*  67 */         con.close();
/*     */       }
/*     */       catch (SQLException ex) {
/*  70 */         logger.debug("Could not close JDBC Connection", ex);
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/*  74 */         logger.debug("Unexpected exception on closing JDBC Connection", ex);
/*     */       }
/*     */   }
/*     */ 
/*     */   public static void closeStatement(Statement stmt)
/*     */   {
/*  85 */     if (stmt != null)
/*     */       try {
/*  87 */         stmt.close();
/*     */       }
/*     */       catch (SQLException ex) {
/*  90 */         logger.trace("Could not close JDBC Statement", ex);
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/*  94 */         logger.trace("Unexpected exception on closing JDBC Statement", ex);
/*     */       }
/*     */   }
/*     */ 
/*     */   public static void closeResultSet(ResultSet rs)
/*     */   {
/* 105 */     if (rs != null)
/*     */       try {
/* 107 */         rs.close();
/*     */       }
/*     */       catch (SQLException ex) {
/* 110 */         logger.trace("Could not close JDBC ResultSet", ex);
/*     */       }
/*     */       catch (Throwable ex)
/*     */       {
/* 114 */         logger.trace("Unexpected exception on closing JDBC ResultSet", ex);
/*     */       }
/*     */   }
/*     */ 
/*     */   public static Object getResultSetValue(ResultSet rs, int index, Class requiredType)
/*     */     throws SQLException
/*     */   {
/* 133 */     if (requiredType == null) {
/* 134 */       return getResultSetValue(rs, index);
/*     */     }
/*     */ 
/* 137 */     Object value = null;
/* 138 */     boolean wasNullCheck = false;
/*     */ 
/* 141 */     if (String.class.equals(requiredType)) {
/* 142 */       value = rs.getString(index);
/*     */     }
/* 144 */     else if ((Boolean.TYPE.equals(requiredType)) || (Boolean.class.equals(requiredType))) {
/* 145 */       value = Boolean.valueOf(rs.getBoolean(index));
/* 146 */       wasNullCheck = true;
/*     */     }
/* 148 */     else if ((Byte.TYPE.equals(requiredType)) || (Byte.class.equals(requiredType))) {
/* 149 */       value = Byte.valueOf(rs.getByte(index));
/* 150 */       wasNullCheck = true;
/*     */     }
/* 152 */     else if ((Short.TYPE.equals(requiredType)) || (Short.class.equals(requiredType))) {
/* 153 */       value = Short.valueOf(rs.getShort(index));
/* 154 */       wasNullCheck = true;
/*     */     }
/* 156 */     else if ((Integer.TYPE.equals(requiredType)) || (Integer.class.equals(requiredType))) {
/* 157 */       value = Integer.valueOf(rs.getInt(index));
/* 158 */       wasNullCheck = true;
/*     */     }
/* 160 */     else if ((Long.TYPE.equals(requiredType)) || (Long.class.equals(requiredType))) {
/* 161 */       value = Long.valueOf(rs.getLong(index));
/* 162 */       wasNullCheck = true;
/*     */     }
/* 164 */     else if ((Float.TYPE.equals(requiredType)) || (Float.class.equals(requiredType))) {
/* 165 */       value = Float.valueOf(rs.getFloat(index));
/* 166 */       wasNullCheck = true;
/*     */     }
/* 168 */     else if ((Double.TYPE.equals(requiredType)) || (Double.class.equals(requiredType)) || (Number.class.equals(requiredType)))
/*     */     {
/* 170 */       value = Double.valueOf(rs.getDouble(index));
/* 171 */       wasNullCheck = true;
/*     */     }
/* 173 */     else if ([B.class.equals(requiredType)) {
/* 174 */       value = rs.getBytes(index);
/*     */     }
/* 176 */     else if (java.sql.Date.class.equals(requiredType)) {
/* 177 */       value = rs.getDate(index);
/*     */     }
/* 179 */     else if (Time.class.equals(requiredType)) {
/* 180 */       value = rs.getTime(index);
/*     */     }
/* 182 */     else if ((Timestamp.class.equals(requiredType)) || (java.util.Date.class.equals(requiredType))) {
/* 183 */       value = rs.getTimestamp(index);
/*     */     }
/* 185 */     else if (BigDecimal.class.equals(requiredType)) {
/* 186 */       value = rs.getBigDecimal(index);
/*     */     }
/* 188 */     else if (Blob.class.equals(requiredType)) {
/* 189 */       value = rs.getBlob(index);
/*     */     }
/* 191 */     else if (Clob.class.equals(requiredType)) {
/* 192 */       value = rs.getClob(index);
/*     */     }
/*     */     else
/*     */     {
/* 196 */       value = getResultSetValue(rs, index);
/*     */     }
/*     */ 
/* 201 */     if ((wasNullCheck) && (value != null) && (rs.wasNull())) {
/* 202 */       value = null;
/*     */     }
/* 204 */     return value;
/*     */   }
/*     */ 
/*     */   public static Object getResultSetValue(ResultSet rs, int index)
/*     */     throws SQLException
/*     */   {
/* 226 */     Object obj = rs.getObject(index);
/* 227 */     String className = null;
/* 228 */     if (obj != null) {
/* 229 */       className = obj.getClass().getName();
/*     */     }
/* 231 */     if ((obj instanceof Blob)) {
/* 232 */       obj = rs.getBytes(index);
/*     */     }
/* 234 */     else if ((obj instanceof Clob)) {
/* 235 */       obj = rs.getString(index);
/*     */     }
/* 237 */     else if ((className != null) && (("oracle.sql.TIMESTAMP".equals(className)) || ("oracle.sql.TIMESTAMPTZ".equals(className))))
/*     */     {
/* 240 */       obj = rs.getTimestamp(index);
/*     */     }
/* 242 */     else if ((className != null) && (className.startsWith("oracle.sql.DATE"))) {
/* 243 */       String metaDataClassName = rs.getMetaData().getColumnClassName(index);
/* 244 */       if (("java.sql.Timestamp".equals(metaDataClassName)) || ("oracle.sql.TIMESTAMP".equals(metaDataClassName)))
/*     */       {
/* 246 */         obj = rs.getTimestamp(index);
/*     */       }
/*     */       else {
/* 249 */         obj = rs.getDate(index);
/*     */       }
/*     */     }
/* 252 */     else if ((obj != null) && ((obj instanceof java.sql.Date)) && 
/* 253 */       ("java.sql.Timestamp".equals(rs.getMetaData().getColumnClassName(index)))) {
/* 254 */       obj = rs.getTimestamp(index);
/*     */     }
/*     */ 
/* 257 */     return obj;
/*     */   }
/*     */ 
/*     */   public static Object extractDatabaseMetaData(DataSource dataSource, DatabaseMetaDataCallback action)
/*     */     throws MetaDataAccessException
/*     */   {
/* 278 */     Connection con = null;
/*     */     try {
/* 280 */       con = DataSourceUtils.getConnection(dataSource);
/* 281 */       if (con == null)
/*     */       {
/* 283 */         throw new MetaDataAccessException("Connection returned by DataSource [" + dataSource + "] was null");
/*     */       }
/* 285 */       DatabaseMetaData metaData = con.getMetaData();
/* 286 */       if (metaData == null)
/*     */       {
/* 288 */         throw new MetaDataAccessException("DatabaseMetaData returned by Connection [" + con + "] was null");
/*     */       }
/* 290 */       return action.processMetaData(metaData);
/*     */     }
/*     */     catch (CannotGetJdbcConnectionException ex) {
/* 293 */       throw new MetaDataAccessException("Could not get Connection for extracting meta data", ex);
/*     */     }
/*     */     catch (SQLException ex) {
/* 296 */       throw new MetaDataAccessException("Error while extracting DatabaseMetaData", ex);
/*     */     }
/*     */     catch (AbstractMethodError err) {
/* 299 */       throw new MetaDataAccessException("JDBC DatabaseMetaData method not implemented by JDBC driver - upgrade your driver", err);
/*     */     }
/*     */     finally
/*     */     {
/* 303 */       DataSourceUtils.releaseConnection(con, dataSource);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Object extractDatabaseMetaData(DataSource dataSource, String metaDataMethodName)
/*     */     throws MetaDataAccessException
/*     */   {
/* 320 */     return extractDatabaseMetaData(dataSource, new DatabaseMetaDataCallback()
/*     */     {
/*     */       public Object processMetaData(DatabaseMetaData dbmd) throws SQLException, MetaDataAccessException {
/*     */         try {
/* 324 */           Method method = DatabaseMetaData.class.getMethod(this.val$metaDataMethodName, (Class[])null);
/* 325 */           return method.invoke(dbmd, (Object[])null);
/*     */         }
/*     */         catch (NoSuchMethodException ex) {
/* 328 */           throw new MetaDataAccessException("No method named '" + this.val$metaDataMethodName + "' found on DatabaseMetaData instance [" + dbmd + "]", ex);
/*     */         }
/*     */         catch (IllegalAccessException ex)
/*     */         {
/* 332 */           throw new MetaDataAccessException("Could not access DatabaseMetaData method '" + this.val$metaDataMethodName + "'", ex);
/*     */         }
/*     */         catch (InvocationTargetException ex)
/*     */         {
/* 336 */           if ((ex.getTargetException() instanceof SQLException)) {
/* 337 */             throw ((SQLException)ex.getTargetException());
/*     */           }
/* 339 */           throw new MetaDataAccessException("Invocation of DatabaseMetaData method '" + this.val$metaDataMethodName + "' failed", ex);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public static boolean supportsBatchUpdates(Connection con)
/*     */   {
/*     */     try
/*     */     {
/* 359 */       DatabaseMetaData dbmd = con.getMetaData();
/* 360 */       if (dbmd != null) {
/* 361 */         if (dbmd.supportsBatchUpdates()) {
/* 362 */           logger.debug("JDBC driver supports batch updates");
/* 363 */           return true;
/*     */         }
/*     */ 
/* 366 */         logger.debug("JDBC driver does not support batch updates");
/*     */       }
/*     */     }
/*     */     catch (SQLException ex)
/*     */     {
/* 371 */       logger.debug("JDBC driver 'supportsBatchUpdates' method threw exception", ex);
/*     */     }
/*     */     catch (AbstractMethodError err) {
/* 374 */       logger.debug("JDBC driver does not support JDBC 2.0 'supportsBatchUpdates' method", err);
/*     */     }
/* 376 */     return false;
/*     */   }
/*     */ 
/*     */   public static String commonDatabaseName(String source)
/*     */   {
/* 385 */     String name = source;
/* 386 */     if ((source != null) && (source.startsWith("DB2"))) {
/* 387 */       name = "DB2";
/*     */     }
/* 389 */     else if (("Sybase SQL Server".equals(source)) || ("Adaptive Server Enterprise".equals(source)) || ("ASE".equals(source)) || ("sql server".equalsIgnoreCase(source)))
/*     */     {
/* 393 */       name = "Sybase";
/*     */     }
/* 395 */     return name;
/*     */   }
/*     */ 
/*     */   public static boolean isNumeric(int sqlType)
/*     */   {
/* 404 */     return (-7 == sqlType) || (-5 == sqlType) || (3 == sqlType) || (8 == sqlType) || (6 == sqlType) || (4 == sqlType) || (2 == sqlType) || (7 == sqlType) || (5 == sqlType) || (-6 == sqlType);
/*     */   }
/*     */ 
/*     */   public static String lookupColumnName(ResultSetMetaData resultSetMetaData, int columnIndex)
/*     */     throws SQLException
/*     */   {
/* 423 */     String name = resultSetMetaData.getColumnLabel(columnIndex);
/* 424 */     if ((name == null) || (name.length() < 1)) {
/* 425 */       name = resultSetMetaData.getColumnName(columnIndex);
/*     */     }
/* 427 */     return name;
/*     */   }
/*     */ 
/*     */   public static String convertUnderscoreNameToPropertyName(String name)
/*     */   {
/* 437 */     StringBuilder result = new StringBuilder();
/* 438 */     boolean nextIsUpper = false;
/* 439 */     if ((name != null) && (name.length() > 0)) {
/* 440 */       if ((name.length() > 1) && (name.substring(1, 2).equals("_"))) {
/* 441 */         result.append(name.substring(0, 1).toUpperCase());
/*     */       }
/*     */       else {
/* 444 */         result.append(name.substring(0, 1).toLowerCase());
/*     */       }
/* 446 */       for (int i = 1; i < name.length(); i++) {
/* 447 */         String s = name.substring(i, i + 1);
/* 448 */         if (s.equals("_")) {
/* 449 */           nextIsUpper = true;
/*     */         }
/* 452 */         else if (nextIsUpper) {
/* 453 */           result.append(s.toUpperCase());
/* 454 */           nextIsUpper = false;
/*     */         }
/*     */         else {
/* 457 */           result.append(s.toLowerCase());
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 462 */     return result.toString();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.JdbcUtils
 * JD-Core Version:    0.6.1
 */