/*     */ package org.springframework.jdbc.support.incrementer;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ 
/*     */ public class SybaseMaxValueIncrementer extends AbstractColumnMaxValueIncrementer
/*     */ {
/*     */   private long[] valueCache;
/*  70 */   private int nextValueIndex = -1;
/*     */ 
/*     */   public SybaseMaxValueIncrementer()
/*     */   {
/*     */   }
/*     */ 
/*     */   public SybaseMaxValueIncrementer(DataSource dataSource, String incrementerName, String columnName)
/*     */   {
/*  89 */     super(dataSource, incrementerName, columnName);
/*     */   }
/*     */ 
/*     */   protected synchronized long getNextKey()
/*     */     throws DataAccessException
/*     */   {
/*  95 */     if ((this.nextValueIndex < 0) || (this.nextValueIndex >= getCacheSize()))
/*     */     {
/* 101 */       Connection con = DataSourceUtils.getConnection(getDataSource());
/* 102 */       Statement stmt = null;
/*     */       try {
/* 104 */         stmt = con.createStatement();
/* 105 */         DataSourceUtils.applyTransactionTimeout(stmt, getDataSource());
/* 106 */         this.valueCache = new long[getCacheSize()];
/* 107 */         this.nextValueIndex = 0;
/* 108 */         for (int i = 0; i < getCacheSize(); i++) {
/* 109 */           stmt.executeUpdate(getIncrementStatement());
/* 110 */           ResultSet rs = stmt.executeQuery("select @@identity");
/*     */           try {
/* 112 */             if (!rs.next()) {
/* 113 */               throw new DataAccessResourceFailureException("@@identity failed after executing an update");
/*     */             }
/* 115 */             this.valueCache[i] = rs.getLong(1);
/*     */           }
/*     */           finally {
/* 118 */             JdbcUtils.closeResultSet(rs);
/*     */           }
/*     */         }
/* 121 */         long maxValue = this.valueCache[(this.valueCache.length - 1)];
/* 122 */         stmt.executeUpdate("delete from " + getIncrementerName() + " where " + getColumnName() + " < " + maxValue);
/*     */       }
/*     */       catch (SQLException ex) {
/* 125 */         throw new DataAccessResourceFailureException("Could not increment identity", ex);
/*     */       }
/*     */       finally {
/* 128 */         JdbcUtils.closeStatement(stmt);
/* 129 */         DataSourceUtils.releaseConnection(con, getDataSource());
/*     */       }
/*     */     }
/* 132 */     return this.valueCache[(this.nextValueIndex++)];
/*     */   }
/*     */ 
/*     */   protected String getIncrementStatement()
/*     */   {
/* 140 */     return "insert into " + getIncrementerName() + " values()";
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.incrementer.SybaseMaxValueIncrementer
 * JD-Core Version:    0.6.1
 */