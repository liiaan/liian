/*    */ package org.springframework.jdbc.core.metadata;
/*    */ 
/*    */ public class CallParameterMetaData
/*    */ {
/*    */   private String parameterName;
/*    */   private int parameterType;
/*    */   private int sqlType;
/*    */   private String typeName;
/*    */   private boolean nullable;
/*    */ 
/*    */   public CallParameterMetaData(String columnName, int columnType, int sqlType, String typeName, boolean nullable)
/*    */   {
/* 36 */     this.parameterName = columnName;
/* 37 */     this.parameterType = columnType;
/* 38 */     this.sqlType = sqlType;
/* 39 */     this.typeName = typeName;
/* 40 */     this.nullable = nullable;
/*    */   }
/*    */ 
/*    */   public String getParameterName()
/*    */   {
/* 48 */     return this.parameterName;
/*    */   }
/*    */ 
/*    */   public int getParameterType()
/*    */   {
/* 55 */     return this.parameterType;
/*    */   }
/*    */ 
/*    */   public int getSqlType()
/*    */   {
/* 62 */     return this.sqlType;
/*    */   }
/*    */ 
/*    */   public String getTypeName()
/*    */   {
/* 69 */     return this.typeName;
/*    */   }
/*    */ 
/*    */   public boolean isNullable()
/*    */   {
/* 76 */     return this.nullable;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.CallParameterMetaData
 * JD-Core Version:    0.6.1
 */