/*    */ package org.springframework.jdbc.core.namedparam;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public abstract class AbstractSqlParameterSource
/*    */   implements SqlParameterSource
/*    */ {
/* 33 */   private final Map<String, Integer> sqlTypes = new HashMap();
/*    */ 
/* 35 */   private final Map<String, String> typeNames = new HashMap();
/*    */ 
/*    */   public void registerSqlType(String paramName, int sqlType)
/*    */   {
/* 44 */     Assert.notNull(paramName, "Parameter name must not be null");
/* 45 */     this.sqlTypes.put(paramName, Integer.valueOf(sqlType));
/*    */   }
/*    */ 
/*    */   public void registerTypeName(String paramName, String typeName)
/*    */   {
/* 54 */     Assert.notNull(paramName, "Parameter name must not be null");
/* 55 */     this.typeNames.put(paramName, typeName);
/*    */   }
/*    */ 
/*    */   public int getSqlType(String paramName)
/*    */   {
/* 65 */     Assert.notNull(paramName, "Parameter name must not be null");
/* 66 */     Integer sqlType = (Integer)this.sqlTypes.get(paramName);
/* 67 */     if (sqlType != null) {
/* 68 */       return sqlType.intValue();
/*    */     }
/* 70 */     return -2147483648;
/*    */   }
/*    */ 
/*    */   public String getTypeName(String paramName)
/*    */   {
/* 80 */     Assert.notNull(paramName, "Parameter name must not be null");
/* 81 */     return (String)this.typeNames.get(paramName);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.namedparam.AbstractSqlParameterSource
 * JD-Core Version:    0.6.1
 */