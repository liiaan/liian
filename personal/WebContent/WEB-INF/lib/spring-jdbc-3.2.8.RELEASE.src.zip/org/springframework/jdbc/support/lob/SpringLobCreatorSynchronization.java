/*    */ package org.springframework.jdbc.support.lob;
/*    */ 
/*    */ import org.springframework.transaction.support.TransactionSynchronizationAdapter;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class SpringLobCreatorSynchronization extends TransactionSynchronizationAdapter
/*    */ {
/*    */   public static final int LOB_CREATOR_SYNCHRONIZATION_ORDER = 800;
/*    */   private final LobCreator lobCreator;
/* 46 */   private boolean beforeCompletionCalled = false;
/*    */ 
/*    */   public SpringLobCreatorSynchronization(LobCreator lobCreator)
/*    */   {
/* 54 */     Assert.notNull(lobCreator, "LobCreator must not be null");
/* 55 */     this.lobCreator = lobCreator;
/*    */   }
/*    */ 
/*    */   public int getOrder()
/*    */   {
/* 60 */     return 800;
/*    */   }
/*    */ 
/*    */   public void beforeCompletion()
/*    */   {
/* 69 */     this.beforeCompletionCalled = true;
/* 70 */     this.lobCreator.close();
/*    */   }
/*    */ 
/*    */   public void afterCompletion(int status)
/*    */   {
/* 75 */     if (!this.beforeCompletionCalled)
/*    */     {
/* 79 */       this.lobCreator.close();
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.lob.SpringLobCreatorSynchronization
 * JD-Core Version:    0.6.1
 */