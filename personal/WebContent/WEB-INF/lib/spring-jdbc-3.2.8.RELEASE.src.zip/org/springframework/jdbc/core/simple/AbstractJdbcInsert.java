/*     */ package org.springframework.jdbc.core.simple;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.DataIntegrityViolationException;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.dao.InvalidDataAccessResourceUsageException;
/*     */ import org.springframework.jdbc.core.BatchPreparedStatementSetter;
/*     */ import org.springframework.jdbc.core.ConnectionCallback;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.PreparedStatementCreator;
/*     */ import org.springframework.jdbc.core.StatementCreatorUtils;
/*     */ import org.springframework.jdbc.core.metadata.TableMetaDataContext;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*     */ import org.springframework.jdbc.support.GeneratedKeyHolder;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ import org.springframework.jdbc.support.KeyHolder;
/*     */ import org.springframework.jdbc.support.nativejdbc.NativeJdbcExtractor;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class AbstractJdbcInsert
/*     */ {
/*  65 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private final JdbcTemplate jdbcTemplate;
/*  71 */   private final TableMetaDataContext tableMetaDataContext = new TableMetaDataContext();
/*     */ 
/*  74 */   private final List<String> declaredColumns = new ArrayList();
/*     */ 
/*  81 */   private boolean compiled = false;
/*     */   private String insertString;
/*     */   private int[] insertTypes;
/*  90 */   private String[] generatedKeyNames = new String[0];
/*     */ 
/*     */   protected AbstractJdbcInsert(DataSource dataSource)
/*     */   {
/*  97 */     this.jdbcTemplate = new JdbcTemplate(dataSource);
/*     */   }
/*     */ 
/*     */   protected AbstractJdbcInsert(JdbcTemplate jdbcTemplate)
/*     */   {
/* 104 */     Assert.notNull(jdbcTemplate, "JdbcTemplate must not be null");
/* 105 */     this.jdbcTemplate = jdbcTemplate;
/* 106 */     setNativeJdbcExtractor(jdbcTemplate.getNativeJdbcExtractor());
/*     */   }
/*     */ 
/*     */   public JdbcTemplate getJdbcTemplate()
/*     */   {
/* 118 */     return this.jdbcTemplate;
/*     */   }
/*     */ 
/*     */   public void setTableName(String tableName)
/*     */   {
/* 125 */     checkIfConfigurationModificationIsAllowed();
/* 126 */     this.tableMetaDataContext.setTableName(tableName);
/*     */   }
/*     */ 
/*     */   public String getTableName()
/*     */   {
/* 133 */     return this.tableMetaDataContext.getTableName();
/*     */   }
/*     */ 
/*     */   public void setSchemaName(String schemaName)
/*     */   {
/* 140 */     checkIfConfigurationModificationIsAllowed();
/* 141 */     this.tableMetaDataContext.setSchemaName(schemaName);
/*     */   }
/*     */ 
/*     */   public String getSchemaName()
/*     */   {
/* 148 */     return this.tableMetaDataContext.getSchemaName();
/*     */   }
/*     */ 
/*     */   public void setCatalogName(String catalogName)
/*     */   {
/* 155 */     checkIfConfigurationModificationIsAllowed();
/* 156 */     this.tableMetaDataContext.setCatalogName(catalogName);
/*     */   }
/*     */ 
/*     */   public String getCatalogName()
/*     */   {
/* 163 */     return this.tableMetaDataContext.getCatalogName();
/*     */   }
/*     */ 
/*     */   public void setColumnNames(List<String> columnNames)
/*     */   {
/* 170 */     checkIfConfigurationModificationIsAllowed();
/* 171 */     this.declaredColumns.clear();
/* 172 */     this.declaredColumns.addAll(columnNames);
/*     */   }
/*     */ 
/*     */   public List<String> getColumnNames()
/*     */   {
/* 179 */     return Collections.unmodifiableList(this.declaredColumns);
/*     */   }
/*     */ 
/*     */   public String[] getGeneratedKeyNames()
/*     */   {
/* 186 */     return this.generatedKeyNames;
/*     */   }
/*     */ 
/*     */   public void setGeneratedKeyNames(String[] generatedKeyNames)
/*     */   {
/* 193 */     checkIfConfigurationModificationIsAllowed();
/* 194 */     this.generatedKeyNames = generatedKeyNames;
/*     */   }
/*     */ 
/*     */   public void setGeneratedKeyName(String generatedKeyName)
/*     */   {
/* 201 */     checkIfConfigurationModificationIsAllowed();
/* 202 */     this.generatedKeyNames = new String[] { generatedKeyName };
/*     */   }
/*     */ 
/*     */   public void setAccessTableColumnMetaData(boolean accessTableColumnMetaData)
/*     */   {
/* 209 */     this.tableMetaDataContext.setAccessTableColumnMetaData(accessTableColumnMetaData);
/*     */   }
/*     */ 
/*     */   public void setOverrideIncludeSynonymsDefault(boolean override)
/*     */   {
/* 216 */     this.tableMetaDataContext.setOverrideIncludeSynonymsDefault(override);
/*     */   }
/*     */ 
/*     */   public void setNativeJdbcExtractor(NativeJdbcExtractor nativeJdbcExtractor)
/*     */   {
/* 223 */     this.tableMetaDataContext.setNativeJdbcExtractor(nativeJdbcExtractor);
/*     */   }
/*     */ 
/*     */   public String getInsertString()
/*     */   {
/* 230 */     return this.insertString;
/*     */   }
/*     */ 
/*     */   public int[] getInsertTypes()
/*     */   {
/* 237 */     return this.insertTypes;
/*     */   }
/*     */ 
/*     */   public final synchronized void compile()
/*     */     throws InvalidDataAccessApiUsageException
/*     */   {
/* 253 */     if (!isCompiled()) {
/* 254 */       if (getTableName() == null)
/* 255 */         throw new InvalidDataAccessApiUsageException("Table name is required");
/*     */       try
/*     */       {
/* 258 */         this.jdbcTemplate.afterPropertiesSet();
/*     */       }
/*     */       catch (IllegalArgumentException ex) {
/* 261 */         throw new InvalidDataAccessApiUsageException(ex.getMessage());
/*     */       }
/* 263 */       compileInternal();
/* 264 */       this.compiled = true;
/* 265 */       if (this.logger.isDebugEnabled())
/* 266 */         this.logger.debug("JdbcInsert for table [" + getTableName() + "] compiled");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void compileInternal()
/*     */   {
/* 276 */     this.tableMetaDataContext.processMetaData(getJdbcTemplate().getDataSource(), getColumnNames(), getGeneratedKeyNames());
/*     */ 
/* 278 */     this.insertString = this.tableMetaDataContext.createInsertString(getGeneratedKeyNames());
/* 279 */     this.insertTypes = this.tableMetaDataContext.createInsertTypes();
/* 280 */     if (this.logger.isDebugEnabled()) {
/* 281 */       this.logger.debug("Compiled insert object: insert string is [" + getInsertString() + "]");
/*     */     }
/* 283 */     onCompileInternal();
/*     */   }
/*     */ 
/*     */   protected void onCompileInternal()
/*     */   {
/*     */   }
/*     */ 
/*     */   public boolean isCompiled()
/*     */   {
/* 298 */     return this.compiled;
/*     */   }
/*     */ 
/*     */   protected void checkCompiled()
/*     */   {
/* 307 */     if (!isCompiled()) {
/* 308 */       this.logger.debug("JdbcInsert not compiled before execution - invoking compile");
/* 309 */       compile();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void checkIfConfigurationModificationIsAllowed()
/*     */   {
/* 318 */     if (isCompiled())
/* 319 */       throw new InvalidDataAccessApiUsageException("Configuration can't be altered once the class has been compiled or used");
/*     */   }
/*     */ 
/*     */   protected int doExecute(Map<String, Object> args)
/*     */   {
/* 335 */     checkCompiled();
/* 336 */     List values = matchInParameterValuesWithInsertColumns(args);
/* 337 */     return executeInsertInternal(values);
/*     */   }
/*     */ 
/*     */   protected int doExecute(SqlParameterSource parameterSource)
/*     */   {
/* 346 */     checkCompiled();
/* 347 */     List values = matchInParameterValuesWithInsertColumns(parameterSource);
/* 348 */     return executeInsertInternal(values);
/*     */   }
/*     */ 
/*     */   private int executeInsertInternal(List<Object> values)
/*     */   {
/* 355 */     if (this.logger.isDebugEnabled()) {
/* 356 */       this.logger.debug("The following parameters are used for insert " + getInsertString() + " with: " + values);
/*     */     }
/* 358 */     return getJdbcTemplate().update(getInsertString(), values.toArray(), getInsertTypes());
/*     */   }
/*     */ 
/*     */   protected Number doExecuteAndReturnKey(Map<String, Object> args)
/*     */   {
/* 369 */     checkCompiled();
/* 370 */     List values = matchInParameterValuesWithInsertColumns(args);
/* 371 */     return executeInsertAndReturnKeyInternal(values);
/*     */   }
/*     */ 
/*     */   protected Number doExecuteAndReturnKey(SqlParameterSource parameterSource)
/*     */   {
/* 382 */     checkCompiled();
/* 383 */     List values = matchInParameterValuesWithInsertColumns(parameterSource);
/* 384 */     return executeInsertAndReturnKeyInternal(values);
/*     */   }
/*     */ 
/*     */   protected KeyHolder doExecuteAndReturnKeyHolder(Map<String, Object> args)
/*     */   {
/* 395 */     checkCompiled();
/* 396 */     List values = matchInParameterValuesWithInsertColumns(args);
/* 397 */     return executeInsertAndReturnKeyHolderInternal(values);
/*     */   }
/*     */ 
/*     */   protected KeyHolder doExecuteAndReturnKeyHolder(SqlParameterSource parameterSource)
/*     */   {
/* 408 */     checkCompiled();
/* 409 */     List values = matchInParameterValuesWithInsertColumns(parameterSource);
/* 410 */     return executeInsertAndReturnKeyHolderInternal(values);
/*     */   }
/*     */ 
/*     */   private Number executeInsertAndReturnKeyInternal(List<Object> values)
/*     */   {
/* 417 */     KeyHolder kh = executeInsertAndReturnKeyHolderInternal(values);
/* 418 */     if ((kh != null) && (kh.getKey() != null)) {
/* 419 */       return kh.getKey();
/*     */     }
/*     */ 
/* 422 */     throw new DataIntegrityViolationException("Unable to retrieve the generated key for the insert: " + getInsertString());
/*     */   }
/*     */ 
/*     */   private KeyHolder executeInsertAndReturnKeyHolderInternal(final List<Object> values)
/*     */   {
/* 431 */     if (this.logger.isDebugEnabled()) {
/* 432 */       this.logger.debug("The following parameters are used for call " + getInsertString() + " with: " + values);
/*     */     }
/* 434 */     final KeyHolder keyHolder = new GeneratedKeyHolder();
/* 435 */     if (this.tableMetaDataContext.isGetGeneratedKeysSupported()) {
/* 436 */       getJdbcTemplate().update(new PreparedStatementCreator()
/*     */       {
/*     */         public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
/* 439 */           PreparedStatement ps = AbstractJdbcInsert.this.prepareStatementForGeneratedKeys(con);
/* 440 */           AbstractJdbcInsert.this.setParameterValues(ps, values, AbstractJdbcInsert.this.getInsertTypes());
/* 441 */           return ps;
/*     */         }
/*     */       }
/*     */       , keyHolder);
/*     */     }
/*     */     else
/*     */     {
/* 447 */       if (!this.tableMetaDataContext.isGetGeneratedKeysSimulated()) {
/* 448 */         throw new InvalidDataAccessResourceUsageException("The getGeneratedKeys feature is not supported by this database");
/*     */       }
/*     */ 
/* 451 */       if (getGeneratedKeyNames().length < 1) {
/* 452 */         throw new InvalidDataAccessApiUsageException("Generated Key Name(s) not specificed. Using the generated keys features requires specifying the name(s) of the generated column(s)");
/*     */       }
/*     */ 
/* 455 */       if (getGeneratedKeyNames().length > 1) {
/* 456 */         throw new InvalidDataAccessApiUsageException("Current database only supports retreiving the key for a single column. There are " + getGeneratedKeyNames().length + " columns specified: " + Arrays.asList(getGeneratedKeyNames()));
/*     */       }
/*     */ 
/* 463 */       final String keyQuery = this.tableMetaDataContext.getSimulationQueryForGetGeneratedKey(this.tableMetaDataContext.getTableName(), getGeneratedKeyNames()[0]);
/*     */ 
/* 465 */       Assert.notNull(keyQuery, "Query for simulating get generated keys can't be null");
/* 466 */       if (keyQuery.toUpperCase().startsWith("RETURNING")) {
/* 467 */         Long key = (Long)getJdbcTemplate().queryForObject(getInsertString() + " " + keyQuery, values.toArray(new Object[values.size()]), Long.class);
/*     */ 
/* 469 */         Map keys = new HashMap(1);
/* 470 */         keys.put(getGeneratedKeyNames()[0], key);
/* 471 */         keyHolder.getKeyList().add(keys);
/*     */       }
/*     */       else {
/* 474 */         getJdbcTemplate().execute(new ConnectionCallback()
/*     */         {
/*     */           public Object doInConnection(Connection con) throws SQLException, DataAccessException {
/* 477 */             PreparedStatement ps = null;
/*     */             try {
/* 479 */               ps = con.prepareStatement(AbstractJdbcInsert.this.getInsertString());
/* 480 */               AbstractJdbcInsert.this.setParameterValues(ps, values, AbstractJdbcInsert.this.getInsertTypes());
/* 481 */               ps.executeUpdate();
/*     */             }
/*     */             finally {
/* 484 */               JdbcUtils.closeStatement(ps);
/*     */             }
/*     */ 
/* 487 */             Statement keyStmt = null;
/* 488 */             ResultSet rs = null;
/* 489 */             Map keys = new HashMap(1);
/*     */             try {
/* 491 */               keyStmt = con.createStatement();
/* 492 */               rs = keyStmt.executeQuery(keyQuery);
/* 493 */               if (rs.next()) {
/* 494 */                 long key = rs.getLong(1);
/* 495 */                 keys.put(AbstractJdbcInsert.this.getGeneratedKeyNames()[0], Long.valueOf(key));
/* 496 */                 keyHolder.getKeyList().add(keys);
/*     */               }
/*     */             }
/*     */             finally {
/* 500 */               JdbcUtils.closeResultSet(rs);
/* 501 */               JdbcUtils.closeStatement(keyStmt);
/*     */             }
/* 503 */             return null;
/*     */           }
/*     */         });
/*     */       }
/* 507 */       return keyHolder;
/*     */     }
/* 509 */     return keyHolder;
/*     */   }
/*     */ 
/*     */   private PreparedStatement prepareStatementForGeneratedKeys(Connection con)
/*     */     throws SQLException
/*     */   {
/* 520 */     if (getGeneratedKeyNames().length < 1)
/* 521 */       throw new InvalidDataAccessApiUsageException("Generated Key Name(s) not specificed. Using the generated keys features requires specifying the name(s) of the generated column(s)");
/*     */     PreparedStatement ps;
/*     */     PreparedStatement ps;
/* 525 */     if (this.tableMetaDataContext.isGeneratedKeysColumnNameArraySupported()) {
/* 526 */       if (this.logger.isDebugEnabled()) {
/* 527 */         this.logger.debug("Using generated keys support with array of column names.");
/*     */       }
/* 529 */       ps = con.prepareStatement(getInsertString(), getGeneratedKeyNames());
/*     */     }
/*     */     else {
/* 532 */       if (this.logger.isDebugEnabled()) {
/* 533 */         this.logger.debug("Using generated keys support with Statement.RETURN_GENERATED_KEYS.");
/*     */       }
/* 535 */       ps = con.prepareStatement(getInsertString(), 1);
/*     */     }
/* 537 */     return ps;
/*     */   }
/*     */ 
/*     */   protected int[] doExecuteBatch(Map<String, Object>[] batch)
/*     */   {
/* 547 */     checkCompiled();
/* 548 */     List[] batchValues = new ArrayList[batch.length];
/* 549 */     int i = 0;
/* 550 */     for (Map args : batch) {
/* 551 */       List values = matchInParameterValuesWithInsertColumns(args);
/* 552 */       batchValues[(i++)] = values;
/*     */     }
/* 554 */     return executeBatchInternal(batchValues);
/*     */   }
/*     */ 
/*     */   protected int[] doExecuteBatch(SqlParameterSource[] batch)
/*     */   {
/* 564 */     checkCompiled();
/* 565 */     List[] batchValues = new ArrayList[batch.length];
/* 566 */     int i = 0;
/* 567 */     for (SqlParameterSource parameterSource : batch) {
/* 568 */       List values = matchInParameterValuesWithInsertColumns(parameterSource);
/* 569 */       batchValues[(i++)] = values;
/*     */     }
/* 571 */     return executeBatchInternal(batchValues);
/*     */   }
/*     */ 
/*     */   private int[] executeBatchInternal(final List<Object>[] batchValues)
/*     */   {
/* 578 */     if (this.logger.isDebugEnabled()) {
/* 579 */       this.logger.debug("Executing statement " + getInsertString() + " with batch of size: " + batchValues.length);
/*     */     }
/* 581 */     return getJdbcTemplate().batchUpdate(getInsertString(), new BatchPreparedStatementSetter()
/*     */     {
/*     */       public void setValues(PreparedStatement ps, int i) throws SQLException {
/* 584 */         List values = batchValues[i];
/* 585 */         AbstractJdbcInsert.this.setParameterValues(ps, values, AbstractJdbcInsert.this.getInsertTypes());
/*     */       }
/*     */       public int getBatchSize() {
/* 588 */         return batchValues.length;
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   private void setParameterValues(PreparedStatement preparedStatement, List<Object> values, int[] columnTypes)
/*     */     throws SQLException
/*     */   {
/* 601 */     int colIndex = 0;
/* 602 */     for (Iterator i$ = values.iterator(); i$.hasNext(); ) { Object value = i$.next();
/* 603 */       colIndex++;
/* 604 */       if ((columnTypes == null) || (colIndex > columnTypes.length)) {
/* 605 */         StatementCreatorUtils.setParameterValue(preparedStatement, colIndex, -2147483648, value);
/*     */       }
/*     */       else
/* 608 */         StatementCreatorUtils.setParameterValue(preparedStatement, colIndex, columnTypes[(colIndex - 1)], value);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected List<Object> matchInParameterValuesWithInsertColumns(SqlParameterSource parameterSource)
/*     */   {
/* 620 */     return this.tableMetaDataContext.matchInParameterValuesWithInsertColumns(parameterSource);
/*     */   }
/*     */ 
/*     */   protected List<Object> matchInParameterValuesWithInsertColumns(Map<String, Object> args)
/*     */   {
/* 630 */     return this.tableMetaDataContext.matchInParameterValuesWithInsertColumns(args);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.simple.AbstractJdbcInsert
 * JD-Core Version:    0.6.1
 */