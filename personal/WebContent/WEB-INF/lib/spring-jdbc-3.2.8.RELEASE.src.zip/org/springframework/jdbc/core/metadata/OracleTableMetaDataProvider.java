/*     */ package org.springframework.jdbc.core.metadata;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.SQLException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.jdbc.support.nativejdbc.NativeJdbcExtractor;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class OracleTableMetaDataProvider extends GenericTableMetaDataProvider
/*     */ {
/*     */   private final boolean includeSynonyms;
/*     */   private String defaultSchema;
/*     */ 
/*     */   public OracleTableMetaDataProvider(DatabaseMetaData databaseMetaData)
/*     */     throws SQLException
/*     */   {
/*  50 */     this(databaseMetaData, false);
/*     */   }
/*     */ 
/*     */   public OracleTableMetaDataProvider(DatabaseMetaData databaseMetaData, boolean includeSynonyms) throws SQLException {
/*  54 */     super(databaseMetaData);
/*  55 */     this.includeSynonyms = includeSynonyms;
/*  56 */     lookupDefaultSchema(databaseMetaData);
/*     */   }
/*     */ 
/*     */   protected String getDefaultSchema()
/*     */   {
/*  61 */     if (this.defaultSchema != null) {
/*  62 */       return this.defaultSchema;
/*     */     }
/*  64 */     return super.getDefaultSchema();
/*     */   }
/*     */ 
/*     */   public void initializeWithTableColumnMetaData(DatabaseMetaData databaseMetaData, String catalogName, String schemaName, String tableName)
/*     */     throws SQLException
/*     */   {
/*  71 */     if (!this.includeSynonyms) {
/*  72 */       logger.debug("Defaulting to no synonyms in table metadata lookup");
/*  73 */       super.initializeWithTableColumnMetaData(databaseMetaData, catalogName, schemaName, tableName);
/*  74 */       return;
/*     */     }
/*     */ 
/*  77 */     Connection con = databaseMetaData.getConnection();
/*  78 */     NativeJdbcExtractor nativeJdbcExtractor = getNativeJdbcExtractor();
/*  79 */     if (nativeJdbcExtractor != null)
/*  80 */       con = nativeJdbcExtractor.getNativeConnection(con);
/*     */     boolean isOracleCon;
/*     */     try
/*     */     {
/*  84 */       Class oracleConClass = getClass().getClassLoader().loadClass("oracle.jdbc.OracleConnection");
/*  85 */       isOracleCon = oracleConClass.isInstance(con);
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/*  88 */       if (logger.isInfoEnabled()) {
/*  89 */         logger.info("Couldn't find Oracle JDBC API: " + ex);
/*     */       }
/*  91 */       isOracleCon = false;
/*     */     }
/*     */ 
/*  94 */     if (!isOracleCon) {
/*  95 */       logger.warn("Unable to include synonyms in table metadata lookup. Connection used for DatabaseMetaData is not recognized as an Oracle connection: " + con);
/*     */ 
/*  97 */       super.initializeWithTableColumnMetaData(databaseMetaData, catalogName, schemaName, tableName);
/*  98 */       return;
/* 101 */     }
/*     */ logger.debug("Including synonyms in table metadata lookup");
/*     */     Boolean originalValueForIncludeSynonyms;
/*     */     Method setIncludeSynonyms;
/*     */     try {
/* 106 */       Method getIncludeSynonyms = con.getClass().getMethod("getIncludeSynonyms", (Class[])null);
/* 107 */       ReflectionUtils.makeAccessible(getIncludeSynonyms);
/* 108 */       originalValueForIncludeSynonyms = (Boolean)getIncludeSynonyms.invoke(con, new Object[0]);
/*     */ 
/* 110 */       setIncludeSynonyms = con.getClass().getMethod("setIncludeSynonyms", new Class[] { Boolean.TYPE });
/* 111 */       ReflectionUtils.makeAccessible(setIncludeSynonyms);
/* 112 */       setIncludeSynonyms.invoke(con, new Object[] { Boolean.TRUE });
/*     */     }
/*     */     catch (Exception ex) {
/* 115 */       throw new InvalidDataAccessApiUsageException("Couldn't prepare Oracle Connection", ex);
/*     */     }
/*     */ 
/* 118 */     super.initializeWithTableColumnMetaData(databaseMetaData, catalogName, schemaName, tableName);
/*     */     try
/*     */     {
/* 121 */       setIncludeSynonyms.invoke(con, new Object[] { originalValueForIncludeSynonyms });
/*     */     }
/*     */     catch (Exception ex) {
/* 124 */       throw new InvalidDataAccessApiUsageException("Couldn't reset Oracle Connection", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void lookupDefaultSchema(DatabaseMetaData databaseMetaData)
/*     */   {
/*     */     try
/*     */     {
/* 135 */       CallableStatement cstmt = null;
/*     */       try {
/* 137 */         cstmt = databaseMetaData.getConnection().prepareCall("{? = call sys_context('USERENV', 'CURRENT_SCHEMA')}");
/* 138 */         cstmt.registerOutParameter(1, 12);
/* 139 */         cstmt.execute();
/* 140 */         this.defaultSchema = cstmt.getString(1);
/*     */       }
/*     */       finally {
/* 143 */         if (cstmt != null)
/* 144 */           cstmt.close();
/*     */       }
/*     */     }
/*     */     catch (Exception ignore)
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.OracleTableMetaDataProvider
 * JD-Core Version:    0.6.1
 */