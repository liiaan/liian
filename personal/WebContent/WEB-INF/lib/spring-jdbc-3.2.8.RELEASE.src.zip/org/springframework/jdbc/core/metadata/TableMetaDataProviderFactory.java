/*    */ package org.springframework.jdbc.core.metadata;
/*    */ 
/*    */ import java.sql.DatabaseMetaData;
/*    */ import java.sql.SQLException;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ import org.springframework.dao.DataAccessResourceFailureException;
/*    */ import org.springframework.jdbc.support.DatabaseMetaDataCallback;
/*    */ import org.springframework.jdbc.support.JdbcUtils;
/*    */ import org.springframework.jdbc.support.MetaDataAccessException;
/*    */ import org.springframework.jdbc.support.nativejdbc.NativeJdbcExtractor;
/*    */ 
/*    */ public class TableMetaDataProviderFactory
/*    */ {
/* 40 */   private static final Log logger = LogFactory.getLog(TableMetaDataProviderFactory.class);
/*    */ 
/*    */   public static TableMetaDataProvider createMetaDataProvider(DataSource dataSource, TableMetaDataContext context)
/*    */   {
/* 50 */     return createMetaDataProvider(dataSource, context, null);
/*    */   }
/*    */ 
/*    */   public static TableMetaDataProvider createMetaDataProvider(DataSource dataSource, TableMetaDataContext context, final NativeJdbcExtractor nativeJdbcExtractor)
/*    */   {
/*    */     try
/*    */     {
/* 63 */       return (TableMetaDataProvider)JdbcUtils.extractDatabaseMetaData(dataSource, new DatabaseMetaDataCallback()
/*    */       {
/*    */         public Object processMetaData(DatabaseMetaData databaseMetaData) throws SQLException {
/* 66 */           String databaseProductName = JdbcUtils.commonDatabaseName(databaseMetaData.getDatabaseProductName());
/*    */ 
/* 68 */           boolean accessTableColumnMetaData = this.val$context.isAccessTableColumnMetaData();
/*    */           TableMetaDataProvider provider;
/*    */           TableMetaDataProvider provider;
/* 70 */           if ("Oracle".equals(databaseProductName)) {
/* 71 */             provider = new OracleTableMetaDataProvider(databaseMetaData, this.val$context.isOverrideIncludeSynonymsDefault());
/*    */           }
/*    */           else
/*    */           {
/*    */             TableMetaDataProvider provider;
/* 74 */             if ("HSQL Database Engine".equals(databaseProductName)) {
/* 75 */               provider = new HsqlTableMetaDataProvider(databaseMetaData);
/*    */             }
/*    */             else
/*    */             {
/*    */               TableMetaDataProvider provider;
/* 77 */               if ("PostgreSQL".equals(databaseProductName)) {
/* 78 */                 provider = new PostgresTableMetaDataProvider(databaseMetaData);
/*    */               }
/*    */               else
/*    */               {
/*    */                 TableMetaDataProvider provider;
/* 80 */                 if ("Apache Derby".equals(databaseProductName)) {
/* 81 */                   provider = new DerbyTableMetaDataProvider(databaseMetaData);
/*    */                 }
/*    */                 else
/* 84 */                   provider = new GenericTableMetaDataProvider(databaseMetaData); 
/*    */               }
/*    */             }
/*    */           }
/* 86 */           if (nativeJdbcExtractor != null) {
/* 87 */             provider.setNativeJdbcExtractor(nativeJdbcExtractor);
/*    */           }
/* 89 */           if (TableMetaDataProviderFactory.logger.isDebugEnabled()) {
/* 90 */             TableMetaDataProviderFactory.logger.debug("Using " + provider.getClass().getSimpleName());
/*    */           }
/* 92 */           provider.initializeWithMetaData(databaseMetaData);
/* 93 */           if (accessTableColumnMetaData) {
/* 94 */             provider.initializeWithTableColumnMetaData(databaseMetaData, this.val$context.getCatalogName(), this.val$context.getSchemaName(), this.val$context.getTableName());
/*    */           }
/*    */ 
/* 97 */           return provider;
/*    */         }
/*    */       });
/*    */     }
/*    */     catch (MetaDataAccessException ex) {
/* 102 */       throw new DataAccessResourceFailureException("Error retrieving database metadata", ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.TableMetaDataProviderFactory
 * JD-Core Version:    0.6.1
 */