package org.springframework.jdbc.datasource.embedded;

import javax.sql.DataSource;

public abstract interface EmbeddedDatabaseConfigurer
{
  public abstract void configureConnectionProperties(ConnectionProperties paramConnectionProperties, String paramString);

  public abstract void shutdown(DataSource paramDataSource, String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseConfigurer
 * JD-Core Version:    0.6.1
 */