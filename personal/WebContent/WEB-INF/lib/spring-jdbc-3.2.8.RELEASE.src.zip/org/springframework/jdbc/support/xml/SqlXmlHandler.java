package org.springframework.jdbc.support.xml;

import java.io.InputStream;
import java.io.Reader;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.xml.transform.Source;
import org.w3c.dom.Document;

public abstract interface SqlXmlHandler
{
  public abstract String getXmlAsString(ResultSet paramResultSet, String paramString)
    throws SQLException;

  public abstract String getXmlAsString(ResultSet paramResultSet, int paramInt)
    throws SQLException;

  public abstract InputStream getXmlAsBinaryStream(ResultSet paramResultSet, String paramString)
    throws SQLException;

  public abstract InputStream getXmlAsBinaryStream(ResultSet paramResultSet, int paramInt)
    throws SQLException;

  public abstract Reader getXmlAsCharacterStream(ResultSet paramResultSet, String paramString)
    throws SQLException;

  public abstract Reader getXmlAsCharacterStream(ResultSet paramResultSet, int paramInt)
    throws SQLException;

  public abstract Source getXmlAsSource(ResultSet paramResultSet, String paramString, Class paramClass)
    throws SQLException;

  public abstract Source getXmlAsSource(ResultSet paramResultSet, int paramInt, Class paramClass)
    throws SQLException;

  public abstract SqlXmlValue newSqlXmlValue(String paramString);

  public abstract SqlXmlValue newSqlXmlValue(XmlBinaryStreamProvider paramXmlBinaryStreamProvider);

  public abstract SqlXmlValue newSqlXmlValue(XmlCharacterStreamProvider paramXmlCharacterStreamProvider);

  public abstract SqlXmlValue newSqlXmlValue(Class paramClass, XmlResultProvider paramXmlResultProvider);

  public abstract SqlXmlValue newSqlXmlValue(Document paramDocument);
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.xml.SqlXmlHandler
 * JD-Core Version:    0.6.1
 */