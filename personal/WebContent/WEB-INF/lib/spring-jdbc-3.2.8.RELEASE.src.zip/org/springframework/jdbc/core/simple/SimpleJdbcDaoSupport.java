/*    */ package org.springframework.jdbc.core.simple;
/*    */ 
/*    */ import org.springframework.jdbc.core.support.JdbcDaoSupport;
/*    */ 
/*    */ @Deprecated
/*    */ public class SimpleJdbcDaoSupport extends JdbcDaoSupport
/*    */ {
/*    */   private SimpleJdbcTemplate simpleJdbcTemplate;
/*    */ 
/*    */   protected void initTemplateConfig()
/*    */   {
/* 45 */     this.simpleJdbcTemplate = new SimpleJdbcTemplate(getJdbcTemplate());
/*    */   }
/*    */ 
/*    */   public SimpleJdbcTemplate getSimpleJdbcTemplate()
/*    */   {
/* 52 */     return this.simpleJdbcTemplate;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport
 * JD-Core Version:    0.6.1
 */