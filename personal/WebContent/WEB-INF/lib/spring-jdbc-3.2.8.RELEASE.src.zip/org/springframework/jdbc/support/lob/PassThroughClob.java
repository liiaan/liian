/*     */ package org.springframework.jdbc.support.lob;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.io.Writer;
/*     */ import java.sql.Clob;
/*     */ import java.sql.SQLException;
/*     */ import org.springframework.util.FileCopyUtils;
/*     */ 
/*     */ class PassThroughClob
/*     */   implements Clob
/*     */ {
/*     */   private String content;
/*     */   private Reader characterStream;
/*     */   private InputStream asciiStream;
/*     */   private long contentLength;
/*     */ 
/*     */   public PassThroughClob(String content)
/*     */   {
/*  52 */     this.content = content;
/*  53 */     this.contentLength = content.length();
/*     */   }
/*     */ 
/*     */   public PassThroughClob(Reader characterStream, long contentLength) {
/*  57 */     this.characterStream = characterStream;
/*  58 */     this.contentLength = contentLength;
/*     */   }
/*     */ 
/*     */   public PassThroughClob(InputStream asciiStream, long contentLength) {
/*  62 */     this.asciiStream = asciiStream;
/*  63 */     this.contentLength = contentLength;
/*     */   }
/*     */ 
/*     */   public long length() throws SQLException
/*     */   {
/*  68 */     return this.contentLength;
/*     */   }
/*     */ 
/*     */   public Reader getCharacterStream() throws SQLException {
/*     */     try {
/*  73 */       if (this.content != null) {
/*  74 */         return new StringReader(this.content);
/*     */       }
/*  76 */       if (this.characterStream != null) {
/*  77 */         return this.characterStream;
/*     */       }
/*     */ 
/*  80 */       return new InputStreamReader(this.asciiStream, "US-ASCII");
/*     */     }
/*     */     catch (UnsupportedEncodingException ex)
/*     */     {
/*  84 */       throw new SQLException("US-ASCII encoding not supported: " + ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public InputStream getAsciiStream() throws SQLException {
/*     */     try {
/*  90 */       if (this.content != null) {
/*  91 */         return new ByteArrayInputStream(this.content.getBytes("US-ASCII"));
/*     */       }
/*  93 */       if (this.characterStream != null) {
/*  94 */         String tempContent = FileCopyUtils.copyToString(this.characterStream);
/*  95 */         return new ByteArrayInputStream(tempContent.getBytes("US-ASCII"));
/*     */       }
/*     */ 
/*  98 */       return this.asciiStream;
/*     */     }
/*     */     catch (UnsupportedEncodingException ex)
/*     */     {
/* 102 */       throw new SQLException("US-ASCII encoding not supported: " + ex);
/*     */     }
/*     */     catch (IOException ex) {
/* 105 */       throw new SQLException("Failed to read stream content: " + ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Reader getCharacterStream(long pos, long length) throws SQLException
/*     */   {
/* 111 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public Writer setCharacterStream(long pos) throws SQLException {
/* 115 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public OutputStream setAsciiStream(long pos) throws SQLException {
/* 119 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public String getSubString(long pos, int length) throws SQLException {
/* 123 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public int setString(long pos, String str) throws SQLException {
/* 127 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public int setString(long pos, String str, int offset, int len) throws SQLException {
/* 131 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public long position(String searchstr, long start) throws SQLException {
/* 135 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public long position(Clob searchstr, long start) throws SQLException {
/* 139 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public void truncate(long len) throws SQLException {
/* 143 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public void free()
/*     */     throws SQLException
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.lob.PassThroughClob
 * JD-Core Version:    0.6.1
 */