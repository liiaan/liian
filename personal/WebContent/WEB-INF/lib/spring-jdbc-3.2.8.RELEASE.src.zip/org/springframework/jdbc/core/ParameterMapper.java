package org.springframework.jdbc.core;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Map;

public abstract interface ParameterMapper
{
  public abstract Map<String, ?> createMap(Connection paramConnection)
    throws SQLException;
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.ParameterMapper
 * JD-Core Version:    0.6.1
 */