/*    */ package org.springframework.jdbc.object;
/*    */ 
/*    */ import java.util.Map;
/*    */ import org.springframework.dao.InvalidDataAccessResourceUsageException;
/*    */ import org.springframework.jdbc.core.RowMapper;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class GenericSqlQuery extends SqlQuery
/*    */ {
/*    */   Class rowMapperClass;
/*    */   RowMapper rowMapper;
/*    */ 
/*    */   public void setRowMapperClass(Class rowMapperClass)
/*    */     throws IllegalAccessException, InstantiationException
/*    */   {
/* 33 */     this.rowMapperClass = rowMapperClass;
/* 34 */     if (!RowMapper.class.isAssignableFrom(rowMapperClass))
/* 35 */       throw new IllegalStateException("The specified class '" + rowMapperClass.getName() + " is not a sub class of " + "'org.springframework.jdbc.core.RowMapper'");
/*    */   }
/*    */ 
/*    */   public void afterPropertiesSet()
/*    */   {
/* 41 */     super.afterPropertiesSet();
/* 42 */     Assert.notNull(this.rowMapperClass, "The 'rowMapperClass' property is required");
/*    */   }
/*    */ 
/*    */   protected RowMapper newRowMapper(Object[] parameters, Map context) {
/*    */     try {
/* 47 */       return (RowMapper)this.rowMapperClass.newInstance();
/*    */     }
/*    */     catch (InstantiationException e) {
/* 50 */       throw new InvalidDataAccessResourceUsageException("Unable to instantiate RowMapper", e);
/*    */     }
/*    */     catch (IllegalAccessException e) {
/* 53 */       throw new InvalidDataAccessResourceUsageException("Unable to instantiate RowMapper", e);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.object.GenericSqlQuery
 * JD-Core Version:    0.6.1
 */