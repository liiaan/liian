/*     */ package org.springframework.jdbc.support.nativejdbc;
/*     */ 
/*     */ public class SimpleNativeJdbcExtractor extends NativeJdbcExtractorAdapter
/*     */ {
/*  74 */   private boolean nativeConnectionNecessaryForNativeStatements = false;
/*     */ 
/*  76 */   private boolean nativeConnectionNecessaryForNativePreparedStatements = false;
/*     */ 
/*  78 */   private boolean nativeConnectionNecessaryForNativeCallableStatements = false;
/*     */ 
/*     */   public void setNativeConnectionNecessaryForNativeStatements(boolean nativeConnectionNecessaryForNativeStatements)
/*     */   {
/*  94 */     this.nativeConnectionNecessaryForNativeStatements = nativeConnectionNecessaryForNativeStatements;
/*     */   }
/*     */ 
/*     */   public boolean isNativeConnectionNecessaryForNativeStatements()
/*     */   {
/*  99 */     return this.nativeConnectionNecessaryForNativeStatements;
/*     */   }
/*     */ 
/*     */   public void setNativeConnectionNecessaryForNativePreparedStatements(boolean nativeConnectionNecessary)
/*     */   {
/* 115 */     this.nativeConnectionNecessaryForNativePreparedStatements = nativeConnectionNecessary;
/*     */   }
/*     */ 
/*     */   public boolean isNativeConnectionNecessaryForNativePreparedStatements()
/*     */   {
/* 120 */     return this.nativeConnectionNecessaryForNativePreparedStatements;
/*     */   }
/*     */ 
/*     */   public void setNativeConnectionNecessaryForNativeCallableStatements(boolean nativeConnectionNecessary)
/*     */   {
/* 136 */     this.nativeConnectionNecessaryForNativeCallableStatements = nativeConnectionNecessary;
/*     */   }
/*     */ 
/*     */   public boolean isNativeConnectionNecessaryForNativeCallableStatements()
/*     */   {
/* 141 */     return this.nativeConnectionNecessaryForNativeCallableStatements;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.nativejdbc.SimpleNativeJdbcExtractor
 * JD-Core Version:    0.6.1
 */