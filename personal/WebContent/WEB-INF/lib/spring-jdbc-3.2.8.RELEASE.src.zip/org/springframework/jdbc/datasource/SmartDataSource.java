package org.springframework.jdbc.datasource;

import java.sql.Connection;
import javax.sql.DataSource;

public abstract interface SmartDataSource extends DataSource
{
  public abstract boolean shouldClose(Connection paramConnection);
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.SmartDataSource
 * JD-Core Version:    0.6.1
 */