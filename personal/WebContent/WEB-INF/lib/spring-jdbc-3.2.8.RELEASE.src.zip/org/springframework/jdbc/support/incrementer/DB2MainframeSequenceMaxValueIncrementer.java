/*    */ package org.springframework.jdbc.support.incrementer;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ public class DB2MainframeSequenceMaxValueIncrementer extends AbstractSequenceMaxValueIncrementer
/*    */ {
/*    */   public DB2MainframeSequenceMaxValueIncrementer()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DB2MainframeSequenceMaxValueIncrementer(DataSource dataSource, String incrementerName)
/*    */   {
/* 45 */     super(dataSource, incrementerName);
/*    */   }
/*    */ 
/*    */   protected String getSequenceQuery()
/*    */   {
/* 51 */     return "select next value for " + getIncrementerName() + " from sysibm.sysdummy1";
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.incrementer.DB2MainframeSequenceMaxValueIncrementer
 * JD-Core Version:    0.6.1
 */