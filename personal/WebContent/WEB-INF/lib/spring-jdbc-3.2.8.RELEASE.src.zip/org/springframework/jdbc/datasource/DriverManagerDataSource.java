/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.ClassUtils;
/*     */ 
/*     */ public class DriverManagerDataSource extends AbstractDriverBasedDataSource
/*     */ {
/*     */   public DriverManagerDataSource()
/*     */   {
/*     */   }
/*     */ 
/*     */   public DriverManagerDataSource(String url)
/*     */   {
/*  81 */     setUrl(url);
/*     */   }
/*     */ 
/*     */   public DriverManagerDataSource(String url, String username, String password)
/*     */   {
/*  93 */     setUrl(url);
/*  94 */     setUsername(username);
/*  95 */     setPassword(password);
/*     */   }
/*     */ 
/*     */   public DriverManagerDataSource(String url, Properties conProps)
/*     */   {
/* 106 */     setUrl(url);
/* 107 */     setConnectionProperties(conProps);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public DriverManagerDataSource(String driverClassName, String url, String username, String password)
/*     */   {
/* 124 */     setDriverClassName(driverClassName);
/* 125 */     setUrl(url);
/* 126 */     setUsername(username);
/* 127 */     setPassword(password);
/*     */   }
/*     */ 
/*     */   public void setDriverClassName(String driverClassName)
/*     */   {
/* 144 */     Assert.hasText(driverClassName, "Property 'driverClassName' must not be empty");
/* 145 */     String driverClassNameToUse = driverClassName.trim();
/*     */     try {
/* 147 */       Class.forName(driverClassNameToUse, true, ClassUtils.getDefaultClassLoader());
/*     */     }
/*     */     catch (ClassNotFoundException ex) {
/* 150 */       throw new IllegalStateException("Could not load JDBC driver class [" + driverClassNameToUse + "]", ex);
/*     */     }
/* 152 */     if (this.logger.isInfoEnabled())
/* 153 */       this.logger.info("Loaded JDBC driver: " + driverClassNameToUse);
/*     */   }
/*     */ 
/*     */   protected Connection getConnectionFromDriver(Properties props)
/*     */     throws SQLException
/*     */   {
/* 160 */     String url = getUrl();
/* 161 */     if (this.logger.isDebugEnabled()) {
/* 162 */       this.logger.debug("Creating new JDBC DriverManager Connection to [" + url + "]");
/*     */     }
/* 164 */     return getConnectionFromDriverManager(url, props);
/*     */   }
/*     */ 
/*     */   protected Connection getConnectionFromDriverManager(String url, Properties props)
/*     */     throws SQLException
/*     */   {
/* 173 */     return DriverManager.getConnection(url, props);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.DriverManagerDataSource
 * JD-Core Version:    0.6.1
 */