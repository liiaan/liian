/*     */ package org.springframework.jdbc.core.namedparam;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.jdbc.core.SqlParameter;
/*     */ import org.springframework.jdbc.core.SqlParameterValue;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class NamedParameterUtils
/*     */ {
/*  48 */   private static final char[] PARAMETER_SEPARATORS = { '"', '\'', ':', '&', ',', ';', '(', ')', '|', '=', '+', '-', '*', '%', '/', '\\', '<', '>', '^' };
/*     */ 
/*  54 */   private static final String[] START_SKIP = { "'", "\"", "--", "/*" };
/*     */ 
/*  60 */   private static final String[] STOP_SKIP = { "'", "\"", "\n", "*/" };
/*     */ 
/*     */   public static ParsedSql parseSqlStatement(String sql)
/*     */   {
/*  75 */     Assert.notNull(sql, "SQL must not be null");
/*     */ 
/*  77 */     Set namedParameters = new HashSet();
/*  78 */     String sqlToUse = sql;
/*  79 */     List parameterList = new ArrayList();
/*     */ 
/*  81 */     char[] statement = sql.toCharArray();
/*  82 */     int namedParameterCount = 0;
/*  83 */     int unnamedParameterCount = 0;
/*  84 */     int totalParameterCount = 0;
/*     */ 
/*  86 */     int escapes = 0;
/*  87 */     int i = 0;
/*  88 */     while (i < statement.length) {
/*  89 */       int skipToPosition = i;
/*  90 */       while (i < statement.length) {
/*  91 */         skipToPosition = skipCommentsAndQuotes(statement, i);
/*  92 */         if (i == skipToPosition)
/*     */         {
/*     */           break;
/*     */         }
/*  96 */         i = skipToPosition;
/*     */       }
/*     */ 
/*  99 */       if (i >= statement.length) {
/*     */         break;
/*     */       }
/* 102 */       char c = statement[i];
/* 103 */       if ((c == ':') || (c == '&')) {
/* 104 */         int j = i + 1;
/* 105 */         if ((j < statement.length) && (statement[j] == ':') && (c == ':'))
/*     */         {
/* 107 */           i += 2;
/*     */         }
/*     */         else {
/* 110 */           String parameter = null;
/* 111 */           if ((j < statement.length) && (c == ':') && (statement[j] == '{'))
/*     */           {
/* 113 */             while ((j < statement.length) && ('}' != statement[j])) {
/* 114 */               j++;
/* 115 */               if ((':' == statement[j]) || ('{' == statement[j])) {
/* 116 */                 throw new InvalidDataAccessApiUsageException("Parameter name contains invalid character '" + statement[j] + "' at position " + i + " in statement: " + sql);
/*     */               }
/*     */             }
/*     */ 
/* 120 */             if (j >= statement.length) {
/* 121 */               throw new InvalidDataAccessApiUsageException("Non-terminated named parameter declaration at position " + i + " in statement: " + sql);
/*     */             }
/*     */ 
/* 124 */             if (j - i > 3) {
/* 125 */               parameter = sql.substring(i + 2, j);
/* 126 */               namedParameterCount = addNewNamedParameter(namedParameters, namedParameterCount, parameter);
/* 127 */               totalParameterCount = addNamedParameter(parameterList, totalParameterCount, escapes, i, j + 1, parameter);
/*     */             }
/* 129 */             j++;
/*     */           }
/*     */           else {
/* 132 */             while ((j < statement.length) && (!isParameterSeparator(statement[j]))) {
/* 133 */               j++;
/*     */             }
/* 135 */             if (j - i > 1) {
/* 136 */               parameter = sql.substring(i + 1, j);
/* 137 */               namedParameterCount = addNewNamedParameter(namedParameters, namedParameterCount, parameter);
/* 138 */               totalParameterCount = addNamedParameter(parameterList, totalParameterCount, escapes, i, j, parameter);
/*     */             }
/*     */           }
/* 141 */           i = j - 1;
/*     */         }
/*     */       }
/* 144 */       else if (c == '\\') {
/* 145 */         int j = i + 1;
/* 146 */         if ((j < statement.length) && (statement[j] == ':'))
/*     */         {
/* 148 */           sqlToUse = sqlToUse.substring(0, i - escapes) + sqlToUse.substring(i - escapes + 1);
/* 149 */           escapes++;
/* 150 */           i += 2;
/*     */         }
/*     */       }
/*     */       else {
/* 154 */         if (c == '?') {
/* 155 */           unnamedParameterCount++;
/* 156 */           totalParameterCount++;
/*     */         }
/*     */ 
/* 159 */         i++;
/*     */       }
/*     */     }
/* 161 */     ParsedSql parsedSql = new ParsedSql(sqlToUse);
/* 162 */     for (ParameterHolder ph : parameterList) {
/* 163 */       parsedSql.addNamedParameter(ph.getParameterName(), ph.getStartIndex(), ph.getEndIndex());
/*     */     }
/* 165 */     parsedSql.setNamedParameterCount(namedParameterCount);
/* 166 */     parsedSql.setUnnamedParameterCount(unnamedParameterCount);
/* 167 */     parsedSql.setTotalParameterCount(totalParameterCount);
/* 168 */     return parsedSql;
/*     */   }
/*     */ 
/*     */   private static int addNamedParameter(List<ParameterHolder> parameterList, int totalParameterCount, int escapes, int i, int j, String parameter)
/*     */   {
/* 174 */     parameterList.add(new ParameterHolder(parameter, i - escapes, j - escapes));
/* 175 */     totalParameterCount++;
/* 176 */     return totalParameterCount;
/*     */   }
/*     */ 
/*     */   private static int addNewNamedParameter(Set<String> namedParameters, int namedParameterCount, String parameter) {
/* 180 */     if (!namedParameters.contains(parameter)) {
/* 181 */       namedParameters.add(parameter);
/* 182 */       namedParameterCount++;
/*     */     }
/* 184 */     return namedParameterCount;
/*     */   }
/*     */ 
/*     */   private static int skipCommentsAndQuotes(char[] statement, int position)
/*     */   {
/* 194 */     for (int i = 0; i < START_SKIP.length; i++) {
/* 195 */       if (statement[position] == START_SKIP[i].charAt(0)) {
/* 196 */         boolean match = true;
/* 197 */         for (int j = 1; j < START_SKIP[i].length(); j++) {
/* 198 */           if (statement[(position + j)] != START_SKIP[i].charAt(j)) {
/* 199 */             match = false;
/* 200 */             break;
/*     */           }
/*     */         }
/* 203 */         if (match) {
/* 204 */           int offset = START_SKIP[i].length();
/* 205 */           for (int m = position + offset; m < statement.length; m++) {
/* 206 */             if (statement[m] == STOP_SKIP[i].charAt(0)) {
/* 207 */               boolean endMatch = true;
/* 208 */               int endPos = m;
/* 209 */               for (int n = 1; n < STOP_SKIP[i].length(); n++) {
/* 210 */                 if (m + n >= statement.length)
/*     */                 {
/* 212 */                   return statement.length;
/*     */                 }
/* 214 */                 if (statement[(m + n)] != STOP_SKIP[i].charAt(n)) {
/* 215 */                   endMatch = false;
/* 216 */                   break;
/*     */                 }
/* 218 */                 endPos = m + n;
/*     */               }
/* 220 */               if (endMatch)
/*     */               {
/* 222 */                 return endPos + 1;
/*     */               }
/*     */             }
/*     */           }
/*     */ 
/* 227 */           return statement.length;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 232 */     return position;
/*     */   }
/*     */ 
/*     */   public static String substituteNamedParameters(ParsedSql parsedSql, SqlParameterSource paramSource)
/*     */   {
/* 253 */     String originalSql = parsedSql.getOriginalSql();
/* 254 */     StringBuilder actualSql = new StringBuilder();
/* 255 */     List paramNames = parsedSql.getParameterNames();
/* 256 */     int lastIndex = 0;
/* 257 */     for (int i = 0; i < paramNames.size(); i++) {
/* 258 */       String paramName = (String)paramNames.get(i);
/* 259 */       int[] indexes = parsedSql.getParameterIndexes(i);
/* 260 */       int startIndex = indexes[0];
/* 261 */       int endIndex = indexes[1];
/* 262 */       actualSql.append(originalSql, lastIndex, startIndex);
/* 263 */       if ((paramSource != null) && (paramSource.hasValue(paramName))) {
/* 264 */         Object value = paramSource.getValue(paramName);
/* 265 */         if ((value instanceof SqlParameterValue)) {
/* 266 */           value = ((SqlParameterValue)value).getValue();
/*     */         }
/* 268 */         if ((value instanceof Collection)) {
/* 269 */           Iterator entryIter = ((Collection)value).iterator();
/* 270 */           int k = 0;
/* 271 */           while (entryIter.hasNext()) {
/* 272 */             if (k > 0) {
/* 273 */               actualSql.append(", ");
/*     */             }
/* 275 */             k++;
/* 276 */             Object entryItem = entryIter.next();
/* 277 */             if ((entryItem instanceof Object[])) {
/* 278 */               Object[] expressionList = (Object[])entryItem;
/* 279 */               actualSql.append("(");
/* 280 */               for (int m = 0; m < expressionList.length; m++) {
/* 281 */                 if (m > 0) {
/* 282 */                   actualSql.append(", ");
/*     */                 }
/* 284 */                 actualSql.append("?");
/*     */               }
/* 286 */               actualSql.append(")");
/*     */             }
/*     */             else {
/* 289 */               actualSql.append("?");
/*     */             }
/*     */           }
/*     */         }
/*     */         else {
/* 294 */           actualSql.append("?");
/*     */         }
/*     */       }
/*     */       else {
/* 298 */         actualSql.append("?");
/*     */       }
/* 300 */       lastIndex = endIndex;
/*     */     }
/* 302 */     actualSql.append(originalSql, lastIndex, originalSql.length());
/* 303 */     return actualSql.toString();
/*     */   }
/*     */ 
/*     */   public static Object[] buildValueArray(ParsedSql parsedSql, SqlParameterSource paramSource, List<SqlParameter> declaredParams)
/*     */   {
/* 318 */     Object[] paramArray = new Object[parsedSql.getTotalParameterCount()];
/* 319 */     if ((parsedSql.getNamedParameterCount() > 0) && (parsedSql.getUnnamedParameterCount() > 0)) {
/* 320 */       throw new InvalidDataAccessApiUsageException("Not allowed to mix named and traditional ? placeholders. You have " + parsedSql.getNamedParameterCount() + " named parameter(s) and " + parsedSql.getUnnamedParameterCount() + " traditional placeholder(s) in statement: " + parsedSql.getOriginalSql());
/*     */     }
/*     */ 
/* 326 */     List paramNames = parsedSql.getParameterNames();
/* 327 */     for (int i = 0; i < paramNames.size(); i++) {
/* 328 */       String paramName = (String)paramNames.get(i);
/*     */       try {
/* 330 */         Object value = paramSource.getValue(paramName);
/* 331 */         SqlParameter param = findParameter(declaredParams, paramName, i);
/* 332 */         paramArray[i] = (param != null ? new SqlParameterValue(param, value) : value);
/*     */       }
/*     */       catch (IllegalArgumentException ex) {
/* 335 */         throw new InvalidDataAccessApiUsageException("No value supplied for the SQL parameter '" + paramName + "': " + ex.getMessage());
/*     */       }
/*     */     }
/*     */ 
/* 339 */     return paramArray;
/*     */   }
/*     */ 
/*     */   private static SqlParameter findParameter(List<SqlParameter> declaredParams, String paramName, int paramIndex)
/*     */   {
/* 350 */     if (declaredParams != null)
/*     */     {
/* 352 */       for (SqlParameter declaredParam : declaredParams) {
/* 353 */         if (paramName.equals(declaredParam.getName())) {
/* 354 */           return declaredParam;
/*     */         }
/*     */       }
/*     */ 
/* 358 */       if (paramIndex < declaredParams.size()) {
/* 359 */         SqlParameter declaredParam = (SqlParameter)declaredParams.get(paramIndex);
/*     */ 
/* 361 */         if (declaredParam.getName() == null) {
/* 362 */           return declaredParam;
/*     */         }
/*     */       }
/*     */     }
/* 366 */     return null;
/*     */   }
/*     */ 
/*     */   private static boolean isParameterSeparator(char c)
/*     */   {
/* 374 */     if (Character.isWhitespace(c)) {
/* 375 */       return true;
/*     */     }
/* 377 */     for (char separator : PARAMETER_SEPARATORS) {
/* 378 */       if (c == separator) {
/* 379 */         return true;
/*     */       }
/*     */     }
/* 382 */     return false;
/*     */   }
/*     */ 
/*     */   public static int[] buildSqlTypeArray(ParsedSql parsedSql, SqlParameterSource paramSource)
/*     */   {
/* 394 */     int[] sqlTypes = new int[parsedSql.getTotalParameterCount()];
/* 395 */     List paramNames = parsedSql.getParameterNames();
/* 396 */     for (int i = 0; i < paramNames.size(); i++) {
/* 397 */       String paramName = (String)paramNames.get(i);
/* 398 */       sqlTypes[i] = paramSource.getSqlType(paramName);
/*     */     }
/* 400 */     return sqlTypes;
/*     */   }
/*     */ 
/*     */   public static List<SqlParameter> buildSqlParameterList(ParsedSql parsedSql, SqlParameterSource paramSource)
/*     */   {
/* 412 */     List paramNames = parsedSql.getParameterNames();
/* 413 */     List params = new LinkedList();
/* 414 */     for (String paramName : paramNames) {
/* 415 */       params.add(new SqlParameter(paramName, paramSource.getSqlType(paramName), paramSource.getTypeName(paramName)));
/*     */     }
/* 417 */     return params;
/*     */   }
/*     */ 
/*     */   public static String parseSqlStatementIntoString(String sql)
/*     */   {
/* 435 */     ParsedSql parsedSql = parseSqlStatement(sql);
/* 436 */     return substituteNamedParameters(parsedSql, null);
/*     */   }
/*     */ 
/*     */   public static String substituteNamedParameters(String sql, SqlParameterSource paramSource)
/*     */   {
/* 450 */     ParsedSql parsedSql = parseSqlStatement(sql);
/* 451 */     return substituteNamedParameters(parsedSql, paramSource);
/*     */   }
/*     */ 
/*     */   public static Object[] buildValueArray(String sql, Map<String, ?> paramMap)
/*     */   {
/* 463 */     ParsedSql parsedSql = parseSqlStatement(sql);
/* 464 */     return buildValueArray(parsedSql, new MapSqlParameterSource(paramMap), null);
/*     */   }
/*     */ 
/*     */   private static class ParameterHolder
/*     */   {
/*     */     private final String parameterName;
/*     */     private final int startIndex;
/*     */     private final int endIndex;
/*     */ 
/*     */     public ParameterHolder(String parameterName, int startIndex, int endIndex)
/*     */     {
/* 477 */       this.parameterName = parameterName;
/* 478 */       this.startIndex = startIndex;
/* 479 */       this.endIndex = endIndex;
/*     */     }
/*     */ 
/*     */     public String getParameterName() {
/* 483 */       return this.parameterName;
/*     */     }
/*     */ 
/*     */     public int getStartIndex() {
/* 487 */       return this.startIndex;
/*     */     }
/*     */ 
/*     */     public int getEndIndex() {
/* 491 */       return this.endIndex;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.namedparam.NamedParameterUtils
 * JD-Core Version:    0.6.1
 */