/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Set;
/*     */ import org.springframework.core.Constants;
/*     */ import org.springframework.transaction.TransactionDefinition;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ 
/*     */ public class IsolationLevelDataSourceAdapter extends UserCredentialsDataSourceAdapter
/*     */ {
/*  58 */   private static final Constants constants = new Constants(TransactionDefinition.class);
/*     */   private Integer isolationLevel;
/*     */ 
/*     */   public final void setIsolationLevelName(String constantName)
/*     */     throws IllegalArgumentException
/*     */   {
/*  78 */     if ((constantName == null) || (!constantName.startsWith("ISOLATION_"))) {
/*  79 */       throw new IllegalArgumentException("Only isolation constants allowed");
/*     */     }
/*  81 */     setIsolationLevel(constants.asNumber(constantName).intValue());
/*     */   }
/*     */ 
/*     */   public void setIsolationLevel(int isolationLevel)
/*     */   {
/* 104 */     if (!constants.getValues("ISOLATION_").contains(Integer.valueOf(isolationLevel))) {
/* 105 */       throw new IllegalArgumentException("Only values of isolation constants allowed");
/*     */     }
/* 107 */     this.isolationLevel = (isolationLevel != -1 ? Integer.valueOf(isolationLevel) : null);
/*     */   }
/*     */ 
/*     */   protected Integer getIsolationLevel()
/*     */   {
/* 115 */     return this.isolationLevel;
/*     */   }
/*     */ 
/*     */   protected Connection doGetConnection(String username, String password)
/*     */     throws SQLException
/*     */   {
/* 127 */     Connection con = super.doGetConnection(username, password);
/* 128 */     Boolean readOnlyToUse = getCurrentReadOnlyFlag();
/* 129 */     if (readOnlyToUse != null) {
/* 130 */       con.setReadOnly(readOnlyToUse.booleanValue());
/*     */     }
/* 132 */     Integer isolationLevelToUse = getCurrentIsolationLevel();
/* 133 */     if (isolationLevelToUse != null) {
/* 134 */       con.setTransactionIsolation(isolationLevelToUse.intValue());
/*     */     }
/* 136 */     return con;
/*     */   }
/*     */ 
/*     */   protected Integer getCurrentIsolationLevel()
/*     */   {
/* 147 */     Integer isolationLevelToUse = TransactionSynchronizationManager.getCurrentTransactionIsolationLevel();
/* 148 */     if (isolationLevelToUse == null) {
/* 149 */       isolationLevelToUse = getIsolationLevel();
/*     */     }
/* 151 */     return isolationLevelToUse;
/*     */   }
/*     */ 
/*     */   protected Boolean getCurrentReadOnlyFlag()
/*     */   {
/* 161 */     boolean txReadOnly = TransactionSynchronizationManager.isCurrentTransactionReadOnly();
/* 162 */     return txReadOnly ? Boolean.TRUE : null;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.IsolationLevelDataSourceAdapter
 * JD-Core Version:    0.6.1
 */