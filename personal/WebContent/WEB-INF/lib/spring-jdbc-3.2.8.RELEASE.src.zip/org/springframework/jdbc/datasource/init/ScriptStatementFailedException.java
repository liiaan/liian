/*    */ package org.springframework.jdbc.datasource.init;
/*    */ 
/*    */ import org.springframework.core.io.support.EncodedResource;
/*    */ 
/*    */ public class ScriptStatementFailedException extends RuntimeException
/*    */ {
/*    */   public ScriptStatementFailedException(String statement, int lineNumber, EncodedResource resource, Throwable cause)
/*    */   {
/* 40 */     super("Failed to execute SQL script statement at line " + lineNumber + " of resource " + resource + ": " + statement, cause);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.init.ScriptStatementFailedException
 * JD-Core Version:    0.6.1
 */