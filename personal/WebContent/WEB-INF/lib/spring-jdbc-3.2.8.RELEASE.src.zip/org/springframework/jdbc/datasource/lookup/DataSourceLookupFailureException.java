/*    */ package org.springframework.jdbc.datasource.lookup;
/*    */ 
/*    */ import org.springframework.dao.NonTransientDataAccessException;
/*    */ 
/*    */ public class DataSourceLookupFailureException extends NonTransientDataAccessException
/*    */ {
/*    */   public DataSourceLookupFailureException(String msg)
/*    */   {
/* 36 */     super(msg);
/*    */   }
/*    */ 
/*    */   public DataSourceLookupFailureException(String msg, Throwable cause)
/*    */   {
/* 46 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.lookup.DataSourceLookupFailureException
 * JD-Core Version:    0.6.1
 */