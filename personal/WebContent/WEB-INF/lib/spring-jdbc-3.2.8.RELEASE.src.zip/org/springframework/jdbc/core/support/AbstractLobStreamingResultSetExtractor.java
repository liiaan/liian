/*     */ package org.springframework.jdbc.core.support;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.EmptyResultDataAccessException;
/*     */ import org.springframework.dao.IncorrectResultSizeDataAccessException;
/*     */ import org.springframework.jdbc.LobRetrievalFailureException;
/*     */ import org.springframework.jdbc.core.ResultSetExtractor;
/*     */ 
/*     */ public abstract class AbstractLobStreamingResultSetExtractor
/*     */   implements ResultSetExtractor
/*     */ {
/*     */   public final Object extractData(ResultSet rs)
/*     */     throws SQLException, DataAccessException
/*     */   {
/*  68 */     if (!rs.next())
/*  69 */       handleNoRowFound();
/*     */     else {
/*     */       try
/*     */       {
/*  73 */         streamData(rs);
/*  74 */         if (rs.next())
/*  75 */           handleMultipleRowsFound();
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*  79 */         throw new LobRetrievalFailureException("Couldn't stream LOB content", ex);
/*     */       }
/*     */     }
/*  82 */     return null;
/*     */   }
/*     */ 
/*     */   protected void handleNoRowFound()
/*     */     throws DataAccessException
/*     */   {
/*  92 */     throw new EmptyResultDataAccessException("LobStreamingResultSetExtractor did not find row in database", 1);
/*     */   }
/*     */ 
/*     */   protected void handleMultipleRowsFound()
/*     */     throws DataAccessException
/*     */   {
/* 103 */     throw new IncorrectResultSizeDataAccessException("LobStreamingResultSetExtractor found multiple rows in database", 1);
/*     */   }
/*     */ 
/*     */   protected abstract void streamData(ResultSet paramResultSet)
/*     */     throws SQLException, IOException, DataAccessException;
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.support.AbstractLobStreamingResultSetExtractor
 * JD-Core Version:    0.6.1
 */