/*    */ package org.springframework.jdbc.core;
/*    */ 
/*    */ public class SqlReturnResultSet extends ResultSetSupportingSqlParameter
/*    */ {
/*    */   public SqlReturnResultSet(String name, ResultSetExtractor extractor)
/*    */   {
/* 39 */     super(name, 0, extractor);
/*    */   }
/*    */ 
/*    */   public SqlReturnResultSet(String name, RowCallbackHandler handler)
/*    */   {
/* 48 */     super(name, 0, handler);
/*    */   }
/*    */ 
/*    */   public SqlReturnResultSet(String name, RowMapper mapper)
/*    */   {
/* 57 */     super(name, 0, mapper);
/*    */   }
/*    */ 
/*    */   public boolean isResultsParameter()
/*    */   {
/* 67 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.SqlReturnResultSet
 * JD-Core Version:    0.6.1
 */