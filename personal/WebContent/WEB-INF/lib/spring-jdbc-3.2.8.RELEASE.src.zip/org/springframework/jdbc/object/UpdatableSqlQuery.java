/*     */ package org.springframework.jdbc.object;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ 
/*     */ public abstract class UpdatableSqlQuery<T> extends SqlQuery<T>
/*     */ {
/*     */   public UpdatableSqlQuery()
/*     */   {
/*  44 */     setUpdatableResults(true);
/*     */   }
/*     */ 
/*     */   public UpdatableSqlQuery(DataSource ds, String sql)
/*     */   {
/*  53 */     super(ds, sql);
/*  54 */     setUpdatableResults(true);
/*     */   }
/*     */ 
/*     */   protected RowMapper<T> newRowMapper(Object[] parameters, Map context)
/*     */   {
/*  64 */     return new RowMapperImpl(context);
/*     */   }
/*     */ 
/*     */   protected abstract T updateRow(ResultSet paramResultSet, int paramInt, Map paramMap)
/*     */     throws SQLException;
/*     */ 
/*     */   protected class RowMapperImpl
/*     */     implements RowMapper<T>
/*     */   {
/*     */     private final Map context;
/*     */ 
/*     */     public RowMapperImpl(Map context)
/*     */     {
/*  94 */       this.context = context;
/*     */     }
/*     */ 
/*     */     public T mapRow(ResultSet rs, int rowNum) throws SQLException {
/*  98 */       Object result = UpdatableSqlQuery.this.updateRow(rs, rowNum, this.context);
/*  99 */       rs.updateRow();
/* 100 */       return result;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.object.UpdatableSqlQuery
 * JD-Core Version:    0.6.1
 */