/*    */ package org.springframework.jdbc;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.dao.InvalidDataAccessResourceUsageException;
/*    */ 
/*    */ public class BadSqlGrammarException extends InvalidDataAccessResourceUsageException
/*    */ {
/*    */   private String sql;
/*    */ 
/*    */   public BadSqlGrammarException(String task, String sql, SQLException ex)
/*    */   {
/* 47 */     super(task + "; bad SQL grammar [" + sql + "]", ex);
/* 48 */     this.sql = sql;
/*    */   }
/*    */ 
/*    */   public SQLException getSQLException()
/*    */   {
/* 56 */     return (SQLException)getCause();
/*    */   }
/*    */ 
/*    */   public String getSql()
/*    */   {
/* 63 */     return this.sql;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.BadSqlGrammarException
 * JD-Core Version:    0.6.1
 */