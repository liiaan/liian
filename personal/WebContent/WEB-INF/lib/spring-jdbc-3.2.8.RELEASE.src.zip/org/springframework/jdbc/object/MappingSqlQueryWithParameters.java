/*     */ package org.springframework.jdbc.object;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ 
/*     */ public abstract class MappingSqlQueryWithParameters<T> extends SqlQuery<T>
/*     */ {
/*     */   public MappingSqlQueryWithParameters()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MappingSqlQueryWithParameters(DataSource ds, String sql)
/*     */   {
/*  64 */     super(ds, sql);
/*     */   }
/*     */ 
/*     */   protected RowMapper<T> newRowMapper(Object[] parameters, Map context)
/*     */   {
/*  74 */     return new RowMapperImpl(parameters, context);
/*     */   }
/*     */ 
/*     */   protected abstract T mapRow(ResultSet paramResultSet, int paramInt, Object[] paramArrayOfObject, Map paramMap)
/*     */     throws SQLException;
/*     */ 
/*     */   protected class RowMapperImpl
/*     */     implements RowMapper<T>
/*     */   {
/*     */     private final Object[] params;
/*     */     private final Map context;
/*     */ 
/*     */     public RowMapperImpl(Object[] parameters, Map context)
/*     */     {
/* 110 */       this.params = parameters;
/* 111 */       this.context = context;
/*     */     }
/*     */ 
/*     */     public T mapRow(ResultSet rs, int rowNum) throws SQLException {
/* 115 */       return MappingSqlQueryWithParameters.this.mapRow(rs, rowNum, this.params, this.context);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.object.MappingSqlQueryWithParameters
 * JD-Core Version:    0.6.1
 */