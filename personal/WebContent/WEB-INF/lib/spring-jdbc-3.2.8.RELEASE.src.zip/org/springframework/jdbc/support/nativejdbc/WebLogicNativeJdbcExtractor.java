/*     */ package org.springframework.jdbc.support.nativejdbc;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class WebLogicNativeJdbcExtractor extends NativeJdbcExtractorAdapter
/*     */ {
/*     */   private static final String JDBC_EXTENSION_NAME = "weblogic.jdbc.extensions.WLConnection";
/*     */   private final Class jdbcExtensionClass;
/*     */   private final Method getVendorConnectionMethod;
/*     */ 
/*     */   public WebLogicNativeJdbcExtractor()
/*     */   {
/*     */     try
/*     */     {
/*  60 */       this.jdbcExtensionClass = getClass().getClassLoader().loadClass("weblogic.jdbc.extensions.WLConnection");
/*  61 */       this.getVendorConnectionMethod = this.jdbcExtensionClass.getMethod("getVendorConnection", (Class[])null);
/*     */     }
/*     */     catch (Exception ex) {
/*  64 */       throw new IllegalStateException("Could not initialize WebLogicNativeJdbcExtractor because WebLogic API classes are not available: " + ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isNativeConnectionNecessaryForNativeStatements()
/*     */   {
/*  75 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isNativeConnectionNecessaryForNativePreparedStatements()
/*     */   {
/*  83 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isNativeConnectionNecessaryForNativeCallableStatements()
/*     */   {
/*  91 */     return true;
/*     */   }
/*     */ 
/*     */   protected Connection doGetNativeConnection(Connection con)
/*     */     throws SQLException
/*     */   {
/*  99 */     if (this.jdbcExtensionClass.isAssignableFrom(con.getClass())) {
/* 100 */       return (Connection)ReflectionUtils.invokeJdbcMethod(this.getVendorConnectionMethod, con);
/*     */     }
/* 102 */     return con;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.nativejdbc.WebLogicNativeJdbcExtractor
 * JD-Core Version:    0.6.1
 */