/*     */ package org.springframework.jdbc.object;
/*     */ 
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.jdbc.JdbcUpdateAffectedIncorrectNumberOfRowsException;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
/*     */ import org.springframework.jdbc.core.namedparam.NamedParameterUtils;
/*     */ import org.springframework.jdbc.core.namedparam.ParsedSql;
/*     */ import org.springframework.jdbc.support.KeyHolder;
/*     */ 
/*     */ public class SqlUpdate extends SqlOperation
/*     */ {
/*  56 */   private int maxRowsAffected = 0;
/*     */ 
/*  62 */   private int requiredRowsAffected = 0;
/*     */ 
/*     */   public SqlUpdate()
/*     */   {
/*     */   }
/*     */ 
/*     */   public SqlUpdate(DataSource ds, String sql)
/*     */   {
/*  80 */     setDataSource(ds);
/*  81 */     setSql(sql);
/*     */   }
/*     */ 
/*     */   public SqlUpdate(DataSource ds, String sql, int[] types)
/*     */   {
/*  94 */     setDataSource(ds);
/*  95 */     setSql(sql);
/*  96 */     setTypes(types);
/*     */   }
/*     */ 
/*     */   public SqlUpdate(DataSource ds, String sql, int[] types, int maxRowsAffected)
/*     */   {
/* 112 */     setDataSource(ds);
/* 113 */     setSql(sql);
/* 114 */     setTypes(types);
/* 115 */     this.maxRowsAffected = maxRowsAffected;
/*     */   }
/*     */ 
/*     */   public void setMaxRowsAffected(int maxRowsAffected)
/*     */   {
/* 126 */     this.maxRowsAffected = maxRowsAffected;
/*     */   }
/*     */ 
/*     */   public void setRequiredRowsAffected(int requiredRowsAffected)
/*     */   {
/* 138 */     this.requiredRowsAffected = requiredRowsAffected;
/*     */   }
/*     */ 
/*     */   protected void checkRowsAffected(int rowsAffected)
/*     */     throws JdbcUpdateAffectedIncorrectNumberOfRowsException
/*     */   {
/* 151 */     if ((this.maxRowsAffected > 0) && (rowsAffected > this.maxRowsAffected)) {
/* 152 */       throw new JdbcUpdateAffectedIncorrectNumberOfRowsException(getSql(), this.maxRowsAffected, rowsAffected);
/*     */     }
/* 154 */     if ((this.requiredRowsAffected > 0) && (rowsAffected != this.requiredRowsAffected))
/* 155 */       throw new JdbcUpdateAffectedIncorrectNumberOfRowsException(getSql(), this.requiredRowsAffected, rowsAffected);
/*     */   }
/*     */ 
/*     */   public int update(Object[] params)
/*     */     throws DataAccessException
/*     */   {
/* 167 */     validateParameters(params);
/* 168 */     int rowsAffected = getJdbcTemplate().update(newPreparedStatementCreator(params));
/* 169 */     checkRowsAffected(rowsAffected);
/* 170 */     return rowsAffected;
/*     */   }
/*     */ 
/*     */   public int update(Object[] params, KeyHolder generatedKeyHolder)
/*     */     throws DataAccessException
/*     */   {
/* 181 */     if ((!isReturnGeneratedKeys()) && (getGeneratedKeysColumnNames() == null)) {
/* 182 */       throw new InvalidDataAccessApiUsageException("The update method taking a KeyHolder should only be used when generated keys have been configured by calling either 'setReturnGeneratedKeys' or 'setGeneratedKeysColumnNames'.");
/*     */     }
/*     */ 
/* 187 */     validateParameters(params);
/* 188 */     int rowsAffected = getJdbcTemplate().update(newPreparedStatementCreator(params), generatedKeyHolder);
/* 189 */     checkRowsAffected(rowsAffected);
/* 190 */     return rowsAffected;
/*     */   }
/*     */ 
/*     */   public int update()
/*     */     throws DataAccessException
/*     */   {
/* 197 */     return update((Object[])null);
/*     */   }
/*     */ 
/*     */   public int update(int p1)
/*     */     throws DataAccessException
/*     */   {
/* 204 */     return update(new Object[] { Integer.valueOf(p1) });
/*     */   }
/*     */ 
/*     */   public int update(int p1, int p2)
/*     */     throws DataAccessException
/*     */   {
/* 211 */     return update(new Object[] { Integer.valueOf(p1), Integer.valueOf(p2) });
/*     */   }
/*     */ 
/*     */   public int update(long p1)
/*     */     throws DataAccessException
/*     */   {
/* 218 */     return update(new Object[] { Long.valueOf(p1) });
/*     */   }
/*     */ 
/*     */   public int update(long p1, long p2)
/*     */     throws DataAccessException
/*     */   {
/* 225 */     return update(new Object[] { Long.valueOf(p1), Long.valueOf(p2) });
/*     */   }
/*     */ 
/*     */   public int update(String p)
/*     */     throws DataAccessException
/*     */   {
/* 232 */     return update(new Object[] { p });
/*     */   }
/*     */ 
/*     */   public int update(String p1, String p2)
/*     */     throws DataAccessException
/*     */   {
/* 239 */     return update(new Object[] { p1, p2 });
/*     */   }
/*     */ 
/*     */   public int updateByNamedParam(Map<String, ?> paramMap)
/*     */     throws DataAccessException
/*     */   {
/* 250 */     validateNamedParameters(paramMap);
/* 251 */     ParsedSql parsedSql = getParsedSql();
/* 252 */     MapSqlParameterSource paramSource = new MapSqlParameterSource(paramMap);
/* 253 */     String sqlToUse = NamedParameterUtils.substituteNamedParameters(parsedSql, paramSource);
/* 254 */     Object[] params = NamedParameterUtils.buildValueArray(parsedSql, paramSource, getDeclaredParameters());
/* 255 */     int rowsAffected = getJdbcTemplate().update(newPreparedStatementCreator(sqlToUse, params));
/* 256 */     checkRowsAffected(rowsAffected);
/* 257 */     return rowsAffected;
/*     */   }
/*     */ 
/*     */   public int updateByNamedParam(Map<String, ?> paramMap, KeyHolder generatedKeyHolder)
/*     */     throws DataAccessException
/*     */   {
/* 269 */     validateNamedParameters(paramMap);
/* 270 */     ParsedSql parsedSql = getParsedSql();
/* 271 */     MapSqlParameterSource paramSource = new MapSqlParameterSource(paramMap);
/* 272 */     String sqlToUse = NamedParameterUtils.substituteNamedParameters(parsedSql, paramSource);
/* 273 */     Object[] params = NamedParameterUtils.buildValueArray(parsedSql, paramSource, getDeclaredParameters());
/* 274 */     int rowsAffected = getJdbcTemplate().update(newPreparedStatementCreator(sqlToUse, params), generatedKeyHolder);
/* 275 */     checkRowsAffected(rowsAffected);
/* 276 */     return rowsAffected;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.object.SqlUpdate
 * JD-Core Version:    0.6.1
 */