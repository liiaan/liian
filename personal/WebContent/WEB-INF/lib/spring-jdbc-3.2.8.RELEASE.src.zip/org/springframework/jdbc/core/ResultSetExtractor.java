package org.springframework.jdbc.core;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.dao.DataAccessException;

public abstract interface ResultSetExtractor<T>
{
  public abstract T extractData(ResultSet paramResultSet)
    throws SQLException, DataAccessException;
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.ResultSetExtractor
 * JD-Core Version:    0.6.1
 */