package org.springframework.jdbc.core;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import org.springframework.dao.DataAccessException;

public abstract interface PreparedStatementCallback<T>
{
  public abstract T doInPreparedStatement(PreparedStatement paramPreparedStatement)
    throws SQLException, DataAccessException;
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.PreparedStatementCallback
 * JD-Core Version:    0.6.1
 */