/*    */ package org.springframework.jdbc.core.simple;
/*    */ 
/*    */ import org.springframework.jdbc.core.SingleColumnRowMapper;
/*    */ 
/*    */ public class ParameterizedSingleColumnRowMapper<T> extends SingleColumnRowMapper<T>
/*    */   implements ParameterizedRowMapper<T>
/*    */ {
/*    */   public static <T> ParameterizedSingleColumnRowMapper<T> newInstance(Class<T> requiredType)
/*    */   {
/* 45 */     ParameterizedSingleColumnRowMapper rm = new ParameterizedSingleColumnRowMapper();
/* 46 */     rm.setRequiredType(requiredType);
/* 47 */     return rm;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.simple.ParameterizedSingleColumnRowMapper
 * JD-Core Version:    0.6.1
 */