/*     */ package org.springframework.jdbc.support.nativejdbc;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class WebSphereNativeJdbcExtractor extends NativeJdbcExtractorAdapter
/*     */ {
/*     */   private static final String JDBC_ADAPTER_CONNECTION_NAME = "com.ibm.ws.rsadapter.jdbc.WSJdbcConnection";
/*     */   private static final String JDBC_ADAPTER_UTIL_NAME = "com.ibm.ws.rsadapter.jdbc.WSJdbcUtil";
/*     */   private Class webSphereConnectionClass;
/*     */   private Method webSphereNativeConnectionMethod;
/*     */ 
/*     */   public WebSphereNativeJdbcExtractor()
/*     */   {
/*     */     try
/*     */     {
/*  59 */       this.webSphereConnectionClass = getClass().getClassLoader().loadClass("com.ibm.ws.rsadapter.jdbc.WSJdbcConnection");
/*  60 */       Class jdbcAdapterUtilClass = getClass().getClassLoader().loadClass("com.ibm.ws.rsadapter.jdbc.WSJdbcUtil");
/*  61 */       this.webSphereNativeConnectionMethod = jdbcAdapterUtilClass.getMethod("getNativeConnection", new Class[] { this.webSphereConnectionClass });
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*  65 */       throw new IllegalStateException("Could not initialize WebSphereNativeJdbcExtractor because WebSphere API classes are not available: " + ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isNativeConnectionNecessaryForNativeStatements()
/*     */   {
/*  76 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isNativeConnectionNecessaryForNativePreparedStatements()
/*     */   {
/*  84 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isNativeConnectionNecessaryForNativeCallableStatements()
/*     */   {
/*  92 */     return true;
/*     */   }
/*     */ 
/*     */   protected Connection doGetNativeConnection(Connection con)
/*     */     throws SQLException
/*     */   {
/* 100 */     if (this.webSphereConnectionClass.isAssignableFrom(con.getClass())) {
/* 101 */       return (Connection)ReflectionUtils.invokeJdbcMethod(this.webSphereNativeConnectionMethod, null, new Object[] { con });
/*     */     }
/* 103 */     return con;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.nativejdbc.WebSphereNativeJdbcExtractor
 * JD-Core Version:    0.6.1
 */