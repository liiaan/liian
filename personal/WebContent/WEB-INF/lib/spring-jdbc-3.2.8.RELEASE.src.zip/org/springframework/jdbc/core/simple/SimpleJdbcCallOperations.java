package org.springframework.jdbc.core.simple;

import java.util.Map;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

public abstract interface SimpleJdbcCallOperations
{
  public abstract SimpleJdbcCallOperations withProcedureName(String paramString);

  public abstract SimpleJdbcCallOperations withFunctionName(String paramString);

  public abstract SimpleJdbcCallOperations withSchemaName(String paramString);

  public abstract SimpleJdbcCallOperations withCatalogName(String paramString);

  public abstract SimpleJdbcCallOperations withReturnValue();

  public abstract SimpleJdbcCallOperations declareParameters(SqlParameter[] paramArrayOfSqlParameter);

  public abstract SimpleJdbcCallOperations useInParameterNames(String[] paramArrayOfString);

  public abstract SimpleJdbcCallOperations returningResultSet(String paramString, RowMapper paramRowMapper);

  @Deprecated
  public abstract SimpleJdbcCallOperations returningResultSet(String paramString, ParameterizedRowMapper paramParameterizedRowMapper);

  public abstract SimpleJdbcCallOperations withoutProcedureColumnMetaDataAccess();

  public abstract <T> T executeFunction(Class<T> paramClass, Object[] paramArrayOfObject);

  public abstract <T> T executeFunction(Class<T> paramClass, Map<String, ?> paramMap);

  public abstract <T> T executeFunction(Class<T> paramClass, SqlParameterSource paramSqlParameterSource);

  public abstract <T> T executeObject(Class<T> paramClass, Object[] paramArrayOfObject);

  public abstract <T> T executeObject(Class<T> paramClass, Map<String, ?> paramMap);

  public abstract <T> T executeObject(Class<T> paramClass, SqlParameterSource paramSqlParameterSource);

  public abstract Map<String, Object> execute(Object[] paramArrayOfObject);

  public abstract Map<String, Object> execute(Map<String, ?> paramMap);

  public abstract Map<String, Object> execute(SqlParameterSource paramSqlParameterSource);
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.simple.SimpleJdbcCallOperations
 * JD-Core Version:    0.6.1
 */