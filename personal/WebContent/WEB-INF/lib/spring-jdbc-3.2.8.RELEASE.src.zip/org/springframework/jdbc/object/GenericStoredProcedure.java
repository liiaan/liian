package org.springframework.jdbc.object;

public class GenericStoredProcedure extends StoredProcedure
{
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.object.GenericStoredProcedure
 * JD-Core Version:    0.6.1
 */