/*    */ package org.springframework.jdbc.config;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.URL;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.Comparator;
/*    */ import java.util.List;
/*    */ import org.springframework.beans.factory.config.AbstractFactoryBean;
/*    */ import org.springframework.context.ResourceLoaderAware;
/*    */ import org.springframework.core.io.Resource;
/*    */ import org.springframework.core.io.ResourceLoader;
/*    */ import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
/*    */ import org.springframework.core.io.support.ResourcePatternResolver;
/*    */ import org.springframework.core.io.support.ResourcePatternUtils;
/*    */ 
/*    */ public class SortedResourcesFactoryBean extends AbstractFactoryBean<Resource[]>
/*    */   implements ResourceLoaderAware
/*    */ {
/*    */   private final List<String> locations;
/*    */   private ResourcePatternResolver resourcePatternResolver;
/*    */ 
/*    */   public SortedResourcesFactoryBean(List<String> locations)
/*    */   {
/* 52 */     this.locations = locations;
/* 53 */     this.resourcePatternResolver = new PathMatchingResourcePatternResolver();
/*    */   }
/*    */ 
/*    */   public SortedResourcesFactoryBean(ResourceLoader resourceLoader, List<String> locations) {
/* 57 */     this.locations = locations;
/* 58 */     this.resourcePatternResolver = ResourcePatternUtils.getResourcePatternResolver(resourceLoader);
/*    */   }
/*    */ 
/*    */   public void setResourceLoader(ResourceLoader resourceLoader)
/*    */   {
/* 63 */     this.resourcePatternResolver = ResourcePatternUtils.getResourcePatternResolver(resourceLoader);
/*    */   }
/*    */ 
/*    */   public Class<? extends Resource[]> getObjectType()
/*    */   {
/* 69 */     return [Lorg.springframework.core.io.Resource.class;
/*    */   }
/*    */ 
/*    */   protected Resource[] createInstance() throws Exception
/*    */   {
/* 74 */     List scripts = new ArrayList();
/* 75 */     for (String location : this.locations) {
/* 76 */       List resources = new ArrayList(Arrays.asList(this.resourcePatternResolver.getResources(location)));
/*    */ 
/* 78 */       Collections.sort(resources, new Comparator() {
/*    */         public int compare(Resource r1, Resource r2) {
/*    */           try {
/* 81 */             return r1.getURL().toString().compareTo(r2.getURL().toString());
/*    */           } catch (IOException ex) {
/*    */           }
/* 84 */           return 0;
/*    */         }
/*    */       });
/* 88 */       for (Resource resource : resources) {
/* 89 */         scripts.add(resource);
/*    */       }
/*    */     }
/* 92 */     return (Resource[])scripts.toArray(new Resource[scripts.size()]);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.config.SortedResourcesFactoryBean
 * JD-Core Version:    0.6.1
 */