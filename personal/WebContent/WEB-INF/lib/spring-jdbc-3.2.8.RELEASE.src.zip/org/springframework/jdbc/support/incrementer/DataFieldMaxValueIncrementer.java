package org.springframework.jdbc.support.incrementer;

import org.springframework.dao.DataAccessException;

public abstract interface DataFieldMaxValueIncrementer
{
  public abstract int nextIntValue()
    throws DataAccessException;

  public abstract long nextLongValue()
    throws DataAccessException;

  public abstract String nextStringValue()
    throws DataAccessException;
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.incrementer.DataFieldMaxValueIncrementer
 * JD-Core Version:    0.6.1
 */