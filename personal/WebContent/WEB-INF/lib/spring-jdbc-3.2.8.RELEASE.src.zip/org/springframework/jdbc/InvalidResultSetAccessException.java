/*    */ package org.springframework.jdbc;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.dao.InvalidDataAccessResourceUsageException;
/*    */ 
/*    */ public class InvalidResultSetAccessException extends InvalidDataAccessResourceUsageException
/*    */ {
/*    */   private String sql;
/*    */ 
/*    */   public InvalidResultSetAccessException(String task, String sql, SQLException ex)
/*    */   {
/* 48 */     super(task + "; invalid ResultSet access for SQL [" + sql + "]", ex);
/* 49 */     this.sql = sql;
/*    */   }
/*    */ 
/*    */   public InvalidResultSetAccessException(SQLException ex)
/*    */   {
/* 57 */     super(ex.getMessage(), ex);
/*    */   }
/*    */ 
/*    */   public SQLException getSQLException()
/*    */   {
/* 65 */     return (SQLException)getCause();
/*    */   }
/*    */ 
/*    */   public String getSql()
/*    */   {
/* 73 */     return this.sql;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.InvalidResultSetAccessException
 * JD-Core Version:    0.6.1
 */