/*     */ package org.springframework.jdbc.support.incrementer;
/*     */ 
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public abstract class AbstractDataFieldMaxValueIncrementer
/*     */   implements DataFieldMaxValueIncrementer, InitializingBean
/*     */ {
/*     */   private DataSource dataSource;
/*     */   private String incrementerName;
/*  43 */   protected int paddingLength = 0;
/*     */ 
/*     */   public AbstractDataFieldMaxValueIncrementer()
/*     */   {
/*     */   }
/*     */ 
/*     */   public AbstractDataFieldMaxValueIncrementer(DataSource dataSource, String incrementerName)
/*     */   {
/*  60 */     Assert.notNull(dataSource, "DataSource must not be null");
/*  61 */     Assert.notNull(incrementerName, "Incrementer name must not be null");
/*  62 */     this.dataSource = dataSource;
/*  63 */     this.incrementerName = incrementerName;
/*     */   }
/*     */ 
/*     */   public void setDataSource(DataSource dataSource)
/*     */   {
/*  71 */     this.dataSource = dataSource;
/*     */   }
/*     */ 
/*     */   public DataSource getDataSource()
/*     */   {
/*  78 */     return this.dataSource;
/*     */   }
/*     */ 
/*     */   public void setIncrementerName(String incrementerName)
/*     */   {
/*  85 */     this.incrementerName = incrementerName;
/*     */   }
/*     */ 
/*     */   public String getIncrementerName()
/*     */   {
/*  92 */     return this.incrementerName;
/*     */   }
/*     */ 
/*     */   public void setPaddingLength(int paddingLength)
/*     */   {
/* 100 */     this.paddingLength = paddingLength;
/*     */   }
/*     */ 
/*     */   public int getPaddingLength()
/*     */   {
/* 107 */     return this.paddingLength;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() {
/* 111 */     if (this.dataSource == null) {
/* 112 */       throw new IllegalArgumentException("Property 'dataSource' is required");
/*     */     }
/* 114 */     if (this.incrementerName == null)
/* 115 */       throw new IllegalArgumentException("Property 'incrementerName' is required");
/*     */   }
/*     */ 
/*     */   public int nextIntValue()
/*     */     throws DataAccessException
/*     */   {
/* 121 */     return (int)getNextKey();
/*     */   }
/*     */ 
/*     */   public long nextLongValue() throws DataAccessException {
/* 125 */     return getNextKey();
/*     */   }
/*     */ 
/*     */   public String nextStringValue() throws DataAccessException {
/* 129 */     String s = Long.toString(getNextKey());
/* 130 */     int len = s.length();
/* 131 */     if (len < this.paddingLength) {
/* 132 */       StringBuilder sb = new StringBuilder(this.paddingLength);
/* 133 */       for (int i = 0; i < this.paddingLength - len; i++) {
/* 134 */         sb.append('0');
/*     */       }
/* 136 */       sb.append(s);
/* 137 */       s = sb.toString();
/*     */     }
/* 139 */     return s;
/*     */   }
/*     */ 
/*     */   protected abstract long getNextKey();
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.incrementer.AbstractDataFieldMaxValueIncrementer
 * JD-Core Version:    0.6.1
 */