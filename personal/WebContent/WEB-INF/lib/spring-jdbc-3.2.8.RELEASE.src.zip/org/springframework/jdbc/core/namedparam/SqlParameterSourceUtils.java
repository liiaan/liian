/*     */ package org.springframework.jdbc.core.namedparam;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.jdbc.core.SqlParameterValue;
/*     */ 
/*     */ public class SqlParameterSourceUtils
/*     */ {
/*     */   public static SqlParameterSource[] createBatch(Map[] valueMaps)
/*     */   {
/*  39 */     MapSqlParameterSource[] batch = new MapSqlParameterSource[valueMaps.length];
/*  40 */     for (int i = 0; i < valueMaps.length; i++) {
/*  41 */       Map valueMap = valueMaps[i];
/*  42 */       batch[i] = new MapSqlParameterSource(valueMap);
/*     */     }
/*  44 */     return batch;
/*     */   }
/*     */ 
/*     */   public static SqlParameterSource[] createBatch(Object[] beans)
/*     */   {
/*  54 */     BeanPropertySqlParameterSource[] batch = new BeanPropertySqlParameterSource[beans.length];
/*  55 */     for (int i = 0; i < beans.length; i++) {
/*  56 */       Object bean = beans[i];
/*  57 */       batch[i] = new BeanPropertySqlParameterSource(bean);
/*     */     }
/*  59 */     return batch;
/*     */   }
/*     */ 
/*     */   public static Object getTypedValue(SqlParameterSource source, String parameterName)
/*     */   {
/*  69 */     int sqlType = source.getSqlType(parameterName);
/*  70 */     if (sqlType != -2147483648) {
/*  71 */       if (source.getTypeName(parameterName) != null) {
/*  72 */         return new SqlParameterValue(sqlType, source.getTypeName(parameterName), source.getValue(parameterName));
/*     */       }
/*     */ 
/*  75 */       return new SqlParameterValue(sqlType, source.getValue(parameterName));
/*     */     }
/*     */ 
/*  79 */     return source.getValue(parameterName);
/*     */   }
/*     */ 
/*     */   public static Map extractCaseInsensitiveParameterNames(SqlParameterSource parameterSource)
/*     */   {
/*  89 */     Map caseInsensitiveParameterNames = new HashMap();
/*  90 */     if ((parameterSource instanceof BeanPropertySqlParameterSource)) {
/*  91 */       String[] propertyNames = ((BeanPropertySqlParameterSource)parameterSource).getReadablePropertyNames();
/*  92 */       for (int i = 0; i < propertyNames.length; i++) {
/*  93 */         String name = propertyNames[i];
/*  94 */         caseInsensitiveParameterNames.put(name.toLowerCase(), name);
/*     */       }
/*     */     }
/*  97 */     else if ((parameterSource instanceof MapSqlParameterSource)) {
/*  98 */       for (String name : ((MapSqlParameterSource)parameterSource).getValues().keySet()) {
/*  99 */         caseInsensitiveParameterNames.put(name.toLowerCase(), name);
/*     */       }
/*     */     }
/* 102 */     return caseInsensitiveParameterNames;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.namedparam.SqlParameterSourceUtils
 * JD-Core Version:    0.6.1
 */