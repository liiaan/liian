/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ import com.sun.rowset.CachedRowSetImpl;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import javax.sql.rowset.CachedRowSet;
/*     */ import javax.sql.rowset.RowSetFactory;
/*     */ import javax.sql.rowset.RowSetProvider;
/*     */ import org.springframework.core.JdkVersion;
/*     */ import org.springframework.jdbc.support.rowset.ResultSetWrappingSqlRowSet;
/*     */ import org.springframework.jdbc.support.rowset.SqlRowSet;
/*     */ 
/*     */ public class SqlRowSetResultSetExtractor
/*     */   implements ResultSetExtractor<SqlRowSet>
/*     */ {
/*     */   private static final CachedRowSetFactory cachedRowSetFactory;
/*     */ 
/*     */   public SqlRowSet extractData(ResultSet rs)
/*     */     throws SQLException
/*     */   {
/*  62 */     return createSqlRowSet(rs);
/*     */   }
/*     */ 
/*     */   protected SqlRowSet createSqlRowSet(ResultSet rs)
/*     */     throws SQLException
/*     */   {
/*  78 */     CachedRowSet rowSet = newCachedRowSet();
/*  79 */     rowSet.populate(rs);
/*  80 */     return new ResultSetWrappingSqlRowSet(rowSet);
/*     */   }
/*     */ 
/*     */   protected CachedRowSet newCachedRowSet()
/*     */     throws SQLException
/*     */   {
/*  94 */     return cachedRowSetFactory.createCachedRowSet();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  50 */     if (JdkVersion.getMajorJavaVersion() >= 4)
/*     */     {
/*  52 */       cachedRowSetFactory = new StandardCachedRowSetFactory();
/*     */     }
/*     */     else
/*     */     {
/*  56 */       cachedRowSetFactory = new SunCachedRowSetFactory(null);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class SunCachedRowSetFactory
/*     */     implements SqlRowSetResultSetExtractor.CachedRowSetFactory
/*     */   {
/*     */     public CachedRowSet createCachedRowSet()
/*     */       throws SQLException
/*     */     {
/* 135 */       return new CachedRowSetImpl();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class StandardCachedRowSetFactory
/*     */     implements SqlRowSetResultSetExtractor.CachedRowSetFactory
/*     */   {
/*     */     private final RowSetFactory rowSetFactory;
/*     */ 
/*     */     public StandardCachedRowSetFactory()
/*     */     {
/*     */       try
/*     */       {
/* 116 */         this.rowSetFactory = RowSetProvider.newFactory();
/*     */       }
/*     */       catch (SQLException ex) {
/* 119 */         throw new IllegalStateException("Cannot create RowSetFactory through RowSetProvider", ex);
/*     */       }
/*     */     }
/*     */ 
/*     */     public CachedRowSet createCachedRowSet() throws SQLException {
/* 124 */       return this.rowSetFactory.createCachedRowSet();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static abstract interface CachedRowSetFactory
/*     */   {
/*     */     public abstract CachedRowSet createCachedRowSet()
/*     */       throws SQLException;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.SqlRowSetResultSetExtractor
 * JD-Core Version:    0.6.1
 */