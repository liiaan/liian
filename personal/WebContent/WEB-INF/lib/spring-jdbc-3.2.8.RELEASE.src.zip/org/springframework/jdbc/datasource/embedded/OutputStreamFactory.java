/*    */ package org.springframework.jdbc.datasource.embedded;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ public class OutputStreamFactory
/*    */ {
/*    */   public static OutputStream getNoopOutputStream()
/*    */   {
/* 35 */     return new OutputStream()
/*    */     {
/*    */       public void write(int b)
/*    */         throws IOException
/*    */       {
/*    */       }
/*    */     };
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.embedded.OutputStreamFactory
 * JD-Core Version:    0.6.1
 */