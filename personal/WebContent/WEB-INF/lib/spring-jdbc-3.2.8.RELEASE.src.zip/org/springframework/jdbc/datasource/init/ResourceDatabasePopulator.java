/*     */ package org.springframework.jdbc.datasource.init;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.LineNumberReader;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.core.io.support.EncodedResource;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class ResourceDatabasePopulator
/*     */   implements DatabasePopulator
/*     */ {
/*     */   private static final String DEFAULT_COMMENT_PREFIX = "--";
/*     */   private static final String DEFAULT_STATEMENT_SEPARATOR = ";";
/*  56 */   private static final Log logger = LogFactory.getLog(ResourceDatabasePopulator.class);
/*     */ 
/*  59 */   private List<Resource> scripts = new ArrayList();
/*     */   private String sqlScriptEncoding;
/*     */   private String separator;
/*  65 */   private String commentPrefix = "--";
/*     */ 
/*  67 */   private boolean continueOnError = false;
/*     */ 
/*  69 */   private boolean ignoreFailedDrops = false;
/*     */ 
/*     */   public void addScript(Resource script)
/*     */   {
/*  77 */     this.scripts.add(script);
/*     */   }
/*     */ 
/*     */   public void setScripts(Resource[] scripts)
/*     */   {
/*  85 */     this.scripts = Arrays.asList(scripts);
/*     */   }
/*     */ 
/*     */   public void setSqlScriptEncoding(String sqlScriptEncoding)
/*     */   {
/*  95 */     this.sqlScriptEncoding = sqlScriptEncoding;
/*     */   }
/*     */ 
/*     */   public void setSeparator(String separator)
/*     */   {
/* 102 */     this.separator = separator;
/*     */   }
/*     */ 
/*     */   public void setCommentPrefix(String commentPrefix)
/*     */   {
/* 110 */     this.commentPrefix = commentPrefix;
/*     */   }
/*     */ 
/*     */   public void setContinueOnError(boolean continueOnError)
/*     */   {
/* 118 */     this.continueOnError = continueOnError;
/*     */   }
/*     */ 
/*     */   public void setIgnoreFailedDrops(boolean ignoreFailedDrops)
/*     */   {
/* 128 */     this.ignoreFailedDrops = ignoreFailedDrops;
/*     */   }
/*     */ 
/*     */   public void populate(Connection connection) throws SQLException
/*     */   {
/* 133 */     for (Resource script : this.scripts)
/* 134 */       executeSqlScript(connection, applyEncodingIfNecessary(script), this.continueOnError, this.ignoreFailedDrops);
/*     */   }
/*     */ 
/*     */   private EncodedResource applyEncodingIfNecessary(Resource script)
/*     */   {
/* 139 */     if ((script instanceof EncodedResource)) {
/* 140 */       return (EncodedResource)script;
/*     */     }
/*     */ 
/* 143 */     return new EncodedResource(script, this.sqlScriptEncoding);
/*     */   }
/*     */ 
/*     */   private void executeSqlScript(Connection connection, EncodedResource resource, boolean continueOnError, boolean ignoreFailedDrops)
/*     */     throws SQLException
/*     */   {
/* 160 */     if (logger.isInfoEnabled()) {
/* 161 */       logger.info("Executing SQL script from " + resource);
/* 163 */     }long startTime = System.currentTimeMillis();
/* 164 */     List statements = new LinkedList();
/*     */     String script;
/*     */     try { script = readScript(resource);
/*     */     } catch (IOException ex)
/*     */     {
/* 170 */       throw new CannotReadScriptException(resource, ex);
/*     */     }
/* 172 */     String delimiter = this.separator;
/* 173 */     if (delimiter == null) {
/* 174 */       delimiter = ";";
/* 175 */       if (!containsSqlScriptDelimiters(script, delimiter)) {
/* 176 */         delimiter = "\n";
/*     */       }
/*     */     }
/* 179 */     splitSqlScript(script, delimiter, this.commentPrefix, statements);
/* 180 */     int lineNumber = 0;
/* 181 */     Statement stmt = connection.createStatement();
/*     */     try {
/* 183 */       for (String statement : statements) {
/* 184 */         lineNumber++;
/*     */         try {
/* 186 */           stmt.execute(statement);
/* 187 */           int rowsAffected = stmt.getUpdateCount();
/* 188 */           if (logger.isDebugEnabled())
/* 189 */             logger.debug(rowsAffected + " returned as updateCount for SQL: " + statement);
/*     */         }
/*     */         catch (SQLException ex)
/*     */         {
/* 193 */           boolean dropStatement = StringUtils.startsWithIgnoreCase(statement.trim(), "drop");
/* 194 */           if ((continueOnError) || ((dropStatement) && (ignoreFailedDrops))) {
/* 195 */             if (logger.isDebugEnabled()) {
/* 196 */               logger.debug("Failed to execute SQL script statement at line " + lineNumber + " of resource " + resource + ": " + statement, ex);
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 201 */             throw new ScriptStatementFailedException(statement, lineNumber, resource, ex);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */     finally {
/*     */       try {
/* 208 */         stmt.close();
/*     */       }
/*     */       catch (Throwable ex) {
/* 211 */         logger.debug("Could not close JDBC Statement", ex);
/*     */       }
/*     */     }
/* 214 */     long elapsedTime = System.currentTimeMillis() - startTime;
/* 215 */     if (logger.isInfoEnabled())
/* 216 */       logger.info("Done executing SQL script from " + resource + " in " + elapsedTime + " ms.");
/*     */   }
/*     */ 
/*     */   private String readScript(EncodedResource resource)
/*     */     throws IOException
/*     */   {
/* 227 */     LineNumberReader lnr = new LineNumberReader(resource.getReader());
/*     */     try {
/* 229 */       String currentStatement = lnr.readLine();
/* 230 */       StringBuilder scriptBuilder = new StringBuilder();
/* 231 */       while (currentStatement != null) {
/* 232 */         if ((StringUtils.hasText(currentStatement)) && (this.commentPrefix != null) && (!currentStatement.startsWith(this.commentPrefix)))
/*     */         {
/* 234 */           if (scriptBuilder.length() > 0) {
/* 235 */             scriptBuilder.append('\n');
/*     */           }
/* 237 */           scriptBuilder.append(currentStatement);
/*     */         }
/* 239 */         currentStatement = lnr.readLine();
/*     */       }
/* 241 */       maybeAddSeparatorToScript(scriptBuilder);
/* 242 */       return scriptBuilder.toString();
/*     */     }
/*     */     finally {
/* 245 */       lnr.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void maybeAddSeparatorToScript(StringBuilder scriptBuilder) {
/* 250 */     if (this.separator == null) {
/* 251 */       return;
/*     */     }
/* 253 */     String trimmed = this.separator.trim();
/* 254 */     if (trimmed.length() == this.separator.length()) {
/* 255 */       return;
/*     */     }
/*     */ 
/* 259 */     if (scriptBuilder.lastIndexOf(trimmed) == scriptBuilder.length() - trimmed.length())
/* 260 */       scriptBuilder.append(this.separator.substring(trimmed.length()));
/*     */   }
/*     */ 
/*     */   private boolean containsSqlScriptDelimiters(String script, String delim)
/*     */   {
/* 270 */     boolean inLiteral = false;
/* 271 */     char[] content = script.toCharArray();
/* 272 */     for (int i = 0; i < script.length(); i++) {
/* 273 */       if (content[i] == '\'') {
/* 274 */         inLiteral = !inLiteral;
/*     */       }
/* 276 */       if ((!inLiteral) && (script.startsWith(delim, i))) {
/* 277 */         return true;
/*     */       }
/*     */     }
/* 280 */     return false;
/*     */   }
/*     */ 
/*     */   private void splitSqlScript(String script, String delim, String commentPrefix, List<String> statements)
/*     */   {
/* 296 */     StringBuilder sb = new StringBuilder();
/* 297 */     boolean inLiteral = false;
/* 298 */     boolean inEscape = false;
/* 299 */     char[] content = script.toCharArray();
/* 300 */     for (int i = 0; i < script.length(); i++) {
/* 301 */       char c = content[i];
/* 302 */       if (inEscape) {
/* 303 */         inEscape = false;
/* 304 */         sb.append(c);
/*     */       }
/* 308 */       else if (c == '\\') {
/* 309 */         inEscape = true;
/* 310 */         sb.append(c);
/*     */       }
/*     */       else {
/* 313 */         if (c == '\'') {
/* 314 */           inLiteral = !inLiteral;
/*     */         }
/* 316 */         if (!inLiteral) {
/* 317 */           if (script.startsWith(delim, i))
/*     */           {
/* 319 */             if (sb.length() > 0) {
/* 320 */               statements.add(sb.toString());
/* 321 */               sb = new StringBuilder();
/*     */             }
/* 323 */             i += delim.length() - 1;
/* 324 */             continue;
/*     */           }
/* 326 */           if (script.startsWith(commentPrefix, i))
/*     */           {
/* 328 */             int indexOfNextNewline = script.indexOf("\n", i);
/* 329 */             if (indexOfNextNewline <= i) break;
/* 330 */             i = indexOfNextNewline;
/* 331 */             continue;
/*     */           }
/*     */ 
/* 339 */           if ((c == ' ') || (c == '\n') || (c == '\t'))
/*     */           {
/* 341 */             if ((sb.length() <= 0) || (sb.charAt(sb.length() - 1) == ' ')) continue;
/* 342 */             c = ' ';
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 349 */         sb.append(c);
/*     */       }
/*     */     }
/* 351 */     if (StringUtils.hasText(sb))
/* 352 */       statements.add(sb.toString());
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.init.ResourceDatabasePopulator
 * JD-Core Version:    0.6.1
 */