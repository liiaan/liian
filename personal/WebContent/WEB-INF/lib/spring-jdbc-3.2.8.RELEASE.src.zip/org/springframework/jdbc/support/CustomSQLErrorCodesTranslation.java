/*    */ package org.springframework.jdbc.support;
/*    */ 
/*    */ import org.springframework.dao.DataAccessException;
/*    */ import org.springframework.util.StringUtils;
/*    */ 
/*    */ public class CustomSQLErrorCodesTranslation
/*    */ {
/* 33 */   private String[] errorCodes = new String[0];
/*    */   private Class exceptionClass;
/*    */ 
/*    */   public void setErrorCodes(String[] errorCodes)
/*    */   {
/* 42 */     this.errorCodes = StringUtils.sortStringArray(errorCodes);
/*    */   }
/*    */ 
/*    */   public String[] getErrorCodes()
/*    */   {
/* 49 */     return this.errorCodes;
/*    */   }
/*    */ 
/*    */   public void setExceptionClass(Class exceptionClass)
/*    */   {
/* 56 */     if (!DataAccessException.class.isAssignableFrom(exceptionClass)) {
/* 57 */       throw new IllegalArgumentException("Invalid exception class [" + exceptionClass + "]: needs to be a subclass of [org.springframework.dao.DataAccessException]");
/*    */     }
/*    */ 
/* 60 */     this.exceptionClass = exceptionClass;
/*    */   }
/*    */ 
/*    */   public Class getExceptionClass()
/*    */   {
/* 67 */     return this.exceptionClass;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.CustomSQLErrorCodesTranslation
 * JD-Core Version:    0.6.1
 */