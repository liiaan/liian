package org.springframework.jdbc.core;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public abstract interface BatchPreparedStatementSetter
{
  public abstract void setValues(PreparedStatement paramPreparedStatement, int paramInt)
    throws SQLException;

  public abstract int getBatchSize();
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.BatchPreparedStatementSetter
 * JD-Core Version:    0.6.1
 */