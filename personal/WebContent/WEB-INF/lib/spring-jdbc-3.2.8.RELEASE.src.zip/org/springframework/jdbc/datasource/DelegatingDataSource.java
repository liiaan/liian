/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.logging.Logger;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class DelegatingDataSource
/*     */   implements DataSource, InitializingBean
/*     */ {
/*     */   private DataSource targetDataSource;
/*     */ 
/*     */   public DelegatingDataSource()
/*     */   {
/*     */   }
/*     */ 
/*     */   public DelegatingDataSource(DataSource targetDataSource)
/*     */   {
/*  57 */     setTargetDataSource(targetDataSource);
/*     */   }
/*     */ 
/*     */   public void setTargetDataSource(DataSource targetDataSource)
/*     */   {
/*  65 */     Assert.notNull(targetDataSource, "'targetDataSource' must not be null");
/*  66 */     this.targetDataSource = targetDataSource;
/*     */   }
/*     */ 
/*     */   public DataSource getTargetDataSource()
/*     */   {
/*  73 */     return this.targetDataSource;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() {
/*  77 */     if (getTargetDataSource() == null)
/*  78 */       throw new IllegalArgumentException("Property 'targetDataSource' is required");
/*     */   }
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws SQLException
/*     */   {
/*  84 */     return getTargetDataSource().getConnection();
/*     */   }
/*     */ 
/*     */   public Connection getConnection(String username, String password) throws SQLException {
/*  88 */     return getTargetDataSource().getConnection(username, password);
/*     */   }
/*     */ 
/*     */   public PrintWriter getLogWriter() throws SQLException {
/*  92 */     return getTargetDataSource().getLogWriter();
/*     */   }
/*     */ 
/*     */   public void setLogWriter(PrintWriter out) throws SQLException {
/*  96 */     getTargetDataSource().setLogWriter(out);
/*     */   }
/*     */ 
/*     */   public int getLoginTimeout() throws SQLException {
/* 100 */     return getTargetDataSource().getLoginTimeout();
/*     */   }
/*     */ 
/*     */   public void setLoginTimeout(int seconds) throws SQLException {
/* 104 */     getTargetDataSource().setLoginTimeout(seconds);
/*     */   }
/*     */ 
/*     */   public <T> T unwrap(Class<T> iface)
/*     */     throws SQLException
/*     */   {
/* 114 */     if (iface.isInstance(this)) {
/* 115 */       return this;
/*     */     }
/* 117 */     return getTargetDataSource().unwrap(iface);
/*     */   }
/*     */ 
/*     */   public boolean isWrapperFor(Class<?> iface) throws SQLException {
/* 121 */     return (iface.isInstance(this)) || (getTargetDataSource().isWrapperFor(iface));
/*     */   }
/*     */ 
/*     */   public Logger getParentLogger()
/*     */   {
/* 130 */     return Logger.getLogger("global");
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.DelegatingDataSource
 * JD-Core Version:    0.6.1
 */