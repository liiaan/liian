/*    */ package org.springframework.jdbc.core.metadata;
/*    */ 
/*    */ import java.sql.DatabaseMetaData;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ public class SybaseCallMetaDataProvider extends GenericCallMetaDataProvider
/*    */ {
/*    */   private static final String REMOVABLE_COLUMN_PREFIX = "@";
/*    */   private static final String RETURN_VALUE_NAME = "RETURN_VALUE";
/*    */ 
/*    */   public SybaseCallMetaDataProvider(DatabaseMetaData databaseMetaData)
/*    */     throws SQLException
/*    */   {
/* 37 */     super(databaseMetaData);
/*    */   }
/*    */ 
/*    */   public String parameterNameToUse(String parameterName)
/*    */   {
/* 43 */     if (parameterName == null) {
/* 44 */       return null;
/*    */     }
/* 46 */     if ((parameterName.length() > 1) && (parameterName.startsWith("@"))) {
/* 47 */       return super.parameterNameToUse(parameterName.substring(1));
/*    */     }
/*    */ 
/* 50 */     return super.parameterNameToUse(parameterName);
/*    */   }
/*    */ 
/*    */   public boolean byPassReturnParameter(String parameterName)
/*    */   {
/* 56 */     return ("RETURN_VALUE".equals(parameterName)) || ("RETURN_VALUE".equals(parameterNameToUse(parameterName))) || (super.byPassReturnParameter(parameterName));
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.SybaseCallMetaDataProvider
 * JD-Core Version:    0.6.1
 */