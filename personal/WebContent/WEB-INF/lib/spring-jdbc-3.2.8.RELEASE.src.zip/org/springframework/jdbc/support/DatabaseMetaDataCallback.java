package org.springframework.jdbc.support;

import java.sql.DatabaseMetaData;
import java.sql.SQLException;

public abstract interface DatabaseMetaDataCallback
{
  public abstract Object processMetaData(DatabaseMetaData paramDatabaseMetaData)
    throws SQLException, MetaDataAccessException;
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.DatabaseMetaDataCallback
 * JD-Core Version:    0.6.1
 */