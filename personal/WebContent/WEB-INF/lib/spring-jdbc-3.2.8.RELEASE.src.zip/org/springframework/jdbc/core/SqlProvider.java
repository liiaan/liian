package org.springframework.jdbc.core;

public abstract interface SqlProvider
{
  public abstract String getSql();
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.SqlProvider
 * JD-Core Version:    0.6.1
 */