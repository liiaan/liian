/*     */ package org.springframework.jdbc.support.lob;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class DefaultLobHandler extends AbstractLobHandler
/*     */ {
/*     */   protected final Log logger;
/*     */   private boolean wrapAsLob;
/*     */   private boolean streamAsLob;
/*     */   private boolean createTemporaryLob;
/*     */ 
/*     */   public DefaultLobHandler()
/*     */   {
/*  78 */     this.logger = LogFactory.getLog(getClass());
/*     */ 
/*  80 */     this.wrapAsLob = false;
/*     */ 
/*  82 */     this.streamAsLob = false;
/*     */ 
/*  84 */     this.createTemporaryLob = false;
/*     */   }
/*     */ 
/*     */   public void setWrapAsLob(boolean wrapAsLob)
/*     */   {
/* 103 */     this.wrapAsLob = wrapAsLob;
/*     */   }
/*     */ 
/*     */   public void setStreamAsLob(boolean streamAsLob)
/*     */   {
/* 121 */     this.streamAsLob = streamAsLob;
/*     */   }
/*     */ 
/*     */   public void setCreateTemporaryLob(boolean createTemporaryLob)
/*     */   {
/* 138 */     this.createTemporaryLob = createTemporaryLob;
/*     */   }
/*     */ 
/*     */   public byte[] getBlobAsBytes(ResultSet rs, int columnIndex) throws SQLException
/*     */   {
/* 143 */     this.logger.debug("Returning BLOB as bytes");
/* 144 */     if (this.wrapAsLob) {
/* 145 */       Blob blob = rs.getBlob(columnIndex);
/* 146 */       return blob.getBytes(1L, (int)blob.length());
/*     */     }
/*     */ 
/* 149 */     return rs.getBytes(columnIndex);
/*     */   }
/*     */ 
/*     */   public InputStream getBlobAsBinaryStream(ResultSet rs, int columnIndex) throws SQLException
/*     */   {
/* 154 */     this.logger.debug("Returning BLOB as binary stream");
/* 155 */     if (this.wrapAsLob) {
/* 156 */       Blob blob = rs.getBlob(columnIndex);
/* 157 */       return blob.getBinaryStream();
/*     */     }
/*     */ 
/* 160 */     return rs.getBinaryStream(columnIndex);
/*     */   }
/*     */ 
/*     */   public String getClobAsString(ResultSet rs, int columnIndex) throws SQLException
/*     */   {
/* 165 */     this.logger.debug("Returning CLOB as string");
/* 166 */     if (this.wrapAsLob) {
/* 167 */       Clob clob = rs.getClob(columnIndex);
/* 168 */       return clob.getSubString(1L, (int)clob.length());
/*     */     }
/*     */ 
/* 171 */     return rs.getString(columnIndex);
/*     */   }
/*     */ 
/*     */   public InputStream getClobAsAsciiStream(ResultSet rs, int columnIndex) throws SQLException
/*     */   {
/* 176 */     this.logger.debug("Returning CLOB as ASCII stream");
/* 177 */     if (this.wrapAsLob) {
/* 178 */       Clob clob = rs.getClob(columnIndex);
/* 179 */       return clob.getAsciiStream();
/*     */     }
/*     */ 
/* 182 */     return rs.getAsciiStream(columnIndex);
/*     */   }
/*     */ 
/*     */   public Reader getClobAsCharacterStream(ResultSet rs, int columnIndex) throws SQLException
/*     */   {
/* 187 */     this.logger.debug("Returning CLOB as character stream");
/* 188 */     if (this.wrapAsLob) {
/* 189 */       Clob clob = rs.getClob(columnIndex);
/* 190 */       return clob.getCharacterStream();
/*     */     }
/*     */ 
/* 193 */     return rs.getCharacterStream(columnIndex);
/*     */   }
/*     */ 
/*     */   public LobCreator getLobCreator()
/*     */   {
/* 198 */     return this.createTemporaryLob ? new TemporaryLobCreator() : new DefaultLobCreator();
/*     */   }
/*     */ 
/*     */   protected class DefaultLobCreator
/*     */     implements LobCreator
/*     */   {
/*     */     protected DefaultLobCreator()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void setBlobAsBytes(PreparedStatement ps, int paramIndex, byte[] content)
/*     */       throws SQLException
/*     */     {
/* 211 */       if (DefaultLobHandler.this.streamAsLob) {
/* 212 */         if (content != null) {
/* 213 */           ps.setBlob(paramIndex, new ByteArrayInputStream(content), content.length);
/*     */         }
/*     */         else {
/* 216 */           ps.setBlob(paramIndex, (Blob)null);
/*     */         }
/*     */       }
/* 219 */       else if (DefaultLobHandler.this.wrapAsLob) {
/* 220 */         if (content != null) {
/* 221 */           ps.setBlob(paramIndex, new PassThroughBlob(content));
/*     */         }
/*     */         else {
/* 224 */           ps.setBlob(paramIndex, (Blob)null);
/*     */         }
/*     */       }
/*     */       else {
/* 228 */         ps.setBytes(paramIndex, content);
/*     */       }
/* 230 */       if (DefaultLobHandler.this.logger.isDebugEnabled())
/* 231 */         DefaultLobHandler.this.logger.debug(content != null ? "Set bytes for BLOB with length " + content.length : "Set BLOB to null");
/*     */     }
/*     */ 
/*     */     public void setBlobAsBinaryStream(PreparedStatement ps, int paramIndex, InputStream binaryStream, int contentLength)
/*     */       throws SQLException
/*     */     {
/* 240 */       if (DefaultLobHandler.this.streamAsLob) {
/* 241 */         if (binaryStream != null) {
/* 242 */           ps.setBlob(paramIndex, binaryStream, contentLength);
/*     */         }
/*     */         else {
/* 245 */           ps.setBlob(paramIndex, (Blob)null);
/*     */         }
/*     */       }
/* 248 */       else if (DefaultLobHandler.this.wrapAsLob) {
/* 249 */         if (binaryStream != null) {
/* 250 */           ps.setBlob(paramIndex, new PassThroughBlob(binaryStream, contentLength));
/*     */         }
/*     */         else {
/* 253 */           ps.setBlob(paramIndex, (Blob)null);
/*     */         }
/*     */       }
/*     */       else {
/* 257 */         ps.setBinaryStream(paramIndex, binaryStream, contentLength);
/*     */       }
/* 259 */       if (DefaultLobHandler.this.logger.isDebugEnabled())
/* 260 */         DefaultLobHandler.this.logger.debug(binaryStream != null ? "Set binary stream for BLOB with length " + contentLength : "Set BLOB to null");
/*     */     }
/*     */ 
/*     */     public void setClobAsString(PreparedStatement ps, int paramIndex, String content)
/*     */       throws SQLException
/*     */     {
/* 268 */       if (DefaultLobHandler.this.streamAsLob) {
/* 269 */         if (content != null) {
/* 270 */           ps.setClob(paramIndex, new StringReader(content), content.length());
/*     */         }
/*     */         else {
/* 273 */           ps.setClob(paramIndex, (Clob)null);
/*     */         }
/*     */       }
/* 276 */       else if (DefaultLobHandler.this.wrapAsLob) {
/* 277 */         if (content != null) {
/* 278 */           ps.setClob(paramIndex, new PassThroughClob(content));
/*     */         }
/*     */         else {
/* 281 */           ps.setClob(paramIndex, (Clob)null);
/*     */         }
/*     */       }
/*     */       else {
/* 285 */         ps.setString(paramIndex, content);
/*     */       }
/* 287 */       if (DefaultLobHandler.this.logger.isDebugEnabled())
/* 288 */         DefaultLobHandler.this.logger.debug(content != null ? "Set string for CLOB with length " + content.length() : "Set CLOB to null");
/*     */     }
/*     */ 
/*     */     public void setClobAsAsciiStream(PreparedStatement ps, int paramIndex, InputStream asciiStream, int contentLength)
/*     */       throws SQLException
/*     */     {
/* 297 */       if (DefaultLobHandler.this.streamAsLob) {
/* 298 */         if (asciiStream != null) {
/*     */           try {
/* 300 */             ps.setClob(paramIndex, new InputStreamReader(asciiStream, "US-ASCII"), contentLength);
/*     */           }
/*     */           catch (UnsupportedEncodingException ex) {
/* 303 */             throw new SQLException("US-ASCII encoding not supported: " + ex);
/*     */           }
/*     */         }
/*     */         else {
/* 307 */           ps.setClob(paramIndex, (Clob)null);
/*     */         }
/*     */       }
/* 310 */       else if (DefaultLobHandler.this.wrapAsLob) {
/* 311 */         if (asciiStream != null) {
/* 312 */           ps.setClob(paramIndex, new PassThroughClob(asciiStream, contentLength));
/*     */         }
/*     */         else {
/* 315 */           ps.setClob(paramIndex, (Clob)null);
/*     */         }
/*     */       }
/*     */       else {
/* 319 */         ps.setAsciiStream(paramIndex, asciiStream, contentLength);
/*     */       }
/* 321 */       if (DefaultLobHandler.this.logger.isDebugEnabled())
/* 322 */         DefaultLobHandler.this.logger.debug(asciiStream != null ? "Set ASCII stream for CLOB with length " + contentLength : "Set CLOB to null");
/*     */     }
/*     */ 
/*     */     public void setClobAsCharacterStream(PreparedStatement ps, int paramIndex, Reader characterStream, int contentLength)
/*     */       throws SQLException
/*     */     {
/* 331 */       if (DefaultLobHandler.this.streamAsLob) {
/* 332 */         if (characterStream != null) {
/* 333 */           ps.setClob(paramIndex, characterStream, contentLength);
/*     */         }
/*     */         else {
/* 336 */           ps.setClob(paramIndex, (Clob)null);
/*     */         }
/*     */       }
/* 339 */       else if (DefaultLobHandler.this.wrapAsLob) {
/* 340 */         if (characterStream != null) {
/* 341 */           ps.setClob(paramIndex, new PassThroughClob(characterStream, contentLength));
/*     */         }
/*     */         else {
/* 344 */           ps.setClob(paramIndex, (Clob)null);
/*     */         }
/*     */       }
/*     */       else {
/* 348 */         ps.setCharacterStream(paramIndex, characterStream, contentLength);
/*     */       }
/* 350 */       if (DefaultLobHandler.this.logger.isDebugEnabled())
/* 351 */         DefaultLobHandler.this.logger.debug(characterStream != null ? "Set character stream for CLOB with length " + contentLength : "Set CLOB to null");
/*     */     }
/*     */ 
/*     */     public void close()
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.lob.DefaultLobHandler
 * JD-Core Version:    0.6.1
 */