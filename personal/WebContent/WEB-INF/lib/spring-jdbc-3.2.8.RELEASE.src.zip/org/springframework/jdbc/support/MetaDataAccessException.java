/*    */ package org.springframework.jdbc.support;
/*    */ 
/*    */ import org.springframework.core.NestedCheckedException;
/*    */ 
/*    */ public class MetaDataAccessException extends NestedCheckedException
/*    */ {
/*    */   public MetaDataAccessException(String msg)
/*    */   {
/* 39 */     super(msg);
/*    */   }
/*    */ 
/*    */   public MetaDataAccessException(String msg, Throwable cause)
/*    */   {
/* 48 */     super(msg, cause);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.MetaDataAccessException
 * JD-Core Version:    0.6.1
 */