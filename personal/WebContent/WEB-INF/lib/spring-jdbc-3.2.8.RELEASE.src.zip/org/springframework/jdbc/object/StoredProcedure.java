/*     */ package org.springframework.jdbc.object;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.ParameterMapper;
/*     */ import org.springframework.jdbc.core.SqlParameter;
/*     */ 
/*     */ public abstract class StoredProcedure extends SqlCall
/*     */ {
/*     */   protected StoredProcedure()
/*     */   {
/*     */   }
/*     */ 
/*     */   protected StoredProcedure(DataSource ds, String name)
/*     */   {
/*  59 */     setDataSource(ds);
/*  60 */     setSql(name);
/*     */   }
/*     */ 
/*     */   protected StoredProcedure(JdbcTemplate jdbcTemplate, String name)
/*     */   {
/*  69 */     setJdbcTemplate(jdbcTemplate);
/*  70 */     setSql(name);
/*     */   }
/*     */ 
/*     */   protected boolean allowsUnusedParameters()
/*     */   {
/*  80 */     return true;
/*     */   }
/*     */ 
/*     */   public void declareParameter(SqlParameter param)
/*     */     throws InvalidDataAccessApiUsageException
/*     */   {
/*  96 */     if (param.getName() == null) {
/*  97 */       throw new InvalidDataAccessApiUsageException("Parameters to stored procedures must have names as well as types");
/*     */     }
/*  99 */     super.declareParameter(param);
/*     */   }
/*     */ 
/*     */   public Map<String, Object> execute(Object[] inParams)
/*     */   {
/* 115 */     Map paramsToUse = new HashMap();
/* 116 */     validateParameters(inParams);
/* 117 */     int i = 0;
/* 118 */     for (SqlParameter sqlParameter : getDeclaredParameters()) {
/* 119 */       if ((sqlParameter.isInputValueProvided()) && 
/* 120 */         (i < inParams.length)) {
/* 121 */         paramsToUse.put(sqlParameter.getName(), inParams[(i++)]);
/*     */       }
/*     */     }
/*     */ 
/* 125 */     return getJdbcTemplate().call(newCallableStatementCreator(paramsToUse), getDeclaredParameters());
/*     */   }
/*     */ 
/*     */   public Map<String, Object> execute(Map<String, ?> inParams)
/*     */     throws DataAccessException
/*     */   {
/* 143 */     validateParameters(inParams.values().toArray());
/* 144 */     return getJdbcTemplate().call(newCallableStatementCreator(inParams), getDeclaredParameters());
/*     */   }
/*     */ 
/*     */   public Map<String, Object> execute(ParameterMapper inParamMapper)
/*     */     throws DataAccessException
/*     */   {
/* 164 */     checkCompiled();
/* 165 */     return getJdbcTemplate().call(newCallableStatementCreator(inParamMapper), getDeclaredParameters());
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.object.StoredProcedure
 * JD-Core Version:    0.6.1
 */