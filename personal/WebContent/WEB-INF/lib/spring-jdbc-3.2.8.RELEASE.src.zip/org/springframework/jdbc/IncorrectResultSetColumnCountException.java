/*    */ package org.springframework.jdbc;
/*    */ 
/*    */ import org.springframework.dao.DataRetrievalFailureException;
/*    */ 
/*    */ public class IncorrectResultSetColumnCountException extends DataRetrievalFailureException
/*    */ {
/*    */   private int expectedCount;
/*    */   private int actualCount;
/*    */ 
/*    */   public IncorrectResultSetColumnCountException(int expectedCount, int actualCount)
/*    */   {
/* 43 */     super("Incorrect column count: expected " + expectedCount + ", actual " + actualCount);
/* 44 */     this.expectedCount = expectedCount;
/* 45 */     this.actualCount = actualCount;
/*    */   }
/*    */ 
/*    */   public IncorrectResultSetColumnCountException(String msg, int expectedCount, int actualCount)
/*    */   {
/* 55 */     super(msg);
/* 56 */     this.expectedCount = expectedCount;
/* 57 */     this.actualCount = actualCount;
/*    */   }
/*    */ 
/*    */   public int getExpectedCount()
/*    */   {
/* 65 */     return this.expectedCount;
/*    */   }
/*    */ 
/*    */   public int getActualCount()
/*    */   {
/* 72 */     return this.actualCount;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.IncorrectResultSetColumnCountException
 * JD-Core Version:    0.6.1
 */