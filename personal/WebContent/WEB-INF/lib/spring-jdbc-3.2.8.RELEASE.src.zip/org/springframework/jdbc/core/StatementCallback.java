package org.springframework.jdbc.core;

import java.sql.SQLException;
import java.sql.Statement;
import org.springframework.dao.DataAccessException;

public abstract interface StatementCallback<T>
{
  public abstract T doInStatement(Statement paramStatement)
    throws SQLException, DataAccessException;
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.StatementCallback
 * JD-Core Version:    0.6.1
 */