/*    */ package org.springframework.jdbc.core.metadata;
/*    */ 
/*    */ public class TableParameterMetaData
/*    */ {
/*    */   private final String parameterName;
/*    */   private final int sqlType;
/*    */   private final boolean nullable;
/*    */ 
/*    */   public TableParameterMetaData(String columnName, int sqlType, boolean nullable)
/*    */   {
/* 38 */     this.parameterName = columnName;
/* 39 */     this.sqlType = sqlType;
/* 40 */     this.nullable = nullable;
/*    */   }
/*    */ 
/*    */   public String getParameterName()
/*    */   {
/* 48 */     return this.parameterName;
/*    */   }
/*    */ 
/*    */   public int getSqlType()
/*    */   {
/* 55 */     return this.sqlType;
/*    */   }
/*    */ 
/*    */   public boolean isNullable()
/*    */   {
/* 62 */     return this.nullable;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.metadata.TableParameterMetaData
 * JD-Core Version:    0.6.1
 */