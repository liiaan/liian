/*     */ package org.springframework.jdbc.core.simple;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.jdbc.core.CallableStatementCreator;
/*     */ import org.springframework.jdbc.core.CallableStatementCreatorFactory;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ import org.springframework.jdbc.core.SqlParameter;
/*     */ import org.springframework.jdbc.core.metadata.CallMetaDataContext;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public abstract class AbstractJdbcCall
/*     */ {
/*  51 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private final JdbcTemplate jdbcTemplate;
/*  57 */   private final List<SqlParameter> declaredParameters = new ArrayList();
/*     */ 
/*  60 */   private final Map<String, RowMapper> declaredRowMappers = new LinkedHashMap();
/*     */ 
/*  67 */   private boolean compiled = false;
/*     */   private String callString;
/*  73 */   private CallMetaDataContext callMetaDataContext = new CallMetaDataContext();
/*     */   private CallableStatementCreatorFactory callableStatementFactory;
/*     */ 
/*     */   protected AbstractJdbcCall(DataSource dataSource)
/*     */   {
/*  87 */     this.jdbcTemplate = new JdbcTemplate(dataSource);
/*     */   }
/*     */ 
/*     */   protected AbstractJdbcCall(JdbcTemplate jdbcTemplate)
/*     */   {
/*  95 */     this.jdbcTemplate = jdbcTemplate;
/*     */   }
/*     */ 
/*     */   public JdbcTemplate getJdbcTemplate()
/*     */   {
/* 103 */     return this.jdbcTemplate;
/*     */   }
/*     */ 
/*     */   protected CallableStatementCreatorFactory getCallableStatementFactory()
/*     */   {
/* 110 */     return this.callableStatementFactory;
/*     */   }
/*     */ 
/*     */   public void setProcedureName(String procedureName)
/*     */   {
/* 117 */     this.callMetaDataContext.setProcedureName(procedureName);
/*     */   }
/*     */ 
/*     */   public String getProcedureName()
/*     */   {
/* 124 */     return this.callMetaDataContext.getProcedureName();
/*     */   }
/*     */ 
/*     */   public void setInParameterNames(Set<String> inParameterNames)
/*     */   {
/* 131 */     this.callMetaDataContext.setLimitedInParameterNames(inParameterNames);
/*     */   }
/*     */ 
/*     */   public Set<String> getInParameterNames()
/*     */   {
/* 138 */     return this.callMetaDataContext.getLimitedInParameterNames();
/*     */   }
/*     */ 
/*     */   public void setCatalogName(String catalogName)
/*     */   {
/* 145 */     this.callMetaDataContext.setCatalogName(catalogName);
/*     */   }
/*     */ 
/*     */   public String getCatalogName()
/*     */   {
/* 152 */     return this.callMetaDataContext.getCatalogName();
/*     */   }
/*     */ 
/*     */   public void setSchemaName(String schemaName)
/*     */   {
/* 159 */     this.callMetaDataContext.setSchemaName(schemaName);
/*     */   }
/*     */ 
/*     */   public String getSchemaName()
/*     */   {
/* 166 */     return this.callMetaDataContext.getSchemaName();
/*     */   }
/*     */ 
/*     */   public void setFunction(boolean function)
/*     */   {
/* 173 */     this.callMetaDataContext.setFunction(function);
/*     */   }
/*     */ 
/*     */   public boolean isFunction()
/*     */   {
/* 180 */     return this.callMetaDataContext.isFunction();
/*     */   }
/*     */ 
/*     */   public void setReturnValueRequired(boolean b)
/*     */   {
/* 187 */     this.callMetaDataContext.setReturnValueRequired(b);
/*     */   }
/*     */ 
/*     */   public boolean isReturnValueRequired()
/*     */   {
/* 194 */     return this.callMetaDataContext.isReturnValueRequired();
/*     */   }
/*     */ 
/*     */   public void addDeclaredParameter(SqlParameter parameter)
/*     */   {
/* 206 */     Assert.notNull(parameter, "The supplied parameter must not be null");
/* 207 */     if (!StringUtils.hasText(parameter.getName())) {
/* 208 */       throw new InvalidDataAccessApiUsageException("You must specify a parameter name when declaring parameters for \"" + getProcedureName() + "\"");
/*     */     }
/*     */ 
/* 211 */     this.declaredParameters.add(parameter);
/* 212 */     if (this.logger.isDebugEnabled())
/* 213 */       this.logger.debug("Added declared parameter for [" + getProcedureName() + "]: " + parameter.getName());
/*     */   }
/*     */ 
/*     */   public void addDeclaredRowMapper(String parameterName, RowMapper rowMapper)
/*     */   {
/* 223 */     this.declaredRowMappers.put(parameterName, rowMapper);
/* 224 */     if (this.logger.isDebugEnabled())
/* 225 */       this.logger.debug("Added row mapper for [" + getProcedureName() + "]: " + parameterName);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void addDeclaredRowMapper(String parameterName, ParameterizedRowMapper rowMapper)
/*     */   {
/* 235 */     addDeclaredRowMapper(parameterName, rowMapper);
/*     */   }
/*     */ 
/*     */   public String getCallString()
/*     */   {
/* 242 */     return this.callString;
/*     */   }
/*     */ 
/*     */   public void setAccessCallParameterMetaData(boolean accessCallParameterMetaData)
/*     */   {
/* 249 */     this.callMetaDataContext.setAccessCallParameterMetaData(accessCallParameterMetaData);
/*     */   }
/*     */ 
/*     */   public final synchronized void compile()
/*     */     throws InvalidDataAccessApiUsageException
/*     */   {
/* 265 */     if (!isCompiled()) {
/* 266 */       if (getProcedureName() == null)
/* 267 */         throw new InvalidDataAccessApiUsageException("Procedure or Function name is required");
/*     */       try
/*     */       {
/* 270 */         this.jdbcTemplate.afterPropertiesSet();
/*     */       }
/*     */       catch (IllegalArgumentException ex) {
/* 273 */         throw new InvalidDataAccessApiUsageException(ex.getMessage());
/*     */       }
/* 275 */       compileInternal();
/* 276 */       this.compiled = true;
/* 277 */       if (this.logger.isDebugEnabled())
/* 278 */         this.logger.debug("SqlCall for " + (isFunction() ? "function" : "procedure") + " [" + getProcedureName() + "] compiled");
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void compileInternal()
/*     */   {
/* 288 */     this.callMetaDataContext.initializeMetaData(getJdbcTemplate().getDataSource());
/*     */ 
/* 291 */     for (Map.Entry entry : this.declaredRowMappers.entrySet()) {
/* 292 */       SqlParameter resultSetParameter = this.callMetaDataContext.createReturnResultSetParameter((String)entry.getKey(), (RowMapper)entry.getValue());
/*     */ 
/* 294 */       this.declaredParameters.add(resultSetParameter);
/*     */     }
/* 296 */     this.callMetaDataContext.processParameters(this.declaredParameters);
/*     */ 
/* 298 */     this.callString = this.callMetaDataContext.createCallString();
/* 299 */     if (this.logger.isDebugEnabled()) {
/* 300 */       this.logger.debug("Compiled stored procedure. Call string is [" + this.callString + "]");
/*     */     }
/*     */ 
/* 303 */     this.callableStatementFactory = new CallableStatementCreatorFactory(getCallString(), this.callMetaDataContext.getCallParameters());
/*     */ 
/* 305 */     this.callableStatementFactory.setNativeJdbcExtractor(getJdbcTemplate().getNativeJdbcExtractor());
/*     */ 
/* 307 */     onCompileInternal();
/*     */   }
/*     */ 
/*     */   protected void onCompileInternal()
/*     */   {
/*     */   }
/*     */ 
/*     */   public boolean isCompiled()
/*     */   {
/* 322 */     return this.compiled;
/*     */   }
/*     */ 
/*     */   protected void checkCompiled()
/*     */   {
/* 331 */     if (!isCompiled()) {
/* 332 */       this.logger.debug("JdbcCall call not compiled before execution - invoking compile");
/* 333 */       compile();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Map<String, Object> doExecute(SqlParameterSource parameterSource)
/*     */   {
/* 348 */     checkCompiled();
/* 349 */     Map params = matchInParameterValuesWithCallParameters(parameterSource);
/* 350 */     return executeCallInternal(params);
/*     */   }
/*     */ 
/*     */   protected Map<String, Object> doExecute(Object[] args)
/*     */   {
/* 359 */     checkCompiled();
/* 360 */     Map params = matchInParameterValuesWithCallParameters(args);
/* 361 */     return executeCallInternal(params);
/*     */   }
/*     */ 
/*     */   protected Map<String, Object> doExecute(Map<String, ?> args)
/*     */   {
/* 370 */     checkCompiled();
/* 371 */     Map params = matchInParameterValuesWithCallParameters(args);
/* 372 */     return executeCallInternal(params);
/*     */   }
/*     */ 
/*     */   private Map<String, Object> executeCallInternal(Map<String, ?> params)
/*     */   {
/* 379 */     CallableStatementCreator csc = getCallableStatementFactory().newCallableStatementCreator(params);
/*     */     int i;
/* 380 */     if (this.logger.isDebugEnabled()) {
/* 381 */       this.logger.debug("The following parameters are used for call " + getCallString() + " with: " + params);
/* 382 */       i = 1;
/* 383 */       for (SqlParameter p : getCallParameters()) {
/* 384 */         this.logger.debug(i++ + ": " + p.getName() + " SQL Type " + p.getSqlType() + " Type Name " + p.getTypeName() + " " + p.getClass().getName());
/*     */       }
/*     */     }
/* 387 */     return getJdbcTemplate().call(csc, getCallParameters());
/*     */   }
/*     */ 
/*     */   protected String getScalarOutParameterName()
/*     */   {
/* 395 */     return this.callMetaDataContext.getScalarOutParameterName();
/*     */   }
/*     */ 
/*     */   protected Map<String, Object> matchInParameterValuesWithCallParameters(SqlParameterSource parameterSource)
/*     */   {
/* 405 */     return this.callMetaDataContext.matchInParameterValuesWithCallParameters(parameterSource);
/*     */   }
/*     */ 
/*     */   private Map<String, ?> matchInParameterValuesWithCallParameters(Object[] args)
/*     */   {
/* 415 */     return this.callMetaDataContext.matchInParameterValuesWithCallParameters(args);
/*     */   }
/*     */ 
/*     */   protected Map<String, ?> matchInParameterValuesWithCallParameters(Map<String, ?> args)
/*     */   {
/* 425 */     return this.callMetaDataContext.matchInParameterValuesWithCallParameters(args);
/*     */   }
/*     */ 
/*     */   protected List<SqlParameter> getCallParameters()
/*     */   {
/* 433 */     return this.callMetaDataContext.getCallParameters();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.simple.AbstractJdbcCall
 * JD-Core Version:    0.6.1
 */