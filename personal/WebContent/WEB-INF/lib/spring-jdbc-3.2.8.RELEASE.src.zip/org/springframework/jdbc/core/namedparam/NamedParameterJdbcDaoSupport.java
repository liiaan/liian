/*    */ package org.springframework.jdbc.core.namedparam;
/*    */ 
/*    */ import org.springframework.jdbc.core.support.JdbcDaoSupport;
/*    */ 
/*    */ public class NamedParameterJdbcDaoSupport extends JdbcDaoSupport
/*    */ {
/*    */   private NamedParameterJdbcTemplate namedParameterJdbcTemplate;
/*    */ 
/*    */   protected void initTemplateConfig()
/*    */   {
/* 39 */     this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(getJdbcTemplate());
/*    */   }
/*    */ 
/*    */   public NamedParameterJdbcTemplate getNamedParameterJdbcTemplate()
/*    */   {
/* 46 */     return this.namedParameterJdbcTemplate;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport
 * JD-Core Version:    0.6.1
 */