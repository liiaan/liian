/*     */ package org.springframework.jdbc.support.rowset;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Date;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import org.springframework.jdbc.InvalidResultSetAccessException;
/*     */ 
/*     */ public class ResultSetWrappingSqlRowSet
/*     */   implements SqlRowSet
/*     */ {
/*     */   private static final long serialVersionUID = -4688694393146734764L;
/*     */   private final ResultSet resultSet;
/*     */   private final SqlRowSetMetaData rowSetMetaData;
/*     */   private final Map<String, Integer> columnLabelMap;
/*     */ 
/*     */   public ResultSetWrappingSqlRowSet(ResultSet resultSet)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*  89 */     this.resultSet = resultSet;
/*     */     try {
/*  91 */       this.rowSetMetaData = new ResultSetWrappingSqlRowSetMetaData(resultSet.getMetaData());
/*     */     }
/*     */     catch (SQLException se) {
/*  94 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */     try {
/*  97 */       ResultSetMetaData rsmd = resultSet.getMetaData();
/*  98 */       if (rsmd != null) {
/*  99 */         int columnCount = rsmd.getColumnCount();
/* 100 */         this.columnLabelMap = new HashMap(columnCount);
/* 101 */         for (int i = 1; i <= columnCount; i++)
/* 102 */           this.columnLabelMap.put(rsmd.getColumnLabel(i), Integer.valueOf(i));
/*     */       }
/*     */       else
/*     */       {
/* 106 */         this.columnLabelMap = Collections.emptyMap();
/*     */       }
/*     */     }
/*     */     catch (SQLException se) {
/* 110 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public final ResultSet getResultSet()
/*     */   {
/* 122 */     return this.resultSet;
/*     */   }
/*     */ 
/*     */   public final SqlRowSetMetaData getMetaData()
/*     */   {
/* 129 */     return this.rowSetMetaData;
/*     */   }
/*     */ 
/*     */   public int findColumn(String columnLabel)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/* 136 */     Integer columnIndex = (Integer)this.columnLabelMap.get(columnLabel);
/* 137 */     if (columnIndex != null) {
/* 138 */       return columnIndex.intValue();
/*     */     }
/*     */     try
/*     */     {
/* 142 */       return this.resultSet.findColumn(columnLabel);
/*     */     }
/*     */     catch (SQLException se) {
/* 145 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public BigDecimal getBigDecimal(int columnIndex)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 158 */       return this.resultSet.getBigDecimal(columnIndex);
/*     */     }
/*     */     catch (SQLException se) {
/* 161 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public BigDecimal getBigDecimal(String columnLabel)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/* 169 */     return getBigDecimal(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */   public boolean getBoolean(int columnIndex)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 177 */       return this.resultSet.getBoolean(columnIndex);
/*     */     }
/*     */     catch (SQLException se) {
/* 180 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean getBoolean(String columnLabel)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/* 188 */     return getBoolean(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */   public byte getByte(int columnIndex)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 196 */       return this.resultSet.getByte(columnIndex);
/*     */     }
/*     */     catch (SQLException se) {
/* 199 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public byte getByte(String columnLabel)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/* 207 */     return getByte(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */   public Date getDate(int columnIndex, Calendar cal)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 215 */       return this.resultSet.getDate(columnIndex, cal);
/*     */     }
/*     */     catch (SQLException se) {
/* 218 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Date getDate(int columnIndex)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 227 */       return this.resultSet.getDate(columnIndex);
/*     */     }
/*     */     catch (SQLException se) {
/* 230 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Date getDate(String columnLabel, Calendar cal)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/* 237 */     return getDate(findColumn(columnLabel), cal);
/*     */   }
/*     */ 
/*     */   public Date getDate(String columnLabel)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/* 244 */     return getDate(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */   public double getDouble(int columnIndex)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 252 */       return this.resultSet.getDouble(columnIndex);
/*     */     }
/*     */     catch (SQLException se) {
/* 255 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public double getDouble(String columnLabel)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/* 263 */     return getDouble(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */   public float getFloat(int columnIndex)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 271 */       return this.resultSet.getFloat(columnIndex);
/*     */     }
/*     */     catch (SQLException se) {
/* 274 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public float getFloat(String columnLabel)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/* 282 */     return getFloat(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */   public int getInt(int columnIndex) throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 289 */       return this.resultSet.getInt(columnIndex);
/*     */     }
/*     */     catch (SQLException se) {
/* 292 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getInt(String columnLabel)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/* 300 */     return getInt(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */   public long getLong(int columnIndex)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 308 */       return this.resultSet.getLong(columnIndex);
/*     */     }
/*     */     catch (SQLException se) {
/* 311 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getLong(String columnLabel)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/* 319 */     return getLong(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */   public Object getObject(int i, Map<String, Class<?>> map)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 327 */       return this.resultSet.getObject(i, map);
/*     */     }
/*     */     catch (SQLException se) {
/* 330 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object getObject(int columnIndex)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 339 */       return this.resultSet.getObject(columnIndex);
/*     */     }
/*     */     catch (SQLException se) {
/* 342 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object getObject(String columnLabel, Map<String, Class<?>> map)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/* 350 */     return getObject(findColumn(columnLabel), map);
/*     */   }
/*     */ 
/*     */   public Object getObject(String columnLabel)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/* 357 */     return getObject(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */   public short getShort(int columnIndex)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 365 */       return this.resultSet.getShort(columnIndex);
/*     */     }
/*     */     catch (SQLException se) {
/* 368 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public short getShort(String columnLabel)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/* 376 */     return getShort(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */   public String getString(int columnIndex)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 384 */       return this.resultSet.getString(columnIndex);
/*     */     }
/*     */     catch (SQLException se) {
/* 387 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getString(String columnLabel)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/* 395 */     return getString(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */   public Time getTime(int columnIndex, Calendar cal)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 403 */       return this.resultSet.getTime(columnIndex, cal);
/*     */     }
/*     */     catch (SQLException se) {
/* 406 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Time getTime(int columnIndex)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 415 */       return this.resultSet.getTime(columnIndex);
/*     */     }
/*     */     catch (SQLException se) {
/* 418 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Time getTime(String columnLabel, Calendar cal)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/* 426 */     return getTime(findColumn(columnLabel), cal);
/*     */   }
/*     */ 
/*     */   public Time getTime(String columnLabel)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/* 433 */     return getTime(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */   public Timestamp getTimestamp(int columnIndex, Calendar cal)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 441 */       return this.resultSet.getTimestamp(columnIndex, cal);
/*     */     }
/*     */     catch (SQLException se) {
/* 444 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Timestamp getTimestamp(int columnIndex)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 453 */       return this.resultSet.getTimestamp(columnIndex);
/*     */     }
/*     */     catch (SQLException se) {
/* 456 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Timestamp getTimestamp(String columnLabel, Calendar cal)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/* 464 */     return getTimestamp(findColumn(columnLabel), cal);
/*     */   }
/*     */ 
/*     */   public Timestamp getTimestamp(String columnLabel)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/* 471 */     return getTimestamp(findColumn(columnLabel));
/*     */   }
/*     */ 
/*     */   public boolean absolute(int row)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 482 */       return this.resultSet.absolute(row);
/*     */     }
/*     */     catch (SQLException se) {
/* 485 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void afterLast()
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 494 */       this.resultSet.afterLast();
/*     */     }
/*     */     catch (SQLException se) {
/* 497 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void beforeFirst()
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 506 */       this.resultSet.beforeFirst();
/*     */     }
/*     */     catch (SQLException se) {
/* 509 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean first()
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 518 */       return this.resultSet.first();
/*     */     }
/*     */     catch (SQLException se) {
/* 521 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getRow()
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 530 */       return this.resultSet.getRow();
/*     */     }
/*     */     catch (SQLException se) {
/* 533 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isAfterLast()
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 542 */       return this.resultSet.isAfterLast();
/*     */     }
/*     */     catch (SQLException se) {
/* 545 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isBeforeFirst()
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 554 */       return this.resultSet.isBeforeFirst();
/*     */     }
/*     */     catch (SQLException se) {
/* 557 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isFirst()
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 566 */       return this.resultSet.isFirst();
/*     */     }
/*     */     catch (SQLException se) {
/* 569 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isLast()
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 578 */       return this.resultSet.isLast();
/*     */     }
/*     */     catch (SQLException se) {
/* 581 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean last()
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 590 */       return this.resultSet.last();
/*     */     }
/*     */     catch (SQLException se) {
/* 593 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean next()
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 602 */       return this.resultSet.next();
/*     */     }
/*     */     catch (SQLException se) {
/* 605 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean previous()
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 614 */       return this.resultSet.previous();
/*     */     }
/*     */     catch (SQLException se) {
/* 617 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean relative(int rows)
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 626 */       return this.resultSet.relative(rows);
/*     */     }
/*     */     catch (SQLException se) {
/* 629 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean wasNull()
/*     */     throws InvalidResultSetAccessException
/*     */   {
/*     */     try
/*     */     {
/* 638 */       return this.resultSet.wasNull();
/*     */     }
/*     */     catch (SQLException se) {
/* 641 */       throw new InvalidResultSetAccessException(se);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.rowset.ResultSetWrappingSqlRowSet
 * JD-Core Version:    0.6.1
 */