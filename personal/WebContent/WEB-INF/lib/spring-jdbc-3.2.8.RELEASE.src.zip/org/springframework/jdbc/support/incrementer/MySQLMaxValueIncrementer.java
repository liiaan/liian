/*     */ package org.springframework.jdbc.support.incrementer;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ 
/*     */ public class MySQLMaxValueIncrementer extends AbstractColumnMaxValueIncrementer
/*     */ {
/*     */   private static final String VALUE_SQL = "select last_insert_id()";
/*  62 */   private long nextId = 0L;
/*     */ 
/*  65 */   private long maxId = 0L;
/*     */ 
/*     */   public MySQLMaxValueIncrementer()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MySQLMaxValueIncrementer(DataSource dataSource, String incrementerName, String columnName)
/*     */   {
/*  84 */     super(dataSource, incrementerName, columnName);
/*     */   }
/*     */ 
/*     */   protected synchronized long getNextKey()
/*     */     throws DataAccessException
/*     */   {
/*  90 */     if (this.maxId == this.nextId)
/*     */     {
/*  96 */       Connection con = DataSourceUtils.getConnection(getDataSource());
/*  97 */       Statement stmt = null;
/*     */       try {
/*  99 */         stmt = con.createStatement();
/* 100 */         DataSourceUtils.applyTransactionTimeout(stmt, getDataSource());
/*     */ 
/* 102 */         String columnName = getColumnName();
/* 103 */         stmt.executeUpdate("update " + getIncrementerName() + " set " + columnName + " = last_insert_id(" + columnName + " + " + getCacheSize() + ")");
/*     */ 
/* 106 */         ResultSet rs = stmt.executeQuery("select last_insert_id()");
/*     */         try {
/* 108 */           if (!rs.next()) {
/* 109 */             throw new DataAccessResourceFailureException("last_insert_id() failed after executing an update");
/*     */           }
/* 111 */           this.maxId = rs.getLong(1);
/*     */         }
/*     */         finally {
/* 114 */           JdbcUtils.closeResultSet(rs);
/*     */         }
/* 116 */         this.nextId = (this.maxId - getCacheSize() + 1L);
/*     */       }
/*     */       catch (SQLException ex) {
/* 119 */         throw new DataAccessResourceFailureException("Could not obtain last_insert_id()", ex);
/*     */       }
/*     */       finally {
/* 122 */         JdbcUtils.closeStatement(stmt);
/* 123 */         DataSourceUtils.releaseConnection(con, getDataSource());
/*     */       }
/*     */     }
/*     */     else {
/* 127 */       this.nextId += 1L;
/*     */     }
/* 129 */     return this.nextId;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.incrementer.MySQLMaxValueIncrementer
 * JD-Core Version:    0.6.1
 */