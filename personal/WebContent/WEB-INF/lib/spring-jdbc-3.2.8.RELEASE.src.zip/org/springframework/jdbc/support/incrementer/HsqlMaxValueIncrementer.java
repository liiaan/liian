/*     */ package org.springframework.jdbc.support.incrementer;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*     */ import org.springframework.jdbc.support.JdbcUtils;
/*     */ 
/*     */ public class HsqlMaxValueIncrementer extends AbstractColumnMaxValueIncrementer
/*     */ {
/*     */   private long[] valueCache;
/*  64 */   private int nextValueIndex = -1;
/*     */ 
/*     */   public HsqlMaxValueIncrementer()
/*     */   {
/*     */   }
/*     */ 
/*     */   public HsqlMaxValueIncrementer(DataSource dataSource, String incrementerName, String columnName)
/*     */   {
/*  83 */     super(dataSource, incrementerName, columnName);
/*     */   }
/*     */ 
/*     */   protected synchronized long getNextKey()
/*     */     throws DataAccessException
/*     */   {
/*  89 */     if ((this.nextValueIndex < 0) || (this.nextValueIndex >= getCacheSize()))
/*     */     {
/*  95 */       Connection con = DataSourceUtils.getConnection(getDataSource());
/*  96 */       Statement stmt = null;
/*     */       try {
/*  98 */         stmt = con.createStatement();
/*  99 */         DataSourceUtils.applyTransactionTimeout(stmt, getDataSource());
/* 100 */         this.valueCache = new long[getCacheSize()];
/* 101 */         this.nextValueIndex = 0;
/* 102 */         for (int i = 0; i < getCacheSize(); i++) {
/* 103 */           stmt.executeUpdate("insert into " + getIncrementerName() + " values(null)");
/* 104 */           ResultSet rs = stmt.executeQuery("select max(identity()) from " + getIncrementerName());
/*     */           try {
/* 106 */             if (!rs.next()) {
/* 107 */               throw new DataAccessResourceFailureException("identity() failed after executing an update");
/*     */             }
/* 109 */             this.valueCache[i] = rs.getLong(1);
/*     */           }
/*     */           finally {
/* 112 */             JdbcUtils.closeResultSet(rs);
/*     */           }
/*     */         }
/* 115 */         long maxValue = this.valueCache[(this.valueCache.length - 1)];
/* 116 */         stmt.executeUpdate("delete from " + getIncrementerName() + " where " + getColumnName() + " < " + maxValue);
/*     */       }
/*     */       catch (SQLException ex) {
/* 119 */         throw new DataAccessResourceFailureException("Could not obtain identity()", ex);
/*     */       }
/*     */       finally {
/* 122 */         JdbcUtils.closeStatement(stmt);
/* 123 */         DataSourceUtils.releaseConnection(con, getDataSource());
/*     */       }
/*     */     }
/* 126 */     return this.valueCache[(this.nextValueIndex++)];
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.incrementer.HsqlMaxValueIncrementer
 * JD-Core Version:    0.6.1
 */