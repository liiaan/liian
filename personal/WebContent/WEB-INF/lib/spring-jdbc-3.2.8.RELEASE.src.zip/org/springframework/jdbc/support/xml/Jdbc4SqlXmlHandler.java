/*     */ package org.springframework.jdbc.support.xml;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLXML;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.dom.DOMResult;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.w3c.dom.Document;
/*     */ 
/*     */ public class Jdbc4SqlXmlHandler
/*     */   implements SqlXmlHandler
/*     */ {
/*     */   public String getXmlAsString(ResultSet rs, String columnName)
/*     */     throws SQLException
/*     */   {
/*  54 */     return rs.getSQLXML(columnName).getString();
/*     */   }
/*     */ 
/*     */   public String getXmlAsString(ResultSet rs, int columnIndex) throws SQLException {
/*  58 */     return rs.getSQLXML(columnIndex).getString();
/*     */   }
/*     */ 
/*     */   public InputStream getXmlAsBinaryStream(ResultSet rs, String columnName) throws SQLException {
/*  62 */     return rs.getSQLXML(columnName).getBinaryStream();
/*     */   }
/*     */ 
/*     */   public InputStream getXmlAsBinaryStream(ResultSet rs, int columnIndex) throws SQLException {
/*  66 */     return rs.getSQLXML(columnIndex).getBinaryStream();
/*     */   }
/*     */ 
/*     */   public Reader getXmlAsCharacterStream(ResultSet rs, String columnName) throws SQLException {
/*  70 */     return rs.getSQLXML(columnName).getCharacterStream();
/*     */   }
/*     */ 
/*     */   public Reader getXmlAsCharacterStream(ResultSet rs, int columnIndex) throws SQLException {
/*  74 */     return rs.getSQLXML(columnIndex).getCharacterStream();
/*     */   }
/*     */ 
/*     */   public Source getXmlAsSource(ResultSet rs, String columnName, Class sourceClass) throws SQLException
/*     */   {
/*  79 */     return rs.getSQLXML(columnName).getSource(sourceClass != null ? sourceClass : DOMSource.class);
/*     */   }
/*     */ 
/*     */   public Source getXmlAsSource(ResultSet rs, int columnIndex, Class sourceClass) throws SQLException
/*     */   {
/*  84 */     return rs.getSQLXML(columnIndex).getSource(sourceClass != null ? sourceClass : DOMSource.class);
/*     */   }
/*     */ 
/*     */   public SqlXmlValue newSqlXmlValue(final String value)
/*     */   {
/*  93 */     return new AbstractJdbc4SqlXmlValue(value)
/*     */     {
/*     */       protected void provideXml(SQLXML xmlObject) throws SQLException, IOException {
/*  96 */         xmlObject.setString(value);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public SqlXmlValue newSqlXmlValue(final XmlBinaryStreamProvider provider) {
/* 102 */     return new AbstractJdbc4SqlXmlValue(provider)
/*     */     {
/*     */       protected void provideXml(SQLXML xmlObject) throws SQLException, IOException {
/* 105 */         provider.provideXml(xmlObject.setBinaryStream());
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public SqlXmlValue newSqlXmlValue(final XmlCharacterStreamProvider provider) {
/* 111 */     return new AbstractJdbc4SqlXmlValue(provider)
/*     */     {
/*     */       protected void provideXml(SQLXML xmlObject) throws SQLException, IOException {
/* 114 */         provider.provideXml(xmlObject.setCharacterStream());
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public SqlXmlValue newSqlXmlValue(final Class resultClass, final XmlResultProvider provider) {
/* 120 */     return new AbstractJdbc4SqlXmlValue(provider)
/*     */     {
/*     */       protected void provideXml(SQLXML xmlObject) throws SQLException, IOException
/*     */       {
/* 124 */         provider.provideXml(xmlObject.setResult(resultClass));
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public SqlXmlValue newSqlXmlValue(final Document document) {
/* 130 */     return new AbstractJdbc4SqlXmlValue(document)
/*     */     {
/*     */       protected void provideXml(SQLXML xmlObject) throws SQLException, IOException {
/* 133 */         ((DOMResult)xmlObject.setResult(DOMResult.class)).setNode(document);
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   private static abstract class AbstractJdbc4SqlXmlValue
/*     */     implements SqlXmlValue
/*     */   {
/*     */     private SQLXML xmlObject;
/*     */ 
/*     */     public void setValue(PreparedStatement ps, int paramIndex)
/*     */       throws SQLException
/*     */     {
/* 147 */       this.xmlObject = ps.getConnection().createSQLXML();
/*     */       try {
/* 149 */         provideXml(this.xmlObject);
/*     */       }
/*     */       catch (IOException ex) {
/* 152 */         throw new DataAccessResourceFailureException("Failure encountered while providing XML", ex);
/*     */       }
/* 154 */       ps.setSQLXML(paramIndex, this.xmlObject);
/*     */     }
/*     */ 
/*     */     public void cleanup() {
/*     */       try {
/* 159 */         this.xmlObject.free();
/*     */       }
/*     */       catch (SQLException ex) {
/* 162 */         throw new DataAccessResourceFailureException("Could not free SQLXML object", ex);
/*     */       }
/*     */     }
/*     */ 
/*     */     protected abstract void provideXml(SQLXML paramSQLXML)
/*     */       throws SQLException, IOException;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.xml.Jdbc4SqlXmlHandler
 * JD-Core Version:    0.6.1
 */