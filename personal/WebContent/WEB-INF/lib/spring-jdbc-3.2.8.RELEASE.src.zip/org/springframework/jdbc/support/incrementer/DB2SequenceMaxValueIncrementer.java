/*    */ package org.springframework.jdbc.support.incrementer;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ 
/*    */ public class DB2SequenceMaxValueIncrementer extends AbstractSequenceMaxValueIncrementer
/*    */ {
/*    */   public DB2SequenceMaxValueIncrementer()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DB2SequenceMaxValueIncrementer(DataSource dataSource, String incrementerName)
/*    */   {
/* 45 */     super(dataSource, incrementerName);
/*    */   }
/*    */ 
/*    */   protected String getSequenceQuery()
/*    */   {
/* 51 */     return "values nextval for " + getIncrementerName();
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.incrementer.DB2SequenceMaxValueIncrementer
 * JD-Core Version:    0.6.1
 */