/*     */ package org.springframework.jdbc.core.support;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.dao.support.DaoSupport;
/*     */ import org.springframework.jdbc.CannotGetJdbcConnectionException;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*     */ import org.springframework.jdbc.support.SQLExceptionTranslator;
/*     */ 
/*     */ public abstract class JdbcDaoSupport extends DaoSupport
/*     */ {
/*     */   private JdbcTemplate jdbcTemplate;
/*     */ 
/*     */   public final void setDataSource(DataSource dataSource)
/*     */   {
/*  55 */     if ((this.jdbcTemplate == null) || (dataSource != this.jdbcTemplate.getDataSource())) {
/*  56 */       this.jdbcTemplate = createJdbcTemplate(dataSource);
/*  57 */       initTemplateConfig();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected JdbcTemplate createJdbcTemplate(DataSource dataSource)
/*     */   {
/*  71 */     return new JdbcTemplate(dataSource);
/*     */   }
/*     */ 
/*     */   public final DataSource getDataSource()
/*     */   {
/*  78 */     return this.jdbcTemplate != null ? this.jdbcTemplate.getDataSource() : null;
/*     */   }
/*     */ 
/*     */   public final void setJdbcTemplate(JdbcTemplate jdbcTemplate)
/*     */   {
/*  86 */     this.jdbcTemplate = jdbcTemplate;
/*  87 */     initTemplateConfig();
/*     */   }
/*     */ 
/*     */   public final JdbcTemplate getJdbcTemplate()
/*     */   {
/*  95 */     return this.jdbcTemplate;
/*     */   }
/*     */ 
/*     */   protected void initTemplateConfig()
/*     */   {
/*     */   }
/*     */ 
/*     */   protected void checkDaoConfig()
/*     */   {
/* 111 */     if (this.jdbcTemplate == null)
/* 112 */       throw new IllegalArgumentException("'dataSource' or 'jdbcTemplate' is required");
/*     */   }
/*     */ 
/*     */   protected final SQLExceptionTranslator getExceptionTranslator()
/*     */   {
/* 123 */     return getJdbcTemplate().getExceptionTranslator();
/*     */   }
/*     */ 
/*     */   protected final Connection getConnection()
/*     */     throws CannotGetJdbcConnectionException
/*     */   {
/* 133 */     return DataSourceUtils.getConnection(getDataSource());
/*     */   }
/*     */ 
/*     */   protected final void releaseConnection(Connection con)
/*     */   {
/* 143 */     DataSourceUtils.releaseConnection(con, getDataSource());
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.support.JdbcDaoSupport
 * JD-Core Version:    0.6.1
 */