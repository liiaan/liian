/*     */ package org.springframework.jdbc.object;
/*     */ 
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.jdbc.core.BatchPreparedStatementSetter;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.PreparedStatementSetter;
/*     */ 
/*     */ public class BatchSqlUpdate extends SqlUpdate
/*     */ {
/*  51 */   public static int DEFAULT_BATCH_SIZE = 5000;
/*     */ 
/*  54 */   private int batchSize = DEFAULT_BATCH_SIZE;
/*     */ 
/*  56 */   private boolean trackRowsAffected = true;
/*     */ 
/*  58 */   private final LinkedList<Object[]> parameterQueue = new LinkedList();
/*     */ 
/*  60 */   private final List<Integer> rowsAffected = new ArrayList();
/*     */ 
/*     */   public BatchSqlUpdate()
/*     */   {
/*     */   }
/*     */ 
/*     */   public BatchSqlUpdate(DataSource ds, String sql)
/*     */   {
/*  79 */     super(ds, sql);
/*     */   }
/*     */ 
/*     */   public BatchSqlUpdate(DataSource ds, String sql, int[] types)
/*     */   {
/*  92 */     super(ds, sql, types);
/*     */   }
/*     */ 
/*     */   public BatchSqlUpdate(DataSource ds, String sql, int[] types, int batchSize)
/*     */   {
/* 108 */     super(ds, sql, types);
/* 109 */     setBatchSize(batchSize);
/*     */   }
/*     */ 
/*     */   public void setBatchSize(int batchSize)
/*     */   {
/* 123 */     this.batchSize = batchSize;
/*     */   }
/*     */ 
/*     */   public void setTrackRowsAffected(boolean trackRowsAffected)
/*     */   {
/* 134 */     this.trackRowsAffected = trackRowsAffected;
/*     */   }
/*     */ 
/*     */   protected boolean supportsLobParameters()
/*     */   {
/* 142 */     return false;
/*     */   }
/*     */ 
/*     */   public int update(Object[] params)
/*     */     throws DataAccessException
/*     */   {
/* 162 */     validateParameters(params);
/* 163 */     this.parameterQueue.add(params.clone());
/*     */ 
/* 165 */     if (this.parameterQueue.size() == this.batchSize) {
/* 166 */       if (this.logger.isDebugEnabled()) {
/* 167 */         this.logger.debug("Triggering auto-flush because queue reached batch size of " + this.batchSize);
/*     */       }
/* 169 */       flush();
/*     */     }
/*     */ 
/* 172 */     return -1;
/*     */   }
/*     */ 
/*     */   public int[] flush()
/*     */   {
/* 180 */     if (this.parameterQueue.isEmpty()) {
/* 181 */       return new int[0];
/*     */     }
/*     */ 
/* 184 */     int[] rowsAffected = getJdbcTemplate().batchUpdate(getSql(), new BatchPreparedStatementSetter()
/*     */     {
/*     */       public int getBatchSize()
/*     */       {
/* 188 */         return BatchSqlUpdate.this.parameterQueue.size();
/*     */       }
/*     */       public void setValues(PreparedStatement ps, int index) throws SQLException {
/* 191 */         Object[] params = (Object[])BatchSqlUpdate.this.parameterQueue.removeFirst();
/* 192 */         BatchSqlUpdate.this.newPreparedStatementSetter(params).setValues(ps);
/*     */       }
/*     */     });
/* 196 */     for (int rowCount : rowsAffected) {
/* 197 */       checkRowsAffected(rowCount);
/* 198 */       if (this.trackRowsAffected) {
/* 199 */         this.rowsAffected.add(Integer.valueOf(rowCount));
/*     */       }
/*     */     }
/*     */ 
/* 203 */     return rowsAffected;
/*     */   }
/*     */ 
/*     */   public int getQueueCount()
/*     */   {
/* 211 */     return this.parameterQueue.size();
/*     */   }
/*     */ 
/*     */   public int getExecutionCount()
/*     */   {
/* 218 */     return this.rowsAffected.size();
/*     */   }
/*     */ 
/*     */   public int[] getRowsAffected()
/*     */   {
/* 229 */     int[] result = new int[this.rowsAffected.size()];
/* 230 */     int i = 0;
/* 231 */     for (Iterator it = this.rowsAffected.iterator(); it.hasNext(); i++) {
/* 232 */       result[i] = ((Integer)it.next()).intValue();
/*     */     }
/* 234 */     return result;
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */   {
/* 242 */     this.parameterQueue.clear();
/* 243 */     this.rowsAffected.clear();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.object.BatchSqlUpdate
 * JD-Core Version:    0.6.1
 */