/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.core.NamedThreadLocal;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class UserCredentialsDataSourceAdapter extends DelegatingDataSource
/*     */ {
/*     */   private String username;
/*     */   private String password;
/*     */   private final ThreadLocal<JdbcUserCredentials> threadBoundCredentials;
/*     */ 
/*     */   public UserCredentialsDataSourceAdapter()
/*     */   {
/*  68 */     this.threadBoundCredentials = new NamedThreadLocal("Current JDBC user credentials");
/*     */   }
/*     */ 
/*     */   public void setUsername(String username)
/*     */   {
/*  81 */     this.username = username;
/*     */   }
/*     */ 
/*     */   public void setPassword(String password)
/*     */   {
/*  93 */     this.password = password;
/*     */   }
/*     */ 
/*     */   public void setCredentialsForCurrentThread(String username, String password)
/*     */   {
/* 108 */     this.threadBoundCredentials.set(new JdbcUserCredentials(username, password, null));
/*     */   }
/*     */ 
/*     */   public void removeCredentialsFromCurrentThread()
/*     */   {
/* 117 */     this.threadBoundCredentials.remove();
/*     */   }
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws SQLException
/*     */   {
/* 130 */     JdbcUserCredentials threadCredentials = (JdbcUserCredentials)this.threadBoundCredentials.get();
/* 131 */     if (threadCredentials != null) {
/* 132 */       return doGetConnection(threadCredentials.username, threadCredentials.password);
/*     */     }
/*     */ 
/* 135 */     return doGetConnection(this.username, this.password);
/*     */   }
/*     */ 
/*     */   public Connection getConnection(String username, String password)
/*     */     throws SQLException
/*     */   {
/* 145 */     return doGetConnection(username, password);
/*     */   }
/*     */ 
/*     */   protected Connection doGetConnection(String username, String password)
/*     */     throws SQLException
/*     */   {
/* 160 */     Assert.state(getTargetDataSource() != null, "'targetDataSource' is required");
/* 161 */     if (StringUtils.hasLength(username)) {
/* 162 */       return getTargetDataSource().getConnection(username, password);
/*     */     }
/*     */ 
/* 165 */     return getTargetDataSource().getConnection();
/*     */   }
/*     */ 
/*     */   private static class JdbcUserCredentials
/*     */   {
/*     */     public final String username;
/*     */     public final String password;
/*     */ 
/*     */     private JdbcUserCredentials(String username, String password)
/*     */     {
/* 180 */       this.username = username;
/* 181 */       this.password = password;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 186 */       return "JdbcUserCredentials[username='" + this.username + "',password='" + this.password + "']";
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.UserCredentialsDataSourceAdapter
 * JD-Core Version:    0.6.1
 */