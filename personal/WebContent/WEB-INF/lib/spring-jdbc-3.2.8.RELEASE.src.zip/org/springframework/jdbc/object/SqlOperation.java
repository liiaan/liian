/*     */ package org.springframework.jdbc.object;
/*     */ 
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.PreparedStatementCreator;
/*     */ import org.springframework.jdbc.core.PreparedStatementCreatorFactory;
/*     */ import org.springframework.jdbc.core.PreparedStatementSetter;
/*     */ import org.springframework.jdbc.core.namedparam.NamedParameterUtils;
/*     */ import org.springframework.jdbc.core.namedparam.ParsedSql;
/*     */ 
/*     */ public abstract class SqlOperation extends RdbmsOperation
/*     */ {
/*     */   private PreparedStatementCreatorFactory preparedStatementFactory;
/*     */   private ParsedSql cachedSql;
/*  47 */   private final Object parsedSqlMonitor = new Object();
/*     */ 
/*     */   protected final void compileInternal()
/*     */   {
/*  56 */     this.preparedStatementFactory = new PreparedStatementCreatorFactory(getSql(), getDeclaredParameters());
/*  57 */     this.preparedStatementFactory.setResultSetType(getResultSetType());
/*  58 */     this.preparedStatementFactory.setUpdatableResults(isUpdatableResults());
/*  59 */     this.preparedStatementFactory.setReturnGeneratedKeys(isReturnGeneratedKeys());
/*  60 */     if (getGeneratedKeysColumnNames() != null) {
/*  61 */       this.preparedStatementFactory.setGeneratedKeysColumnNames(getGeneratedKeysColumnNames());
/*     */     }
/*  63 */     this.preparedStatementFactory.setNativeJdbcExtractor(getJdbcTemplate().getNativeJdbcExtractor());
/*     */ 
/*  65 */     onCompileInternal();
/*     */   }
/*     */ 
/*     */   protected void onCompileInternal()
/*     */   {
/*     */   }
/*     */ 
/*     */   protected ParsedSql getParsedSql()
/*     */   {
/*  81 */     synchronized (this.parsedSqlMonitor) {
/*  82 */       if (this.cachedSql == null) {
/*  83 */         this.cachedSql = NamedParameterUtils.parseSqlStatement(getSql());
/*     */       }
/*  85 */       return this.cachedSql;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected final PreparedStatementSetter newPreparedStatementSetter(Object[] params)
/*     */   {
/*  96 */     return this.preparedStatementFactory.newPreparedStatementSetter(params);
/*     */   }
/*     */ 
/*     */   protected final PreparedStatementCreator newPreparedStatementCreator(Object[] params)
/*     */   {
/* 105 */     return this.preparedStatementFactory.newPreparedStatementCreator(params);
/*     */   }
/*     */ 
/*     */   protected final PreparedStatementCreator newPreparedStatementCreator(String sqlToUse, Object[] params)
/*     */   {
/* 116 */     return this.preparedStatementFactory.newPreparedStatementCreator(sqlToUse, params);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.object.SqlOperation
 * JD-Core Version:    0.6.1
 */