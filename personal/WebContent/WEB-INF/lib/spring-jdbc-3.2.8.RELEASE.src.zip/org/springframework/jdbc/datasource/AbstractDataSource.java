/*    */ package org.springframework.jdbc.datasource;
/*    */ 
/*    */ import java.io.PrintWriter;
/*    */ import java.sql.SQLException;
/*    */ import java.util.logging.Logger;
/*    */ import javax.sql.DataSource;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.LogFactory;
/*    */ 
/*    */ public abstract class AbstractDataSource
/*    */   implements DataSource
/*    */ {
/* 42 */   protected final Log logger = LogFactory.getLog(getClass());
/*    */ 
/*    */   public int getLoginTimeout()
/*    */     throws SQLException
/*    */   {
/* 49 */     return 0;
/*    */   }
/*    */ 
/*    */   public void setLoginTimeout(int timeout)
/*    */     throws SQLException
/*    */   {
/* 56 */     throw new UnsupportedOperationException("setLoginTimeout");
/*    */   }
/*    */ 
/*    */   public PrintWriter getLogWriter()
/*    */   {
/* 63 */     throw new UnsupportedOperationException("getLogWriter");
/*    */   }
/*    */ 
/*    */   public void setLogWriter(PrintWriter pw)
/*    */     throws SQLException
/*    */   {
/* 70 */     throw new UnsupportedOperationException("setLogWriter");
/*    */   }
/*    */ 
/*    */   public <T> T unwrap(Class<T> iface)
/*    */     throws SQLException
/*    */   {
/* 80 */     if (iface.isInstance(this)) {
/* 81 */       return this;
/*    */     }
/* 83 */     throw new SQLException("DataSource of type [" + getClass().getName() + "] cannot be unwrapped as [" + iface.getName() + "]");
/*    */   }
/*    */ 
/*    */   public boolean isWrapperFor(Class<?> iface) throws SQLException
/*    */   {
/* 88 */     return iface.isInstance(this);
/*    */   }
/*    */ 
/*    */   public Logger getParentLogger()
/*    */   {
/* 97 */     return Logger.getLogger("global");
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.AbstractDataSource
 * JD-Core Version:    0.6.1
 */