/*     */ package org.springframework.jdbc.core.simple;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*     */ import org.springframework.jdbc.support.KeyHolder;
/*     */ import org.springframework.jdbc.support.nativejdbc.NativeJdbcExtractor;
/*     */ 
/*     */ public class SimpleJdbcInsert extends AbstractJdbcInsert
/*     */   implements SimpleJdbcInsertOperations
/*     */ {
/*     */   public SimpleJdbcInsert(DataSource dataSource)
/*     */   {
/*  60 */     super(dataSource);
/*     */   }
/*     */ 
/*     */   public SimpleJdbcInsert(JdbcTemplate jdbcTemplate)
/*     */   {
/*  69 */     super(jdbcTemplate);
/*     */   }
/*     */ 
/*     */   public SimpleJdbcInsert withTableName(String tableName)
/*     */   {
/*  74 */     setTableName(tableName);
/*  75 */     return this;
/*     */   }
/*     */ 
/*     */   public SimpleJdbcInsert withSchemaName(String schemaName) {
/*  79 */     setSchemaName(schemaName);
/*  80 */     return this;
/*     */   }
/*     */ 
/*     */   public SimpleJdbcInsert withCatalogName(String catalogName) {
/*  84 */     setCatalogName(catalogName);
/*  85 */     return this;
/*     */   }
/*     */ 
/*     */   public SimpleJdbcInsert usingColumns(String[] columnNames) {
/*  89 */     setColumnNames(Arrays.asList(columnNames));
/*  90 */     return this;
/*     */   }
/*     */ 
/*     */   public SimpleJdbcInsert usingGeneratedKeyColumns(String[] columnNames) {
/*  94 */     setGeneratedKeyNames(columnNames);
/*  95 */     return this;
/*     */   }
/*     */ 
/*     */   public SimpleJdbcInsertOperations withoutTableColumnMetaDataAccess() {
/*  99 */     setAccessTableColumnMetaData(false);
/* 100 */     return this;
/*     */   }
/*     */ 
/*     */   public SimpleJdbcInsertOperations includeSynonymsForTableColumnMetaData() {
/* 104 */     setOverrideIncludeSynonymsDefault(true);
/* 105 */     return this;
/*     */   }
/*     */ 
/*     */   public SimpleJdbcInsertOperations useNativeJdbcExtractorForMetaData(NativeJdbcExtractor nativeJdbcExtractor) {
/* 109 */     setNativeJdbcExtractor(nativeJdbcExtractor);
/* 110 */     return this;
/*     */   }
/*     */ 
/*     */   public int execute(Map<String, Object> args) {
/* 114 */     return doExecute(args);
/*     */   }
/*     */ 
/*     */   public int execute(SqlParameterSource parameterSource) {
/* 118 */     return doExecute(parameterSource);
/*     */   }
/*     */ 
/*     */   public Number executeAndReturnKey(Map<String, Object> args) {
/* 122 */     return doExecuteAndReturnKey(args);
/*     */   }
/*     */ 
/*     */   public Number executeAndReturnKey(SqlParameterSource parameterSource) {
/* 126 */     return doExecuteAndReturnKey(parameterSource);
/*     */   }
/*     */ 
/*     */   public KeyHolder executeAndReturnKeyHolder(Map<String, Object> args) {
/* 130 */     return doExecuteAndReturnKeyHolder(args);
/*     */   }
/*     */ 
/*     */   public KeyHolder executeAndReturnKeyHolder(SqlParameterSource parameterSource) {
/* 134 */     return doExecuteAndReturnKeyHolder(parameterSource);
/*     */   }
/*     */ 
/*     */   public int[] executeBatch(Map<String, Object>[] batch) {
/* 138 */     return doExecuteBatch(batch);
/*     */   }
/*     */ 
/*     */   public int[] executeBatch(SqlParameterSource[] batch) {
/* 142 */     return doExecuteBatch(batch);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.simple.SimpleJdbcInsert
 * JD-Core Version:    0.6.1
 */