/*     */ package org.springframework.jdbc.support.nativejdbc;
/*     */ 
/*     */ import com.mchange.v2.c3p0.C3P0ProxyConnection;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class C3P0NativeJdbcExtractor extends NativeJdbcExtractorAdapter
/*     */ {
/*     */   private final Method getRawConnectionMethod;
/*     */ 
/*     */   public static Connection getRawConnection(Connection con)
/*     */   {
/*  60 */     return con;
/*     */   }
/*     */ 
/*     */   public C3P0NativeJdbcExtractor()
/*     */   {
/*     */     try {
/*  66 */       this.getRawConnectionMethod = getClass().getMethod("getRawConnection", new Class[] { Connection.class });
/*     */     }
/*     */     catch (NoSuchMethodException ex) {
/*  69 */       throw new IllegalStateException("Internal error in C3P0NativeJdbcExtractor: " + ex.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isNativeConnectionNecessaryForNativeStatements()
/*     */   {
/*  76 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isNativeConnectionNecessaryForNativePreparedStatements()
/*     */   {
/*  81 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isNativeConnectionNecessaryForNativeCallableStatements()
/*     */   {
/*  86 */     return true;
/*     */   }
/*     */ 
/*     */   protected Connection doGetNativeConnection(Connection con)
/*     */     throws SQLException
/*     */   {
/*  97 */     if ((con instanceof C3P0ProxyConnection)) {
/*  98 */       C3P0ProxyConnection cpCon = (C3P0ProxyConnection)con;
/*     */       try {
/* 100 */         return (Connection)cpCon.rawConnectionOperation(this.getRawConnectionMethod, null, new Object[] { C3P0ProxyConnection.RAW_CONNECTION });
/*     */       }
/*     */       catch (SQLException ex)
/*     */       {
/* 104 */         throw ex;
/*     */       }
/*     */       catch (Exception ex) {
/* 107 */         ReflectionUtils.handleReflectionException(ex);
/*     */       }
/*     */     }
/* 110 */     return con;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.nativejdbc.C3P0NativeJdbcExtractor
 * JD-Core Version:    0.6.1
 */