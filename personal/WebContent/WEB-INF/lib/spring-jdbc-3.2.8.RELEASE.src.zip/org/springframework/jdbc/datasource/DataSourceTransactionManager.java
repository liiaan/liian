/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ import org.springframework.transaction.CannotCreateTransactionException;
/*     */ import org.springframework.transaction.TransactionDefinition;
/*     */ import org.springframework.transaction.TransactionSystemException;
/*     */ import org.springframework.transaction.support.AbstractPlatformTransactionManager;
/*     */ import org.springframework.transaction.support.DefaultTransactionStatus;
/*     */ import org.springframework.transaction.support.ResourceTransactionManager;
/*     */ import org.springframework.transaction.support.TransactionSynchronizationManager;
/*     */ 
/*     */ public class DataSourceTransactionManager extends AbstractPlatformTransactionManager
/*     */   implements ResourceTransactionManager, InitializingBean
/*     */ {
/*     */   private DataSource dataSource;
/*     */ 
/*     */   public DataSourceTransactionManager()
/*     */   {
/* 115 */     setNestedTransactionAllowed(true);
/*     */   }
/*     */ 
/*     */   public DataSourceTransactionManager(DataSource dataSource)
/*     */   {
/* 123 */     this();
/* 124 */     setDataSource(dataSource);
/* 125 */     afterPropertiesSet();
/*     */   }
/*     */ 
/*     */   public void setDataSource(DataSource dataSource)
/*     */   {
/* 147 */     if ((dataSource instanceof TransactionAwareDataSourceProxy))
/*     */     {
/* 151 */       this.dataSource = ((TransactionAwareDataSourceProxy)dataSource).getTargetDataSource();
/*     */     }
/*     */     else
/* 154 */       this.dataSource = dataSource;
/*     */   }
/*     */ 
/*     */   public DataSource getDataSource()
/*     */   {
/* 162 */     return this.dataSource;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet() {
/* 166 */     if (getDataSource() == null)
/* 167 */       throw new IllegalArgumentException("Property 'dataSource' is required");
/*     */   }
/*     */ 
/*     */   public Object getResourceFactory()
/*     */   {
/* 173 */     return getDataSource();
/*     */   }
/*     */ 
/*     */   protected Object doGetTransaction()
/*     */   {
/* 178 */     DataSourceTransactionObject txObject = new DataSourceTransactionObject(null);
/* 179 */     txObject.setSavepointAllowed(isNestedTransactionAllowed());
/* 180 */     ConnectionHolder conHolder = (ConnectionHolder)TransactionSynchronizationManager.getResource(this.dataSource);
/*     */ 
/* 182 */     txObject.setConnectionHolder(conHolder, false);
/* 183 */     return txObject;
/*     */   }
/*     */ 
/*     */   protected boolean isExistingTransaction(Object transaction)
/*     */   {
/* 188 */     DataSourceTransactionObject txObject = (DataSourceTransactionObject)transaction;
/* 189 */     return (txObject.getConnectionHolder() != null) && (txObject.getConnectionHolder().isTransactionActive());
/*     */   }
/*     */ 
/*     */   protected void doBegin(Object transaction, TransactionDefinition definition)
/*     */   {
/* 197 */     DataSourceTransactionObject txObject = (DataSourceTransactionObject)transaction;
/* 198 */     Connection con = null;
/*     */     try
/*     */     {
/* 201 */       if ((txObject.getConnectionHolder() == null) || (txObject.getConnectionHolder().isSynchronizedWithTransaction()))
/*     */       {
/* 203 */         Connection newCon = this.dataSource.getConnection();
/* 204 */         if (this.logger.isDebugEnabled()) {
/* 205 */           this.logger.debug("Acquired Connection [" + newCon + "] for JDBC transaction");
/*     */         }
/* 207 */         txObject.setConnectionHolder(new ConnectionHolder(newCon), true);
/*     */       }
/*     */ 
/* 210 */       txObject.getConnectionHolder().setSynchronizedWithTransaction(true);
/* 211 */       con = txObject.getConnectionHolder().getConnection();
/*     */ 
/* 213 */       Integer previousIsolationLevel = DataSourceUtils.prepareConnectionForTransaction(con, definition);
/* 214 */       txObject.setPreviousIsolationLevel(previousIsolationLevel);
/*     */ 
/* 219 */       if (con.getAutoCommit()) {
/* 220 */         txObject.setMustRestoreAutoCommit(true);
/* 221 */         if (this.logger.isDebugEnabled()) {
/* 222 */           this.logger.debug("Switching JDBC Connection [" + con + "] to manual commit");
/*     */         }
/* 224 */         con.setAutoCommit(false);
/*     */       }
/* 226 */       txObject.getConnectionHolder().setTransactionActive(true);
/*     */ 
/* 228 */       int timeout = determineTimeout(definition);
/* 229 */       if (timeout != -1) {
/* 230 */         txObject.getConnectionHolder().setTimeoutInSeconds(timeout);
/*     */       }
/*     */ 
/* 234 */       if (txObject.isNewConnectionHolder()) {
/* 235 */         TransactionSynchronizationManager.bindResource(getDataSource(), txObject.getConnectionHolder());
/*     */       }
/*     */     }
/*     */     catch (Throwable ex)
/*     */     {
/* 240 */       DataSourceUtils.releaseConnection(con, this.dataSource);
/* 241 */       throw new CannotCreateTransactionException("Could not open JDBC Connection for transaction", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object doSuspend(Object transaction)
/*     */   {
/* 247 */     DataSourceTransactionObject txObject = (DataSourceTransactionObject)transaction;
/* 248 */     txObject.setConnectionHolder(null);
/* 249 */     ConnectionHolder conHolder = (ConnectionHolder)TransactionSynchronizationManager.unbindResource(this.dataSource);
/*     */ 
/* 251 */     return conHolder;
/*     */   }
/*     */ 
/*     */   protected void doResume(Object transaction, Object suspendedResources)
/*     */   {
/* 256 */     ConnectionHolder conHolder = (ConnectionHolder)suspendedResources;
/* 257 */     TransactionSynchronizationManager.bindResource(this.dataSource, conHolder);
/*     */   }
/*     */ 
/*     */   protected void doCommit(DefaultTransactionStatus status)
/*     */   {
/* 262 */     DataSourceTransactionObject txObject = (DataSourceTransactionObject)status.getTransaction();
/* 263 */     Connection con = txObject.getConnectionHolder().getConnection();
/* 264 */     if (status.isDebug())
/* 265 */       this.logger.debug("Committing JDBC transaction on Connection [" + con + "]");
/*     */     try
/*     */     {
/* 268 */       con.commit();
/*     */     }
/*     */     catch (SQLException ex) {
/* 271 */       throw new TransactionSystemException("Could not commit JDBC transaction", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void doRollback(DefaultTransactionStatus status)
/*     */   {
/* 277 */     DataSourceTransactionObject txObject = (DataSourceTransactionObject)status.getTransaction();
/* 278 */     Connection con = txObject.getConnectionHolder().getConnection();
/* 279 */     if (status.isDebug())
/* 280 */       this.logger.debug("Rolling back JDBC transaction on Connection [" + con + "]");
/*     */     try
/*     */     {
/* 283 */       con.rollback();
/*     */     }
/*     */     catch (SQLException ex) {
/* 286 */       throw new TransactionSystemException("Could not roll back JDBC transaction", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void doSetRollbackOnly(DefaultTransactionStatus status)
/*     */   {
/* 292 */     DataSourceTransactionObject txObject = (DataSourceTransactionObject)status.getTransaction();
/* 293 */     if (status.isDebug()) {
/* 294 */       this.logger.debug("Setting JDBC transaction [" + txObject.getConnectionHolder().getConnection() + "] rollback-only");
/*     */     }
/*     */ 
/* 297 */     txObject.setRollbackOnly();
/*     */   }
/*     */ 
/*     */   protected void doCleanupAfterCompletion(Object transaction)
/*     */   {
/* 302 */     DataSourceTransactionObject txObject = (DataSourceTransactionObject)transaction;
/*     */ 
/* 305 */     if (txObject.isNewConnectionHolder()) {
/* 306 */       TransactionSynchronizationManager.unbindResource(this.dataSource);
/*     */     }
/*     */ 
/* 310 */     Connection con = txObject.getConnectionHolder().getConnection();
/*     */     try {
/* 312 */       if (txObject.isMustRestoreAutoCommit()) {
/* 313 */         con.setAutoCommit(true);
/*     */       }
/* 315 */       DataSourceUtils.resetConnectionAfterTransaction(con, txObject.getPreviousIsolationLevel());
/*     */     }
/*     */     catch (Throwable ex) {
/* 318 */       this.logger.debug("Could not reset JDBC Connection after transaction", ex);
/*     */     }
/*     */ 
/* 321 */     if (txObject.isNewConnectionHolder()) {
/* 322 */       if (this.logger.isDebugEnabled()) {
/* 323 */         this.logger.debug("Releasing JDBC Connection [" + con + "] after transaction");
/*     */       }
/* 325 */       DataSourceUtils.releaseConnection(con, this.dataSource);
/*     */     }
/*     */ 
/* 328 */     txObject.getConnectionHolder().clear();
/*     */   }
/*     */ 
/*     */   private static class DataSourceTransactionObject extends JdbcTransactionObjectSupport
/*     */   {
/*     */     private boolean newConnectionHolder;
/*     */     private boolean mustRestoreAutoCommit;
/*     */ 
/*     */     public void setConnectionHolder(ConnectionHolder connectionHolder, boolean newConnectionHolder)
/*     */     {
/* 343 */       super.setConnectionHolder(connectionHolder);
/* 344 */       this.newConnectionHolder = newConnectionHolder;
/*     */     }
/*     */ 
/*     */     public boolean isNewConnectionHolder() {
/* 348 */       return this.newConnectionHolder;
/*     */     }
/*     */ 
/*     */     public void setMustRestoreAutoCommit(boolean mustRestoreAutoCommit) {
/* 352 */       this.mustRestoreAutoCommit = mustRestoreAutoCommit;
/*     */     }
/*     */ 
/*     */     public boolean isMustRestoreAutoCommit() {
/* 356 */       return this.mustRestoreAutoCommit;
/*     */     }
/*     */ 
/*     */     public void setRollbackOnly() {
/* 360 */       getConnectionHolder().setRollbackOnly();
/*     */     }
/*     */ 
/*     */     public boolean isRollbackOnly() {
/* 364 */       return getConnectionHolder().isRollbackOnly();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.DataSourceTransactionManager
 * JD-Core Version:    0.6.1
 */