/*     */ package org.springframework.jdbc.support.nativejdbc;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import org.springframework.util.ReflectionUtils;
/*     */ 
/*     */ public class JBossNativeJdbcExtractor extends NativeJdbcExtractorAdapter
/*     */ {
/*     */   private static final String JBOSS_JCA_PREFIX = "org.jboss.jca.adapters.jdbc.";
/*     */   private static final String JBOSS_RESOURCE_PREFIX = "org.jboss.resource.adapter.jdbc.";
/*     */   private Class wrappedConnectionClass;
/*     */   private Class wrappedStatementClass;
/*     */   private Class wrappedResultSetClass;
/*     */   private Method getUnderlyingConnectionMethod;
/*     */   private Method getUnderlyingStatementMethod;
/*     */   private Method getUnderlyingResultSetMethod;
/*     */ 
/*     */   public JBossNativeJdbcExtractor()
/*     */   {
/*  76 */     String prefix = "org.jboss.jca.adapters.jdbc.";
/*     */     try
/*     */     {
/*  79 */       this.wrappedConnectionClass = getClass().getClassLoader().loadClass(prefix + "WrappedConnection");
/*     */     }
/*     */     catch (ClassNotFoundException ex)
/*     */     {
/*  83 */       prefix = "org.jboss.resource.adapter.jdbc.";
/*     */       try {
/*  85 */         this.wrappedConnectionClass = getClass().getClassLoader().loadClass(prefix + "WrappedConnection");
/*     */       }
/*     */       catch (ClassNotFoundException ex2) {
/*  88 */         throw new IllegalStateException("Could not initialize JBossNativeJdbcExtractor: neither JBoss 7's [org.jboss.jca.adapters.jdbc..WrappedConnection] nor traditional JBoss [org.jboss.resource.adapter.jdbc..WrappedConnection] found");
/*     */       }
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  94 */       this.wrappedStatementClass = getClass().getClassLoader().loadClass(prefix + "WrappedStatement");
/*  95 */       this.wrappedResultSetClass = getClass().getClassLoader().loadClass(prefix + "WrappedResultSet");
/*  96 */       this.getUnderlyingConnectionMethod = this.wrappedConnectionClass.getMethod("getUnderlyingConnection", (Class[])null);
/*     */ 
/*  98 */       this.getUnderlyingStatementMethod = this.wrappedStatementClass.getMethod("getUnderlyingStatement", (Class[])null);
/*     */ 
/* 100 */       this.getUnderlyingResultSetMethod = this.wrappedResultSetClass.getMethod("getUnderlyingResultSet", (Class[])null);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 104 */       throw new IllegalStateException("Could not initialize JBossNativeJdbcExtractor because of missing JBoss API methods/classes: " + ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Connection doGetNativeConnection(Connection con)
/*     */     throws SQLException
/*     */   {
/* 115 */     if (this.wrappedConnectionClass.isAssignableFrom(con.getClass())) {
/* 116 */       return (Connection)ReflectionUtils.invokeJdbcMethod(this.getUnderlyingConnectionMethod, con);
/*     */     }
/* 118 */     return con;
/*     */   }
/*     */ 
/*     */   public Statement getNativeStatement(Statement stmt)
/*     */     throws SQLException
/*     */   {
/* 126 */     if (this.wrappedStatementClass.isAssignableFrom(stmt.getClass())) {
/* 127 */       return (Statement)ReflectionUtils.invokeJdbcMethod(this.getUnderlyingStatementMethod, stmt);
/*     */     }
/* 129 */     return stmt;
/*     */   }
/*     */ 
/*     */   public PreparedStatement getNativePreparedStatement(PreparedStatement ps)
/*     */     throws SQLException
/*     */   {
/* 137 */     return (PreparedStatement)getNativeStatement(ps);
/*     */   }
/*     */ 
/*     */   public CallableStatement getNativeCallableStatement(CallableStatement cs)
/*     */     throws SQLException
/*     */   {
/* 145 */     return (CallableStatement)getNativeStatement(cs);
/*     */   }
/*     */ 
/*     */   public ResultSet getNativeResultSet(ResultSet rs)
/*     */     throws SQLException
/*     */   {
/* 153 */     if (this.wrappedResultSetClass.isAssignableFrom(rs.getClass())) {
/* 154 */       return (ResultSet)ReflectionUtils.invokeJdbcMethod(this.getUnderlyingResultSetMethod, rs);
/*     */     }
/* 156 */     return rs;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.nativejdbc.JBossNativeJdbcExtractor
 * JD-Core Version:    0.6.1
 */