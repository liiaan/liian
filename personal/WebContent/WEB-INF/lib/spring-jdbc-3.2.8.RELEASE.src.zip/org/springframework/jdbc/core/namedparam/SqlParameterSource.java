package org.springframework.jdbc.core.namedparam;

public abstract interface SqlParameterSource
{
  public static final int TYPE_UNKNOWN = -2147483648;

  public abstract boolean hasValue(String paramString);

  public abstract Object getValue(String paramString)
    throws IllegalArgumentException;

  public abstract int getSqlType(String paramString);

  public abstract String getTypeName(String paramString);
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.namedparam.SqlParameterSource
 * JD-Core Version:    0.6.1
 */