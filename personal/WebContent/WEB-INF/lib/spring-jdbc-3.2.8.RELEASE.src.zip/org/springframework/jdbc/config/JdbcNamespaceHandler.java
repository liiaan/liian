/*    */ package org.springframework.jdbc.config;
/*    */ 
/*    */ import org.springframework.beans.factory.xml.NamespaceHandlerSupport;
/*    */ 
/*    */ public class JdbcNamespaceHandler extends NamespaceHandlerSupport
/*    */ {
/*    */   public void init()
/*    */   {
/* 30 */     registerBeanDefinitionParser("embedded-database", new EmbeddedDatabaseBeanDefinitionParser());
/* 31 */     registerBeanDefinitionParser("initialize-database", new InitializeDatabaseBeanDefinitionParser());
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.config.JdbcNamespaceHandler
 * JD-Core Version:    0.6.1
 */