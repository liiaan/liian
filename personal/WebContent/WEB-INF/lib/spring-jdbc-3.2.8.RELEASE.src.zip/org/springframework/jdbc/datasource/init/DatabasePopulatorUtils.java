/*    */ package org.springframework.jdbc.datasource.init;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.dao.DataAccessResourceFailureException;
/*    */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public abstract class DatabasePopulatorUtils
/*    */ {
/*    */   public static void execute(DatabasePopulator populator, DataSource dataSource)
/*    */   {
/* 42 */     Assert.notNull(populator, "DatabasePopulator must be provided");
/* 43 */     Assert.notNull(dataSource, "DataSource must be provided");
/*    */     try {
/* 45 */       Connection connection = DataSourceUtils.getConnection(dataSource);
/*    */       try {
/* 47 */         populator.populate(connection);
/*    */       }
/*    */       finally {
/* 50 */         if (connection != null)
/* 51 */           DataSourceUtils.releaseConnection(connection, dataSource);
/*    */       }
/*    */     }
/*    */     catch (Exception ex)
/*    */     {
/* 56 */       throw new DataAccessResourceFailureException("Failed to execute database script", ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.init.DatabasePopulatorUtils
 * JD-Core Version:    0.6.1
 */