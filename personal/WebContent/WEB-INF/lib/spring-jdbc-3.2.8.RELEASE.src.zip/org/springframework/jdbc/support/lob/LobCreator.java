package org.springframework.jdbc.support.lob;

import java.io.Closeable;
import java.io.InputStream;
import java.io.Reader;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public abstract interface LobCreator extends Closeable
{
  public abstract void setBlobAsBytes(PreparedStatement paramPreparedStatement, int paramInt, byte[] paramArrayOfByte)
    throws SQLException;

  public abstract void setBlobAsBinaryStream(PreparedStatement paramPreparedStatement, int paramInt1, InputStream paramInputStream, int paramInt2)
    throws SQLException;

  public abstract void setClobAsString(PreparedStatement paramPreparedStatement, int paramInt, String paramString)
    throws SQLException;

  public abstract void setClobAsAsciiStream(PreparedStatement paramPreparedStatement, int paramInt1, InputStream paramInputStream, int paramInt2)
    throws SQLException;

  public abstract void setClobAsCharacterStream(PreparedStatement paramPreparedStatement, int paramInt1, Reader paramReader, int paramInt2)
    throws SQLException;

  public abstract void close();
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.lob.LobCreator
 * JD-Core Version:    0.6.1
 */