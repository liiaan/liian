/*     */ package org.springframework.jdbc.core.simple;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import javax.sql.DataSource;
/*     */ import org.springframework.jdbc.core.JdbcTemplate;
/*     */ import org.springframework.jdbc.core.RowMapper;
/*     */ import org.springframework.jdbc.core.SqlParameter;
/*     */ import org.springframework.jdbc.core.namedparam.SqlParameterSource;
/*     */ 
/*     */ public class SimpleJdbcCall extends AbstractJdbcCall
/*     */   implements SimpleJdbcCallOperations
/*     */ {
/*     */   public SimpleJdbcCall(DataSource dataSource)
/*     */   {
/*  69 */     super(dataSource);
/*     */   }
/*     */ 
/*     */   public SimpleJdbcCall(JdbcTemplate jdbcTemplate)
/*     */   {
/*  78 */     super(jdbcTemplate);
/*     */   }
/*     */ 
/*     */   public SimpleJdbcCall withProcedureName(String procedureName)
/*     */   {
/*  83 */     setProcedureName(procedureName);
/*  84 */     setFunction(false);
/*  85 */     return this;
/*     */   }
/*     */ 
/*     */   public SimpleJdbcCall withFunctionName(String functionName) {
/*  89 */     setProcedureName(functionName);
/*  90 */     setFunction(true);
/*  91 */     return this;
/*     */   }
/*     */ 
/*     */   public SimpleJdbcCall withSchemaName(String schemaName) {
/*  95 */     setSchemaName(schemaName);
/*  96 */     return this;
/*     */   }
/*     */ 
/*     */   public SimpleJdbcCall withCatalogName(String catalogName) {
/* 100 */     setCatalogName(catalogName);
/* 101 */     return this;
/*     */   }
/*     */ 
/*     */   public SimpleJdbcCall withReturnValue() {
/* 105 */     setReturnValueRequired(true);
/* 106 */     return this;
/*     */   }
/*     */ 
/*     */   public SimpleJdbcCall declareParameters(SqlParameter[] sqlParameters) {
/* 110 */     for (SqlParameter sqlParameter : sqlParameters) {
/* 111 */       if (sqlParameter != null) {
/* 112 */         addDeclaredParameter(sqlParameter);
/*     */       }
/*     */     }
/* 115 */     return this;
/*     */   }
/*     */ 
/*     */   public SimpleJdbcCall useInParameterNames(String[] inParameterNames) {
/* 119 */     setInParameterNames(new HashSet(Arrays.asList(inParameterNames)));
/* 120 */     return this;
/*     */   }
/*     */ 
/*     */   public SimpleJdbcCall returningResultSet(String parameterName, RowMapper rowMapper) {
/* 124 */     addDeclaredRowMapper(parameterName, rowMapper);
/* 125 */     return this;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public SimpleJdbcCall returningResultSet(String parameterName, ParameterizedRowMapper rowMapper)
/*     */   {
/* 133 */     addDeclaredRowMapper(parameterName, rowMapper);
/* 134 */     return this;
/*     */   }
/*     */ 
/*     */   public SimpleJdbcCall withoutProcedureColumnMetaDataAccess() {
/* 138 */     setAccessCallParameterMetaData(false);
/* 139 */     return this;
/*     */   }
/*     */ 
/*     */   public <T> T executeFunction(Class<T> returnType, Object[] args)
/*     */   {
/* 144 */     return doExecute(args).get(getScalarOutParameterName());
/*     */   }
/*     */ 
/*     */   public <T> T executeFunction(Class<T> returnType, Map<String, ?> args)
/*     */   {
/* 149 */     return doExecute(args).get(getScalarOutParameterName());
/*     */   }
/*     */ 
/*     */   public <T> T executeFunction(Class<T> returnType, SqlParameterSource args)
/*     */   {
/* 154 */     return doExecute(args).get(getScalarOutParameterName());
/*     */   }
/*     */ 
/*     */   public <T> T executeObject(Class<T> returnType, Object[] args)
/*     */   {
/* 159 */     return doExecute(args).get(getScalarOutParameterName());
/*     */   }
/*     */ 
/*     */   public <T> T executeObject(Class<T> returnType, Map<String, ?> args)
/*     */   {
/* 164 */     return doExecute(args).get(getScalarOutParameterName());
/*     */   }
/*     */ 
/*     */   public <T> T executeObject(Class<T> returnType, SqlParameterSource args)
/*     */   {
/* 169 */     return doExecute(args).get(getScalarOutParameterName());
/*     */   }
/*     */ 
/*     */   public Map<String, Object> execute(Object[] args) {
/* 173 */     return doExecute(args);
/*     */   }
/*     */ 
/*     */   public Map<String, Object> execute(Map<String, ?> args) {
/* 177 */     return doExecute(args);
/*     */   }
/*     */ 
/*     */   public Map<String, Object> execute(SqlParameterSource parameterSource) {
/* 181 */     return doExecute(parameterSource);
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.simple.SimpleJdbcCall
 * JD-Core Version:    0.6.1
 */