/*    */ package org.springframework.jdbc.config;
/*    */ 
/*    */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.xml.AbstractBeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseFactoryBean;
/*    */ import org.springframework.util.StringUtils;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ class EmbeddedDatabaseBeanDefinitionParser extends AbstractBeanDefinitionParser
/*    */ {
/*    */   protected AbstractBeanDefinition parseInternal(Element element, ParserContext parserContext)
/*    */   {
/* 43 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(EmbeddedDatabaseFactoryBean.class);
/* 44 */     setDatabaseType(element, builder);
/* 45 */     DatabasePopulatorConfigUtils.setDatabasePopulator(element, builder);
/* 46 */     useIdAsDatabaseNameIfGiven(element, builder);
/* 47 */     builder.getRawBeanDefinition().setSource(parserContext.extractSource(element));
/* 48 */     return builder.getBeanDefinition();
/*    */   }
/*    */ 
/*    */   private void useIdAsDatabaseNameIfGiven(Element element, BeanDefinitionBuilder builder) {
/* 52 */     String id = element.getAttribute("id");
/* 53 */     if (StringUtils.hasText(id))
/* 54 */       builder.addPropertyValue("databaseName", id);
/*    */   }
/*    */ 
/*    */   private void setDatabaseType(Element element, BeanDefinitionBuilder builder)
/*    */   {
/* 59 */     String type = element.getAttribute("type");
/* 60 */     if (StringUtils.hasText(type))
/* 61 */       builder.addPropertyValue("databaseType", type);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.config.EmbeddedDatabaseBeanDefinitionParser
 * JD-Core Version:    0.6.1
 */