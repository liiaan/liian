package org.springframework.jdbc.core;

public abstract interface ParameterDisposer
{
  public abstract void cleanupParameters();
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.ParameterDisposer
 * JD-Core Version:    0.6.1
 */