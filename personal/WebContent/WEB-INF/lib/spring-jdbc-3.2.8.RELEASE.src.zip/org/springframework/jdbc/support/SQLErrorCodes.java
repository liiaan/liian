/*     */ package org.springframework.jdbc.support;
/*     */ 
/*     */ import org.springframework.util.StringUtils;
/*     */ 
/*     */ public class SQLErrorCodes
/*     */ {
/*     */   private String[] databaseProductNames;
/*  38 */   private boolean useSqlStateForTranslation = false;
/*     */ 
/*  40 */   private String[] badSqlGrammarCodes = new String[0];
/*     */ 
/*  42 */   private String[] invalidResultSetAccessCodes = new String[0];
/*     */ 
/*  44 */   private String[] duplicateKeyCodes = new String[0];
/*     */ 
/*  46 */   private String[] dataIntegrityViolationCodes = new String[0];
/*     */ 
/*  48 */   private String[] permissionDeniedCodes = new String[0];
/*     */ 
/*  50 */   private String[] dataAccessResourceFailureCodes = new String[0];
/*     */ 
/*  52 */   private String[] transientDataAccessResourceCodes = new String[0];
/*     */ 
/*  54 */   private String[] cannotAcquireLockCodes = new String[0];
/*     */ 
/*  56 */   private String[] deadlockLoserCodes = new String[0];
/*     */ 
/*  58 */   private String[] cannotSerializeTransactionCodes = new String[0];
/*     */   private CustomSQLErrorCodesTranslation[] customTranslations;
/*     */   private SQLExceptionTranslator customSqlExceptionTranslator;
/*     */ 
/*     */   public void setDatabaseProductName(String databaseProductName)
/*     */   {
/*  70 */     this.databaseProductNames = new String[] { databaseProductName };
/*     */   }
/*     */ 
/*     */   public String getDatabaseProductName() {
/*  74 */     return (this.databaseProductNames != null) && (this.databaseProductNames.length > 0) ? this.databaseProductNames[0] : null;
/*     */   }
/*     */ 
/*     */   public void setDatabaseProductNames(String[] databaseProductNames)
/*     */   {
/*  83 */     this.databaseProductNames = databaseProductNames;
/*     */   }
/*     */ 
/*     */   public String[] getDatabaseProductNames() {
/*  87 */     return this.databaseProductNames;
/*     */   }
/*     */ 
/*     */   public void setUseSqlStateForTranslation(boolean useStateCodeForTranslation)
/*     */   {
/*  95 */     this.useSqlStateForTranslation = useStateCodeForTranslation;
/*     */   }
/*     */ 
/*     */   public boolean isUseSqlStateForTranslation() {
/*  99 */     return this.useSqlStateForTranslation;
/*     */   }
/*     */ 
/*     */   public void setBadSqlGrammarCodes(String[] badSqlGrammarCodes) {
/* 103 */     this.badSqlGrammarCodes = StringUtils.sortStringArray(badSqlGrammarCodes);
/*     */   }
/*     */ 
/*     */   public String[] getBadSqlGrammarCodes() {
/* 107 */     return this.badSqlGrammarCodes;
/*     */   }
/*     */ 
/*     */   public void setInvalidResultSetAccessCodes(String[] invalidResultSetAccessCodes) {
/* 111 */     this.invalidResultSetAccessCodes = StringUtils.sortStringArray(invalidResultSetAccessCodes);
/*     */   }
/*     */ 
/*     */   public String[] getInvalidResultSetAccessCodes() {
/* 115 */     return this.invalidResultSetAccessCodes;
/*     */   }
/*     */ 
/*     */   public String[] getDuplicateKeyCodes() {
/* 119 */     return this.duplicateKeyCodes;
/*     */   }
/*     */ 
/*     */   public void setDuplicateKeyCodes(String[] duplicateKeyCodes) {
/* 123 */     this.duplicateKeyCodes = duplicateKeyCodes;
/*     */   }
/*     */ 
/*     */   public void setDataIntegrityViolationCodes(String[] dataIntegrityViolationCodes) {
/* 127 */     this.dataIntegrityViolationCodes = StringUtils.sortStringArray(dataIntegrityViolationCodes);
/*     */   }
/*     */ 
/*     */   public String[] getDataIntegrityViolationCodes() {
/* 131 */     return this.dataIntegrityViolationCodes;
/*     */   }
/*     */ 
/*     */   public void setPermissionDeniedCodes(String[] permissionDeniedCodes) {
/* 135 */     this.permissionDeniedCodes = StringUtils.sortStringArray(permissionDeniedCodes);
/*     */   }
/*     */ 
/*     */   public String[] getPermissionDeniedCodes() {
/* 139 */     return this.permissionDeniedCodes;
/*     */   }
/*     */ 
/*     */   public void setDataAccessResourceFailureCodes(String[] dataAccessResourceFailureCodes) {
/* 143 */     this.dataAccessResourceFailureCodes = StringUtils.sortStringArray(dataAccessResourceFailureCodes);
/*     */   }
/*     */ 
/*     */   public String[] getDataAccessResourceFailureCodes() {
/* 147 */     return this.dataAccessResourceFailureCodes;
/*     */   }
/*     */ 
/*     */   public void setTransientDataAccessResourceCodes(String[] transientDataAccessResourceCodes) {
/* 151 */     this.transientDataAccessResourceCodes = StringUtils.sortStringArray(transientDataAccessResourceCodes);
/*     */   }
/*     */ 
/*     */   public String[] getTransientDataAccessResourceCodes() {
/* 155 */     return this.transientDataAccessResourceCodes;
/*     */   }
/*     */ 
/*     */   public void setCannotAcquireLockCodes(String[] cannotAcquireLockCodes) {
/* 159 */     this.cannotAcquireLockCodes = StringUtils.sortStringArray(cannotAcquireLockCodes);
/*     */   }
/*     */ 
/*     */   public String[] getCannotAcquireLockCodes() {
/* 163 */     return this.cannotAcquireLockCodes;
/*     */   }
/*     */ 
/*     */   public void setDeadlockLoserCodes(String[] deadlockLoserCodes) {
/* 167 */     this.deadlockLoserCodes = StringUtils.sortStringArray(deadlockLoserCodes);
/*     */   }
/*     */ 
/*     */   public String[] getDeadlockLoserCodes() {
/* 171 */     return this.deadlockLoserCodes;
/*     */   }
/*     */ 
/*     */   public void setCannotSerializeTransactionCodes(String[] cannotSerializeTransactionCodes) {
/* 175 */     this.cannotSerializeTransactionCodes = StringUtils.sortStringArray(cannotSerializeTransactionCodes);
/*     */   }
/*     */ 
/*     */   public String[] getCannotSerializeTransactionCodes() {
/* 179 */     return this.cannotSerializeTransactionCodes;
/*     */   }
/*     */ 
/*     */   public void setCustomTranslations(CustomSQLErrorCodesTranslation[] customTranslations) {
/* 183 */     this.customTranslations = customTranslations;
/*     */   }
/*     */ 
/*     */   public CustomSQLErrorCodesTranslation[] getCustomTranslations() {
/* 187 */     return this.customTranslations;
/*     */   }
/*     */ 
/*     */   public void setCustomSqlExceptionTranslatorClass(Class<? extends SQLExceptionTranslator> customTranslatorClass) {
/* 191 */     if (customTranslatorClass != null) {
/*     */       try {
/* 193 */         this.customSqlExceptionTranslator = ((SQLExceptionTranslator)customTranslatorClass.newInstance());
/*     */       }
/*     */       catch (Exception ex) {
/* 196 */         throw new IllegalStateException("Unable to instantiate custom translator", ex);
/*     */       }
/*     */     }
/*     */     else
/* 200 */       this.customSqlExceptionTranslator = null;
/*     */   }
/*     */ 
/*     */   public void setCustomSqlExceptionTranslator(SQLExceptionTranslator customSqlExceptionTranslator)
/*     */   {
/* 205 */     this.customSqlExceptionTranslator = customSqlExceptionTranslator;
/*     */   }
/*     */ 
/*     */   public SQLExceptionTranslator getCustomSqlExceptionTranslator() {
/* 209 */     return this.customSqlExceptionTranslator;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.SQLErrorCodes
 * JD-Core Version:    0.6.1
 */