package org.springframework.jdbc.support;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public abstract interface SqlValue
{
  public abstract void setValue(PreparedStatement paramPreparedStatement, int paramInt)
    throws SQLException;

  public abstract void cleanup();
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.SqlValue
 * JD-Core Version:    0.6.1
 */