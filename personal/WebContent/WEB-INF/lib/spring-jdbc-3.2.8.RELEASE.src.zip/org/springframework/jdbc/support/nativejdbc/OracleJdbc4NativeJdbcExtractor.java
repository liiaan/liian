/*    */ package org.springframework.jdbc.support.nativejdbc;
/*    */ 
/*    */ public class OracleJdbc4NativeJdbcExtractor extends Jdbc4NativeJdbcExtractor
/*    */ {
/*    */   public OracleJdbc4NativeJdbcExtractor()
/*    */   {
/*    */     try
/*    */     {
/* 48 */       setConnectionType(getClass().getClassLoader().loadClass("oracle.jdbc.OracleConnection"));
/* 49 */       setStatementType(getClass().getClassLoader().loadClass("oracle.jdbc.OracleStatement"));
/* 50 */       setPreparedStatementType(getClass().getClassLoader().loadClass("oracle.jdbc.OraclePreparedStatement"));
/* 51 */       setCallableStatementType(getClass().getClassLoader().loadClass("oracle.jdbc.OracleCallableStatement"));
/* 52 */       setResultSetType(getClass().getClassLoader().loadClass("oracle.jdbc.OracleResultSet"));
/*    */     }
/*    */     catch (Exception ex) {
/* 55 */       throw new IllegalStateException("Could not initialize OracleJdbc4NativeJdbcExtractor because Oracle API classes are not available: " + ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.nativejdbc.OracleJdbc4NativeJdbcExtractor
 * JD-Core Version:    0.6.1
 */