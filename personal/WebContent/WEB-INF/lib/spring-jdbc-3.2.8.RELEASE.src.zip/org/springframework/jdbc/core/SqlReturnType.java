package org.springframework.jdbc.core;

import java.sql.CallableStatement;
import java.sql.SQLException;

public abstract interface SqlReturnType
{
  public static final int TYPE_UNKNOWN = -2147483648;

  public abstract Object getTypeValue(CallableStatement paramCallableStatement, int paramInt1, int paramInt2, String paramString)
    throws SQLException;
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.SqlReturnType
 * JD-Core Version:    0.6.1
 */