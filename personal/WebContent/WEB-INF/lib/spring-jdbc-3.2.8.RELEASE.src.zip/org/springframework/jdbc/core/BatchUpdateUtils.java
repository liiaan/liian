/*    */ package org.springframework.jdbc.core;
/*    */ 
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.SQLException;
/*    */ import java.util.List;
/*    */ 
/*    */ public abstract class BatchUpdateUtils
/*    */ {
/*    */   public static int[] executeBatchUpdate(String sql, List<Object[]> batchValues, final int[] columnTypes, JdbcOperations jdbcOperations)
/*    */   {
/* 32 */     return jdbcOperations.batchUpdate(sql, new BatchPreparedStatementSetter()
/*    */     {
/*    */       public void setValues(PreparedStatement ps, int i)
/*    */         throws SQLException
/*    */       {
/* 37 */         Object[] values = (Object[])this.val$batchValues.get(i);
/* 38 */         BatchUpdateUtils.setStatementParameters(values, ps, columnTypes);
/*    */       }
/*    */ 
/*    */       public int getBatchSize() {
/* 42 */         return this.val$batchValues.size();
/*    */       }
/*    */     });
/*    */   }
/*    */ 
/*    */   protected static void setStatementParameters(Object[] values, PreparedStatement ps, int[] columnTypes) throws SQLException {
/* 48 */     int colIndex = 0;
/* 49 */     for (Object value : values) {
/* 50 */       colIndex++;
/* 51 */       if ((value instanceof SqlParameterValue)) {
/* 52 */         SqlParameterValue paramValue = (SqlParameterValue)value;
/* 53 */         StatementCreatorUtils.setParameterValue(ps, colIndex, paramValue, paramValue.getValue());
/*    */       }
/*    */       else
/*    */       {
/*    */         int colType;
/*    */         int colType;
/* 57 */         if ((columnTypes == null) || (columnTypes.length < colIndex)) {
/* 58 */           colType = -2147483648;
/*    */         }
/*    */         else {
/* 61 */           colType = columnTypes[(colIndex - 1)];
/*    */         }
/* 63 */         StatementCreatorUtils.setParameterValue(ps, colIndex, colType, value);
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.BatchUpdateUtils
 * JD-Core Version:    0.6.1
 */