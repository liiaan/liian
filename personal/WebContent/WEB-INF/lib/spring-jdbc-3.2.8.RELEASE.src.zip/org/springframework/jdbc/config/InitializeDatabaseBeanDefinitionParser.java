/*    */ package org.springframework.jdbc.config;
/*    */ 
/*    */ import org.springframework.beans.factory.support.AbstractBeanDefinition;
/*    */ import org.springframework.beans.factory.support.BeanDefinitionBuilder;
/*    */ import org.springframework.beans.factory.xml.AbstractBeanDefinitionParser;
/*    */ import org.springframework.beans.factory.xml.ParserContext;
/*    */ import org.springframework.jdbc.datasource.init.DataSourceInitializer;
/*    */ import org.w3c.dom.Element;
/*    */ 
/*    */ class InitializeDatabaseBeanDefinitionParser extends AbstractBeanDefinitionParser
/*    */ {
/*    */   protected AbstractBeanDefinition parseInternal(Element element, ParserContext parserContext)
/*    */   {
/* 42 */     BeanDefinitionBuilder builder = BeanDefinitionBuilder.genericBeanDefinition(DataSourceInitializer.class);
/* 43 */     builder.addPropertyReference("dataSource", element.getAttribute("data-source"));
/* 44 */     builder.addPropertyValue("enabled", element.getAttribute("enabled"));
/* 45 */     DatabasePopulatorConfigUtils.setDatabasePopulator(element, builder);
/* 46 */     builder.getRawBeanDefinition().setSource(parserContext.extractSource(element));
/* 47 */     return builder.getBeanDefinition();
/*    */   }
/*    */ 
/*    */   protected boolean shouldGenerateId()
/*    */   {
/* 52 */     return true;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.config.InitializeDatabaseBeanDefinitionParser
 * JD-Core Version:    0.6.1
 */