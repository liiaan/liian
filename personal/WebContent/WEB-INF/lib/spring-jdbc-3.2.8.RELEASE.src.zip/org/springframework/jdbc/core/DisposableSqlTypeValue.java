package org.springframework.jdbc.core;

public abstract interface DisposableSqlTypeValue extends SqlTypeValue
{
  public abstract void cleanup();
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.DisposableSqlTypeValue
 * JD-Core Version:    0.6.1
 */