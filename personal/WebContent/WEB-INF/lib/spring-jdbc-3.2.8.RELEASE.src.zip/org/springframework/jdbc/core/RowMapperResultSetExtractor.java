/*    */ package org.springframework.jdbc.core;
/*    */ 
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class RowMapperResultSetExtractor<T>
/*    */   implements ResultSetExtractor<List<T>>
/*    */ {
/*    */   private final RowMapper<T> rowMapper;
/*    */   private final int rowsExpected;
/*    */ 
/*    */   public RowMapperResultSetExtractor(RowMapper<T> rowMapper)
/*    */   {
/* 72 */     this(rowMapper, 0);
/*    */   }
/*    */ 
/*    */   public RowMapperResultSetExtractor(RowMapper<T> rowMapper, int rowsExpected)
/*    */   {
/* 82 */     Assert.notNull(rowMapper, "RowMapper is required");
/* 83 */     this.rowMapper = rowMapper;
/* 84 */     this.rowsExpected = rowsExpected;
/*    */   }
/*    */ 
/*    */   public List<T> extractData(ResultSet rs) throws SQLException
/*    */   {
/* 89 */     List results = this.rowsExpected > 0 ? new ArrayList(this.rowsExpected) : new ArrayList();
/* 90 */     int rowNum = 0;
/* 91 */     while (rs.next()) {
/* 92 */       results.add(this.rowMapper.mapRow(rs, rowNum++));
/*    */     }
/* 94 */     return results;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.RowMapperResultSetExtractor
 * JD-Core Version:    0.6.1
 */