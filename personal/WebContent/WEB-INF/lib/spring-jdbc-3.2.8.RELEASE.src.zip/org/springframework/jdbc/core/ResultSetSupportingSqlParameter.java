/*     */ package org.springframework.jdbc.core;
/*     */ 
/*     */ public class ResultSetSupportingSqlParameter extends SqlParameter
/*     */ {
/*     */   private ResultSetExtractor resultSetExtractor;
/*     */   private RowCallbackHandler rowCallbackHandler;
/*     */   private RowMapper rowMapper;
/*     */ 
/*     */   public ResultSetSupportingSqlParameter(String name, int sqlType)
/*     */   {
/*  41 */     super(name, sqlType);
/*     */   }
/*     */ 
/*     */   public ResultSetSupportingSqlParameter(String name, int sqlType, int scale)
/*     */   {
/*  52 */     super(name, sqlType, scale);
/*     */   }
/*     */ 
/*     */   public ResultSetSupportingSqlParameter(String name, int sqlType, String typeName)
/*     */   {
/*  62 */     super(name, sqlType, typeName);
/*     */   }
/*     */ 
/*     */   public ResultSetSupportingSqlParameter(String name, int sqlType, ResultSetExtractor rse)
/*     */   {
/*  72 */     super(name, sqlType);
/*  73 */     this.resultSetExtractor = rse;
/*     */   }
/*     */ 
/*     */   public ResultSetSupportingSqlParameter(String name, int sqlType, RowCallbackHandler rch)
/*     */   {
/*  83 */     super(name, sqlType);
/*  84 */     this.rowCallbackHandler = rch;
/*     */   }
/*     */ 
/*     */   public ResultSetSupportingSqlParameter(String name, int sqlType, RowMapper rm)
/*     */   {
/*  94 */     super(name, sqlType);
/*  95 */     this.rowMapper = rm;
/*     */   }
/*     */ 
/*     */   public boolean isResultSetSupported()
/*     */   {
/* 104 */     return (this.resultSetExtractor != null) || (this.rowCallbackHandler != null) || (this.rowMapper != null);
/*     */   }
/*     */ 
/*     */   public ResultSetExtractor getResultSetExtractor()
/*     */   {
/* 111 */     return this.resultSetExtractor;
/*     */   }
/*     */ 
/*     */   public RowCallbackHandler getRowCallbackHandler()
/*     */   {
/* 118 */     return this.rowCallbackHandler;
/*     */   }
/*     */ 
/*     */   public RowMapper getRowMapper()
/*     */   {
/* 125 */     return this.rowMapper;
/*     */   }
/*     */ 
/*     */   public boolean isInputValueProvided()
/*     */   {
/* 134 */     return false;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.ResultSetSupportingSqlParameter
 * JD-Core Version:    0.6.1
 */