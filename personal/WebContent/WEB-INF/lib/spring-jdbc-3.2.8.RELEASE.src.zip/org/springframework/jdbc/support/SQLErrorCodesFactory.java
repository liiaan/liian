/*     */ package org.springframework.jdbc.support;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.BeansException;
/*     */ import org.springframework.beans.factory.support.DefaultListableBeanFactory;
/*     */ import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
/*     */ import org.springframework.core.io.ClassPathResource;
/*     */ import org.springframework.core.io.Resource;
/*     */ import org.springframework.util.Assert;
/*     */ import org.springframework.util.PatternMatchUtils;
/*     */ 
/*     */ public class SQLErrorCodesFactory
/*     */ {
/*     */   public static final String SQL_ERROR_CODE_OVERRIDE_PATH = "sql-error-codes.xml";
/*     */   public static final String SQL_ERROR_CODE_DEFAULT_PATH = "org/springframework/jdbc/support/sql-error-codes.xml";
/*  63 */   private static final Log logger = LogFactory.getLog(SQLErrorCodesFactory.class);
/*     */ 
/*  68 */   private static final SQLErrorCodesFactory instance = new SQLErrorCodesFactory();
/*     */   private final Map<String, SQLErrorCodes> errorCodesMap;
/*  88 */   private final Map<DataSource, SQLErrorCodes> dataSourceCache = new WeakHashMap(16);
/*     */ 
/*     */   public static SQLErrorCodesFactory getInstance()
/*     */   {
/*  75 */     return instance;
/*     */   }
/*     */ 
/*     */   protected SQLErrorCodesFactory()
/*     */   {
/*     */     Map errorCodes;
/*     */     try
/*     */     {
/* 103 */       DefaultListableBeanFactory lbf = new DefaultListableBeanFactory();
/* 104 */       lbf.setBeanClassLoader(getClass().getClassLoader());
/* 105 */       XmlBeanDefinitionReader bdr = new XmlBeanDefinitionReader(lbf);
/*     */ 
/* 108 */       Resource resource = loadResource("org/springframework/jdbc/support/sql-error-codes.xml");
/* 109 */       if ((resource != null) && (resource.exists())) {
/* 110 */         bdr.loadBeanDefinitions(resource);
/*     */       }
/*     */       else {
/* 113 */         logger.warn("Default sql-error-codes.xml not found (should be included in spring.jar)");
/*     */       }
/*     */ 
/* 117 */       resource = loadResource("sql-error-codes.xml");
/* 118 */       if ((resource != null) && (resource.exists())) {
/* 119 */         bdr.loadBeanDefinitions(resource);
/* 120 */         logger.info("Found custom sql-error-codes.xml file at the root of the classpath");
/*     */       }
/*     */ 
/* 124 */       errorCodes = lbf.getBeansOfType(SQLErrorCodes.class, true, false);
/* 125 */       if (logger.isInfoEnabled())
/* 126 */         logger.info("SQLErrorCodes loaded: " + errorCodes.keySet());
/*     */     }
/*     */     catch (BeansException ex)
/*     */     {
/* 130 */       logger.warn("Error loading SQL error codes from config file", ex);
/* 131 */       errorCodes = Collections.emptyMap();
/*     */     }
/*     */ 
/* 134 */     this.errorCodesMap = errorCodes;
/*     */   }
/*     */ 
/*     */   protected Resource loadResource(String path)
/*     */   {
/* 149 */     return new ClassPathResource(path, getClass().getClassLoader());
/*     */   }
/*     */ 
/*     */   public SQLErrorCodes getErrorCodes(String dbName)
/*     */   {
/* 161 */     Assert.notNull(dbName, "Database product name must not be null");
/*     */ 
/* 163 */     SQLErrorCodes sec = (SQLErrorCodes)this.errorCodesMap.get(dbName);
/* 164 */     if (sec == null) {
/* 165 */       for (SQLErrorCodes candidate : this.errorCodesMap.values()) {
/* 166 */         if (PatternMatchUtils.simpleMatch(candidate.getDatabaseProductNames(), dbName)) {
/* 167 */           sec = candidate;
/* 168 */           break;
/*     */         }
/*     */       }
/*     */     }
/* 172 */     if (sec != null) {
/* 173 */       checkCustomTranslatorRegistry(dbName, sec);
/* 174 */       if (logger.isDebugEnabled()) {
/* 175 */         logger.debug("SQL error codes for '" + dbName + "' found");
/*     */       }
/* 177 */       return sec;
/*     */     }
/*     */ 
/* 181 */     if (logger.isDebugEnabled()) {
/* 182 */       logger.debug("SQL error codes for '" + dbName + "' not found");
/*     */     }
/* 184 */     return new SQLErrorCodes();
/*     */   }
/*     */ 
/*     */   public SQLErrorCodes getErrorCodes(DataSource dataSource)
/*     */   {
/* 197 */     Assert.notNull(dataSource, "DataSource must not be null");
/* 198 */     if (logger.isDebugEnabled()) {
/* 199 */       logger.debug("Looking up default SQLErrorCodes for DataSource [" + dataSource + "]");
/*     */     }
/*     */ 
/* 202 */     synchronized (this.dataSourceCache)
/*     */     {
/* 204 */       SQLErrorCodes sec = (SQLErrorCodes)this.dataSourceCache.get(dataSource);
/* 205 */       if (sec != null) {
/* 206 */         if (logger.isDebugEnabled()) {
/* 207 */           logger.debug("SQLErrorCodes found in cache for DataSource [" + dataSource.getClass().getName() + '@' + Integer.toHexString(dataSource.hashCode()) + "]");
/*     */         }
/*     */ 
/* 210 */         return sec;
/*     */       }
/*     */       try
/*     */       {
/* 214 */         String dbName = (String)JdbcUtils.extractDatabaseMetaData(dataSource, "getDatabaseProductName");
/* 215 */         if (dbName != null) {
/* 216 */           if (logger.isDebugEnabled()) {
/* 217 */             logger.debug("Database product name cached for DataSource [" + dataSource.getClass().getName() + '@' + Integer.toHexString(dataSource.hashCode()) + "]: name is '" + dbName + "'");
/*     */           }
/*     */ 
/* 221 */           sec = getErrorCodes(dbName);
/* 222 */           this.dataSourceCache.put(dataSource, sec);
/* 223 */           return sec;
/*     */         }
/*     */       }
/*     */       catch (MetaDataAccessException ex) {
/* 227 */         logger.warn("Error while extracting database product name - falling back to empty error codes", ex);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 232 */     return new SQLErrorCodes();
/*     */   }
/*     */ 
/*     */   public SQLErrorCodes registerDatabase(DataSource dataSource, String dbName)
/*     */   {
/* 243 */     synchronized (this.dataSourceCache) {
/* 244 */       SQLErrorCodes sec = getErrorCodes(dbName);
/* 245 */       this.dataSourceCache.put(dataSource, sec);
/* 246 */       return sec;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkCustomTranslatorRegistry(String dbName, SQLErrorCodes dbCodes)
/*     */   {
/* 254 */     SQLExceptionTranslator customTranslator = CustomSQLExceptionTranslatorRegistry.getInstance().findTranslatorForDatabase(dbName);
/*     */ 
/* 256 */     if (customTranslator != null) {
/* 257 */       if (dbCodes.getCustomSqlExceptionTranslator() != null) {
/* 258 */         logger.warn("Overriding already defined custom translator '" + dbCodes.getCustomSqlExceptionTranslator().getClass().getSimpleName() + " with '" + customTranslator.getClass().getSimpleName() + "' found in the CustomSQLExceptionTranslatorRegistry for database " + dbName);
/*     */       }
/*     */       else
/*     */       {
/* 264 */         logger.info("Using custom translator '" + customTranslator.getClass().getSimpleName() + "' found in the CustomSQLExceptionTranslatorRegistry for database " + dbName);
/*     */       }
/*     */ 
/* 267 */       dbCodes.setCustomSqlExceptionTranslator(customTranslator);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.SQLErrorCodesFactory
 * JD-Core Version:    0.6.1
 */