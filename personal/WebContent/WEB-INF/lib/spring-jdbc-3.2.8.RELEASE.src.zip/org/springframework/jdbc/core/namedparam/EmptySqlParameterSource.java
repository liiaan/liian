/*    */ package org.springframework.jdbc.core.namedparam;
/*    */ 
/*    */ public class EmptySqlParameterSource
/*    */   implements SqlParameterSource
/*    */ {
/* 30 */   public static final EmptySqlParameterSource INSTANCE = new EmptySqlParameterSource();
/*    */ 
/*    */   public boolean hasValue(String paramName)
/*    */   {
/* 34 */     return false;
/*    */   }
/*    */ 
/*    */   public Object getValue(String paramName) throws IllegalArgumentException {
/* 38 */     throw new IllegalArgumentException("This SqlParameterSource is empty");
/*    */   }
/*    */ 
/*    */   public int getSqlType(String paramName) {
/* 42 */     return -2147483648;
/*    */   }
/*    */ 
/*    */   public String getTypeName(String paramName) {
/* 46 */     return null;
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.namedparam.EmptySqlParameterSource
 * JD-Core Version:    0.6.1
 */