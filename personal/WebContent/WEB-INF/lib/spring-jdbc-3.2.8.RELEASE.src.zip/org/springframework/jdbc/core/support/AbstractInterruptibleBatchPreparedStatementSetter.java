/*    */ package org.springframework.jdbc.core.support;
/*    */ 
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.jdbc.core.InterruptibleBatchPreparedStatementSetter;
/*    */ 
/*    */ public abstract class AbstractInterruptibleBatchPreparedStatementSetter
/*    */   implements InterruptibleBatchPreparedStatementSetter
/*    */ {
/*    */   private boolean exhausted;
/*    */ 
/*    */   public final void setValues(PreparedStatement ps, int i)
/*    */     throws SQLException
/*    */   {
/* 44 */     this.exhausted = (!setValuesIfAvailable(ps, i));
/*    */   }
/*    */ 
/*    */   public final boolean isBatchExhausted(int i)
/*    */   {
/* 51 */     return this.exhausted;
/*    */   }
/*    */ 
/*    */   public int getBatchSize()
/*    */   {
/* 59 */     return 2147483647;
/*    */   }
/*    */ 
/*    */   protected abstract boolean setValuesIfAvailable(PreparedStatement paramPreparedStatement, int paramInt)
/*    */     throws SQLException;
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.support.AbstractInterruptibleBatchPreparedStatementSetter
 * JD-Core Version:    0.6.1
 */