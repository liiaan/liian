package org.springframework.jdbc.core;

import java.sql.Connection;
import java.sql.SQLException;
import org.springframework.dao.DataAccessException;

public abstract interface ConnectionCallback<T>
{
  public abstract T doInConnection(Connection paramConnection)
    throws SQLException, DataAccessException;
}

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.ConnectionCallback
 * JD-Core Version:    0.6.1
 */