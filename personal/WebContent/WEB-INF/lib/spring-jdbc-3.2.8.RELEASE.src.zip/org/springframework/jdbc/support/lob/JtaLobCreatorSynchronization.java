/*    */ package org.springframework.jdbc.support.lob;
/*    */ 
/*    */ import javax.transaction.Synchronization;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class JtaLobCreatorSynchronization
/*    */   implements Synchronization
/*    */ {
/*    */   private final LobCreator lobCreator;
/* 37 */   private boolean beforeCompletionCalled = false;
/*    */ 
/*    */   public JtaLobCreatorSynchronization(LobCreator lobCreator)
/*    */   {
/* 45 */     Assert.notNull(lobCreator, "LobCreator must not be null");
/* 46 */     this.lobCreator = lobCreator;
/*    */   }
/*    */ 
/*    */   public void beforeCompletion()
/*    */   {
/* 53 */     this.beforeCompletionCalled = true;
/* 54 */     this.lobCreator.close();
/*    */   }
/*    */ 
/*    */   public void afterCompletion(int status) {
/* 58 */     if (!this.beforeCompletionCalled)
/*    */     {
/* 61 */       this.lobCreator.close();
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.lob.JtaLobCreatorSynchronization
 * JD-Core Version:    0.6.1
 */