/*    */ package org.springframework.jdbc.datasource.init;
/*    */ 
/*    */ import org.springframework.core.io.support.EncodedResource;
/*    */ 
/*    */ public class CannotReadScriptException extends RuntimeException
/*    */ {
/*    */   public CannotReadScriptException(EncodedResource resource, Throwable cause)
/*    */   {
/* 37 */     super("Cannot read SQL script from " + resource, cause);
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.init.CannotReadScriptException
 * JD-Core Version:    0.6.1
 */