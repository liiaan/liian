/*    */ package org.springframework.jdbc.datasource.lookup;
/*    */ 
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.beans.BeansException;
/*    */ import org.springframework.beans.factory.BeanFactory;
/*    */ import org.springframework.beans.factory.BeanFactoryAware;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public class BeanFactoryDataSourceLookup
/*    */   implements DataSourceLookup, BeanFactoryAware
/*    */ {
/*    */   private BeanFactory beanFactory;
/*    */ 
/*    */   public BeanFactoryDataSourceLookup()
/*    */   {
/*    */   }
/*    */ 
/*    */   public BeanFactoryDataSourceLookup(BeanFactory beanFactory)
/*    */   {
/* 60 */     Assert.notNull(beanFactory, "BeanFactory is required");
/* 61 */     this.beanFactory = beanFactory;
/*    */   }
/*    */ 
/*    */   public void setBeanFactory(BeanFactory beanFactory)
/*    */   {
/* 66 */     this.beanFactory = beanFactory;
/*    */   }
/*    */ 
/*    */   public DataSource getDataSource(String dataSourceName) throws DataSourceLookupFailureException
/*    */   {
/* 71 */     Assert.state(this.beanFactory != null, "BeanFactory is required");
/*    */     try {
/* 73 */       return (DataSource)this.beanFactory.getBean(dataSourceName, DataSource.class);
/*    */     }
/*    */     catch (BeansException ex) {
/* 76 */       throw new DataSourceLookupFailureException("Failed to look up DataSource bean with name '" + dataSourceName + "'", ex);
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.lookup.BeanFactoryDataSourceLookup
 * JD-Core Version:    0.6.1
 */