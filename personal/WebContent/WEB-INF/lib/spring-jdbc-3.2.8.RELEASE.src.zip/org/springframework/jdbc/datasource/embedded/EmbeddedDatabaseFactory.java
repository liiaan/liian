/*     */ package org.springframework.jdbc.datasource.embedded;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.util.logging.Logger;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.jdbc.datasource.init.DatabasePopulator;
/*     */ import org.springframework.jdbc.datasource.init.DatabasePopulatorUtils;
/*     */ import org.springframework.util.Assert;
/*     */ 
/*     */ public class EmbeddedDatabaseFactory
/*     */ {
/*  50 */   private static Log logger = LogFactory.getLog(EmbeddedDatabaseFactory.class);
/*     */   private String databaseName;
/*     */   private DataSourceFactory dataSourceFactory;
/*     */   private EmbeddedDatabaseConfigurer databaseConfigurer;
/*     */   private DatabasePopulator databasePopulator;
/*     */   private DataSource dataSource;
/*     */ 
/*     */   public EmbeddedDatabaseFactory()
/*     */   {
/*  52 */     this.databaseName = "testdb";
/*     */ 
/*  54 */     this.dataSourceFactory = new SimpleDriverDataSourceFactory();
/*     */   }
/*     */ 
/*     */   public void setDatabaseName(String databaseName)
/*     */   {
/*  68 */     Assert.notNull(databaseName, "Database name is required");
/*  69 */     this.databaseName = databaseName;
/*     */   }
/*     */ 
/*     */   public void setDataSourceFactory(DataSourceFactory dataSourceFactory)
/*     */   {
/*  77 */     Assert.notNull(dataSourceFactory, "DataSourceFactory is required");
/*  78 */     this.dataSourceFactory = dataSourceFactory;
/*     */   }
/*     */ 
/*     */   public void setDatabaseType(EmbeddedDatabaseType type)
/*     */   {
/*  87 */     this.databaseConfigurer = EmbeddedDatabaseConfigurerFactory.getConfigurer(type);
/*     */   }
/*     */ 
/*     */   public void setDatabaseConfigurer(EmbeddedDatabaseConfigurer configurer)
/*     */   {
/*  95 */     this.databaseConfigurer = configurer;
/*     */   }
/*     */ 
/*     */   public void setDatabasePopulator(DatabasePopulator populator)
/*     */   {
/* 103 */     this.databasePopulator = populator;
/*     */   }
/*     */ 
/*     */   public EmbeddedDatabase getDatabase()
/*     */   {
/* 110 */     if (this.dataSource == null) {
/* 111 */       initDatabase();
/*     */     }
/* 113 */     return new EmbeddedDataSourceProxy(this.dataSource);
/*     */   }
/*     */ 
/*     */   protected void initDatabase()
/*     */   {
/* 123 */     if (logger.isInfoEnabled()) {
/* 124 */       logger.info("Creating embedded database '" + this.databaseName + "'");
/*     */     }
/* 126 */     if (this.databaseConfigurer == null) {
/* 127 */       this.databaseConfigurer = EmbeddedDatabaseConfigurerFactory.getConfigurer(EmbeddedDatabaseType.HSQL);
/*     */     }
/* 129 */     this.databaseConfigurer.configureConnectionProperties(this.dataSourceFactory.getConnectionProperties(), this.databaseName);
/*     */ 
/* 131 */     this.dataSource = this.dataSourceFactory.getDataSource();
/*     */ 
/* 134 */     if (this.databasePopulator != null)
/*     */       try {
/* 136 */         DatabasePopulatorUtils.execute(this.databasePopulator, this.dataSource);
/*     */       }
/*     */       catch (RuntimeException ex)
/*     */       {
/* 140 */         shutdownDatabase();
/* 141 */         throw ex;
/*     */       }
/*     */   }
/*     */ 
/*     */   protected void shutdownDatabase()
/*     */   {
/* 151 */     if (this.dataSource != null) {
/* 152 */       this.databaseConfigurer.shutdown(this.dataSource, this.databaseName);
/* 153 */       this.dataSource = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected final DataSource getDataSource()
/*     */   {
/* 163 */     return this.dataSource;
/*     */   }
/*     */ 
/*     */   private class EmbeddedDataSourceProxy implements EmbeddedDatabase
/*     */   {
/*     */     private final DataSource dataSource;
/*     */ 
/*     */     public EmbeddedDataSourceProxy(DataSource dataSource)
/*     */     {
/* 172 */       this.dataSource = dataSource;
/*     */     }
/*     */ 
/*     */     public Connection getConnection() throws SQLException {
/* 176 */       return this.dataSource.getConnection();
/*     */     }
/*     */ 
/*     */     public Connection getConnection(String username, String password) throws SQLException {
/* 180 */       return this.dataSource.getConnection(username, password);
/*     */     }
/*     */ 
/*     */     public PrintWriter getLogWriter() throws SQLException {
/* 184 */       return this.dataSource.getLogWriter();
/*     */     }
/*     */ 
/*     */     public void setLogWriter(PrintWriter out) throws SQLException {
/* 188 */       this.dataSource.setLogWriter(out);
/*     */     }
/*     */ 
/*     */     public int getLoginTimeout() throws SQLException {
/* 192 */       return this.dataSource.getLoginTimeout();
/*     */     }
/*     */ 
/*     */     public void setLoginTimeout(int seconds) throws SQLException {
/* 196 */       this.dataSource.setLoginTimeout(seconds);
/*     */     }
/*     */ 
/*     */     public <T> T unwrap(Class<T> iface) throws SQLException {
/* 200 */       return this.dataSource.unwrap(iface);
/*     */     }
/*     */ 
/*     */     public boolean isWrapperFor(Class<?> iface) throws SQLException {
/* 204 */       return this.dataSource.isWrapperFor(iface);
/*     */     }
/*     */ 
/*     */     public Logger getParentLogger()
/*     */     {
/* 209 */       return Logger.getLogger("global");
/*     */     }
/*     */ 
/*     */     public void shutdown() {
/* 213 */       EmbeddedDatabaseFactory.this.shutdownDatabase();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseFactory
 * JD-Core Version:    0.6.1
 */