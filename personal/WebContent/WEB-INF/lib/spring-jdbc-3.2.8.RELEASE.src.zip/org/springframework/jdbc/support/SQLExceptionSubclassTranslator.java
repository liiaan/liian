/*     */ package org.springframework.jdbc.support;
/*     */ 
/*     */ import java.sql.SQLDataException;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLFeatureNotSupportedException;
/*     */ import java.sql.SQLIntegrityConstraintViolationException;
/*     */ import java.sql.SQLInvalidAuthorizationSpecException;
/*     */ import java.sql.SQLNonTransientConnectionException;
/*     */ import java.sql.SQLNonTransientException;
/*     */ import java.sql.SQLRecoverableException;
/*     */ import java.sql.SQLSyntaxErrorException;
/*     */ import java.sql.SQLTimeoutException;
/*     */ import java.sql.SQLTransactionRollbackException;
/*     */ import java.sql.SQLTransientConnectionException;
/*     */ import java.sql.SQLTransientException;
/*     */ import org.springframework.dao.ConcurrencyFailureException;
/*     */ import org.springframework.dao.DataAccessException;
/*     */ import org.springframework.dao.DataAccessResourceFailureException;
/*     */ import org.springframework.dao.DataIntegrityViolationException;
/*     */ import org.springframework.dao.InvalidDataAccessApiUsageException;
/*     */ import org.springframework.dao.PermissionDeniedDataAccessException;
/*     */ import org.springframework.dao.QueryTimeoutException;
/*     */ import org.springframework.dao.RecoverableDataAccessException;
/*     */ import org.springframework.dao.TransientDataAccessResourceException;
/*     */ import org.springframework.jdbc.BadSqlGrammarException;
/*     */ 
/*     */ public class SQLExceptionSubclassTranslator extends AbstractFallbackSQLExceptionTranslator
/*     */ {
/*     */   public SQLExceptionSubclassTranslator()
/*     */   {
/*  62 */     setFallbackTranslator(new SQLStateSQLExceptionTranslator());
/*     */   }
/*     */ 
/*     */   protected DataAccessException doTranslate(String task, String sql, SQLException ex)
/*     */   {
/*  67 */     if ((ex instanceof SQLTransientException)) {
/*  68 */       if ((ex instanceof SQLTransactionRollbackException)) {
/*  69 */         return new ConcurrencyFailureException(buildMessage(task, sql, ex), ex);
/*     */       }
/*  71 */       if ((ex instanceof SQLTransientConnectionException)) {
/*  72 */         return new TransientDataAccessResourceException(buildMessage(task, sql, ex), ex);
/*     */       }
/*  74 */       if ((ex instanceof SQLTimeoutException)) {
/*  75 */         return new QueryTimeoutException(buildMessage(task, sql, ex), ex);
/*     */       }
/*     */     }
/*  78 */     else if ((ex instanceof SQLNonTransientException)) {
/*  79 */       if ((ex instanceof SQLDataException)) {
/*  80 */         return new DataIntegrityViolationException(buildMessage(task, sql, ex), ex);
/*     */       }
/*  82 */       if ((ex instanceof SQLFeatureNotSupportedException)) {
/*  83 */         return new InvalidDataAccessApiUsageException(buildMessage(task, sql, ex), ex);
/*     */       }
/*  85 */       if ((ex instanceof SQLIntegrityConstraintViolationException)) {
/*  86 */         return new DataIntegrityViolationException(buildMessage(task, sql, ex), ex);
/*     */       }
/*  88 */       if ((ex instanceof SQLInvalidAuthorizationSpecException)) {
/*  89 */         return new PermissionDeniedDataAccessException(buildMessage(task, sql, ex), ex);
/*     */       }
/*  91 */       if ((ex instanceof SQLNonTransientConnectionException)) {
/*  92 */         return new DataAccessResourceFailureException(buildMessage(task, sql, ex), ex);
/*     */       }
/*  94 */       if ((ex instanceof SQLSyntaxErrorException)) {
/*  95 */         return new BadSqlGrammarException(task, sql, ex);
/*     */       }
/*     */     }
/*  98 */     else if ((ex instanceof SQLRecoverableException)) {
/*  99 */       return new RecoverableDataAccessException(buildMessage(task, sql, ex), ex);
/*     */     }
/*     */ 
/* 103 */     return null;
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.SQLExceptionSubclassTranslator
 * JD-Core Version:    0.6.1
 */