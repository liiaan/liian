/*     */ package org.springframework.jdbc.support;
/*     */ 
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.beans.factory.InitializingBean;
/*     */ 
/*     */ public abstract class JdbcAccessor
/*     */   implements InitializingBean
/*     */ {
/*  41 */   protected final Log logger = LogFactory.getLog(getClass());
/*     */   private DataSource dataSource;
/*     */   private SQLExceptionTranslator exceptionTranslator;
/*  47 */   private boolean lazyInit = true;
/*     */ 
/*     */   public void setDataSource(DataSource dataSource)
/*     */   {
/*  54 */     this.dataSource = dataSource;
/*     */   }
/*     */ 
/*     */   public DataSource getDataSource()
/*     */   {
/*  61 */     return this.dataSource;
/*     */   }
/*     */ 
/*     */   public void setDatabaseProductName(String dbName)
/*     */   {
/*  73 */     this.exceptionTranslator = new SQLErrorCodeSQLExceptionTranslator(dbName);
/*     */   }
/*     */ 
/*     */   public void setExceptionTranslator(SQLExceptionTranslator exceptionTranslator)
/*     */   {
/*  85 */     this.exceptionTranslator = exceptionTranslator;
/*     */   }
/*     */ 
/*     */   public synchronized SQLExceptionTranslator getExceptionTranslator()
/*     */   {
/*  96 */     if (this.exceptionTranslator == null) {
/*  97 */       DataSource dataSource = getDataSource();
/*  98 */       if (dataSource != null) {
/*  99 */         this.exceptionTranslator = new SQLErrorCodeSQLExceptionTranslator(dataSource);
/*     */       }
/*     */       else {
/* 102 */         this.exceptionTranslator = new SQLStateSQLExceptionTranslator();
/*     */       }
/*     */     }
/* 105 */     return this.exceptionTranslator;
/*     */   }
/*     */ 
/*     */   public void setLazyInit(boolean lazyInit)
/*     */   {
/* 117 */     this.lazyInit = lazyInit;
/*     */   }
/*     */ 
/*     */   public boolean isLazyInit()
/*     */   {
/* 125 */     return this.lazyInit;
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 133 */     if (getDataSource() == null) {
/* 134 */       throw new IllegalArgumentException("Property 'dataSource' is required");
/*     */     }
/* 136 */     if (!isLazyInit())
/* 137 */       getExceptionTranslator();
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.JdbcAccessor
 * JD-Core Version:    0.6.1
 */