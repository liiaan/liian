/*    */ package org.springframework.jdbc.support.incrementer;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.SQLException;
/*    */ import java.sql.Statement;
/*    */ import javax.sql.DataSource;
/*    */ import org.springframework.dao.DataAccessException;
/*    */ import org.springframework.dao.DataAccessResourceFailureException;
/*    */ import org.springframework.jdbc.datasource.DataSourceUtils;
/*    */ import org.springframework.jdbc.support.JdbcUtils;
/*    */ 
/*    */ public abstract class AbstractSequenceMaxValueIncrementer extends AbstractDataFieldMaxValueIncrementer
/*    */ {
/*    */   public AbstractSequenceMaxValueIncrementer()
/*    */   {
/*    */   }
/*    */ 
/*    */   public AbstractSequenceMaxValueIncrementer(DataSource dataSource, String incrementerName)
/*    */   {
/* 55 */     super(dataSource, incrementerName);
/*    */   }
/*    */ 
/*    */   protected long getNextKey()
/*    */     throws DataAccessException
/*    */   {
/* 64 */     Connection con = DataSourceUtils.getConnection(getDataSource());
/* 65 */     Statement stmt = null;
/* 66 */     ResultSet rs = null;
/*    */     try {
/* 68 */       stmt = con.createStatement();
/* 69 */       DataSourceUtils.applyTransactionTimeout(stmt, getDataSource());
/* 70 */       rs = stmt.executeQuery(getSequenceQuery());
/* 71 */       if (rs.next()) {
/* 72 */         return rs.getLong(1);
/*    */       }
/*    */ 
/* 75 */       throw new DataAccessResourceFailureException("Sequence query did not return a result");
/*    */     }
/*    */     catch (SQLException ex)
/*    */     {
/* 79 */       throw new DataAccessResourceFailureException("Could not obtain sequence value", ex);
/*    */     }
/*    */     finally {
/* 82 */       JdbcUtils.closeResultSet(rs);
/* 83 */       JdbcUtils.closeStatement(stmt);
/* 84 */       DataSourceUtils.releaseConnection(con, getDataSource());
/*    */     }
/*    */   }
/*    */ 
/*    */   protected abstract String getSequenceQuery();
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.support.incrementer.AbstractSequenceMaxValueIncrementer
 * JD-Core Version:    0.6.1
 */