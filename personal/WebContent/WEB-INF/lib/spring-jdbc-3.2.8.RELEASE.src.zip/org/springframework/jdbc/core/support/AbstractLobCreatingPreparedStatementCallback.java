/*    */ package org.springframework.jdbc.core.support;
/*    */ 
/*    */ import java.sql.PreparedStatement;
/*    */ import java.sql.SQLException;
/*    */ import org.springframework.dao.DataAccessException;
/*    */ import org.springframework.jdbc.core.PreparedStatementCallback;
/*    */ import org.springframework.jdbc.support.lob.LobCreator;
/*    */ import org.springframework.jdbc.support.lob.LobHandler;
/*    */ import org.springframework.util.Assert;
/*    */ 
/*    */ public abstract class AbstractLobCreatingPreparedStatementCallback
/*    */   implements PreparedStatementCallback<Integer>
/*    */ {
/*    */   private final LobHandler lobHandler;
/*    */ 
/*    */   public AbstractLobCreatingPreparedStatementCallback(LobHandler lobHandler)
/*    */   {
/* 66 */     Assert.notNull(lobHandler, "LobHandler must not be null");
/* 67 */     this.lobHandler = lobHandler;
/*    */   }
/*    */ 
/*    */   public final Integer doInPreparedStatement(PreparedStatement ps) throws SQLException, DataAccessException
/*    */   {
/* 72 */     LobCreator lobCreator = this.lobHandler.getLobCreator();
/*    */     try {
/* 74 */       setValues(ps, lobCreator);
/* 75 */       return Integer.valueOf(ps.executeUpdate());
/*    */     }
/*    */     finally {
/* 78 */       lobCreator.close();
/*    */     }
/*    */   }
/*    */ 
/*    */   protected abstract void setValues(PreparedStatement paramPreparedStatement, LobCreator paramLobCreator)
/*    */     throws SQLException, DataAccessException;
/*    */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.core.support.AbstractLobCreatingPreparedStatementCallback
 * JD-Core Version:    0.6.1
 */