/*     */ package org.springframework.jdbc.datasource;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import javax.sql.DataSource;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.springframework.core.Constants;
/*     */ 
/*     */ public class LazyConnectionDataSourceProxy extends DelegatingDataSource
/*     */ {
/*  84 */   private static final Constants constants = new Constants(Connection.class);
/*     */ 
/*  86 */   private static final Log logger = LogFactory.getLog(LazyConnectionDataSourceProxy.class);
/*     */   private Boolean defaultAutoCommit;
/*     */   private Integer defaultTransactionIsolation;
/*     */ 
/*     */   public LazyConnectionDataSourceProxy()
/*     */   {
/*     */   }
/*     */ 
/*     */   public LazyConnectionDataSourceProxy(DataSource targetDataSource)
/*     */   {
/* 105 */     setTargetDataSource(targetDataSource);
/* 106 */     afterPropertiesSet();
/*     */   }
/*     */ 
/*     */   public void setDefaultAutoCommit(boolean defaultAutoCommit)
/*     */   {
/* 119 */     this.defaultAutoCommit = Boolean.valueOf(defaultAutoCommit);
/*     */   }
/*     */ 
/*     */   public void setDefaultTransactionIsolation(int defaultTransactionIsolation)
/*     */   {
/* 136 */     this.defaultTransactionIsolation = Integer.valueOf(defaultTransactionIsolation);
/*     */   }
/*     */ 
/*     */   public void setDefaultTransactionIsolationName(String constantName)
/*     */   {
/* 150 */     setDefaultTransactionIsolation(constants.asNumber(constantName).intValue());
/*     */   }
/*     */ 
/*     */   public void afterPropertiesSet()
/*     */   {
/* 156 */     super.afterPropertiesSet();
/*     */ 
/* 160 */     if ((this.defaultAutoCommit == null) || (this.defaultTransactionIsolation == null))
/*     */       try {
/* 162 */         Connection con = getTargetDataSource().getConnection();
/*     */         try {
/* 164 */           checkDefaultConnectionProperties(con);
/*     */         }
/*     */         finally {
/* 167 */           con.close();
/*     */         }
/*     */       }
/*     */       catch (SQLException ex) {
/* 171 */         logger.warn("Could not retrieve default auto-commit and transaction isolation settings", ex);
/*     */       }
/*     */   }
/*     */ 
/*     */   protected synchronized void checkDefaultConnectionProperties(Connection con)
/*     */     throws SQLException
/*     */   {
/* 187 */     if (this.defaultAutoCommit == null) {
/* 188 */       this.defaultAutoCommit = Boolean.valueOf(con.getAutoCommit());
/*     */     }
/* 190 */     if (this.defaultTransactionIsolation == null)
/* 191 */       this.defaultTransactionIsolation = Integer.valueOf(con.getTransactionIsolation());
/*     */   }
/*     */ 
/*     */   protected Boolean defaultAutoCommit()
/*     */   {
/* 199 */     return this.defaultAutoCommit;
/*     */   }
/*     */ 
/*     */   protected Integer defaultTransactionIsolation()
/*     */   {
/* 206 */     return this.defaultTransactionIsolation;
/*     */   }
/*     */ 
/*     */   public Connection getConnection()
/*     */     throws SQLException
/*     */   {
/* 220 */     return (Connection)Proxy.newProxyInstance(ConnectionProxy.class.getClassLoader(), new Class[] { ConnectionProxy.class }, new LazyConnectionInvocationHandler());
/*     */   }
/*     */ 
/*     */   public Connection getConnection(String username, String password)
/*     */     throws SQLException
/*     */   {
/* 238 */     return (Connection)Proxy.newProxyInstance(ConnectionProxy.class.getClassLoader(), new Class[] { ConnectionProxy.class }, new LazyConnectionInvocationHandler(username, password));
/*     */   }
/*     */ 
/*     */   private class LazyConnectionInvocationHandler
/*     */     implements InvocationHandler
/*     */   {
/*     */     private String username;
/*     */     private String password;
/* 255 */     private Boolean readOnly = Boolean.FALSE;
/*     */     private Integer transactionIsolation;
/*     */     private Boolean autoCommit;
/* 261 */     private boolean closed = false;
/*     */     private Connection target;
/*     */ 
/*     */     public LazyConnectionInvocationHandler()
/*     */     {
/* 266 */       this.autoCommit = LazyConnectionDataSourceProxy.this.defaultAutoCommit();
/* 267 */       this.transactionIsolation = LazyConnectionDataSourceProxy.this.defaultTransactionIsolation();
/*     */     }
/*     */ 
/*     */     public LazyConnectionInvocationHandler(String username, String password) {
/* 271 */       this();
/* 272 */       this.username = username;
/* 273 */       this.password = password;
/*     */     }
/*     */ 
/*     */     public Object invoke(Object proxy, Method method, Object[] args)
/*     */       throws Throwable
/*     */     {
/* 279 */       if (method.getName().equals("equals"))
/*     */       {
/* 282 */         return Boolean.valueOf(proxy == args[0]);
/*     */       }
/* 284 */       if (method.getName().equals("hashCode"))
/*     */       {
/* 288 */         return Integer.valueOf(System.identityHashCode(proxy));
/*     */       }
/* 290 */       if (method.getName().equals("unwrap")) {
/* 291 */         if (((Class)args[0]).isInstance(proxy)) {
/* 292 */           return proxy;
/*     */         }
/*     */       }
/* 295 */       else if (method.getName().equals("isWrapperFor")) {
/* 296 */         if (((Class)args[0]).isInstance(proxy)) {
/* 297 */           return Boolean.valueOf(true);
/*     */         }
/*     */       }
/* 300 */       else if (method.getName().equals("getTargetConnection"))
/*     */       {
/* 302 */         return getTargetConnection(method);
/*     */       }
/*     */ 
/* 305 */       if (!hasTargetConnection())
/*     */       {
/* 310 */         if (method.getName().equals("toString")) {
/* 311 */           return "Lazy Connection proxy for target DataSource [" + LazyConnectionDataSourceProxy.this.getTargetDataSource() + "]";
/*     */         }
/* 313 */         if (method.getName().equals("isReadOnly")) {
/* 314 */           return this.readOnly;
/*     */         }
/* 316 */         if (method.getName().equals("setReadOnly")) {
/* 317 */           this.readOnly = ((Boolean)args[0]);
/* 318 */           return null;
/*     */         }
/* 320 */         if (method.getName().equals("getTransactionIsolation")) {
/* 321 */           if (this.transactionIsolation != null) {
/* 322 */             return this.transactionIsolation;
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 327 */           if (method.getName().equals("setTransactionIsolation")) {
/* 328 */             this.transactionIsolation = ((Integer)args[0]);
/* 329 */             return null;
/*     */           }
/* 331 */           if (method.getName().equals("getAutoCommit")) {
/* 332 */             if (this.autoCommit != null) {
/* 333 */               return this.autoCommit;
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 338 */             if (method.getName().equals("setAutoCommit")) {
/* 339 */               this.autoCommit = ((Boolean)args[0]);
/* 340 */               return null;
/*     */             }
/* 342 */             if (method.getName().equals("commit"))
/*     */             {
/* 344 */               return null;
/*     */             }
/* 346 */             if (method.getName().equals("rollback"))
/*     */             {
/* 348 */               return null;
/*     */             }
/* 350 */             if (method.getName().equals("getWarnings")) {
/* 351 */               return null;
/*     */             }
/* 353 */             if (method.getName().equals("clearWarnings")) {
/* 354 */               return null;
/*     */             }
/* 356 */             if (method.getName().equals("close"))
/*     */             {
/* 358 */               this.closed = true;
/* 359 */               return null;
/*     */             }
/* 361 */             if (method.getName().equals("isClosed")) {
/* 362 */               return Boolean.valueOf(this.closed);
/*     */             }
/* 364 */             if (this.closed)
/*     */             {
/* 367 */               throw new SQLException("Illegal operation: connection is closed");
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 375 */         return method.invoke(getTargetConnection(method), args);
/*     */       }
/*     */       catch (InvocationTargetException ex) {
/* 378 */         throw ex.getTargetException();
/*     */       }
/*     */     }
/*     */ 
/*     */     private boolean hasTargetConnection()
/*     */     {
/* 386 */       return this.target != null;
/*     */     }
/*     */ 
/*     */     private Connection getTargetConnection(Method operation)
/*     */       throws SQLException
/*     */     {
/* 393 */       if (this.target == null)
/*     */       {
/* 395 */         if (LazyConnectionDataSourceProxy.logger.isDebugEnabled()) {
/* 396 */           LazyConnectionDataSourceProxy.logger.debug("Connecting to database for operation '" + operation.getName() + "'");
/*     */         }
/*     */ 
/* 400 */         this.target = (this.username != null ? LazyConnectionDataSourceProxy.this.getTargetDataSource().getConnection(this.username, this.password) : LazyConnectionDataSourceProxy.this.getTargetDataSource().getConnection());
/*     */ 
/* 405 */         LazyConnectionDataSourceProxy.this.checkDefaultConnectionProperties(this.target);
/*     */ 
/* 408 */         if (this.readOnly.booleanValue()) {
/*     */           try {
/* 410 */             this.target.setReadOnly(this.readOnly.booleanValue());
/*     */           }
/*     */           catch (Exception ex)
/*     */           {
/* 414 */             LazyConnectionDataSourceProxy.logger.debug("Could not set JDBC Connection read-only", ex);
/*     */           }
/*     */         }
/* 417 */         if ((this.transactionIsolation != null) && (!this.transactionIsolation.equals(LazyConnectionDataSourceProxy.this.defaultTransactionIsolation())))
/*     */         {
/* 419 */           this.target.setTransactionIsolation(this.transactionIsolation.intValue());
/*     */         }
/* 421 */         if ((this.autoCommit != null) && (this.autoCommit.booleanValue() != this.target.getAutoCommit())) {
/* 422 */           this.target.setAutoCommit(this.autoCommit.booleanValue());
/*     */         }
/*     */ 
/*     */       }
/* 428 */       else if (LazyConnectionDataSourceProxy.logger.isDebugEnabled()) {
/* 429 */         LazyConnectionDataSourceProxy.logger.debug("Using existing database connection for operation '" + operation.getName() + "'");
/*     */       }
/*     */ 
/* 433 */       return this.target;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Administrator\Desktop\spring-jdbc-3.2.8.RELEASE.jar
 * Qualified Name:     org.springframework.jdbc.datasource.LazyConnectionDataSourceProxy
 * JD-Core Version:    0.6.1
 */