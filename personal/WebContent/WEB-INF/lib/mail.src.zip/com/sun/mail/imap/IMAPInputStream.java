/*     */ package com.sun.mail.imap;
/*     */ 
/*     */ import com.sun.mail.iap.ByteArray;
/*     */ import com.sun.mail.iap.ConnectionException;
/*     */ import com.sun.mail.iap.ProtocolException;
/*     */ import com.sun.mail.imap.protocol.BODY;
/*     */ import com.sun.mail.imap.protocol.IMAPProtocol;
/*     */ import com.sun.mail.util.FolderClosedIOException;
/*     */ import com.sun.mail.util.MessageRemovedIOException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import javax.mail.Flags.Flag;
/*     */ import javax.mail.Folder;
/*     */ import javax.mail.FolderClosedException;
/*     */ import javax.mail.MessagingException;
/*     */ 
/*     */ public class IMAPInputStream extends InputStream
/*     */ {
/*     */   private IMAPMessage msg;
/*     */   private String section;
/*     */   private int pos;
/*     */   private int blksize;
/*     */   private int max;
/*     */   private byte[] buf;
/*     */   private int bufcount;
/*     */   private int bufpos;
/*     */   private boolean peek;
/*     */   private ByteArray readbuf;
/*     */   private static final int slop = 64;
/*     */ 
/*     */   public IMAPInputStream(IMAPMessage msg, String section, int max, boolean peek)
/*     */   {
/*  75 */     this.msg = msg;
/*  76 */     this.section = section;
/*  77 */     this.max = max;
/*  78 */     this.peek = peek;
/*  79 */     this.pos = 0;
/*  80 */     this.blksize = msg.getFetchBlockSize();
/*     */   }
/*     */ 
/*     */   private void forceCheckExpunged()
/*     */     throws MessageRemovedIOException, FolderClosedIOException
/*     */   {
/*  89 */     synchronized (this.msg.getMessageCacheLock()) {
/*     */       try {
/*  91 */         this.msg.getProtocol().noop();
/*     */       } catch (ConnectionException cex) {
/*  93 */         throw new FolderClosedIOException(this.msg.getFolder(), cex.getMessage());
/*     */       }
/*     */       catch (FolderClosedException fex) {
/*  96 */         throw new FolderClosedIOException(fex.getFolder(), fex.getMessage());
/*     */       }
/*     */       catch (ProtocolException pex)
/*     */       {
/*     */       }
/*     */     }
/* 102 */     if (this.msg.isExpunged())
/* 103 */       throw new MessageRemovedIOException();
/*     */   }
/*     */ 
/*     */   private void fill()
/*     */     throws IOException
/*     */   {
/* 115 */     if ((this.max != -1) && (this.pos >= this.max)) {
/* 116 */       if (this.pos == 0)
/* 117 */         checkSeen();
/* 118 */       this.readbuf = null;
/* 119 */       return;
/*     */     }
/*     */ 
/* 122 */     BODY b = null;
/* 123 */     if (this.readbuf == null)
/* 124 */       this.readbuf = new ByteArray(this.blksize + 64);
/*     */     ByteArray ba;
/* 128 */     synchronized (this.msg.getMessageCacheLock()) {
/*     */       try {
/* 130 */         IMAPProtocol p = this.msg.getProtocol();
/*     */ 
/* 133 */         if (this.msg.isExpunged()) {
/* 134 */           throw new MessageRemovedIOException("No content for expunged message");
/*     */         }
/*     */ 
/* 137 */         int seqnum = this.msg.getSequenceNumber();
/* 138 */         int cnt = this.blksize;
/* 139 */         if ((this.max != -1) && (this.pos + this.blksize > this.max))
/* 140 */           cnt = this.max - this.pos;
/* 141 */         if (this.peek)
/* 142 */           b = p.peekBody(seqnum, this.section, this.pos, cnt, this.readbuf);
/*     */         else
/* 144 */           b = p.fetchBody(seqnum, this.section, this.pos, cnt, this.readbuf);
/*     */       } catch (ProtocolException pex) {
/* 146 */         forceCheckExpunged();
/* 147 */         throw new IOException(pex.getMessage());
/*     */       } catch (FolderClosedException fex) {
/* 149 */         throw new FolderClosedIOException(fex.getFolder(), fex.getMessage());
/*     */       }
/*     */       ByteArray ba;
/* 153 */       if ((b == null) || ((ba = b.getByteArray()) == null)) {
/* 154 */         forceCheckExpunged();
/* 155 */         throw new IOException("No content");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 160 */     if (this.pos == 0) {
/* 161 */       checkSeen();
/*     */     }
/*     */ 
/* 164 */     this.buf = ba.getBytes();
/* 165 */     this.bufpos = ba.getStart();
/* 166 */     int n = ba.getCount();
/*     */ 
/* 168 */     this.bufcount = (this.bufpos + n);
/* 169 */     this.pos += n;
/*     */   }
/*     */ 
/*     */   public synchronized int read()
/*     */     throws IOException
/*     */   {
/* 177 */     if (this.bufpos >= this.bufcount) {
/* 178 */       fill();
/* 179 */       if (this.bufpos >= this.bufcount)
/* 180 */         return -1;
/*     */     }
/* 182 */     return this.buf[(this.bufpos++)] & 0xFF;
/*     */   }
/*     */ 
/*     */   public synchronized int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 202 */     int avail = this.bufcount - this.bufpos;
/* 203 */     if (avail <= 0) {
/* 204 */       fill();
/* 205 */       avail = this.bufcount - this.bufpos;
/* 206 */       if (avail <= 0)
/* 207 */         return -1;
/*     */     }
/* 209 */     int cnt = avail < len ? avail : len;
/* 210 */     System.arraycopy(this.buf, this.bufpos, b, off, cnt);
/* 211 */     this.bufpos += cnt;
/* 212 */     return cnt;
/*     */   }
/*     */ 
/*     */   public int read(byte[] b)
/*     */     throws IOException
/*     */   {
/* 230 */     return read(b, 0, b.length);
/*     */   }
/*     */ 
/*     */   public synchronized int available()
/*     */     throws IOException
/*     */   {
/* 238 */     return this.bufcount - this.bufpos;
/*     */   }
/*     */ 
/*     */   private void checkSeen()
/*     */   {
/* 249 */     if (this.peek)
/* 250 */       return;
/*     */     try {
/* 252 */       Folder f = this.msg.getFolder();
/* 253 */       if ((f != null) && (f.getMode() != 1) && (!this.msg.isSet(Flags.Flag.SEEN)))
/*     */       {
/* 255 */         this.msg.setFlag(Flags.Flag.SEEN, true);
/*     */       }
/*     */     }
/*     */     catch (MessagingException ex)
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.IMAPInputStream
 * JD-Core Version:    0.6.1
 */