/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ public class ASCIIUtility
/*     */ {
/*     */   public static int parseInt(byte[] b, int start, int end, int radix)
/*     */     throws NumberFormatException
/*     */   {
/*  57 */     if (b == null) {
/*  58 */       throw new NumberFormatException("null");
/*     */     }
/*  60 */     int result = 0;
/*  61 */     boolean negative = false;
/*  62 */     int i = start;
/*     */ 
/*  67 */     if (end > start)
/*     */     {
/*     */       int limit;
/*  68 */       if (b[i] == 45) {
/*  69 */         negative = true;
/*  70 */         int limit = -2147483648;
/*  71 */         i++;
/*     */       } else {
/*  73 */         limit = -2147483647;
/*     */       }
/*  75 */       int multmin = limit / radix;
/*  76 */       if (i < end) {
/*  77 */         int digit = Character.digit((char)b[(i++)], radix);
/*  78 */         if (digit < 0) {
/*  79 */           throw new NumberFormatException("illegal number: " + toString(b, start, end));
/*     */         }
/*     */ 
/*  83 */         result = -digit;
/*     */       }
/*     */ 
/*  86 */       while (i < end)
/*     */       {
/*  88 */         int digit = Character.digit((char)b[(i++)], radix);
/*  89 */         if (digit < 0) {
/*  90 */           throw new NumberFormatException("illegal number");
/*     */         }
/*  92 */         if (result < multmin) {
/*  93 */           throw new NumberFormatException("illegal number");
/*     */         }
/*  95 */         result *= radix;
/*  96 */         if (result < limit + digit) {
/*  97 */           throw new NumberFormatException("illegal number");
/*     */         }
/*  99 */         result -= digit;
/*     */       }
/*     */     }
/* 102 */     throw new NumberFormatException("illegal number");
/*     */     int multmin;
/*     */     int limit;
/* 104 */     if (negative) {
/* 105 */       if (i > start + 1) {
/* 106 */         return result;
/*     */       }
/* 108 */       throw new NumberFormatException("illegal number");
/*     */     }
/*     */ 
/* 111 */     return -result;
/*     */   }
/*     */ 
/*     */   public static int parseInt(byte[] b, int start, int end)
/*     */     throws NumberFormatException
/*     */   {
/* 122 */     return parseInt(b, start, end, 10);
/*     */   }
/*     */ 
/*     */   public static long parseLong(byte[] b, int start, int end, int radix)
/*     */     throws NumberFormatException
/*     */   {
/* 134 */     if (b == null) {
/* 135 */       throw new NumberFormatException("null");
/*     */     }
/* 137 */     long result = 0L;
/* 138 */     boolean negative = false;
/* 139 */     int i = start;
/*     */ 
/* 144 */     if (end > start)
/*     */     {
/*     */       long limit;
/* 145 */       if (b[i] == 45) {
/* 146 */         negative = true;
/* 147 */         long limit = -9223372036854775808L;
/* 148 */         i++;
/*     */       } else {
/* 150 */         limit = -9223372036854775807L;
/*     */       }
/* 152 */       long multmin = limit / radix;
/* 153 */       if (i < end) {
/* 154 */         int digit = Character.digit((char)b[(i++)], radix);
/* 155 */         if (digit < 0) {
/* 156 */           throw new NumberFormatException("illegal number: " + toString(b, start, end));
/*     */         }
/*     */ 
/* 160 */         result = -digit;
/*     */       }
/*     */ 
/* 163 */       while (i < end)
/*     */       {
/* 165 */         int digit = Character.digit((char)b[(i++)], radix);
/* 166 */         if (digit < 0) {
/* 167 */           throw new NumberFormatException("illegal number");
/*     */         }
/* 169 */         if (result < multmin) {
/* 170 */           throw new NumberFormatException("illegal number");
/*     */         }
/* 172 */         result *= radix;
/* 173 */         if (result < limit + digit) {
/* 174 */           throw new NumberFormatException("illegal number");
/*     */         }
/* 176 */         result -= digit;
/*     */       }
/*     */     }
/* 179 */     throw new NumberFormatException("illegal number");
/*     */     long multmin;
/*     */     long limit;
/* 181 */     if (negative) {
/* 182 */       if (i > start + 1) {
/* 183 */         return result;
/*     */       }
/* 185 */       throw new NumberFormatException("illegal number");
/*     */     }
/*     */ 
/* 188 */     return -result;
/*     */   }
/*     */ 
/*     */   public static long parseLong(byte[] b, int start, int end)
/*     */     throws NumberFormatException
/*     */   {
/* 199 */     return parseLong(b, start, end, 10);
/*     */   }
/*     */ 
/*     */   public static String toString(byte[] b, int start, int end)
/*     */   {
/* 208 */     int size = end - start;
/* 209 */     char[] theChars = new char[size];
/*     */ 
/* 211 */     int i = 0; for (int j = start; i < size; ) {
/* 212 */       theChars[(i++)] = (char)(b[(j++)] & 0xFF);
/*     */     }
/* 214 */     return new String(theChars);
/*     */   }
/*     */ 
/*     */   public static String toString(ByteArrayInputStream is) {
/* 218 */     int size = is.available();
/* 219 */     char[] theChars = new char[size];
/* 220 */     byte[] bytes = new byte[size];
/*     */ 
/* 222 */     is.read(bytes, 0, size);
/* 223 */     for (int i = 0; i < size; ) {
/* 224 */       theChars[i] = (char)(bytes[(i++)] & 0xFF);
/*     */     }
/* 226 */     return new String(theChars);
/*     */   }
/*     */ 
/*     */   public static byte[] getBytes(String s)
/*     */   {
/* 231 */     char[] chars = s.toCharArray();
/* 232 */     int size = chars.length;
/* 233 */     byte[] bytes = new byte[size];
/*     */ 
/* 235 */     for (int i = 0; i < size; )
/* 236 */       bytes[i] = (byte)chars[(i++)];
/* 237 */     return bytes;
/*     */   }
/*     */ 
/*     */   public static byte[] getBytes(InputStream is)
/*     */     throws IOException
/*     */   {
/* 243 */     int size = 1024;
/*     */     int len;
/*     */     byte[] buf;
/* 247 */     if ((is instanceof ByteArrayInputStream)) {
/* 248 */       size = is.available();
/* 249 */       byte[] buf = new byte[size];
/* 250 */       len = is.read(buf, 0, size);
/*     */     }
/*     */     else {
/* 253 */       ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 254 */       buf = new byte[size];
/*     */       int len;
/* 255 */       while ((len = is.read(buf, 0, size)) != -1)
/* 256 */         bos.write(buf, 0, len);
/* 257 */       buf = bos.toByteArray();
/*     */     }
/* 259 */     return buf;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.util.ASCIIUtility
 * JD-Core Version:    0.6.1
 */