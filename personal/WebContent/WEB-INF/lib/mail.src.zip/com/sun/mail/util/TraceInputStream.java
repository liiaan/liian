/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ public class TraceInputStream extends FilterInputStream
/*     */ {
/*  51 */   private boolean trace = false;
/*  52 */   private boolean quote = false;
/*     */   private OutputStream traceOut;
/*     */ 
/*     */   public TraceInputStream(InputStream in, OutputStream traceOut)
/*     */   {
/*  63 */     super(in);
/*  64 */     this.traceOut = traceOut;
/*     */   }
/*     */ 
/*     */   public void setTrace(boolean trace)
/*     */   {
/*  72 */     this.trace = trace;
/*     */   }
/*     */ 
/*     */   public void setQuote(boolean quote)
/*     */   {
/*  80 */     this.quote = quote;
/*     */   }
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/*  89 */     int b = this.in.read();
/*  90 */     if ((this.trace) && (b != -1)) {
/*  91 */       if (this.quote)
/*  92 */         writeByte(b);
/*     */       else
/*  94 */         this.traceOut.write(b);
/*     */     }
/*  96 */     return b;
/*     */   }
/*     */ 
/*     */   public int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 106 */     int count = this.in.read(b, off, len);
/* 107 */     if ((this.trace) && (count != -1)) {
/* 108 */       if (this.quote)
/* 109 */         for (int i = 0; i < count; i++)
/* 110 */           writeByte(b[(off + i)]);
/*     */       else
/* 112 */         this.traceOut.write(b, off, count);
/*     */     }
/* 114 */     return count;
/*     */   }
/*     */ 
/*     */   private final void writeByte(int b)
/*     */     throws IOException
/*     */   {
/* 121 */     b &= 255;
/* 122 */     if (b > 127) {
/* 123 */       this.traceOut.write(77);
/* 124 */       this.traceOut.write(45);
/* 125 */       b &= 127;
/*     */     }
/* 127 */     if (b == 13) {
/* 128 */       this.traceOut.write(92);
/* 129 */       this.traceOut.write(114);
/* 130 */     } else if (b == 10) {
/* 131 */       this.traceOut.write(92);
/* 132 */       this.traceOut.write(110);
/* 133 */       this.traceOut.write(10);
/* 134 */     } else if (b == 9) {
/* 135 */       this.traceOut.write(92);
/* 136 */       this.traceOut.write(116);
/* 137 */     } else if (b < 32) {
/* 138 */       this.traceOut.write(94);
/* 139 */       this.traceOut.write(64 + b);
/*     */     } else {
/* 141 */       this.traceOut.write(b);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.util.TraceInputStream
 * JD-Core Version:    0.6.1
 */