/*     */ package com.sun.mail.iap;
/*     */ 
/*     */ import com.sun.mail.util.ASCIIUtility;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class Response
/*     */ {
/*     */   protected int index;
/*     */   protected int pindex;
/*     */   protected int size;
/*  54 */   protected byte[] buffer = null;
/*  55 */   protected int type = 0;
/*  56 */   protected String tag = null;
/*     */   private static final int increment = 100;
/*     */   public static final int TAG_MASK = 3;
/*     */   public static final int CONTINUATION = 1;
/*     */   public static final int TAGGED = 2;
/*     */   public static final int UNTAGGED = 3;
/*     */   public static final int TYPE_MASK = 28;
/*     */   public static final int OK = 4;
/*     */   public static final int NO = 8;
/*     */   public static final int BAD = 12;
/*     */   public static final int BYE = 16;
/*     */   public static final int SYNTHETIC = 32;
/*     */ 
/*     */   public Response(String s)
/*     */   {
/*  79 */     this.buffer = ASCIIUtility.getBytes(s);
/*  80 */     this.size = this.buffer.length;
/*  81 */     parse();
/*     */   }
/*     */ 
/*     */   public Response(Protocol p)
/*     */     throws IOException, ProtocolException
/*     */   {
/*  90 */     ByteArray ba = p.getResponseBuffer();
/*  91 */     ByteArray response = p.getInputStream().readResponse(ba);
/*  92 */     this.buffer = response.getBytes();
/*  93 */     this.size = (response.getCount() - 2);
/*     */ 
/*  95 */     parse();
/*     */   }
/*     */ 
/*     */   public Response(Response r)
/*     */   {
/* 102 */     this.index = r.index;
/* 103 */     this.size = r.size;
/* 104 */     this.buffer = r.buffer;
/* 105 */     this.type = r.type;
/* 106 */     this.tag = r.tag;
/*     */   }
/*     */ 
/*     */   public static Response byeResponse(Exception ex)
/*     */   {
/* 114 */     String err = "* BYE JavaMail Exception: " + ex.toString();
/* 115 */     err = err.replace('\r', ' ').replace('\n', ' ');
/* 116 */     Response r = new Response(err);
/* 117 */     r.type |= 32;
/* 118 */     return r;
/*     */   }
/*     */ 
/*     */   private void parse() {
/* 122 */     this.index = 0;
/*     */ 
/* 124 */     if (this.buffer[this.index] == 43) {
/* 125 */       this.type |= 1;
/* 126 */       this.index += 1;
/* 127 */       return;
/* 128 */     }if (this.buffer[this.index] == 42) {
/* 129 */       this.type |= 3;
/* 130 */       this.index += 1;
/*     */     } else {
/* 132 */       this.type |= 2;
/* 133 */       this.tag = readAtom();
/*     */     }
/*     */ 
/* 136 */     int mark = this.index;
/* 137 */     String s = readAtom();
/* 138 */     if (s == null)
/* 139 */       s = "";
/* 140 */     if (s.equalsIgnoreCase("OK"))
/* 141 */       this.type |= 4;
/* 142 */     else if (s.equalsIgnoreCase("NO"))
/* 143 */       this.type |= 8;
/* 144 */     else if (s.equalsIgnoreCase("BAD"))
/* 145 */       this.type |= 12;
/* 146 */     else if (s.equalsIgnoreCase("BYE"))
/* 147 */       this.type |= 16;
/*     */     else {
/* 149 */       this.index = mark;
/*     */     }
/* 151 */     this.pindex = this.index;
/*     */   }
/*     */ 
/*     */   public void skipSpaces()
/*     */   {
/* 156 */     while ((this.index < this.size) && (this.buffer[this.index] == 32))
/* 157 */       this.index += 1;
/*     */   }
/*     */ 
/*     */   public void skipToken()
/*     */   {
/* 164 */     while ((this.index < this.size) && (this.buffer[this.index] != 32))
/* 165 */       this.index += 1;
/*     */   }
/*     */ 
/*     */   public void skip(int count) {
/* 169 */     this.index += count;
/*     */   }
/*     */ 
/*     */   public byte peekByte() {
/* 173 */     if (this.index < this.size) {
/* 174 */       return this.buffer[this.index];
/*     */     }
/* 176 */     return 0;
/*     */   }
/*     */ 
/*     */   public byte readByte()
/*     */   {
/* 184 */     if (this.index < this.size) {
/* 185 */       return this.buffer[(this.index++)];
/*     */     }
/* 187 */     return 0;
/*     */   }
/*     */ 
/*     */   public String readAtom()
/*     */   {
/* 196 */     return readAtom('\000');
/*     */   }
/*     */ 
/*     */   public String readAtom(char delim)
/*     */   {
/* 204 */     skipSpaces();
/*     */ 
/* 206 */     if (this.index >= this.size) {
/* 207 */       return null;
/*     */     }
/*     */ 
/* 214 */     int start = this.index;
/*     */     byte b;
/* 217 */     while ((this.index < this.size) && ((b = this.buffer[this.index]) > 32) && (b != 40) && (b != 41) && (b != 37) && (b != 42) && (b != 34) && (b != 92) && (b != 127) && ((delim == 0) || (b != delim)))
/*     */     {
/* 219 */       this.index += 1;
/*     */     }
/* 221 */     return ASCIIUtility.toString(this.buffer, start, this.index);
/*     */   }
/*     */ 
/*     */   public String readString(char delim)
/*     */   {
/* 230 */     skipSpaces();
/*     */ 
/* 232 */     if (this.index >= this.size) {
/* 233 */       return null;
/*     */     }
/* 235 */     int start = this.index;
/* 236 */     while ((this.index < this.size) && (this.buffer[this.index] != delim)) {
/* 237 */       this.index += 1;
/*     */     }
/* 239 */     return ASCIIUtility.toString(this.buffer, start, this.index);
/*     */   }
/*     */ 
/*     */   public String[] readStringList() {
/* 243 */     skipSpaces();
/*     */ 
/* 245 */     if (this.buffer[this.index] != 40)
/* 246 */       return null;
/* 247 */     this.index += 1;
/*     */ 
/* 249 */     Vector v = new Vector();
/*     */     do
/* 251 */       v.addElement(readString());
/* 252 */     while (this.buffer[(this.index++)] != 41);
/*     */ 
/* 254 */     int size = v.size();
/* 255 */     if (size > 0) {
/* 256 */       String[] s = new String[size];
/* 257 */       v.copyInto(s);
/* 258 */       return s;
/*     */     }
/* 260 */     return null;
/*     */   }
/*     */ 
/*     */   public int readNumber()
/*     */   {
/* 272 */     skipSpaces();
/*     */ 
/* 274 */     int start = this.index;
/* 275 */     while ((this.index < this.size) && (Character.isDigit((char)this.buffer[this.index]))) {
/* 276 */       this.index += 1;
/*     */     }
/* 278 */     if (this.index > start)
/*     */       try {
/* 280 */         return ASCIIUtility.parseInt(this.buffer, start, this.index);
/*     */       }
/*     */       catch (NumberFormatException nex) {
/*     */       }
/* 284 */     return -1;
/*     */   }
/*     */ 
/*     */   public long readLong()
/*     */   {
/* 296 */     skipSpaces();
/*     */ 
/* 298 */     int start = this.index;
/* 299 */     while ((this.index < this.size) && (Character.isDigit((char)this.buffer[this.index]))) {
/* 300 */       this.index += 1;
/*     */     }
/* 302 */     if (this.index > start)
/*     */       try {
/* 304 */         return ASCIIUtility.parseLong(this.buffer, start, this.index);
/*     */       }
/*     */       catch (NumberFormatException nex) {
/*     */       }
/* 308 */     return -1L;
/*     */   }
/*     */ 
/*     */   public String readString()
/*     */   {
/* 320 */     return (String)parseString(false, true);
/*     */   }
/*     */ 
/*     */   public ByteArrayInputStream readBytes()
/*     */   {
/* 332 */     ByteArray ba = readByteArray();
/* 333 */     if (ba != null) {
/* 334 */       return ba.toByteArrayInputStream();
/*     */     }
/* 336 */     return null;
/*     */   }
/*     */ 
/*     */   public ByteArray readByteArray()
/*     */   {
/* 352 */     if (isContinuation()) {
/* 353 */       skipSpaces();
/* 354 */       return new ByteArray(this.buffer, this.index, this.size - this.index);
/*     */     }
/* 356 */     return (ByteArray)parseString(false, false);
/*     */   }
/*     */ 
/*     */   public String readAtomString()
/*     */   {
/* 371 */     return (String)parseString(true, true);
/*     */   }
/*     */ 
/*     */   private Object parseString(boolean parseAtoms, boolean returnString)
/*     */   {
/* 383 */     skipSpaces();
/*     */ 
/* 385 */     byte b = this.buffer[this.index];
/* 386 */     if (b == 34) {
/* 387 */       this.index += 1;
/* 388 */       int start = this.index;
/* 389 */       int copyto = this.index;
/*     */ 
/* 391 */       while ((b = this.buffer[this.index]) != 34) {
/* 392 */         if (b == 92)
/* 393 */           this.index += 1;
/* 394 */         if (this.index != copyto)
/*     */         {
/* 397 */           this.buffer[copyto] = this.buffer[this.index];
/*     */         }
/* 399 */         copyto++;
/* 400 */         this.index += 1;
/*     */       }
/* 402 */       this.index += 1;
/*     */ 
/* 404 */       if (returnString) {
/* 405 */         return ASCIIUtility.toString(this.buffer, start, copyto);
/*     */       }
/* 407 */       return new ByteArray(this.buffer, start, copyto - start);
/* 408 */     }if (b == 123) {
/* 409 */       int start = ++this.index;
/*     */ 
/* 411 */       while (this.buffer[this.index] != 125) {
/* 412 */         this.index += 1;
/*     */       }
/* 414 */       int count = 0;
/*     */       try {
/* 416 */         count = ASCIIUtility.parseInt(this.buffer, start, this.index);
/*     */       }
/*     */       catch (NumberFormatException nex) {
/* 419 */         return null;
/*     */       }
/*     */ 
/* 422 */       start = this.index + 3;
/* 423 */       this.index = (start + count);
/*     */ 
/* 425 */       if (returnString) {
/* 426 */         return ASCIIUtility.toString(this.buffer, start, start + count);
/*     */       }
/* 428 */       return new ByteArray(this.buffer, start, count);
/* 429 */     }if (parseAtoms) {
/* 430 */       int start = this.index;
/*     */ 
/* 432 */       String s = readAtom();
/* 433 */       if (returnString) {
/* 434 */         return s;
/*     */       }
/* 436 */       return new ByteArray(this.buffer, start, this.index);
/* 437 */     }if ((b == 78) || (b == 110)) {
/* 438 */       this.index += 3;
/* 439 */       return null;
/*     */     }
/* 441 */     return null;
/*     */   }
/*     */ 
/*     */   public int getType() {
/* 445 */     return this.type;
/*     */   }
/*     */ 
/*     */   public boolean isContinuation() {
/* 449 */     return (this.type & 0x3) == 1;
/*     */   }
/*     */ 
/*     */   public boolean isTagged() {
/* 453 */     return (this.type & 0x3) == 2;
/*     */   }
/*     */ 
/*     */   public boolean isUnTagged() {
/* 457 */     return (this.type & 0x3) == 3;
/*     */   }
/*     */ 
/*     */   public boolean isOK() {
/* 461 */     return (this.type & 0x1C) == 4;
/*     */   }
/*     */ 
/*     */   public boolean isNO() {
/* 465 */     return (this.type & 0x1C) == 8;
/*     */   }
/*     */ 
/*     */   public boolean isBAD() {
/* 469 */     return (this.type & 0x1C) == 12;
/*     */   }
/*     */ 
/*     */   public boolean isBYE() {
/* 473 */     return (this.type & 0x1C) == 16;
/*     */   }
/*     */ 
/*     */   public boolean isSynthetic() {
/* 477 */     return (this.type & 0x20) == 32;
/*     */   }
/*     */ 
/*     */   public String getTag()
/*     */   {
/* 485 */     return this.tag;
/*     */   }
/*     */ 
/*     */   public String getRest()
/*     */   {
/* 493 */     skipSpaces();
/* 494 */     return ASCIIUtility.toString(this.buffer, this.index, this.size);
/*     */   }
/*     */ 
/*     */   public void reset()
/*     */   {
/* 501 */     this.index = this.pindex;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 505 */     return ASCIIUtility.toString(this.buffer, 0, this.size);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.iap.Response
 * JD-Core Version:    0.6.1
 */