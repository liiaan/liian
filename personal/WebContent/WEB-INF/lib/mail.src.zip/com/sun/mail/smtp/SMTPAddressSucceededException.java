/*    */ package com.sun.mail.smtp;
/*    */ 
/*    */ import javax.mail.MessagingException;
/*    */ import javax.mail.internet.InternetAddress;
/*    */ 
/*    */ public class SMTPAddressSucceededException extends MessagingException
/*    */ {
/*    */   protected InternetAddress addr;
/*    */   protected String cmd;
/*    */   protected int rc;
/*    */   private static final long serialVersionUID = -1168335848623096749L;
/*    */ 
/*    */   public SMTPAddressSucceededException(InternetAddress addr, String cmd, int rc, String err)
/*    */   {
/* 70 */     super(err);
/* 71 */     this.addr = addr;
/* 72 */     this.cmd = cmd;
/* 73 */     this.rc = rc;
/*    */   }
/*    */ 
/*    */   public InternetAddress getAddress()
/*    */   {
/* 80 */     return this.addr;
/*    */   }
/*    */ 
/*    */   public String getCommand()
/*    */   {
/* 87 */     return this.cmd;
/*    */   }
/*    */ 
/*    */   public int getReturnCode()
/*    */   {
/* 98 */     return this.rc;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.smtp.SMTPAddressSucceededException
 * JD-Core Version:    0.6.1
 */