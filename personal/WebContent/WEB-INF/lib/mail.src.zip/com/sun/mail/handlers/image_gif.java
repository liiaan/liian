/*     */ package com.sun.mail.handlers;
/*     */ 
/*     */ import java.awt.Image;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.datatransfer.DataFlavor;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import javax.activation.ActivationDataFlavor;
/*     */ import javax.activation.DataContentHandler;
/*     */ import javax.activation.DataSource;
/*     */ 
/*     */ public class image_gif
/*     */   implements DataContentHandler
/*     */ {
/*  49 */   private static ActivationDataFlavor myDF = new ActivationDataFlavor(Image.class, "image/gif", "GIF Image");
/*     */ 
/*     */   protected ActivationDataFlavor getDF()
/*     */   {
/*  55 */     return myDF;
/*     */   }
/*     */ 
/*     */   public DataFlavor[] getTransferDataFlavors()
/*     */   {
/*  64 */     return new DataFlavor[] { getDF() };
/*     */   }
/*     */ 
/*     */   public Object getTransferData(DataFlavor df, DataSource ds)
/*     */     throws IOException
/*     */   {
/*  78 */     if (getDF().equals(df)) {
/*  79 */       return getContent(ds);
/*     */     }
/*  81 */     return null;
/*     */   }
/*     */ 
/*     */   public Object getContent(DataSource ds) throws IOException {
/*  85 */     InputStream is = ds.getInputStream();
/*  86 */     int pos = 0;
/*     */ 
/*  88 */     byte[] buf = new byte[1024];
/*     */     int count;
/*  90 */     while ((count = is.read(buf, pos, buf.length - pos)) != -1) {
/*  91 */       pos += count;
/*  92 */       if (pos >= buf.length) {
/*  93 */         int size = buf.length;
/*  94 */         if (size < 262144)
/*  95 */           size += size;
/*     */         else
/*  97 */           size += 262144;
/*  98 */         byte[] tbuf = new byte[size];
/*  99 */         System.arraycopy(buf, 0, tbuf, 0, pos);
/* 100 */         buf = tbuf;
/*     */       }
/*     */     }
/* 103 */     Toolkit tk = Toolkit.getDefaultToolkit();
/* 104 */     return tk.createImage(buf, 0, pos);
/*     */   }
/*     */ 
/*     */   public void writeTo(Object obj, String type, OutputStream os)
/*     */     throws IOException
/*     */   {
/* 112 */     if (!(obj instanceof Image)) {
/* 113 */       throw new IOException("\"" + getDF().getMimeType() + "\" DataContentHandler requires Image object, " + "was given object of type " + obj.getClass().toString());
/*     */     }
/*     */ 
/* 117 */     throw new IOException(getDF().getMimeType() + " encoding not supported");
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.handlers.image_gif
 * JD-Core Version:    0.6.1
 */