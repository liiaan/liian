/*    */ package com.sun.mail.imap.protocol;
/*    */ 
/*    */ import com.sun.mail.iap.ByteArray;
/*    */ import com.sun.mail.iap.ParsingException;
/*    */ import java.io.ByteArrayInputStream;
/*    */ 
/*    */ public class RFC822DATA
/*    */   implements Item
/*    */ {
/* 51 */   static final char[] name = { 'R', 'F', 'C', '8', '2', '2' };
/*    */   public int msgno;
/*    */   public ByteArray data;
/*    */ 
/*    */   public RFC822DATA(FetchResponse r)
/*    */     throws ParsingException
/*    */   {
/* 60 */     this.msgno = r.getNumber();
/* 61 */     r.skipSpaces();
/* 62 */     this.data = r.readByteArray();
/*    */   }
/*    */ 
/*    */   public ByteArray getByteArray() {
/* 66 */     return this.data;
/*    */   }
/*    */ 
/*    */   public ByteArrayInputStream getByteArrayInputStream() {
/* 70 */     if (this.data != null) {
/* 71 */       return this.data.toByteArrayInputStream();
/*    */     }
/* 73 */     return null;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.protocol.RFC822DATA
 * JD-Core Version:    0.6.1
 */