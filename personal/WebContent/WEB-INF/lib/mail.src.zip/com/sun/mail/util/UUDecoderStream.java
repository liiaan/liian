/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ public class UUDecoderStream extends FilterInputStream
/*     */ {
/*     */   private String name;
/*     */   private int mode;
/*  55 */   private byte[] buffer = new byte[45];
/*  56 */   private int bufsize = 0;
/*  57 */   private int index = 0;
/*  58 */   private boolean gotPrefix = false;
/*  59 */   private boolean gotEnd = false;
/*     */   private LineInputStream lin;
/*     */   private boolean ignoreErrors;
/*     */   private boolean ignoreMissingBeginEnd;
/*     */   private String readAhead;
/*     */ 
/*     */   public UUDecoderStream(InputStream in)
/*     */   {
/*  76 */     super(in);
/*  77 */     this.lin = new LineInputStream(in);
/*     */ 
/*  79 */     this.ignoreErrors = PropUtil.getBooleanSystemProperty("mail.mime.uudecode.ignoreerrors", false);
/*     */ 
/*  82 */     this.ignoreMissingBeginEnd = PropUtil.getBooleanSystemProperty("mail.mime.uudecode.ignoremissingbeginend", false);
/*     */   }
/*     */ 
/*     */   public UUDecoderStream(InputStream in, boolean ignoreErrors, boolean ignoreMissingBeginEnd)
/*     */   {
/*  94 */     super(in);
/*  95 */     this.lin = new LineInputStream(in);
/*  96 */     this.ignoreErrors = ignoreErrors;
/*  97 */     this.ignoreMissingBeginEnd = ignoreMissingBeginEnd;
/*     */   }
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/* 114 */     if (this.index >= this.bufsize) {
/* 115 */       readPrefix();
/* 116 */       if (!decode())
/* 117 */         return -1;
/* 118 */       this.index = 0;
/*     */     }
/* 120 */     return this.buffer[(this.index++)] & 0xFF;
/*     */   }
/*     */ 
/*     */   public int read(byte[] buf, int off, int len) throws IOException
/*     */   {
/* 125 */     for (int i = 0; i < len; i++)
/*     */     {
/*     */       int c;
/* 126 */       if ((c = read()) == -1) {
/* 127 */         if (i != 0) break;
/* 128 */         i = -1; break;
/*     */       }
/*     */ 
/* 131 */       buf[(off + i)] = (byte)c;
/*     */     }
/* 133 */     return i;
/*     */   }
/*     */ 
/*     */   public boolean markSupported() {
/* 137 */     return false;
/*     */   }
/*     */ 
/*     */   public int available()
/*     */     throws IOException
/*     */   {
/* 143 */     return this.in.available() * 3 / 4 + (this.bufsize - this.index);
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */     throws IOException
/*     */   {
/* 154 */     readPrefix();
/* 155 */     return this.name;
/*     */   }
/*     */ 
/*     */   public int getMode()
/*     */     throws IOException
/*     */   {
/* 166 */     readPrefix();
/* 167 */     return this.mode;
/*     */   }
/*     */ 
/*     */   private void readPrefix()
/*     */     throws IOException
/*     */   {
/* 176 */     if (this.gotPrefix) {
/* 177 */       return;
/*     */     }
/* 179 */     this.mode = 438;
/* 180 */     this.name = "encoder.buf";
/*     */     while (true)
/*     */     {
/* 184 */       String line = this.lin.readLine();
/* 185 */       if (line == null) {
/* 186 */         if (!this.ignoreMissingBeginEnd) {
/* 187 */           throw new DecodingException("UUDecoder: Missing begin");
/*     */         }
/* 189 */         this.gotPrefix = true;
/* 190 */         this.gotEnd = true;
/* 191 */         break;
/*     */       }
/* 193 */       if (line.regionMatches(false, 0, "begin", 0, 5)) {
/*     */         try {
/* 195 */           this.mode = Integer.parseInt(line.substring(6, 9));
/*     */         } catch (NumberFormatException ex) {
/* 197 */           if (!this.ignoreErrors) {
/* 198 */             throw new DecodingException("UUDecoder: Error in mode: " + ex.toString());
/*     */           }
/*     */         }
/* 201 */         if (line.length() > 10) {
/* 202 */           this.name = line.substring(10);
/*     */         }
/* 204 */         else if (!this.ignoreErrors) {
/* 205 */           throw new DecodingException("UUDecoder: Missing name: " + line);
/*     */         }
/*     */ 
/* 208 */         this.gotPrefix = true;
/* 209 */         break;
/* 210 */       }if (this.ignoreMissingBeginEnd) {
/* 211 */         int count = line.charAt(0);
/* 212 */         count = count - 32 & 0x3F;
/* 213 */         int need = (count * 8 + 5) / 6;
/* 214 */         if ((need == 0) || (line.length() >= need + 1))
/*     */         {
/* 221 */           this.readAhead = line;
/* 222 */           this.gotPrefix = true;
/* 223 */           break;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean decode() throws IOException
/*     */   {
/* 231 */     if (this.gotEnd)
/* 232 */       return false;
/* 233 */     this.bufsize = 0;
/* 234 */     int count = 0;
/*     */     String line;
/*     */     do {
/*     */       do {
/*     */         do {
/* 241 */           if (this.readAhead != null) {
/* 242 */             String line = this.readAhead;
/* 243 */             this.readAhead = null;
/*     */           } else {
/* 245 */             line = this.lin.readLine();
/*     */           }
/*     */ 
/* 252 */           if (line == null) {
/* 253 */             if (!this.ignoreMissingBeginEnd) {
/* 254 */               throw new DecodingException("UUDecoder: Missing end at EOF");
/*     */             }
/* 256 */             this.gotEnd = true;
/* 257 */             return false;
/*     */           }
/* 259 */           if (line.equals("end")) {
/* 260 */             this.gotEnd = true;
/* 261 */             return false;
/*     */           }
/*     */         }
/* 263 */         while (line.length() == 0);
/*     */ 
/* 265 */         count = line.charAt(0);
/* 266 */         if (count >= 32) break; 
/* 267 */       }while (this.ignoreErrors);
/* 268 */       throw new DecodingException("UUDecoder: Buffer format error");
/*     */ 
/* 279 */       count = count - 32 & 0x3F;
/*     */ 
/* 281 */       if (count == 0) {
/* 282 */         line = this.lin.readLine();
/* 283 */         if (((line == null) || (!line.equals("end"))) && 
/* 284 */           (!this.ignoreMissingBeginEnd)) {
/* 285 */           throw new DecodingException("UUDecoder: Missing End after count 0 line");
/*     */         }
/*     */ 
/* 288 */         this.gotEnd = true;
/* 289 */         return false;
/*     */       }
/*     */ 
/* 292 */       int need = (count * 8 + 5) / 6;
/*     */ 
/* 294 */       if (line.length() >= need + 1) break; 
/* 295 */     }while (this.ignoreErrors);
/* 296 */     throw new DecodingException("UUDecoder: Short buffer error");
/*     */ 
/* 305 */     int i = 1;
/*     */ 
/* 313 */     while (this.bufsize < count)
/*     */     {
/* 315 */       byte a = (byte)(line.charAt(i++) - ' ' & 0x3F);
/* 316 */       byte b = (byte)(line.charAt(i++) - ' ' & 0x3F);
/* 317 */       this.buffer[(this.bufsize++)] = (byte)(a << 2 & 0xFC | b >>> 4 & 0x3);
/*     */ 
/* 319 */       if (this.bufsize < count) {
/* 320 */         a = b;
/* 321 */         b = (byte)(line.charAt(i++) - ' ' & 0x3F);
/* 322 */         this.buffer[(this.bufsize++)] = (byte)(a << 4 & 0xF0 | b >>> 2 & 0xF);
/*     */       }
/*     */ 
/* 326 */       if (this.bufsize < count) {
/* 327 */         a = b;
/* 328 */         b = (byte)(line.charAt(i++) - ' ' & 0x3F);
/* 329 */         this.buffer[(this.bufsize++)] = (byte)(a << 6 & 0xC0 | b & 0x3F);
/*     */       }
/*     */     }
/* 332 */     return true;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.util.UUDecoderStream
 * JD-Core Version:    0.6.1
 */