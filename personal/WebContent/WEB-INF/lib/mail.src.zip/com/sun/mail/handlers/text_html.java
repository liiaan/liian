/*    */ package com.sun.mail.handlers;
/*    */ 
/*    */ import javax.activation.ActivationDataFlavor;
/*    */ 
/*    */ public class text_html extends text_plain
/*    */ {
/* 46 */   private static ActivationDataFlavor myDF = new ActivationDataFlavor(String.class, "text/html", "HTML String");
/*    */ 
/*    */   protected ActivationDataFlavor getDF()
/*    */   {
/* 52 */     return myDF;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.handlers.text_html
 * JD-Core Version:    0.6.1
 */