/*      */ package com.sun.mail.imap;
/*      */ 
/*      */ import com.sun.mail.iap.BadCommandException;
/*      */ import com.sun.mail.iap.CommandFailedException;
/*      */ import com.sun.mail.iap.ConnectionException;
/*      */ import com.sun.mail.iap.ProtocolException;
/*      */ import com.sun.mail.iap.Response;
/*      */ import com.sun.mail.iap.ResponseHandler;
/*      */ import com.sun.mail.imap.protocol.FetchResponse;
/*      */ import com.sun.mail.imap.protocol.IMAPProtocol;
/*      */ import com.sun.mail.imap.protocol.IMAPResponse;
/*      */ import com.sun.mail.imap.protocol.ListInfo;
/*      */ import com.sun.mail.imap.protocol.MailboxInfo;
/*      */ import com.sun.mail.imap.protocol.MessageSet;
/*      */ import com.sun.mail.imap.protocol.Status;
/*      */ import com.sun.mail.imap.protocol.UID;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.util.Date;
/*      */ import java.util.Hashtable;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Vector;
/*      */ import javax.mail.FetchProfile;
/*      */ import javax.mail.FetchProfile.Item;
/*      */ import javax.mail.Flags;
/*      */ import javax.mail.Flags.Flag;
/*      */ import javax.mail.Folder;
/*      */ import javax.mail.FolderClosedException;
/*      */ import javax.mail.FolderNotFoundException;
/*      */ import javax.mail.Message;
/*      */ import javax.mail.MessageRemovedException;
/*      */ import javax.mail.MessagingException;
/*      */ import javax.mail.Quota;
/*      */ import javax.mail.Session;
/*      */ import javax.mail.StoreClosedException;
/*      */ import javax.mail.UIDFolder;
/*      */ import javax.mail.UIDFolder.FetchProfileItem;
/*      */ import javax.mail.event.MessageCountListener;
/*      */ import javax.mail.internet.MimeMessage;
/*      */ import javax.mail.search.FlagTerm;
/*      */ import javax.mail.search.SearchException;
/*      */ import javax.mail.search.SearchTerm;
/*      */ 
/*      */ public class IMAPFolder extends Folder
/*      */   implements UIDFolder, ResponseHandler
/*      */ {
/*      */   protected String fullName;
/*      */   protected String name;
/*      */   protected int type;
/*      */   protected char separator;
/*      */   protected Flags availableFlags;
/*      */   protected Flags permanentFlags;
/*  161 */   protected boolean exists = false;
/*  162 */   protected boolean isNamespace = false;
/*      */   protected String[] attributes;
/*      */   protected IMAPProtocol protocol;
/*      */   protected MessageCache messageCache;
/*  168 */   protected final Object messageCacheLock = new Object();
/*      */   protected Hashtable uidTable;
/*      */   protected static final char UNKNOWN_SEPARATOR = '����';
/*  180 */   private boolean opened = false;
/*      */ 
/*  192 */   private boolean reallyClosed = true;
/*      */   private static final int RUNNING = 0;
/*      */   private static final int IDLE = 1;
/*      */   private static final int ABORTING = 2;
/*  244 */   private int idleState = 0;
/*      */ 
/*  246 */   private int total = -1;
/*      */ 
/*  248 */   private int recent = -1;
/*  249 */   private int realTotal = -1;
/*      */ 
/*  251 */   private long uidvalidity = -1L;
/*  252 */   private long uidnext = -1L;
/*  253 */   private boolean doExpungeNotification = true;
/*      */ 
/*  255 */   private Status cachedStatus = null;
/*  256 */   private long cachedStatusTime = 0L;
/*      */ 
/*  258 */   private boolean hasMessageCountListener = false;
/*      */ 
/*  260 */   private boolean debug = false;
/*      */   private PrintStream out;
/*      */   private boolean connectionPoolDebug;
/*      */ 
/*      */   protected IMAPFolder(String fullName, char separator, IMAPStore store)
/*      */   {
/*  316 */     super(store);
/*  317 */     if (fullName == null)
/*  318 */       throw new NullPointerException("Folder name is null");
/*  319 */     this.fullName = fullName;
/*  320 */     this.separator = separator;
/*  321 */     this.debug = store.getSession().getDebug();
/*  322 */     this.connectionPoolDebug = store.getConnectionPoolDebug();
/*  323 */     this.out = store.getSession().getDebugOut();
/*  324 */     if (this.out == null) {
/*  325 */       this.out = System.out;
/*      */     }
/*      */ 
/*  338 */     this.isNamespace = false;
/*  339 */     if ((separator != 65535) && (separator != 0)) {
/*  340 */       int i = this.fullName.indexOf(separator);
/*  341 */       if ((i > 0) && (i == this.fullName.length() - 1)) {
/*  342 */         this.fullName = this.fullName.substring(0, i);
/*  343 */         this.isNamespace = true;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected IMAPFolder(String fullName, char separator, IMAPStore store, boolean isNamespace)
/*      */   {
/*  358 */     this(fullName, separator, store);
/*  359 */     this.isNamespace = isNamespace;
/*      */   }
/*      */ 
/*      */   protected IMAPFolder(ListInfo li, IMAPStore store)
/*      */   {
/*  366 */     this(li.name, li.separator, store);
/*      */ 
/*  368 */     if (li.hasInferiors)
/*  369 */       this.type |= 2;
/*  370 */     if (li.canOpen)
/*  371 */       this.type |= 1;
/*  372 */     this.exists = true;
/*  373 */     this.attributes = li.attrs;
/*      */   }
/*      */ 
/*      */   private void checkExists()
/*      */     throws MessagingException
/*      */   {
/*  385 */     if ((!this.exists) && (!exists()))
/*  386 */       throw new FolderNotFoundException(this, this.fullName + " not found");
/*      */   }
/*      */ 
/*      */   private void checkClosed()
/*      */   {
/*  395 */     if (this.opened)
/*  396 */       throw new IllegalStateException("This operation is not allowed on an open folder");
/*      */   }
/*      */ 
/*      */   private void checkOpened()
/*      */     throws FolderClosedException
/*      */   {
/*  406 */     assert (Thread.holdsLock(this));
/*  407 */     if (!this.opened) {
/*  408 */       if (this.reallyClosed) {
/*  409 */         throw new IllegalStateException("This operation is not allowed on a closed folder");
/*      */       }
/*      */ 
/*  413 */       throw new FolderClosedException(this, "Lost folder connection to server");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void checkRange(int msgno)
/*      */     throws MessagingException
/*      */   {
/*  426 */     if (msgno < 1) {
/*  427 */       throw new IndexOutOfBoundsException("message number < 1");
/*      */     }
/*  429 */     if (msgno <= this.total) {
/*  430 */       return;
/*      */     }
/*      */ 
/*  435 */     synchronized (this.messageCacheLock) {
/*      */       try {
/*  437 */         keepConnectionAlive(false);
/*      */       }
/*      */       catch (ConnectionException cex) {
/*  440 */         throw new FolderClosedException(this, cex.getMessage());
/*      */       } catch (ProtocolException pex) {
/*  442 */         throw new MessagingException(pex.getMessage(), pex);
/*      */       }
/*      */     }
/*      */ 
/*  446 */     if (msgno > this.total)
/*  447 */       throw new IndexOutOfBoundsException(msgno + " > " + this.total);
/*      */   }
/*      */ 
/*      */   private void checkFlags(Flags flags)
/*      */     throws MessagingException
/*      */   {
/*  455 */     assert (Thread.holdsLock(this));
/*  456 */     if (this.mode != 2)
/*  457 */       throw new IllegalStateException("Cannot change flags on READ_ONLY folder: " + this.fullName);
/*      */   }
/*      */ 
/*      */   public synchronized String getName()
/*      */   {
/*  475 */     if (this.name == null)
/*      */       try {
/*  477 */         this.name = this.fullName.substring(this.fullName.lastIndexOf(getSeparator()) + 1);
/*      */       }
/*      */       catch (MessagingException mex)
/*      */       {
/*      */       }
/*  482 */     return this.name;
/*      */   }
/*      */ 
/*      */   public synchronized String getFullName()
/*      */   {
/*  489 */     return this.fullName;
/*      */   }
/*      */ 
/*      */   public synchronized Folder getParent()
/*      */     throws MessagingException
/*      */   {
/*  496 */     char c = getSeparator();
/*      */     int index;
/*  498 */     if ((index = this.fullName.lastIndexOf(c)) != -1) {
/*  499 */       return new IMAPFolder(this.fullName.substring(0, index), c, (IMAPStore)this.store);
/*      */     }
/*      */ 
/*  502 */     return new DefaultFolder((IMAPStore)this.store);
/*      */   }
/*      */ 
/*      */   public synchronized boolean exists()
/*      */     throws MessagingException
/*      */   {
/*  510 */     ListInfo[] li = null;
/*      */     String lname;
/*      */     final String lname;
/*  512 */     if ((this.isNamespace) && (this.separator != 0))
/*  513 */       lname = this.fullName + this.separator;
/*      */     else {
/*  515 */       lname = this.fullName;
/*      */     }
/*  517 */     li = (ListInfo[])doCommand(new ProtocolCommand() { private final String val$lname;
/*      */ 
/*  519 */       public Object doCommand(IMAPProtocol p) throws ProtocolException { return p.list("", lname); }
/*      */ 
/*      */     });
/*  523 */     if (li != null) {
/*  524 */       int i = findName(li, lname);
/*  525 */       this.fullName = li[i].name;
/*  526 */       this.separator = li[i].separator;
/*  527 */       int len = this.fullName.length();
/*  528 */       if ((this.separator != 0) && (len > 0) && (this.fullName.charAt(len - 1) == this.separator))
/*      */       {
/*  530 */         this.fullName = this.fullName.substring(0, len - 1);
/*      */       }
/*  532 */       this.type = 0;
/*  533 */       if (li[i].hasInferiors)
/*  534 */         this.type |= 2;
/*  535 */       if (li[i].canOpen)
/*  536 */         this.type |= 1;
/*  537 */       this.exists = true;
/*  538 */       this.attributes = li[i].attrs;
/*      */     } else {
/*  540 */       this.exists = this.opened;
/*  541 */       this.attributes = null;
/*      */     }
/*      */ 
/*  544 */     return this.exists;
/*      */   }
/*      */ 
/*      */   private int findName(ListInfo[] li, String lname)
/*      */   {
/*  555 */     for (int i = 0; (i < li.length) && 
/*  556 */       (!li[i].name.equals(lname)); i++);
/*  559 */     if (i >= li.length)
/*      */     {
/*  563 */       i = 0;
/*      */     }
/*  565 */     return i;
/*      */   }
/*      */ 
/*      */   public Folder[] list(String pattern)
/*      */     throws MessagingException
/*      */   {
/*  572 */     return doList(pattern, false);
/*      */   }
/*      */ 
/*      */   public Folder[] listSubscribed(String pattern)
/*      */     throws MessagingException
/*      */   {
/*  579 */     return doList(pattern, true);
/*      */   }
/*      */ 
/*      */   private synchronized Folder[] doList(final String pattern, final boolean subscribed) throws MessagingException
/*      */   {
/*  584 */     checkExists();
/*      */ 
/*  587 */     if ((this.attributes != null) && (!isDirectory())) {
/*  588 */       return new Folder[0];
/*      */     }
/*  590 */     final char c = getSeparator();
/*      */ 
/*  592 */     ListInfo[] li = (ListInfo[])doCommandIgnoreFailure(new ProtocolCommand() { private final boolean val$subscribed;
/*      */       private final char val$c;
/*      */       private final String val$pattern;
/*      */ 
/*  596 */       public Object doCommand(IMAPProtocol p) throws ProtocolException { if (subscribed) {
/*  597 */           return p.lsub("", IMAPFolder.this.fullName + c + pattern);
/*      */         }
/*  599 */         return p.list("", IMAPFolder.this.fullName + c + pattern);
/*      */       }
/*      */     });
/*  603 */     if (li == null) {
/*  604 */       return new Folder[0];
/*      */     }
/*      */ 
/*  617 */     int start = 0;
/*      */ 
/*  619 */     if ((li.length > 0) && (li[0].name.equals(this.fullName + c))) {
/*  620 */       start = 1;
/*      */     }
/*  622 */     IMAPFolder[] folders = new IMAPFolder[li.length - start];
/*  623 */     for (int i = start; i < li.length; i++)
/*  624 */       folders[(i - start)] = new IMAPFolder(li[i], (IMAPStore)this.store);
/*  625 */     return folders;
/*      */   }
/*      */ 
/*      */   public synchronized char getSeparator()
/*      */     throws MessagingException
/*      */   {
/*  632 */     if (this.separator == 65535) {
/*  633 */       ListInfo[] li = null;
/*      */ 
/*  635 */       li = (ListInfo[])doCommand(new ProtocolCommand()
/*      */       {
/*      */         public Object doCommand(IMAPProtocol p)
/*      */           throws ProtocolException
/*      */         {
/*  640 */           if (p.isREV1()) {
/*  641 */             return p.list(IMAPFolder.this.fullName, "");
/*      */           }
/*      */ 
/*  644 */           return p.list("", IMAPFolder.this.fullName);
/*      */         }
/*      */       });
/*  648 */       if (li != null)
/*  649 */         this.separator = li[0].separator;
/*      */       else
/*  651 */         this.separator = '/';
/*      */     }
/*  653 */     return this.separator;
/*      */   }
/*      */ 
/*      */   public synchronized int getType()
/*      */     throws MessagingException
/*      */   {
/*  660 */     if (this.opened)
/*      */     {
/*  662 */       if (this.attributes == null)
/*  663 */         exists();
/*      */     }
/*  665 */     else checkExists();
/*      */ 
/*  667 */     return this.type;
/*      */   }
/*      */ 
/*      */   public synchronized boolean isSubscribed()
/*      */   {
/*  674 */     ListInfo[] li = null;
/*      */     String lname;
/*      */     final String lname;
/*  676 */     if ((this.isNamespace) && (this.separator != 0))
/*  677 */       lname = this.fullName + this.separator;
/*      */     else
/*  679 */       lname = this.fullName;
/*      */     try
/*      */     {
/*  682 */       li = (ListInfo[])doProtocolCommand(new ProtocolCommand() {
/*      */         private final String val$lname;
/*      */ 
/*  685 */         public Object doCommand(IMAPProtocol p) throws ProtocolException { return p.lsub("", lname); }
/*      */       });
/*      */     }
/*      */     catch (ProtocolException pex)
/*      */     {
/*      */     }
/*  691 */     if (li != null) {
/*  692 */       int i = findName(li, lname);
/*  693 */       return li[i].canOpen;
/*      */     }
/*  695 */     return false;
/*      */   }
/*      */ 
/*      */   public synchronized void setSubscribed(final boolean subscribe)
/*      */     throws MessagingException
/*      */   {
/*  703 */     doCommandIgnoreFailure(new ProtocolCommand() { private final boolean val$subscribe;
/*      */ 
/*  705 */       public Object doCommand(IMAPProtocol p) throws ProtocolException { if (subscribe)
/*  706 */           p.subscribe(IMAPFolder.this.fullName);
/*      */         else
/*  708 */           p.unsubscribe(IMAPFolder.this.fullName);
/*  709 */         return null;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public synchronized boolean create(final int type)
/*      */     throws MessagingException
/*      */   {
/*  720 */     char c = '\000';
/*  721 */     if ((type & 0x1) == 0)
/*  722 */       c = getSeparator();
/*  723 */     final char sep = c;
/*  724 */     Object ret = doCommandIgnoreFailure(new ProtocolCommand() { private final int val$type;
/*      */       private final char val$sep;
/*      */ 
/*  727 */       public Object doCommand(IMAPProtocol p) throws ProtocolException { if ((type & 0x1) == 0) {
/*  728 */           p.create(IMAPFolder.this.fullName + sep);
/*      */         } else {
/*  730 */           p.create(IMAPFolder.this.fullName);
/*      */ 
/*  736 */           if ((type & 0x2) != 0)
/*      */           {
/*  739 */             ListInfo[] li = p.list("", IMAPFolder.this.fullName);
/*  740 */             if ((li != null) && (!li[0].hasInferiors))
/*      */             {
/*  743 */               p.delete(IMAPFolder.this.fullName);
/*  744 */               throw new ProtocolException("Unsupported type");
/*      */             }
/*      */           }
/*      */         }
/*  748 */         return Boolean.TRUE;
/*      */       }
/*      */     });
/*  752 */     if (ret == null) {
/*  753 */       return false;
/*      */     }
/*      */ 
/*  758 */     boolean retb = exists();
/*  759 */     if (retb)
/*  760 */       notifyFolderListeners(1);
/*  761 */     return retb;
/*      */   }
/*      */ 
/*      */   public synchronized boolean hasNewMessages()
/*      */     throws MessagingException
/*      */   {
/*  768 */     if (this.opened)
/*      */     {
/*  770 */       synchronized (this.messageCacheLock)
/*      */       {
/*      */         try {
/*  773 */           keepConnectionAlive(true);
/*      */         } catch (ConnectionException cex) {
/*  775 */           throw new FolderClosedException(this, cex.getMessage());
/*      */         } catch (ProtocolException pex) {
/*  777 */           throw new MessagingException(pex.getMessage(), pex);
/*      */         }
/*  779 */         return this.recent > 0;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  786 */     ListInfo[] li = null;
/*      */     String lname;
/*      */     final String lname;
/*  788 */     if ((this.isNamespace) && (this.separator != 0))
/*  789 */       lname = this.fullName + this.separator;
/*      */     else
/*  791 */       lname = this.fullName;
/*  792 */     li = (ListInfo[])doCommandIgnoreFailure(new ProtocolCommand() { private final String val$lname;
/*      */ 
/*  794 */       public Object doCommand(IMAPProtocol p) throws ProtocolException { return p.list("", lname); }
/*      */ 
/*      */     });
/*  799 */     if (li == null) {
/*  800 */       throw new FolderNotFoundException(this, this.fullName + " not found");
/*      */     }
/*  802 */     int i = findName(li, lname);
/*  803 */     if (li[i].changeState == 1)
/*  804 */       return true;
/*  805 */     if (li[i].changeState == 2) {
/*  806 */       return false;
/*      */     }
/*      */     try
/*      */     {
/*  810 */       Status status = getStatus();
/*  811 */       if (status.recent > 0) {
/*  812 */         return true;
/*      */       }
/*  814 */       return false;
/*      */     }
/*      */     catch (BadCommandException bex) {
/*  817 */       return false;
/*      */     } catch (ConnectionException cex) {
/*  819 */       throw new StoreClosedException(this.store, cex.getMessage());
/*      */     } catch (ProtocolException pex) {
/*  821 */       throw new MessagingException(pex.getMessage(), pex);
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized Folder getFolder(String name)
/*      */     throws MessagingException
/*      */   {
/*  832 */     if ((this.attributes != null) && (!isDirectory())) {
/*  833 */       throw new MessagingException("Cannot contain subfolders");
/*      */     }
/*  835 */     char c = getSeparator();
/*  836 */     return new IMAPFolder(this.fullName + c + name, c, (IMAPStore)this.store);
/*      */   }
/*      */ 
/*      */   public synchronized boolean delete(boolean recurse)
/*      */     throws MessagingException
/*      */   {
/*  844 */     checkClosed();
/*      */ 
/*  846 */     if (recurse)
/*      */     {
/*  848 */       Folder[] f = list();
/*  849 */       for (int i = 0; i < f.length; i++) {
/*  850 */         f[i].delete(recurse);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  855 */     Object ret = doCommandIgnoreFailure(new ProtocolCommand() {
/*      */       public Object doCommand(IMAPProtocol p) throws ProtocolException {
/*  857 */         p.delete(IMAPFolder.this.fullName);
/*  858 */         return Boolean.TRUE;
/*      */       }
/*      */     });
/*  862 */     if (ret == null)
/*      */     {
/*  864 */       return false;
/*      */     }
/*      */ 
/*  867 */     this.exists = false;
/*  868 */     this.attributes = null;
/*      */ 
/*  871 */     notifyFolderListeners(2);
/*  872 */     return true;
/*      */   }
/*      */ 
/*      */   public synchronized boolean renameTo(final Folder f)
/*      */     throws MessagingException
/*      */   {
/*  880 */     checkClosed();
/*  881 */     checkExists();
/*  882 */     if (f.getStore() != this.store) {
/*  883 */       throw new MessagingException("Can't rename across Stores");
/*      */     }
/*      */ 
/*  886 */     Object ret = doCommandIgnoreFailure(new ProtocolCommand() { private final Folder val$f;
/*      */ 
/*  888 */       public Object doCommand(IMAPProtocol p) throws ProtocolException { p.rename(IMAPFolder.this.fullName, f.getFullName());
/*  889 */         return Boolean.TRUE;
/*      */       }
/*      */     });
/*  893 */     if (ret == null) {
/*  894 */       return false;
/*      */     }
/*  896 */     this.exists = false;
/*  897 */     this.attributes = null;
/*  898 */     notifyFolderRenamedListeners(f);
/*  899 */     return true; } 
/*      */   // ERROR //
/*      */   public synchronized void open(int mode) throws MessagingException { // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: invokespecial 129	com/sun/mail/imap/IMAPFolder:checkClosed	()V
/*      */     //   4: aconst_null
/*      */     //   5: astore_2
/*      */     //   6: aload_0
/*      */     //   7: aload_0
/*      */     //   8: getfield 89	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
/*      */     //   11: checkcast 90	com/sun/mail/imap/IMAPStore
/*      */     //   14: aload_0
/*      */     //   15: invokevirtual 139	com/sun/mail/imap/IMAPStore:getProtocol	(Lcom/sun/mail/imap/IMAPFolder;)Lcom/sun/mail/imap/protocol/IMAPProtocol;
/*      */     //   18: putfield 140	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
/*      */     //   21: aload_0
/*      */     //   22: getfield 12	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
/*      */     //   25: dup
/*      */     //   26: astore_3
/*      */     //   27: monitorenter
/*      */     //   28: aload_0
/*      */     //   29: getfield 140	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
/*      */     //   32: aload_0
/*      */     //   33: invokevirtual 141	com/sun/mail/imap/protocol/IMAPProtocol:addResponseHandler	(Lcom/sun/mail/iap/ResponseHandler;)V
/*      */     //   36: iload_1
/*      */     //   37: iconst_1
/*      */     //   38: if_icmpne +18 -> 56
/*      */     //   41: aload_0
/*      */     //   42: getfield 140	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
/*      */     //   45: aload_0
/*      */     //   46: getfield 30	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
/*      */     //   49: invokevirtual 142	com/sun/mail/imap/protocol/IMAPProtocol:examine	(Ljava/lang/String;)Lcom/sun/mail/imap/protocol/MailboxInfo;
/*      */     //   52: astore_2
/*      */     //   53: goto +15 -> 68
/*      */     //   56: aload_0
/*      */     //   57: getfield 140	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
/*      */     //   60: aload_0
/*      */     //   61: getfield 30	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
/*      */     //   64: invokevirtual 143	com/sun/mail/imap/protocol/IMAPProtocol:select	(Ljava/lang/String;)Lcom/sun/mail/imap/protocol/MailboxInfo;
/*      */     //   67: astore_2
/*      */     //   68: goto +141 -> 209
/*      */     //   71: astore 4
/*      */     //   73: aload_0
/*      */     //   74: invokespecial 102	com/sun/mail/imap/IMAPFolder:checkExists	()V
/*      */     //   77: aload_0
/*      */     //   78: getfield 47	com/sun/mail/imap/IMAPFolder:type	I
/*      */     //   81: iconst_1
/*      */     //   82: iand
/*      */     //   83: ifne +13 -> 96
/*      */     //   86: new 77	javax/mail/MessagingException
/*      */     //   89: dup
/*      */     //   90: ldc 145
/*      */     //   92: invokespecial 128	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
/*      */     //   95: athrow
/*      */     //   96: new 77	javax/mail/MessagingException
/*      */     //   99: dup
/*      */     //   100: aload 4
/*      */     //   102: invokevirtual 146	com/sun/mail/iap/CommandFailedException:getMessage	()Ljava/lang/String;
/*      */     //   105: aload 4
/*      */     //   107: invokespecial 79	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
/*      */     //   110: athrow
/*      */     //   111: astore 5
/*      */     //   113: aload_0
/*      */     //   114: iconst_0
/*      */     //   115: putfield 8	com/sun/mail/imap/IMAPFolder:exists	Z
/*      */     //   118: aload_0
/*      */     //   119: aconst_null
/*      */     //   120: putfield 50	com/sun/mail/imap/IMAPFolder:attributes	[Ljava/lang/String;
/*      */     //   123: aload_0
/*      */     //   124: iconst_0
/*      */     //   125: putfield 47	com/sun/mail/imap/IMAPFolder:type	I
/*      */     //   128: aload_0
/*      */     //   129: iconst_1
/*      */     //   130: invokespecial 147	com/sun/mail/imap/IMAPFolder:releaseProtocol	(Z)V
/*      */     //   133: aload 5
/*      */     //   135: athrow
/*      */     //   136: astore 4
/*      */     //   138: aload_0
/*      */     //   139: getfield 140	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
/*      */     //   142: invokevirtual 148	com/sun/mail/imap/protocol/IMAPProtocol:logout	()V
/*      */     //   145: aload_0
/*      */     //   146: iconst_0
/*      */     //   147: invokespecial 147	com/sun/mail/imap/IMAPFolder:releaseProtocol	(Z)V
/*      */     //   150: new 77	javax/mail/MessagingException
/*      */     //   153: dup
/*      */     //   154: aload 4
/*      */     //   156: invokevirtual 78	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
/*      */     //   159: aload 4
/*      */     //   161: invokespecial 79	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
/*      */     //   164: athrow
/*      */     //   165: astore 5
/*      */     //   167: aload_0
/*      */     //   168: iconst_0
/*      */     //   169: invokespecial 147	com/sun/mail/imap/IMAPFolder:releaseProtocol	(Z)V
/*      */     //   172: new 77	javax/mail/MessagingException
/*      */     //   175: dup
/*      */     //   176: aload 4
/*      */     //   178: invokevirtual 78	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
/*      */     //   181: aload 4
/*      */     //   183: invokespecial 79	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
/*      */     //   186: athrow
/*      */     //   187: astore 6
/*      */     //   189: aload_0
/*      */     //   190: iconst_0
/*      */     //   191: invokespecial 147	com/sun/mail/imap/IMAPFolder:releaseProtocol	(Z)V
/*      */     //   194: new 77	javax/mail/MessagingException
/*      */     //   197: dup
/*      */     //   198: aload 4
/*      */     //   200: invokevirtual 78	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
/*      */     //   203: aload 4
/*      */     //   205: invokespecial 79	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
/*      */     //   208: athrow
/*      */     //   209: aload_2
/*      */     //   210: getfield 149	com/sun/mail/imap/protocol/MailboxInfo:mode	I
/*      */     //   213: iload_1
/*      */     //   214: if_icmpeq +116 -> 330
/*      */     //   217: iload_1
/*      */     //   218: iconst_2
/*      */     //   219: if_icmpne +27 -> 246
/*      */     //   222: aload_2
/*      */     //   223: getfield 149	com/sun/mail/imap/protocol/MailboxInfo:mode	I
/*      */     //   226: iconst_1
/*      */     //   227: if_icmpne +19 -> 246
/*      */     //   230: aload_0
/*      */     //   231: getfield 89	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
/*      */     //   234: checkcast 90	com/sun/mail/imap/IMAPStore
/*      */     //   237: invokevirtual 150	com/sun/mail/imap/IMAPStore:allowReadOnlySelect	()Z
/*      */     //   240: ifeq +6 -> 246
/*      */     //   243: goto +87 -> 330
/*      */     //   246: aload_0
/*      */     //   247: getfield 140	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
/*      */     //   250: invokevirtual 151	com/sun/mail/imap/protocol/IMAPProtocol:close	()V
/*      */     //   253: aload_0
/*      */     //   254: iconst_1
/*      */     //   255: invokespecial 147	com/sun/mail/imap/IMAPFolder:releaseProtocol	(Z)V
/*      */     //   258: new 152	javax/mail/ReadOnlyFolderException
/*      */     //   261: dup
/*      */     //   262: aload_0
/*      */     //   263: ldc 153
/*      */     //   265: invokespecial 154	javax/mail/ReadOnlyFolderException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
/*      */     //   268: athrow
/*      */     //   269: astore 4
/*      */     //   271: aload_0
/*      */     //   272: getfield 140	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
/*      */     //   275: invokevirtual 148	com/sun/mail/imap/protocol/IMAPProtocol:logout	()V
/*      */     //   278: aload_0
/*      */     //   279: iconst_0
/*      */     //   280: invokespecial 147	com/sun/mail/imap/IMAPFolder:releaseProtocol	(Z)V
/*      */     //   283: goto +23 -> 306
/*      */     //   286: astore 5
/*      */     //   288: aload_0
/*      */     //   289: iconst_0
/*      */     //   290: invokespecial 147	com/sun/mail/imap/IMAPFolder:releaseProtocol	(Z)V
/*      */     //   293: goto +13 -> 306
/*      */     //   296: astore 7
/*      */     //   298: aload_0
/*      */     //   299: iconst_0
/*      */     //   300: invokespecial 147	com/sun/mail/imap/IMAPFolder:releaseProtocol	(Z)V
/*      */     //   303: aload 7
/*      */     //   305: athrow
/*      */     //   306: new 152	javax/mail/ReadOnlyFolderException
/*      */     //   309: dup
/*      */     //   310: aload_0
/*      */     //   311: ldc 153
/*      */     //   313: invokespecial 154	javax/mail/ReadOnlyFolderException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
/*      */     //   316: athrow
/*      */     //   317: astore 8
/*      */     //   319: new 152	javax/mail/ReadOnlyFolderException
/*      */     //   322: dup
/*      */     //   323: aload_0
/*      */     //   324: ldc 153
/*      */     //   326: invokespecial 154	javax/mail/ReadOnlyFolderException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
/*      */     //   329: athrow
/*      */     //   330: aload_0
/*      */     //   331: iconst_1
/*      */     //   332: putfield 13	com/sun/mail/imap/IMAPFolder:opened	Z
/*      */     //   335: aload_0
/*      */     //   336: iconst_0
/*      */     //   337: putfield 14	com/sun/mail/imap/IMAPFolder:reallyClosed	Z
/*      */     //   340: aload_0
/*      */     //   341: aload_2
/*      */     //   342: getfield 149	com/sun/mail/imap/protocol/MailboxInfo:mode	I
/*      */     //   345: putfield 82	com/sun/mail/imap/IMAPFolder:mode	I
/*      */     //   348: aload_0
/*      */     //   349: aload_2
/*      */     //   350: getfield 155	com/sun/mail/imap/protocol/MailboxInfo:availableFlags	Ljavax/mail/Flags;
/*      */     //   353: putfield 156	com/sun/mail/imap/IMAPFolder:availableFlags	Ljavax/mail/Flags;
/*      */     //   356: aload_0
/*      */     //   357: aload_2
/*      */     //   358: getfield 157	com/sun/mail/imap/protocol/MailboxInfo:permanentFlags	Ljavax/mail/Flags;
/*      */     //   361: putfield 158	com/sun/mail/imap/IMAPFolder:permanentFlags	Ljavax/mail/Flags;
/*      */     //   364: aload_0
/*      */     //   365: aload_0
/*      */     //   366: aload_2
/*      */     //   367: getfield 159	com/sun/mail/imap/protocol/MailboxInfo:total	I
/*      */     //   370: dup_x1
/*      */     //   371: putfield 17	com/sun/mail/imap/IMAPFolder:realTotal	I
/*      */     //   374: putfield 15	com/sun/mail/imap/IMAPFolder:total	I
/*      */     //   377: aload_0
/*      */     //   378: aload_2
/*      */     //   379: getfield 160	com/sun/mail/imap/protocol/MailboxInfo:recent	I
/*      */     //   382: putfield 16	com/sun/mail/imap/IMAPFolder:recent	I
/*      */     //   385: aload_0
/*      */     //   386: aload_2
/*      */     //   387: getfield 161	com/sun/mail/imap/protocol/MailboxInfo:uidvalidity	J
/*      */     //   390: putfield 20	com/sun/mail/imap/IMAPFolder:uidvalidity	J
/*      */     //   393: aload_0
/*      */     //   394: aload_2
/*      */     //   395: getfield 162	com/sun/mail/imap/protocol/MailboxInfo:uidnext	J
/*      */     //   398: putfield 21	com/sun/mail/imap/IMAPFolder:uidnext	J
/*      */     //   401: aload_0
/*      */     //   402: new 163	com/sun/mail/imap/MessageCache
/*      */     //   405: dup
/*      */     //   406: aload_0
/*      */     //   407: aload_0
/*      */     //   408: getfield 89	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
/*      */     //   411: checkcast 90	com/sun/mail/imap/IMAPStore
/*      */     //   414: aload_0
/*      */     //   415: getfield 15	com/sun/mail/imap/IMAPFolder:total	I
/*      */     //   418: invokespecial 164	com/sun/mail/imap/MessageCache:<init>	(Lcom/sun/mail/imap/IMAPFolder;Lcom/sun/mail/imap/IMAPStore;I)V
/*      */     //   421: putfield 165	com/sun/mail/imap/IMAPFolder:messageCache	Lcom/sun/mail/imap/MessageCache;
/*      */     //   424: aload_3
/*      */     //   425: monitorexit
/*      */     //   426: goto +10 -> 436
/*      */     //   429: astore 9
/*      */     //   431: aload_3
/*      */     //   432: monitorexit
/*      */     //   433: aload 9
/*      */     //   435: athrow
/*      */     //   436: aload_0
/*      */     //   437: iconst_1
/*      */     //   438: putfield 8	com/sun/mail/imap/IMAPFolder:exists	Z
/*      */     //   441: aload_0
/*      */     //   442: aconst_null
/*      */     //   443: putfield 50	com/sun/mail/imap/IMAPFolder:attributes	[Ljava/lang/String;
/*      */     //   446: aload_0
/*      */     //   447: iconst_1
/*      */     //   448: putfield 47	com/sun/mail/imap/IMAPFolder:type	I
/*      */     //   451: aload_0
/*      */     //   452: iconst_1
/*      */     //   453: invokevirtual 166	com/sun/mail/imap/IMAPFolder:notifyConnectionListeners	(I)V
/*      */     //   456: return
/*      */     //
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   36	68	71	com/sun/mail/iap/CommandFailedException
/*      */     //   73	113	111	finally
/*      */     //   36	68	136	com/sun/mail/iap/ProtocolException
/*      */     //   138	145	165	com/sun/mail/iap/ProtocolException
/*      */     //   138	145	187	finally
/*      */     //   165	167	187	finally
/*      */     //   187	189	187	finally
/*      */     //   246	258	269	com/sun/mail/iap/ProtocolException
/*      */     //   271	278	286	com/sun/mail/iap/ProtocolException
/*      */     //   271	278	296	finally
/*      */     //   286	288	296	finally
/*      */     //   296	298	296	finally
/*      */     //   246	258	317	finally
/*      */     //   269	306	317	finally
/*      */     //   317	319	317	finally
/*      */     //   28	426	429	finally
/*      */     //   429	433	429	finally } 
/* 1019 */   public synchronized void fetch(Message[] msgs, FetchProfile fp) throws MessagingException { checkOpened();
/* 1020 */     IMAPMessage.fetch(this, msgs, fp);
/*      */   }
/*      */ 
/*      */   public synchronized void setFlags(Message[] msgs, Flags flag, boolean value)
/*      */     throws MessagingException
/*      */   {
/* 1028 */     checkOpened();
/* 1029 */     checkFlags(flag);
/*      */ 
/* 1031 */     if (msgs.length == 0) {
/* 1032 */       return;
/*      */     }
/* 1034 */     synchronized (this.messageCacheLock) {
/*      */       try {
/* 1036 */         IMAPProtocol p = getProtocol();
/* 1037 */         MessageSet[] ms = Utility.toMessageSet(msgs, null);
/* 1038 */         if (ms == null) {
/* 1039 */           throw new MessageRemovedException("Messages have been removed");
/*      */         }
/* 1041 */         p.storeFlags(ms, flag, value);
/*      */       } catch (ConnectionException cex) {
/* 1043 */         throw new FolderClosedException(this, cex.getMessage());
/*      */       } catch (ProtocolException pex) {
/* 1045 */         throw new MessagingException(pex.getMessage(), pex);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void close(boolean expunge)
/*      */     throws MessagingException
/*      */   {
/* 1054 */     close(expunge, false);
/*      */   }
/*      */ 
/*      */   public synchronized void forceClose()
/*      */     throws MessagingException
/*      */   {
/* 1061 */     close(false, true);
/*      */   }
/*      */ 
/*      */   private void close(boolean expunge, boolean force)
/*      */     throws MessagingException
/*      */   {
/* 1069 */     assert (Thread.holdsLock(this));
/* 1070 */     synchronized (this.messageCacheLock)
/*      */     {
/* 1077 */       if ((!this.opened) && (this.reallyClosed)) {
/* 1078 */         throw new IllegalStateException("This operation is not allowed on a closed folder");
/*      */       }
/*      */ 
/* 1082 */       this.reallyClosed = true;
/*      */ 
/* 1088 */       if (!this.opened)
/* 1089 */         return;
/*      */       try
/*      */       {
/* 1092 */         waitIfIdle();
/* 1093 */         if (force) {
/* 1094 */           if (this.debug) {
/* 1095 */             this.out.println("DEBUG: forcing folder " + this.fullName + " to close");
/*      */           }
/* 1097 */           if (this.protocol != null)
/* 1098 */             this.protocol.disconnect();
/* 1099 */         } else if (((IMAPStore)this.store).isConnectionPoolFull())
/*      */         {
/* 1101 */           if (this.debug) {
/* 1102 */             this.out.println("DEBUG: pool is full, not adding an Authenticated connection");
/*      */           }
/*      */ 
/* 1106 */           if (expunge) {
/* 1107 */             this.protocol.close();
/*      */           }
/* 1109 */           if (this.protocol != null) {
/* 1110 */             this.protocol.logout();
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/* 1115 */           if ((!expunge) && (this.mode == 2)) {
/*      */             try {
/* 1117 */               mi = this.protocol.examine(this.fullName);
/*      */             }
/*      */             catch (ProtocolException pex2)
/*      */             {
/*      */               MailboxInfo mi;
/* 1119 */               if (this.protocol != null)
/* 1120 */                 this.protocol.disconnect();
/*      */             }
/*      */           }
/* 1123 */           if (this.protocol != null)
/* 1124 */             this.protocol.close();
/*      */         }
/*      */       } catch (ProtocolException pex) {
/* 1127 */         throw new MessagingException(pex.getMessage(), pex);
/*      */       }
/*      */       finally {
/* 1130 */         if (this.opened)
/* 1131 */           cleanup(true);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void cleanup(boolean returnToPool)
/*      */   {
/* 1142 */     assert (Thread.holdsLock(this.messageCacheLock));
/* 1143 */     releaseProtocol(returnToPool);
/* 1144 */     this.messageCache = null;
/* 1145 */     this.uidTable = null;
/* 1146 */     this.exists = false;
/* 1147 */     this.attributes = null;
/* 1148 */     this.opened = false;
/* 1149 */     this.idleState = 0;
/* 1150 */     notifyConnectionListeners(3);
/*      */   }
/*      */ 
/*      */   public synchronized boolean isOpen()
/*      */   {
/* 1157 */     synchronized (this.messageCacheLock)
/*      */     {
/* 1159 */       if (this.opened)
/*      */         try {
/* 1161 */           keepConnectionAlive(false);
/*      */         }
/*      */         catch (ProtocolException pex) {
/*      */         }
/*      */     }
/* 1166 */     return this.opened;
/*      */   }
/*      */ 
/*      */   public synchronized Flags getPermanentFlags()
/*      */   {
/* 1173 */     return (Flags)this.permanentFlags.clone();
/*      */   }
/*      */ 
/*      */   public synchronized int getMessageCount()
/*      */     throws MessagingException
/*      */   {
/* 1180 */     if (!this.opened) {
/* 1181 */       checkExists();
/*      */       try
/*      */       {
/* 1185 */         Status status = getStatus();
/* 1186 */         return status.total;
/*      */       }
/*      */       catch (BadCommandException bex)
/*      */       {
/* 1190 */         IMAPProtocol p = null;
/*      */         try
/*      */         {
/* 1193 */           p = getStoreProtocol();
/* 1194 */           MailboxInfo minfo = p.examine(this.fullName);
/* 1195 */           p.close();
/* 1196 */           return minfo.total;
/*      */         }
/*      */         catch (ProtocolException pex) {
/* 1199 */           throw new MessagingException(pex.getMessage(), pex);
/*      */         } finally {
/* 1201 */           releaseStoreProtocol(p);
/*      */         }
/*      */       } catch (ConnectionException cex) {
/* 1204 */         throw new StoreClosedException(this.store, cex.getMessage());
/*      */       } catch (ProtocolException pex) {
/* 1206 */         throw new MessagingException(pex.getMessage(), pex);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1211 */     synchronized (this.messageCacheLock)
/*      */     {
/*      */       try {
/* 1214 */         keepConnectionAlive(true);
/* 1215 */         return this.total;
/*      */       } catch (ConnectionException cex) {
/* 1217 */         throw new FolderClosedException(this, cex.getMessage());
/*      */       } catch (ProtocolException pex) {
/* 1219 */         throw new MessagingException(pex.getMessage(), pex);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized int getNewMessageCount()
/*      */     throws MessagingException
/*      */   {
/* 1229 */     if (!this.opened) {
/* 1230 */       checkExists();
/*      */       try
/*      */       {
/* 1234 */         Status status = getStatus();
/* 1235 */         return status.recent;
/*      */       }
/*      */       catch (BadCommandException bex)
/*      */       {
/* 1239 */         IMAPProtocol p = null;
/*      */         try
/*      */         {
/* 1242 */           p = getStoreProtocol();
/* 1243 */           MailboxInfo minfo = p.examine(this.fullName);
/* 1244 */           p.close();
/* 1245 */           return minfo.recent;
/*      */         }
/*      */         catch (ProtocolException pex) {
/* 1248 */           throw new MessagingException(pex.getMessage(), pex);
/*      */         } finally {
/* 1250 */           releaseStoreProtocol(p);
/*      */         }
/*      */       } catch (ConnectionException cex) {
/* 1253 */         throw new StoreClosedException(this.store, cex.getMessage());
/*      */       } catch (ProtocolException pex) {
/* 1255 */         throw new MessagingException(pex.getMessage(), pex);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1260 */     synchronized (this.messageCacheLock)
/*      */     {
/*      */       try {
/* 1263 */         keepConnectionAlive(true);
/* 1264 */         return this.recent;
/*      */       } catch (ConnectionException cex) {
/* 1266 */         throw new FolderClosedException(this, cex.getMessage());
/*      */       } catch (ProtocolException pex) {
/* 1268 */         throw new MessagingException(pex.getMessage(), pex);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized int getUnreadMessageCount()
/*      */     throws MessagingException
/*      */   {
/* 1278 */     if (!this.opened) {
/* 1279 */       checkExists();
/*      */       try
/*      */       {
/* 1283 */         Status status = getStatus();
/* 1284 */         return status.unseen;
/*      */       }
/*      */       catch (BadCommandException bex)
/*      */       {
/* 1289 */         return -1;
/*      */       } catch (ConnectionException cex) {
/* 1291 */         throw new StoreClosedException(this.store, cex.getMessage());
/*      */       } catch (ProtocolException pex) {
/* 1293 */         throw new MessagingException(pex.getMessage(), pex);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1299 */     Flags f = new Flags();
/* 1300 */     f.add(Flags.Flag.SEEN);
/*      */     try {
/* 1302 */       synchronized (this.messageCacheLock) {
/* 1303 */         int[] matches = getProtocol().search(new FlagTerm(f, false));
/* 1304 */         return matches.length;
/*      */       }
/*      */     } catch (ConnectionException cex) {
/* 1307 */       throw new FolderClosedException(this, cex.getMessage());
/*      */     }
/*      */     catch (ProtocolException pex) {
/* 1310 */       throw new MessagingException(pex.getMessage(), pex);
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized int getDeletedMessageCount()
/*      */     throws MessagingException
/*      */   {
/* 1319 */     if (!this.opened) {
/* 1320 */       checkExists();
/*      */ 
/* 1322 */       return -1;
/*      */     }
/*      */ 
/* 1327 */     Flags f = new Flags();
/* 1328 */     f.add(Flags.Flag.DELETED);
/*      */     try {
/* 1330 */       synchronized (this.messageCacheLock) {
/* 1331 */         int[] matches = getProtocol().search(new FlagTerm(f, true));
/* 1332 */         return matches.length;
/*      */       }
/*      */     } catch (ConnectionException cex) {
/* 1335 */       throw new FolderClosedException(this, cex.getMessage());
/*      */     }
/*      */     catch (ProtocolException pex) {
/* 1338 */       throw new MessagingException(pex.getMessage(), pex);
/*      */     }
/*      */   }
/*      */ 
/*      */   private Status getStatus()
/*      */     throws ProtocolException
/*      */   {
/* 1348 */     int statusCacheTimeout = ((IMAPStore)this.store).getStatusCacheTimeout();
/*      */ 
/* 1351 */     if ((statusCacheTimeout > 0) && (this.cachedStatus != null) && (System.currentTimeMillis() - this.cachedStatusTime < statusCacheTimeout))
/*      */     {
/* 1353 */       return this.cachedStatus;
/*      */     }
/* 1355 */     IMAPProtocol p = null;
/*      */     try
/*      */     {
/* 1358 */       p = getStoreProtocol();
/* 1359 */       Status s = p.status(this.fullName, null);
/*      */ 
/* 1361 */       if (statusCacheTimeout > 0) {
/* 1362 */         this.cachedStatus = s;
/* 1363 */         this.cachedStatusTime = System.currentTimeMillis();
/*      */       }
/* 1365 */       return s;
/*      */     } finally {
/* 1367 */       releaseStoreProtocol(p);
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized Message getMessage(int msgnum)
/*      */     throws MessagingException
/*      */   {
/* 1376 */     checkOpened();
/* 1377 */     checkRange(msgnum);
/*      */ 
/* 1379 */     return this.messageCache.getMessage(msgnum);
/*      */   }
/*      */ 
/*      */   public synchronized void appendMessages(Message[] msgs)
/*      */     throws MessagingException
/*      */   {
/* 1387 */     checkExists();
/*      */ 
/* 1394 */     int maxsize = ((IMAPStore)this.store).getAppendBufferSize();
/*      */ 
/* 1396 */     for (int i = 0; i < msgs.length; i++) {
/* 1397 */       Message m = msgs[i];
/* 1398 */       Date d = m.getReceivedDate();
/* 1399 */       if (d == null)
/* 1400 */         d = m.getSentDate();
/* 1401 */       final Date dd = d;
/* 1402 */       final Flags f = m.getFlags();
/*      */       final MessageLiteral mos;
/*      */       try {
/* 1407 */         mos = new MessageLiteral(m, m.getSize() > maxsize ? 0 : maxsize);
/*      */       }
/*      */       catch (IOException ex) {
/* 1410 */         throw new MessagingException("IOException while appending messages", ex);
/*      */       }
/*      */       catch (MessageRemovedException mrex) {
/* 1413 */         continue;
/*      */       }
/*      */ 
/* 1416 */       doCommand(new ProtocolCommand() { private final Flags val$f;
/*      */         private final Date val$dd;
/*      */         private final MessageLiteral val$mos;
/*      */ 
/* 1419 */         public Object doCommand(IMAPProtocol p) throws ProtocolException { p.append(IMAPFolder.this.fullName, f, dd, mos);
/* 1420 */           return null;
/*      */         }
/*      */       });
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized AppendUID[] appendUIDMessages(Message[] msgs)
/*      */     throws MessagingException
/*      */   {
/* 1443 */     checkExists();
/*      */ 
/* 1450 */     int maxsize = ((IMAPStore)this.store).getAppendBufferSize();
/*      */ 
/* 1452 */     AppendUID[] uids = new AppendUID[msgs.length];
/* 1453 */     for (int i = 0; i < msgs.length; i++) {
/* 1454 */       Message m = msgs[i];
/*      */       final MessageLiteral mos;
/*      */       try
/*      */       {
/* 1459 */         mos = new MessageLiteral(m, m.getSize() > maxsize ? 0 : maxsize);
/*      */       }
/*      */       catch (IOException ex) {
/* 1462 */         throw new MessagingException("IOException while appending messages", ex);
/*      */       }
/*      */       catch (MessageRemovedException mrex) {
/* 1465 */         continue;
/*      */       }
/*      */ 
/* 1468 */       Date d = m.getReceivedDate();
/* 1469 */       if (d == null)
/* 1470 */         d = m.getSentDate();
/* 1471 */       final Date dd = d;
/* 1472 */       final Flags f = m.getFlags();
/* 1473 */       AppendUID auid = (AppendUID)doCommand(new ProtocolCommand() { private final Flags val$f;
/*      */         private final Date val$dd;
/*      */         private final MessageLiteral val$mos;
/*      */ 
/* 1476 */         public Object doCommand(IMAPProtocol p) throws ProtocolException { return p.appenduid(IMAPFolder.this.fullName, f, dd, mos); }
/*      */ 
/*      */       });
/* 1479 */       uids[i] = auid;
/*      */     }
/* 1481 */     return uids;
/*      */   }
/*      */ 
/*      */   public synchronized Message[] addMessages(Message[] msgs)
/*      */     throws MessagingException
/*      */   {
/* 1502 */     checkOpened();
/* 1503 */     Message[] rmsgs = new MimeMessage[msgs.length];
/* 1504 */     AppendUID[] uids = appendUIDMessages(msgs);
/* 1505 */     for (int i = 0; i < uids.length; i++) {
/* 1506 */       AppendUID auid = uids[i];
/* 1507 */       if ((auid != null) && 
/* 1508 */         (auid.uidvalidity == this.uidvalidity)) {
/*      */         try {
/* 1510 */           rmsgs[i] = getMessageByUID(auid.uid);
/*      */         }
/*      */         catch (MessagingException mex)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/* 1517 */     return rmsgs;
/*      */   }
/*      */ 
/*      */   public synchronized void copyMessages(Message[] msgs, Folder folder)
/*      */     throws MessagingException
/*      */   {
/* 1526 */     checkOpened();
/*      */ 
/* 1528 */     if (msgs.length == 0) {
/* 1529 */       return;
/*      */     }
/*      */ 
/* 1532 */     if (folder.getStore() == this.store)
/* 1533 */       synchronized (this.messageCacheLock) {
/*      */         try {
/* 1535 */           IMAPProtocol p = getProtocol();
/* 1536 */           MessageSet[] ms = Utility.toMessageSet(msgs, null);
/* 1537 */           if (ms == null) {
/* 1538 */             throw new MessageRemovedException("Messages have been removed");
/*      */           }
/* 1540 */           p.copy(ms, folder.getFullName());
/*      */         } catch (CommandFailedException cfx) {
/* 1542 */           if (cfx.getMessage().indexOf("TRYCREATE") != -1) {
/* 1543 */             throw new FolderNotFoundException(folder, folder.getFullName() + " does not exist");
/*      */           }
/*      */ 
/* 1548 */           throw new MessagingException(cfx.getMessage(), cfx);
/*      */         } catch (ConnectionException cex) {
/* 1550 */           throw new FolderClosedException(this, cex.getMessage());
/*      */         } catch (ProtocolException pex) {
/* 1552 */           throw new MessagingException(pex.getMessage(), pex);
/*      */         }
/*      */       }
/*      */     else
/* 1556 */       super.copyMessages(msgs, folder);
/*      */   }
/*      */ 
/*      */   public synchronized Message[] expunge()
/*      */     throws MessagingException
/*      */   {
/* 1563 */     return expunge(null);
/*      */   }
/*      */ 
/*      */   public synchronized Message[] expunge(Message[] msgs)
/*      */     throws MessagingException
/*      */   {
/* 1571 */     checkOpened();
/*      */ 
/* 1573 */     if (msgs != null)
/*      */     {
/* 1575 */       FetchProfile fp = new FetchProfile();
/* 1576 */       fp.add(UIDFolder.FetchProfileItem.UID);
/* 1577 */       fetch(msgs, fp);
/*      */     }
/*      */     IMAPMessage[] rmsgs;
/* 1581 */     synchronized (this.messageCacheLock) {
/* 1582 */       this.doExpungeNotification = false;
/*      */       try {
/* 1584 */         IMAPProtocol p = getProtocol();
/* 1585 */         if (msgs != null)
/* 1586 */           p.uidexpunge(Utility.toUIDSet(msgs));
/*      */         else
/* 1588 */           p.expunge();
/*      */       }
/*      */       catch (CommandFailedException cfx) {
/* 1591 */         if (this.mode != 2) {
/* 1592 */           throw new IllegalStateException("Cannot expunge READ_ONLY folder: " + this.fullName);
/*      */         }
/*      */ 
/* 1595 */         throw new MessagingException(cfx.getMessage(), cfx);
/*      */       } catch (ConnectionException cex) {
/* 1597 */         throw new FolderClosedException(this, cex.getMessage());
/*      */       }
/*      */       catch (ProtocolException pex) {
/* 1600 */         throw new MessagingException(pex.getMessage(), pex);
/*      */       } finally {
/* 1602 */         this.doExpungeNotification = true;
/*      */       }
/*      */       IMAPMessage[] rmsgs;
/* 1606 */       if (msgs != null)
/* 1607 */         rmsgs = this.messageCache.removeExpungedMessages(msgs);
/*      */       else
/* 1609 */         rmsgs = this.messageCache.removeExpungedMessages();
/* 1610 */       if (this.uidTable != null) {
/* 1611 */         for (int i = 0; i < rmsgs.length; i++) {
/* 1612 */           IMAPMessage m = rmsgs[i];
/*      */ 
/* 1614 */           long uid = m.getUID();
/* 1615 */           if (uid != -1L) {
/* 1616 */             this.uidTable.remove(new Long(uid));
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 1621 */       this.total = this.messageCache.size();
/*      */     }
/*      */ 
/* 1625 */     if (rmsgs.length > 0)
/* 1626 */       notifyMessageRemovedListeners(true, rmsgs);
/* 1627 */     return rmsgs;
/*      */   }
/*      */ 
/*      */   public synchronized Message[] search(SearchTerm term)
/*      */     throws MessagingException
/*      */   {
/* 1635 */     checkOpened();
/*      */     try
/*      */     {
/* 1638 */       Message[] matchMsgs = null;
/*      */ 
/* 1640 */       synchronized (this.messageCacheLock) {
/* 1641 */         int[] matches = getProtocol().search(term);
/* 1642 */         if (matches != null) {
/* 1643 */           matchMsgs = new IMAPMessage[matches.length];
/*      */ 
/* 1645 */           for (int i = 0; i < matches.length; i++)
/* 1646 */             matchMsgs[i] = getMessageBySeqNumber(matches[i]);
/*      */         }
/*      */       }
/* 1649 */       return matchMsgs;
/*      */     }
/*      */     catch (CommandFailedException cfx)
/*      */     {
/* 1653 */       return super.search(term);
/*      */     }
/*      */     catch (SearchException sex) {
/* 1656 */       return super.search(term);
/*      */     } catch (ConnectionException cex) {
/* 1658 */       throw new FolderClosedException(this, cex.getMessage());
/*      */     }
/*      */     catch (ProtocolException pex) {
/* 1661 */       throw new MessagingException(pex.getMessage(), pex);
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized Message[] search(SearchTerm term, Message[] msgs)
/*      */     throws MessagingException
/*      */   {
/* 1672 */     checkOpened();
/*      */ 
/* 1674 */     if (msgs.length == 0)
/*      */     {
/* 1676 */       return msgs;
/*      */     }
/*      */     try {
/* 1679 */       Message[] matchMsgs = null;
/*      */ 
/* 1681 */       synchronized (this.messageCacheLock) {
/* 1682 */         IMAPProtocol p = getProtocol();
/* 1683 */         MessageSet[] ms = Utility.toMessageSet(msgs, null);
/* 1684 */         if (ms == null) {
/* 1685 */           throw new MessageRemovedException("Messages have been removed");
/*      */         }
/* 1687 */         int[] matches = p.search(ms, term);
/* 1688 */         if (matches != null) {
/* 1689 */           matchMsgs = new IMAPMessage[matches.length];
/* 1690 */           for (int i = 0; i < matches.length; i++)
/* 1691 */             matchMsgs[i] = getMessageBySeqNumber(matches[i]);
/*      */         }
/*      */       }
/* 1694 */       return matchMsgs;
/*      */     }
/*      */     catch (CommandFailedException cfx)
/*      */     {
/* 1698 */       return super.search(term, msgs);
/*      */     }
/*      */     catch (SearchException sex) {
/* 1701 */       return super.search(term, msgs);
/*      */     } catch (ConnectionException cex) {
/* 1703 */       throw new FolderClosedException(this, cex.getMessage());
/*      */     }
/*      */     catch (ProtocolException pex) {
/* 1706 */       throw new MessagingException(pex.getMessage(), pex);
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void addMessageCountListener(MessageCountListener l)
/*      */   {
/* 1718 */     super.addMessageCountListener(l);
/* 1719 */     this.hasMessageCountListener = true;
/*      */   }
/*      */ 
/*      */   public synchronized long getUIDValidity()
/*      */     throws MessagingException
/*      */   {
/* 1730 */     if (this.opened) {
/* 1731 */       return this.uidvalidity;
/*      */     }
/* 1733 */     IMAPProtocol p = null;
/* 1734 */     Status status = null;
/*      */     try
/*      */     {
/* 1737 */       p = getStoreProtocol();
/* 1738 */       String[] item = { "UIDVALIDITY" };
/* 1739 */       status = p.status(this.fullName, item);
/*      */     }
/*      */     catch (BadCommandException bex) {
/* 1742 */       throw new MessagingException("Cannot obtain UIDValidity", bex);
/*      */     }
/*      */     catch (ConnectionException cex) {
/* 1745 */       throwClosedException(cex);
/*      */     } catch (ProtocolException pex) {
/* 1747 */       throw new MessagingException(pex.getMessage(), pex);
/*      */     } finally {
/* 1749 */       releaseStoreProtocol(p);
/*      */     }
/*      */ 
/* 1752 */     return status.uidvalidity;
/*      */   }
/*      */ 
/*      */   public synchronized long getUIDNext()
/*      */     throws MessagingException
/*      */   {
/* 1774 */     if (this.opened) {
/* 1775 */       return this.uidnext;
/*      */     }
/* 1777 */     IMAPProtocol p = null;
/* 1778 */     Status status = null;
/*      */     try
/*      */     {
/* 1781 */       p = getStoreProtocol();
/* 1782 */       String[] item = { "UIDNEXT" };
/* 1783 */       status = p.status(this.fullName, item);
/*      */     }
/*      */     catch (BadCommandException bex) {
/* 1786 */       throw new MessagingException("Cannot obtain UIDNext", bex);
/*      */     }
/*      */     catch (ConnectionException cex) {
/* 1789 */       throwClosedException(cex);
/*      */     } catch (ProtocolException pex) {
/* 1791 */       throw new MessagingException(pex.getMessage(), pex);
/*      */     } finally {
/* 1793 */       releaseStoreProtocol(p);
/*      */     }
/*      */ 
/* 1796 */     return status.uidnext;
/*      */   }
/*      */ 
/*      */   public synchronized Message getMessageByUID(long uid)
/*      */     throws MessagingException
/*      */   {
/* 1805 */     checkOpened();
/*      */ 
/* 1807 */     IMAPMessage m = null;
/*      */     try
/*      */     {
/* 1810 */       synchronized (this.messageCacheLock) {
/* 1811 */         Long l = new Long(uid);
/*      */ 
/* 1813 */         if (this.uidTable != null)
/*      */         {
/* 1815 */           m = (IMAPMessage)this.uidTable.get(l);
/* 1816 */           if (m != null)
/* 1817 */             return m;
/*      */         } else {
/* 1819 */           this.uidTable = new Hashtable();
/*      */         }
/*      */ 
/* 1823 */         UID u = getProtocol().fetchSequenceNumber(uid);
/*      */ 
/* 1825 */         if ((u != null) && (u.seqnum <= this.total)) {
/* 1826 */           m = getMessageBySeqNumber(u.seqnum);
/* 1827 */           m.setUID(u.uid);
/*      */ 
/* 1829 */           this.uidTable.put(l, m);
/*      */         }
/*      */       }
/*      */     } catch (ConnectionException cex) {
/* 1833 */       throw new FolderClosedException(this, cex.getMessage());
/*      */     } catch (ProtocolException pex) {
/* 1835 */       throw new MessagingException(pex.getMessage(), pex);
/*      */     }
/*      */ 
/* 1838 */     return m;
/*      */   }
/*      */ 
/*      */   public synchronized Message[] getMessagesByUID(long start, long end)
/*      */     throws MessagingException
/*      */   {
/* 1848 */     checkOpened();
/*      */     Message[] msgs;
/*      */     try
/*      */     {
/* 1853 */       synchronized (this.messageCacheLock) {
/* 1854 */         if (this.uidTable == null) {
/* 1855 */           this.uidTable = new Hashtable();
/*      */         }
/*      */ 
/* 1858 */         UID[] ua = getProtocol().fetchSequenceNumbers(start, end);
/*      */ 
/* 1860 */         msgs = new Message[ua.length];
/*      */ 
/* 1863 */         for (int i = 0; i < ua.length; i++) {
/* 1864 */           IMAPMessage m = getMessageBySeqNumber(ua[i].seqnum);
/* 1865 */           m.setUID(ua[i].uid);
/* 1866 */           msgs[i] = m;
/* 1867 */           this.uidTable.put(new Long(ua[i].uid), m);
/*      */         }
/*      */       }
/*      */     } catch (ConnectionException cex) {
/* 1871 */       throw new FolderClosedException(this, cex.getMessage());
/*      */     } catch (ProtocolException pex) {
/* 1873 */       throw new MessagingException(pex.getMessage(), pex);
/*      */     }
/*      */ 
/* 1876 */     return msgs;
/*      */   }
/*      */ 
/*      */   public synchronized Message[] getMessagesByUID(long[] uids)
/*      */     throws MessagingException
/*      */   {
/* 1888 */     checkOpened();
/*      */     try
/*      */     {
/* 1891 */       synchronized (this.messageCacheLock) {
/* 1892 */         long[] unavailUids = uids;
/* 1893 */         if (this.uidTable != null) {
/* 1894 */           Vector v = new Vector();
/*      */ 
/* 1896 */           for (int i = 0; i < uids.length; i++)
/*      */           {
/*      */             Long l;
/* 1897 */             if (!this.uidTable.containsKey(l = new Long(uids[i])))
/*      */             {
/* 1899 */               v.addElement(l);
/*      */             }
/*      */           }
/* 1902 */           int vsize = v.size();
/* 1903 */           unavailUids = new long[vsize];
/* 1904 */           for (int i = 0; i < vsize; i++)
/* 1905 */             unavailUids[i] = ((Long)v.elementAt(i)).longValue();
/*      */         } else {
/* 1907 */           this.uidTable = new Hashtable();
/*      */         }
/* 1909 */         if (unavailUids.length > 0)
/*      */         {
/* 1911 */           UID[] ua = getProtocol().fetchSequenceNumbers(unavailUids);
/*      */ 
/* 1913 */           for (int i = 0; i < ua.length; i++) {
/* 1914 */             IMAPMessage m = getMessageBySeqNumber(ua[i].seqnum);
/* 1915 */             m.setUID(ua[i].uid);
/* 1916 */             this.uidTable.put(new Long(ua[i].uid), m);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1921 */         Message[] msgs = new Message[uids.length];
/* 1922 */         for (int i = 0; i < uids.length; i++)
/* 1923 */           msgs[i] = ((Message)this.uidTable.get(new Long(uids[i])));
/* 1924 */         return msgs;
/*      */       }
/*      */     } catch (ConnectionException cex) {
/* 1927 */       throw new FolderClosedException(this, cex.getMessage());
/*      */     } catch (ProtocolException pex) {
/* 1929 */       throw new MessagingException(pex.getMessage(), pex);
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized long getUID(Message message)
/*      */     throws MessagingException
/*      */   {
/* 1938 */     if (message.getFolder() != this) {
/* 1939 */       throw new NoSuchElementException("Message does not belong to this folder");
/*      */     }
/*      */ 
/* 1942 */     checkOpened();
/*      */ 
/* 1944 */     IMAPMessage m = (IMAPMessage)message;
/*      */     long uid;
/* 1947 */     if ((uid = m.getUID()) != -1L) {
/* 1948 */       return uid;
/*      */     }
/* 1950 */     synchronized (this.messageCacheLock) {
/*      */       try {
/* 1952 */         IMAPProtocol p = getProtocol();
/* 1953 */         m.checkExpunged();
/* 1954 */         UID u = p.fetchUID(m.getSequenceNumber());
/*      */ 
/* 1956 */         if (u != null) {
/* 1957 */           uid = u.uid;
/* 1958 */           m.setUID(uid);
/*      */ 
/* 1961 */           if (this.uidTable == null)
/* 1962 */             this.uidTable = new Hashtable();
/* 1963 */           this.uidTable.put(new Long(uid), m);
/*      */         }
/*      */       } catch (ConnectionException cex) {
/* 1966 */         throw new FolderClosedException(this, cex.getMessage());
/*      */       } catch (ProtocolException pex) {
/* 1968 */         throw new MessagingException(pex.getMessage(), pex);
/*      */       }
/*      */     }
/*      */ 
/* 1972 */     return uid;
/*      */   }
/*      */ 
/*      */   public Quota[] getQuota()
/*      */     throws MessagingException
/*      */   {
/* 1993 */     return (Quota[])doOptionalCommand("QUOTA not supported", new ProtocolCommand()
/*      */     {
/*      */       public Object doCommand(IMAPProtocol p) throws ProtocolException
/*      */       {
/* 1997 */         return p.getQuotaRoot(IMAPFolder.this.fullName);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public void setQuota(final Quota quota)
/*      */     throws MessagingException
/*      */   {
/* 2013 */     doOptionalCommand("QUOTA not supported", new ProtocolCommand() {
/*      */       private final Quota val$quota;
/*      */ 
/*      */       public Object doCommand(IMAPProtocol p) throws ProtocolException {
/* 2017 */         p.setQuota(quota);
/* 2018 */         return null;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public ACL[] getACL()
/*      */     throws MessagingException
/*      */   {
/* 2031 */     return (ACL[])doOptionalCommand("ACL not supported", new ProtocolCommand()
/*      */     {
/*      */       public Object doCommand(IMAPProtocol p) throws ProtocolException
/*      */       {
/* 2035 */         return p.getACL(IMAPFolder.this.fullName);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public void addACL(ACL acl)
/*      */     throws MessagingException
/*      */   {
/* 2049 */     setACL(acl, '\000');
/*      */   }
/*      */ 
/*      */   public void removeACL(final String name)
/*      */     throws MessagingException
/*      */   {
/* 2061 */     doOptionalCommand("ACL not supported", new ProtocolCommand() {
/*      */       private final String val$name;
/*      */ 
/*      */       public Object doCommand(IMAPProtocol p) throws ProtocolException {
/* 2065 */         p.deleteACL(IMAPFolder.this.fullName, name);
/* 2066 */         return null;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public void addRights(ACL acl)
/*      */     throws MessagingException
/*      */   {
/* 2081 */     setACL(acl, '+');
/*      */   }
/*      */ 
/*      */   public void removeRights(ACL acl)
/*      */     throws MessagingException
/*      */   {
/* 2093 */     setACL(acl, '-');
/*      */   }
/*      */ 
/*      */   public Rights[] listRights(final String name)
/*      */     throws MessagingException
/*      */   {
/* 2116 */     return (Rights[])doOptionalCommand("ACL not supported", new ProtocolCommand() {
/*      */       private final String val$name;
/*      */ 
/*      */       public Object doCommand(IMAPProtocol p) throws ProtocolException {
/* 2120 */         return p.listRights(IMAPFolder.this.fullName, name);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public Rights myRights()
/*      */     throws MessagingException
/*      */   {
/* 2133 */     return (Rights)doOptionalCommand("ACL not supported", new ProtocolCommand()
/*      */     {
/*      */       public Object doCommand(IMAPProtocol p) throws ProtocolException
/*      */       {
/* 2137 */         return p.myRights(IMAPFolder.this.fullName);
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private void setACL(final ACL acl, final char mod) throws MessagingException
/*      */   {
/* 2144 */     doOptionalCommand("ACL not supported", new ProtocolCommand() { private final char val$mod;
/*      */       private final ACL val$acl;
/*      */ 
/* 2148 */       public Object doCommand(IMAPProtocol p) throws ProtocolException { p.setACL(IMAPFolder.this.fullName, mod, acl);
/* 2149 */         return null;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   public synchronized String[] getAttributes()
/*      */     throws MessagingException
/*      */   {
/* 2161 */     checkExists();
/* 2162 */     if (this.attributes == null)
/* 2163 */       exists();
/* 2164 */     return this.attributes == null ? new String[0] : (String[])this.attributes.clone();
/*      */   }
/*      */ 
/*      */   public void idle()
/*      */     throws MessagingException
/*      */   {
/* 2194 */     assert (!Thread.holdsLock(this));
/* 2195 */     synchronized (this) {
/* 2196 */       checkOpened();
/* 2197 */       Boolean started = (Boolean)doOptionalCommand("IDLE not supported", new ProtocolCommand()
/*      */       {
/*      */         public Object doCommand(IMAPProtocol p) throws ProtocolException
/*      */         {
/* 2201 */           if (IMAPFolder.this.idleState == 0) {
/* 2202 */             p.idleStart();
/* 2203 */             IMAPFolder.this.idleState = 1;
/* 2204 */             return Boolean.TRUE;
/*      */           }
/*      */ 
/*      */           try
/*      */           {
/* 2211 */             IMAPFolder.this.messageCacheLock.wait(); } catch (InterruptedException ex) {
/*      */           }
/* 2213 */           return Boolean.FALSE;
/*      */         }
/*      */       });
/* 2217 */       if (!started.booleanValue())
/*      */       {
/*      */         return;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*      */     while (true)
/*      */     {
/* 2237 */       Response r = this.protocol.readIdleResponse();
/*      */       try {
/* 2239 */         synchronized (this.messageCacheLock) {
/* 2240 */           if ((r == null) || (this.protocol == null) || (!this.protocol.processIdleResponse(r)))
/*      */           {
/* 2242 */             this.idleState = 0;
/* 2243 */             this.messageCacheLock.notifyAll();
/* 2244 */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (ConnectionException cex) {
/* 2249 */         throwClosedException(cex);
/*      */       } catch (ProtocolException pex) {
/* 2251 */         throw new MessagingException(pex.getMessage(), pex);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2260 */     int minidle = ((IMAPStore)this.store).getMinIdleTime();
/* 2261 */     if (minidle > 0)
/*      */       try {
/* 2263 */         Thread.sleep(minidle);
/*      */       }
/*      */       catch (InterruptedException ex)
/*      */       {
/*      */       }
/*      */   }
/*      */ 
/*      */   void waitIfIdle()
/*      */     throws ProtocolException
/*      */   {
/* 2274 */     assert (Thread.holdsLock(this.messageCacheLock));
/* 2275 */     while (this.idleState != 0) {
/* 2276 */       if (this.idleState == 1) {
/* 2277 */         this.protocol.idleAbort();
/* 2278 */         this.idleState = 2;
/*      */       }
/*      */       try
/*      */       {
/* 2282 */         this.messageCacheLock.wait();
/*      */       }
/*      */       catch (InterruptedException ex)
/*      */       {
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void handleResponse(Response r)
/*      */   {
/* 2300 */     assert (Thread.holdsLock(this.messageCacheLock));
/*      */ 
/* 2305 */     if ((r.isOK()) || (r.isNO()) || (r.isBAD()) || (r.isBYE())) {
/* 2306 */       ((IMAPStore)this.store).handleResponseCode(r);
/*      */     }
/*      */ 
/* 2312 */     if (r.isBYE()) {
/* 2313 */       if (this.opened)
/* 2314 */         cleanup(false);
/* 2315 */       return;
/* 2316 */     }if (r.isOK())
/* 2317 */       return;
/* 2318 */     if (!r.isUnTagged()) {
/* 2319 */       return;
/*      */     }
/*      */ 
/* 2323 */     if (!(r instanceof IMAPResponse))
/*      */     {
/* 2326 */       this.out.println("UNEXPECTED RESPONSE : " + r.toString());
/* 2327 */       this.out.println("CONTACT javamail@sun.com");
/* 2328 */       return;
/*      */     }
/*      */ 
/* 2331 */     IMAPResponse ir = (IMAPResponse)r;
/*      */ 
/* 2333 */     if (ir.keyEquals("EXISTS")) {
/* 2334 */       int exists = ir.getNumber();
/* 2335 */       if (exists <= this.realTotal)
/*      */       {
/* 2337 */         return;
/*      */       }
/* 2339 */       int count = exists - this.realTotal;
/* 2340 */       Message[] msgs = new Message[count];
/*      */ 
/* 2343 */       this.messageCache.addMessages(count);
/* 2344 */       int oldtotal = this.total;
/* 2345 */       this.realTotal += count;
/* 2346 */       this.total += count;
/*      */ 
/* 2349 */       if (this.hasMessageCountListener) {
/* 2350 */         for (int i = 0; i < count; i++) {
/* 2351 */           msgs[i] = this.messageCache.getMessage(++oldtotal);
/*      */         }
/*      */ 
/* 2354 */         notifyMessageAddedListeners(msgs);
/*      */       }
/*      */     }
/* 2357 */     else if (ir.keyEquals("EXPUNGE"))
/*      */     {
/* 2360 */       int seqnum = ir.getNumber();
/* 2361 */       this.messageCache.expungeMessage(seqnum);
/*      */ 
/* 2364 */       this.realTotal -= 1;
/*      */ 
/* 2366 */       if ((this.doExpungeNotification) && (this.hasMessageCountListener))
/*      */       {
/* 2368 */         Message[] msgs = { getMessageBySeqNumber(seqnum) };
/* 2369 */         notifyMessageRemovedListeners(false, msgs);
/*      */       }
/*      */     }
/* 2372 */     else if (ir.keyEquals("FETCH"))
/*      */     {
/* 2375 */       assert ((ir instanceof FetchResponse)) : "!ir instanceof FetchResponse";
/* 2376 */       FetchResponse f = (FetchResponse)ir;
/*      */ 
/* 2378 */       Flags flags = (Flags)f.getItem(Flags.class);
/*      */ 
/* 2380 */       if (flags != null) {
/* 2381 */         IMAPMessage msg = getMessageBySeqNumber(f.getNumber());
/* 2382 */         if (msg != null) {
/* 2383 */           msg._setFlags(flags);
/* 2384 */           notifyMessageChangedListeners(1, msg);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/* 2389 */     else if (ir.keyEquals("RECENT"))
/*      */     {
/* 2391 */       this.recent = ir.getNumber();
/*      */     }
/*      */   }
/*      */ 
/*      */   void handleResponses(Response[] r)
/*      */   {
/* 2402 */     for (int i = 0; i < r.length; i++)
/* 2403 */       if (r[i] != null)
/* 2404 */         handleResponse(r[i]);
/*      */   }
/*      */ 
/*      */   protected synchronized IMAPProtocol getStoreProtocol()
/*      */     throws ProtocolException
/*      */   {
/* 2426 */     if (this.connectionPoolDebug) {
/* 2427 */       this.out.println("DEBUG: getStoreProtocol() - borrowing a connection");
/*      */     }
/*      */ 
/* 2430 */     return ((IMAPStore)this.store).getFolderStoreProtocol();
/*      */   }
/*      */ 
/*      */   private synchronized void throwClosedException(ConnectionException cex)
/*      */     throws FolderClosedException, StoreClosedException
/*      */   {
/* 2445 */     if (((this.protocol != null) && (cex.getProtocol() == this.protocol)) || ((this.protocol == null) && (!this.reallyClosed)))
/*      */     {
/* 2447 */       throw new FolderClosedException(this, cex.getMessage());
/*      */     }
/* 2449 */     throw new StoreClosedException(this.store, cex.getMessage());
/*      */   }
/*      */ 
/*      */   private IMAPProtocol getProtocol()
/*      */     throws ProtocolException
/*      */   {
/* 2461 */     assert (Thread.holdsLock(this.messageCacheLock));
/* 2462 */     waitIfIdle();
/* 2463 */     return this.protocol;
/*      */   }
/*      */ 
/*      */   public Object doCommand(ProtocolCommand cmd)
/*      */     throws MessagingException
/*      */   {
/*      */     try
/*      */     {
/* 2566 */       return doProtocolCommand(cmd);
/*      */     }
/*      */     catch (ConnectionException cex) {
/* 2569 */       throwClosedException(cex);
/*      */     } catch (ProtocolException pex) {
/* 2571 */       throw new MessagingException(pex.getMessage(), pex);
/*      */     }
/* 2573 */     return null;
/*      */   }
/*      */ 
/*      */   public Object doOptionalCommand(String err, ProtocolCommand cmd) throws MessagingException
/*      */   {
/*      */     try {
/* 2579 */       return doProtocolCommand(cmd);
/*      */     } catch (BadCommandException bex) {
/* 2581 */       throw new MessagingException(err, bex);
/*      */     }
/*      */     catch (ConnectionException cex) {
/* 2584 */       throwClosedException(cex);
/*      */     } catch (ProtocolException pex) {
/* 2586 */       throw new MessagingException(pex.getMessage(), pex);
/*      */     }
/* 2588 */     return null;
/*      */   }
/*      */ 
/*      */   public Object doCommandIgnoreFailure(ProtocolCommand cmd) throws MessagingException
/*      */   {
/*      */     try {
/* 2594 */       return doProtocolCommand(cmd);
/*      */     } catch (CommandFailedException cfx) {
/* 2596 */       return null;
/*      */     }
/*      */     catch (ConnectionException cex) {
/* 2599 */       throwClosedException(cex);
/*      */     } catch (ProtocolException pex) {
/* 2601 */       throw new MessagingException(pex.getMessage(), pex);
/*      */     }
/* 2603 */     return null;
/*      */   }
/*      */ 
/*      */   protected Object doProtocolCommand(ProtocolCommand cmd) throws ProtocolException
/*      */   {
/* 2608 */     synchronized (this)
/*      */     {
/* 2614 */       if (this.protocol != null) {
/* 2615 */         synchronized (this.messageCacheLock) {
/*      */         }
/* 2617 */         throw localObject1;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2622 */     IMAPProtocol p = null;
/*      */     try
/*      */     {
/* 2625 */       p = getStoreProtocol();
/* 2626 */       return cmd.doCommand(p);
/*      */     } finally {
/* 2628 */       releaseStoreProtocol(p);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected synchronized void releaseStoreProtocol(IMAPProtocol p)
/*      */   {
/* 2638 */     if (p != this.protocol) {
/* 2639 */       ((IMAPStore)this.store).releaseFolderStoreProtocol(p);
/*      */     }
/* 2642 */     else if (this.debug)
/* 2643 */       this.out.println("DEBUG: releasing our protocol as store protocol?");
/*      */   }
/*      */ 
/*      */   private void releaseProtocol(boolean returnToPool)
/*      */   {
/* 2654 */     if (this.protocol != null) {
/* 2655 */       this.protocol.removeResponseHandler(this);
/*      */ 
/* 2657 */       if (returnToPool) {
/* 2658 */         ((IMAPStore)this.store).releaseProtocol(this, this.protocol);
/*      */       } else {
/* 2660 */         this.protocol.disconnect();
/* 2661 */         ((IMAPStore)this.store).releaseProtocol(this, null);
/*      */       }
/* 2663 */       this.protocol = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void keepConnectionAlive(boolean keepStoreAlive)
/*      */     throws ProtocolException
/*      */   {
/* 2678 */     if (System.currentTimeMillis() - this.protocol.getTimestamp() > 1000L) {
/* 2679 */       waitIfIdle();
/* 2680 */       this.protocol.noop();
/*      */     }
/*      */ 
/* 2683 */     if ((keepStoreAlive) && (((IMAPStore)this.store).hasSeparateStoreConnection())) {
/* 2684 */       IMAPProtocol p = null;
/*      */       try {
/* 2686 */         p = ((IMAPStore)this.store).getFolderStoreProtocol();
/* 2687 */         if (System.currentTimeMillis() - p.getTimestamp() > 1000L)
/* 2688 */           p.noop();
/*      */       } finally {
/* 2690 */         ((IMAPStore)this.store).releaseFolderStoreProtocol(p);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   IMAPMessage getMessageBySeqNumber(int seqnum)
/*      */   {
/* 2703 */     return this.messageCache.getMessageBySeqnum(seqnum);
/*      */   }
/*      */ 
/*      */   private boolean isDirectory() {
/* 2707 */     return (this.type & 0x2) != 0;
/*      */   }
/*      */ 
/*      */   public static abstract interface ProtocolCommand
/*      */   {
/*      */     public abstract Object doCommand(IMAPProtocol paramIMAPProtocol)
/*      */       throws ProtocolException;
/*      */   }
/*      */ 
/*      */   public static class FetchProfileItem extends FetchProfile.Item
/*      */   {
/*  292 */     public static final FetchProfileItem HEADERS = new FetchProfileItem("HEADERS");
/*      */ 
/*  303 */     public static final FetchProfileItem SIZE = new FetchProfileItem("SIZE");
/*      */ 
/*      */     protected FetchProfileItem(String name)
/*      */     {
/*  274 */       super();
/*      */     }
/*      */   }
/*      */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.IMAPFolder
 * JD-Core Version:    0.6.1
 */