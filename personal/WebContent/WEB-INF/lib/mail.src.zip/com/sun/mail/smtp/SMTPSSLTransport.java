/*    */ package com.sun.mail.smtp;
/*    */ 
/*    */ import javax.mail.Session;
/*    */ import javax.mail.URLName;
/*    */ 
/*    */ public class SMTPSSLTransport extends SMTPTransport
/*    */ {
/*    */   public SMTPSSLTransport(Session session, URLName urlname)
/*    */   {
/* 52 */     super(session, urlname, "smtps", true);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.smtp.SMTPSSLTransport
 * JD-Core Version:    0.6.1
 */