/*     */ package com.sun.mail.imap;
/*     */ 
/*     */ import com.sun.mail.iap.ProtocolException;
/*     */ import com.sun.mail.imap.protocol.BODYSTRUCTURE;
/*     */ import com.sun.mail.imap.protocol.ENVELOPE;
/*     */ import com.sun.mail.imap.protocol.IMAPProtocol;
/*     */ import javax.mail.Flags;
/*     */ import javax.mail.FolderClosedException;
/*     */ import javax.mail.MessageRemovedException;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.MethodNotSupportedException;
/*     */ 
/*     */ public class IMAPNestedMessage extends IMAPMessage
/*     */ {
/*     */   private IMAPMessage msg;
/*     */ 
/*     */   IMAPNestedMessage(IMAPMessage m, BODYSTRUCTURE b, ENVELOPE e, String sid)
/*     */   {
/*  60 */     super(m._getSession());
/*  61 */     this.msg = m;
/*  62 */     this.bs = b;
/*  63 */     this.envelope = e;
/*  64 */     this.sectionId = sid;
/*  65 */     setPeek(m.getPeek());
/*     */   }
/*     */ 
/*     */   protected IMAPProtocol getProtocol()
/*     */     throws ProtocolException, FolderClosedException
/*     */   {
/*  74 */     return this.msg.getProtocol();
/*     */   }
/*     */ 
/*     */   protected boolean isREV1()
/*     */     throws FolderClosedException
/*     */   {
/*  81 */     return this.msg.isREV1();
/*     */   }
/*     */ 
/*     */   protected Object getMessageCacheLock()
/*     */   {
/*  89 */     return this.msg.getMessageCacheLock();
/*     */   }
/*     */ 
/*     */   protected int getSequenceNumber()
/*     */   {
/*  97 */     return this.msg.getSequenceNumber();
/*     */   }
/*     */ 
/*     */   protected void checkExpunged()
/*     */     throws MessageRemovedException
/*     */   {
/* 105 */     this.msg.checkExpunged();
/*     */   }
/*     */ 
/*     */   public boolean isExpunged()
/*     */   {
/* 113 */     return this.msg.isExpunged();
/*     */   }
/*     */ 
/*     */   protected int getFetchBlockSize()
/*     */   {
/* 120 */     return this.msg.getFetchBlockSize();
/*     */   }
/*     */ 
/*     */   public int getSize()
/*     */     throws MessagingException
/*     */   {
/* 128 */     return this.bs.size;
/*     */   }
/*     */ 
/*     */   public synchronized void setFlags(Flags flag, boolean set)
/*     */     throws MessagingException
/*     */   {
/* 137 */     throw new MethodNotSupportedException("Cannot set flags on this nested message");
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.IMAPNestedMessage
 * JD-Core Version:    0.6.1
 */