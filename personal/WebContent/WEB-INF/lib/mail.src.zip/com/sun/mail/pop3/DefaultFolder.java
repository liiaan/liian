/*     */ package com.sun.mail.pop3;
/*     */ 
/*     */ import javax.mail.Flags;
/*     */ import javax.mail.Folder;
/*     */ import javax.mail.Message;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.MethodNotSupportedException;
/*     */ import javax.mail.Store;
/*     */ 
/*     */ public class DefaultFolder extends Folder
/*     */ {
/*     */   DefaultFolder(POP3Store store)
/*     */   {
/*  49 */     super(store);
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  53 */     return "";
/*     */   }
/*     */ 
/*     */   public String getFullName() {
/*  57 */     return "";
/*     */   }
/*     */ 
/*     */   public Folder getParent() {
/*  61 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean exists() {
/*  65 */     return true;
/*     */   }
/*     */ 
/*     */   public Folder[] list(String pattern) throws MessagingException {
/*  69 */     Folder[] f = { getInbox() };
/*  70 */     return f;
/*     */   }
/*     */ 
/*     */   public char getSeparator() {
/*  74 */     return '/';
/*     */   }
/*     */ 
/*     */   public int getType() {
/*  78 */     return 2;
/*     */   }
/*     */ 
/*     */   public boolean create(int type) throws MessagingException {
/*  82 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean hasNewMessages() throws MessagingException {
/*  86 */     return false;
/*     */   }
/*     */ 
/*     */   public Folder getFolder(String name) throws MessagingException {
/*  90 */     if (!name.equalsIgnoreCase("INBOX")) {
/*  91 */       throw new MessagingException("only INBOX supported");
/*     */     }
/*  93 */     return getInbox();
/*     */   }
/*     */ 
/*     */   protected Folder getInbox() throws MessagingException
/*     */   {
/*  98 */     return getStore().getFolder("INBOX");
/*     */   }
/*     */ 
/*     */   public boolean delete(boolean recurse) throws MessagingException
/*     */   {
/* 103 */     throw new MethodNotSupportedException("delete");
/*     */   }
/*     */ 
/*     */   public boolean renameTo(Folder f) throws MessagingException {
/* 107 */     throw new MethodNotSupportedException("renameTo");
/*     */   }
/*     */ 
/*     */   public void open(int mode) throws MessagingException {
/* 111 */     throw new MethodNotSupportedException("open");
/*     */   }
/*     */ 
/*     */   public void close(boolean expunge) throws MessagingException {
/* 115 */     throw new MethodNotSupportedException("close");
/*     */   }
/*     */ 
/*     */   public boolean isOpen() {
/* 119 */     return false;
/*     */   }
/*     */ 
/*     */   public Flags getPermanentFlags() {
/* 123 */     return new Flags();
/*     */   }
/*     */ 
/*     */   public int getMessageCount() throws MessagingException {
/* 127 */     return 0;
/*     */   }
/*     */ 
/*     */   public Message getMessage(int msgno) throws MessagingException {
/* 131 */     throw new MethodNotSupportedException("getMessage");
/*     */   }
/*     */ 
/*     */   public void appendMessages(Message[] msgs) throws MessagingException {
/* 135 */     throw new MethodNotSupportedException("Append not supported");
/*     */   }
/*     */ 
/*     */   public Message[] expunge() throws MessagingException {
/* 139 */     throw new MethodNotSupportedException("expunge");
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.pop3.DefaultFolder
 * JD-Core Version:    0.6.1
 */