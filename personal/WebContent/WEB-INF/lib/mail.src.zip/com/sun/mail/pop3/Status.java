/*    */ package com.sun.mail.pop3;
/*    */ 
/*    */ class Status
/*    */ {
/* 43 */   int total = 0;
/* 44 */   int size = 0;
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.pop3.Status
 * JD-Core Version:    0.6.1
 */