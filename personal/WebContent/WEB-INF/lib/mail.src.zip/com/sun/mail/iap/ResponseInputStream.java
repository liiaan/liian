/*     */ package com.sun.mail.iap;
/*     */ 
/*     */ import com.sun.mail.util.ASCIIUtility;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ public class ResponseInputStream
/*     */ {
/*     */   private static final int minIncrement = 256;
/*     */   private static final int maxIncrement = 262144;
/*     */   private static final int incrementSlop = 16;
/*     */   private BufferedInputStream bin;
/*     */ 
/*     */   public ResponseInputStream(InputStream in)
/*     */   {
/*  65 */     this.bin = new BufferedInputStream(in, 2048);
/*     */   }
/*     */ 
/*     */   public ByteArray readResponse()
/*     */     throws IOException
/*     */   {
/*  73 */     return readResponse(null);
/*     */   }
/*     */ 
/*     */   public ByteArray readResponse(ByteArray ba)
/*     */     throws IOException
/*     */   {
/*  81 */     if (ba == null) {
/*  82 */       ba = new ByteArray(new byte[''], 0, 128);
/*     */     }
/*  84 */     byte[] buffer = ba.getBytes();
/*  85 */     int idx = 0;
/*     */     while (true)
/*     */     {
/*  88 */       int b = 0;
/*  89 */       boolean gotCRLF = false;
/*     */ 
/*  92 */       while ((!gotCRLF) && ((b = this.bin.read()) != -1))
/*     */       {
/*  94 */         switch (b) {
/*     */         case 10:
/*  96 */           if ((idx > 0) && (buffer[(idx - 1)] == 13))
/*  97 */             gotCRLF = true; break;
/*     */         }
/*  99 */         if (idx >= buffer.length) {
/* 100 */           int incr = buffer.length;
/* 101 */           if (incr > 262144)
/* 102 */             incr = 262144;
/* 103 */           ba.grow(incr);
/* 104 */           buffer = ba.getBytes();
/*     */         }
/* 106 */         buffer[(idx++)] = (byte)b;
/*     */       }
/*     */ 
/* 110 */       if (b == -1) {
/* 111 */         throw new IOException("Connection dropped by server?");
/*     */       }
/*     */ 
/* 115 */       if ((idx < 5) || (buffer[(idx - 3)] != 125))
/*     */       {
/*     */         break;
/*     */       }
/*     */ 
/* 120 */       for (int i = idx - 4; (i >= 0) && 
/* 121 */         (buffer[i] != 123); i--);
/* 124 */       if (i < 0) {
/*     */         break;
/*     */       }
/* 127 */       int count = 0;
/*     */       try
/*     */       {
/* 130 */         count = ASCIIUtility.parseInt(buffer, i + 1, idx - 3);
/*     */       } catch (NumberFormatException e) {
/* 132 */         break;
/*     */       }
/*     */ 
/* 136 */       if (count > 0) {
/* 137 */         int avail = buffer.length - idx;
/* 138 */         if (count + 16 > avail)
/*     */         {
/* 140 */           ba.grow(256 > count + 16 - avail ? 256 : count + 16 - avail);
/*     */ 
/* 142 */           buffer = ba.getBytes();
/*     */         }
/*     */ 
/* 150 */         while (count > 0) {
/* 151 */           int actual = this.bin.read(buffer, idx, count);
/* 152 */           count -= actual;
/* 153 */           idx += actual;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 158 */     ba.setCount(idx);
/* 159 */     return ba;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.iap.ResponseInputStream
 * JD-Core Version:    0.6.1
 */