/*     */ package com.sun.mail.pop3;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Enumeration;
/*     */ import javax.mail.Flags;
/*     */ import javax.mail.Folder;
/*     */ import javax.mail.FolderClosedException;
/*     */ import javax.mail.IllegalWriteException;
/*     */ import javax.mail.MessageRemovedException;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.internet.InternetHeaders;
/*     */ import javax.mail.internet.MimeMessage;
/*     */ import javax.mail.internet.SharedInputStream;
/*     */ 
/*     */ public class POP3Message extends MimeMessage
/*     */ {
/*     */   static final String UNKNOWN = "UNKNOWN";
/*     */   private POP3Folder folder;
/*  63 */   private int hdrSize = -1;
/*  64 */   private int msgSize = -1;
/*  65 */   String uid = "UNKNOWN";
/*     */ 
/*     */   public POP3Message(Folder folder, int msgno) throws MessagingException
/*     */   {
/*  69 */     super(folder, msgno);
/*  70 */     this.folder = ((POP3Folder)folder);
/*     */   }
/*     */ 
/*     */   public void setFlags(Flags newFlags, boolean set)
/*     */     throws MessagingException
/*     */   {
/*  81 */     Flags oldFlags = (Flags)this.flags.clone();
/*  82 */     super.setFlags(newFlags, set);
/*  83 */     if (!this.flags.equals(oldFlags))
/*  84 */       this.folder.notifyMessageChangedListeners(1, this);
/*     */   }
/*     */ 
/*     */   public int getSize()
/*     */     throws MessagingException
/*     */   {
/*     */     try
/*     */     {
/* 101 */       synchronized (this) {
/* 102 */         if (this.msgSize >= 0)
/* 103 */           return this.msgSize;
/* 104 */         if (this.msgSize < 0)
/*     */         {
/* 113 */           if (this.headers == null)
/* 114 */             loadHeaders();
/* 115 */           if (this.contentStream != null)
/* 116 */             this.msgSize = this.contentStream.available();
/*     */           else
/* 118 */             this.msgSize = (this.folder.getProtocol().list(this.msgnum) - this.hdrSize);
/*     */         }
/* 120 */         return this.msgSize;
/*     */       }
/*     */     } catch (EOFException eex) {
/* 123 */       this.folder.close(false);
/* 124 */       throw new FolderClosedException(this.folder, eex.toString());
/*     */     } catch (IOException ex) {
/* 126 */       throw new MessagingException("error getting size", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected InputStream getContentStream()
/*     */     throws MessagingException
/*     */   {
/*     */     try
/*     */     {
/* 139 */       synchronized (this) {
/* 140 */         if (this.contentStream == null) {
/* 141 */           InputStream rawcontent = this.folder.getProtocol().retr(this.msgnum, this.msgSize > 0 ? this.msgSize + this.hdrSize : 0);
/*     */ 
/* 143 */           if (rawcontent == null) {
/* 144 */             this.expunged = true;
/* 145 */             throw new MessageRemovedException();
/*     */           }
/* 147 */           if ((this.headers == null) || (((POP3Store)this.folder.getStore()).forgetTopHeaders))
/*     */           {
/* 149 */             this.headers = new InternetHeaders(rawcontent);
/* 150 */             this.hdrSize = (int)((SharedInputStream)rawcontent).getPosition();
/*     */           }
/*     */           else
/*     */           {
/* 165 */             int offset = 0;
/*     */             while (true) {
/* 167 */               int len = 0;
/*     */               int c1;
/* 169 */               while (((c1 = rawcontent.read()) >= 0) && 
/* 170 */                 (c1 != 10))
/*     */               {
/* 172 */                 if (c1 == 13)
/*     */                 {
/* 174 */                   if (rawcontent.available() <= 0) break;
/* 175 */                   rawcontent.mark(1);
/* 176 */                   if (rawcontent.read() == 10) break;
/* 177 */                   rawcontent.reset(); break;
/*     */                 }
/*     */ 
/* 183 */                 len++;
/*     */               }
/*     */ 
/* 188 */               if (rawcontent.available() == 0)
/*     */               {
/*     */                 break;
/*     */               }
/* 192 */               if (len == 0)
/*     */                 break;
/*     */             }
/* 195 */             this.hdrSize = (int)((SharedInputStream)rawcontent).getPosition();
/*     */           }
/*     */ 
/* 198 */           this.contentStream = ((SharedInputStream)rawcontent).newStream(this.hdrSize, -1L);
/*     */ 
/* 200 */           rawcontent = null;
/*     */         }
/*     */       }
/*     */     } catch (EOFException eex) {
/* 204 */       this.folder.close(false);
/* 205 */       throw new FolderClosedException(this.folder, eex.toString());
/*     */     } catch (IOException ex) {
/* 207 */       throw new MessagingException("error fetching POP3 content", ex);
/*     */     }
/* 209 */     return super.getContentStream();
/*     */   }
/*     */ 
/*     */   public synchronized void invalidate(boolean invalidateHeaders)
/*     */   {
/* 221 */     this.content = null;
/* 222 */     this.contentStream = null;
/* 223 */     this.msgSize = -1;
/* 224 */     if (invalidateHeaders) {
/* 225 */       this.headers = null;
/* 226 */       this.hdrSize = -1;
/*     */     }
/*     */   }
/*     */ 
/*     */   public InputStream top(int n)
/*     */     throws MessagingException
/*     */   {
/*     */     try
/*     */     {
/* 240 */       synchronized (this) {
/* 241 */         return this.folder.getProtocol().top(this.msgnum, n);
/*     */       }
/*     */     } catch (EOFException eex) {
/* 244 */       this.folder.close(false);
/* 245 */       throw new FolderClosedException(this.folder, eex.toString());
/*     */     } catch (IOException ex) {
/* 247 */       throw new MessagingException("error getting size", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String[] getHeader(String name)
/*     */     throws MessagingException
/*     */   {
/* 263 */     if (this.headers == null)
/* 264 */       loadHeaders();
/* 265 */     return this.headers.getHeader(name);
/*     */   }
/*     */ 
/*     */   public String getHeader(String name, String delimiter)
/*     */     throws MessagingException
/*     */   {
/* 282 */     if (this.headers == null)
/* 283 */       loadHeaders();
/* 284 */     return this.headers.getHeader(name, delimiter);
/*     */   }
/*     */ 
/*     */   public void setHeader(String name, String value)
/*     */     throws MessagingException
/*     */   {
/* 302 */     throw new IllegalWriteException("POP3 messages are read-only");
/*     */   }
/*     */ 
/*     */   public void addHeader(String name, String value)
/*     */     throws MessagingException
/*     */   {
/* 320 */     throw new IllegalWriteException("POP3 messages are read-only");
/*     */   }
/*     */ 
/*     */   public void removeHeader(String name)
/*     */     throws MessagingException
/*     */   {
/* 335 */     throw new IllegalWriteException("POP3 messages are read-only");
/*     */   }
/*     */ 
/*     */   public Enumeration getAllHeaders()
/*     */     throws MessagingException
/*     */   {
/* 351 */     if (this.headers == null)
/* 352 */       loadHeaders();
/* 353 */     return this.headers.getAllHeaders();
/*     */   }
/*     */ 
/*     */   public Enumeration getMatchingHeaders(String[] names)
/*     */     throws MessagingException
/*     */   {
/* 364 */     if (this.headers == null)
/* 365 */       loadHeaders();
/* 366 */     return this.headers.getMatchingHeaders(names);
/*     */   }
/*     */ 
/*     */   public Enumeration getNonMatchingHeaders(String[] names)
/*     */     throws MessagingException
/*     */   {
/* 377 */     if (this.headers == null)
/* 378 */       loadHeaders();
/* 379 */     return this.headers.getNonMatchingHeaders(names);
/*     */   }
/*     */ 
/*     */   public void addHeaderLine(String line)
/*     */     throws MessagingException
/*     */   {
/* 393 */     throw new IllegalWriteException("POP3 messages are read-only");
/*     */   }
/*     */ 
/*     */   public Enumeration getAllHeaderLines()
/*     */     throws MessagingException
/*     */   {
/* 404 */     if (this.headers == null)
/* 405 */       loadHeaders();
/* 406 */     return this.headers.getAllHeaderLines();
/*     */   }
/*     */ 
/*     */   public Enumeration getMatchingHeaderLines(String[] names)
/*     */     throws MessagingException
/*     */   {
/* 418 */     if (this.headers == null)
/* 419 */       loadHeaders();
/* 420 */     return this.headers.getMatchingHeaderLines(names);
/*     */   }
/*     */ 
/*     */   public Enumeration getNonMatchingHeaderLines(String[] names)
/*     */     throws MessagingException
/*     */   {
/* 432 */     if (this.headers == null)
/* 433 */       loadHeaders();
/* 434 */     return this.headers.getNonMatchingHeaderLines(names);
/*     */   }
/*     */ 
/*     */   public void saveChanges()
/*     */     throws MessagingException
/*     */   {
/* 446 */     throw new IllegalWriteException("POP3 messages are read-only");
/*     */   }
/*     */ 
/*     */   private void loadHeaders()
/*     */     throws MessagingException
/*     */   {
/*     */     try
/*     */     {
/* 455 */       synchronized (this) {
/* 456 */         if (this.headers != null)
/* 457 */           return;
/* 458 */         InputStream hdrs = null;
/* 459 */         if ((((POP3Store)this.folder.getStore()).disableTop) || ((hdrs = this.folder.getProtocol().top(this.msgnum, 0)) == null))
/*     */         {
/* 464 */           InputStream cs = getContentStream();
/* 465 */           cs.close();
/*     */         } else {
/* 467 */           this.hdrSize = hdrs.available();
/* 468 */           this.headers = new InternetHeaders(hdrs);
/*     */         }
/*     */       }
/*     */     } catch (EOFException eex) {
/* 472 */       this.folder.close(false);
/* 473 */       throw new FolderClosedException(this.folder, eex.toString());
/*     */     } catch (IOException ex) {
/* 475 */       throw new MessagingException("error loading POP3 headers", ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.pop3.POP3Message
 * JD-Core Version:    0.6.1
 */