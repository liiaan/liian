/*     */ package com.sun.mail.imap;
/*     */ 
/*     */ public class ACL
/*     */   implements Cloneable
/*     */ {
/*     */   private String name;
/*     */   private Rights rights;
/*     */ 
/*     */   public ACL(String name)
/*     */   {
/*  61 */     this.name = name;
/*  62 */     this.rights = new Rights();
/*     */   }
/*     */ 
/*     */   public ACL(String name, Rights rights)
/*     */   {
/*  72 */     this.name = name;
/*  73 */     this.rights = rights;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  82 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setRights(Rights rights)
/*     */   {
/*  91 */     this.rights = rights;
/*     */   }
/*     */ 
/*     */   public Rights getRights()
/*     */   {
/* 102 */     return this.rights;
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */     throws CloneNotSupportedException
/*     */   {
/* 109 */     ACL acl = (ACL)super.clone();
/* 110 */     acl.rights = ((Rights)this.rights.clone());
/* 111 */     return acl;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.ACL
 * JD-Core Version:    0.6.1
 */