/*    */ package com.sun.mail.imap.protocol;
/*    */ 
/*    */ import com.sun.mail.iap.ParsingException;
/*    */ import com.sun.mail.iap.Response;
/*    */ 
/*    */ public class Status
/*    */ {
/* 48 */   public String mbox = null;
/* 49 */   public int total = -1;
/* 50 */   public int recent = -1;
/* 51 */   public long uidnext = -1L;
/* 52 */   public long uidvalidity = -1L;
/* 53 */   public int unseen = -1;
/*    */ 
/* 55 */   static final String[] standardItems = { "MESSAGES", "RECENT", "UNSEEN", "UIDNEXT", "UIDVALIDITY" };
/*    */ 
/*    */   public Status(Response r) throws ParsingException
/*    */   {
/* 59 */     this.mbox = r.readAtomString();
/* 60 */     r.skipSpaces();
/* 61 */     if (r.readByte() != 40)
/* 62 */       throw new ParsingException("parse error in STATUS");
/*    */     do
/*    */     {
/* 65 */       String attr = r.readAtom();
/* 66 */       if (attr.equalsIgnoreCase("MESSAGES"))
/* 67 */         this.total = r.readNumber();
/* 68 */       else if (attr.equalsIgnoreCase("RECENT"))
/* 69 */         this.recent = r.readNumber();
/* 70 */       else if (attr.equalsIgnoreCase("UIDNEXT"))
/* 71 */         this.uidnext = r.readLong();
/* 72 */       else if (attr.equalsIgnoreCase("UIDVALIDITY"))
/* 73 */         this.uidvalidity = r.readLong();
/* 74 */       else if (attr.equalsIgnoreCase("UNSEEN"))
/* 75 */         this.unseen = r.readNumber(); 
/*    */     }
/* 76 */     while (r.readByte() != 41);
/*    */   }
/*    */ 
/*    */   public static void add(Status s1, Status s2) {
/* 80 */     if (s2.total != -1)
/* 81 */       s1.total = s2.total;
/* 82 */     if (s2.recent != -1)
/* 83 */       s1.recent = s2.recent;
/* 84 */     if (s2.uidnext != -1L)
/* 85 */       s1.uidnext = s2.uidnext;
/* 86 */     if (s2.uidvalidity != -1L)
/* 87 */       s1.uidvalidity = s2.uidvalidity;
/* 88 */     if (s2.unseen != -1)
/* 89 */       s1.unseen = s2.unseen;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.protocol.Status
 * JD-Core Version:    0.6.1
 */