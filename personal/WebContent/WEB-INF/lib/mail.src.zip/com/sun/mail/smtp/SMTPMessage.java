/*     */ package com.sun.mail.smtp;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.Session;
/*     */ import javax.mail.internet.MimeMessage;
/*     */ 
/*     */ public class SMTPMessage extends MimeMessage
/*     */ {
/*     */   public static final int NOTIFY_NEVER = -1;
/*     */   public static final int NOTIFY_SUCCESS = 1;
/*     */   public static final int NOTIFY_FAILURE = 2;
/*     */   public static final int NOTIFY_DELAY = 4;
/*     */   public static final int RETURN_FULL = 1;
/*     */   public static final int RETURN_HDRS = 2;
/*  73 */   private static final String[] returnOptionString = { null, "FULL", "HDRS" };
/*     */   private String envelopeFrom;
/*  76 */   private int notifyOptions = 0;
/*  77 */   private int returnOption = 0;
/*  78 */   private boolean sendPartial = false;
/*  79 */   private boolean allow8bitMIME = false;
/*  80 */   private String submitter = null;
/*  81 */   private String extension = null;
/*     */ 
/*     */   public SMTPMessage(Session session)
/*     */   {
/*  90 */     super(session);
/*     */   }
/*     */ 
/*     */   public SMTPMessage(Session session, InputStream is)
/*     */     throws MessagingException
/*     */   {
/* 105 */     super(session, is);
/*     */   }
/*     */ 
/*     */   public SMTPMessage(MimeMessage source)
/*     */     throws MessagingException
/*     */   {
/* 120 */     super(source);
/*     */   }
/*     */ 
/*     */   public void setEnvelopeFrom(String from)
/*     */   {
/* 135 */     this.envelopeFrom = from;
/*     */   }
/*     */ 
/*     */   public String getEnvelopeFrom()
/*     */   {
/* 144 */     return this.envelopeFrom;
/*     */   }
/*     */ 
/*     */   public void setNotifyOptions(int options)
/*     */   {
/* 160 */     if ((options < -1) || (options >= 8))
/* 161 */       throw new IllegalArgumentException("Bad return option");
/* 162 */     this.notifyOptions = options;
/*     */   }
/*     */ 
/*     */   public int getNotifyOptions()
/*     */   {
/* 171 */     return this.notifyOptions;
/*     */   }
/*     */ 
/*     */   String getDSNNotify()
/*     */   {
/* 179 */     if (this.notifyOptions == 0)
/* 180 */       return null;
/* 181 */     if (this.notifyOptions == -1)
/* 182 */       return "NEVER";
/* 183 */     StringBuffer sb = new StringBuffer();
/* 184 */     if ((this.notifyOptions & 0x1) != 0)
/* 185 */       sb.append("SUCCESS");
/* 186 */     if ((this.notifyOptions & 0x2) != 0) {
/* 187 */       if (sb.length() != 0)
/* 188 */         sb.append(',');
/* 189 */       sb.append("FAILURE");
/*     */     }
/* 191 */     if ((this.notifyOptions & 0x4) != 0) {
/* 192 */       if (sb.length() != 0)
/* 193 */         sb.append(',');
/* 194 */       sb.append("DELAY");
/*     */     }
/* 196 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public void setReturnOption(int option)
/*     */   {
/* 210 */     if ((option < 0) || (option > 2))
/* 211 */       throw new IllegalArgumentException("Bad return option");
/* 212 */     this.returnOption = option;
/*     */   }
/*     */ 
/*     */   public int getReturnOption()
/*     */   {
/* 221 */     return this.returnOption;
/*     */   }
/*     */ 
/*     */   String getDSNRet()
/*     */   {
/* 229 */     return returnOptionString[this.returnOption];
/*     */   }
/*     */ 
/*     */   public void setAllow8bitMIME(boolean allow)
/*     */   {
/* 243 */     this.allow8bitMIME = allow;
/*     */   }
/*     */ 
/*     */   public boolean getAllow8bitMIME()
/*     */   {
/* 252 */     return this.allow8bitMIME;
/*     */   }
/*     */ 
/*     */   public void setSendPartial(boolean partial)
/*     */   {
/* 267 */     this.sendPartial = partial;
/*     */   }
/*     */ 
/*     */   public boolean getSendPartial()
/*     */   {
/* 276 */     return this.sendPartial;
/*     */   }
/*     */ 
/*     */   public String getSubmitter()
/*     */   {
/* 286 */     return this.submitter;
/*     */   }
/*     */ 
/*     */   public void setSubmitter(String submitter)
/*     */   {
/* 300 */     this.submitter = submitter;
/*     */   }
/*     */ 
/*     */   public String getMailExtension()
/*     */   {
/* 311 */     return this.extension;
/*     */   }
/*     */ 
/*     */   public void setMailExtension(String extension)
/*     */   {
/* 336 */     this.extension = extension;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.smtp.SMTPMessage
 * JD-Core Version:    0.6.1
 */