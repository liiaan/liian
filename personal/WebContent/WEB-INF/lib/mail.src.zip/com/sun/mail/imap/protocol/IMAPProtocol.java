/*      */ package com.sun.mail.imap.protocol;
/*      */ 
/*      */ import com.sun.mail.iap.Argument;
/*      */ import com.sun.mail.iap.BadCommandException;
/*      */ import com.sun.mail.iap.ByteArray;
/*      */ import com.sun.mail.iap.CommandFailedException;
/*      */ import com.sun.mail.iap.ConnectionException;
/*      */ import com.sun.mail.iap.Literal;
/*      */ import com.sun.mail.iap.LiteralException;
/*      */ import com.sun.mail.iap.ParsingException;
/*      */ import com.sun.mail.iap.Protocol;
/*      */ import com.sun.mail.iap.ProtocolException;
/*      */ import com.sun.mail.iap.Response;
/*      */ import com.sun.mail.imap.ACL;
/*      */ import com.sun.mail.imap.AppendUID;
/*      */ import com.sun.mail.imap.Rights;
/*      */ import com.sun.mail.util.ASCIIUtility;
/*      */ import com.sun.mail.util.BASE64EncoderStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InterruptedIOException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.Hashtable;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.Vector;
/*      */ import javax.mail.Flags;
/*      */ import javax.mail.Flags.Flag;
/*      */ import javax.mail.Quota;
/*      */ import javax.mail.Quota.Resource;
/*      */ import javax.mail.internet.MimeUtility;
/*      */ import javax.mail.search.SearchException;
/*      */ import javax.mail.search.SearchTerm;
/*      */ 
/*      */ public class IMAPProtocol extends Protocol
/*      */ {
/*   70 */   private boolean connected = false;
/*   71 */   private boolean rev1 = false;
/*      */   private boolean authenticated;
/*      */   private Map capabilities;
/*      */   private List authmechs;
/*      */   private String[] searchCharsets;
/*      */   private String name;
/*      */   private SaslAuthenticator saslAuthenticator;
/*      */   private ByteArray ba;
/*   89 */   private static final byte[] CRLF = { 13, 10 };
/*      */   private String idleTag;
/* 2098 */   private static final byte[] DONE = { 68, 79, 78, 69, 13, 10 };
/*      */ 
/*      */   public IMAPProtocol(String name, String host, int port, boolean debug, PrintStream out, Properties props, boolean isSSL)
/*      */     throws IOException, ProtocolException
/*      */   {
/*  103 */     super(host, port, debug, out, props, "mail." + name, isSSL);
/*      */     try
/*      */     {
/*  106 */       this.name = name;
/*      */ 
/*  108 */       if (this.capabilities == null) {
/*  109 */         capability();
/*      */       }
/*  111 */       if (hasCapability("IMAP4rev1")) {
/*  112 */         this.rev1 = true;
/*      */       }
/*  114 */       this.searchCharsets = new String[2];
/*  115 */       this.searchCharsets[0] = "UTF-8";
/*  116 */       this.searchCharsets[1] = MimeUtility.mimeCharset(MimeUtility.getDefaultJavaCharset());
/*      */ 
/*  120 */       this.connected = true;
/*      */     }
/*      */     finally
/*      */     {
/*  128 */       if (!this.connected)
/*  129 */         disconnect();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void capability()
/*      */     throws ProtocolException
/*      */   {
/*  140 */     Response[] r = command("CAPABILITY", null);
/*      */ 
/*  142 */     if (!r[(r.length - 1)].isOK()) {
/*  143 */       throw new ProtocolException(r[(r.length - 1)].toString());
/*      */     }
/*  145 */     this.capabilities = new HashMap(10);
/*  146 */     this.authmechs = new ArrayList(5);
/*  147 */     int i = 0; for (int len = r.length; i < len; i++)
/*  148 */       if ((r[i] instanceof IMAPResponse))
/*      */       {
/*  151 */         IMAPResponse ir = (IMAPResponse)r[i];
/*      */ 
/*  157 */         if (ir.keyEquals("CAPABILITY"))
/*  158 */           parseCapabilities(ir);
/*      */       }
/*      */   }
/*      */ 
/*      */   protected void setCapabilities(Response r)
/*      */   {
/*      */     byte b;
/*  168 */     while (((b = r.readByte()) > 0) && (b != 91));
/*  170 */     if (b == 0) {
/*  171 */       return;
/*      */     }
/*  173 */     String s = r.readAtom();
/*  174 */     if (!s.equalsIgnoreCase("CAPABILITY"))
/*  175 */       return;
/*  176 */     this.capabilities = new HashMap(10);
/*  177 */     this.authmechs = new ArrayList(5);
/*  178 */     parseCapabilities(r);
/*      */   }
/*      */ 
/*      */   protected void parseCapabilities(Response r)
/*      */   {
/*      */     String s;
/*  187 */     while ((s = r.readAtom(']')) != null)
/*  188 */       if (s.length() == 0) {
/*  189 */         if (r.peekByte() == 93)
/*      */         {
/*      */           break;
/*      */         }
/*      */ 
/*  202 */         r.skipToken();
/*      */       } else {
/*  204 */         this.capabilities.put(s.toUpperCase(Locale.ENGLISH), s);
/*  205 */         if (s.regionMatches(true, 0, "AUTH=", 0, 5)) {
/*  206 */           this.authmechs.add(s.substring(5));
/*  207 */           if (this.debug)
/*  208 */             this.out.println("IMAP DEBUG: AUTH: " + s.substring(5));
/*      */         }
/*      */       }
/*      */   }
/*      */ 
/*      */   protected void processGreeting(Response r)
/*      */     throws ProtocolException
/*      */   {
/*  218 */     super.processGreeting(r);
/*  219 */     if (r.isOK()) {
/*  220 */       setCapabilities(r);
/*  221 */       return;
/*      */     }
/*      */ 
/*  224 */     IMAPResponse ir = (IMAPResponse)r;
/*  225 */     if (ir.keyEquals("PREAUTH")) {
/*  226 */       this.authenticated = true;
/*  227 */       setCapabilities(r);
/*      */     } else {
/*  229 */       throw new ConnectionException(this, r);
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean isAuthenticated()
/*      */   {
/*  237 */     return this.authenticated;
/*      */   }
/*      */ 
/*      */   public boolean isREV1()
/*      */   {
/*  244 */     return this.rev1;
/*      */   }
/*      */ 
/*      */   protected boolean supportsNonSyncLiterals()
/*      */   {
/*  251 */     return hasCapability("LITERAL+");
/*      */   }
/*      */ 
/*      */   public Response readResponse()
/*      */     throws IOException, ProtocolException
/*      */   {
/*  260 */     return IMAPResponse.readResponse(this);
/*      */   }
/*      */ 
/*      */   public boolean hasCapability(String c)
/*      */   {
/*  269 */     return this.capabilities.containsKey(c.toUpperCase(Locale.ENGLISH));
/*      */   }
/*      */ 
/*      */   public Map getCapabilities()
/*      */   {
/*  278 */     return this.capabilities;
/*      */   }
/*      */ 
/*      */   public void disconnect()
/*      */   {
/*  288 */     super.disconnect();
/*  289 */     this.authenticated = false;
/*      */   }
/*      */ 
/*      */   public void noop()
/*      */     throws ProtocolException
/*      */   {
/*  298 */     if (this.debug)
/*  299 */       this.out.println("IMAP DEBUG: IMAPProtocol noop");
/*  300 */     simpleCommand("NOOP", null);
/*      */   }
/*      */ 
/*      */   public void logout()
/*      */     throws ProtocolException
/*      */   {
/*      */     try
/*      */     {
/*  310 */       Response[] r = command("LOGOUT", null);
/*      */ 
/*  312 */       this.authenticated = false;
/*      */ 
/*  315 */       notifyResponseHandlers(r);
/*      */     } finally {
/*  317 */       disconnect();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void login(String u, String p)
/*      */     throws ProtocolException
/*      */   {
/*  327 */     Argument args = new Argument();
/*  328 */     args.writeString(u);
/*  329 */     args.writeString(p);
/*      */ 
/*  331 */     Response[] r = command("LOGIN", args);
/*      */ 
/*  334 */     notifyResponseHandlers(r);
/*      */ 
/*  337 */     handleResult(r[(r.length - 1)]);
/*      */ 
/*  339 */     setCapabilities(r[(r.length - 1)]);
/*      */ 
/*  341 */     this.authenticated = true;
/*      */   }
/*      */ 
/*      */   public synchronized void authlogin(String u, String p)
/*      */     throws ProtocolException
/*      */   {
/*  351 */     Vector v = new Vector();
/*  352 */     String tag = null;
/*  353 */     Response r = null;
/*  354 */     boolean done = false;
/*      */     try
/*      */     {
/*  357 */       tag = writeCommand("AUTHENTICATE LOGIN", null);
/*      */     }
/*      */     catch (Exception ex) {
/*  360 */       r = Response.byeResponse(ex);
/*  361 */       done = true;
/*      */     }
/*      */ 
/*  364 */     OutputStream os = getOutputStream();
/*      */ 
/*  382 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*  383 */     OutputStream b64os = new BASE64EncoderStream(bos, 2147483647);
/*  384 */     boolean first = true;
/*      */ 
/*  386 */     while (!done) {
/*      */       try {
/*  388 */         r = readResponse();
/*  389 */         if (r.isContinuation())
/*      */         {
/*      */           String s;
/*  392 */           if (first) {
/*  393 */             String s = u;
/*  394 */             first = false;
/*      */           } else {
/*  396 */             s = p;
/*      */           }
/*      */ 
/*  399 */           b64os.write(ASCIIUtility.getBytes(s));
/*  400 */           b64os.flush();
/*      */ 
/*  402 */           bos.write(CRLF);
/*  403 */           os.write(bos.toByteArray());
/*  404 */           os.flush();
/*  405 */           bos.reset();
/*  406 */         } else if ((r.isTagged()) && (r.getTag().equals(tag)))
/*      */         {
/*  408 */           done = true;
/*  409 */         } else if (r.isBYE()) {
/*  410 */           done = true;
/*      */         } else {
/*  412 */           v.addElement(r);
/*      */         }
/*      */       } catch (Exception ioex) {
/*  415 */         r = Response.byeResponse(ioex);
/*  416 */         done = true;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  426 */     Response[] responses = new Response[v.size()];
/*  427 */     v.copyInto(responses);
/*  428 */     notifyResponseHandlers(responses);
/*      */ 
/*  431 */     handleResult(r);
/*      */ 
/*  433 */     setCapabilities(r);
/*      */ 
/*  435 */     this.authenticated = true;
/*      */   }
/*      */ 
/*      */   public synchronized void authplain(String authzid, String u, String p)
/*      */     throws ProtocolException
/*      */   {
/*  453 */     Vector v = new Vector();
/*  454 */     String tag = null;
/*  455 */     Response r = null;
/*  456 */     boolean done = false;
/*      */     try
/*      */     {
/*  459 */       tag = writeCommand("AUTHENTICATE PLAIN", null);
/*      */     }
/*      */     catch (Exception ex) {
/*  462 */       r = Response.byeResponse(ex);
/*  463 */       done = true;
/*      */     }
/*      */ 
/*  466 */     OutputStream os = getOutputStream();
/*      */ 
/*  484 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*  485 */     OutputStream b64os = new BASE64EncoderStream(bos, 2147483647);
/*      */ 
/*  487 */     while (!done) {
/*      */       try {
/*  489 */         r = readResponse();
/*  490 */         if (r.isContinuation())
/*      */         {
/*  492 */           String nullByte = "";
/*  493 */           String s = authzid + "" + u + "" + p;
/*      */ 
/*  496 */           b64os.write(ASCIIUtility.getBytes(s));
/*  497 */           b64os.flush();
/*      */ 
/*  499 */           bos.write(CRLF);
/*  500 */           os.write(bos.toByteArray());
/*  501 */           os.flush();
/*  502 */           bos.reset();
/*  503 */         } else if ((r.isTagged()) && (r.getTag().equals(tag)))
/*      */         {
/*  505 */           done = true;
/*  506 */         } else if (r.isBYE()) {
/*  507 */           done = true;
/*      */         } else {
/*  509 */           v.addElement(r);
/*      */         }
/*      */       } catch (Exception ioex) {
/*  512 */         r = Response.byeResponse(ioex);
/*  513 */         done = true;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  523 */     Response[] responses = new Response[v.size()];
/*  524 */     v.copyInto(responses);
/*  525 */     notifyResponseHandlers(responses);
/*      */ 
/*  528 */     handleResult(r);
/*      */ 
/*  530 */     setCapabilities(r);
/*      */ 
/*  532 */     this.authenticated = true;
/*      */   }
/*      */ 
/*      */   public void sasllogin(String[] allowed, String realm, String authzid, String u, String p)
/*      */     throws ProtocolException
/*      */   {
/*  540 */     if (this.saslAuthenticator == null)
/*      */       try {
/*  542 */         Class sac = Class.forName("com.sun.mail.imap.protocol.IMAPSaslAuthenticator");
/*      */ 
/*  544 */         Constructor c = sac.getConstructor(new Class[] { IMAPProtocol.class, String.class, Properties.class, Boolean.TYPE, PrintStream.class, String.class });
/*      */ 
/*  552 */         this.saslAuthenticator = ((SaslAuthenticator)c.newInstance(new Object[] { this, this.name, this.props, this.debug ? Boolean.TRUE : Boolean.FALSE, this.out, this.host }));
/*      */       }
/*      */       catch (Exception ex)
/*      */       {
/*  562 */         if (this.debug)
/*  563 */           this.out.println("IMAP DEBUG: Can't load SASL authenticator: " + ex);
/*      */         return;
/*      */       }
/*      */     List v;
/*  572 */     if ((allowed != null) && (allowed.length > 0))
/*      */     {
/*  574 */       List v = new ArrayList(allowed.length);
/*  575 */       for (int i = 0; i < allowed.length; i++)
/*  576 */         if (this.authmechs.contains(allowed[i]))
/*  577 */           v.add(allowed[i]);
/*      */     }
/*      */     else {
/*  580 */       v = this.authmechs;
/*      */     }
/*  582 */     String[] mechs = (String[])v.toArray(new String[v.size()]);
/*  583 */     if (this.saslAuthenticator.authenticate(mechs, realm, authzid, u, p))
/*  584 */       this.authenticated = true;
/*      */   }
/*      */ 
/*      */   OutputStream getIMAPOutputStream()
/*      */   {
/*  589 */     return getOutputStream();
/*      */   }
/*      */ 
/*      */   public void proxyauth(String u)
/*      */     throws ProtocolException
/*      */   {
/*  598 */     Argument args = new Argument();
/*  599 */     args.writeString(u);
/*      */ 
/*  601 */     simpleCommand("PROXYAUTH", args);
/*      */   }
/*      */ 
/*      */   public void startTLS()
/*      */     throws ProtocolException
/*      */   {
/*      */     try
/*      */     {
/*  611 */       super.startTLS("STARTTLS");
/*      */     }
/*      */     catch (ProtocolException pex)
/*      */     {
/*  616 */       throw pex;
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*  620 */       Response[] r = { Response.byeResponse(ex) };
/*  621 */       notifyResponseHandlers(r);
/*  622 */       disconnect();
/*      */     }
/*      */   }
/*      */ 
/*      */   public MailboxInfo select(String mbox)
/*      */     throws ProtocolException
/*      */   {
/*  633 */     mbox = BASE64MailboxEncoder.encode(mbox);
/*      */ 
/*  635 */     Argument args = new Argument();
/*  636 */     args.writeString(mbox);
/*      */ 
/*  638 */     Response[] r = command("SELECT", args);
/*      */ 
/*  642 */     MailboxInfo minfo = new MailboxInfo(r);
/*      */ 
/*  645 */     notifyResponseHandlers(r);
/*      */ 
/*  647 */     Response response = r[(r.length - 1)];
/*      */ 
/*  649 */     if (response.isOK()) {
/*  650 */       if (response.toString().indexOf("READ-ONLY") != -1)
/*  651 */         minfo.mode = 1;
/*      */       else {
/*  653 */         minfo.mode = 2;
/*      */       }
/*      */     }
/*  656 */     handleResult(response);
/*  657 */     return minfo;
/*      */   }
/*      */ 
/*      */   public MailboxInfo examine(String mbox)
/*      */     throws ProtocolException
/*      */   {
/*  667 */     mbox = BASE64MailboxEncoder.encode(mbox);
/*      */ 
/*  669 */     Argument args = new Argument();
/*  670 */     args.writeString(mbox);
/*      */ 
/*  672 */     Response[] r = command("EXAMINE", args);
/*      */ 
/*  676 */     MailboxInfo minfo = new MailboxInfo(r);
/*  677 */     minfo.mode = 1;
/*      */ 
/*  680 */     notifyResponseHandlers(r);
/*      */ 
/*  682 */     handleResult(r[(r.length - 1)]);
/*  683 */     return minfo;
/*      */   }
/*      */ 
/*      */   public Status status(String mbox, String[] items)
/*      */     throws ProtocolException
/*      */   {
/*  693 */     if ((!isREV1()) && (!hasCapability("IMAP4SUNVERSION")))
/*      */     {
/*  696 */       throw new BadCommandException("STATUS not supported");
/*      */     }
/*      */ 
/*  699 */     mbox = BASE64MailboxEncoder.encode(mbox);
/*      */ 
/*  701 */     Argument args = new Argument();
/*  702 */     args.writeString(mbox);
/*      */ 
/*  704 */     Argument itemArgs = new Argument();
/*  705 */     if (items == null) {
/*  706 */       items = Status.standardItems;
/*      */     }
/*  708 */     int i = 0; for (int len = items.length; i < len; i++)
/*  709 */       itemArgs.writeAtom(items[i]);
/*  710 */     args.writeArgument(itemArgs);
/*      */ 
/*  712 */     Response[] r = command("STATUS", args);
/*      */ 
/*  714 */     Status status = null;
/*  715 */     Response response = r[(r.length - 1)];
/*      */ 
/*  718 */     if (response.isOK()) {
/*  719 */       int i = 0; for (int len = r.length; i < len; i++) {
/*  720 */         if ((r[i] instanceof IMAPResponse))
/*      */         {
/*  723 */           IMAPResponse ir = (IMAPResponse)r[i];
/*  724 */           if (ir.keyEquals("STATUS")) {
/*  725 */             if (status == null)
/*  726 */               status = new Status(ir);
/*      */             else
/*  728 */               Status.add(status, new Status(ir));
/*  729 */             r[i] = null;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  735 */     notifyResponseHandlers(r);
/*  736 */     handleResult(response);
/*  737 */     return status;
/*      */   }
/*      */ 
/*      */   public void create(String mbox)
/*      */     throws ProtocolException
/*      */   {
/*  747 */     mbox = BASE64MailboxEncoder.encode(mbox);
/*      */ 
/*  749 */     Argument args = new Argument();
/*  750 */     args.writeString(mbox);
/*      */ 
/*  752 */     simpleCommand("CREATE", args);
/*      */   }
/*      */ 
/*      */   public void delete(String mbox)
/*      */     throws ProtocolException
/*      */   {
/*  762 */     mbox = BASE64MailboxEncoder.encode(mbox);
/*      */ 
/*  764 */     Argument args = new Argument();
/*  765 */     args.writeString(mbox);
/*      */ 
/*  767 */     simpleCommand("DELETE", args);
/*      */   }
/*      */ 
/*      */   public void rename(String o, String n)
/*      */     throws ProtocolException
/*      */   {
/*  777 */     o = BASE64MailboxEncoder.encode(o);
/*  778 */     n = BASE64MailboxEncoder.encode(n);
/*      */ 
/*  780 */     Argument args = new Argument();
/*  781 */     args.writeString(o);
/*  782 */     args.writeString(n);
/*      */ 
/*  784 */     simpleCommand("RENAME", args);
/*      */   }
/*      */ 
/*      */   public void subscribe(String mbox)
/*      */     throws ProtocolException
/*      */   {
/*  793 */     Argument args = new Argument();
/*      */ 
/*  795 */     mbox = BASE64MailboxEncoder.encode(mbox);
/*  796 */     args.writeString(mbox);
/*      */ 
/*  798 */     simpleCommand("SUBSCRIBE", args);
/*      */   }
/*      */ 
/*      */   public void unsubscribe(String mbox)
/*      */     throws ProtocolException
/*      */   {
/*  807 */     Argument args = new Argument();
/*      */ 
/*  809 */     mbox = BASE64MailboxEncoder.encode(mbox);
/*  810 */     args.writeString(mbox);
/*      */ 
/*  812 */     simpleCommand("UNSUBSCRIBE", args);
/*      */   }
/*      */ 
/*      */   public ListInfo[] list(String ref, String pattern)
/*      */     throws ProtocolException
/*      */   {
/*  822 */     return doList("LIST", ref, pattern);
/*      */   }
/*      */ 
/*      */   public ListInfo[] lsub(String ref, String pattern)
/*      */     throws ProtocolException
/*      */   {
/*  832 */     return doList("LSUB", ref, pattern);
/*      */   }
/*      */ 
/*      */   private ListInfo[] doList(String cmd, String ref, String pat)
/*      */     throws ProtocolException
/*      */   {
/*  838 */     ref = BASE64MailboxEncoder.encode(ref);
/*  839 */     pat = BASE64MailboxEncoder.encode(pat);
/*      */ 
/*  841 */     Argument args = new Argument();
/*  842 */     args.writeString(ref);
/*  843 */     args.writeString(pat);
/*      */ 
/*  845 */     Response[] r = command(cmd, args);
/*      */ 
/*  847 */     ListInfo[] linfo = null;
/*  848 */     Response response = r[(r.length - 1)];
/*      */ 
/*  850 */     if (response.isOK()) {
/*  851 */       Vector v = new Vector(1);
/*  852 */       int i = 0; for (int len = r.length; i < len; i++)
/*  853 */         if ((r[i] instanceof IMAPResponse))
/*      */         {
/*  856 */           IMAPResponse ir = (IMAPResponse)r[i];
/*  857 */           if (ir.keyEquals(cmd)) {
/*  858 */             v.addElement(new ListInfo(ir));
/*  859 */             r[i] = null;
/*      */           }
/*      */         }
/*  862 */       if (v.size() > 0) {
/*  863 */         linfo = new ListInfo[v.size()];
/*  864 */         v.copyInto(linfo);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  869 */     notifyResponseHandlers(r);
/*  870 */     handleResult(response);
/*  871 */     return linfo;
/*      */   }
/*      */ 
/*      */   public void append(String mbox, Flags f, Date d, Literal data)
/*      */     throws ProtocolException
/*      */   {
/*  881 */     appenduid(mbox, f, d, data, false);
/*      */   }
/*      */ 
/*      */   public AppendUID appenduid(String mbox, Flags f, Date d, Literal data)
/*      */     throws ProtocolException
/*      */   {
/*  891 */     return appenduid(mbox, f, d, data, true);
/*      */   }
/*      */ 
/*      */   public AppendUID appenduid(String mbox, Flags f, Date d, Literal data, boolean uid)
/*      */     throws ProtocolException
/*      */   {
/*  897 */     mbox = BASE64MailboxEncoder.encode(mbox);
/*      */ 
/*  899 */     Argument args = new Argument();
/*  900 */     args.writeString(mbox);
/*      */ 
/*  902 */     if (f != null)
/*      */     {
/*  904 */       if (f.contains(Flags.Flag.RECENT)) {
/*  905 */         f = new Flags(f);
/*  906 */         f.remove(Flags.Flag.RECENT);
/*      */       }
/*      */ 
/*  919 */       args.writeAtom(createFlagList(f));
/*      */     }
/*  921 */     if (d != null) {
/*  922 */       args.writeString(INTERNALDATE.format(d));
/*      */     }
/*  924 */     args.writeBytes(data);
/*      */ 
/*  926 */     Response[] r = command("APPEND", args);
/*      */ 
/*  929 */     notifyResponseHandlers(r);
/*      */ 
/*  932 */     handleResult(r[(r.length - 1)]);
/*      */ 
/*  934 */     if (uid) {
/*  935 */       return getAppendUID(r[(r.length - 1)]);
/*      */     }
/*  937 */     return null;
/*      */   }
/*      */ 
/*      */   private AppendUID getAppendUID(Response r)
/*      */   {
/*  945 */     if (!r.isOK())
/*  946 */       return null;
/*      */     byte b;
/*  948 */     while (((b = r.readByte()) > 0) && (b != 91));
/*  950 */     if (b == 0) {
/*  951 */       return null;
/*      */     }
/*  953 */     String s = r.readAtom();
/*  954 */     if (!s.equalsIgnoreCase("APPENDUID")) {
/*  955 */       return null;
/*      */     }
/*  957 */     long uidvalidity = r.readLong();
/*  958 */     long uid = r.readLong();
/*  959 */     return new AppendUID(uidvalidity, uid);
/*      */   }
/*      */ 
/*      */   public void check()
/*      */     throws ProtocolException
/*      */   {
/*  968 */     simpleCommand("CHECK", null);
/*      */   }
/*      */ 
/*      */   public void close()
/*      */     throws ProtocolException
/*      */   {
/*  977 */     simpleCommand("CLOSE", null);
/*      */   }
/*      */ 
/*      */   public void expunge()
/*      */     throws ProtocolException
/*      */   {
/*  986 */     simpleCommand("EXPUNGE", null);
/*      */   }
/*      */ 
/*      */   public void uidexpunge(UIDSet[] set)
/*      */     throws ProtocolException
/*      */   {
/*  995 */     if (!hasCapability("UIDPLUS"))
/*  996 */       throw new BadCommandException("UID EXPUNGE not supported");
/*  997 */     simpleCommand("UID EXPUNGE " + UIDSet.toString(set), null);
/*      */   }
/*      */ 
/*      */   public BODYSTRUCTURE fetchBodyStructure(int msgno)
/*      */     throws ProtocolException
/*      */   {
/* 1005 */     Response[] r = fetch(msgno, "BODYSTRUCTURE");
/* 1006 */     notifyResponseHandlers(r);
/*      */ 
/* 1008 */     Response response = r[(r.length - 1)];
/* 1009 */     if (response.isOK()) {
/* 1010 */       return (BODYSTRUCTURE)FetchResponse.getItem(r, msgno, BODYSTRUCTURE.class);
/*      */     }
/* 1012 */     if (response.isNO()) {
/* 1013 */       return null;
/*      */     }
/* 1015 */     handleResult(response);
/* 1016 */     return null;
/*      */   }
/*      */ 
/*      */   public BODY peekBody(int msgno, String section)
/*      */     throws ProtocolException
/*      */   {
/* 1026 */     return fetchBody(msgno, section, true);
/*      */   }
/*      */ 
/*      */   public BODY fetchBody(int msgno, String section)
/*      */     throws ProtocolException
/*      */   {
/* 1034 */     return fetchBody(msgno, section, false);
/*      */   }
/*      */ 
/*      */   protected BODY fetchBody(int msgno, String section, boolean peek)
/*      */     throws ProtocolException
/*      */   {
/*      */     Response[] r;
/*      */     Response[] r;
/* 1041 */     if (peek) {
/* 1042 */       r = fetch(msgno, "BODY.PEEK[" + (section == null ? "]" : new StringBuffer().append(section).append("]").toString()));
/*      */     }
/*      */     else {
/* 1045 */       r = fetch(msgno, "BODY[" + (section == null ? "]" : new StringBuffer().append(section).append("]").toString()));
/*      */     }
/*      */ 
/* 1048 */     notifyResponseHandlers(r);
/*      */ 
/* 1050 */     Response response = r[(r.length - 1)];
/* 1051 */     if (response.isOK())
/* 1052 */       return (BODY)FetchResponse.getItem(r, msgno, BODY.class);
/* 1053 */     if (response.isNO()) {
/* 1054 */       return null;
/*      */     }
/* 1056 */     handleResult(response);
/* 1057 */     return null;
/*      */   }
/*      */ 
/*      */   public BODY peekBody(int msgno, String section, int start, int size)
/*      */     throws ProtocolException
/*      */   {
/* 1066 */     return fetchBody(msgno, section, start, size, true, null);
/*      */   }
/*      */ 
/*      */   public BODY fetchBody(int msgno, String section, int start, int size)
/*      */     throws ProtocolException
/*      */   {
/* 1074 */     return fetchBody(msgno, section, start, size, false, null);
/*      */   }
/*      */ 
/*      */   public BODY peekBody(int msgno, String section, int start, int size, ByteArray ba)
/*      */     throws ProtocolException
/*      */   {
/* 1082 */     return fetchBody(msgno, section, start, size, true, ba);
/*      */   }
/*      */ 
/*      */   public BODY fetchBody(int msgno, String section, int start, int size, ByteArray ba)
/*      */     throws ProtocolException
/*      */   {
/* 1090 */     return fetchBody(msgno, section, start, size, false, ba);
/*      */   }
/*      */ 
/*      */   protected BODY fetchBody(int msgno, String section, int start, int size, boolean peek, ByteArray ba) throws ProtocolException
/*      */   {
/* 1095 */     this.ba = ba;
/* 1096 */     Response[] r = fetch(msgno, (peek ? "BODY.PEEK[" : "BODY[") + (section == null ? "]<" : new StringBuffer().append(section).append("]<").toString()) + String.valueOf(start) + "." + String.valueOf(size) + ">");
/*      */ 
/* 1103 */     notifyResponseHandlers(r);
/*      */ 
/* 1105 */     Response response = r[(r.length - 1)];
/* 1106 */     if (response.isOK())
/* 1107 */       return (BODY)FetchResponse.getItem(r, msgno, BODY.class);
/* 1108 */     if (response.isNO()) {
/* 1109 */       return null;
/*      */     }
/* 1111 */     handleResult(response);
/* 1112 */     return null;
/*      */   }
/*      */ 
/*      */   protected ByteArray getResponseBuffer()
/*      */   {
/* 1122 */     ByteArray ret = this.ba;
/* 1123 */     this.ba = null;
/* 1124 */     return ret;
/*      */   }
/*      */ 
/*      */   public RFC822DATA fetchRFC822(int msgno, String what)
/*      */     throws ProtocolException
/*      */   {
/* 1134 */     Response[] r = fetch(msgno, "RFC822." + what);
/*      */ 
/* 1139 */     notifyResponseHandlers(r);
/*      */ 
/* 1141 */     Response response = r[(r.length - 1)];
/* 1142 */     if (response.isOK()) {
/* 1143 */       return (RFC822DATA)FetchResponse.getItem(r, msgno, RFC822DATA.class);
/*      */     }
/* 1145 */     if (response.isNO()) {
/* 1146 */       return null;
/*      */     }
/* 1148 */     handleResult(response);
/* 1149 */     return null;
/*      */   }
/*      */ 
/*      */   public Flags fetchFlags(int msgno)
/*      */     throws ProtocolException
/*      */   {
/* 1157 */     Flags flags = null;
/* 1158 */     Response[] r = fetch(msgno, "FLAGS");
/*      */ 
/* 1161 */     int i = 0; for (int len = r.length; i < len; i++) {
/* 1162 */       if ((r[i] != null) && ((r[i] instanceof FetchResponse)) && (((FetchResponse)r[i]).getNumber() == msgno))
/*      */       {
/* 1167 */         FetchResponse fr = (FetchResponse)r[i];
/* 1168 */         if ((flags = (Flags)fr.getItem(Flags.class)) != null) {
/* 1169 */           r[i] = null;
/* 1170 */           break;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1175 */     notifyResponseHandlers(r);
/* 1176 */     handleResult(r[(r.length - 1)]);
/* 1177 */     return flags;
/*      */   }
/*      */ 
/*      */   public UID fetchUID(int msgno)
/*      */     throws ProtocolException
/*      */   {
/* 1184 */     Response[] r = fetch(msgno, "UID");
/*      */ 
/* 1187 */     notifyResponseHandlers(r);
/*      */ 
/* 1189 */     Response response = r[(r.length - 1)];
/* 1190 */     if (response.isOK())
/* 1191 */       return (UID)FetchResponse.getItem(r, msgno, UID.class);
/* 1192 */     if (response.isNO()) {
/* 1193 */       return null;
/*      */     }
/* 1195 */     handleResult(response);
/* 1196 */     return null;
/*      */   }
/*      */ 
/*      */   public UID fetchSequenceNumber(long uid)
/*      */     throws ProtocolException
/*      */   {
/* 1206 */     UID u = null;
/* 1207 */     Response[] r = fetch(String.valueOf(uid), "UID", true);
/*      */ 
/* 1209 */     int i = 0; for (int len = r.length; i < len; i++) {
/* 1210 */       if ((r[i] != null) && ((r[i] instanceof FetchResponse)))
/*      */       {
/* 1213 */         FetchResponse fr = (FetchResponse)r[i];
/* 1214 */         if ((u = (UID)fr.getItem(UID.class)) != null) {
/* 1215 */           if (u.uid == uid) {
/*      */             break;
/*      */           }
/* 1218 */           u = null;
/*      */         }
/*      */       }
/*      */     }
/* 1222 */     notifyResponseHandlers(r);
/* 1223 */     handleResult(r[(r.length - 1)]);
/* 1224 */     return u;
/*      */   }
/*      */ 
/*      */   public UID[] fetchSequenceNumbers(long start, long end)
/*      */     throws ProtocolException
/*      */   {
/* 1234 */     Response[] r = fetch(String.valueOf(start) + ":" + (end == -1L ? "*" : String.valueOf(end)), "UID", true);
/*      */ 
/* 1240 */     Vector v = new Vector();
/* 1241 */     int i = 0; for (int len = r.length; i < len; i++) {
/* 1242 */       if ((r[i] != null) && ((r[i] instanceof FetchResponse)))
/*      */       {
/* 1245 */         FetchResponse fr = (FetchResponse)r[i];
/*      */         UID u;
/* 1246 */         if ((u = (UID)fr.getItem(UID.class)) != null)
/* 1247 */           v.addElement(u);
/*      */       }
/*      */     }
/* 1250 */     notifyResponseHandlers(r);
/* 1251 */     handleResult(r[(r.length - 1)]);
/*      */ 
/* 1253 */     UID[] ua = new UID[v.size()];
/* 1254 */     v.copyInto(ua);
/* 1255 */     return ua;
/*      */   }
/*      */ 
/*      */   public UID[] fetchSequenceNumbers(long[] uids)
/*      */     throws ProtocolException
/*      */   {
/* 1264 */     StringBuffer sb = new StringBuffer();
/* 1265 */     for (int i = 0; i < uids.length; i++) {
/* 1266 */       if (i > 0)
/* 1267 */         sb.append(",");
/* 1268 */       sb.append(String.valueOf(uids[i]));
/*      */     }
/*      */ 
/* 1271 */     Response[] r = fetch(sb.toString(), "UID", true);
/*      */ 
/* 1274 */     Vector v = new Vector();
/* 1275 */     int i = 0; for (int len = r.length; i < len; i++) {
/* 1276 */       if ((r[i] != null) && ((r[i] instanceof FetchResponse)))
/*      */       {
/* 1279 */         FetchResponse fr = (FetchResponse)r[i];
/*      */         UID u;
/* 1280 */         if ((u = (UID)fr.getItem(UID.class)) != null)
/* 1281 */           v.addElement(u);
/*      */       }
/*      */     }
/* 1284 */     notifyResponseHandlers(r);
/* 1285 */     handleResult(r[(r.length - 1)]);
/*      */ 
/* 1287 */     UID[] ua = new UID[v.size()];
/* 1288 */     v.copyInto(ua);
/* 1289 */     return ua;
/*      */   }
/*      */ 
/*      */   public Response[] fetch(MessageSet[] msgsets, String what) throws ProtocolException
/*      */   {
/* 1294 */     return fetch(MessageSet.toString(msgsets), what, false);
/*      */   }
/*      */ 
/*      */   public Response[] fetch(int start, int end, String what) throws ProtocolException
/*      */   {
/* 1299 */     return fetch(String.valueOf(start) + ":" + String.valueOf(end), what, false);
/*      */   }
/*      */ 
/*      */   public Response[] fetch(int msg, String what)
/*      */     throws ProtocolException
/*      */   {
/* 1305 */     return fetch(String.valueOf(msg), what, false);
/*      */   }
/*      */ 
/*      */   private Response[] fetch(String msgSequence, String what, boolean uid) throws ProtocolException
/*      */   {
/* 1310 */     if (uid) {
/* 1311 */       return command("UID FETCH " + msgSequence + " (" + what + ")", null);
/*      */     }
/* 1313 */     return command("FETCH " + msgSequence + " (" + what + ")", null);
/*      */   }
/*      */ 
/*      */   public void copy(MessageSet[] msgsets, String mbox)
/*      */     throws ProtocolException
/*      */   {
/* 1321 */     copy(MessageSet.toString(msgsets), mbox);
/*      */   }
/*      */ 
/*      */   public void copy(int start, int end, String mbox) throws ProtocolException
/*      */   {
/* 1326 */     copy(String.valueOf(start) + ":" + String.valueOf(end), mbox);
/*      */   }
/*      */ 
/*      */   private void copy(String msgSequence, String mbox)
/*      */     throws ProtocolException
/*      */   {
/* 1333 */     mbox = BASE64MailboxEncoder.encode(mbox);
/*      */ 
/* 1335 */     Argument args = new Argument();
/* 1336 */     args.writeAtom(msgSequence);
/* 1337 */     args.writeString(mbox);
/*      */ 
/* 1339 */     simpleCommand("COPY", args);
/*      */   }
/*      */ 
/*      */   public void storeFlags(MessageSet[] msgsets, Flags flags, boolean set) throws ProtocolException
/*      */   {
/* 1344 */     storeFlags(MessageSet.toString(msgsets), flags, set);
/*      */   }
/*      */ 
/*      */   public void storeFlags(int start, int end, Flags flags, boolean set) throws ProtocolException
/*      */   {
/* 1349 */     storeFlags(String.valueOf(start) + ":" + String.valueOf(end), flags, set);
/*      */   }
/*      */ 
/*      */   public void storeFlags(int msg, Flags flags, boolean set)
/*      */     throws ProtocolException
/*      */   {
/* 1358 */     storeFlags(String.valueOf(msg), flags, set);
/*      */   }
/*      */ 
/*      */   private void storeFlags(String msgset, Flags flags, boolean set)
/*      */     throws ProtocolException
/*      */   {
/*      */     Response[] r;
/*      */     Response[] r;
/* 1364 */     if (set) {
/* 1365 */       r = command("STORE " + msgset + " +FLAGS " + createFlagList(flags), null);
/*      */     }
/*      */     else {
/* 1368 */       r = command("STORE " + msgset + " -FLAGS " + createFlagList(flags), null);
/*      */     }
/*      */ 
/* 1372 */     notifyResponseHandlers(r);
/* 1373 */     handleResult(r[(r.length - 1)]);
/*      */   }
/*      */ 
/*      */   private String createFlagList(Flags flags)
/*      */   {
/* 1380 */     StringBuffer sb = new StringBuffer();
/* 1381 */     sb.append("(");
/*      */ 
/* 1383 */     Flags.Flag[] sf = flags.getSystemFlags();
/* 1384 */     boolean first = true;
/* 1385 */     for (int i = 0; i < sf.length; i++)
/*      */     {
/* 1387 */       Flags.Flag f = sf[i];
/*      */       String s;
/*      */       String s;
/* 1388 */       if (f == Flags.Flag.ANSWERED) {
/* 1389 */         s = "\\Answered";
/*      */       }
/*      */       else
/*      */       {
/*      */         String s;
/* 1390 */         if (f == Flags.Flag.DELETED) {
/* 1391 */           s = "\\Deleted";
/*      */         }
/*      */         else
/*      */         {
/*      */           String s;
/* 1392 */           if (f == Flags.Flag.DRAFT) {
/* 1393 */             s = "\\Draft";
/*      */           }
/*      */           else
/*      */           {
/*      */             String s;
/* 1394 */             if (f == Flags.Flag.FLAGGED) {
/* 1395 */               s = "\\Flagged";
/*      */             }
/*      */             else
/*      */             {
/*      */               String s;
/* 1396 */               if (f == Flags.Flag.RECENT) {
/* 1397 */                 s = "\\Recent"; } else {
/* 1398 */                 if (f != Flags.Flag.SEEN) continue;
/* 1399 */                 s = "\\Seen";
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/* 1402 */       if (first)
/* 1403 */         first = false;
/*      */       else
/* 1405 */         sb.append(' ');
/* 1406 */       sb.append(s);
/*      */     }
/*      */ 
/* 1409 */     String[] uf = flags.getUserFlags();
/* 1410 */     for (int i = 0; i < uf.length; i++) {
/* 1411 */       if (first)
/* 1412 */         first = false;
/*      */       else
/* 1414 */         sb.append(' ');
/* 1415 */       sb.append(uf[i]);
/*      */     }
/*      */ 
/* 1418 */     sb.append(")");
/* 1419 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public int[] search(MessageSet[] msgsets, SearchTerm term)
/*      */     throws ProtocolException, SearchException
/*      */   {
/* 1433 */     return search(MessageSet.toString(msgsets), term);
/*      */   }
/*      */ 
/*      */   public int[] search(SearchTerm term)
/*      */     throws ProtocolException, SearchException
/*      */   {
/* 1446 */     return search("ALL", term);
/*      */   }
/*      */ 
/*      */   private int[] search(String msgSequence, SearchTerm term)
/*      */     throws ProtocolException, SearchException
/*      */   {
/* 1456 */     if (SearchSequence.isAscii(term)) {
/*      */       try {
/* 1458 */         return issueSearch(msgSequence, term, null);
/*      */       }
/*      */       catch (IOException ioex)
/*      */       {
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1470 */     for (int i = 0; i < this.searchCharsets.length; i++) {
/* 1471 */       if (this.searchCharsets[i] != null)
/*      */       {
/*      */         try
/*      */         {
/* 1475 */           return issueSearch(msgSequence, term, this.searchCharsets[i]);
/*      */         }
/*      */         catch (CommandFailedException cfx)
/*      */         {
/* 1482 */           this.searchCharsets[i] = null;
/*      */         }
/*      */         catch (IOException ioex)
/*      */         {
/*      */         }
/*      */         catch (ProtocolException pex) {
/* 1488 */           throw pex;
/*      */         } catch (SearchException sex) {
/* 1490 */           throw sex;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1495 */     throw new SearchException("Search failed");
/*      */   }
/*      */ 
/*      */   private int[] issueSearch(String msgSequence, SearchTerm term, String charset)
/*      */     throws ProtocolException, SearchException, IOException
/*      */   {
/* 1508 */     Argument args = SearchSequence.generateSequence(term, charset == null ? null : MimeUtility.javaCharset(charset));
/*      */ 
/* 1512 */     args.writeAtom(msgSequence);
/*      */     Response[] r;
/*      */     Response[] r;
/* 1516 */     if (charset == null)
/* 1517 */       r = command("SEARCH", args);
/*      */     else {
/* 1519 */       r = command("SEARCH CHARSET " + charset, args);
/*      */     }
/* 1521 */     Response response = r[(r.length - 1)];
/* 1522 */     int[] matches = null;
/*      */ 
/* 1525 */     if (response.isOK()) {
/* 1526 */       Vector v = new Vector();
/*      */ 
/* 1528 */       int i = 0; for (int len = r.length; i < len; i++) {
/* 1529 */         if ((r[i] instanceof IMAPResponse))
/*      */         {
/* 1532 */           IMAPResponse ir = (IMAPResponse)r[i];
/*      */ 
/* 1534 */           if (ir.keyEquals("SEARCH"))
/*      */           {
/*      */             int num;
/* 1535 */             while ((num = ir.readNumber()) != -1)
/* 1536 */               v.addElement(new Integer(num));
/* 1537 */             r[i] = null;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 1542 */       int vsize = v.size();
/* 1543 */       matches = new int[vsize];
/* 1544 */       for (int i = 0; i < vsize; i++) {
/* 1545 */         matches[i] = ((Integer)v.elementAt(i)).intValue();
/*      */       }
/*      */     }
/*      */ 
/* 1549 */     notifyResponseHandlers(r);
/* 1550 */     handleResult(response);
/* 1551 */     return matches;
/*      */   }
/*      */ 
/*      */   public Namespaces namespace()
/*      */     throws ProtocolException
/*      */   {
/* 1560 */     if (!hasCapability("NAMESPACE")) {
/* 1561 */       throw new BadCommandException("NAMESPACE not supported");
/*      */     }
/* 1563 */     Response[] r = command("NAMESPACE", null);
/*      */ 
/* 1565 */     Namespaces namespace = null;
/* 1566 */     Response response = r[(r.length - 1)];
/*      */ 
/* 1569 */     if (response.isOK()) {
/* 1570 */       int i = 0; for (int len = r.length; i < len; i++) {
/* 1571 */         if ((r[i] instanceof IMAPResponse))
/*      */         {
/* 1574 */           IMAPResponse ir = (IMAPResponse)r[i];
/* 1575 */           if (ir.keyEquals("NAMESPACE")) {
/* 1576 */             if (namespace == null)
/* 1577 */               namespace = new Namespaces(ir);
/* 1578 */             r[i] = null;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1584 */     notifyResponseHandlers(r);
/* 1585 */     handleResult(response);
/* 1586 */     return namespace;
/*      */   }
/*      */ 
/*      */   public Quota[] getQuotaRoot(String mbox)
/*      */     throws ProtocolException
/*      */   {
/* 1599 */     if (!hasCapability("QUOTA")) {
/* 1600 */       throw new BadCommandException("GETQUOTAROOT not supported");
/*      */     }
/*      */ 
/* 1603 */     mbox = BASE64MailboxEncoder.encode(mbox);
/*      */ 
/* 1605 */     Argument args = new Argument();
/* 1606 */     args.writeString(mbox);
/*      */ 
/* 1608 */     Response[] r = command("GETQUOTAROOT", args);
/*      */ 
/* 1610 */     Response response = r[(r.length - 1)];
/*      */ 
/* 1612 */     Hashtable tab = new Hashtable();
/*      */ 
/* 1615 */     if (response.isOK()) {
/* 1616 */       int i = 0; for (int len = r.length; i < len; i++) {
/* 1617 */         if ((r[i] instanceof IMAPResponse))
/*      */         {
/* 1620 */           IMAPResponse ir = (IMAPResponse)r[i];
/* 1621 */           if (ir.keyEquals("QUOTAROOT"))
/*      */           {
/* 1626 */             ir.readAtomString();
/*      */ 
/* 1628 */             String root = null;
/* 1629 */             while ((root = ir.readAtomString()) != null)
/* 1630 */               tab.put(root, new Quota(root));
/* 1631 */             r[i] = null;
/* 1632 */           } else if (ir.keyEquals("QUOTA")) {
/* 1633 */             Quota quota = parseQuota(ir);
/* 1634 */             Quota q = (Quota)tab.get(quota.quotaRoot);
/* 1635 */             if ((q != null) && (q.resources != null));
/* 1638 */             tab.put(quota.quotaRoot, quota);
/* 1639 */             r[i] = null;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1645 */     notifyResponseHandlers(r);
/* 1646 */     handleResult(response);
/*      */ 
/* 1648 */     Quota[] qa = new Quota[tab.size()];
/* 1649 */     Enumeration e = tab.elements();
/* 1650 */     for (int i = 0; e.hasMoreElements(); i++)
/* 1651 */       qa[i] = ((Quota)e.nextElement());
/* 1652 */     return qa;
/*      */   }
/*      */ 
/*      */   public Quota[] getQuota(String root)
/*      */     throws ProtocolException
/*      */   {
/* 1664 */     if (!hasCapability("QUOTA")) {
/* 1665 */       throw new BadCommandException("QUOTA not supported");
/*      */     }
/* 1667 */     Argument args = new Argument();
/* 1668 */     args.writeString(root);
/*      */ 
/* 1670 */     Response[] r = command("GETQUOTA", args);
/*      */ 
/* 1672 */     Quota quota = null;
/* 1673 */     Vector v = new Vector();
/* 1674 */     Response response = r[(r.length - 1)];
/*      */ 
/* 1677 */     if (response.isOK()) {
/* 1678 */       int i = 0; for (int len = r.length; i < len; i++) {
/* 1679 */         if ((r[i] instanceof IMAPResponse))
/*      */         {
/* 1682 */           IMAPResponse ir = (IMAPResponse)r[i];
/* 1683 */           if (ir.keyEquals("QUOTA")) {
/* 1684 */             quota = parseQuota(ir);
/* 1685 */             v.addElement(quota);
/* 1686 */             r[i] = null;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1692 */     notifyResponseHandlers(r);
/* 1693 */     handleResult(response);
/* 1694 */     Quota[] qa = new Quota[v.size()];
/* 1695 */     v.copyInto(qa);
/* 1696 */     return qa;
/*      */   }
/*      */ 
/*      */   public void setQuota(Quota quota)
/*      */     throws ProtocolException
/*      */   {
/* 1707 */     if (!hasCapability("QUOTA")) {
/* 1708 */       throw new BadCommandException("QUOTA not supported");
/*      */     }
/* 1710 */     Argument args = new Argument();
/* 1711 */     args.writeString(quota.quotaRoot);
/* 1712 */     Argument qargs = new Argument();
/* 1713 */     if (quota.resources != null) {
/* 1714 */       for (int i = 0; i < quota.resources.length; i++) {
/* 1715 */         qargs.writeAtom(quota.resources[i].name);
/* 1716 */         qargs.writeNumber(quota.resources[i].limit);
/*      */       }
/*      */     }
/* 1719 */     args.writeArgument(qargs);
/*      */ 
/* 1721 */     Response[] r = command("SETQUOTA", args);
/* 1722 */     Response response = r[(r.length - 1)];
/*      */ 
/* 1749 */     notifyResponseHandlers(r);
/* 1750 */     handleResult(response);
/*      */   }
/*      */ 
/*      */   private Quota parseQuota(Response r)
/*      */     throws ParsingException
/*      */   {
/* 1763 */     String quotaRoot = r.readAtomString();
/* 1764 */     Quota q = new Quota(quotaRoot);
/* 1765 */     r.skipSpaces();
/*      */ 
/* 1767 */     if (r.readByte() != 40) {
/* 1768 */       throw new ParsingException("parse error in QUOTA");
/*      */     }
/* 1770 */     Vector v = new Vector();
/* 1771 */     while (r.peekByte() != 41)
/*      */     {
/* 1773 */       String name = r.readAtom();
/* 1774 */       if (name != null) {
/* 1775 */         long usage = r.readLong();
/* 1776 */         long limit = r.readLong();
/* 1777 */         Quota.Resource res = new Quota.Resource(name, usage, limit);
/* 1778 */         v.addElement(res);
/*      */       }
/*      */     }
/* 1781 */     r.readByte();
/* 1782 */     q.resources = new Quota.Resource[v.size()];
/* 1783 */     v.copyInto(q.resources);
/* 1784 */     return q;
/*      */   }
/*      */ 
/*      */   public void setACL(String mbox, char modifier, ACL acl)
/*      */     throws ProtocolException
/*      */   {
/* 1795 */     if (!hasCapability("ACL")) {
/* 1796 */       throw new BadCommandException("ACL not supported");
/*      */     }
/*      */ 
/* 1799 */     mbox = BASE64MailboxEncoder.encode(mbox);
/*      */ 
/* 1801 */     Argument args = new Argument();
/* 1802 */     args.writeString(mbox);
/* 1803 */     args.writeString(acl.getName());
/* 1804 */     String rights = acl.getRights().toString();
/* 1805 */     if ((modifier == '+') || (modifier == '-'))
/* 1806 */       rights = modifier + rights;
/* 1807 */     args.writeString(rights);
/*      */ 
/* 1809 */     Response[] r = command("SETACL", args);
/* 1810 */     Response response = r[(r.length - 1)];
/*      */ 
/* 1813 */     notifyResponseHandlers(r);
/* 1814 */     handleResult(response);
/*      */   }
/*      */ 
/*      */   public void deleteACL(String mbox, String user)
/*      */     throws ProtocolException
/*      */   {
/* 1823 */     if (!hasCapability("ACL")) {
/* 1824 */       throw new BadCommandException("ACL not supported");
/*      */     }
/*      */ 
/* 1827 */     mbox = BASE64MailboxEncoder.encode(mbox);
/*      */ 
/* 1829 */     Argument args = new Argument();
/* 1830 */     args.writeString(mbox);
/* 1831 */     args.writeString(user);
/*      */ 
/* 1833 */     Response[] r = command("DELETEACL", args);
/* 1834 */     Response response = r[(r.length - 1)];
/*      */ 
/* 1837 */     notifyResponseHandlers(r);
/* 1838 */     handleResult(response);
/*      */   }
/*      */ 
/*      */   public ACL[] getACL(String mbox)
/*      */     throws ProtocolException
/*      */   {
/* 1847 */     if (!hasCapability("ACL")) {
/* 1848 */       throw new BadCommandException("ACL not supported");
/*      */     }
/*      */ 
/* 1851 */     mbox = BASE64MailboxEncoder.encode(mbox);
/*      */ 
/* 1853 */     Argument args = new Argument();
/* 1854 */     args.writeString(mbox);
/*      */ 
/* 1856 */     Response[] r = command("GETACL", args);
/* 1857 */     Response response = r[(r.length - 1)];
/*      */ 
/* 1860 */     Vector v = new Vector();
/* 1861 */     if (response.isOK()) {
/* 1862 */       int i = 0; for (int len = r.length; i < len; i++) {
/* 1863 */         if ((r[i] instanceof IMAPResponse))
/*      */         {
/* 1866 */           IMAPResponse ir = (IMAPResponse)r[i];
/* 1867 */           if (ir.keyEquals("ACL"))
/*      */           {
/* 1871 */             ir.readAtomString();
/* 1872 */             String name = null;
/* 1873 */             while ((name = ir.readAtomString()) != null) {
/* 1874 */               String rights = ir.readAtomString();
/* 1875 */               if (rights == null)
/*      */                 break;
/* 1877 */               ACL acl = new ACL(name, new Rights(rights));
/* 1878 */               v.addElement(acl);
/*      */             }
/* 1880 */             r[i] = null;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1886 */     notifyResponseHandlers(r);
/* 1887 */     handleResult(response);
/* 1888 */     ACL[] aa = new ACL[v.size()];
/* 1889 */     v.copyInto(aa);
/* 1890 */     return aa;
/*      */   }
/*      */ 
/*      */   public Rights[] listRights(String mbox, String user)
/*      */     throws ProtocolException
/*      */   {
/* 1900 */     if (!hasCapability("ACL")) {
/* 1901 */       throw new BadCommandException("ACL not supported");
/*      */     }
/*      */ 
/* 1904 */     mbox = BASE64MailboxEncoder.encode(mbox);
/*      */ 
/* 1906 */     Argument args = new Argument();
/* 1907 */     args.writeString(mbox);
/* 1908 */     args.writeString(user);
/*      */ 
/* 1910 */     Response[] r = command("LISTRIGHTS", args);
/* 1911 */     Response response = r[(r.length - 1)];
/*      */ 
/* 1914 */     Vector v = new Vector();
/* 1915 */     if (response.isOK()) {
/* 1916 */       int i = 0; for (int len = r.length; i < len; i++) {
/* 1917 */         if ((r[i] instanceof IMAPResponse))
/*      */         {
/* 1920 */           IMAPResponse ir = (IMAPResponse)r[i];
/* 1921 */           if (ir.keyEquals("LISTRIGHTS"))
/*      */           {
/* 1925 */             ir.readAtomString();
/*      */ 
/* 1927 */             ir.readAtomString();
/*      */             String rights;
/* 1929 */             while ((rights = ir.readAtomString()) != null)
/* 1930 */               v.addElement(new Rights(rights));
/* 1931 */             r[i] = null;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1937 */     notifyResponseHandlers(r);
/* 1938 */     handleResult(response);
/* 1939 */     Rights[] ra = new Rights[v.size()];
/* 1940 */     v.copyInto(ra);
/* 1941 */     return ra;
/*      */   }
/*      */ 
/*      */   public Rights myRights(String mbox)
/*      */     throws ProtocolException
/*      */   {
/* 1950 */     if (!hasCapability("ACL")) {
/* 1951 */       throw new BadCommandException("ACL not supported");
/*      */     }
/*      */ 
/* 1954 */     mbox = BASE64MailboxEncoder.encode(mbox);
/*      */ 
/* 1956 */     Argument args = new Argument();
/* 1957 */     args.writeString(mbox);
/*      */ 
/* 1959 */     Response[] r = command("MYRIGHTS", args);
/* 1960 */     Response response = r[(r.length - 1)];
/*      */ 
/* 1963 */     Rights rights = null;
/* 1964 */     if (response.isOK()) {
/* 1965 */       int i = 0; for (int len = r.length; i < len; i++) {
/* 1966 */         if ((r[i] instanceof IMAPResponse))
/*      */         {
/* 1969 */           IMAPResponse ir = (IMAPResponse)r[i];
/* 1970 */           if (ir.keyEquals("MYRIGHTS"))
/*      */           {
/* 1973 */             ir.readAtomString();
/* 1974 */             String rs = ir.readAtomString();
/* 1975 */             if (rights == null)
/* 1976 */               rights = new Rights(rs);
/* 1977 */             r[i] = null;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1983 */     notifyResponseHandlers(r);
/* 1984 */     handleResult(response);
/* 1985 */     return rights;
/*      */   }
/*      */ 
/*      */   public synchronized void idleStart()
/*      */     throws ProtocolException
/*      */   {
/* 2012 */     if (!hasCapability("IDLE")) {
/* 2013 */       throw new BadCommandException("IDLE not supported");
/*      */     }
/*      */     Response r;
/*      */     try
/*      */     {
/* 2018 */       this.idleTag = writeCommand("IDLE", null);
/* 2019 */       r = readResponse();
/*      */     } catch (LiteralException lex) {
/* 2021 */       r = lex.getResponse();
/*      */     }
/*      */     catch (Exception ex) {
/* 2024 */       r = Response.byeResponse(ex);
/*      */     }
/*      */ 
/* 2027 */     if (!r.isContinuation())
/* 2028 */       handleResult(r);
/*      */   }
/*      */ 
/*      */   public synchronized Response readIdleResponse()
/*      */   {
/* 2041 */     if (this.idleTag == null)
/* 2042 */       return null;
/* 2043 */     Response r = null;
/* 2044 */     while (r == null) {
/*      */       try {
/* 2046 */         r = readResponse();
/*      */       }
/*      */       catch (InterruptedIOException iioex)
/*      */       {
/* 2054 */         if (iioex.bytesTransferred == 0) {
/* 2055 */           r = null;
/*      */         }
/*      */         else
/* 2058 */           r = Response.byeResponse(iioex);
/*      */       }
/*      */       catch (IOException ioex) {
/* 2061 */         r = Response.byeResponse(ioex);
/*      */       }
/*      */       catch (ProtocolException pex) {
/* 2064 */         r = Response.byeResponse(pex);
/*      */       }
/*      */     }
/* 2067 */     return r;
/*      */   }
/*      */ 
/*      */   public boolean processIdleResponse(Response r)
/*      */     throws ProtocolException
/*      */   {
/* 2078 */     Response[] responses = new Response[1];
/* 2079 */     responses[0] = r;
/* 2080 */     boolean done = false;
/* 2081 */     notifyResponseHandlers(responses);
/*      */ 
/* 2083 */     if (r.isBYE()) {
/* 2084 */       done = true;
/*      */     }
/*      */ 
/* 2087 */     if ((r.isTagged()) && (r.getTag().equals(this.idleTag))) {
/* 2088 */       done = true;
/*      */     }
/* 2090 */     if (done) {
/* 2091 */       this.idleTag = null;
/*      */     }
/* 2093 */     handleResult(r);
/* 2094 */     return !done;
/*      */   }
/*      */ 
/*      */   public void idleAbort()
/*      */     throws ProtocolException
/*      */   {
/* 2111 */     OutputStream os = getOutputStream();
/*      */     try {
/* 2113 */       os.write(DONE);
/* 2114 */       os.flush();
/*      */     }
/*      */     catch (IOException ex)
/*      */     {
/*      */     }
/*      */   }
/*      */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.protocol.IMAPProtocol
 * JD-Core Version:    0.6.1
 */