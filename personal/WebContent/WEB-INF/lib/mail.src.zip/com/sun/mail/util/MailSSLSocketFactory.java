/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.security.KeyManagementException;
/*     */ import java.security.KeyStore;
/*     */ import java.security.SecureRandom;
/*     */ import java.security.cert.CertificateException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.net.ssl.KeyManager;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import javax.net.ssl.TrustManager;
/*     */ import javax.net.ssl.TrustManagerFactory;
/*     */ import javax.net.ssl.X509TrustManager;
/*     */ 
/*     */ public class MailSSLSocketFactory extends SSLSocketFactory
/*     */ {
/*     */   private boolean trustAllHosts;
/*  67 */   private String[] trustedHosts = null;
/*     */   private SSLContext sslcontext;
/*     */   private KeyManager[] keyManagers;
/*     */   private TrustManager[] trustManagers;
/*     */   private SecureRandom secureRandom;
/*  82 */   private SSLSocketFactory adapteeFactory = null;
/*     */ 
/*     */   public MailSSLSocketFactory()
/*     */     throws GeneralSecurityException
/*     */   {
/*  90 */     this("TLS");
/*     */   }
/*     */ 
/*     */   public MailSSLSocketFactory(String protocol)
/*     */     throws GeneralSecurityException
/*     */   {
/* 104 */     this.trustAllHosts = false;
/*     */ 
/* 107 */     this.sslcontext = SSLContext.getInstance(protocol);
/*     */ 
/* 110 */     this.keyManagers = null;
/* 111 */     this.trustManagers = new TrustManager[] { new MailTrustManager(null) };
/* 112 */     this.secureRandom = null;
/*     */ 
/* 115 */     newAdapteeFactory();
/*     */   }
/*     */ 
/*     */   private synchronized void newAdapteeFactory()
/*     */     throws KeyManagementException
/*     */   {
/* 126 */     this.sslcontext.init(this.keyManagers, this.trustManagers, this.secureRandom);
/*     */ 
/* 129 */     this.adapteeFactory = this.sslcontext.getSocketFactory();
/*     */   }
/*     */ 
/*     */   public synchronized KeyManager[] getKeyManagers()
/*     */   {
/* 136 */     return (KeyManager[])this.keyManagers.clone();
/*     */   }
/*     */ 
/*     */   public synchronized void setKeyManagers(KeyManager[] keyManagers)
/*     */     throws GeneralSecurityException
/*     */   {
/* 144 */     this.keyManagers = ((KeyManager[])keyManagers.clone());
/* 145 */     newAdapteeFactory();
/*     */   }
/*     */ 
/*     */   public synchronized SecureRandom getSecureRandom()
/*     */   {
/* 152 */     return this.secureRandom;
/*     */   }
/*     */ 
/*     */   public synchronized void setSecureRandom(SecureRandom secureRandom)
/*     */     throws GeneralSecurityException
/*     */   {
/* 160 */     this.secureRandom = secureRandom;
/* 161 */     newAdapteeFactory();
/*     */   }
/*     */ 
/*     */   public synchronized TrustManager[] getTrustManagers()
/*     */   {
/* 168 */     return this.trustManagers;
/*     */   }
/*     */ 
/*     */   public synchronized void setTrustManagers(TrustManager[] trustManagers)
/*     */     throws GeneralSecurityException
/*     */   {
/* 176 */     this.trustManagers = trustManagers;
/* 177 */     newAdapteeFactory();
/*     */   }
/*     */ 
/*     */   public synchronized boolean isTrustAllHosts()
/*     */   {
/* 184 */     return this.trustAllHosts;
/*     */   }
/*     */ 
/*     */   public synchronized void setTrustAllHosts(boolean trustAllHosts)
/*     */   {
/* 191 */     this.trustAllHosts = trustAllHosts;
/*     */   }
/*     */ 
/*     */   public synchronized String[] getTrustedHosts()
/*     */   {
/* 198 */     return (String[])this.trustedHosts.clone();
/*     */   }
/*     */ 
/*     */   public synchronized void setTrustedHosts(String[] trustedHosts)
/*     */   {
/* 205 */     this.trustedHosts = ((String[])trustedHosts.clone());
/*     */   }
/*     */ 
/*     */   public synchronized boolean isServerTrusted(String server, SSLSocket sslSocket)
/*     */   {
/* 223 */     if (this.trustAllHosts) {
/* 224 */       return true;
/*     */     }
/*     */ 
/* 228 */     if (this.trustedHosts != null) {
/* 229 */       return Arrays.asList(this.trustedHosts).contains(server);
/*     */     }
/*     */ 
/* 232 */     return true;
/*     */   }
/*     */ 
/*     */   public synchronized Socket createSocket(Socket socket, String s, int i, boolean flag)
/*     */     throws IOException
/*     */   {
/* 245 */     return this.adapteeFactory.createSocket(socket, s, i, flag);
/*     */   }
/*     */ 
/*     */   public synchronized String[] getDefaultCipherSuites()
/*     */   {
/* 253 */     return this.adapteeFactory.getDefaultCipherSuites();
/*     */   }
/*     */ 
/*     */   public synchronized String[] getSupportedCipherSuites()
/*     */   {
/* 261 */     return this.adapteeFactory.getSupportedCipherSuites();
/*     */   }
/*     */ 
/*     */   public synchronized Socket createSocket()
/*     */     throws IOException
/*     */   {
/* 269 */     return this.adapteeFactory.createSocket();
/*     */   }
/*     */ 
/*     */   public synchronized Socket createSocket(InetAddress inetaddress, int i, InetAddress inetaddress1, int j)
/*     */     throws IOException
/*     */   {
/* 279 */     return this.adapteeFactory.createSocket(inetaddress, i, inetaddress1, j);
/*     */   }
/*     */ 
/*     */   public synchronized Socket createSocket(InetAddress inetaddress, int i)
/*     */     throws IOException
/*     */   {
/* 288 */     return this.adapteeFactory.createSocket(inetaddress, i);
/*     */   }
/*     */ 
/*     */   public synchronized Socket createSocket(String s, int i, InetAddress inetaddress, int j)
/*     */     throws IOException, UnknownHostException
/*     */   {
/* 299 */     return this.adapteeFactory.createSocket(s, i, inetaddress, j);
/*     */   }
/*     */ 
/*     */   public synchronized Socket createSocket(String s, int i)
/*     */     throws IOException, UnknownHostException
/*     */   {
/* 308 */     return this.adapteeFactory.createSocket(s, i);
/*     */   }
/*     */ 
/*     */   private class MailTrustManager
/*     */     implements X509TrustManager
/*     */   {
/* 322 */     private X509TrustManager adapteeTrustManager = null;
/*     */ 
/*     */     private MailTrustManager()
/*     */       throws GeneralSecurityException
/*     */     {
/* 328 */       TrustManagerFactory tmf = TrustManagerFactory.getInstance("X509");
/* 329 */       tmf.init((KeyStore)null);
/* 330 */       this.adapteeTrustManager = ((X509TrustManager)tmf.getTrustManagers()[0]);
/*     */     }
/*     */ 
/*     */     public void checkClientTrusted(X509Certificate[] certs, String authType)
/*     */       throws CertificateException
/*     */     {
/* 339 */       if ((!MailSSLSocketFactory.this.trustAllHosts) && (MailSSLSocketFactory.this.trustedHosts == null))
/* 340 */         this.adapteeTrustManager.checkClientTrusted(certs, authType);
/*     */     }
/*     */ 
/*     */     public void checkServerTrusted(X509Certificate[] certs, String authType)
/*     */       throws CertificateException
/*     */     {
/* 350 */       if ((!MailSSLSocketFactory.this.trustAllHosts) && (MailSSLSocketFactory.this.trustedHosts == null))
/* 351 */         this.adapteeTrustManager.checkServerTrusted(certs, authType);
/*     */     }
/*     */ 
/*     */     public X509Certificate[] getAcceptedIssuers()
/*     */     {
/* 358 */       return this.adapteeTrustManager.getAcceptedIssuers();
/*     */     }
/*     */ 
/*     */     MailTrustManager(MailSSLSocketFactory.1 x1)
/*     */       throws GeneralSecurityException
/*     */     {
/* 319 */       this();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.util.MailSSLSocketFactory
 * JD-Core Version:    0.6.1
 */