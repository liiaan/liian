/*     */ package com.sun.mail.imap.protocol;
/*     */ 
/*     */ import com.sun.mail.iap.Argument;
/*     */ import java.io.IOException;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import javax.mail.Address;
/*     */ import javax.mail.Flags;
/*     */ import javax.mail.Flags.Flag;
/*     */ import javax.mail.Message.RecipientType;
/*     */ import javax.mail.search.AddressTerm;
/*     */ import javax.mail.search.AndTerm;
/*     */ import javax.mail.search.BodyTerm;
/*     */ import javax.mail.search.DateTerm;
/*     */ import javax.mail.search.FlagTerm;
/*     */ import javax.mail.search.FromStringTerm;
/*     */ import javax.mail.search.FromTerm;
/*     */ import javax.mail.search.HeaderTerm;
/*     */ import javax.mail.search.MessageIDTerm;
/*     */ import javax.mail.search.NotTerm;
/*     */ import javax.mail.search.OrTerm;
/*     */ import javax.mail.search.ReceivedDateTerm;
/*     */ import javax.mail.search.RecipientStringTerm;
/*     */ import javax.mail.search.RecipientTerm;
/*     */ import javax.mail.search.SearchException;
/*     */ import javax.mail.search.SearchTerm;
/*     */ import javax.mail.search.SentDateTerm;
/*     */ import javax.mail.search.SizeTerm;
/*     */ import javax.mail.search.StringTerm;
/*     */ import javax.mail.search.SubjectTerm;
/*     */ 
/*     */ class SearchSequence
/*     */ {
/* 353 */   private static String[] monthTable = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
/*     */ 
/* 359 */   private static Calendar cal = new GregorianCalendar();
/*     */ 
/*     */   static Argument generateSequence(SearchTerm term, String charset)
/*     */     throws SearchException, IOException
/*     */   {
/*  62 */     if ((term instanceof AndTerm))
/*  63 */       return and((AndTerm)term, charset);
/*  64 */     if ((term instanceof OrTerm))
/*  65 */       return or((OrTerm)term, charset);
/*  66 */     if ((term instanceof NotTerm))
/*  67 */       return not((NotTerm)term, charset);
/*  68 */     if ((term instanceof HeaderTerm))
/*  69 */       return header((HeaderTerm)term, charset);
/*  70 */     if ((term instanceof FlagTerm))
/*  71 */       return flag((FlagTerm)term);
/*  72 */     if ((term instanceof FromTerm)) {
/*  73 */       FromTerm fterm = (FromTerm)term;
/*  74 */       return from(fterm.getAddress().toString(), charset);
/*     */     }
/*  76 */     if ((term instanceof FromStringTerm)) {
/*  77 */       FromStringTerm fterm = (FromStringTerm)term;
/*  78 */       return from(fterm.getPattern(), charset);
/*     */     }
/*  80 */     if ((term instanceof RecipientTerm)) {
/*  81 */       RecipientTerm rterm = (RecipientTerm)term;
/*  82 */       return recipient(rterm.getRecipientType(), rterm.getAddress().toString(), charset);
/*     */     }
/*     */ 
/*  86 */     if ((term instanceof RecipientStringTerm)) {
/*  87 */       RecipientStringTerm rterm = (RecipientStringTerm)term;
/*  88 */       return recipient(rterm.getRecipientType(), rterm.getPattern(), charset);
/*     */     }
/*     */ 
/*  92 */     if ((term instanceof SubjectTerm))
/*  93 */       return subject((SubjectTerm)term, charset);
/*  94 */     if ((term instanceof BodyTerm))
/*  95 */       return body((BodyTerm)term, charset);
/*  96 */     if ((term instanceof SizeTerm))
/*  97 */       return size((SizeTerm)term);
/*  98 */     if ((term instanceof SentDateTerm))
/*  99 */       return sentdate((SentDateTerm)term);
/* 100 */     if ((term instanceof ReceivedDateTerm))
/* 101 */       return receiveddate((ReceivedDateTerm)term);
/* 102 */     if ((term instanceof MessageIDTerm)) {
/* 103 */       return messageid((MessageIDTerm)term, charset);
/*     */     }
/* 105 */     throw new SearchException("Search too complex");
/*     */   }
/*     */ 
/*     */   static boolean isAscii(SearchTerm term)
/*     */   {
/* 113 */     if (((term instanceof AndTerm)) || ((term instanceof OrTerm)))
/*     */     {
/*     */       SearchTerm[] terms;
/*     */       SearchTerm[] terms;
/* 115 */       if ((term instanceof AndTerm))
/* 116 */         terms = ((AndTerm)term).getTerms();
/*     */       else {
/* 118 */         terms = ((OrTerm)term).getTerms();
/*     */       }
/* 120 */       for (int i = 0; i < terms.length; i++)
/* 121 */         if (!isAscii(terms[i]))
/* 122 */           return false; 
/*     */     } else { if ((term instanceof NotTerm))
/* 124 */         return isAscii(((NotTerm)term).getTerm());
/* 125 */       if ((term instanceof StringTerm))
/* 126 */         return isAscii(((StringTerm)term).getPattern());
/* 127 */       if ((term instanceof AddressTerm)) {
/* 128 */         return isAscii(((AddressTerm)term).getAddress().toString());
/*     */       }
/*     */     }
/* 131 */     return true;
/*     */   }
/*     */ 
/*     */   private static boolean isAscii(String s) {
/* 135 */     int l = s.length();
/*     */ 
/* 137 */     for (int i = 0; i < l; i++) {
/* 138 */       if (s.charAt(i) > '')
/* 139 */         return false;
/*     */     }
/* 141 */     return true;
/*     */   }
/*     */ 
/*     */   private static Argument and(AndTerm term, String charset)
/*     */     throws SearchException, IOException
/*     */   {
/* 147 */     SearchTerm[] terms = term.getTerms();
/*     */ 
/* 149 */     Argument result = generateSequence(terms[0], charset);
/*     */ 
/* 151 */     for (int i = 1; i < terms.length; i++)
/* 152 */       result.append(generateSequence(terms[i], charset));
/* 153 */     return result;
/*     */   }
/*     */ 
/*     */   private static Argument or(OrTerm term, String charset) throws SearchException, IOException
/*     */   {
/* 158 */     SearchTerm[] terms = term.getTerms();
/*     */ 
/* 164 */     if (terms.length > 2) {
/* 165 */       SearchTerm t = terms[0];
/*     */ 
/* 168 */       for (int i = 1; i < terms.length; i++) {
/* 169 */         t = new OrTerm(t, terms[i]);
/*     */       }
/* 171 */       term = (OrTerm)t;
/*     */ 
/* 173 */       terms = term.getTerms();
/*     */     }
/*     */ 
/* 177 */     Argument result = new Argument();
/*     */ 
/* 180 */     if (terms.length > 1) {
/* 181 */       result.writeAtom("OR");
/*     */     }
/*     */ 
/* 188 */     if (((terms[0] instanceof AndTerm)) || ((terms[0] instanceof FlagTerm)))
/* 189 */       result.writeArgument(generateSequence(terms[0], charset));
/*     */     else {
/* 191 */       result.append(generateSequence(terms[0], charset));
/*     */     }
/*     */ 
/* 194 */     if (terms.length > 1) {
/* 195 */       if (((terms[1] instanceof AndTerm)) || ((terms[1] instanceof FlagTerm)))
/* 196 */         result.writeArgument(generateSequence(terms[1], charset));
/*     */       else {
/* 198 */         result.append(generateSequence(terms[1], charset));
/*     */       }
/*     */     }
/* 201 */     return result;
/*     */   }
/*     */ 
/*     */   private static Argument not(NotTerm term, String charset) throws SearchException, IOException
/*     */   {
/* 206 */     Argument result = new Argument();
/*     */ 
/* 209 */     result.writeAtom("NOT");
/*     */ 
/* 216 */     SearchTerm nterm = term.getTerm();
/* 217 */     if (((nterm instanceof AndTerm)) || ((nterm instanceof FlagTerm)))
/* 218 */       result.writeArgument(generateSequence(nterm, charset));
/*     */     else {
/* 220 */       result.append(generateSequence(nterm, charset));
/*     */     }
/* 222 */     return result;
/*     */   }
/*     */ 
/*     */   private static Argument header(HeaderTerm term, String charset) throws SearchException, IOException
/*     */   {
/* 227 */     Argument result = new Argument();
/* 228 */     result.writeAtom("HEADER");
/* 229 */     result.writeString(term.getHeaderName());
/* 230 */     result.writeString(term.getPattern(), charset);
/* 231 */     return result;
/*     */   }
/*     */ 
/*     */   private static Argument messageid(MessageIDTerm term, String charset) throws SearchException, IOException
/*     */   {
/* 236 */     Argument result = new Argument();
/* 237 */     result.writeAtom("HEADER");
/* 238 */     result.writeString("Message-ID");
/*     */ 
/* 240 */     result.writeString(term.getPattern(), charset);
/* 241 */     return result;
/*     */   }
/*     */ 
/*     */   private static Argument flag(FlagTerm term) throws SearchException {
/* 245 */     boolean set = term.getTestSet();
/*     */ 
/* 247 */     Argument result = new Argument();
/*     */ 
/* 249 */     Flags flags = term.getFlags();
/* 250 */     Flags.Flag[] sf = flags.getSystemFlags();
/* 251 */     String[] uf = flags.getUserFlags();
/* 252 */     if ((sf.length == 0) && (uf.length == 0)) {
/* 253 */       throw new SearchException("Invalid FlagTerm");
/*     */     }
/* 255 */     for (int i = 0; i < sf.length; i++) {
/* 256 */       if (sf[i] == Flags.Flag.DELETED)
/* 257 */         result.writeAtom(set ? "DELETED" : "UNDELETED");
/* 258 */       else if (sf[i] == Flags.Flag.ANSWERED)
/* 259 */         result.writeAtom(set ? "ANSWERED" : "UNANSWERED");
/* 260 */       else if (sf[i] == Flags.Flag.DRAFT)
/* 261 */         result.writeAtom(set ? "DRAFT" : "UNDRAFT");
/* 262 */       else if (sf[i] == Flags.Flag.FLAGGED)
/* 263 */         result.writeAtom(set ? "FLAGGED" : "UNFLAGGED");
/* 264 */       else if (sf[i] == Flags.Flag.RECENT)
/* 265 */         result.writeAtom(set ? "RECENT" : "OLD");
/* 266 */       else if (sf[i] == Flags.Flag.SEEN) {
/* 267 */         result.writeAtom(set ? "SEEN" : "UNSEEN");
/*     */       }
/*     */     }
/* 270 */     for (int i = 0; i < uf.length; i++) {
/* 271 */       result.writeAtom(set ? "KEYWORD" : "UNKEYWORD");
/* 272 */       result.writeAtom(uf[i]);
/*     */     }
/*     */ 
/* 275 */     return result;
/*     */   }
/*     */ 
/*     */   private static Argument from(String address, String charset) throws SearchException, IOException
/*     */   {
/* 280 */     Argument result = new Argument();
/* 281 */     result.writeAtom("FROM");
/* 282 */     result.writeString(address, charset);
/* 283 */     return result;
/*     */   }
/*     */ 
/*     */   private static Argument recipient(Message.RecipientType type, String address, String charset)
/*     */     throws SearchException, IOException
/*     */   {
/* 289 */     Argument result = new Argument();
/*     */ 
/* 291 */     if (type == Message.RecipientType.TO)
/* 292 */       result.writeAtom("TO");
/* 293 */     else if (type == Message.RecipientType.CC)
/* 294 */       result.writeAtom("CC");
/* 295 */     else if (type == Message.RecipientType.BCC)
/* 296 */       result.writeAtom("BCC");
/*     */     else {
/* 298 */       throw new SearchException("Illegal Recipient type");
/*     */     }
/* 300 */     result.writeString(address, charset);
/* 301 */     return result;
/*     */   }
/*     */ 
/*     */   private static Argument subject(SubjectTerm term, String charset) throws SearchException, IOException
/*     */   {
/* 306 */     Argument result = new Argument();
/*     */ 
/* 308 */     result.writeAtom("SUBJECT");
/* 309 */     result.writeString(term.getPattern(), charset);
/* 310 */     return result;
/*     */   }
/*     */ 
/*     */   private static Argument body(BodyTerm term, String charset) throws SearchException, IOException
/*     */   {
/* 315 */     Argument result = new Argument();
/*     */ 
/* 317 */     result.writeAtom("BODY");
/* 318 */     result.writeString(term.getPattern(), charset);
/* 319 */     return result;
/*     */   }
/*     */ 
/*     */   private static Argument size(SizeTerm term) throws SearchException
/*     */   {
/* 324 */     Argument result = new Argument();
/*     */ 
/* 326 */     switch (term.getComparison()) {
/*     */     case 5:
/* 328 */       result.writeAtom("LARGER");
/* 329 */       break;
/*     */     case 2:
/* 331 */       result.writeAtom("SMALLER");
/* 332 */       break;
/*     */     default:
/* 335 */       throw new SearchException("Cannot handle Comparison");
/*     */     }
/*     */ 
/* 338 */     result.writeNumber(term.getNumber());
/* 339 */     return result;
/*     */   }
/*     */ 
/*     */   private static synchronized String toIMAPDate(Date date)
/*     */   {
/* 362 */     StringBuffer s = new StringBuffer();
/*     */ 
/* 367 */     synchronized (cal) {
/* 368 */       cal.setTime(date);
/*     */ 
/* 370 */       s.append(cal.get(5)).append("-");
/* 371 */       s.append(monthTable[cal.get(2)]).append('-');
/* 372 */       s.append(cal.get(1));
/*     */     }
/*     */ 
/* 375 */     return s.toString();
/*     */   }
/*     */ 
/*     */   private static Argument sentdate(DateTerm term) throws SearchException
/*     */   {
/* 380 */     Argument result = new Argument();
/* 381 */     String date = toIMAPDate(term.getDate());
/*     */ 
/* 383 */     switch (term.getComparison()) {
/*     */     case 5:
/* 385 */       result.writeAtom("SENTSINCE " + date);
/* 386 */       break;
/*     */     case 3:
/* 388 */       result.writeAtom("SENTON " + date);
/* 389 */       break;
/*     */     case 2:
/* 391 */       result.writeAtom("SENTBEFORE " + date);
/* 392 */       break;
/*     */     case 6:
/* 394 */       result.writeAtom("OR SENTSINCE " + date + " SENTON " + date);
/* 395 */       break;
/*     */     case 1:
/* 397 */       result.writeAtom("OR SENTBEFORE " + date + " SENTON " + date);
/* 398 */       break;
/*     */     case 4:
/* 400 */       result.writeAtom("NOT SENTON " + date);
/* 401 */       break;
/*     */     default:
/* 403 */       throw new SearchException("Cannot handle Date Comparison");
/*     */     }
/*     */ 
/* 406 */     return result;
/*     */   }
/*     */ 
/*     */   private static Argument receiveddate(DateTerm term) throws SearchException
/*     */   {
/* 411 */     Argument result = new Argument();
/* 412 */     String date = toIMAPDate(term.getDate());
/*     */ 
/* 414 */     switch (term.getComparison()) {
/*     */     case 5:
/* 416 */       result.writeAtom("SINCE " + date);
/* 417 */       break;
/*     */     case 3:
/* 419 */       result.writeAtom("ON " + date);
/* 420 */       break;
/*     */     case 2:
/* 422 */       result.writeAtom("BEFORE " + date);
/* 423 */       break;
/*     */     case 6:
/* 425 */       result.writeAtom("OR SINCE " + date + " ON " + date);
/* 426 */       break;
/*     */     case 1:
/* 428 */       result.writeAtom("OR BEFORE " + date + " ON " + date);
/* 429 */       break;
/*     */     case 4:
/* 431 */       result.writeAtom("NOT ON " + date);
/* 432 */       break;
/*     */     default:
/* 434 */       throw new SearchException("Cannot handle Date Comparison");
/*     */     }
/*     */ 
/* 437 */     return result;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.protocol.SearchSequence
 * JD-Core Version:    0.6.1
 */