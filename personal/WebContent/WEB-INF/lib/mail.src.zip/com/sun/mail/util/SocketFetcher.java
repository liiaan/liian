/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketTimeoutException;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.CertificateParsingException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.net.SocketFactory;
/*     */ import javax.net.ssl.SSLPeerUnverifiedException;
/*     */ import javax.net.ssl.SSLSession;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import javax.security.auth.x500.X500Principal;
/*     */ 
/*     */ public class SocketFetcher
/*     */ {
/*  61 */   private static boolean debug = PropUtil.getBooleanSystemProperty("mail.socket.debug", false);
/*     */ 
/*     */   public static Socket getSocket(String host, int port, Properties props, String prefix, boolean useSSL)
/*     */     throws IOException
/*     */   {
/* 131 */     if (debug) {
/* 132 */       System.out.println("DEBUG SocketFetcher: getSocket, host " + host + ", port " + port + ", prefix " + prefix + ", useSSL " + useSSL);
/*     */     }
/*     */ 
/* 135 */     if (prefix == null)
/* 136 */       prefix = "socket";
/* 137 */     if (props == null)
/* 138 */       props = new Properties();
/* 139 */     int cto = PropUtil.getIntProperty(props, prefix + ".connectiontimeout", -1);
/*     */ 
/* 141 */     Socket socket = null;
/* 142 */     String localaddrstr = props.getProperty(prefix + ".localaddress", null);
/* 143 */     InetAddress localaddr = null;
/* 144 */     if (localaddrstr != null)
/* 145 */       localaddr = InetAddress.getByName(localaddrstr);
/* 146 */     int localport = PropUtil.getIntProperty(props, prefix + ".localport", 0);
/*     */ 
/* 149 */     boolean fb = PropUtil.getBooleanProperty(props, prefix + ".socketFactory.fallback", true);
/*     */ 
/* 151 */     boolean idCheck = PropUtil.getBooleanProperty(props, prefix + ".ssl.checkserveridentity", false);
/*     */ 
/* 154 */     int sfPort = -1;
/* 155 */     String sfErr = "unknown socket factory";
/*     */     try
/*     */     {
/* 161 */       SocketFactory sf = null;
/* 162 */       String sfPortName = null;
/* 163 */       if (useSSL) {
/* 164 */         Object sfo = props.get(prefix + ".ssl.socketFactory");
/* 165 */         if ((sfo instanceof SocketFactory)) {
/* 166 */           sf = (SocketFactory)sfo;
/* 167 */           sfErr = "SSL socket factory instance " + sf;
/*     */         }
/* 169 */         if (sf == null) {
/* 170 */           String sfClass = props.getProperty(prefix + ".ssl.socketFactory.class");
/*     */ 
/* 172 */           sf = getSocketFactory(sfClass);
/* 173 */           sfErr = "SSL socket factory class " + sfClass;
/*     */         }
/* 175 */         sfPortName = ".ssl.socketFactory.port";
/*     */       }
/*     */ 
/* 178 */       if (sf == null) {
/* 179 */         Object sfo = props.get(prefix + ".socketFactory");
/* 180 */         if ((sfo instanceof SocketFactory)) {
/* 181 */           sf = (SocketFactory)sfo;
/* 182 */           sfErr = "socket factory instance " + sf;
/*     */         }
/* 184 */         if (sf == null) {
/* 185 */           String sfClass = props.getProperty(prefix + ".socketFactory.class");
/*     */ 
/* 187 */           sf = getSocketFactory(sfClass);
/* 188 */           sfErr = "socket factory class " + sfClass;
/*     */         }
/* 190 */         sfPortName = ".socketFactory.port";
/*     */       }
/*     */ 
/* 194 */       if (sf != null) {
/* 195 */         sfPort = PropUtil.getIntProperty(props, prefix + sfPortName, -1);
/*     */ 
/* 199 */         if (sfPort == -1)
/* 200 */           sfPort = port;
/* 201 */         socket = createSocket(localaddr, localport, host, sfPort, cto, sf, useSSL, idCheck);
/*     */       }
/*     */     }
/*     */     catch (SocketTimeoutException sex) {
/* 205 */       throw sex;
/*     */     } catch (Exception ex) {
/* 207 */       if (!fb) {
/* 208 */         if ((ex instanceof InvocationTargetException)) {
/* 209 */           Throwable t = ((InvocationTargetException)ex).getTargetException();
/*     */ 
/* 211 */           if ((t instanceof Exception))
/* 212 */             ex = (Exception)t;
/*     */         }
/* 214 */         if ((ex instanceof IOException))
/* 215 */           throw ((IOException)ex);
/* 216 */         IOException ioex = new IOException("Couldn't connect using " + sfErr + " to host, port: " + host + ", " + sfPort + "; Exception: " + ex);
/*     */ 
/* 221 */         ioex.initCause(ex);
/* 222 */         throw ioex;
/*     */       }
/*     */     }
/*     */ 
/* 226 */     if (socket == null) {
/* 227 */       socket = createSocket(localaddr, localport, host, port, cto, null, useSSL, idCheck);
/*     */     }
/*     */ 
/* 230 */     int to = PropUtil.getIntProperty(props, prefix + ".timeout", -1);
/* 231 */     if (to >= 0) {
/* 232 */       socket.setSoTimeout(to);
/*     */     }
/* 234 */     configureSSLSocket(socket, props, prefix);
/* 235 */     return socket;
/*     */   }
/*     */ 
/*     */   public static Socket getSocket(String host, int port, Properties props, String prefix) throws IOException
/*     */   {
/* 240 */     return getSocket(host, port, props, prefix, false);
/*     */   }
/*     */ 
/*     */   private static Socket createSocket(InetAddress localaddr, int localport, String host, int port, int cto, SocketFactory sf, boolean useSSL, boolean idCheck)
/*     */     throws IOException
/*     */   {
/*     */     Socket socket;
/*     */     Socket socket;
/* 255 */     if (sf != null) {
/* 256 */       socket = sf.createSocket();
/*     */     }
/*     */     else
/*     */     {
/*     */       Socket socket;
/* 257 */       if (useSSL) {
/* 258 */         sf = SSLSocketFactory.getDefault();
/* 259 */         socket = sf.createSocket();
/*     */       } else {
/* 261 */         socket = new Socket(); } 
/* 262 */     }if (localaddr != null)
/* 263 */       socket.bind(new InetSocketAddress(localaddr, localport));
/* 264 */     if (cto >= 0)
/* 265 */       socket.connect(new InetSocketAddress(host, port), cto);
/*     */     else {
/* 267 */       socket.connect(new InetSocketAddress(host, port));
/*     */     }
/* 269 */     if ((idCheck) && ((socket instanceof SSLSocket)))
/* 270 */       checkServerIdentity(host, (SSLSocket)socket);
/* 271 */     if ((sf instanceof MailSSLSocketFactory)) {
/* 272 */       MailSSLSocketFactory msf = (MailSSLSocketFactory)sf;
/* 273 */       if (!msf.isServerTrusted(host, (SSLSocket)socket))
/*     */         try {
/* 275 */           socket.close();
/*     */         }
/*     */         finally
/*     */         {
/*     */         }
/*     */     }
/* 281 */     return socket;
/*     */   }
/*     */ 
/*     */   private static SocketFactory getSocketFactory(String sfClass)
/*     */     throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 292 */     if ((sfClass == null) || (sfClass.length() == 0)) {
/* 293 */       return null;
/*     */     }
/*     */ 
/* 297 */     ClassLoader cl = getContextClassLoader();
/* 298 */     Class clsSockFact = null;
/* 299 */     if (cl != null)
/*     */       try {
/* 301 */         clsSockFact = cl.loadClass(sfClass);
/*     */       } catch (ClassNotFoundException cex) {
/*     */       }
/* 304 */     if (clsSockFact == null) {
/* 305 */       clsSockFact = Class.forName(sfClass);
/*     */     }
/* 307 */     Method mthGetDefault = clsSockFact.getMethod("getDefault", new Class[0]);
/*     */ 
/* 309 */     SocketFactory sf = (SocketFactory)mthGetDefault.invoke(new Object(), new Object[0]);
/*     */ 
/* 311 */     return sf;
/*     */   }
/*     */ 
/*     */   public static Socket startTLS(Socket socket)
/*     */     throws IOException
/*     */   {
/* 321 */     return startTLS(socket, new Properties(), "socket");
/*     */   }
/*     */ 
/*     */   public static Socket startTLS(Socket socket, Properties props, String prefix)
/*     */     throws IOException
/*     */   {
/* 332 */     InetAddress a = socket.getInetAddress();
/* 333 */     String host = a.getHostName();
/* 334 */     return startTLS(socket, host, props, prefix);
/*     */   }
/*     */ 
/*     */   public static Socket startTLS(Socket socket, String host, Properties props, String prefix)
/*     */     throws IOException
/*     */   {
/* 343 */     int port = socket.getPort();
/* 344 */     if (debug) {
/* 345 */       System.out.println("DEBUG SocketFetcher: startTLS host " + host + ", port " + port);
/*     */     }
/*     */ 
/* 348 */     String sfErr = "unknown socket factory";
/*     */     try {
/* 350 */       SSLSocketFactory ssf = null;
/* 351 */       SocketFactory sf = null;
/*     */ 
/* 354 */       Object sfo = props.get(prefix + ".ssl.socketFactory");
/* 355 */       if ((sfo instanceof SocketFactory)) {
/* 356 */         sf = (SocketFactory)sfo;
/* 357 */         sfErr = "SSL socket factory instance " + sf;
/*     */       }
/* 359 */       if (sf == null) {
/* 360 */         String sfClass = props.getProperty(prefix + ".ssl.socketFactory.class");
/*     */ 
/* 362 */         sf = getSocketFactory(sfClass);
/* 363 */         sfErr = "SSL socket factory class " + sfClass;
/*     */       }
/* 365 */       if ((sf != null) && ((sf instanceof SSLSocketFactory))) {
/* 366 */         ssf = (SSLSocketFactory)sf;
/*     */       }
/*     */ 
/* 370 */       if (ssf == null) {
/* 371 */         sfo = props.get(prefix + ".socketFactory");
/* 372 */         if ((sfo instanceof SocketFactory)) {
/* 373 */           sf = (SocketFactory)sfo;
/* 374 */           sfErr = "socket factory instance " + sf;
/*     */         }
/* 376 */         if (sf == null) {
/* 377 */           String sfClass = props.getProperty(prefix + ".socketFactory.class");
/*     */ 
/* 379 */           sf = getSocketFactory(sfClass);
/* 380 */           sfErr = "socket factory class " + sfClass;
/*     */         }
/* 382 */         if ((sf != null) && ((sf instanceof SSLSocketFactory))) {
/* 383 */           ssf = (SSLSocketFactory)sf;
/*     */         }
/*     */       }
/*     */ 
/* 387 */       if (ssf == null) {
/* 388 */         ssf = (SSLSocketFactory)SSLSocketFactory.getDefault();
/* 389 */         sfErr = "default SSL socket factory";
/*     */       }
/*     */ 
/* 392 */       socket = ssf.createSocket(socket, host, port, true);
/* 393 */       boolean idCheck = PropUtil.getBooleanProperty(props, prefix + ".ssl.checkserveridentity", false);
/*     */ 
/* 395 */       if (idCheck)
/* 396 */         checkServerIdentity(host, (SSLSocket)socket);
/* 397 */       if ((ssf instanceof MailSSLSocketFactory)) {
/* 398 */         MailSSLSocketFactory msf = (MailSSLSocketFactory)ssf;
/* 399 */         if (!msf.isServerTrusted(host, (SSLSocket)socket))
/*     */           try {
/* 401 */             socket.close();
/*     */           }
/*     */           finally
/*     */           {
/*     */           }
/*     */       }
/* 407 */       configureSSLSocket(socket, props, prefix);
/*     */     } catch (Exception ex) {
/* 409 */       if ((ex instanceof InvocationTargetException)) {
/* 410 */         Throwable t = ((InvocationTargetException)ex).getTargetException();
/*     */ 
/* 412 */         if ((t instanceof Exception))
/* 413 */           ex = (Exception)t;
/*     */       }
/* 415 */       if ((ex instanceof IOException)) {
/* 416 */         throw ((IOException)ex);
/*     */       }
/* 418 */       IOException ioex = new IOException("Exception in startTLS using " + sfErr + ": host, port: " + host + ", " + port + "; Exception: " + ex);
/*     */ 
/* 423 */       ioex.initCause(ex);
/* 424 */       throw ioex;
/*     */     }
/* 426 */     return socket;
/*     */   }
/*     */ 
/*     */   private static void configureSSLSocket(Socket socket, Properties props, String prefix)
/*     */   {
/* 436 */     if (!(socket instanceof SSLSocket))
/* 437 */       return;
/* 438 */     SSLSocket sslsocket = (SSLSocket)socket;
/*     */ 
/* 440 */     String protocols = props.getProperty(prefix + ".ssl.protocols", null);
/* 441 */     if (protocols != null) {
/* 442 */       sslsocket.setEnabledProtocols(stringArray(protocols));
/*     */     }
/*     */     else
/*     */     {
/* 450 */       sslsocket.setEnabledProtocols(new String[] { "TLSv1" });
/*     */     }
/* 452 */     String ciphers = props.getProperty(prefix + ".ssl.ciphersuites", null);
/* 453 */     if (ciphers != null)
/* 454 */       sslsocket.setEnabledCipherSuites(stringArray(ciphers));
/* 455 */     if (debug) {
/* 456 */       System.out.println("DEBUG SocketFetcher: SSL protocols after " + Arrays.asList(sslsocket.getEnabledProtocols()));
/*     */ 
/* 458 */       System.out.println("DEBUG SocketFetcher: SSL ciphers after " + Arrays.asList(sslsocket.getEnabledCipherSuites()));
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void checkServerIdentity(String server, SSLSocket sslSocket)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 476 */       Certificate[] certChain = sslSocket.getSession().getPeerCertificates();
/*     */ 
/* 478 */       if ((certChain != null) && (certChain.length > 0) && ((certChain[0] instanceof X509Certificate)) && (matchCert(server, (X509Certificate)certChain[0])))
/*     */       {
/* 481 */         return;
/*     */       }
/*     */     } catch (SSLPeerUnverifiedException e) { sslSocket.close();
/* 484 */       IOException ioex = new IOException("Can't verify identity of server: " + server);
/*     */ 
/* 486 */       ioex.initCause(e);
/* 487 */       throw ioex;
/*     */     }
/*     */ 
/* 491 */     sslSocket.close();
/* 492 */     throw new IOException("Can't verify identity of server: " + server);
/*     */   }
/*     */ 
/*     */   private static boolean matchCert(String server, X509Certificate cert)
/*     */   {
/* 503 */     if (debug) {
/* 504 */       System.out.println("DEBUG SocketFetcher: matchCert server " + server + ", cert " + cert);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 514 */       Class hnc = Class.forName("sun.security.util.HostnameChecker");
/*     */ 
/* 518 */       Method getInstance = hnc.getMethod("getInstance", new Class[] { Byte.TYPE });
/*     */ 
/* 520 */       Object hostnameChecker = getInstance.invoke(new Object(), new Object[] { new Byte(2) });
/*     */ 
/* 524 */       if (debug) {
/* 525 */         System.out.println("DEBUG SocketFetcher: using sun.security.util.HostnameChecker");
/*     */       }
/* 527 */       Method match = hnc.getMethod("match", new Class[] { String.class, X509Certificate.class });
/*     */       try
/*     */       {
/* 530 */         match.invoke(hostnameChecker, new Object[] { server, cert });
/* 531 */         return true;
/*     */       } catch (InvocationTargetException cex) {
/* 533 */         if (debug)
/* 534 */           System.out.println("DEBUG SocketFetcher: FAIL: " + cex);
/* 535 */         return false;
/*     */       }
/*     */     } catch (Exception ex) {
/* 538 */       if (debug) {
/* 539 */         System.out.println("DEBUG SocketFetcher: NO sun.security.util.HostnameChecker: " + ex);
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 554 */         Collection names = cert.getSubjectAlternativeNames();
/* 555 */         if (names != null) {
/* 556 */           boolean foundName = false;
/* 557 */           for (Iterator it = names.iterator(); it.hasNext(); ) {
/* 558 */             List nameEnt = (List)it.next();
/* 559 */             Integer type = (Integer)nameEnt.get(0);
/* 560 */             if (type.intValue() == 2) {
/* 561 */               foundName = true;
/* 562 */               String name = (String)nameEnt.get(1);
/* 563 */               if (debug) {
/* 564 */                 System.out.println("DEBUG SocketFetcher: found name: " + name);
/*     */               }
/* 566 */               if (matchServer(server, name))
/* 567 */                 return true;
/*     */             }
/*     */           }
/* 570 */           if (foundName) {
/* 571 */             return false;
/*     */           }
/*     */         }
/*     */       }
/*     */       catch (CertificateParsingException ex)
/*     */       {
/*     */       }
/*     */ 
/* 579 */       Pattern p = Pattern.compile("CN=([^,]*)");
/* 580 */       Matcher m = p.matcher(cert.getSubjectX500Principal().getName());
/* 581 */       if ((m.find()) && (matchServer(server, m.group(1).trim())))
/* 582 */         return true;
/*     */     }
/* 584 */     return false;
/*     */   }
/*     */ 
/*     */   private static boolean matchServer(String server, String name)
/*     */   {
/* 595 */     if (debug) {
/* 596 */       System.out.println("DEBUG SocketFetcher: match server " + server + " with " + name);
/*     */     }
/* 598 */     if (name.startsWith("*."))
/*     */     {
/* 600 */       String tail = name.substring(2);
/* 601 */       if (tail.length() == 0)
/* 602 */         return false;
/* 603 */       int off = server.length() - tail.length();
/* 604 */       if (off < 1) {
/* 605 */         return false;
/*     */       }
/* 607 */       return (server.charAt(off - 1) == '.') && (server.regionMatches(true, off, tail, 0, tail.length()));
/*     */     }
/*     */ 
/* 610 */     return server.equalsIgnoreCase(name);
/*     */   }
/*     */ 
/*     */   private static String[] stringArray(String s)
/*     */   {
/* 618 */     StringTokenizer st = new StringTokenizer(s);
/* 619 */     List tokens = new ArrayList();
/* 620 */     while (st.hasMoreTokens())
/* 621 */       tokens.add(st.nextToken());
/* 622 */     return (String[])tokens.toArray(new String[tokens.size()]);
/*     */   }
/*     */ 
/*     */   private static ClassLoader getContextClassLoader()
/*     */   {
/* 631 */     return (ClassLoader)AccessController.doPrivileged(new PrivilegedAction()
/*     */     {
/*     */       public Object run() {
/* 634 */         ClassLoader cl = null;
/*     */         try {
/* 636 */           cl = Thread.currentThread().getContextClassLoader(); } catch (SecurityException ex) {
/*     */         }
/* 638 */         return cl;
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.util.SocketFetcher
 * JD-Core Version:    0.6.1
 */