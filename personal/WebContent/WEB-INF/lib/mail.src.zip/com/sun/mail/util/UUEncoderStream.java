/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ public class UUEncoderStream extends FilterOutputStream
/*     */ {
/*     */   private byte[] buffer;
/*  52 */   private int bufsize = 0;
/*  53 */   private boolean wrotePrefix = false;
/*     */   protected String name;
/*     */   protected int mode;
/*     */ 
/*     */   public UUEncoderStream(OutputStream out)
/*     */   {
/*  63 */     this(out, "encoder.buf", 644);
/*     */   }
/*     */ 
/*     */   public UUEncoderStream(OutputStream out, String name)
/*     */   {
/*  72 */     this(out, name, 644);
/*     */   }
/*     */ 
/*     */   public UUEncoderStream(OutputStream out, String name, int mode)
/*     */   {
/*  82 */     super(out);
/*  83 */     this.name = name;
/*  84 */     this.mode = mode;
/*  85 */     this.buffer = new byte[45];
/*     */   }
/*     */ 
/*     */   public void setNameMode(String name, int mode)
/*     */   {
/*  94 */     this.name = name;
/*  95 */     this.mode = mode;
/*     */   }
/*     */ 
/*     */   public void write(byte[] b, int off, int len) throws IOException {
/*  99 */     for (int i = 0; i < len; i++)
/* 100 */       write(b[(off + i)]);
/*     */   }
/*     */ 
/*     */   public void write(byte[] data) throws IOException {
/* 104 */     write(data, 0, data.length);
/*     */   }
/*     */ 
/*     */   public void write(int c)
/*     */     throws IOException
/*     */   {
/* 112 */     this.buffer[(this.bufsize++)] = (byte)c;
/* 113 */     if (this.bufsize == 45) {
/* 114 */       writePrefix();
/* 115 */       encode();
/* 116 */       this.bufsize = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void flush() throws IOException {
/* 121 */     if (this.bufsize > 0) {
/* 122 */       writePrefix();
/* 123 */       encode();
/*     */     }
/* 125 */     writeSuffix();
/* 126 */     this.out.flush();
/*     */   }
/*     */ 
/*     */   public void close() throws IOException {
/* 130 */     flush();
/* 131 */     this.out.close();
/*     */   }
/*     */ 
/*     */   private void writePrefix()
/*     */     throws IOException
/*     */   {
/* 138 */     if (!this.wrotePrefix) {
/* 139 */       PrintStream ps = new PrintStream(this.out);
/* 140 */       ps.println("begin " + this.mode + " " + this.name);
/* 141 */       ps.flush();
/* 142 */       this.wrotePrefix = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void writeSuffix()
/*     */     throws IOException
/*     */   {
/* 151 */     PrintStream ps = new PrintStream(this.out);
/* 152 */     ps.println(" \nend");
/* 153 */     ps.flush();
/*     */   }
/*     */ 
/*     */   private void encode()
/*     */     throws IOException
/*     */   {
/* 168 */     int i = 0;
/*     */ 
/* 171 */     this.out.write((this.bufsize & 0x3F) + 32);
/*     */ 
/* 173 */     while (i < this.bufsize) {
/* 174 */       byte a = this.buffer[(i++)];
/*     */       byte c;
/*     */       byte b;
/*     */       byte c;
/* 175 */       if (i < this.bufsize) {
/* 176 */         byte b = this.buffer[(i++)];
/*     */         byte c;
/* 177 */         if (i < this.bufsize)
/* 178 */           c = this.buffer[(i++)];
/*     */         else
/* 180 */           c = 1;
/*     */       }
/*     */       else {
/* 183 */         b = 1;
/* 184 */         c = 1;
/*     */       }
/*     */ 
/* 187 */       int c1 = a >>> 2 & 0x3F;
/* 188 */       int c2 = a << 4 & 0x30 | b >>> 4 & 0xF;
/* 189 */       int c3 = b << 2 & 0x3C | c >>> 6 & 0x3;
/* 190 */       int c4 = c & 0x3F;
/* 191 */       this.out.write(c1 + 32);
/* 192 */       this.out.write(c2 + 32);
/* 193 */       this.out.write(c3 + 32);
/* 194 */       this.out.write(c4 + 32);
/*     */     }
/*     */ 
/* 197 */     this.out.write(10);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.util.UUEncoderStream
 * JD-Core Version:    0.6.1
 */