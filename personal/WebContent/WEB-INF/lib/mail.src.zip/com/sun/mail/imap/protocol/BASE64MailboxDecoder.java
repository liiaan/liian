/*     */ package com.sun.mail.imap.protocol;
/*     */ 
/*     */ import java.text.CharacterIterator;
/*     */ import java.text.StringCharacterIterator;
/*     */ 
/*     */ public class BASE64MailboxDecoder
/*     */ {
/* 171 */   static final char[] pem_array = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', ',' };
/*     */ 
/* 182 */   private static final byte[] pem_convert_array = new byte[256];
/*     */ 
/*     */   public static String decode(String original)
/*     */   {
/*  53 */     if ((original == null) || (original.length() == 0)) {
/*  54 */       return original;
/*     */     }
/*  56 */     boolean changedString = false;
/*  57 */     int copyTo = 0;
/*     */ 
/*  59 */     char[] chars = new char[original.length()];
/*  60 */     StringCharacterIterator iter = new StringCharacterIterator(original);
/*     */ 
/*  62 */     for (char c = iter.first(); c != 65535; 
/*  63 */       c = iter.next())
/*     */     {
/*  65 */       if (c == '&') {
/*  66 */         changedString = true;
/*  67 */         copyTo = base64decode(chars, copyTo, iter);
/*     */       } else {
/*  69 */         chars[(copyTo++)] = c;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  74 */     if (changedString) {
/*  75 */       return new String(chars, 0, copyTo);
/*     */     }
/*  77 */     return original;
/*     */   }
/*     */ 
/*     */   protected static int base64decode(char[] buffer, int offset, CharacterIterator iter)
/*     */   {
/*  84 */     boolean firsttime = true;
/*  85 */     int leftover = -1;
/*     */     while (true)
/*     */     {
/*  89 */       byte orig_0 = (byte)iter.next();
/*  90 */       if (orig_0 == -1) break;
/*  91 */       if (orig_0 == 45) {
/*  92 */         if (!firsttime)
/*     */           break;
/*  94 */         buffer[(offset++)] = '&'; break;
/*     */       }
/*     */ 
/*  99 */       firsttime = false;
/*     */ 
/* 102 */       byte orig_1 = (byte)iter.next();
/* 103 */       if ((orig_1 == -1) || (orig_1 == 45))
/*     */       {
/*     */         break;
/*     */       }
/* 107 */       byte a = pem_convert_array[(orig_0 & 0xFF)];
/* 108 */       byte b = pem_convert_array[(orig_1 & 0xFF)];
/*     */ 
/* 110 */       byte current = (byte)(a << 2 & 0xFC | b >>> 4 & 0x3);
/*     */ 
/* 113 */       if (leftover != -1) {
/* 114 */         buffer[(offset++)] = (char)(leftover << 8 | current & 0xFF);
/* 115 */         leftover = -1;
/*     */       } else {
/* 117 */         leftover = current & 0xFF;
/*     */       }
/*     */ 
/* 120 */       byte orig_2 = (byte)iter.next();
/* 121 */       if (orig_2 != 61)
/*     */       {
/* 123 */         if ((orig_2 == -1) || (orig_2 == 45))
/*     */         {
/*     */           break;
/*     */         }
/*     */ 
/* 128 */         a = b;
/* 129 */         b = pem_convert_array[(orig_2 & 0xFF)];
/* 130 */         current = (byte)(a << 4 & 0xF0 | b >>> 2 & 0xF);
/*     */ 
/* 133 */         if (leftover != -1) {
/* 134 */           buffer[(offset++)] = (char)(leftover << 8 | current & 0xFF);
/* 135 */           leftover = -1;
/*     */         } else {
/* 137 */           leftover = current & 0xFF;
/*     */         }
/*     */ 
/* 140 */         byte orig_3 = (byte)iter.next();
/* 141 */         if (orig_3 != 61)
/*     */         {
/* 143 */           if ((orig_3 == -1) || (orig_3 == 45))
/*     */           {
/*     */             break;
/*     */           }
/*     */ 
/* 148 */           a = b;
/* 149 */           b = pem_convert_array[(orig_3 & 0xFF)];
/* 150 */           current = (byte)(a << 6 & 0xC0 | b & 0x3F);
/*     */ 
/* 153 */           if (leftover != -1) {
/* 154 */             buffer[(offset++)] = (char)(leftover << 8 | current & 0xFF);
/* 155 */             leftover = -1;
/*     */           } else {
/* 157 */             leftover = current & 0xFF;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 161 */     return offset;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 185 */     for (int i = 0; i < 255; i++)
/* 186 */       pem_convert_array[i] = -1;
/* 187 */     for (int i = 0; i < pem_array.length; i++)
/* 188 */       pem_convert_array[pem_array[i]] = (byte)i;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.protocol.BASE64MailboxDecoder
 * JD-Core Version:    0.6.1
 */