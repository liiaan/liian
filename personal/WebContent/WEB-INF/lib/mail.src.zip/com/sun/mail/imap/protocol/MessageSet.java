/*     */ package com.sun.mail.imap.protocol;
/*     */ 
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class MessageSet
/*     */ {
/*     */   public int start;
/*     */   public int end;
/*     */ 
/*     */   public MessageSet()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MessageSet(int start, int end)
/*     */   {
/*  51 */     this.start = start;
/*  52 */     this.end = end;
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/*  59 */     return this.end - this.start + 1;
/*     */   }
/*     */ 
/*     */   public static MessageSet[] createMessageSets(int[] msgs)
/*     */   {
/*  66 */     Vector v = new Vector();
/*     */ 
/*  69 */     for (int i = 0; i < msgs.length; i++) {
/*  70 */       MessageSet ms = new MessageSet();
/*  71 */       ms.start = msgs[i];
/*     */ 
/*  74 */       for (int j = i + 1; (j < msgs.length) && 
/*  75 */         (msgs[j] == msgs[(j - 1)] + 1); j++);
/*  78 */       ms.end = msgs[(j - 1)];
/*  79 */       v.addElement(ms);
/*  80 */       i = j - 1;
/*     */     }
/*  82 */     MessageSet[] msgsets = new MessageSet[v.size()];
/*  83 */     v.copyInto(msgsets);
/*  84 */     return msgsets;
/*     */   }
/*     */ 
/*     */   public static String toString(MessageSet[] msgsets)
/*     */   {
/*  91 */     if ((msgsets == null) || (msgsets.length == 0)) {
/*  92 */       return null;
/*     */     }
/*  94 */     int i = 0;
/*  95 */     StringBuffer s = new StringBuffer();
/*  96 */     int size = msgsets.length;
/*     */     while (true)
/*     */     {
/* 100 */       int start = msgsets[i].start;
/* 101 */       int end = msgsets[i].end;
/*     */ 
/* 103 */       if (end > start)
/* 104 */         s.append(start).append(':').append(end);
/*     */       else {
/* 106 */         s.append(start);
/*     */       }
/* 108 */       i++;
/* 109 */       if (i >= size) {
/*     */         break;
/*     */       }
/* 112 */       s.append(',');
/*     */     }
/* 114 */     return s.toString();
/*     */   }
/*     */ 
/*     */   public static int size(MessageSet[] msgsets)
/*     */   {
/* 122 */     int count = 0;
/*     */ 
/* 124 */     if (msgsets == null) {
/* 125 */       return 0;
/*     */     }
/* 127 */     for (int i = 0; i < msgsets.length; i++) {
/* 128 */       count += msgsets[i].size();
/*     */     }
/* 130 */     return count;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.protocol.MessageSet
 * JD-Core Version:    0.6.1
 */