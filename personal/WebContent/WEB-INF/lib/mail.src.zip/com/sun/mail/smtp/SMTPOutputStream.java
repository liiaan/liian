/*     */ package com.sun.mail.smtp;
/*     */ 
/*     */ import com.sun.mail.util.CRLFOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ public class SMTPOutputStream extends CRLFOutputStream
/*     */ {
/*     */   public SMTPOutputStream(OutputStream os)
/*     */   {
/*  53 */     super(os);
/*     */   }
/*     */ 
/*     */   public void write(int b)
/*     */     throws IOException
/*     */   {
/*  59 */     if (((this.lastb == 10) || (this.lastb == 13) || (this.lastb == -1)) && (b == 46)) {
/*  60 */       this.out.write(46);
/*     */     }
/*     */ 
/*  63 */     super.write(b);
/*     */   }
/*     */ 
/*     */   public void write(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/*  70 */     int lastc = this.lastb == -1 ? 10 : this.lastb;
/*  71 */     int start = off;
/*     */ 
/*  73 */     len += off;
/*  74 */     for (int i = off; i < len; i++) {
/*  75 */       if (((lastc == 10) || (lastc == 13)) && (b[i] == 46)) {
/*  76 */         super.write(b, start, i - start);
/*  77 */         this.out.write(46);
/*  78 */         start = i;
/*     */       }
/*  80 */       lastc = b[i];
/*     */     }
/*  82 */     if (len - start > 0)
/*  83 */       super.write(b, start, len - start);
/*     */   }
/*     */ 
/*     */   public void flush()
/*     */   {
/*     */   }
/*     */ 
/*     */   public void ensureAtBOL()
/*     */     throws IOException
/*     */   {
/* 107 */     if (!this.atBOL)
/* 108 */       super.writeln();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.smtp.SMTPOutputStream
 * JD-Core Version:    0.6.1
 */