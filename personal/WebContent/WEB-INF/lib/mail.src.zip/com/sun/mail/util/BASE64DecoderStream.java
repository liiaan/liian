/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ public class BASE64DecoderStream extends FilterInputStream
/*     */ {
/*  53 */   private byte[] buffer = new byte[3];
/*  54 */   private int bufsize = 0;
/*  55 */   private int index = 0;
/*     */ 
/*  59 */   private byte[] input_buffer = new byte[8190];
/*  60 */   private int input_pos = 0;
/*  61 */   private int input_len = 0;
/*     */ 
/*  63 */   private boolean ignoreErrors = false;
/*     */ 
/* 200 */   private static final char[] pem_array = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/' };
/*     */ 
/* 211 */   private static final byte[] pem_convert_array = new byte[256];
/*     */ 
/*     */   public BASE64DecoderStream(InputStream in)
/*     */   {
/*  74 */     super(in);
/*     */ 
/*  76 */     this.ignoreErrors = PropUtil.getBooleanSystemProperty("mail.mime.base64.ignoreerrors", false);
/*     */   }
/*     */ 
/*     */   public BASE64DecoderStream(InputStream in, boolean ignoreErrors)
/*     */   {
/*  87 */     super(in);
/*  88 */     this.ignoreErrors = ignoreErrors;
/*     */   }
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/* 105 */     if (this.index >= this.bufsize) {
/* 106 */       this.bufsize = decode(this.buffer, 0, this.buffer.length);
/* 107 */       if (this.bufsize <= 0)
/* 108 */         return -1;
/* 109 */       this.index = 0;
/*     */     }
/* 111 */     return this.buffer[(this.index++)] & 0xFF;
/*     */   }
/*     */ 
/*     */   public int read(byte[] buf, int off, int len)
/*     */     throws IOException
/*     */   {
/* 130 */     int off0 = off;
/* 131 */     while ((this.index < this.bufsize) && (len > 0)) {
/* 132 */       buf[(off++)] = this.buffer[(this.index++)];
/* 133 */       len--;
/*     */     }
/* 135 */     if (this.index >= this.bufsize) {
/* 136 */       this.bufsize = (this.index = 0);
/*     */     }
/* 138 */     int bsize = len / 3 * 3;
/* 139 */     if (bsize > 0) {
/* 140 */       int size = decode(buf, off, bsize);
/* 141 */       off += size;
/* 142 */       len -= size;
/*     */ 
/* 144 */       if (size != bsize) {
/* 145 */         if (off == off0) {
/* 146 */           return -1;
/*     */         }
/* 148 */         return off - off0;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 153 */     for (; len > 0; len--) {
/* 154 */       int c = read();
/* 155 */       if (c == -1)
/*     */         break;
/* 157 */       buf[(off++)] = (byte)c;
/*     */     }
/*     */ 
/* 160 */     if (off == off0) {
/* 161 */       return -1;
/*     */     }
/* 163 */     return off - off0;
/*     */   }
/*     */ 
/*     */   public long skip(long n)
/*     */     throws IOException
/*     */   {
/* 170 */     long skipped = 0L;
/* 171 */     while ((n-- > 0L) && (read() >= 0))
/* 172 */       skipped += 1L;
/* 173 */     return skipped;
/*     */   }
/*     */ 
/*     */   public boolean markSupported()
/*     */   {
/* 181 */     return false;
/*     */   }
/*     */ 
/*     */   public int available()
/*     */     throws IOException
/*     */   {
/* 193 */     return this.in.available() * 3 / 4 + (this.bufsize - this.index);
/*     */   }
/*     */ 
/*     */   private int decode(byte[] outbuf, int pos, int len)
/*     */     throws IOException
/*     */   {
/* 235 */     int pos0 = pos;
/* 236 */     while (len >= 3)
/*     */     {
/* 242 */       int got = 0;
/* 243 */       int val = 0;
/* 244 */       while (got < 4) {
/* 245 */         int i = getByte();
/* 246 */         if ((i == -1) || (i == -2))
/*     */         {
/*     */           boolean atEOF;
/*     */           boolean atEOF;
/* 248 */           if (i == -1) {
/* 249 */             if (got == 0)
/* 250 */               return pos - pos0;
/* 251 */             if (!this.ignoreErrors) {
/* 252 */               throw new DecodingException("BASE64Decoder: Error in encoded stream: needed 4 valid base64 characters but only got " + got + " before EOF" + recentChars());
/*     */             }
/*     */ 
/* 257 */             atEOF = true;
/*     */           }
/*     */           else
/*     */           {
/* 261 */             if ((got < 2) && (!this.ignoreErrors)) {
/* 262 */               throw new DecodingException("BASE64Decoder: Error in encoded stream: needed at least 2 valid base64 characters, but only got " + got + " before padding character (=)" + recentChars());
/*     */             }
/*     */ 
/* 270 */             if (got == 0)
/* 271 */               return pos - pos0;
/* 272 */             atEOF = false;
/*     */           }
/*     */ 
/* 279 */           int size = got - 1;
/* 280 */           if (size == 0) {
/* 281 */             size = 1;
/*     */           }
/*     */ 
/* 284 */           got++;
/* 285 */           val <<= 6;
/*     */ 
/* 287 */           while (got < 4) {
/* 288 */             if (!atEOF)
/*     */             {
/* 291 */               i = getByte();
/* 292 */               if (i == -1) {
/* 293 */                 if (!this.ignoreErrors) {
/* 294 */                   throw new DecodingException("BASE64Decoder: Error in encoded stream: hit EOF while looking for padding characters (=)" + recentChars());
/*     */                 }
/*     */ 
/*     */               }
/* 299 */               else if ((i != -2) && 
/* 300 */                 (!this.ignoreErrors)) {
/* 301 */                 throw new DecodingException("BASE64Decoder: Error in encoded stream: found valid base64 character after a padding character (=)" + recentChars());
/*     */               }
/*     */ 
/*     */             }
/*     */ 
/* 308 */             val <<= 6;
/* 309 */             got++;
/*     */           }
/*     */ 
/* 313 */           val >>= 8;
/* 314 */           if (size == 2)
/* 315 */             outbuf[(pos + 1)] = (byte)(val & 0xFF);
/* 316 */           val >>= 8;
/* 317 */           outbuf[pos] = (byte)(val & 0xFF);
/*     */ 
/* 319 */           pos += size;
/* 320 */           return pos - pos0;
/*     */         }
/*     */ 
/* 323 */         val <<= 6;
/* 324 */         got++;
/* 325 */         val |= i;
/*     */       }
/*     */ 
/* 330 */       outbuf[(pos + 2)] = (byte)(val & 0xFF);
/* 331 */       val >>= 8;
/* 332 */       outbuf[(pos + 1)] = (byte)(val & 0xFF);
/* 333 */       val >>= 8;
/* 334 */       outbuf[pos] = (byte)(val & 0xFF);
/* 335 */       len -= 3;
/* 336 */       pos += 3;
/*     */     }
/* 338 */     return pos - pos0;
/*     */   }
/*     */ 
/*     */   private int getByte()
/*     */     throws IOException
/*     */   {
/*     */     int c;
/*     */     do
/*     */     {
/* 352 */       if (this.input_pos >= this.input_len) {
/*     */         try {
/* 354 */           this.input_len = this.in.read(this.input_buffer);
/*     */         } catch (EOFException ex) {
/* 356 */           return -1;
/*     */         }
/* 358 */         if (this.input_len <= 0)
/* 359 */           return -1;
/* 360 */         this.input_pos = 0;
/*     */       }
/*     */ 
/* 363 */       c = this.input_buffer[(this.input_pos++)] & 0xFF;
/*     */ 
/* 365 */       if (c == 61) {
/* 366 */         return -2;
/*     */       }
/* 368 */       c = pem_convert_array[c];
/*     */     }
/* 370 */     while (c == -1);
/* 371 */     return c;
/*     */   }
/*     */ 
/*     */   private String recentChars()
/*     */   {
/* 380 */     String errstr = "";
/* 381 */     int nc = this.input_pos > 10 ? 10 : this.input_pos;
/* 382 */     if (nc > 0) {
/* 383 */       errstr = errstr + ", the " + nc + " most recent characters were: \"";
/*     */ 
/* 385 */       for (int k = this.input_pos - nc; k < this.input_pos; k++) {
/* 386 */         char c = (char)(this.input_buffer[k] & 0xFF);
/* 387 */         switch (c) { case '\r':
/* 388 */           errstr = errstr + "\\r"; break;
/*     */         case '\n':
/* 389 */           errstr = errstr + "\\n"; break;
/*     */         case '\t':
/* 390 */           errstr = errstr + "\\t"; break;
/*     */         case '\013':
/*     */         case '\f':
/*     */         default:
/* 392 */           if ((c >= ' ') && (c < ''))
/* 393 */             errstr = errstr + c;
/*     */           else
/* 395 */             errstr = errstr + "\\" + c;
/*     */           break; }
/*     */       }
/* 398 */       errstr = errstr + "\"";
/*     */     }
/* 400 */     return errstr;
/*     */   }
/*     */ 
/*     */   public static byte[] decode(byte[] inbuf)
/*     */   {
/* 413 */     int size = inbuf.length / 4 * 3;
/* 414 */     if (size == 0) {
/* 415 */       return inbuf;
/*     */     }
/* 417 */     if (inbuf[(inbuf.length - 1)] == 61) {
/* 418 */       size--;
/* 419 */       if (inbuf[(inbuf.length - 2)] == 61)
/* 420 */         size--;
/*     */     }
/* 422 */     byte[] outbuf = new byte[size];
/*     */ 
/* 424 */     int inpos = 0; int outpos = 0;
/* 425 */     size = inbuf.length;
/* 426 */     while (size > 0)
/*     */     {
/* 428 */       int osize = 3;
/* 429 */       int val = pem_convert_array[(inbuf[(inpos++)] & 0xFF)];
/* 430 */       val <<= 6;
/* 431 */       val |= pem_convert_array[(inbuf[(inpos++)] & 0xFF)];
/* 432 */       val <<= 6;
/* 433 */       if (inbuf[inpos] != 61)
/* 434 */         val |= pem_convert_array[(inbuf[(inpos++)] & 0xFF)];
/*     */       else
/* 436 */         osize--;
/* 437 */       val <<= 6;
/* 438 */       if (inbuf[inpos] != 61)
/* 439 */         val |= pem_convert_array[(inbuf[(inpos++)] & 0xFF)];
/*     */       else
/* 441 */         osize--;
/* 442 */       if (osize > 2)
/* 443 */         outbuf[(outpos + 2)] = (byte)(val & 0xFF);
/* 444 */       val >>= 8;
/* 445 */       if (osize > 1)
/* 446 */         outbuf[(outpos + 1)] = (byte)(val & 0xFF);
/* 447 */       val >>= 8;
/* 448 */       outbuf[outpos] = (byte)(val & 0xFF);
/* 449 */       outpos += osize;
/* 450 */       size -= 4;
/*     */     }
/* 452 */     return outbuf;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/* 214 */     for (int i = 0; i < 255; i++)
/* 215 */       pem_convert_array[i] = -1;
/* 216 */     for (int i = 0; i < pem_array.length; i++)
/* 217 */       pem_convert_array[pem_array[i]] = (byte)i;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.util.BASE64DecoderStream
 * JD-Core Version:    0.6.1
 */