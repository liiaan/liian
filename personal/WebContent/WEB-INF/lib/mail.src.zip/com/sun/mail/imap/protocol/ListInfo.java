/*    */ package com.sun.mail.imap.protocol;
/*    */ 
/*    */ import com.sun.mail.iap.ParsingException;
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class ListInfo
/*    */ {
/* 51 */   public String name = null;
/* 52 */   public char separator = '/';
/* 53 */   public boolean hasInferiors = true;
/* 54 */   public boolean canOpen = true;
/* 55 */   public int changeState = 3;
/*    */   public String[] attrs;
/*    */   public static final int CHANGED = 1;
/*    */   public static final int UNCHANGED = 2;
/*    */   public static final int INDETERMINATE = 3;
/*    */ 
/*    */   public ListInfo(IMAPResponse r)
/*    */     throws ParsingException
/*    */   {
/* 63 */     String[] s = r.readSimpleList();
/*    */ 
/* 65 */     Vector v = new Vector();
/* 66 */     if (s != null)
/*    */     {
/* 68 */       for (int i = 0; i < s.length; i++) {
/* 69 */         if (s[i].equalsIgnoreCase("\\Marked"))
/* 70 */           this.changeState = 1;
/* 71 */         else if (s[i].equalsIgnoreCase("\\Unmarked"))
/* 72 */           this.changeState = 2;
/* 73 */         else if (s[i].equalsIgnoreCase("\\Noselect"))
/* 74 */           this.canOpen = false;
/* 75 */         else if (s[i].equalsIgnoreCase("\\Noinferiors"))
/* 76 */           this.hasInferiors = false;
/* 77 */         v.addElement(s[i]);
/*    */       }
/*    */     }
/* 80 */     this.attrs = new String[v.size()];
/* 81 */     v.copyInto(this.attrs);
/*    */ 
/* 83 */     r.skipSpaces();
/* 84 */     if (r.readByte() == 34) {
/* 85 */       if ((this.separator = (char)r.readByte()) == '\\')
/*    */       {
/* 87 */         this.separator = (char)r.readByte();
/* 88 */       }r.skip(1);
/*    */     } else {
/* 90 */       r.skip(2);
/*    */     }
/* 92 */     r.skipSpaces();
/* 93 */     this.name = r.readAtomString();
/*    */ 
/* 96 */     this.name = BASE64MailboxDecoder.decode(this.name);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.protocol.ListInfo
 * JD-Core Version:    0.6.1
 */