/*    */ package com.sun.mail.iap;
/*    */ 
/*    */ public class ProtocolException extends Exception
/*    */ {
/* 44 */   protected transient Response response = null;
/*    */   private static final long serialVersionUID = -4360500807971797439L;
/*    */ 
/*    */   public ProtocolException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ProtocolException(String s)
/*    */   {
/* 60 */     super(s);
/*    */   }
/*    */ 
/*    */   public ProtocolException(Response r)
/*    */   {
/* 67 */     super(r.toString());
/* 68 */     this.response = r;
/*    */   }
/*    */ 
/*    */   public Response getResponse()
/*    */   {
/* 75 */     return this.response;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.iap.ProtocolException
 * JD-Core Version:    0.6.1
 */