/*     */ package com.sun.mail.iap;
/*     */ 
/*     */ class AString
/*     */ {
/*     */   byte[] bytes;
/*     */ 
/*     */   AString(byte[] b)
/*     */   {
/* 303 */     this.bytes = b;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.iap.AString
 * JD-Core Version:    0.6.1
 */