/*    */ package com.sun.mail.handlers;
/*    */ 
/*    */ import java.awt.Image;
/*    */ import javax.activation.ActivationDataFlavor;
/*    */ 
/*    */ public class image_jpeg extends image_gif
/*    */ {
/* 46 */   private static ActivationDataFlavor myDF = new ActivationDataFlavor(Image.class, "image/jpeg", "JPEG Image");
/*    */ 
/*    */   protected ActivationDataFlavor getDF()
/*    */   {
/* 52 */     return myDF;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.handlers.image_jpeg
 * JD-Core Version:    0.6.1
 */