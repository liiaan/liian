/*     */ package com.sun.mail.imap;
/*     */ 
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class Rights
/*     */   implements Cloneable
/*     */ {
/*  74 */   private boolean[] rights = new boolean[''];
/*     */ 
/*     */   public Rights()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Rights(Rights rights)
/*     */   {
/* 172 */     System.arraycopy(rights.rights, 0, this.rights, 0, this.rights.length);
/*     */   }
/*     */ 
/*     */   public Rights(String rights)
/*     */   {
/* 181 */     for (int i = 0; i < rights.length(); i++)
/* 182 */       add(Right.getInstance(rights.charAt(i)));
/*     */   }
/*     */ 
/*     */   public Rights(Right right)
/*     */   {
/* 191 */     this.rights[right.right] = true;
/*     */   }
/*     */ 
/*     */   public void add(Right right)
/*     */   {
/* 200 */     this.rights[right.right] = true;
/*     */   }
/*     */ 
/*     */   public void add(Rights rights)
/*     */   {
/* 210 */     for (int i = 0; i < rights.rights.length; i++)
/* 211 */       if (rights.rights[i] != 0)
/* 212 */         this.rights[i] = true;
/*     */   }
/*     */ 
/*     */   public void remove(Right right)
/*     */   {
/* 221 */     this.rights[right.right] = false;
/*     */   }
/*     */ 
/*     */   public void remove(Rights rights)
/*     */   {
/* 231 */     for (int i = 0; i < rights.rights.length; i++)
/* 232 */       if (rights.rights[i] != 0)
/* 233 */         this.rights[i] = false;
/*     */   }
/*     */ 
/*     */   public boolean contains(Right right)
/*     */   {
/* 242 */     return this.rights[right.right];
/*     */   }
/*     */ 
/*     */   public boolean contains(Rights rights)
/*     */   {
/* 253 */     for (int i = 0; i < rights.rights.length; i++) {
/* 254 */       if ((rights.rights[i] != 0) && (this.rights[i] == 0)) {
/* 255 */         return false;
/*     */       }
/*     */     }
/* 258 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 267 */     if (!(obj instanceof Rights)) {
/* 268 */       return false;
/*     */     }
/* 270 */     Rights rights = (Rights)obj;
/*     */ 
/* 272 */     for (int i = 0; i < rights.rights.length; i++) {
/* 273 */       if (rights.rights[i] != this.rights[i])
/* 274 */         return false;
/*     */     }
/* 276 */     return true;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 285 */     int hash = 0;
/* 286 */     for (int i = 0; i < this.rights.length; i++)
/* 287 */       if (this.rights[i] != 0)
/* 288 */         hash++;
/* 289 */     return hash;
/*     */   }
/*     */ 
/*     */   public Right[] getRights()
/*     */   {
/* 299 */     Vector v = new Vector();
/* 300 */     for (int i = 0; i < this.rights.length; i++)
/* 301 */       if (this.rights[i] != 0)
/* 302 */         v.addElement(Right.getInstance((char)i));
/* 303 */     Right[] rights = new Right[v.size()];
/* 304 */     v.copyInto(rights);
/* 305 */     return rights;
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 312 */     Rights r = null;
/*     */     try {
/* 314 */       r = (Rights)super.clone();
/* 315 */       r.rights = new boolean[''];
/* 316 */       System.arraycopy(this.rights, 0, r.rights, 0, this.rights.length);
/*     */     }
/*     */     catch (CloneNotSupportedException cex) {
/*     */     }
/* 320 */     return r;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 324 */     StringBuffer sb = new StringBuffer();
/* 325 */     for (int i = 0; i < this.rights.length; i++)
/* 326 */       if (this.rights[i] != 0)
/* 327 */         sb.append((char)i);
/* 328 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static final class Right
/*     */   {
/*  81 */     private static Right[] cache = new Right[''];
/*     */ 
/*  87 */     public static final Right LOOKUP = getInstance('l');
/*     */ 
/*  93 */     public static final Right READ = getInstance('r');
/*     */ 
/*  98 */     public static final Right KEEP_SEEN = getInstance('s');
/*     */ 
/* 103 */     public static final Right WRITE = getInstance('w');
/*     */ 
/* 108 */     public static final Right INSERT = getInstance('i');
/*     */ 
/* 114 */     public static final Right POST = getInstance('p');
/*     */ 
/* 120 */     public static final Right CREATE = getInstance('c');
/*     */ 
/* 125 */     public static final Right DELETE = getInstance('d');
/*     */ 
/* 130 */     public static final Right ADMINISTER = getInstance('a');
/*     */     char right;
/*     */ 
/*     */     private Right(char right)
/*     */     {
/* 138 */       if (right >= '')
/* 139 */         throw new IllegalArgumentException("Right must be ASCII");
/* 140 */       this.right = right;
/*     */     }
/*     */ 
/*     */     public static synchronized Right getInstance(char right)
/*     */     {
/* 148 */       if (right >= '')
/* 149 */         throw new IllegalArgumentException("Right must be ASCII");
/* 150 */       if (cache[right] == null)
/* 151 */         cache[right] = new Right(right);
/* 152 */       return cache[right];
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 156 */       return String.valueOf(this.right);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.Rights
 * JD-Core Version:    0.6.1
 */