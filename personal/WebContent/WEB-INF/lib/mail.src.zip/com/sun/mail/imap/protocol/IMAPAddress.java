/*     */ package com.sun.mail.imap.protocol;
/*     */ 
/*     */ import com.sun.mail.iap.ParsingException;
/*     */ import com.sun.mail.iap.Response;
/*     */ import java.util.Vector;
/*     */ import javax.mail.internet.AddressException;
/*     */ import javax.mail.internet.InternetAddress;
/*     */ 
/*     */ class IMAPAddress extends InternetAddress
/*     */ {
/* 140 */   private boolean group = false;
/*     */   private InternetAddress[] grouplist;
/*     */   private String groupname;
/*     */   private static final long serialVersionUID = -3835822029483122232L;
/*     */ 
/*     */   IMAPAddress(Response r)
/*     */     throws ParsingException
/*     */   {
/* 147 */     r.skipSpaces();
/*     */ 
/* 149 */     if (r.readByte() != 40) {
/* 150 */       throw new ParsingException("ADDRESS parse error");
/*     */     }
/* 152 */     this.encodedPersonal = r.readString();
/*     */ 
/* 154 */     r.readString();
/* 155 */     String mb = r.readString();
/* 156 */     String host = r.readString();
/* 157 */     if (r.readByte() != 41) {
/* 158 */       throw new ParsingException("ADDRESS parse error");
/*     */     }
/* 160 */     if (host == null)
/*     */     {
/* 162 */       this.group = true;
/* 163 */       this.groupname = mb;
/* 164 */       if (this.groupname == null) {
/* 165 */         return;
/*     */       }
/*     */ 
/* 169 */       StringBuffer sb = new StringBuffer();
/* 170 */       sb.append(this.groupname).append(':');
/* 171 */       Vector v = new Vector();
/* 172 */       while (r.peekByte() != 41) {
/* 173 */         IMAPAddress a = new IMAPAddress(r);
/* 174 */         if (a.isEndOfGroup())
/*     */           break;
/* 176 */         if (v.size() != 0)
/* 177 */           sb.append(',');
/* 178 */         sb.append(a.toString());
/* 179 */         v.addElement(a);
/*     */       }
/* 181 */       sb.append(';');
/* 182 */       this.address = sb.toString();
/* 183 */       this.grouplist = new IMAPAddress[v.size()];
/* 184 */       v.copyInto(this.grouplist);
/*     */     }
/* 186 */     else if ((mb == null) || (mb.length() == 0)) {
/* 187 */       this.address = host;
/* 188 */     } else if (host.length() == 0) {
/* 189 */       this.address = mb;
/*     */     } else {
/* 191 */       this.address = (mb + "@" + host);
/*     */     }
/*     */   }
/*     */ 
/*     */   boolean isEndOfGroup()
/*     */   {
/* 197 */     return (this.group) && (this.groupname == null);
/*     */   }
/*     */ 
/*     */   public boolean isGroup() {
/* 201 */     return this.group;
/*     */   }
/*     */ 
/*     */   public InternetAddress[] getGroup(boolean strict) throws AddressException {
/* 205 */     if (this.grouplist == null)
/* 206 */       return null;
/* 207 */     return (InternetAddress[])this.grouplist.clone();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.protocol.IMAPAddress
 * JD-Core Version:    0.6.1
 */