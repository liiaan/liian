/*     */ package com.sun.mail.imap.protocol;
/*     */ 
/*     */ import com.sun.mail.iap.ParsingException;
/*     */ import com.sun.mail.iap.Response;
/*     */ import javax.mail.Flags;
/*     */ 
/*     */ public class MailboxInfo
/*     */ {
/*  49 */   public Flags availableFlags = null;
/*  50 */   public Flags permanentFlags = null;
/*  51 */   public int total = -1;
/*  52 */   public int recent = -1;
/*  53 */   public int first = -1;
/*  54 */   public long uidvalidity = -1L;
/*  55 */   public long uidnext = -1L;
/*     */   public int mode;
/*     */ 
/*     */   public MailboxInfo(Response[] r)
/*     */     throws ParsingException
/*     */   {
/*  59 */     for (int i = 0; i < r.length; i++) {
/*  60 */       if ((r[i] != null) && ((r[i] instanceof IMAPResponse)))
/*     */       {
/*  63 */         IMAPResponse ir = (IMAPResponse)r[i];
/*     */ 
/*  65 */         if (ir.keyEquals("EXISTS")) {
/*  66 */           this.total = ir.getNumber();
/*  67 */           r[i] = null;
/*     */         }
/*  69 */         else if (ir.keyEquals("RECENT")) {
/*  70 */           this.recent = ir.getNumber();
/*  71 */           r[i] = null;
/*     */         }
/*  73 */         else if (ir.keyEquals("FLAGS")) {
/*  74 */           this.availableFlags = new FLAGS(ir);
/*  75 */           r[i] = null;
/*     */         }
/*  77 */         else if ((ir.isUnTagged()) && (ir.isOK()))
/*     */         {
/*  84 */           ir.skipSpaces();
/*     */ 
/*  86 */           if (ir.readByte() != 91) {
/*  87 */             ir.reset();
/*     */           }
/*     */           else
/*     */           {
/*  91 */             boolean handled = true;
/*  92 */             String s = ir.readAtom();
/*  93 */             if (s.equalsIgnoreCase("UNSEEN"))
/*  94 */               this.first = ir.readNumber();
/*  95 */             else if (s.equalsIgnoreCase("UIDVALIDITY"))
/*  96 */               this.uidvalidity = ir.readLong();
/*  97 */             else if (s.equalsIgnoreCase("PERMANENTFLAGS"))
/*  98 */               this.permanentFlags = new FLAGS(ir);
/*  99 */             else if (s.equalsIgnoreCase("UIDNEXT"))
/* 100 */               this.uidnext = ir.readLong();
/*     */             else {
/* 102 */               handled = false;
/*     */             }
/* 104 */             if (handled)
/* 105 */               r[i] = null;
/*     */             else {
/* 107 */               ir.reset();
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 116 */     if (this.permanentFlags == null)
/* 117 */       if (this.availableFlags != null)
/* 118 */         this.permanentFlags = new Flags(this.availableFlags);
/*     */       else
/* 120 */         this.permanentFlags = new Flags();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.protocol.MailboxInfo
 * JD-Core Version:    0.6.1
 */