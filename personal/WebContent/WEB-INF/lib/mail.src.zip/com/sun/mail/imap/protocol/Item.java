package com.sun.mail.imap.protocol;

public abstract interface Item
{
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.protocol.Item
 * JD-Core Version:    0.6.1
 */