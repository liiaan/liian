/*      */ package com.sun.mail.imap;
/*      */ 
/*      */ import com.sun.mail.iap.Literal;
/*      */ import com.sun.mail.util.CRLFOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ import javax.mail.Message;
/*      */ import javax.mail.MessagingException;
/*      */ 
/*      */ class MessageLiteral
/*      */   implements Literal
/*      */ {
/*      */   private Message msg;
/* 2720 */   private int msgSize = -1;
/*      */   private byte[] buf;
/*      */ 
/*      */   public MessageLiteral(Message msg, int maxsize)
/*      */     throws MessagingException, IOException
/*      */   {
/* 2725 */     this.msg = msg;
/*      */ 
/* 2727 */     LengthCounter lc = new LengthCounter(maxsize);
/* 2728 */     OutputStream os = new CRLFOutputStream(lc);
/* 2729 */     msg.writeTo(os);
/* 2730 */     os.flush();
/* 2731 */     this.msgSize = lc.getSize();
/* 2732 */     this.buf = lc.getBytes();
/*      */   }
/*      */ 
/*      */   public int size() {
/* 2736 */     return this.msgSize;
/*      */   }
/*      */ 
/*      */   public void writeTo(OutputStream os) throws IOException
/*      */   {
/*      */     try {
/* 2742 */       if (this.buf != null) {
/* 2743 */         os.write(this.buf, 0, this.msgSize);
/*      */       } else {
/* 2745 */         os = new CRLFOutputStream(os);
/* 2746 */         this.msg.writeTo(os);
/*      */       }
/*      */     }
/*      */     catch (MessagingException mex) {
/* 2750 */       throw new IOException("MessagingException while appending message: " + mex);
/*      */     }
/*      */   }
/*      */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.MessageLiteral
 * JD-Core Version:    0.6.1
 */