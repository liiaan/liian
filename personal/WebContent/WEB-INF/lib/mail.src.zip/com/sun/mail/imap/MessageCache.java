/*     */ package com.sun.mail.imap;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.mail.Message;
/*     */ import javax.mail.Session;
/*     */ 
/*     */ public class MessageCache
/*     */ {
/*     */   private IMAPMessage[] messages;
/*     */   private int[] seqnums;
/*     */   private int size;
/*     */   private IMAPFolder folder;
/*     */   private boolean debug;
/*     */   private PrintStream out;
/*     */   private static final int SLOP = 64;
/*     */ 
/*     */   MessageCache(IMAPFolder folder, IMAPStore store, int size)
/*     */   {
/*  95 */     this.folder = folder;
/*  96 */     this.debug = store.getMessageCacheDebug();
/*  97 */     this.out = store.getSession().getDebugOut();
/*  98 */     if (this.debug)
/*  99 */       this.out.println("DEBUG IMAP MC: create cache of size " + size);
/* 100 */     ensureCapacity(size);
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 107 */     return this.size;
/*     */   }
/*     */ 
/*     */   public IMAPMessage getMessage(int msgnum)
/*     */   {
/* 116 */     if ((msgnum < 1) || (msgnum > this.size)) {
/* 117 */       throw new ArrayIndexOutOfBoundsException("message number out of bounds");
/*     */     }
/* 119 */     IMAPMessage msg = this.messages[(msgnum - 1)];
/* 120 */     if (msg == null) {
/* 121 */       if (this.debug)
/* 122 */         this.out.println("DEBUG IMAP MC: create message number " + msgnum);
/* 123 */       msg = new IMAPMessage(this.folder, msgnum);
/* 124 */       this.messages[(msgnum - 1)] = msg;
/*     */ 
/* 126 */       if (seqnumOf(msgnum) <= 0) {
/* 127 */         if (this.debug)
/* 128 */           this.out.println("DEBUG IMAP MC: it's expunged!");
/* 129 */         msg.setExpunged(true);
/*     */       }
/*     */     }
/* 132 */     return msg;
/*     */   }
/*     */ 
/*     */   public IMAPMessage getMessageBySeqnum(int seqnum)
/*     */   {
/* 141 */     int msgnum = msgnumOf(seqnum);
/* 142 */     if (msgnum < 0) {
/* 143 */       if (this.debug)
/* 144 */         this.out.println("DEBUG IMAP MC: no message seqnum " + seqnum);
/* 145 */       return null;
/*     */     }
/* 147 */     return getMessage(msgnum);
/*     */   }
/*     */ 
/*     */   public void expungeMessage(int seqnum)
/*     */   {
/* 154 */     int msgnum = msgnumOf(seqnum);
/* 155 */     if (msgnum < 0) {
/* 156 */       if (this.debug)
/* 157 */         this.out.println("DEBUG IMAP MC: expunge no seqnum " + seqnum);
/* 158 */       return;
/*     */     }
/* 160 */     IMAPMessage msg = this.messages[(msgnum - 1)];
/* 161 */     if (msg != null) {
/* 162 */       if (this.debug)
/* 163 */         this.out.println("DEBUG IMAP MC: expunge existing " + msgnum);
/* 164 */       msg.setExpunged(true);
/*     */     }
/* 166 */     if (this.seqnums == null) {
/* 167 */       if (this.debug)
/* 168 */         this.out.println("DEBUG IMAP MC: create seqnums array");
/* 169 */       this.seqnums = new int[this.messages.length];
/* 170 */       for (int i = 1; i < msgnum; i++)
/* 171 */         this.seqnums[(i - 1)] = i;
/* 172 */       this.seqnums[(msgnum - 1)] = 0;
/* 173 */       for (int i = msgnum + 1; i <= this.seqnums.length; i++)
/* 174 */         this.seqnums[(i - 1)] = (i - 1);
/*     */     } else {
/* 176 */       this.seqnums[(msgnum - 1)] = 0;
/* 177 */       for (int i = msgnum + 1; i <= this.seqnums.length; i++) {
/* 178 */         assert (this.seqnums[(i - 1)] != 1);
/* 179 */         if (this.seqnums[(i - 1)] > 0)
/* 180 */           this.seqnums[(i - 1)] -= 1;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public IMAPMessage[] removeExpungedMessages()
/*     */   {
/* 190 */     if (this.debug)
/* 191 */       this.out.println("DEBUG IMAP MC: remove expunged messages");
/* 192 */     List mlist = new ArrayList();
/*     */ 
/* 202 */     int oldnum = 1;
/* 203 */     int newnum = 1;
/* 204 */     while (oldnum <= this.size)
/*     */     {
/* 206 */       if (seqnumOf(oldnum) <= 0) {
/* 207 */         IMAPMessage m = getMessage(oldnum);
/* 208 */         mlist.add(m);
/*     */       }
/*     */       else {
/* 211 */         if (newnum != oldnum)
/*     */         {
/* 213 */           this.messages[(newnum - 1)] = this.messages[(oldnum - 1)];
/* 214 */           if (this.messages[(newnum - 1)] != null)
/* 215 */             this.messages[(newnum - 1)].setMessageNumber(newnum);
/*     */         }
/* 217 */         newnum++;
/*     */       }
/* 219 */       oldnum++;
/*     */     }
/* 221 */     this.seqnums = null;
/* 222 */     shrink(newnum, oldnum);
/*     */ 
/* 224 */     IMAPMessage[] rmsgs = new IMAPMessage[mlist.size()];
/* 225 */     if (this.debug)
/* 226 */       this.out.println("DEBUG IMAP MC: return " + rmsgs.length);
/* 227 */     mlist.toArray(rmsgs);
/* 228 */     return rmsgs;
/*     */   }
/*     */ 
/*     */   public IMAPMessage[] removeExpungedMessages(Message[] msgs)
/*     */   {
/* 238 */     if (this.debug)
/* 239 */       this.out.println("DEBUG IMAP MC: remove expunged messages");
/* 240 */     List mlist = new ArrayList();
/*     */ 
/* 247 */     int[] mnum = new int[msgs.length];
/* 248 */     for (int i = 0; i < msgs.length; i++)
/* 249 */       mnum[i] = msgs[i].getMessageNumber();
/* 250 */     Arrays.sort(mnum);
/*     */ 
/* 266 */     int oldnum = 1;
/* 267 */     int newnum = 1;
/* 268 */     int mnumi = 0;
/* 269 */     boolean keepSeqnums = false;
/* 270 */     while (oldnum <= this.size)
/*     */     {
/* 276 */       if ((mnumi < mnum.length) && (oldnum == mnum[mnumi]) && (seqnumOf(oldnum) <= 0))
/*     */       {
/* 279 */         IMAPMessage m = getMessage(oldnum);
/* 280 */         mlist.add(m);
/*     */ 
/* 286 */         while ((mnumi < mnum.length) && (mnum[mnumi] <= oldnum))
/* 287 */           mnumi++;
/*     */       }
/*     */       else {
/* 290 */         if (newnum != oldnum)
/*     */         {
/* 292 */           this.messages[(newnum - 1)] = this.messages[(oldnum - 1)];
/* 293 */           if (this.messages[(newnum - 1)] != null)
/* 294 */             this.messages[(newnum - 1)].setMessageNumber(newnum);
/* 295 */           if (this.seqnums != null)
/* 296 */             this.seqnums[(newnum - 1)] = this.seqnums[(oldnum - 1)];
/*     */         }
/* 298 */         if ((this.seqnums != null) && (this.seqnums[(newnum - 1)] != newnum))
/* 299 */           keepSeqnums = true;
/* 300 */         newnum++;
/*     */       }
/* 302 */       oldnum++;
/*     */     }
/*     */ 
/* 305 */     if (!keepSeqnums)
/* 306 */       this.seqnums = null;
/* 307 */     shrink(newnum, oldnum);
/*     */ 
/* 309 */     IMAPMessage[] rmsgs = new IMAPMessage[mlist.size()];
/* 310 */     if (this.debug)
/* 311 */       this.out.println("DEBUG IMAP MC: return " + rmsgs.length);
/* 312 */     mlist.toArray(rmsgs);
/* 313 */     return rmsgs;
/*     */   }
/*     */ 
/*     */   private void shrink(int newend, int oldend)
/*     */   {
/* 321 */     this.size = (newend - 1);
/* 322 */     if (this.debug)
/* 323 */       this.out.println("DEBUG IMAP MC: size now " + this.size);
/* 324 */     if (this.size == 0) {
/* 325 */       this.messages = null;
/* 326 */       this.seqnums = null;
/* 327 */     } else if ((this.size > 64) && (this.size < this.messages.length / 2))
/*     */     {
/* 329 */       if (this.debug)
/* 330 */         this.out.println("DEBUG IMAP MC: reallocate array");
/* 331 */       IMAPMessage[] newm = new IMAPMessage[this.size + 64];
/* 332 */       System.arraycopy(this.messages, 0, newm, 0, this.size);
/* 333 */       this.messages = newm;
/* 334 */       if (this.seqnums != null) {
/* 335 */         int[] news = new int[this.size + 64];
/* 336 */         System.arraycopy(this.seqnums, 0, news, 0, this.size);
/* 337 */         this.seqnums = news;
/*     */       }
/*     */     } else {
/* 340 */       if (this.debug) {
/* 341 */         this.out.println("DEBUG IMAP MC: clean " + newend + " to " + oldend);
/*     */       }
/* 343 */       for (int msgnum = newend; msgnum < oldend; msgnum++) {
/* 344 */         this.messages[(msgnum - 1)] = null;
/* 345 */         if (this.seqnums != null)
/* 346 */           this.seqnums[(msgnum - 1)] = 0;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addMessages(int count)
/*     */   {
/* 355 */     if (this.debug) {
/* 356 */       this.out.println("DEBUG IMAP MC: add " + count + " messages");
/*     */     }
/* 358 */     ensureCapacity(this.size + count);
/*     */   }
/*     */ 
/*     */   private void ensureCapacity(int newsize)
/*     */   {
/* 366 */     if (this.messages == null) {
/* 367 */       this.messages = new IMAPMessage[newsize + 64];
/* 368 */     } else if (this.messages.length < newsize) {
/* 369 */       if (this.debug)
/* 370 */         this.out.println("DEBUG IMAP MC: expand capacity to " + newsize);
/* 371 */       IMAPMessage[] newm = new IMAPMessage[newsize + 64];
/* 372 */       System.arraycopy(this.messages, 0, newm, 0, this.messages.length);
/* 373 */       this.messages = newm;
/* 374 */       if (this.seqnums != null) {
/* 375 */         int[] news = new int[newsize + 64];
/* 376 */         System.arraycopy(this.seqnums, 0, news, 0, this.seqnums.length);
/* 377 */         this.seqnums = news;
/*     */       }
/* 379 */     } else if (newsize < this.size)
/*     */     {
/* 381 */       if (this.debug)
/* 382 */         this.out.println("DEBUG IMAP MC: shrink capacity to " + newsize);
/* 383 */       for (int msgnum = newsize + 1; msgnum <= this.size; msgnum++) {
/* 384 */         this.messages[(msgnum - 1)] = null;
/* 385 */         if (this.seqnums != null)
/* 386 */           this.seqnums[(msgnum - 1)] = -1;
/*     */       }
/*     */     }
/* 389 */     this.size = newsize;
/*     */   }
/*     */ 
/*     */   public int seqnumOf(int msgnum)
/*     */   {
/* 396 */     if (this.seqnums == null) {
/* 397 */       return msgnum;
/*     */     }
/* 399 */     return this.seqnums[(msgnum - 1)];
/*     */   }
/*     */ 
/*     */   private int msgnumOf(int seqnum)
/*     */   {
/* 406 */     if (this.seqnums == null)
/* 407 */       return seqnum;
/* 408 */     if (seqnum < 1) {
/* 409 */       if (this.debug)
/* 410 */         this.out.println("DEBUG IMAP MC: bad seqnum " + seqnum);
/* 411 */       return -1;
/*     */     }
/* 413 */     for (int msgnum = seqnum; msgnum <= this.size; msgnum++) {
/* 414 */       if (this.seqnums[(msgnum - 1)] == seqnum)
/* 415 */         return msgnum;
/* 416 */       if (this.seqnums[(msgnum - 1)] > seqnum)
/*     */         break;
/*     */     }
/* 419 */     return -1;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.MessageCache
 * JD-Core Version:    0.6.1
 */