/*     */ package com.sun.mail.imap.protocol;
/*     */ 
/*     */ import com.sun.mail.iap.ParsingException;
/*     */ import com.sun.mail.iap.Response;
/*     */ import com.sun.mail.util.PropUtil;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Vector;
/*     */ import javax.mail.internet.ParameterList;
/*     */ 
/*     */ public class BODYSTRUCTURE
/*     */   implements Item
/*     */ {
/*  53 */   static final char[] name = { 'B', 'O', 'D', 'Y', 'S', 'T', 'R', 'U', 'C', 'T', 'U', 'R', 'E' };
/*     */   public int msgno;
/*     */   public String type;
/*     */   public String subtype;
/*     */   public String encoding;
/*  60 */   public int lines = -1;
/*  61 */   public int size = -1;
/*     */   public String disposition;
/*     */   public String id;
/*     */   public String description;
/*     */   public String md5;
/*     */   public String attachment;
/*     */   public ParameterList cParams;
/*     */   public ParameterList dParams;
/*     */   public String[] language;
/*     */   public BODYSTRUCTURE[] bodies;
/*     */   public ENVELOPE envelope;
/*  74 */   private static int SINGLE = 1;
/*  75 */   private static int MULTI = 2;
/*  76 */   private static int NESTED = 3;
/*     */   private int processedType;
/*  80 */   private static boolean parseDebug = PropUtil.getBooleanSystemProperty("mail.imap.parse.debug", false);
/*     */ 
/*     */   public BODYSTRUCTURE(FetchResponse r)
/*     */     throws ParsingException
/*     */   {
/*  85 */     if (parseDebug)
/*  86 */       System.out.println("DEBUG IMAP: parsing BODYSTRUCTURE");
/*  87 */     this.msgno = r.getNumber();
/*  88 */     if (parseDebug) {
/*  89 */       System.out.println("DEBUG IMAP: msgno " + this.msgno);
/*     */     }
/*  91 */     r.skipSpaces();
/*     */ 
/*  93 */     if (r.readByte() != 40) {
/*  94 */       throw new ParsingException("BODYSTRUCTURE parse error: missing ``('' at start");
/*     */     }
/*     */ 
/*  97 */     if (r.peekByte() == 40) {
/*  98 */       if (parseDebug)
/*  99 */         System.out.println("DEBUG IMAP: parsing multipart");
/* 100 */       this.type = "multipart";
/* 101 */       this.processedType = MULTI;
/* 102 */       Vector v = new Vector(1);
/* 103 */       int i = 1;
/*     */       do {
/* 105 */         v.addElement(new BODYSTRUCTURE(r));
/*     */ 
/* 112 */         r.skipSpaces();
/* 113 */       }while (r.peekByte() == 40);
/*     */ 
/* 116 */       this.bodies = new BODYSTRUCTURE[v.size()];
/* 117 */       v.copyInto(this.bodies);
/*     */ 
/* 119 */       this.subtype = r.readString();
/* 120 */       if (parseDebug) {
/* 121 */         System.out.println("DEBUG IMAP: subtype " + this.subtype);
/*     */       }
/* 123 */       if (r.readByte() == 41) {
/* 124 */         if (parseDebug)
/* 125 */           System.out.println("DEBUG IMAP: parse DONE");
/* 126 */         return;
/*     */       }
/*     */ 
/* 131 */       if (parseDebug) {
/* 132 */         System.out.println("DEBUG IMAP: parsing extension data");
/*     */       }
/* 134 */       this.cParams = parseParameters(r);
/* 135 */       if (r.readByte() == 41) {
/* 136 */         if (parseDebug)
/* 137 */           System.out.println("DEBUG IMAP: body parameters DONE");
/* 138 */         return;
/*     */       }
/*     */ 
/* 142 */       byte b = r.readByte();
/* 143 */       if (b == 40) {
/* 144 */         if (parseDebug)
/* 145 */           System.out.println("DEBUG IMAP: parse disposition");
/* 146 */         this.disposition = r.readString();
/* 147 */         if (parseDebug) {
/* 148 */           System.out.println("DEBUG IMAP: disposition " + this.disposition);
/*     */         }
/* 150 */         this.dParams = parseParameters(r);
/* 151 */         if (r.readByte() != 41) {
/* 152 */           throw new ParsingException("BODYSTRUCTURE parse error: missing ``)'' at end of disposition in multipart");
/*     */         }
/*     */ 
/* 155 */         if (parseDebug)
/* 156 */           System.out.println("DEBUG IMAP: disposition DONE");
/* 157 */       } else if ((b == 78) || (b == 110)) {
/* 158 */         if (parseDebug)
/* 159 */           System.out.println("DEBUG IMAP: disposition NIL");
/* 160 */         r.skip(2);
/*     */       } else {
/* 162 */         throw new ParsingException("BODYSTRUCTURE parse error: " + this.type + "/" + this.subtype + ": " + "bad multipart disposition, b " + b);
/*     */       }
/*     */ 
/* 170 */       if ((b = r.readByte()) == 41) {
/* 171 */         if (parseDebug)
/* 172 */           System.out.println("DEBUG IMAP: no body-fld-lang");
/* 173 */         return;
/*     */       }
/*     */ 
/* 176 */       if (b != 32) {
/* 177 */         throw new ParsingException("BODYSTRUCTURE parse error: missing space after disposition");
/*     */       }
/*     */ 
/* 182 */       if (r.peekByte() == 40) {
/* 183 */         this.language = r.readStringList();
/* 184 */         if (parseDebug)
/* 185 */           System.out.println("DEBUG IMAP: language len " + this.language.length);
/*     */       }
/*     */       else {
/* 188 */         String l = r.readString();
/* 189 */         if (l != null) {
/* 190 */           String[] la = { l };
/* 191 */           this.language = la;
/* 192 */           if (parseDebug) {
/* 193 */             System.out.println("DEBUG IMAP: language " + l);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 201 */       while (r.readByte() == 32)
/* 202 */         parseBodyExtension(r);
/*     */     }
/*     */     else {
/* 205 */       if (parseDebug)
/* 206 */         System.out.println("DEBUG IMAP: single part");
/* 207 */       this.type = r.readString();
/* 208 */       if (parseDebug)
/* 209 */         System.out.println("DEBUG IMAP: type " + this.type);
/* 210 */       this.processedType = SINGLE;
/* 211 */       this.subtype = r.readString();
/* 212 */       if (parseDebug) {
/* 213 */         System.out.println("DEBUG IMAP: subtype " + this.subtype);
/*     */       }
/*     */ 
/* 216 */       if (this.type == null) {
/* 217 */         this.type = "application";
/* 218 */         this.subtype = "octet-stream";
/*     */       }
/* 220 */       this.cParams = parseParameters(r);
/* 221 */       if (parseDebug)
/* 222 */         System.out.println("DEBUG IMAP: cParams " + this.cParams);
/* 223 */       this.id = r.readString();
/* 224 */       if (parseDebug)
/* 225 */         System.out.println("DEBUG IMAP: id " + this.id);
/* 226 */       this.description = r.readString();
/* 227 */       if (parseDebug)
/* 228 */         System.out.println("DEBUG IMAP: description " + this.description);
/* 229 */       this.encoding = r.readString();
/* 230 */       if (parseDebug)
/* 231 */         System.out.println("DEBUG IMAP: encoding " + this.encoding);
/* 232 */       this.size = r.readNumber();
/* 233 */       if (parseDebug)
/* 234 */         System.out.println("DEBUG IMAP: size " + this.size);
/* 235 */       if (this.size < 0) {
/* 236 */         throw new ParsingException("BODYSTRUCTURE parse error: bad ``size'' element");
/*     */       }
/*     */ 
/* 240 */       if (this.type.equalsIgnoreCase("text")) {
/* 241 */         this.lines = r.readNumber();
/* 242 */         if (parseDebug)
/* 243 */           System.out.println("DEBUG IMAP: lines " + this.lines);
/* 244 */         if (this.lines < 0)
/* 245 */           throw new ParsingException("BODYSTRUCTURE parse error: bad ``lines'' element");
/*     */       }
/* 247 */       else if ((this.type.equalsIgnoreCase("message")) && (this.subtype.equalsIgnoreCase("rfc822")))
/*     */       {
/* 250 */         this.processedType = NESTED;
/* 251 */         this.envelope = new ENVELOPE(r);
/* 252 */         BODYSTRUCTURE[] bs = { new BODYSTRUCTURE(r) };
/* 253 */         this.bodies = bs;
/* 254 */         this.lines = r.readNumber();
/* 255 */         if (parseDebug)
/* 256 */           System.out.println("DEBUG IMAP: lines " + this.lines);
/* 257 */         if (this.lines < 0)
/* 258 */           throw new ParsingException("BODYSTRUCTURE parse error: bad ``lines'' element");
/*     */       }
/*     */       else
/*     */       {
/* 262 */         r.skipSpaces();
/* 263 */         byte bn = r.peekByte();
/* 264 */         if (Character.isDigit((char)bn)) {
/* 265 */           throw new ParsingException("BODYSTRUCTURE parse error: server erroneously included ``lines'' element with type " + this.type + "/" + this.subtype);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 271 */       if (r.peekByte() == 41) {
/* 272 */         r.readByte();
/* 273 */         if (parseDebug)
/* 274 */           System.out.println("DEBUG IMAP: parse DONE");
/* 275 */         return;
/*     */       }
/*     */ 
/* 281 */       this.md5 = r.readString();
/* 282 */       if (r.readByte() == 41) {
/* 283 */         if (parseDebug)
/* 284 */           System.out.println("DEBUG IMAP: no MD5 DONE");
/* 285 */         return;
/*     */       }
/*     */ 
/* 289 */       byte b = r.readByte();
/* 290 */       if (b == 40) {
/* 291 */         this.disposition = r.readString();
/* 292 */         if (parseDebug) {
/* 293 */           System.out.println("DEBUG IMAP: disposition " + this.disposition);
/*     */         }
/* 295 */         this.dParams = parseParameters(r);
/* 296 */         if (parseDebug)
/* 297 */           System.out.println("DEBUG IMAP: dParams " + this.dParams);
/* 298 */         if (r.readByte() != 41) {
/* 299 */           throw new ParsingException("BODYSTRUCTURE parse error: missing ``)'' at end of disposition");
/*     */         }
/*     */       }
/* 302 */       else if ((b == 78) || (b == 110)) {
/* 303 */         if (parseDebug)
/* 304 */           System.out.println("DEBUG IMAP: disposition NIL");
/* 305 */         r.skip(2);
/*     */       } else {
/* 307 */         throw new ParsingException("BODYSTRUCTURE parse error: " + this.type + "/" + this.subtype + ": " + "bad single part disposition, b " + b);
/*     */       }
/*     */ 
/* 313 */       if (r.readByte() == 41) {
/* 314 */         if (parseDebug)
/* 315 */           System.out.println("DEBUG IMAP: disposition DONE");
/* 316 */         return;
/*     */       }
/*     */ 
/* 320 */       if (r.peekByte() == 40) {
/* 321 */         this.language = r.readStringList();
/* 322 */         if (parseDebug)
/* 323 */           System.out.println("DEBUG IMAP: language len " + this.language.length);
/*     */       }
/*     */       else {
/* 326 */         String l = r.readString();
/* 327 */         if (l != null) {
/* 328 */           String[] la = { l };
/* 329 */           this.language = la;
/* 330 */           if (parseDebug) {
/* 331 */             System.out.println("DEBUG IMAP: language " + l);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 339 */       while (r.readByte() == 32)
/* 340 */         parseBodyExtension(r);
/* 341 */       if (parseDebug)
/* 342 */         System.out.println("DEBUG IMAP: all DONE");
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isMulti() {
/* 347 */     return this.processedType == MULTI;
/*     */   }
/*     */ 
/*     */   public boolean isSingle() {
/* 351 */     return this.processedType == SINGLE;
/*     */   }
/*     */ 
/*     */   public boolean isNested() {
/* 355 */     return this.processedType == NESTED;
/*     */   }
/*     */ 
/*     */   private ParameterList parseParameters(Response r) throws ParsingException
/*     */   {
/* 360 */     r.skipSpaces();
/*     */ 
/* 362 */     ParameterList list = null;
/* 363 */     byte b = r.readByte();
/* 364 */     if (b == 40) {
/* 365 */       list = new ParameterList();
/*     */       do {
/* 367 */         String name = r.readString();
/* 368 */         if (parseDebug)
/* 369 */           System.out.println("DEBUG IMAP: parameter name " + name);
/* 370 */         if (name == null) {
/* 371 */           throw new ParsingException("BODYSTRUCTURE parse error: " + this.type + "/" + this.subtype + ": " + "null name in parameter list");
/*     */         }
/*     */ 
/* 375 */         String value = r.readString();
/* 376 */         if (parseDebug)
/* 377 */           System.out.println("DEBUG IMAP: parameter value " + value);
/* 378 */         list.set(name, value);
/* 379 */       }while (r.readByte() != 41);
/* 380 */       list.set(null, "DONE");
/* 381 */     } else if ((b == 78) || (b == 110)) {
/* 382 */       if (parseDebug)
/* 383 */         System.out.println("DEBUG IMAP: parameter list NIL");
/* 384 */       r.skip(2);
/*     */     } else {
/* 386 */       throw new ParsingException("Parameter list parse error");
/*     */     }
/* 388 */     return list;
/*     */   }
/*     */ 
/*     */   private void parseBodyExtension(Response r) throws ParsingException {
/* 392 */     r.skipSpaces();
/*     */ 
/* 394 */     byte b = r.peekByte();
/* 395 */     if (b == 40) {
/* 396 */       r.skip(1);
/*     */       do
/* 398 */         parseBodyExtension(r);
/* 399 */       while (r.readByte() != 41);
/* 400 */     } else if (Character.isDigit((char)b)) {
/* 401 */       r.readNumber();
/*     */     } else {
/* 403 */       r.readString();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.protocol.BODYSTRUCTURE
 * JD-Core Version:    0.6.1
 */