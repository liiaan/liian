/*    */ package com.sun.mail.imap;
/*    */ 
/*    */ import com.sun.mail.imap.protocol.BODYSTRUCTURE;
/*    */ import java.util.Vector;
/*    */ import javax.mail.BodyPart;
/*    */ import javax.mail.MessagingException;
/*    */ import javax.mail.MultipartDataSource;
/*    */ import javax.mail.internet.MimePart;
/*    */ import javax.mail.internet.MimePartDataSource;
/*    */ 
/*    */ public class IMAPMultipartDataSource extends MimePartDataSource
/*    */   implements MultipartDataSource
/*    */ {
/*    */   private Vector parts;
/*    */ 
/*    */   protected IMAPMultipartDataSource(MimePart part, BODYSTRUCTURE[] bs, String sectionId, IMAPMessage msg)
/*    */   {
/* 62 */     super(part);
/*    */ 
/* 64 */     this.parts = new Vector(bs.length);
/* 65 */     for (int i = 0; i < bs.length; i++)
/* 66 */       this.parts.addElement(new IMAPBodyPart(bs[i], sectionId + "." + Integer.toString(i + 1), msg));
/*    */   }
/*    */ 
/*    */   public int getCount()
/*    */   {
/* 76 */     return this.parts.size();
/*    */   }
/*    */ 
/*    */   public BodyPart getBodyPart(int index) throws MessagingException {
/* 80 */     return (BodyPart)this.parts.elementAt(index);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.IMAPMultipartDataSource
 * JD-Core Version:    0.6.1
 */