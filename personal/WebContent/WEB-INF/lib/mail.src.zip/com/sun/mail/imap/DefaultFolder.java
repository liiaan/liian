/*     */ package com.sun.mail.imap;
/*     */ 
/*     */ import com.sun.mail.iap.ProtocolException;
/*     */ import com.sun.mail.imap.protocol.IMAPProtocol;
/*     */ import com.sun.mail.imap.protocol.ListInfo;
/*     */ import javax.mail.Folder;
/*     */ import javax.mail.Message;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.MethodNotSupportedException;
/*     */ 
/*     */ public class DefaultFolder extends IMAPFolder
/*     */ {
/*     */   protected DefaultFolder(IMAPStore store)
/*     */   {
/*  54 */     super("", 65535, store);
/*  55 */     this.exists = true;
/*  56 */     this.type = 2;
/*     */   }
/*     */ 
/*     */   public synchronized String getName() {
/*  60 */     return this.fullName;
/*     */   }
/*     */ 
/*     */   public Folder getParent() {
/*  64 */     return null;
/*     */   }
/*     */ 
/*     */   public synchronized Folder[] list(final String pattern) throws MessagingException
/*     */   {
/*  69 */     ListInfo[] li = null;
/*     */ 
/*  71 */     li = (ListInfo[])doCommand(new IMAPFolder.ProtocolCommand() { private final String val$pattern;
/*     */ 
/*  73 */       public Object doCommand(IMAPProtocol p) throws ProtocolException { return p.list("", pattern); }
/*     */ 
/*     */     });
/*  77 */     if (li == null) {
/*  78 */       return new Folder[0];
/*     */     }
/*  80 */     IMAPFolder[] folders = new IMAPFolder[li.length];
/*  81 */     for (int i = 0; i < folders.length; i++)
/*  82 */       folders[i] = new IMAPFolder(li[i], (IMAPStore)this.store);
/*  83 */     return folders;
/*     */   }
/*     */ 
/*     */   public synchronized Folder[] listSubscribed(final String pattern) throws MessagingException
/*     */   {
/*  88 */     ListInfo[] li = null;
/*     */ 
/*  90 */     li = (ListInfo[])doCommand(new IMAPFolder.ProtocolCommand() { private final String val$pattern;
/*     */ 
/*  92 */       public Object doCommand(IMAPProtocol p) throws ProtocolException { return p.lsub("", pattern); }
/*     */ 
/*     */     });
/*  96 */     if (li == null) {
/*  97 */       return new Folder[0];
/*     */     }
/*  99 */     IMAPFolder[] folders = new IMAPFolder[li.length];
/* 100 */     for (int i = 0; i < folders.length; i++)
/* 101 */       folders[i] = new IMAPFolder(li[i], (IMAPStore)this.store);
/* 102 */     return folders;
/*     */   }
/*     */ 
/*     */   public boolean hasNewMessages() throws MessagingException
/*     */   {
/* 107 */     return false;
/*     */   }
/*     */ 
/*     */   public Folder getFolder(String name) throws MessagingException {
/* 111 */     return new IMAPFolder(name, 65535, (IMAPStore)this.store);
/*     */   }
/*     */ 
/*     */   public boolean delete(boolean recurse) throws MessagingException
/*     */   {
/* 116 */     throw new MethodNotSupportedException("Cannot delete Default Folder");
/*     */   }
/*     */ 
/*     */   public boolean renameTo(Folder f) throws MessagingException
/*     */   {
/* 121 */     throw new MethodNotSupportedException("Cannot rename Default Folder");
/*     */   }
/*     */ 
/*     */   public void appendMessages(Message[] msgs) throws MessagingException
/*     */   {
/* 126 */     throw new MethodNotSupportedException("Cannot append to Default Folder");
/*     */   }
/*     */ 
/*     */   public Message[] expunge() throws MessagingException
/*     */   {
/* 131 */     throw new MethodNotSupportedException("Cannot expunge Default Folder");
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.DefaultFolder
 * JD-Core Version:    0.6.1
 */