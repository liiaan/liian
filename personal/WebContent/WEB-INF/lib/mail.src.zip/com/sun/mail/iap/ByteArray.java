/*     */ package com.sun.mail.iap;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ 
/*     */ public class ByteArray
/*     */ {
/*     */   private byte[] bytes;
/*     */   private int start;
/*     */   private int count;
/*     */ 
/*     */   public ByteArray(byte[] b, int start, int count)
/*     */   {
/*  57 */     this.bytes = b;
/*  58 */     this.start = start;
/*  59 */     this.count = count;
/*     */   }
/*     */ 
/*     */   public ByteArray(int size)
/*     */   {
/*  68 */     this(new byte[size], 0, size);
/*     */   }
/*     */ 
/*     */   public byte[] getBytes()
/*     */   {
/*  76 */     return this.bytes;
/*     */   }
/*     */ 
/*     */   public byte[] getNewBytes()
/*     */   {
/*  83 */     byte[] b = new byte[this.count];
/*  84 */     System.arraycopy(this.bytes, this.start, b, 0, this.count);
/*  85 */     return b;
/*     */   }
/*     */ 
/*     */   public int getStart()
/*     */   {
/*  92 */     return this.start;
/*     */   }
/*     */ 
/*     */   public int getCount()
/*     */   {
/*  99 */     return this.count;
/*     */   }
/*     */ 
/*     */   public void setCount(int count)
/*     */   {
/* 108 */     this.count = count;
/*     */   }
/*     */ 
/*     */   public ByteArrayInputStream toByteArrayInputStream()
/*     */   {
/* 115 */     return new ByteArrayInputStream(this.bytes, this.start, this.count);
/*     */   }
/*     */ 
/*     */   public void grow(int incr)
/*     */   {
/* 124 */     byte[] nbuf = new byte[this.bytes.length + incr];
/* 125 */     System.arraycopy(this.bytes, 0, nbuf, 0, this.bytes.length);
/* 126 */     this.bytes = nbuf;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.iap.ByteArray
 * JD-Core Version:    0.6.1
 */