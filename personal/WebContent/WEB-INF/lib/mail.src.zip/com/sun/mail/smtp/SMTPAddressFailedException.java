/*    */ package com.sun.mail.smtp;
/*    */ 
/*    */ import javax.mail.SendFailedException;
/*    */ import javax.mail.internet.InternetAddress;
/*    */ 
/*    */ public class SMTPAddressFailedException extends SendFailedException
/*    */ {
/*    */   protected InternetAddress addr;
/*    */   protected String cmd;
/*    */   protected int rc;
/*    */   private static final long serialVersionUID = 804831199768630097L;
/*    */ 
/*    */   public SMTPAddressFailedException(InternetAddress addr, String cmd, int rc, String err)
/*    */   {
/* 71 */     super(err);
/* 72 */     this.addr = addr;
/* 73 */     this.cmd = cmd;
/* 74 */     this.rc = rc;
/*    */   }
/*    */ 
/*    */   public InternetAddress getAddress()
/*    */   {
/* 81 */     return this.addr;
/*    */   }
/*    */ 
/*    */   public String getCommand()
/*    */   {
/* 88 */     return this.cmd;
/*    */   }
/*    */ 
/*    */   public int getReturnCode()
/*    */   {
/* 99 */     return this.rc;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.smtp.SMTPAddressFailedException
 * JD-Core Version:    0.6.1
 */