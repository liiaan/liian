/*     */ package com.sun.mail.imap.protocol;
/*     */ 
/*     */ import com.sun.mail.iap.ProtocolException;
/*     */ import com.sun.mail.iap.Response;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class Namespaces
/*     */ {
/*     */   public Namespace[] personal;
/*     */   public Namespace[] otherUsers;
/*     */   public Namespace[] shared;
/*     */ 
/*     */   public Namespaces(Response r)
/*     */     throws ProtocolException
/*     */   {
/* 132 */     this.personal = getNamespaces(r);
/* 133 */     this.otherUsers = getNamespaces(r);
/* 134 */     this.shared = getNamespaces(r);
/*     */   }
/*     */ 
/*     */   private Namespace[] getNamespaces(Response r)
/*     */     throws ProtocolException
/*     */   {
/* 141 */     r.skipSpaces();
/*     */ 
/* 143 */     if (r.peekByte() == 40) {
/* 144 */       Vector v = new Vector();
/* 145 */       r.readByte();
/*     */       do {
/* 147 */         Namespace ns = new Namespace(r);
/* 148 */         v.addElement(ns);
/* 149 */       }while (r.peekByte() != 41);
/* 150 */       r.readByte();
/* 151 */       Namespace[] nsa = new Namespace[v.size()];
/* 152 */       v.copyInto(nsa);
/* 153 */       return nsa;
/*     */     }
/* 155 */     String s = r.readAtom();
/* 156 */     if (s == null)
/* 157 */       throw new ProtocolException("Expected NIL, got null");
/* 158 */     if (!s.equalsIgnoreCase("NIL"))
/* 159 */       throw new ProtocolException("Expected NIL, got " + s);
/* 160 */     return null;
/*     */   }
/*     */ 
/*     */   public static class Namespace
/*     */   {
/*     */     public String prefix;
/*     */     public char delimiter;
/*     */ 
/*     */     public Namespace(Response r)
/*     */       throws ProtocolException
/*     */     {
/*  72 */       if (r.readByte() != 40) {
/*  73 */         throw new ProtocolException("Missing '(' at start of Namespace");
/*     */       }
/*     */ 
/*  76 */       this.prefix = BASE64MailboxDecoder.decode(r.readString());
/*  77 */       r.skipSpaces();
/*     */ 
/*  79 */       if (r.peekByte() == 34) {
/*  80 */         r.readByte();
/*  81 */         this.delimiter = (char)r.readByte();
/*  82 */         if (this.delimiter == '\\')
/*  83 */           this.delimiter = (char)r.readByte();
/*  84 */         if (r.readByte() != 34)
/*  85 */           throw new ProtocolException("Missing '\"' at end of QUOTED_CHAR");
/*     */       }
/*     */       else {
/*  88 */         String s = r.readAtom();
/*  89 */         if (s == null)
/*  90 */           throw new ProtocolException("Expected NIL, got null");
/*  91 */         if (!s.equalsIgnoreCase("NIL"))
/*  92 */           throw new ProtocolException("Expected NIL, got " + s);
/*  93 */         this.delimiter = '\000';
/*     */       }
/*     */ 
/*  96 */       if (r.peekByte() != 41)
/*     */       {
/* 100 */         r.skipSpaces();
/* 101 */         r.readString();
/* 102 */         r.skipSpaces();
/* 103 */         r.readStringList();
/*     */       }
/* 105 */       if (r.readByte() != 41)
/* 106 */         throw new ProtocolException("Missing ')' at end of Namespace");
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.protocol.Namespaces
 * JD-Core Version:    0.6.1
 */