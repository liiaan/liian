/*     */ package com.sun.mail.imap;
/*     */ 
/*     */ import com.sun.mail.imap.protocol.MessageSet;
/*     */ import com.sun.mail.imap.protocol.UIDSet;
/*     */ import java.util.Vector;
/*     */ import javax.mail.Message;
/*     */ 
/*     */ public final class Utility
/*     */ {
/*     */   public static MessageSet[] toMessageSet(Message[] msgs, Condition cond)
/*     */   {
/*  71 */     Vector v = new Vector(1);
/*     */ 
/*  75 */     for (int i = 0; i < msgs.length; i++) {
/*  76 */       IMAPMessage msg = (IMAPMessage)msgs[i];
/*  77 */       if (!msg.isExpunged())
/*     */       {
/*  80 */         int current = msg.getSequenceNumber();
/*     */ 
/*  82 */         if ((cond == null) || (cond.test(msg)))
/*     */         {
/*  85 */           MessageSet set = new MessageSet();
/*  86 */           set.start = current;
/*     */ 
/*  89 */           for (i++; i < msgs.length; i++)
/*     */           {
/*  91 */             msg = (IMAPMessage)msgs[i];
/*     */ 
/*  93 */             if (!msg.isExpunged())
/*     */             {
/*  95 */               int next = msg.getSequenceNumber();
/*     */ 
/*  98 */               if ((cond == null) || (cond.test(msg)))
/*     */               {
/* 101 */                 if (next == current + 1) {
/* 102 */                   current = next;
/*     */                 }
/*     */                 else
/*     */                 {
/* 107 */                   i--;
/* 108 */                   break;
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/* 111 */           set.end = current;
/* 112 */           v.addElement(set);
/*     */         }
/*     */       }
/*     */     }
/* 115 */     if (v.isEmpty()) {
/* 116 */       return null;
/*     */     }
/* 118 */     MessageSet[] sets = new MessageSet[v.size()];
/* 119 */     v.copyInto(sets);
/* 120 */     return sets;
/*     */   }
/*     */ 
/*     */   public static UIDSet[] toUIDSet(Message[] msgs)
/*     */   {
/* 129 */     Vector v = new Vector(1);
/*     */ 
/* 133 */     for (int i = 0; i < msgs.length; i++) {
/* 134 */       IMAPMessage msg = (IMAPMessage)msgs[i];
/* 135 */       if (!msg.isExpunged())
/*     */       {
/* 138 */         long current = msg.getUID();
/*     */ 
/* 140 */         UIDSet set = new UIDSet();
/* 141 */         set.start = current;
/*     */ 
/* 144 */         for (i++; i < msgs.length; i++)
/*     */         {
/* 146 */           msg = (IMAPMessage)msgs[i];
/*     */ 
/* 148 */           if (!msg.isExpunged())
/*     */           {
/* 150 */             long next = msg.getUID();
/*     */ 
/* 152 */             if (next == current + 1L) {
/* 153 */               current = next;
/*     */             }
/*     */             else
/*     */             {
/* 158 */               i--;
/* 159 */               break;
/*     */             }
/*     */           }
/*     */         }
/* 162 */         set.end = current;
/* 163 */         v.addElement(set);
/*     */       }
/*     */     }
/* 166 */     if (v.isEmpty()) {
/* 167 */       return null;
/*     */     }
/* 169 */     UIDSet[] sets = new UIDSet[v.size()];
/* 170 */     v.copyInto(sets);
/* 171 */     return sets;
/*     */   }
/*     */ 
/*     */   public static abstract interface Condition
/*     */   {
/*     */     public abstract boolean test(IMAPMessage paramIMAPMessage);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.Utility
 * JD-Core Version:    0.6.1
 */