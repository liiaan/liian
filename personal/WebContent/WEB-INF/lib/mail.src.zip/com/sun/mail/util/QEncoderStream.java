/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ public class QEncoderStream extends QPEncoderStream
/*     */ {
/*     */   private String specials;
/*  51 */   private static String WORD_SPECIALS = "=_?\"#$%&'(),.:;<>@[\\]^`{|}~";
/*  52 */   private static String TEXT_SPECIALS = "=_?";
/*     */ 
/*     */   public QEncoderStream(OutputStream out, boolean encodingWord)
/*     */   {
/*  61 */     super(out, 2147483647);
/*     */ 
/*  68 */     this.specials = (encodingWord ? WORD_SPECIALS : TEXT_SPECIALS);
/*     */   }
/*     */ 
/*     */   public void write(int c)
/*     */     throws IOException
/*     */   {
/*  77 */     c &= 255;
/*  78 */     if (c == 32)
/*  79 */       output(95, false);
/*  80 */     else if ((c < 32) || (c >= 127) || (this.specials.indexOf(c) >= 0))
/*     */     {
/*  82 */       output(c, true);
/*     */     }
/*  84 */     else output(c, false);
/*     */   }
/*     */ 
/*     */   public static int encodedLength(byte[] b, boolean encodingWord)
/*     */   {
/*  91 */     int len = 0;
/*  92 */     String specials = encodingWord ? WORD_SPECIALS : TEXT_SPECIALS;
/*  93 */     for (int i = 0; i < b.length; i++) {
/*  94 */       int c = b[i] & 0xFF;
/*  95 */       if ((c < 32) || (c >= 127) || (specials.indexOf(c) >= 0))
/*     */       {
/*  97 */         len += 3;
/*     */       }
/*  99 */       else len++;
/*     */     }
/* 101 */     return len;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.util.QEncoderStream
 * JD-Core Version:    0.6.1
 */