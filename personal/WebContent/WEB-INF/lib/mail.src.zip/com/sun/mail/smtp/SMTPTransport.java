/*      */ package com.sun.mail.smtp;
/*      */ 
/*      */ import com.sun.mail.util.ASCIIUtility;
/*      */ import com.sun.mail.util.BASE64EncoderStream;
/*      */ import com.sun.mail.util.LineInputStream;
/*      */ import com.sun.mail.util.PropUtil;
/*      */ import com.sun.mail.util.SocketFetcher;
/*      */ import com.sun.mail.util.TraceInputStream;
/*      */ import com.sun.mail.util.TraceOutputStream;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.io.StringReader;
/*      */ import java.net.InetAddress;
/*      */ import java.net.Socket;
/*      */ import java.net.UnknownHostException;
/*      */ import java.util.HashMap;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.Vector;
/*      */ import javax.mail.Address;
/*      */ import javax.mail.Message;
/*      */ import javax.mail.MessagingException;
/*      */ import javax.mail.SendFailedException;
/*      */ import javax.mail.Session;
/*      */ import javax.mail.Transport;
/*      */ import javax.mail.URLName;
/*      */ import javax.mail.internet.InternetAddress;
/*      */ import javax.mail.internet.MimeMessage;
/*      */ import javax.mail.internet.MimeMultipart;
/*      */ import javax.mail.internet.MimePart;
/*      */ import javax.mail.internet.ParseException;
/*      */ 
/*      */ public class SMTPTransport extends Transport
/*      */ {
/*   82 */   private String name = "smtp";
/*   83 */   private int defaultPort = 25;
/*   84 */   private boolean isSSL = false;
/*      */   private String host;
/*      */   private MimeMessage message;
/*      */   private Address[] addresses;
/*      */   private Address[] validSentAddr;
/*      */   private Address[] validUnsentAddr;
/*      */   private Address[] invalidAddr;
/*   93 */   private boolean sendPartiallyFailed = false;
/*      */   private MessagingException exception;
/*      */   private SMTPOutputStream dataStream;
/*      */   private Hashtable extMap;
/*  102 */   private Map authenticators = new HashMap();
/*      */   private String defaultAuthenticationMechanisms;
/*  105 */   private boolean quitWait = false;
/*  106 */   private String saslRealm = "UNKNOWN";
/*      */   private boolean reportSuccess;
/*      */   private boolean useStartTLS;
/*      */   private boolean requireStartTLS;
/*      */   private boolean useRset;
/*      */   private PrintStream out;
/*      */   private String localHostName;
/*      */   private String lastServerResponse;
/*      */   private int lastReturnCode;
/*      */   private boolean notificationDone;
/*  120 */   private static final String[] ignoreList = { "Bcc", "Content-Length" };
/*  121 */   private static final byte[] CRLF = { 13, 10 };
/*      */   private static final String UNKNOWN = "UNKNOWN";
/*      */   private BufferedInputStream serverInput;
/*      */   private LineInputStream lineInputStream;
/*      */   private OutputStream serverOutput;
/*      */   private Socket serverSocket;
/* 1895 */   private static char[] hexchar = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*      */ 
/*      */   public SMTPTransport(Session session, URLName urlname)
/*      */   {
/*  129 */     this(session, urlname, "smtp", false);
/*      */   }
/*      */ 
/*      */   protected SMTPTransport(Session session, URLName urlname, String name, boolean isSSL)
/*      */   {
/*  137 */     super(session, urlname);
/*  138 */     if (urlname != null)
/*  139 */       name = urlname.getProtocol();
/*  140 */     this.name = name;
/*  141 */     if (!isSSL) {
/*  142 */       isSSL = PropUtil.getBooleanSessionProperty(session, "mail." + name + ".ssl.enable", false);
/*      */     }
/*  144 */     if (isSSL)
/*  145 */       this.defaultPort = 465;
/*      */     else
/*  147 */       this.defaultPort = 25;
/*  148 */     this.isSSL = isSSL;
/*      */ 
/*  150 */     this.out = session.getDebugOut();
/*      */ 
/*  154 */     this.quitWait = PropUtil.getBooleanSessionProperty(session, "mail." + name + ".quitwait", true);
/*      */ 
/*  158 */     this.reportSuccess = PropUtil.getBooleanSessionProperty(session, "mail." + name + ".reportsuccess", false);
/*      */ 
/*  162 */     this.useStartTLS = PropUtil.getBooleanSessionProperty(session, "mail." + name + ".starttls.enable", false);
/*      */ 
/*  166 */     this.requireStartTLS = PropUtil.getBooleanSessionProperty(session, "mail." + name + ".starttls.required", false);
/*      */ 
/*  171 */     this.useRset = PropUtil.getBooleanSessionProperty(session, "mail." + name + ".userset", false);
/*      */ 
/*  175 */     Authenticator[] a = { new LoginAuthenticator(), new PlainAuthenticator(), new DigestMD5Authenticator() };
/*      */ 
/*  180 */     StringBuffer sb = new StringBuffer();
/*  181 */     for (int i = 0; i < a.length; i++) {
/*  182 */       this.authenticators.put(a[i].getMechanism(), a[i]);
/*  183 */       sb.append(a[i].getMechanism()).append(' ');
/*      */     }
/*  185 */     this.defaultAuthenticationMechanisms = sb.toString();
/*      */   }
/*      */ 
/*      */   public synchronized String getLocalHost()
/*      */   {
/*      */     try
/*      */     {
/*  196 */       if ((this.localHostName == null) || (this.localHostName.length() <= 0)) {
/*  197 */         this.localHostName = this.session.getProperty("mail." + this.name + ".localhost");
/*      */       }
/*  199 */       if ((this.localHostName == null) || (this.localHostName.length() <= 0)) {
/*  200 */         this.localHostName = this.session.getProperty("mail." + this.name + ".localaddress");
/*      */       }
/*  202 */       if ((this.localHostName == null) || (this.localHostName.length() <= 0)) {
/*  203 */         InetAddress localHost = InetAddress.getLocalHost();
/*  204 */         this.localHostName = localHost.getHostName();
/*      */ 
/*  206 */         if (this.localHostName == null)
/*      */         {
/*  208 */           this.localHostName = ("[" + localHost.getHostAddress() + "]");
/*      */         }
/*      */       }
/*      */     } catch (UnknownHostException uhex) {  }
/*      */ 
/*  212 */     return this.localHostName;
/*      */   }
/*      */ 
/*      */   public synchronized void setLocalHost(String localhost)
/*      */   {
/*  221 */     this.localHostName = localhost;
/*      */   }
/*      */ 
/*      */   public synchronized void connect(Socket socket)
/*      */     throws MessagingException
/*      */   {
/*  233 */     this.serverSocket = socket;
/*  234 */     super.connect();
/*      */   }
/*      */ 
/*      */   public synchronized String getSASLRealm()
/*      */   {
/*  245 */     if (this.saslRealm == "UNKNOWN") {
/*  246 */       this.saslRealm = this.session.getProperty("mail." + this.name + ".sasl.realm");
/*  247 */       if (this.saslRealm == null)
/*  248 */         this.saslRealm = this.session.getProperty("mail." + this.name + ".saslrealm");
/*      */     }
/*  250 */     return this.saslRealm;
/*      */   }
/*      */ 
/*      */   public synchronized void setSASLRealm(String saslRealm)
/*      */   {
/*  262 */     this.saslRealm = saslRealm;
/*      */   }
/*      */ 
/*      */   public synchronized boolean getReportSuccess()
/*      */   {
/*  279 */     return this.reportSuccess;
/*      */   }
/*      */ 
/*      */   public synchronized void setReportSuccess(boolean reportSuccess)
/*      */   {
/*  291 */     this.reportSuccess = reportSuccess;
/*      */   }
/*      */ 
/*      */   public synchronized boolean getStartTLS()
/*      */   {
/*  303 */     return this.useStartTLS;
/*      */   }
/*      */ 
/*      */   public synchronized void setStartTLS(boolean useStartTLS)
/*      */   {
/*  314 */     this.useStartTLS = useStartTLS;
/*      */   }
/*      */ 
/*      */   public synchronized boolean getRequireStartTLS()
/*      */   {
/*  325 */     return this.requireStartTLS;
/*      */   }
/*      */ 
/*      */   public synchronized void setRequireStartTLS(boolean requireStartTLS)
/*      */   {
/*  336 */     this.requireStartTLS = requireStartTLS;
/*      */   }
/*      */ 
/*      */   public synchronized boolean getUseRset()
/*      */   {
/*  348 */     return this.useRset;
/*      */   }
/*      */ 
/*      */   public synchronized void setUseRset(boolean useRset)
/*      */   {
/*  360 */     this.useRset = useRset;
/*      */   }
/*      */ 
/*      */   public synchronized String getLastServerResponse()
/*      */   {
/*  375 */     return this.lastServerResponse;
/*      */   }
/*      */ 
/*      */   public synchronized int getLastReturnCode()
/*      */   {
/*  386 */     return this.lastReturnCode;
/*      */   }
/*      */ 
/*      */   protected boolean protocolConnect(String host, int port, String user, String passwd)
/*      */     throws MessagingException
/*      */   {
/*  410 */     boolean useEhlo = PropUtil.getBooleanSessionProperty(this.session, "mail." + this.name + ".ehlo", true);
/*      */ 
/*  413 */     boolean useAuth = PropUtil.getBooleanSessionProperty(this.session, "mail." + this.name + ".auth", false);
/*      */ 
/*  418 */     String mechs = this.session.getProperty("mail." + this.name + ".auth.mechanisms");
/*  419 */     if (mechs == null) {
/*  420 */       mechs = this.defaultAuthenticationMechanisms;
/*      */     }
/*  422 */     if (this.debug) {
/*  423 */       this.out.println("DEBUG SMTP: useEhlo " + useEhlo + ", useAuth " + useAuth);
/*      */     }
/*      */ 
/*  432 */     if ((useAuth) && ((user == null) || (passwd == null))) {
/*  433 */       return false;
/*      */     }
/*      */ 
/*  439 */     if (port == -1) {
/*  440 */       port = PropUtil.getIntSessionProperty(this.session, "mail." + this.name + ".port", -1);
/*      */     }
/*  442 */     if (port == -1) {
/*  443 */       port = this.defaultPort;
/*      */     }
/*  445 */     if ((host == null) || (host.length() == 0)) {
/*  446 */       host = "localhost";
/*      */     }
/*  448 */     boolean succeed = false;
/*      */ 
/*  450 */     if (this.serverSocket != null)
/*  451 */       openServer();
/*      */     else {
/*  453 */       openServer(host, port);
/*      */     }
/*  455 */     if (useEhlo)
/*  456 */       succeed = ehlo(getLocalHost());
/*  457 */     if (!succeed) {
/*  458 */       helo(getLocalHost());
/*      */     }
/*  460 */     if ((this.useStartTLS) || (this.requireStartTLS)) {
/*  461 */       if (supportsExtension("STARTTLS")) {
/*  462 */         startTLS();
/*      */ 
/*  468 */         ehlo(getLocalHost());
/*  469 */       } else if (this.requireStartTLS) {
/*  470 */         if (this.debug) {
/*  471 */           this.out.println("DEBUG SMTP: STARTTLS required but not supported");
/*      */         }
/*  473 */         return false;
/*      */       }
/*      */     }
/*      */ 
/*  477 */     if (((useAuth) || ((user != null) && (passwd != null))) && ((supportsExtension("AUTH")) || (supportsExtension("AUTH=LOGIN"))))
/*      */     {
/*  479 */       if (this.debug) {
/*  480 */         this.out.println("DEBUG SMTP: Attempt to authenticate");
/*  481 */         this.out.println("DEBUG SMTP: check mechanisms: " + mechs);
/*      */       }
/*      */ 
/*  490 */       StringTokenizer st = new StringTokenizer(mechs);
/*  491 */       while (st.hasMoreTokens()) {
/*  492 */         String m = st.nextToken().toUpperCase(Locale.ENGLISH);
/*  493 */         if (!supportsAuthentication(m)) {
/*  494 */           if (this.debug)
/*  495 */             this.out.println("DEBUG SMTP: mechanism " + m + " not supported by server");
/*      */         }
/*      */         else
/*      */         {
/*  499 */           Authenticator a = (Authenticator)this.authenticators.get(m);
/*  500 */           if (a == null) {
/*  501 */             if (this.debug) {
/*  502 */               this.out.println("DEBUG SMTP: no authenticator for mechanism " + m);
/*      */             }
/*      */           }
/*      */           else
/*      */           {
/*  507 */             return a.authenticate(host, user, passwd);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  513 */     return true;
/*      */   }
/*      */ 
/*      */   public synchronized void sendMessage(Message message, Address[] addresses)
/*      */     throws MessagingException, SendFailedException
/*      */   {
/*  693 */     checkConnected();
/*      */ 
/*  697 */     if (!(message instanceof MimeMessage)) {
/*  698 */       if (this.debug)
/*  699 */         this.out.println("DEBUG SMTP: Can only send RFC822 msgs");
/*  700 */       throw new MessagingException("SMTP can only send RFC822 messages");
/*      */     }
/*  702 */     for (int i = 0; i < addresses.length; i++) {
/*  703 */       if (!(addresses[i] instanceof InternetAddress)) {
/*  704 */         throw new MessagingException(addresses[i] + " is not an InternetAddress");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  709 */     this.message = ((MimeMessage)message);
/*  710 */     this.addresses = addresses;
/*  711 */     this.validUnsentAddr = addresses;
/*  712 */     expandGroups();
/*      */ 
/*  714 */     boolean use8bit = false;
/*  715 */     if ((message instanceof SMTPMessage))
/*  716 */       use8bit = ((SMTPMessage)message).getAllow8bitMIME();
/*  717 */     if (!use8bit) {
/*  718 */       use8bit = PropUtil.getBooleanSessionProperty(this.session, "mail." + this.name + ".allow8bitmime", false);
/*      */     }
/*  720 */     if (this.debug)
/*  721 */       this.out.println("DEBUG SMTP: use8bit " + use8bit);
/*  722 */     if ((use8bit) && (supportsExtension("8BITMIME")) && 
/*  723 */       (convertTo8Bit(this.message)))
/*      */     {
/*      */       try
/*      */       {
/*  727 */         this.message.saveChanges();
/*      */       }
/*      */       catch (MessagingException mex)
/*      */       {
/*      */       }
/*      */     }
/*      */     try
/*      */     {
/*  735 */       mailFrom();
/*  736 */       rcptTo();
/*  737 */       this.message.writeTo(data(), ignoreList);
/*  738 */       finishData();
/*  739 */       if (this.sendPartiallyFailed)
/*      */       {
/*  742 */         if (this.debug) {
/*  743 */           this.out.println("DEBUG SMTP: Sending partially failed because of invalid destination addresses");
/*      */         }
/*  745 */         notifyTransportListeners(3, this.validSentAddr, this.validUnsentAddr, this.invalidAddr, this.message);
/*      */ 
/*  750 */         throw new SMTPSendFailedException(".", this.lastReturnCode, this.lastServerResponse, this.exception, this.validSentAddr, this.validUnsentAddr, this.invalidAddr);
/*      */       }
/*      */ 
/*  754 */       notifyTransportListeners(1, this.validSentAddr, this.validUnsentAddr, this.invalidAddr, this.message);
/*      */     }
/*      */     catch (MessagingException mex)
/*      */     {
/*  758 */       if (this.debug)
/*  759 */         mex.printStackTrace(this.out);
/*  760 */       addressesFailed();
/*  761 */       notifyTransportListeners(2, this.validSentAddr, this.validUnsentAddr, this.invalidAddr, this.message);
/*      */ 
/*  765 */       throw mex;
/*      */     } catch (IOException ex) {
/*  767 */       if (this.debug) {
/*  768 */         ex.printStackTrace(this.out);
/*      */       }
/*      */       try
/*      */       {
/*  772 */         closeConnection(); } catch (MessagingException mex) {
/*      */       }
/*  774 */       addressesFailed();
/*  775 */       notifyTransportListeners(2, this.validSentAddr, this.validUnsentAddr, this.invalidAddr, this.message);
/*      */ 
/*  779 */       throw new MessagingException("IOException while sending message", ex);
/*      */     }
/*      */     finally
/*      */     {
/*  783 */       this.validSentAddr = (this.validUnsentAddr = this.invalidAddr = null);
/*  784 */       this.addresses = null;
/*  785 */       this.message = null;
/*  786 */       this.exception = null;
/*  787 */       this.sendPartiallyFailed = false;
/*  788 */       this.notificationDone = false;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void addressesFailed()
/*      */   {
/*  796 */     if (this.validSentAddr != null)
/*  797 */       if (this.validUnsentAddr != null) {
/*  798 */         Address[] newa = new Address[this.validSentAddr.length + this.validUnsentAddr.length];
/*      */ 
/*  800 */         System.arraycopy(this.validSentAddr, 0, newa, 0, this.validSentAddr.length);
/*      */ 
/*  802 */         System.arraycopy(this.validUnsentAddr, 0, newa, this.validSentAddr.length, this.validUnsentAddr.length);
/*      */ 
/*  804 */         this.validSentAddr = null;
/*  805 */         this.validUnsentAddr = newa;
/*      */       } else {
/*  807 */         this.validUnsentAddr = this.validSentAddr;
/*  808 */         this.validSentAddr = null;
/*      */       }
/*      */   }
/*      */ 
/*      */   public synchronized void close()
/*      */     throws MessagingException
/*      */   {
/*  817 */     if (!super.isConnected())
/*  818 */       return;
/*      */     try {
/*  820 */       if (this.serverSocket != null) {
/*  821 */         sendCommand("QUIT");
/*  822 */         if (this.quitWait) {
/*  823 */           int resp = readServerResponse();
/*  824 */           if ((resp != 221) && (resp != -1) && (this.debug))
/*  825 */             this.out.println("DEBUG SMTP: QUIT failed with " + resp);
/*      */         }
/*      */       }
/*      */     } finally {
/*  829 */       closeConnection();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void closeConnection() throws MessagingException {
/*      */     try {
/*  835 */       if (this.serverSocket != null)
/*  836 */         this.serverSocket.close();
/*      */     } catch (IOException ioex) {
/*  838 */       throw new MessagingException("Server Close Failed", ioex);
/*      */     } finally {
/*  840 */       this.serverSocket = null;
/*  841 */       this.serverOutput = null;
/*  842 */       this.serverInput = null;
/*  843 */       this.lineInputStream = null;
/*  844 */       if (super.isConnected())
/*  845 */         super.close();
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized boolean isConnected()
/*      */   {
/*  854 */     if (!super.isConnected())
/*      */     {
/*  856 */       return false;
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  861 */       if (this.useRset)
/*  862 */         sendCommand("RSET");
/*      */       else
/*  864 */         sendCommand("NOOP");
/*  865 */       int resp = readServerResponse();
/*      */ 
/*  875 */       if ((resp >= 0) && (resp != 421))
/*  876 */         return true;
/*      */       try
/*      */       {
/*  879 */         closeConnection(); } catch (MessagingException mex) {
/*      */       }
/*  881 */       return false;
/*      */     }
/*      */     catch (Exception ex) {
/*      */       try {
/*  885 */         closeConnection(); } catch (MessagingException mex) {  }
/*      */     }
/*  887 */     return false;
/*      */   }
/*      */ 
/*      */   protected void notifyTransportListeners(int type, Address[] validSent, Address[] validUnsent, Address[] invalid, Message msg)
/*      */   {
/*  901 */     if (!this.notificationDone) {
/*  902 */       super.notifyTransportListeners(type, validSent, validUnsent, invalid, msg);
/*      */ 
/*  904 */       this.notificationDone = true;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void expandGroups()
/*      */   {
/*  912 */     Vector groups = null;
/*  913 */     for (int i = 0; i < this.addresses.length; i++) {
/*  914 */       InternetAddress a = (InternetAddress)this.addresses[i];
/*  915 */       if (a.isGroup()) {
/*  916 */         if (groups == null)
/*      */         {
/*  918 */           groups = new Vector();
/*  919 */           for (int k = 0; k < i; k++)
/*  920 */             groups.addElement(this.addresses[k]);
/*      */         }
/*      */         try
/*      */         {
/*  924 */           InternetAddress[] ia = a.getGroup(true);
/*  925 */           if (ia != null)
/*  926 */             for (int j = 0; j < ia.length; j++)
/*  927 */               groups.addElement(ia[j]);
/*      */           else
/*  929 */             groups.addElement(a);
/*      */         }
/*      */         catch (ParseException pex) {
/*  932 */           groups.addElement(a);
/*      */         }
/*      */ 
/*      */       }
/*  936 */       else if (groups != null) {
/*  937 */         groups.addElement(a);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  942 */     if (groups != null) {
/*  943 */       InternetAddress[] newa = new InternetAddress[groups.size()];
/*  944 */       groups.copyInto(newa);
/*  945 */       this.addresses = newa;
/*      */     }
/*      */   }
/*      */ 
/*      */   private boolean convertTo8Bit(MimePart part)
/*      */   {
/*  960 */     boolean changed = false;
/*      */     try {
/*  962 */       if (part.isMimeType("text/*")) {
/*  963 */         String enc = part.getEncoding();
/*  964 */         if ((enc != null) && ((enc.equalsIgnoreCase("quoted-printable")) || (enc.equalsIgnoreCase("base64"))))
/*      */         {
/*  966 */           InputStream is = null;
/*      */           try {
/*  968 */             is = part.getInputStream();
/*  969 */             if (is8Bit(is))
/*      */             {
/*  979 */               part.setContent(part.getContent(), part.getContentType());
/*      */ 
/*  981 */               part.setHeader("Content-Transfer-Encoding", "8bit");
/*  982 */               changed = true;
/*      */             }
/*      */           } finally {
/*  985 */             if (is != null)
/*      */               try {
/*  987 */                 is.close();
/*      */               }
/*      */               catch (IOException ex2) {
/*      */               }
/*      */           }
/*      */         }
/*      */       }
/*  994 */       else if (part.isMimeType("multipart/*")) {
/*  995 */         MimeMultipart mp = (MimeMultipart)part.getContent();
/*  996 */         int count = mp.getCount();
/*  997 */         for (int i = 0; i < count; i++)
/*  998 */           if (convertTo8Bit((MimePart)mp.getBodyPart(i)))
/*  999 */             changed = true;
/*      */       }
/*      */     }
/*      */     catch (IOException ioex)
/*      */     {
/*      */     }
/*      */     catch (MessagingException mex) {
/*      */     }
/* 1007 */     return changed;
/*      */   }
/*      */ 
/*      */   private boolean is8Bit(InputStream is)
/*      */   {
/* 1019 */     int linelen = 0;
/* 1020 */     boolean need8bit = false;
/*      */     try
/*      */     {
/*      */       int b;
/* 1022 */       while ((b = is.read()) >= 0) {
/* 1023 */         b &= 255;
/* 1024 */         if ((b == 13) || (b == 10)) {
/* 1025 */           linelen = 0; } else {
/* 1026 */           if (b == 0) {
/* 1027 */             return false;
/*      */           }
/* 1029 */           linelen++;
/* 1030 */           if (linelen > 998)
/* 1031 */             return false;
/*      */         }
/* 1033 */         if (b > 127)
/* 1034 */           need8bit = true;
/*      */       }
/*      */     } catch (IOException ex) {
/* 1037 */       return false;
/*      */     }
/* 1039 */     if ((this.debug) && (need8bit))
/* 1040 */       this.out.println("DEBUG SMTP: found an 8bit part");
/* 1041 */     return need8bit;
/*      */   }
/*      */ 
/*      */   protected void finalize() throws Throwable {
/* 1045 */     super.finalize();
/*      */     try {
/* 1047 */       closeConnection();
/*      */     }
/*      */     catch (MessagingException mex)
/*      */     {
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void helo(String domain)
/*      */     throws MessagingException
/*      */   {
/* 1067 */     if (domain != null)
/* 1068 */       issueCommand("HELO " + domain, 250);
/*      */     else
/* 1070 */       issueCommand("HELO", 250);
/*      */   }
/*      */ 
/*      */   protected boolean ehlo(String domain)
/*      */     throws MessagingException
/*      */   {
/*      */     String cmd;
/*      */     String cmd;
/* 1084 */     if (domain != null)
/* 1085 */       cmd = "EHLO " + domain;
/*      */     else
/* 1087 */       cmd = "EHLO";
/* 1088 */     sendCommand(cmd);
/* 1089 */     int resp = readServerResponse();
/* 1090 */     if (resp == 250)
/*      */     {
/* 1092 */       BufferedReader rd = new BufferedReader(new StringReader(this.lastServerResponse));
/*      */ 
/* 1095 */       this.extMap = new Hashtable();
/*      */       try {
/* 1097 */         boolean first = true;
/*      */         String line;
/* 1098 */         while ((line = rd.readLine()) != null)
/* 1099 */           if (first) {
/* 1100 */             first = false;
/*      */           }
/* 1103 */           else if (line.length() >= 5)
/*      */           {
/* 1105 */             line = line.substring(4);
/* 1106 */             int i = line.indexOf(' ');
/* 1107 */             String arg = "";
/* 1108 */             if (i > 0) {
/* 1109 */               arg = line.substring(i + 1);
/* 1110 */               line = line.substring(0, i);
/*      */             }
/* 1112 */             if (this.debug) {
/* 1113 */               this.out.println("DEBUG SMTP: Found extension \"" + line + "\", arg \"" + arg + "\"");
/*      */             }
/* 1115 */             this.extMap.put(line.toUpperCase(Locale.ENGLISH), arg);
/*      */           }
/*      */       } catch (IOException ex) {  }
/*      */ 
/*      */     }
/* 1119 */     return resp == 250;
/*      */   }
/*      */ 
/*      */   protected void mailFrom()
/*      */     throws MessagingException
/*      */   {
/* 1137 */     String from = null;
/* 1138 */     if ((this.message instanceof SMTPMessage))
/* 1139 */       from = ((SMTPMessage)this.message).getEnvelopeFrom();
/* 1140 */     if ((from == null) || (from.length() <= 0))
/* 1141 */       from = this.session.getProperty("mail." + this.name + ".from");
/* 1142 */     if ((from == null) || (from.length() <= 0))
/*      */     {
/*      */       Address[] fa;
/*      */       Address me;
/*      */       Address me;
/* 1145 */       if ((this.message != null) && ((fa = this.message.getFrom()) != null) && (fa.length > 0))
/*      */       {
/* 1147 */         me = fa[0];
/*      */       }
/* 1149 */       else me = InternetAddress.getLocalAddress(this.session);
/*      */ 
/* 1151 */       if (me != null)
/* 1152 */         from = ((InternetAddress)me).getAddress();
/*      */       else {
/* 1154 */         throw new MessagingException("can't determine local email address");
/*      */       }
/*      */     }
/*      */ 
/* 1158 */     String cmd = "MAIL FROM:" + normalizeAddress(from);
/*      */ 
/* 1161 */     if (supportsExtension("DSN")) {
/* 1162 */       String ret = null;
/* 1163 */       if ((this.message instanceof SMTPMessage))
/* 1164 */         ret = ((SMTPMessage)this.message).getDSNRet();
/* 1165 */       if (ret == null) {
/* 1166 */         ret = this.session.getProperty("mail." + this.name + ".dsn.ret");
/*      */       }
/* 1168 */       if (ret != null) {
/* 1169 */         cmd = cmd + " RET=" + ret;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1177 */     if (supportsExtension("AUTH")) {
/* 1178 */       String submitter = null;
/* 1179 */       if ((this.message instanceof SMTPMessage))
/* 1180 */         submitter = ((SMTPMessage)this.message).getSubmitter();
/* 1181 */       if (submitter == null) {
/* 1182 */         submitter = this.session.getProperty("mail." + this.name + ".submitter");
/*      */       }
/* 1184 */       if (submitter != null) {
/*      */         try {
/* 1186 */           String s = xtext(submitter);
/* 1187 */           cmd = cmd + " AUTH=" + s;
/*      */         } catch (IllegalArgumentException ex) {
/* 1189 */           if (this.debug) {
/* 1190 */             this.out.println("DEBUG SMTP: ignoring invalid submitter: " + submitter + ", Exception: " + ex);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1199 */     String ext = null;
/* 1200 */     if ((this.message instanceof SMTPMessage))
/* 1201 */       ext = ((SMTPMessage)this.message).getMailExtension();
/* 1202 */     if (ext == null)
/* 1203 */       ext = this.session.getProperty("mail." + this.name + ".mailextension");
/* 1204 */     if ((ext != null) && (ext.length() > 0)) {
/* 1205 */       cmd = cmd + " " + ext;
/*      */     }
/* 1207 */     issueSendCommand(cmd, 250);
/*      */   }
/*      */ 
/*      */   protected void rcptTo()
/*      */     throws MessagingException
/*      */   {
/* 1232 */     Vector valid = new Vector();
/* 1233 */     Vector validUnsent = new Vector();
/* 1234 */     Vector invalid = new Vector();
/* 1235 */     int retCode = -1;
/* 1236 */     MessagingException mex = null;
/* 1237 */     boolean sendFailed = false;
/* 1238 */     MessagingException sfex = null;
/* 1239 */     this.validSentAddr = (this.validUnsentAddr = this.invalidAddr = null);
/* 1240 */     boolean sendPartial = false;
/* 1241 */     if ((this.message instanceof SMTPMessage))
/* 1242 */       sendPartial = ((SMTPMessage)this.message).getSendPartial();
/* 1243 */     if (!sendPartial) {
/* 1244 */       sendPartial = PropUtil.getBooleanSessionProperty(this.session, "mail." + this.name + ".sendpartial", false);
/*      */     }
/* 1246 */     if ((this.debug) && (sendPartial)) {
/* 1247 */       this.out.println("DEBUG SMTP: sendPartial set");
/*      */     }
/* 1249 */     boolean dsn = false;
/* 1250 */     String notify = null;
/* 1251 */     if (supportsExtension("DSN")) {
/* 1252 */       if ((this.message instanceof SMTPMessage))
/* 1253 */         notify = ((SMTPMessage)this.message).getDSNNotify();
/* 1254 */       if (notify == null) {
/* 1255 */         notify = this.session.getProperty("mail." + this.name + ".dsn.notify");
/*      */       }
/* 1257 */       if (notify != null) {
/* 1258 */         dsn = true;
/*      */       }
/*      */     }
/*      */ 
/* 1262 */     for (int i = 0; i < this.addresses.length; i++)
/*      */     {
/* 1264 */       sfex = null;
/* 1265 */       InternetAddress ia = (InternetAddress)this.addresses[i];
/* 1266 */       String cmd = "RCPT TO:" + normalizeAddress(ia.getAddress());
/* 1267 */       if (dsn) {
/* 1268 */         cmd = cmd + " NOTIFY=" + notify;
/*      */       }
/* 1270 */       sendCommand(cmd);
/*      */ 
/* 1272 */       retCode = readServerResponse();
/* 1273 */       switch (retCode) { case 250:
/*      */       case 251:
/* 1275 */         valid.addElement(ia);
/* 1276 */         if (this.reportSuccess)
/*      */         {
/* 1283 */           sfex = new SMTPAddressSucceededException(ia, cmd, retCode, this.lastServerResponse);
/*      */ 
/* 1285 */           if (mex == null)
/* 1286 */             mex = sfex;
/*      */           else
/* 1288 */             mex.setNextException(sfex); 
/*      */         }
/* 1289 */         break;
/*      */       case 501:
/*      */       case 503:
/*      */       case 550:
/*      */       case 551:
/*      */       case 553:
/* 1293 */         if (!sendPartial)
/* 1294 */           sendFailed = true;
/* 1295 */         invalid.addElement(ia);
/*      */ 
/* 1297 */         sfex = new SMTPAddressFailedException(ia, cmd, retCode, this.lastServerResponse);
/*      */ 
/* 1299 */         if (mex == null)
/* 1300 */           mex = sfex;
/*      */         else
/* 1302 */           mex.setNextException(sfex);
/* 1303 */         break;
/*      */       case 450:
/*      */       case 451:
/*      */       case 452:
/*      */       case 552:
/* 1307 */         if (!sendPartial)
/* 1308 */           sendFailed = true;
/* 1309 */         validUnsent.addElement(ia);
/*      */ 
/* 1311 */         sfex = new SMTPAddressFailedException(ia, cmd, retCode, this.lastServerResponse);
/*      */ 
/* 1313 */         if (mex == null)
/* 1314 */           mex = sfex;
/*      */         else
/* 1316 */           mex.setNextException(sfex);
/* 1317 */         break;
/*      */       default:
/* 1321 */         if ((retCode >= 400) && (retCode <= 499))
/*      */         {
/* 1323 */           validUnsent.addElement(ia);
/* 1324 */         } else if ((retCode >= 500) && (retCode <= 599))
/*      */         {
/* 1326 */           invalid.addElement(ia);
/*      */         }
/*      */         else {
/* 1329 */           if (this.debug) {
/* 1330 */             this.out.println("DEBUG SMTP: got response code " + retCode + ", with response: " + this.lastServerResponse);
/*      */           }
/* 1332 */           String _lsr = this.lastServerResponse;
/* 1333 */           int _lrc = this.lastReturnCode;
/* 1334 */           if (this.serverSocket != null)
/* 1335 */             issueCommand("RSET", -1);
/* 1336 */           this.lastServerResponse = _lsr;
/* 1337 */           this.lastReturnCode = _lrc;
/* 1338 */           throw new SMTPAddressFailedException(ia, cmd, retCode, _lsr);
/*      */         }
/*      */ 
/* 1341 */         if (!sendPartial) {
/* 1342 */           sendFailed = true;
/*      */         }
/* 1344 */         sfex = new SMTPAddressFailedException(ia, cmd, retCode, this.lastServerResponse);
/*      */ 
/* 1346 */         if (mex == null)
/* 1347 */           mex = sfex;
/*      */         else {
/* 1349 */           mex.setNextException(sfex);
/*      */         }
/*      */         break;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1356 */     if ((sendPartial) && (valid.size() == 0)) {
/* 1357 */       sendFailed = true;
/*      */     }
/*      */ 
/* 1360 */     if (sendFailed)
/*      */     {
/* 1362 */       this.invalidAddr = new Address[invalid.size()];
/* 1363 */       invalid.copyInto(this.invalidAddr);
/*      */ 
/* 1366 */       this.validUnsentAddr = new Address[valid.size() + validUnsent.size()];
/* 1367 */       int i = 0;
/* 1368 */       for (int j = 0; j < valid.size(); j++)
/* 1369 */         this.validUnsentAddr[(i++)] = ((Address)valid.elementAt(j));
/* 1370 */       for (int j = 0; j < validUnsent.size(); j++)
/* 1371 */         this.validUnsentAddr[(i++)] = ((Address)validUnsent.elementAt(j));
/* 1372 */     } else if ((this.reportSuccess) || ((sendPartial) && ((invalid.size() > 0) || (validUnsent.size() > 0))))
/*      */     {
/* 1376 */       this.sendPartiallyFailed = true;
/* 1377 */       this.exception = mex;
/*      */ 
/* 1380 */       this.invalidAddr = new Address[invalid.size()];
/* 1381 */       invalid.copyInto(this.invalidAddr);
/*      */ 
/* 1384 */       this.validUnsentAddr = new Address[validUnsent.size()];
/* 1385 */       validUnsent.copyInto(this.validUnsentAddr);
/*      */ 
/* 1388 */       this.validSentAddr = new Address[valid.size()];
/* 1389 */       valid.copyInto(this.validSentAddr);
/*      */     } else {
/* 1391 */       this.validSentAddr = this.addresses;
/*      */     }
/*      */ 
/* 1396 */     if (this.debug) {
/* 1397 */       if ((this.validSentAddr != null) && (this.validSentAddr.length > 0)) {
/* 1398 */         this.out.println("DEBUG SMTP: Verified Addresses");
/* 1399 */         for (int l = 0; l < this.validSentAddr.length; l++) {
/* 1400 */           this.out.println("DEBUG SMTP:   " + this.validSentAddr[l]);
/*      */         }
/*      */       }
/* 1403 */       if ((this.validUnsentAddr != null) && (this.validUnsentAddr.length > 0)) {
/* 1404 */         this.out.println("DEBUG SMTP: Valid Unsent Addresses");
/* 1405 */         for (int j = 0; j < this.validUnsentAddr.length; j++) {
/* 1406 */           this.out.println("DEBUG SMTP:   " + this.validUnsentAddr[j]);
/*      */         }
/*      */       }
/* 1409 */       if ((this.invalidAddr != null) && (this.invalidAddr.length > 0)) {
/* 1410 */         this.out.println("DEBUG SMTP: Invalid Addresses");
/* 1411 */         for (int k = 0; k < this.invalidAddr.length; k++) {
/* 1412 */           this.out.println("DEBUG SMTP:   " + this.invalidAddr[k]);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1418 */     if (sendFailed) {
/* 1419 */       if (this.debug) {
/* 1420 */         this.out.println("DEBUG SMTP: Sending failed because of invalid destination addresses");
/*      */       }
/* 1422 */       notifyTransportListeners(2, this.validSentAddr, this.validUnsentAddr, this.invalidAddr, this.message);
/*      */ 
/* 1427 */       String lsr = this.lastServerResponse;
/* 1428 */       int lrc = this.lastReturnCode;
/*      */       try {
/* 1430 */         if (this.serverSocket != null)
/* 1431 */           issueCommand("RSET", -1);
/*      */       }
/*      */       catch (MessagingException ex) {
/*      */         try {
/* 1435 */           close();
/*      */         }
/*      */         catch (MessagingException ex2) {
/* 1438 */           if (this.debug)
/* 1439 */             ex2.printStackTrace(this.out);
/*      */         }
/*      */       } finally {
/* 1442 */         this.lastServerResponse = lsr;
/* 1443 */         this.lastReturnCode = lrc;
/*      */       }
/*      */ 
/* 1446 */       throw new SendFailedException("Invalid Addresses", mex, this.validSentAddr, this.validUnsentAddr, this.invalidAddr);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected OutputStream data()
/*      */     throws MessagingException
/*      */   {
/* 1459 */     assert (Thread.holdsLock(this));
/* 1460 */     issueSendCommand("DATA", 354);
/* 1461 */     this.dataStream = new SMTPOutputStream(this.serverOutput);
/* 1462 */     return this.dataStream;
/*      */   }
/*      */ 
/*      */   protected void finishData()
/*      */     throws IOException, MessagingException
/*      */   {
/* 1471 */     assert (Thread.holdsLock(this));
/* 1472 */     this.dataStream.ensureAtBOL();
/* 1473 */     issueSendCommand(".", 250);
/*      */   }
/*      */ 
/*      */   protected void startTLS()
/*      */     throws MessagingException
/*      */   {
/* 1483 */     issueCommand("STARTTLS", 220);
/*      */     try
/*      */     {
/* 1486 */       this.serverSocket = SocketFetcher.startTLS(this.serverSocket, this.host, this.session.getProperties(), "mail." + this.name);
/*      */ 
/* 1488 */       initStreams();
/*      */     } catch (IOException ioex) {
/* 1490 */       closeConnection();
/* 1491 */       throw new MessagingException("Could not convert socket to TLS", ioex);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void openServer(String host, int port)
/*      */     throws MessagingException
/*      */   {
/* 1504 */     if (this.debug) {
/* 1505 */       this.out.println("DEBUG SMTP: trying to connect to host \"" + host + "\", port " + port + ", isSSL " + this.isSSL);
/*      */     }
/*      */     try
/*      */     {
/* 1509 */       Properties props = this.session.getProperties();
/*      */ 
/* 1511 */       this.serverSocket = SocketFetcher.getSocket(host, port, props, "mail." + this.name, this.isSSL);
/*      */ 
/* 1516 */       port = this.serverSocket.getPort();
/*      */ 
/* 1518 */       this.host = host;
/*      */ 
/* 1520 */       initStreams();
/*      */ 
/* 1522 */       int r = -1;
/* 1523 */       if ((r = readServerResponse()) != 220) {
/* 1524 */         this.serverSocket.close();
/* 1525 */         this.serverSocket = null;
/* 1526 */         this.serverOutput = null;
/* 1527 */         this.serverInput = null;
/* 1528 */         this.lineInputStream = null;
/* 1529 */         if (this.debug) {
/* 1530 */           this.out.println("DEBUG SMTP: could not connect to host \"" + host + "\", port: " + port + ", response: " + r + "\n");
/*      */         }
/*      */ 
/* 1533 */         throw new MessagingException("Could not connect to SMTP host: " + host + ", port: " + port + ", response: " + r);
/*      */       }
/*      */ 
/* 1538 */       if (this.debug)
/* 1539 */         this.out.println("DEBUG SMTP: connected to host \"" + host + "\", port: " + port + "\n");
/*      */     }
/*      */     catch (UnknownHostException uhex)
/*      */     {
/* 1543 */       throw new MessagingException("Unknown SMTP host: " + host, uhex);
/*      */     } catch (IOException ioe) {
/* 1545 */       throw new MessagingException("Could not connect to SMTP host: " + host + ", port: " + port, ioe);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void openServer()
/*      */     throws MessagingException
/*      */   {
/* 1555 */     int port = -1;
/* 1556 */     this.host = "UNKNOWN";
/*      */     try {
/* 1558 */       port = this.serverSocket.getPort();
/* 1559 */       this.host = this.serverSocket.getInetAddress().getHostName();
/* 1560 */       if (this.debug) {
/* 1561 */         this.out.println("DEBUG SMTP: starting protocol to host \"" + this.host + "\", port " + port);
/*      */       }
/*      */ 
/* 1564 */       initStreams();
/*      */ 
/* 1566 */       int r = -1;
/* 1567 */       if ((r = readServerResponse()) != 220) {
/* 1568 */         this.serverSocket.close();
/* 1569 */         this.serverSocket = null;
/* 1570 */         this.serverOutput = null;
/* 1571 */         this.serverInput = null;
/* 1572 */         this.lineInputStream = null;
/* 1573 */         if (this.debug) {
/* 1574 */           this.out.println("DEBUG SMTP: got bad greeting from host \"" + this.host + "\", port: " + port + ", response: " + r + "\n");
/*      */         }
/*      */ 
/* 1577 */         throw new MessagingException("Got bad greeting from SMTP host: " + this.host + ", port: " + port + ", response: " + r);
/*      */       }
/*      */ 
/* 1582 */       if (this.debug)
/* 1583 */         this.out.println("DEBUG SMTP: protocol started to host \"" + this.host + "\", port: " + port + "\n");
/*      */     }
/*      */     catch (IOException ioe)
/*      */     {
/* 1587 */       throw new MessagingException("Could not start protocol to SMTP host: " + this.host + ", port: " + port, ioe);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void initStreams()
/*      */     throws IOException
/*      */   {
/* 1595 */     PrintStream out = this.session.getDebugOut();
/* 1596 */     boolean debug = this.session.getDebug();
/* 1597 */     boolean quote = PropUtil.getBooleanSessionProperty(this.session, "mail.debug.quote", false);
/*      */ 
/* 1600 */     TraceInputStream traceInput = new TraceInputStream(this.serverSocket.getInputStream(), out);
/*      */ 
/* 1602 */     traceInput.setTrace(debug);
/* 1603 */     traceInput.setQuote(quote);
/*      */ 
/* 1605 */     TraceOutputStream traceOutput = new TraceOutputStream(this.serverSocket.getOutputStream(), out);
/*      */ 
/* 1607 */     traceOutput.setTrace(debug);
/* 1608 */     traceOutput.setQuote(quote);
/*      */ 
/* 1610 */     this.serverOutput = new BufferedOutputStream(traceOutput);
/*      */ 
/* 1612 */     this.serverInput = new BufferedInputStream(traceInput);
/*      */ 
/* 1614 */     this.lineInputStream = new LineInputStream(this.serverInput);
/*      */   }
/*      */ 
/*      */   public synchronized void issueCommand(String cmd, int expect)
/*      */     throws MessagingException
/*      */   {
/* 1628 */     sendCommand(cmd);
/*      */ 
/* 1632 */     int resp = readServerResponse();
/* 1633 */     if ((expect != -1) && (resp != expect))
/* 1634 */       throw new MessagingException(this.lastServerResponse);
/*      */   }
/*      */ 
/*      */   private void issueSendCommand(String cmd, int expect)
/*      */     throws MessagingException
/*      */   {
/* 1642 */     sendCommand(cmd);
/*      */     int ret;
/* 1647 */     if ((ret = readServerResponse()) != expect)
/*      */     {
/* 1650 */       int vsl = this.validSentAddr == null ? 0 : this.validSentAddr.length;
/* 1651 */       int vul = this.validUnsentAddr == null ? 0 : this.validUnsentAddr.length;
/* 1652 */       Address[] valid = new Address[vsl + vul];
/* 1653 */       if (vsl > 0)
/* 1654 */         System.arraycopy(this.validSentAddr, 0, valid, 0, vsl);
/* 1655 */       if (vul > 0)
/* 1656 */         System.arraycopy(this.validUnsentAddr, 0, valid, vsl, vul);
/* 1657 */       this.validSentAddr = null;
/* 1658 */       this.validUnsentAddr = valid;
/* 1659 */       if (this.debug) {
/* 1660 */         this.out.println("DEBUG SMTP: got response code " + ret + ", with response: " + this.lastServerResponse);
/*      */       }
/* 1662 */       String _lsr = this.lastServerResponse;
/* 1663 */       int _lrc = this.lastReturnCode;
/* 1664 */       if (this.serverSocket != null)
/* 1665 */         issueCommand("RSET", -1);
/* 1666 */       this.lastServerResponse = _lsr;
/* 1667 */       this.lastReturnCode = _lrc;
/* 1668 */       throw new SMTPSendFailedException(cmd, ret, this.lastServerResponse, this.exception, this.validSentAddr, this.validUnsentAddr, this.invalidAddr);
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized int simpleCommand(String cmd)
/*      */     throws MessagingException
/*      */   {
/* 1681 */     sendCommand(cmd);
/* 1682 */     return readServerResponse();
/*      */   }
/*      */ 
/*      */   protected int simpleCommand(byte[] cmd)
/*      */     throws MessagingException
/*      */   {
/* 1692 */     assert (Thread.holdsLock(this));
/* 1693 */     sendCommand(cmd);
/* 1694 */     return readServerResponse();
/*      */   }
/*      */ 
/*      */   protected void sendCommand(String cmd)
/*      */     throws MessagingException
/*      */   {
/* 1704 */     sendCommand(ASCIIUtility.getBytes(cmd));
/*      */   }
/*      */ 
/*      */   private void sendCommand(byte[] cmdBytes) throws MessagingException {
/* 1708 */     assert (Thread.holdsLock(this));
/*      */     try
/*      */     {
/* 1713 */       this.serverOutput.write(cmdBytes);
/* 1714 */       this.serverOutput.write(CRLF);
/* 1715 */       this.serverOutput.flush();
/*      */     } catch (IOException ex) {
/* 1717 */       throw new MessagingException("Can't send command to SMTP host", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected int readServerResponse()
/*      */     throws MessagingException
/*      */   {
/* 1731 */     assert (Thread.holdsLock(this));
/* 1732 */     String serverResponse = "";
/* 1733 */     int returnCode = 0;
/* 1734 */     StringBuffer buf = new StringBuffer(100);
/*      */     try
/*      */     {
/* 1739 */       String line = null;
/*      */       do
/*      */       {
/* 1742 */         line = this.lineInputStream.readLine();
/* 1743 */         if (line == null) {
/* 1744 */           serverResponse = buf.toString();
/* 1745 */           if (serverResponse.length() == 0)
/* 1746 */             serverResponse = "[EOF]";
/* 1747 */           this.lastServerResponse = serverResponse;
/* 1748 */           this.lastReturnCode = -1;
/* 1749 */           if (this.debug)
/* 1750 */             this.out.println("DEBUG SMTP: EOF: " + serverResponse);
/* 1751 */           return -1;
/*      */         }
/* 1753 */         buf.append(line);
/* 1754 */         buf.append("\n");
/* 1755 */       }while (isNotLastLine(line));
/*      */ 
/* 1757 */       serverResponse = buf.toString();
/*      */     } catch (IOException ioex) {
/* 1759 */       if (this.debug) {
/* 1760 */         this.out.println("DEBUG SMTP: exception reading response: " + ioex);
/*      */       }
/* 1762 */       this.lastServerResponse = "";
/* 1763 */       this.lastReturnCode = 0;
/* 1764 */       throw new MessagingException("Exception reading response", ioex);
/*      */     }
/*      */ 
/* 1773 */     if ((serverResponse != null) && (serverResponse.length() >= 3))
/*      */       try {
/* 1775 */         returnCode = Integer.parseInt(serverResponse.substring(0, 3));
/*      */       } catch (NumberFormatException nfe) {
/*      */         try {
/* 1778 */           close();
/*      */         }
/*      */         catch (MessagingException mex) {
/* 1781 */           if (this.debug)
/* 1782 */             mex.printStackTrace(this.out);
/*      */         }
/* 1784 */         returnCode = -1;
/*      */       }
/*      */       catch (StringIndexOutOfBoundsException ex) {
/*      */         try {
/* 1788 */           close();
/*      */         }
/*      */         catch (MessagingException mex) {
/* 1791 */           if (this.debug)
/* 1792 */             mex.printStackTrace(this.out);
/*      */         }
/* 1794 */         returnCode = -1;
/*      */       }
/*      */     else {
/* 1797 */       returnCode = -1;
/*      */     }
/* 1799 */     if ((returnCode == -1) && (this.debug)) {
/* 1800 */       this.out.println("DEBUG SMTP: bad server response: " + serverResponse);
/*      */     }
/* 1802 */     this.lastServerResponse = serverResponse;
/* 1803 */     this.lastReturnCode = returnCode;
/* 1804 */     return returnCode;
/*      */   }
/*      */ 
/*      */   protected void checkConnected()
/*      */   {
/* 1816 */     if (!super.isConnected())
/* 1817 */       throw new IllegalStateException("Not connected");
/*      */   }
/*      */ 
/*      */   private boolean isNotLastLine(String line)
/*      */   {
/* 1822 */     return (line != null) && (line.length() >= 4) && (line.charAt(3) == '-');
/*      */   }
/*      */ 
/*      */   private String normalizeAddress(String addr)
/*      */   {
/* 1827 */     if ((!addr.startsWith("<")) && (!addr.endsWith(">"))) {
/* 1828 */       return "<" + addr + ">";
/*      */     }
/* 1830 */     return addr;
/*      */   }
/*      */ 
/*      */   public boolean supportsExtension(String ext)
/*      */   {
/* 1846 */     return (this.extMap != null) && (this.extMap.get(ext.toUpperCase(Locale.ENGLISH)) != null);
/*      */   }
/*      */ 
/*      */   public String getExtensionParameter(String ext)
/*      */   {
/* 1860 */     return this.extMap == null ? null : (String)this.extMap.get(ext.toUpperCase(Locale.ENGLISH));
/*      */   }
/*      */ 
/*      */   protected boolean supportsAuthentication(String auth)
/*      */   {
/* 1875 */     assert (Thread.holdsLock(this));
/* 1876 */     if (this.extMap == null)
/* 1877 */       return false;
/* 1878 */     String a = (String)this.extMap.get("AUTH");
/* 1879 */     if (a == null)
/* 1880 */       return false;
/* 1881 */     StringTokenizer st = new StringTokenizer(a);
/* 1882 */     while (st.hasMoreTokens()) {
/* 1883 */       String tok = st.nextToken();
/* 1884 */       if (tok.equalsIgnoreCase(auth)) {
/* 1885 */         return true;
/*      */       }
/*      */     }
/* 1888 */     if ((auth.equalsIgnoreCase("LOGIN")) && (supportsExtension("AUTH=LOGIN"))) {
/* 1889 */       this.out.println("DEBUG SMTP: use AUTH=LOGIN hack");
/* 1890 */       return true;
/*      */     }
/* 1892 */     return false;
/*      */   }
/*      */ 
/*      */   protected static String xtext(String s)
/*      */   {
/* 1919 */     StringBuffer sb = null;
/* 1920 */     for (int i = 0; i < s.length(); i++) {
/* 1921 */       char c = s.charAt(i);
/* 1922 */       if (c >= '') {
/* 1923 */         throw new IllegalArgumentException("Non-ASCII character in SMTP submitter: " + s);
/*      */       }
/* 1925 */       if ((c < '!') || (c > '~') || (c == '+') || (c == '=')) {
/* 1926 */         if (sb == null) {
/* 1927 */           sb = new StringBuffer(s.length() + 4);
/* 1928 */           sb.append(s.substring(0, i));
/*      */         }
/* 1930 */         sb.append('+');
/* 1931 */         sb.append(hexchar[((c & 0xF0) >> '\004')]);
/* 1932 */         sb.append(hexchar[(c & 0xF)]);
/*      */       }
/* 1934 */       else if (sb != null) {
/* 1935 */         sb.append(c);
/*      */       }
/*      */     }
/* 1938 */     return sb != null ? sb.toString() : s;
/*      */   }
/*      */ 
/*      */   private class DigestMD5Authenticator extends SMTPTransport.Authenticator
/*      */   {
/*      */     private DigestMD5 md5support;
/*      */ 
/*      */     DigestMD5Authenticator()
/*      */     {
/*  622 */       super("DIGEST-MD5");
/*      */     }
/*      */ 
/*      */     private synchronized DigestMD5 getMD5() {
/*  626 */       if (this.md5support == null)
/*  627 */         this.md5support = new DigestMD5(SMTPTransport.this.debug ? SMTPTransport.this.out : null);
/*  628 */       return this.md5support;
/*      */     }
/*      */ 
/*      */     void doAuth(String host, String user, String passwd) throws MessagingException, IOException
/*      */     {
/*  633 */       DigestMD5 md5 = getMD5();
/*  634 */       if (md5 == null) {
/*  635 */         this.resp = -1;
/*  636 */         return;
/*      */       }
/*      */ 
/*  639 */       byte[] b = md5.authClient(host, user, passwd, SMTPTransport.this.getSASLRealm(), SMTPTransport.this.getLastServerResponse());
/*      */ 
/*  641 */       this.resp = SMTPTransport.this.simpleCommand(b);
/*  642 */       if (this.resp == 334)
/*  643 */         if (!md5.authServer(SMTPTransport.this.getLastServerResponse()))
/*      */         {
/*  645 */           this.resp = -1;
/*      */         }
/*      */         else
/*  648 */           this.resp = SMTPTransport.this.simpleCommand(new byte[0]);
/*      */     }
/*      */   }
/*      */ 
/*      */   private class PlainAuthenticator extends SMTPTransport.Authenticator
/*      */   {
/*      */     PlainAuthenticator()
/*      */     {
/*  594 */       super("PLAIN");
/*      */     }
/*      */ 
/*      */     void doAuth(String host, String user, String passwd)
/*      */       throws MessagingException, IOException
/*      */     {
/*  601 */       ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*  602 */       OutputStream b64os = new BASE64EncoderStream(bos, 2147483647);
/*      */ 
/*  604 */       b64os.write(0);
/*  605 */       b64os.write(ASCIIUtility.getBytes(user));
/*  606 */       b64os.write(0);
/*  607 */       b64os.write(ASCIIUtility.getBytes(passwd));
/*  608 */       b64os.flush();
/*      */ 
/*  611 */       this.resp = SMTPTransport.this.simpleCommand(bos.toByteArray());
/*      */     }
/*      */   }
/*      */ 
/*      */   private class LoginAuthenticator extends SMTPTransport.Authenticator
/*      */   {
/*      */     LoginAuthenticator()
/*      */     {
/*  573 */       super("LOGIN");
/*      */     }
/*      */ 
/*      */     void doAuth(String host, String user, String passwd)
/*      */       throws MessagingException, IOException
/*      */     {
/*  579 */       this.resp = SMTPTransport.this.simpleCommand(BASE64EncoderStream.encode(ASCIIUtility.getBytes(user)));
/*      */ 
/*  581 */       if (this.resp == 334)
/*      */       {
/*  583 */         this.resp = SMTPTransport.this.simpleCommand(BASE64EncoderStream.encode(ASCIIUtility.getBytes(passwd)));
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private abstract class Authenticator
/*      */   {
/*      */     protected int resp;
/*      */     private String mech;
/*      */ 
/*      */     Authenticator(String mech)
/*      */     {
/*  524 */       this.mech = mech.toUpperCase(Locale.ENGLISH);
/*      */     }
/*      */ 
/*      */     String getMechanism() {
/*  528 */       return this.mech;
/*      */     }
/*      */ 
/*      */     boolean authenticate(String host, String user, String passwd)
/*      */       throws MessagingException
/*      */     {
/*  539 */       this.resp = SMTPTransport.this.simpleCommand("AUTH " + this.mech);
/*      */ 
/*  545 */       if (this.resp == 530) {
/*  546 */         SMTPTransport.this.startTLS();
/*  547 */         this.resp = SMTPTransport.this.simpleCommand("AUTH " + this.mech);
/*      */       }
/*      */       try {
/*  550 */         if (this.resp == 334)
/*  551 */           doAuth(host, user, passwd);
/*      */       } catch (IOException ex) {
/*  553 */         if (SMTPTransport.this.debug)
/*  554 */           SMTPTransport.this.out.println("DEBUG: SMTP: " + this.mech + " failed: " + ex);
/*      */       } finally {
/*  556 */         if (this.resp != 235) {
/*  557 */           SMTPTransport.this.closeConnection();
/*  558 */           return false;
/*      */         }
/*      */       }
/*  561 */       return true;
/*      */     }
/*      */ 
/*      */     abstract void doAuth(String paramString1, String paramString2, String paramString3)
/*      */       throws MessagingException, IOException;
/*      */   }
/*      */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.smtp.SMTPTransport
 * JD-Core Version:    0.6.1
 */