/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import javax.mail.Session;
/*     */ 
/*     */ public class PropUtil
/*     */ {
/*     */   public static int getIntProperty(Properties props, String name, int def)
/*     */   {
/*  58 */     return getInt(props.get(name), def);
/*     */   }
/*     */ 
/*     */   public static boolean getBooleanProperty(Properties props, String name, boolean def)
/*     */   {
/*  66 */     return getBoolean(props.get(name), def);
/*     */   }
/*     */ 
/*     */   public static int getIntSessionProperty(Session session, String name, int def)
/*     */   {
/*  74 */     return getInt(session.getProperties().get(name), def);
/*     */   }
/*     */ 
/*     */   public static boolean getBooleanSessionProperty(Session session, String name, boolean def)
/*     */   {
/*  82 */     return getBoolean(session.getProperties().get(name), def);
/*     */   }
/*     */ 
/*     */   public static boolean getBooleanSystemProperty(String name, boolean def)
/*     */   {
/*     */     try
/*     */     {
/*  90 */       return getBoolean(System.getProperties().get(name), def);
/*     */     }
/*     */     catch (SecurityException sex)
/*     */     {
/*     */       try
/*     */       {
/* 100 */         String value = System.getProperty(name);
/* 101 */         if (value == null)
/* 102 */           return def;
/* 103 */         if (def) {
/* 104 */           return !value.equalsIgnoreCase("false");
/*     */         }
/* 106 */         return value.equalsIgnoreCase("true"); } catch (SecurityException sex) {  }
/*     */     }
/* 108 */     return def;
/*     */   }
/*     */ 
/*     */   private static int getInt(Object value, int def)
/*     */   {
/* 117 */     if (value == null)
/* 118 */       return def;
/* 119 */     if ((value instanceof String))
/*     */       try {
/* 121 */         return Integer.parseInt((String)value);
/*     */       } catch (NumberFormatException nfex) {
/*     */       }
/* 124 */     if ((value instanceof Integer))
/* 125 */       return ((Integer)value).intValue();
/* 126 */     return def;
/*     */   }
/*     */ 
/*     */   private static boolean getBoolean(Object value, boolean def)
/*     */   {
/* 134 */     if (value == null)
/* 135 */       return def;
/* 136 */     if ((value instanceof String))
/*     */     {
/* 141 */       if (def) {
/* 142 */         return !((String)value).equalsIgnoreCase("false");
/*     */       }
/* 144 */       return ((String)value).equalsIgnoreCase("true");
/*     */     }
/* 146 */     if ((value instanceof Boolean))
/* 147 */       return ((Boolean)value).booleanValue();
/* 148 */     return def;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.util.PropUtil
 * JD-Core Version:    0.6.1
 */