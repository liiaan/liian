/*    */ package com.sun.mail.util;
/*    */ 
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ public class BEncoderStream extends BASE64EncoderStream
/*    */ {
/*    */   public BEncoderStream(OutputStream out)
/*    */   {
/* 56 */     super(out, 2147483647);
/*    */   }
/*    */ 
/*    */   public static int encodedLength(byte[] b)
/*    */   {
/* 65 */     return (b.length + 2) / 3 * 4;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.util.BEncoderStream
 * JD-Core Version:    0.6.1
 */