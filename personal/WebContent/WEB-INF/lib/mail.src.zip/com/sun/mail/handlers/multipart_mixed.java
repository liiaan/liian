/*    */ package com.sun.mail.handlers;
/*    */ 
/*    */ import java.awt.datatransfer.DataFlavor;
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ import javax.activation.ActivationDataFlavor;
/*    */ import javax.activation.DataContentHandler;
/*    */ import javax.activation.DataSource;
/*    */ import javax.mail.MessagingException;
/*    */ import javax.mail.internet.MimeMultipart;
/*    */ 
/*    */ public class multipart_mixed
/*    */   implements DataContentHandler
/*    */ {
/* 46 */   private ActivationDataFlavor myDF = new ActivationDataFlavor(MimeMultipart.class, "multipart/mixed", "Multipart");
/*    */ 
/*    */   public DataFlavor[] getTransferDataFlavors()
/*    */   {
/* 57 */     return new DataFlavor[] { this.myDF };
/*    */   }
/*    */ 
/*    */   public Object getTransferData(DataFlavor df, DataSource ds)
/*    */     throws IOException
/*    */   {
/* 71 */     if (this.myDF.equals(df)) {
/* 72 */       return getContent(ds);
/*    */     }
/* 74 */     return null;
/*    */   }
/*    */ 
/*    */   public Object getContent(DataSource ds)
/*    */     throws IOException
/*    */   {
/*    */     try
/*    */     {
/* 82 */       return new MimeMultipart(ds);
/*    */     } catch (MessagingException e) {
/* 84 */       IOException ioex = new IOException("Exception while constructing MimeMultipart");
/*    */ 
/* 86 */       ioex.initCause(e);
/* 87 */       throw ioex;
/*    */     }
/*    */   }
/*    */ 
/*    */   public void writeTo(Object obj, String mimeType, OutputStream os)
/*    */     throws IOException
/*    */   {
/* 96 */     if ((obj instanceof MimeMultipart))
/*    */       try {
/* 98 */         ((MimeMultipart)obj).writeTo(os);
/*    */       } catch (MessagingException e) {
/* 100 */         throw new IOException(e.toString());
/*    */       }
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.handlers.multipart_mixed
 * JD-Core Version:    0.6.1
 */