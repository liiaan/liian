/*     */ package com.sun.mail.imap.protocol;
/*     */ 
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class UIDSet
/*     */ {
/*     */   public long start;
/*     */   public long end;
/*     */ 
/*     */   public UIDSet()
/*     */   {
/*     */   }
/*     */ 
/*     */   public UIDSet(long start, long end)
/*     */   {
/*  52 */     this.start = start;
/*  53 */     this.end = end;
/*     */   }
/*     */ 
/*     */   public long size()
/*     */   {
/*  60 */     return this.end - this.start + 1L;
/*     */   }
/*     */ 
/*     */   public static UIDSet[] createUIDSets(long[] msgs)
/*     */   {
/*  67 */     Vector v = new Vector();
/*     */ 
/*  70 */     for (int i = 0; i < msgs.length; i++) {
/*  71 */       UIDSet ms = new UIDSet();
/*  72 */       ms.start = msgs[i];
/*     */ 
/*  75 */       for (int j = i + 1; (j < msgs.length) && 
/*  76 */         (msgs[j] == msgs[(j - 1)] + 1L); j++);
/*  79 */       ms.end = msgs[(j - 1)];
/*  80 */       v.addElement(ms);
/*  81 */       i = j - 1;
/*     */     }
/*  83 */     UIDSet[] msgsets = new UIDSet[v.size()];
/*  84 */     v.copyInto(msgsets);
/*  85 */     return msgsets;
/*     */   }
/*     */ 
/*     */   public static String toString(UIDSet[] msgsets)
/*     */   {
/*  92 */     if ((msgsets == null) || (msgsets.length == 0)) {
/*  93 */       return null;
/*     */     }
/*  95 */     int i = 0;
/*  96 */     StringBuffer s = new StringBuffer();
/*  97 */     int size = msgsets.length;
/*     */     while (true)
/*     */     {
/* 101 */       long start = msgsets[i].start;
/* 102 */       long end = msgsets[i].end;
/*     */ 
/* 104 */       if (end > start)
/* 105 */         s.append(start).append(':').append(end);
/*     */       else {
/* 107 */         s.append(start);
/*     */       }
/* 109 */       i++;
/* 110 */       if (i >= size) {
/*     */         break;
/*     */       }
/* 113 */       s.append(',');
/*     */     }
/* 115 */     return s.toString();
/*     */   }
/*     */ 
/*     */   public static long size(UIDSet[] msgsets)
/*     */   {
/* 123 */     long count = 0L;
/*     */ 
/* 125 */     if (msgsets == null) {
/* 126 */       return 0L;
/*     */     }
/* 128 */     for (int i = 0; i < msgsets.length; i++) {
/* 129 */       count += msgsets[i].size();
/*     */     }
/* 131 */     return count;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.protocol.UIDSet
 * JD-Core Version:    0.6.1
 */