/*     */ package com.sun.mail.imap.protocol;
/*     */ 
/*     */ import java.io.CharArrayWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.Writer;
/*     */ 
/*     */ public class BASE64MailboxEncoder
/*     */ {
/* 106 */   protected byte[] buffer = new byte[4];
/* 107 */   protected int bufsize = 0;
/* 108 */   protected boolean started = false;
/* 109 */   protected Writer out = null;
/*     */ 
/* 246 */   private static final char[] pem_array = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', ',' };
/*     */ 
/*     */   public static String encode(String original)
/*     */   {
/* 113 */     BASE64MailboxEncoder base64stream = null;
/* 114 */     char[] origchars = original.toCharArray();
/* 115 */     int length = origchars.length;
/* 116 */     boolean changedString = false;
/* 117 */     CharArrayWriter writer = new CharArrayWriter(length);
/*     */ 
/* 120 */     for (int index = 0; index < length; index++) {
/* 121 */       char current = origchars[index];
/*     */ 
/* 125 */       if ((current >= ' ') && (current <= '~')) {
/* 126 */         if (base64stream != null) {
/* 127 */           base64stream.flush();
/*     */         }
/*     */ 
/* 130 */         if (current == '&') {
/* 131 */           changedString = true;
/* 132 */           writer.write(38);
/* 133 */           writer.write(45);
/*     */         } else {
/* 135 */           writer.write(current);
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 144 */         if (base64stream == null) {
/* 145 */           base64stream = new BASE64MailboxEncoder(writer);
/* 146 */           changedString = true;
/*     */         }
/*     */ 
/* 149 */         base64stream.write(current);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 154 */     if (base64stream != null) {
/* 155 */       base64stream.flush();
/*     */     }
/*     */ 
/* 158 */     if (changedString) {
/* 159 */       return writer.toString();
/*     */     }
/* 161 */     return original;
/*     */   }
/*     */ 
/*     */   public BASE64MailboxEncoder(Writer what)
/*     */   {
/* 170 */     this.out = what;
/*     */   }
/*     */ 
/*     */   public void write(int c)
/*     */   {
/*     */     try {
/* 176 */       if (!this.started) {
/* 177 */         this.started = true;
/* 178 */         this.out.write(38);
/*     */       }
/*     */ 
/* 182 */       this.buffer[(this.bufsize++)] = (byte)(c >> 8);
/* 183 */       this.buffer[(this.bufsize++)] = (byte)(c & 0xFF);
/*     */ 
/* 185 */       if (this.bufsize >= 3) {
/* 186 */         encode();
/* 187 */         this.bufsize -= 3;
/*     */       }
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public void flush()
/*     */   {
/*     */     try {
/* 198 */       if (this.bufsize > 0) {
/* 199 */         encode();
/* 200 */         this.bufsize = 0;
/*     */       }
/*     */ 
/* 204 */       if (this.started) {
/* 205 */         this.out.write(45);
/* 206 */         this.started = false;
/*     */       }
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void encode() throws IOException
/*     */   {
/* 216 */     if (this.bufsize == 1) {
/* 217 */       byte a = this.buffer[0];
/* 218 */       byte b = 0;
/* 219 */       byte c = 0;
/* 220 */       this.out.write(pem_array[(a >>> 2 & 0x3F)]);
/* 221 */       this.out.write(pem_array[((a << 4 & 0x30) + (b >>> 4 & 0xF))]);
/*     */     }
/* 223 */     else if (this.bufsize == 2) {
/* 224 */       byte a = this.buffer[0];
/* 225 */       byte b = this.buffer[1];
/* 226 */       byte c = 0;
/* 227 */       this.out.write(pem_array[(a >>> 2 & 0x3F)]);
/* 228 */       this.out.write(pem_array[((a << 4 & 0x30) + (b >>> 4 & 0xF))]);
/* 229 */       this.out.write(pem_array[((b << 2 & 0x3C) + (c >>> 6 & 0x3))]);
/*     */     }
/*     */     else {
/* 232 */       byte a = this.buffer[0];
/* 233 */       byte b = this.buffer[1];
/* 234 */       byte c = this.buffer[2];
/* 235 */       this.out.write(pem_array[(a >>> 2 & 0x3F)]);
/* 236 */       this.out.write(pem_array[((a << 4 & 0x30) + (b >>> 4 & 0xF))]);
/* 237 */       this.out.write(pem_array[((b << 2 & 0x3C) + (c >>> 6 & 0x3))]);
/* 238 */       this.out.write(pem_array[(c & 0x3F)]);
/*     */ 
/* 241 */       if (this.bufsize == 4)
/* 242 */         this.buffer[0] = this.buffer[3];
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.protocol.BASE64MailboxEncoder
 * JD-Core Version:    0.6.1
 */