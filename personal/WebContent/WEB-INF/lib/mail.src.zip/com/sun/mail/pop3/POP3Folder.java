/*     */ package com.sun.mail.pop3;
/*     */ 
/*     */ import com.sun.mail.util.LineInputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ import javax.mail.FetchProfile;
/*     */ import javax.mail.FetchProfile.Item;
/*     */ import javax.mail.Flags;
/*     */ import javax.mail.Flags.Flag;
/*     */ import javax.mail.Folder;
/*     */ import javax.mail.FolderClosedException;
/*     */ import javax.mail.FolderNotFoundException;
/*     */ import javax.mail.Message;
/*     */ import javax.mail.MessageRemovedException;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.MethodNotSupportedException;
/*     */ import javax.mail.Store;
/*     */ import javax.mail.UIDFolder.FetchProfileItem;
/*     */ 
/*     */ public class POP3Folder extends Folder
/*     */ {
/*     */   private String name;
/*     */   private Protocol port;
/*     */   private int total;
/*     */   private int size;
/*  68 */   private boolean exists = false;
/*  69 */   private boolean opened = false;
/*     */   private Vector message_cache;
/*  71 */   private boolean doneUidl = false;
/*     */ 
/*     */   POP3Folder(POP3Store store, String name) {
/*  74 */     super(store);
/*  75 */     this.name = name;
/*  76 */     if (name.equalsIgnoreCase("INBOX"))
/*  77 */       this.exists = true;
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  81 */     return this.name;
/*     */   }
/*     */ 
/*     */   public String getFullName() {
/*  85 */     return this.name;
/*     */   }
/*     */ 
/*     */   public Folder getParent() {
/*  89 */     return new DefaultFolder((POP3Store)this.store);
/*     */   }
/*     */ 
/*     */   public boolean exists()
/*     */   {
/*  99 */     return this.exists;
/*     */   }
/*     */ 
/*     */   public Folder[] list(String pattern)
/*     */     throws MessagingException
/*     */   {
/* 109 */     throw new MessagingException("not a directory");
/*     */   }
/*     */ 
/*     */   public char getSeparator()
/*     */   {
/* 118 */     return '\000';
/*     */   }
/*     */ 
/*     */   public int getType()
/*     */   {
/* 127 */     return 1;
/*     */   }
/*     */ 
/*     */   public boolean create(int type)
/*     */     throws MessagingException
/*     */   {
/* 137 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean hasNewMessages()
/*     */     throws MessagingException
/*     */   {
/* 147 */     return false;
/*     */   }
/*     */ 
/*     */   public Folder getFolder(String name)
/*     */     throws MessagingException
/*     */   {
/* 157 */     throw new MessagingException("not a directory");
/*     */   }
/*     */ 
/*     */   public boolean delete(boolean recurse)
/*     */     throws MessagingException
/*     */   {
/* 168 */     throw new MethodNotSupportedException("delete");
/*     */   }
/*     */ 
/*     */   public boolean renameTo(Folder f)
/*     */     throws MessagingException
/*     */   {
/* 178 */     throw new MethodNotSupportedException("renameTo");
/*     */   }
/*     */ 
/*     */   public synchronized void open(int mode)
/*     */     throws MessagingException
/*     */   {
/* 190 */     checkClosed();
/* 191 */     if (!this.exists)
/* 192 */       throw new FolderNotFoundException(this, "folder is not INBOX");
/*     */     try
/*     */     {
/* 195 */       this.port = ((POP3Store)this.store).getPort(this);
/* 196 */       Status s = this.port.stat();
/* 197 */       this.total = s.total;
/* 198 */       this.size = s.size;
/* 199 */       this.mode = mode;
/* 200 */       this.opened = true;
/*     */     } catch (IOException ioex) {
/*     */       try {
/* 203 */         if (this.port != null)
/* 204 */           this.port.quit();
/*     */       } catch (IOException ioex2) {
/*     */       }
/*     */       finally {
/* 208 */         this.port = null;
/* 209 */         ((POP3Store)this.store).closePort(this);
/*     */       }
/* 211 */       throw new MessagingException("Open failed", ioex);
/*     */     }
/*     */ 
/* 215 */     this.message_cache = new Vector(this.total);
/* 216 */     this.message_cache.setSize(this.total);
/* 217 */     this.doneUidl = false;
/*     */ 
/* 219 */     notifyConnectionListeners(1);
/*     */   }
/*     */ 
/*     */   public synchronized void close(boolean expunge) throws MessagingException {
/* 223 */     checkOpen();
/*     */     try
/*     */     {
/* 235 */       if (((POP3Store)this.store).rsetBeforeQuit)
/* 236 */         this.port.rset();
/* 237 */       if ((expunge) && (this.mode == 2))
/*     */       {
/* 240 */         for (int i = 0; i < this.message_cache.size(); i++)
/*     */         {
/*     */           POP3Message m;
/* 241 */           if (((m = (POP3Message)this.message_cache.elementAt(i)) != null) && 
/* 242 */             (m.isSet(Flags.Flag.DELETED))) {
/*     */             try {
/* 244 */               this.port.dele(i + 1);
/*     */             } catch (IOException ioex) {
/* 246 */               throw new MessagingException("Exception deleting messages during close", ioex);
/*     */             }
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 254 */       this.port.quit();
/*     */     } catch (IOException ex) {
/*     */     }
/*     */     finally {
/* 258 */       this.port = null;
/* 259 */       ((POP3Store)this.store).closePort(this);
/* 260 */       this.message_cache = null;
/* 261 */       this.opened = false;
/* 262 */       notifyConnectionListeners(3);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isOpen() {
/* 267 */     if (!this.opened)
/* 268 */       return false;
/* 269 */     if (this.store.isConnected())
/* 270 */       return true;
/*     */     try {
/* 272 */       close(false); } catch (MessagingException ex) {
/*     */     }
/* 274 */     return false;
/*     */   }
/*     */ 
/*     */   public Flags getPermanentFlags()
/*     */   {
/* 284 */     return new Flags();
/*     */   }
/*     */ 
/*     */   public synchronized int getMessageCount()
/*     */     throws MessagingException
/*     */   {
/* 293 */     if (!this.opened)
/* 294 */       return -1;
/* 295 */     checkReadable();
/* 296 */     return this.total;
/*     */   }
/*     */ 
/*     */   public synchronized Message getMessage(int msgno) throws MessagingException
/*     */   {
/* 301 */     checkOpen();
/*     */     POP3Message m;
/* 306 */     if ((m = (POP3Message)this.message_cache.elementAt(msgno - 1)) == null) {
/* 307 */       m = createMessage(this, msgno);
/* 308 */       this.message_cache.setElementAt(m, msgno - 1);
/*     */     }
/* 310 */     return m;
/*     */   }
/*     */ 
/*     */   protected POP3Message createMessage(Folder f, int msgno) throws MessagingException
/*     */   {
/* 315 */     POP3Message m = null;
/* 316 */     Constructor cons = ((POP3Store)this.store).messageConstructor;
/* 317 */     if (cons != null)
/*     */       try {
/* 319 */         Object[] o = { this, new Integer(msgno) };
/* 320 */         m = (POP3Message)cons.newInstance(o);
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/*     */       }
/* 325 */     if (m == null)
/* 326 */       m = new POP3Message(this, msgno);
/* 327 */     return m;
/*     */   }
/*     */ 
/*     */   public void appendMessages(Message[] msgs)
/*     */     throws MessagingException
/*     */   {
/* 337 */     throw new MethodNotSupportedException("Append not supported");
/*     */   }
/*     */ 
/*     */   public Message[] expunge()
/*     */     throws MessagingException
/*     */   {
/* 350 */     throw new MethodNotSupportedException("Expunge not supported");
/*     */   }
/*     */ 
/*     */   public synchronized void fetch(Message[] msgs, FetchProfile fp)
/*     */     throws MessagingException
/*     */   {
/* 364 */     checkReadable();
/* 365 */     if ((!this.doneUidl) && (fp.contains(UIDFolder.FetchProfileItem.UID)))
/*     */     {
/* 374 */       String[] uids = new String[this.message_cache.size()];
/*     */       try {
/* 376 */         if (!this.port.uidl(uids))
/* 377 */           return;
/*     */       } catch (EOFException eex) {
/* 379 */         close(false);
/* 380 */         throw new FolderClosedException(this, eex.toString());
/*     */       } catch (IOException ex) {
/* 382 */         throw new MessagingException("error getting UIDL", ex);
/*     */       }
/* 384 */       for (int i = 0; i < uids.length; i++)
/* 385 */         if (uids[i] != null)
/*     */         {
/* 387 */           POP3Message m = (POP3Message)getMessage(i + 1);
/* 388 */           m.uid = uids[i];
/*     */         }
/* 390 */       this.doneUidl = true;
/*     */     }
/* 392 */     if (fp.contains(FetchProfile.Item.ENVELOPE))
/* 393 */       for (int i = 0; i < msgs.length; i++)
/*     */         try {
/* 395 */           POP3Message msg = (POP3Message)msgs[i];
/*     */ 
/* 397 */           msg.getHeader("");
/*     */ 
/* 399 */           msg.getSize();
/*     */         }
/*     */         catch (MessageRemovedException mex)
/*     */         {
/*     */         }
/*     */   }
/*     */ 
/*     */   public synchronized String getUID(Message msg)
/*     */     throws MessagingException
/*     */   {
/* 415 */     checkOpen();
/* 416 */     POP3Message m = (POP3Message)msg;
/*     */     try {
/* 418 */       if (m.uid == "UNKNOWN")
/* 419 */         m.uid = this.port.uidl(m.getMessageNumber());
/* 420 */       return m.uid;
/*     */     } catch (EOFException eex) {
/* 422 */       close(false);
/* 423 */       throw new FolderClosedException(this, eex.toString());
/*     */     } catch (IOException ex) {
/* 425 */       throw new MessagingException("error getting UIDL", ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized int getSize()
/*     */     throws MessagingException
/*     */   {
/* 437 */     checkOpen();
/* 438 */     return this.size;
/*     */   }
/*     */ 
/*     */   public synchronized int[] getSizes()
/*     */     throws MessagingException
/*     */   {
/* 451 */     checkOpen();
/* 452 */     int[] sizes = new int[this.total];
/* 453 */     InputStream is = null;
/* 454 */     LineInputStream lis = null;
/*     */     try {
/* 456 */       is = this.port.list();
/* 457 */       lis = new LineInputStream(is);
/*     */       String line;
/* 459 */       while ((line = lis.readLine()) != null)
/*     */         try {
/* 461 */           StringTokenizer st = new StringTokenizer(line);
/* 462 */           int msgnum = Integer.parseInt(st.nextToken());
/* 463 */           int size = Integer.parseInt(st.nextToken());
/* 464 */           if ((msgnum > 0) && (msgnum <= this.total))
/* 465 */             sizes[(msgnum - 1)] = size;
/*     */         } catch (Exception e) {
/*     */         }
/*     */     }
/*     */     catch (IOException ex) {
/*     */     }
/*     */     finally {
/*     */       try {
/* 473 */         if (lis != null)
/* 474 */           lis.close(); 
/*     */       } catch (IOException cex) {
/*     */       }
/*     */       try { if (is != null)
/* 478 */           is.close(); } catch (IOException cex) {
/*     */       }
/*     */     }
/* 481 */     return sizes;
/*     */   }
/*     */ 
/*     */   public synchronized InputStream listCommand()
/*     */     throws MessagingException, IOException
/*     */   {
/* 493 */     checkOpen();
/* 494 */     return this.port.list();
/*     */   }
/*     */ 
/*     */   protected void finalize()
/*     */     throws Throwable
/*     */   {
/* 501 */     super.finalize();
/* 502 */     close(false);
/*     */   }
/*     */ 
/*     */   void checkOpen() throws IllegalStateException
/*     */   {
/* 507 */     if (!this.opened)
/* 508 */       throw new IllegalStateException("Folder is not Open");
/*     */   }
/*     */ 
/*     */   void checkClosed() throws IllegalStateException
/*     */   {
/* 513 */     if (this.opened)
/* 514 */       throw new IllegalStateException("Folder is Open");
/*     */   }
/*     */ 
/*     */   void checkReadable() throws IllegalStateException
/*     */   {
/* 519 */     if ((!this.opened) || ((this.mode != 1) && (this.mode != 2)))
/* 520 */       throw new IllegalStateException("Folder is not Readable");
/*     */   }
/*     */ 
/*     */   void checkWritable() throws IllegalStateException
/*     */   {
/* 525 */     if ((!this.opened) || (this.mode != 2))
/* 526 */       throw new IllegalStateException("Folder is not Writable");
/*     */   }
/*     */ 
/*     */   Protocol getProtocol()
/*     */     throws MessagingException
/*     */   {
/* 535 */     checkOpen();
/* 536 */     return this.port;
/*     */   }
/*     */ 
/*     */   protected void notifyMessageChangedListeners(int type, Message m)
/*     */   {
/* 543 */     super.notifyMessageChangedListeners(type, m);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.pop3.POP3Folder
 * JD-Core Version:    0.6.1
 */