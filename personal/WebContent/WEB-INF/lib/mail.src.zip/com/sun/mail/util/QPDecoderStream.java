/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PushbackInputStream;
/*     */ 
/*     */ public class QPDecoderStream extends FilterInputStream
/*     */ {
/*  51 */   protected byte[] ba = new byte[2];
/*  52 */   protected int spaces = 0;
/*     */ 
/*     */   public QPDecoderStream(InputStream in)
/*     */   {
/*  60 */     super(new PushbackInputStream(in, 2));
/*     */   }
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/*  76 */     if (this.spaces > 0)
/*     */     {
/*  78 */       this.spaces -= 1;
/*  79 */       return 32;
/*     */     }
/*     */ 
/*  82 */     int c = this.in.read();
/*     */ 
/*  84 */     if (c == 32)
/*     */     {
/*  86 */       while ((c = this.in.read()) == 32) {
/*  87 */         this.spaces += 1;
/*     */       }
/*  89 */       if ((c == 13) || (c == 10) || (c == -1))
/*     */       {
/*  92 */         this.spaces = 0;
/*     */       }
/*     */       else {
/*  95 */         ((PushbackInputStream)this.in).unread(c);
/*  96 */         c = 32;
/*     */       }
/*  98 */       return c;
/*     */     }
/* 100 */     if (c == 61)
/*     */     {
/* 102 */       int a = this.in.read();
/*     */ 
/* 104 */       if (a == 10)
/*     */       {
/* 110 */         return read();
/* 111 */       }if (a == 13)
/*     */       {
/* 113 */         int b = this.in.read();
/* 114 */         if (b != 10)
/*     */         {
/* 118 */           ((PushbackInputStream)this.in).unread(b);
/* 119 */         }return read();
/* 120 */       }if (a == -1)
/*     */       {
/* 122 */         return -1;
/*     */       }
/* 124 */       this.ba[0] = (byte)a;
/* 125 */       this.ba[1] = (byte)this.in.read();
/*     */       try {
/* 127 */         return ASCIIUtility.parseInt(this.ba, 0, 2, 16);
/*     */       }
/*     */       catch (NumberFormatException nex)
/*     */       {
/* 136 */         ((PushbackInputStream)this.in).unread(this.ba);
/* 137 */         return c;
/*     */       }
/*     */     }
/*     */ 
/* 141 */     return c;
/*     */   }
/*     */ 
/*     */   public int read(byte[] buf, int off, int len)
/*     */     throws IOException
/*     */   {
/* 160 */     for (int i = 0; i < len; i++)
/*     */     {
/*     */       int c;
/* 161 */       if ((c = read()) == -1) {
/* 162 */         if (i != 0) break;
/* 163 */         i = -1; break;
/*     */       }
/*     */ 
/* 166 */       buf[(off + i)] = (byte)c;
/*     */     }
/* 168 */     return i;
/*     */   }
/*     */ 
/*     */   public long skip(long n)
/*     */     throws IOException
/*     */   {
/* 175 */     long skipped = 0L;
/* 176 */     while ((n-- > 0L) && (read() >= 0))
/* 177 */       skipped += 1L;
/* 178 */     return skipped;
/*     */   }
/*     */ 
/*     */   public boolean markSupported()
/*     */   {
/* 186 */     return false;
/*     */   }
/*     */ 
/*     */   public int available()
/*     */     throws IOException
/*     */   {
/* 199 */     return this.in.available();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.util.QPDecoderStream
 * JD-Core Version:    0.6.1
 */