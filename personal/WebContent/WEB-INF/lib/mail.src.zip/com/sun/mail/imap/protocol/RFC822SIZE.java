/*    */ package com.sun.mail.imap.protocol;
/*    */ 
/*    */ import com.sun.mail.iap.ParsingException;
/*    */ 
/*    */ public class RFC822SIZE
/*    */   implements Item
/*    */ {
/* 49 */   static final char[] name = { 'R', 'F', 'C', '8', '2', '2', '.', 'S', 'I', 'Z', 'E' };
/*    */   public int msgno;
/*    */   public int size;
/*    */ 
/*    */   public RFC822SIZE(FetchResponse r)
/*    */     throws ParsingException
/*    */   {
/* 59 */     this.msgno = r.getNumber();
/* 60 */     r.skipSpaces();
/* 61 */     this.size = r.readNumber();
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.protocol.RFC822SIZE
 * JD-Core Version:    0.6.1
 */