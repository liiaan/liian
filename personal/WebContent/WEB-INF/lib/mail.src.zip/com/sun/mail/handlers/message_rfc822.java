/*     */ package com.sun.mail.handlers;
/*     */ 
/*     */ import java.awt.datatransfer.DataFlavor;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Properties;
/*     */ import javax.activation.ActivationDataFlavor;
/*     */ import javax.activation.DataContentHandler;
/*     */ import javax.activation.DataSource;
/*     */ import javax.mail.Message;
/*     */ import javax.mail.MessageAware;
/*     */ import javax.mail.MessageContext;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.Session;
/*     */ import javax.mail.internet.MimeMessage;
/*     */ 
/*     */ public class message_rfc822
/*     */   implements DataContentHandler
/*     */ {
/*  53 */   ActivationDataFlavor ourDataFlavor = new ActivationDataFlavor(Message.class, "message/rfc822", "Message");
/*     */ 
/*     */   public DataFlavor[] getTransferDataFlavors()
/*     */   {
/*  63 */     return new DataFlavor[] { this.ourDataFlavor };
/*     */   }
/*     */ 
/*     */   public Object getTransferData(DataFlavor df, DataSource ds)
/*     */     throws IOException
/*     */   {
/*  75 */     if (this.ourDataFlavor.equals(df)) {
/*  76 */       return getContent(ds);
/*     */     }
/*  78 */     return null;
/*     */   }
/*     */ 
/*     */   public Object getContent(DataSource ds)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/*     */       Session session;
/*     */       Session session;
/*  88 */       if ((ds instanceof MessageAware)) {
/*  89 */         MessageContext mc = ((MessageAware)ds).getMessageContext();
/*  90 */         session = mc.getSession();
/*     */       }
/*     */       else
/*     */       {
/*  96 */         session = Session.getDefaultInstance(new Properties(), null);
/*     */       }
/*  98 */       return new MimeMessage(session, ds.getInputStream());
/*     */     } catch (MessagingException me) {
/* 100 */       throw new IOException("Exception creating MimeMessage in message/rfc822 DataContentHandler: " + me.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void writeTo(Object obj, String mimeType, OutputStream os)
/*     */     throws IOException
/*     */   {
/* 113 */     if ((obj instanceof Message)) {
/* 114 */       Message m = (Message)obj;
/*     */       try {
/* 116 */         m.writeTo(os);
/*     */       } catch (MessagingException me) {
/* 118 */         throw new IOException(me.toString());
/*     */       }
/*     */     }
/*     */     else {
/* 122 */       throw new IOException("unsupported object");
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.handlers.message_rfc822
 * JD-Core Version:    0.6.1
 */