/*    */ package com.sun.mail.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.mail.Folder;
/*    */ 
/*    */ public class FolderClosedIOException extends IOException
/*    */ {
/*    */   private transient Folder folder;
/*    */   private static final long serialVersionUID = 4281122580365555735L;
/*    */ 
/*    */   public FolderClosedIOException(Folder folder)
/*    */   {
/* 60 */     this(folder, null);
/*    */   }
/*    */ 
/*    */   public FolderClosedIOException(Folder folder, String message)
/*    */   {
/* 69 */     super(message);
/* 70 */     this.folder = folder;
/*    */   }
/*    */ 
/*    */   public Folder getFolder()
/*    */   {
/* 77 */     return this.folder;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.util.FolderClosedIOException
 * JD-Core Version:    0.6.1
 */