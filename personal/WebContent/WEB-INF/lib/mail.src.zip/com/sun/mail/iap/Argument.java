/*     */ package com.sun.mail.iap;
/*     */ 
/*     */ import com.sun.mail.util.ASCIIUtility;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class Argument
/*     */ {
/*     */   protected Vector items;
/*     */ 
/*     */   public Argument()
/*     */   {
/*  54 */     this.items = new Vector(1);
/*     */   }
/*     */ 
/*     */   public void append(Argument arg)
/*     */   {
/*  63 */     this.items.ensureCapacity(this.items.size() + arg.items.size());
/*  64 */     for (int i = 0; i < arg.items.size(); i++)
/*  65 */       this.items.addElement(arg.items.elementAt(i));
/*     */   }
/*     */ 
/*     */   public void writeString(String s)
/*     */   {
/*  78 */     this.items.addElement(new AString(ASCIIUtility.getBytes(s)));
/*     */   }
/*     */ 
/*     */   public void writeString(String s, String charset)
/*     */     throws UnsupportedEncodingException
/*     */   {
/*  87 */     if (charset == null)
/*  88 */       writeString(s);
/*     */     else
/*  90 */       this.items.addElement(new AString(s.getBytes(charset)));
/*     */   }
/*     */ 
/*     */   public void writeBytes(byte[] b)
/*     */   {
/*  98 */     this.items.addElement(b);
/*     */   }
/*     */ 
/*     */   public void writeBytes(ByteArrayOutputStream b)
/*     */   {
/* 106 */     this.items.addElement(b);
/*     */   }
/*     */ 
/*     */   public void writeBytes(Literal b)
/*     */   {
/* 114 */     this.items.addElement(b);
/*     */   }
/*     */ 
/*     */   public void writeAtom(String s)
/*     */   {
/* 124 */     this.items.addElement(new Atom(s));
/*     */   }
/*     */ 
/*     */   public void writeNumber(int i)
/*     */   {
/* 132 */     this.items.addElement(new Integer(i));
/*     */   }
/*     */ 
/*     */   public void writeNumber(long i)
/*     */   {
/* 140 */     this.items.addElement(new Long(i));
/*     */   }
/*     */ 
/*     */   public void writeArgument(Argument c)
/*     */   {
/* 148 */     this.items.addElement(c);
/*     */   }
/*     */ 
/*     */   public void write(Protocol protocol)
/*     */     throws IOException, ProtocolException
/*     */   {
/* 156 */     int size = this.items != null ? this.items.size() : 0;
/* 157 */     DataOutputStream os = (DataOutputStream)protocol.getOutputStream();
/*     */ 
/* 159 */     for (int i = 0; i < size; i++) {
/* 160 */       if (i > 0) {
/* 161 */         os.write(32);
/*     */       }
/* 163 */       Object o = this.items.elementAt(i);
/* 164 */       if ((o instanceof Atom)) {
/* 165 */         os.writeBytes(((Atom)o).string);
/* 166 */       } else if ((o instanceof Number)) {
/* 167 */         os.writeBytes(((Number)o).toString());
/* 168 */       } else if ((o instanceof AString)) {
/* 169 */         astring(((AString)o).bytes, protocol);
/* 170 */       } else if ((o instanceof byte[])) {
/* 171 */         literal((byte[])o, protocol);
/* 172 */       } else if ((o instanceof ByteArrayOutputStream)) {
/* 173 */         literal((ByteArrayOutputStream)o, protocol);
/* 174 */       } else if ((o instanceof Literal)) {
/* 175 */         literal((Literal)o, protocol);
/* 176 */       } else if ((o instanceof Argument)) {
/* 177 */         os.write(40);
/* 178 */         ((Argument)o).write(protocol);
/* 179 */         os.write(41);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void astring(byte[] bytes, Protocol protocol)
/*     */     throws IOException, ProtocolException
/*     */   {
/* 189 */     DataOutputStream os = (DataOutputStream)protocol.getOutputStream();
/* 190 */     int len = bytes.length;
/*     */ 
/* 193 */     if (len > 1024) {
/* 194 */       literal(bytes, protocol);
/* 195 */       return;
/*     */     }
/*     */ 
/* 199 */     boolean quote = len == 0;
/* 200 */     boolean escape = false;
/*     */ 
/* 203 */     for (int i = 0; i < len; i++) {
/* 204 */       byte b = bytes[i];
/* 205 */       if ((b == 0) || (b == 13) || (b == 10) || ((b & 0xFF) > 127))
/*     */       {
/* 207 */         literal(bytes, protocol);
/* 208 */         return;
/*     */       }
/* 210 */       if ((b == 42) || (b == 37) || (b == 40) || (b == 41) || (b == 123) || (b == 34) || (b == 92) || ((b & 0xFF) <= 32))
/*     */       {
/* 212 */         quote = true;
/* 213 */         if ((b == 34) || (b == 92)) {
/* 214 */           escape = true;
/*     */         }
/*     */       }
/*     */     }
/* 218 */     if (quote) {
/* 219 */       os.write(34);
/*     */     }
/* 221 */     if (escape)
/*     */     {
/* 223 */       for (int i = 0; i < len; i++) {
/* 224 */         byte b = bytes[i];
/* 225 */         if ((b == 34) || (b == 92))
/* 226 */           os.write(92);
/* 227 */         os.write(b);
/*     */       }
/*     */     }
/* 230 */     else os.write(bytes);
/*     */ 
/* 233 */     if (quote)
/* 234 */       os.write(34);
/*     */   }
/*     */ 
/*     */   private void literal(byte[] b, Protocol protocol)
/*     */     throws IOException, ProtocolException
/*     */   {
/* 242 */     startLiteral(protocol, b.length).write(b);
/*     */   }
/*     */ 
/*     */   private void literal(ByteArrayOutputStream b, Protocol protocol)
/*     */     throws IOException, ProtocolException
/*     */   {
/* 250 */     b.writeTo(startLiteral(protocol, b.size()));
/*     */   }
/*     */ 
/*     */   private void literal(Literal b, Protocol protocol)
/*     */     throws IOException, ProtocolException
/*     */   {
/* 258 */     b.writeTo(startLiteral(protocol, b.size()));
/*     */   }
/*     */ 
/*     */   private OutputStream startLiteral(Protocol protocol, int size) throws IOException, ProtocolException
/*     */   {
/* 263 */     DataOutputStream os = (DataOutputStream)protocol.getOutputStream();
/* 264 */     boolean nonSync = protocol.supportsNonSyncLiterals();
/*     */ 
/* 266 */     os.write(123);
/* 267 */     os.writeBytes(Integer.toString(size));
/* 268 */     if (nonSync)
/* 269 */       os.writeBytes("+}\r\n");
/*     */     else
/* 271 */       os.writeBytes("}\r\n");
/* 272 */     os.flush();
/*     */ 
/* 276 */     if (!nonSync) {
/*     */       while (true) {
/* 278 */         Response r = protocol.readResponse();
/* 279 */         if (r.isContinuation())
/*     */           break;
/* 281 */         if (r.isTagged()) {
/* 282 */           throw new LiteralException(r);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 287 */     return os;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.iap.Argument
 * JD-Core Version:    0.6.1
 */