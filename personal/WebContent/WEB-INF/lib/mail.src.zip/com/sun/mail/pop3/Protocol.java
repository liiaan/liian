/*     */ package com.sun.mail.pop3;
/*     */ 
/*     */ import com.sun.mail.util.LineInputStream;
/*     */ import com.sun.mail.util.PropUtil;
/*     */ import com.sun.mail.util.SocketFetcher;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedWriter;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.Socket;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ class Protocol
/*     */ {
/*     */   private Socket socket;
/*     */   private DataInputStream input;
/*     */   private PrintWriter output;
/*     */   private static final int POP3_PORT = 110;
/*     */   private static final String CRLF = "\r\n";
/*  69 */   private boolean debug = false;
/*     */   private PrintStream out;
/*  71 */   private String apopChallenge = null;
/*     */ 
/* 183 */   private static char[] digits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
/*     */ 
/*     */   Protocol(String host, int port, boolean debug, PrintStream out, Properties props, String prefix, boolean isSSL)
/*     */     throws IOException
/*     */   {
/*  79 */     this.debug = debug;
/*  80 */     this.out = out;
/*     */ 
/*  82 */     boolean enableAPOP = PropUtil.getBooleanProperty(props, prefix + ".apop.enable", false);
/*     */     Response r;
/*     */     try
/*     */     {
/*  85 */       if (port == -1)
/*  86 */         port = 110;
/*  87 */       if (debug) {
/*  88 */         out.println("DEBUG POP3: connecting to host \"" + host + "\", port " + port + ", isSSL " + isSSL);
/*     */       }
/*     */ 
/*  91 */       this.socket = SocketFetcher.getSocket(host, port, props, prefix, isSSL);
/*     */ 
/*  93 */       this.input = new DataInputStream(new BufferedInputStream(this.socket.getInputStream()));
/*     */ 
/*  95 */       this.output = new PrintWriter(new BufferedWriter(new OutputStreamWriter(this.socket.getOutputStream(), "iso-8859-1")));
/*     */ 
/* 101 */       r = simpleCommand(null);
/*     */     } catch (IOException ioe) {
/*     */       try {
/* 104 */         this.socket.close();
/*     */       }
/*     */       finally
/*     */       {
/*     */       }
/*     */     }
/* 110 */     if (!r.ok)
/*     */       try {
/* 112 */         this.socket.close();
/*     */       }
/*     */       finally
/*     */       {
/*     */       }
/* 117 */     if (enableAPOP) {
/* 118 */       int challStart = r.data.indexOf('<');
/* 119 */       int challEnd = r.data.indexOf('>', challStart);
/* 120 */       if ((challStart != -1) && (challEnd != -1))
/* 121 */         this.apopChallenge = r.data.substring(challStart, challEnd + 1);
/* 122 */       if (debug)
/* 123 */         out.println("DEBUG POP3: APOP challenge: " + this.apopChallenge);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void finalize() throws Throwable {
/* 128 */     super.finalize();
/* 129 */     if (this.socket != null)
/* 130 */       quit();
/*     */   }
/*     */ 
/*     */   synchronized String login(String user, String password)
/*     */     throws IOException
/*     */   {
/* 140 */     String dpw = null;
/* 141 */     if (this.apopChallenge != null)
/* 142 */       dpw = getDigest(password);
/*     */     Response r;
/*     */     Response r;
/* 143 */     if ((this.apopChallenge != null) && (dpw != null)) {
/* 144 */       r = simpleCommand("APOP " + user + " " + dpw);
/*     */     } else {
/* 146 */       r = simpleCommand("USER " + user);
/* 147 */       if (!r.ok)
/* 148 */         return r.data != null ? r.data : "USER command failed";
/* 149 */       r = simpleCommand("PASS " + password);
/*     */     }
/* 151 */     if (!r.ok)
/* 152 */       return r.data != null ? r.data : "login failed";
/* 153 */     return null;
/*     */   }
/*     */ 
/*     */   private String getDigest(String password)
/*     */   {
/* 170 */     String key = this.apopChallenge + password;
/*     */     byte[] digest;
/*     */     try
/*     */     {
/* 173 */       MessageDigest md = MessageDigest.getInstance("MD5");
/* 174 */       digest = md.digest(key.getBytes("iso-8859-1"));
/*     */     } catch (NoSuchAlgorithmException nsae) {
/* 176 */       return null;
/*     */     } catch (UnsupportedEncodingException uee) {
/* 178 */       return null;
/*     */     }
/* 180 */     return toHex(digest);
/*     */   }
/*     */ 
/*     */   private static String toHex(byte[] bytes)
/*     */   {
/* 192 */     char[] result = new char[bytes.length * 2];
/*     */ 
/* 194 */     int index = 0; for (int i = 0; index < bytes.length; index++) {
/* 195 */       int temp = bytes[index] & 0xFF;
/* 196 */       result[(i++)] = digits[(temp >> 4)];
/* 197 */       result[(i++)] = digits[(temp & 0xF)];
/*     */     }
/* 199 */     return new String(result);
/*     */   }
/*     */ 
/*     */   synchronized boolean quit()
/*     */     throws IOException
/*     */   {
/* 206 */     boolean ok = false;
/*     */     try {
/* 208 */       Response r = simpleCommand("QUIT");
/* 209 */       ok = r.ok;
/*     */     }
/*     */     finally
/*     */     {
/*     */     }
/*     */ 
/* 216 */     ret;
/*     */ 
/* 219 */     return ok;
/*     */   }
/*     */ 
/*     */   synchronized Status stat()
/*     */     throws IOException
/*     */   {
/* 227 */     Response r = simpleCommand("STAT");
/* 228 */     Status s = new Status();
/* 229 */     if ((r.ok) && (r.data != null))
/*     */       try {
/* 231 */         StringTokenizer st = new StringTokenizer(r.data);
/* 232 */         s.total = Integer.parseInt(st.nextToken());
/* 233 */         s.size = Integer.parseInt(st.nextToken());
/*     */       }
/*     */       catch (Exception e) {
/*     */       }
/* 237 */     return s;
/*     */   }
/*     */ 
/*     */   synchronized int list(int msg)
/*     */     throws IOException
/*     */   {
/* 244 */     Response r = simpleCommand("LIST " + msg);
/* 245 */     int size = -1;
/* 246 */     if ((r.ok) && (r.data != null))
/*     */       try {
/* 248 */         StringTokenizer st = new StringTokenizer(r.data);
/* 249 */         st.nextToken();
/* 250 */         size = Integer.parseInt(st.nextToken());
/*     */       }
/*     */       catch (Exception e) {
/*     */       }
/* 254 */     return size;
/*     */   }
/*     */ 
/*     */   synchronized InputStream list()
/*     */     throws IOException
/*     */   {
/* 261 */     Response r = multilineCommand("LIST", 128);
/* 262 */     return r.bytes;
/*     */   }
/*     */ 
/*     */   synchronized InputStream retr(int msg, int size)
/*     */     throws IOException
/*     */   {
/* 272 */     Response r = multilineCommand("RETR " + msg, size);
/* 273 */     return r.bytes;
/*     */   }
/*     */ 
/*     */   synchronized InputStream top(int msg, int n)
/*     */     throws IOException
/*     */   {
/* 280 */     Response r = multilineCommand("TOP " + msg + " " + n, 0);
/* 281 */     return r.bytes;
/*     */   }
/*     */ 
/*     */   synchronized boolean dele(int msg)
/*     */     throws IOException
/*     */   {
/* 288 */     Response r = simpleCommand("DELE " + msg);
/* 289 */     return r.ok;
/*     */   }
/*     */ 
/*     */   synchronized String uidl(int msg)
/*     */     throws IOException
/*     */   {
/* 296 */     Response r = simpleCommand("UIDL " + msg);
/* 297 */     if (!r.ok)
/* 298 */       return null;
/* 299 */     int i = r.data.indexOf(' ');
/* 300 */     if (i > 0) {
/* 301 */       return r.data.substring(i + 1);
/*     */     }
/* 303 */     return null;
/*     */   }
/*     */ 
/*     */   synchronized boolean uidl(String[] uids)
/*     */     throws IOException
/*     */   {
/* 311 */     Response r = multilineCommand("UIDL", 15 * uids.length);
/* 312 */     if (!r.ok)
/* 313 */       return false;
/* 314 */     LineInputStream lis = new LineInputStream(r.bytes);
/* 315 */     String line = null;
/* 316 */     while ((line = lis.readLine()) != null) {
/* 317 */       int i = line.indexOf(' ');
/* 318 */       if ((i >= 1) && (i < line.length()))
/*     */       {
/* 320 */         int n = Integer.parseInt(line.substring(0, i));
/* 321 */         if ((n > 0) && (n <= uids.length))
/* 322 */           uids[(n - 1)] = line.substring(i + 1); 
/*     */       }
/*     */     }
/* 324 */     return true;
/*     */   }
/*     */ 
/*     */   synchronized boolean noop()
/*     */     throws IOException
/*     */   {
/* 331 */     Response r = simpleCommand("NOOP");
/* 332 */     return r.ok;
/*     */   }
/*     */ 
/*     */   synchronized boolean rset()
/*     */     throws IOException
/*     */   {
/* 339 */     Response r = simpleCommand("RSET");
/* 340 */     return r.ok;
/*     */   }
/*     */ 
/*     */   private Response simpleCommand(String cmd)
/*     */     throws IOException
/*     */   {
/* 347 */     if (this.socket == null) {
/* 348 */       throw new IOException("Folder is closed");
/*     */     }
/* 350 */     String line = null;
/*     */     try {
/* 352 */       if (cmd != null) {
/* 353 */         if (this.debug)
/* 354 */           this.out.println("C: " + cmd);
/* 355 */         cmd = cmd + "\r\n";
/* 356 */         this.output.print(cmd);
/* 357 */         this.output.flush();
/*     */       }
/* 359 */       line = this.input.readLine();
/*     */     }
/*     */     catch (InterruptedIOException iioex)
/*     */     {
/*     */       try
/*     */       {
/* 369 */         this.socket.close(); } catch (IOException cex) {
/*     */       }
/* 371 */       throw iioex;
/*     */     }
/*     */ 
/* 374 */     if (line == null) {
/* 375 */       if (this.debug)
/* 376 */         this.out.println("S: EOF");
/* 377 */       throw new EOFException("EOF on socket");
/*     */     }
/* 379 */     if (this.debug)
/* 380 */       this.out.println("S: " + line);
/* 381 */     Response r = new Response();
/* 382 */     if (line.startsWith("+OK"))
/* 383 */       r.ok = true;
/* 384 */     else if (line.startsWith("-ERR"))
/* 385 */       r.ok = false;
/*     */     else
/* 387 */       throw new IOException("Unexpected response: " + line);
/*     */     int i;
/* 389 */     if ((i = line.indexOf(' ')) >= 0)
/* 390 */       r.data = line.substring(i + 1);
/* 391 */     return r;
/*     */   }
/*     */ 
/*     */   private Response multilineCommand(String cmd, int size)
/*     */     throws IOException
/*     */   {
/* 399 */     Response r = simpleCommand(cmd);
/* 400 */     if (!r.ok) {
/* 401 */       return r; } SharedByteArrayOutputStream buf = new SharedByteArrayOutputStream(size);
/* 404 */     int lastb = 10;
/*     */     int b;
/*     */     try { while ((b = this.input.read()) >= 0) {
/* 407 */         if ((lastb == 10) && (b == 46)) {
/* 408 */           if (this.debug)
/* 409 */             this.out.write(b);
/* 410 */           b = this.input.read();
/* 411 */           if (b == 13) {
/* 412 */             if (this.debug) {
/* 413 */               this.out.write(b);
/*     */             }
/* 415 */             b = this.input.read();
/* 416 */             if (!this.debug) break;
/* 417 */             this.out.write(b); break;
/*     */           }
/*     */         }
/*     */ 
/* 421 */         buf.write(b);
/* 422 */         if (this.debug)
/* 423 */           this.out.write(b);
/* 424 */         lastb = b;
/*     */       }
/*     */     }
/*     */     catch (InterruptedIOException iioex)
/*     */     {
/*     */       try
/*     */       {
/* 431 */         this.socket.close(); } catch (IOException cex) {
/*     */       }
/* 433 */       throw iioex;
/*     */     }
/* 435 */     if (b < 0)
/* 436 */       throw new EOFException("EOF on socket");
/* 437 */     r.bytes = buf.toStream();
/* 438 */     return r;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.pop3.Protocol
 * JD-Core Version:    0.6.1
 */