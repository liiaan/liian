/*    */ package com.sun.mail.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ public class QDecoderStream extends QPDecoderStream
/*    */ {
/*    */   public QDecoderStream(InputStream in)
/*    */   {
/* 55 */     super(in);
/*    */   }
/*    */ 
/*    */   public int read()
/*    */     throws IOException
/*    */   {
/* 71 */     int c = this.in.read();
/*    */ 
/* 73 */     if (c == 95)
/* 74 */       return 32;
/* 75 */     if (c == 61)
/*    */     {
/* 77 */       this.ba[0] = (byte)this.in.read();
/* 78 */       this.ba[1] = (byte)this.in.read();
/*    */       try
/*    */       {
/* 81 */         return ASCIIUtility.parseInt(this.ba, 0, 2, 16);
/*    */       } catch (NumberFormatException nex) {
/* 83 */         throw new DecodingException("QDecoder: Error in QP stream " + nex.getMessage());
/*    */       }
/*    */     }
/*    */ 
/* 87 */     return c;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.util.QDecoderStream
 * JD-Core Version:    0.6.1
 */