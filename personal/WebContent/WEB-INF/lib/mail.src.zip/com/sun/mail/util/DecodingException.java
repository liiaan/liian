/*    */ package com.sun.mail.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class DecodingException extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = -6913647794421459390L;
/*    */ 
/*    */   public DecodingException(String s)
/*    */   {
/* 57 */     super(s);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.util.DecodingException
 * JD-Core Version:    0.6.1
 */