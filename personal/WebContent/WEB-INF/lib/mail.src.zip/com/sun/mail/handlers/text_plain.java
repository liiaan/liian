/*     */ package com.sun.mail.handlers;
/*     */ 
/*     */ import java.awt.datatransfer.DataFlavor;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import javax.activation.ActivationDataFlavor;
/*     */ import javax.activation.DataContentHandler;
/*     */ import javax.activation.DataSource;
/*     */ import javax.mail.internet.ContentType;
/*     */ import javax.mail.internet.MimeUtility;
/*     */ 
/*     */ public class text_plain
/*     */   implements DataContentHandler
/*     */ {
/*  49 */   private static ActivationDataFlavor myDF = new ActivationDataFlavor(String.class, "text/plain", "Text String");
/*     */ 
/*     */   protected ActivationDataFlavor getDF()
/*     */   {
/*  55 */     return myDF;
/*     */   }
/*     */ 
/*     */   public DataFlavor[] getTransferDataFlavors()
/*     */   {
/*  64 */     return new DataFlavor[] { getDF() };
/*     */   }
/*     */ 
/*     */   public Object getTransferData(DataFlavor df, DataSource ds)
/*     */     throws IOException
/*     */   {
/*  78 */     if (getDF().equals(df)) {
/*  79 */       return getContent(ds);
/*     */     }
/*  81 */     return null;
/*     */   }
/*     */ 
/*     */   public Object getContent(DataSource ds) throws IOException {
/*  85 */     String enc = null;
/*  86 */     InputStreamReader is = null;
/*     */     try
/*     */     {
/*  89 */       enc = getCharset(ds.getContentType());
/*  90 */       is = new InputStreamReader(ds.getInputStream(), enc);
/*     */     }
/*     */     catch (IllegalArgumentException iex)
/*     */     {
/* 100 */       throw new UnsupportedEncodingException(enc);
/*     */     }
/*     */     try
/*     */     {
/* 104 */       int pos = 0;
/*     */ 
/* 106 */       char[] buf = new char[1024];
/*     */       int count;
/*     */       int size;
/* 108 */       while ((count = is.read(buf, pos, buf.length - pos)) != -1) {
/* 109 */         pos += count;
/* 110 */         if (pos >= buf.length) {
/* 111 */           size = buf.length;
/* 112 */           if (size < 262144)
/* 113 */             size += size;
/*     */           else
/* 115 */             size += 262144;
/* 116 */           char[] tbuf = new char[size];
/* 117 */           System.arraycopy(buf, 0, tbuf, 0, pos);
/* 118 */           buf = tbuf;
/*     */         }
/*     */       }
/* 121 */       return new String(buf, 0, pos);
/*     */     } finally {
/*     */       try {
/* 124 */         is.close();
/*     */       }
/*     */       catch (IOException ex)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void writeTo(Object obj, String type, OutputStream os) throws IOException
/*     */   {
/* 134 */     if (!(obj instanceof String)) {
/* 135 */       throw new IOException("\"" + getDF().getMimeType() + "\" DataContentHandler requires String object, " + "was given object of type " + obj.getClass().toString());
/*     */     }
/*     */ 
/* 139 */     String enc = null;
/* 140 */     OutputStreamWriter osw = null;
/*     */     try
/*     */     {
/* 143 */       enc = getCharset(type);
/* 144 */       osw = new OutputStreamWriter(os, enc);
/*     */     }
/*     */     catch (IllegalArgumentException iex)
/*     */     {
/* 154 */       throw new UnsupportedEncodingException(enc);
/*     */     }
/*     */ 
/* 157 */     String s = (String)obj;
/* 158 */     osw.write(s, 0, s.length());
/* 159 */     osw.flush();
/*     */   }
/*     */ 
/*     */   private String getCharset(String type) {
/*     */     try {
/* 164 */       ContentType ct = new ContentType(type);
/* 165 */       String charset = ct.getParameter("charset");
/* 166 */       if (charset == null)
/*     */       {
/* 168 */         charset = "us-ascii";
/* 169 */       }return MimeUtility.javaCharset(charset); } catch (Exception ex) {
/*     */     }
/* 171 */     return null;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.handlers.text_plain
 * JD-Core Version:    0.6.1
 */