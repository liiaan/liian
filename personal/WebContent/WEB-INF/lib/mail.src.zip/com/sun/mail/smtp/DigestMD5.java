/*     */ package com.sun.mail.smtp;
/*     */ 
/*     */ import com.sun.mail.util.ASCIIUtility;
/*     */ import com.sun.mail.util.BASE64DecoderStream;
/*     */ import com.sun.mail.util.BASE64EncoderStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.StreamTokenizer;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Hashtable;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ public class DigestMD5
/*     */ {
/*     */   private PrintStream debugout;
/*     */   private MessageDigest md5;
/*     */   private String uri;
/*     */   private String clientResponse;
/* 209 */   private static char[] digits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
/*     */ 
/*     */   public DigestMD5(PrintStream debugout)
/*     */   {
/*  60 */     this.debugout = debugout;
/*  61 */     if (debugout != null)
/*  62 */       debugout.println("DEBUG DIGEST-MD5: Loaded");
/*     */   }
/*     */ 
/*     */   public byte[] authClient(String host, String user, String passwd, String realm, String serverChallenge)
/*     */     throws IOException
/*     */   {
/*  73 */     ByteArrayOutputStream bos = new ByteArrayOutputStream();
/*  74 */     OutputStream b64os = new BASE64EncoderStream(bos, 2147483647);
/*     */     SecureRandom random;
/*     */     try
/*     */     {
/*  78 */       random = new SecureRandom();
/*  79 */       this.md5 = MessageDigest.getInstance("MD5");
/*     */     } catch (NoSuchAlgorithmException ex) {
/*  81 */       if (this.debugout != null)
/*  82 */         this.debugout.println("DEBUG DIGEST-MD5: " + ex);
/*  83 */       throw new IOException(ex.toString());
/*     */     }
/*  85 */     StringBuffer result = new StringBuffer();
/*     */ 
/*  87 */     this.uri = ("smtp/" + host);
/*  88 */     String nc = "00000001";
/*  89 */     String qop = "auth";
/*  90 */     byte[] bytes = new byte[32];
/*     */ 
/*  93 */     if (this.debugout != null) {
/*  94 */       this.debugout.println("DEBUG DIGEST-MD5: Begin authentication ...");
/*     */     }
/*     */ 
/*  97 */     Hashtable map = tokenize(serverChallenge);
/*     */ 
/*  99 */     if (realm == null) {
/* 100 */       String text = (String)map.get("realm");
/* 101 */       realm = text != null ? new StringTokenizer(text, ",").nextToken() : host;
/*     */     }
/*     */ 
/* 106 */     String nonce = (String)map.get("nonce");
/*     */ 
/* 108 */     random.nextBytes(bytes);
/* 109 */     b64os.write(bytes);
/* 110 */     b64os.flush();
/*     */ 
/* 113 */     String cnonce = bos.toString();
/* 114 */     bos.reset();
/*     */ 
/* 117 */     this.md5.update(this.md5.digest(ASCIIUtility.getBytes(user + ":" + realm + ":" + passwd)));
/*     */ 
/* 119 */     this.md5.update(ASCIIUtility.getBytes(":" + nonce + ":" + cnonce));
/* 120 */     this.clientResponse = (toHex(this.md5.digest()) + ":" + nonce + ":" + nc + ":" + cnonce + ":" + qop + ":");
/*     */ 
/* 124 */     this.md5.update(ASCIIUtility.getBytes("AUTHENTICATE:" + this.uri));
/* 125 */     this.md5.update(ASCIIUtility.getBytes(this.clientResponse + toHex(this.md5.digest())));
/*     */ 
/* 128 */     result.append("username=\"" + user + "\"");
/* 129 */     result.append(",realm=\"" + realm + "\"");
/* 130 */     result.append(",qop=" + qop);
/* 131 */     result.append(",nc=" + nc);
/* 132 */     result.append(",nonce=\"" + nonce + "\"");
/* 133 */     result.append(",cnonce=\"" + cnonce + "\"");
/* 134 */     result.append(",digest-uri=\"" + this.uri + "\"");
/* 135 */     result.append(",response=" + toHex(this.md5.digest()));
/*     */ 
/* 137 */     if (this.debugout != null) {
/* 138 */       this.debugout.println("DEBUG DIGEST-MD5: Response => " + result.toString());
/*     */     }
/* 140 */     b64os.write(ASCIIUtility.getBytes(result.toString()));
/* 141 */     b64os.flush();
/* 142 */     return bos.toByteArray();
/*     */   }
/*     */ 
/*     */   public boolean authServer(String serverResponse)
/*     */     throws IOException
/*     */   {
/* 152 */     Hashtable map = tokenize(serverResponse);
/*     */ 
/* 154 */     this.md5.update(ASCIIUtility.getBytes(":" + this.uri));
/* 155 */     this.md5.update(ASCIIUtility.getBytes(this.clientResponse + toHex(this.md5.digest())));
/* 156 */     String text = toHex(this.md5.digest());
/* 157 */     if (!text.equals((String)map.get("rspauth"))) {
/* 158 */       if (this.debugout != null) {
/* 159 */         this.debugout.println("DEBUG DIGEST-MD5: Expected => rspauth=" + text);
/*     */       }
/* 161 */       return false;
/*     */     }
/* 163 */     return true;
/*     */   }
/*     */ 
/*     */   private Hashtable tokenize(String serverResponse)
/*     */     throws IOException
/*     */   {
/* 172 */     Hashtable map = new Hashtable();
/* 173 */     byte[] bytes = serverResponse.getBytes();
/* 174 */     String key = null;
/*     */ 
/* 176 */     StreamTokenizer tokens = new StreamTokenizer(new InputStreamReader(new BASE64DecoderStream(new ByteArrayInputStream(bytes, 4, bytes.length - 4))));
/*     */ 
/* 183 */     tokens.ordinaryChars(48, 57);
/* 184 */     tokens.wordChars(48, 57);
/*     */     int ttype;
/* 185 */     while ((ttype = tokens.nextToken()) != -1) {
/* 186 */       switch (ttype) {
/*     */       case -3:
/* 188 */         if (key == null)
/* 189 */           key = tokens.sval;
/* 190 */         break;
/*     */       case 34:
/* 194 */         if (this.debugout != null) {
/* 195 */           this.debugout.println("DEBUG DIGEST-MD5: Received => " + key + "='" + tokens.sval + "'");
/*     */         }
/* 197 */         if (map.containsKey(key))
/* 198 */           map.put(key, map.get(key) + "," + tokens.sval);
/*     */         else {
/* 200 */           map.put(key, tokens.sval);
/*     */         }
/* 202 */         key = null;
/*     */       }
/*     */     }
/*     */ 
/* 206 */     return map;
/*     */   }
/*     */ 
/*     */   private static String toHex(byte[] bytes)
/*     */   {
/* 218 */     char[] result = new char[bytes.length * 2];
/*     */ 
/* 220 */     int index = 0; for (int i = 0; index < bytes.length; index++) {
/* 221 */       int temp = bytes[index] & 0xFF;
/* 222 */       result[(i++)] = digits[(temp >> 4)];
/* 223 */       result[(i++)] = digits[(temp & 0xF)];
/*     */     }
/* 225 */     return new String(result);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.smtp.DigestMD5
 * JD-Core Version:    0.6.1
 */