/*     */ package com.sun.mail.imap.protocol;
/*     */ 
/*     */ import com.sun.mail.iap.ParsingException;
/*     */ import com.sun.mail.iap.Protocol;
/*     */ import com.sun.mail.iap.ProtocolException;
/*     */ import com.sun.mail.iap.Response;
/*     */ import java.io.IOException;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class FetchResponse extends IMAPResponse
/*     */ {
/*     */   private Item[] items;
/* 104 */   private static final char[] HEADER = { '.', 'H', 'E', 'A', 'D', 'E', 'R' };
/* 105 */   private static final char[] TEXT = { '.', 'T', 'E', 'X', 'T' };
/*     */ 
/*     */   public FetchResponse(Protocol p)
/*     */     throws IOException, ProtocolException
/*     */   {
/*  56 */     super(p);
/*  57 */     parse();
/*     */   }
/*     */ 
/*     */   public FetchResponse(IMAPResponse r) throws IOException, ProtocolException
/*     */   {
/*  62 */     super(r);
/*  63 */     parse();
/*     */   }
/*     */ 
/*     */   public int getItemCount() {
/*  67 */     return this.items.length;
/*     */   }
/*     */ 
/*     */   public Item getItem(int index) {
/*  71 */     return this.items[index];
/*     */   }
/*     */ 
/*     */   public Item getItem(Class c) {
/*  75 */     for (int i = 0; i < this.items.length; i++) {
/*  76 */       if (c.isInstance(this.items[i])) {
/*  77 */         return this.items[i];
/*     */       }
/*     */     }
/*  80 */     return null;
/*     */   }
/*     */ 
/*     */   public static Item getItem(Response[] r, int msgno, Class c) {
/*  84 */     if (r == null) {
/*  85 */       return null;
/*     */     }
/*  87 */     for (int i = 0; i < r.length; i++)
/*     */     {
/*  89 */       if ((r[i] != null) && ((r[i] instanceof FetchResponse)) && (((FetchResponse)r[i]).getNumber() == msgno))
/*     */       {
/*  94 */         FetchResponse f = (FetchResponse)r[i];
/*  95 */         for (int j = 0; j < f.items.length; j++) {
/*  96 */           if (c.isInstance(f.items[j]))
/*  97 */             return f.items[j];
/*     */         }
/*     */       }
/*     */     }
/* 101 */     return null;
/*     */   }
/*     */ 
/*     */   private void parse()
/*     */     throws ParsingException
/*     */   {
/* 109 */     skipSpaces();
/* 110 */     if (this.buffer[this.index] != 40) {
/* 111 */       throw new ParsingException("error in FETCH parsing, missing '(' at index " + this.index);
/*     */     }
/*     */ 
/* 114 */     Vector v = new Vector();
/* 115 */     Item i = null;
/*     */     do {
/* 117 */       this.index += 1;
/*     */ 
/* 119 */       if (this.index >= this.size) {
/* 120 */         throw new ParsingException("error in FETCH parsing, ran off end of buffer, size " + this.size);
/*     */       }
/*     */ 
/* 123 */       switch (this.buffer[this.index]) {
/*     */       case 69:
/* 125 */         if (match(ENVELOPE.name)) {
/* 126 */           this.index += ENVELOPE.name.length;
/* 127 */           i = new ENVELOPE(this); } break;
/*     */       case 70:
/* 131 */         if (match(FLAGS.name)) {
/* 132 */           this.index += FLAGS.name.length;
/* 133 */           i = new FLAGS(this); } break;
/*     */       case 73:
/* 137 */         if (match(INTERNALDATE.name)) {
/* 138 */           this.index += INTERNALDATE.name.length;
/* 139 */           i = new INTERNALDATE(this); } break;
/*     */       case 66:
/* 143 */         if (match(BODY.name))
/* 144 */           if (this.buffer[(this.index + 4)] == 91) {
/* 145 */             this.index += BODY.name.length;
/* 146 */             i = new BODY(this);
/*     */           }
/*     */           else {
/* 149 */             if (match(BODYSTRUCTURE.name)) {
/* 150 */               this.index += BODYSTRUCTURE.name.length;
/*     */             }
/*     */             else
/* 153 */               this.index += BODY.name.length;
/* 154 */             i = new BODYSTRUCTURE(this); }  break;
/*     */       case 82:
/* 159 */         if (match(RFC822SIZE.name)) {
/* 160 */           this.index += RFC822SIZE.name.length;
/* 161 */           i = new RFC822SIZE(this);
/*     */         }
/* 164 */         else if (match(RFC822DATA.name)) {
/* 165 */           this.index += RFC822DATA.name.length;
/* 166 */           if (match(HEADER))
/* 167 */             this.index += HEADER.length;
/* 168 */           else if (match(TEXT))
/* 169 */             this.index += TEXT.length;
/* 170 */           i = new RFC822DATA(this); } break;
/*     */       case 85:
/* 175 */         if (match(UID.name)) {
/* 176 */           this.index += UID.name.length;
/* 177 */           i = new UID(this); } break;
/*     */       case 67:
/*     */       case 68:
/*     */       case 71:
/*     */       case 72:
/*     */       case 74:
/*     */       case 75:
/*     */       case 76:
/*     */       case 77:
/*     */       case 78:
/*     */       case 79:
/*     */       case 80:
/*     */       case 81:
/*     */       case 83:
/* 182 */       case 84: } if (i != null)
/* 183 */         v.addElement(i); 
/*     */     }
/* 184 */     while (this.buffer[this.index] != 41);
/*     */ 
/* 186 */     this.index += 1;
/* 187 */     this.items = new Item[v.size()];
/* 188 */     v.copyInto(this.items);
/*     */   }
/*     */ 
/*     */   private boolean match(char[] itemName)
/*     */   {
/* 196 */     int len = itemName.length;
/* 197 */     int i = 0; for (int j = this.index; i < len; )
/*     */     {
/* 200 */       if (Character.toUpperCase((char)this.buffer[(j++)]) != itemName[(i++)])
/* 201 */         return false; 
/*     */     }
/* 202 */     return true;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.protocol.FetchResponse
 * JD-Core Version:    0.6.1
 */