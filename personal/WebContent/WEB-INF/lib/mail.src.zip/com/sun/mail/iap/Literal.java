package com.sun.mail.iap;

import java.io.IOException;
import java.io.OutputStream;

public abstract interface Literal
{
  public abstract int size();

  public abstract void writeTo(OutputStream paramOutputStream)
    throws IOException;
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.iap.Literal
 * JD-Core Version:    0.6.1
 */