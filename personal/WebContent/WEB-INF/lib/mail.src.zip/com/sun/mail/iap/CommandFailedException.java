/*    */ package com.sun.mail.iap;
/*    */ 
/*    */ public class CommandFailedException extends ProtocolException
/*    */ {
/*    */   private static final long serialVersionUID = 793932807880443631L;
/*    */ 
/*    */   public CommandFailedException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public CommandFailedException(String s)
/*    */   {
/* 59 */     super(s);
/*    */   }
/*    */ 
/*    */   public CommandFailedException(Response r)
/*    */   {
/* 67 */     super(r);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.iap.CommandFailedException
 * JD-Core Version:    0.6.1
 */