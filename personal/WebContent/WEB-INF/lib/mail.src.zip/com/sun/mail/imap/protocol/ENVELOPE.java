/*     */ package com.sun.mail.imap.protocol;
/*     */ 
/*     */ import com.sun.mail.iap.ParsingException;
/*     */ import com.sun.mail.iap.Response;
/*     */ import java.util.Date;
/*     */ import java.util.Vector;
/*     */ import javax.mail.internet.InternetAddress;
/*     */ import javax.mail.internet.MailDateFormat;
/*     */ 
/*     */ public class ENVELOPE
/*     */   implements Item
/*     */ {
/*  59 */   static final char[] name = { 'E', 'N', 'V', 'E', 'L', 'O', 'P', 'E' };
/*     */   public int msgno;
/*  62 */   public Date date = null;
/*     */   public String subject;
/*     */   public InternetAddress[] from;
/*     */   public InternetAddress[] sender;
/*     */   public InternetAddress[] replyTo;
/*     */   public InternetAddress[] to;
/*     */   public InternetAddress[] cc;
/*     */   public InternetAddress[] bcc;
/*     */   public String inReplyTo;
/*     */   public String messageId;
/*  74 */   private static MailDateFormat mailDateFormat = new MailDateFormat();
/*     */ 
/*     */   public ENVELOPE(FetchResponse r) throws ParsingException {
/*  77 */     this.msgno = r.getNumber();
/*     */ 
/*  79 */     r.skipSpaces();
/*     */ 
/*  81 */     if (r.readByte() != 40) {
/*  82 */       throw new ParsingException("ENVELOPE parse error");
/*     */     }
/*  84 */     String s = r.readString();
/*  85 */     if (s != null) {
/*     */       try {
/*  87 */         this.date = mailDateFormat.parse(s);
/*     */       }
/*     */       catch (Exception pex)
/*     */       {
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  96 */     this.subject = r.readString();
/*  97 */     this.from = parseAddressList(r);
/*  98 */     this.sender = parseAddressList(r);
/*  99 */     this.replyTo = parseAddressList(r);
/* 100 */     this.to = parseAddressList(r);
/* 101 */     this.cc = parseAddressList(r);
/* 102 */     this.bcc = parseAddressList(r);
/* 103 */     this.inReplyTo = r.readString();
/* 104 */     this.messageId = r.readString();
/*     */ 
/* 106 */     if (r.readByte() != 41)
/* 107 */       throw new ParsingException("ENVELOPE parse error");
/*     */   }
/*     */ 
/*     */   private InternetAddress[] parseAddressList(Response r) throws ParsingException
/*     */   {
/* 112 */     r.skipSpaces();
/*     */ 
/* 114 */     byte b = r.readByte();
/* 115 */     if (b == 40) {
/* 116 */       Vector v = new Vector();
/*     */       do
/*     */       {
/* 119 */         IMAPAddress a = new IMAPAddress(r);
/*     */ 
/* 121 */         if (!a.isEndOfGroup())
/* 122 */           v.addElement(a); 
/*     */       }
/* 123 */       while (r.peekByte() != 41);
/*     */ 
/* 126 */       r.skip(1);
/*     */ 
/* 128 */       InternetAddress[] a = new InternetAddress[v.size()];
/* 129 */       v.copyInto(a);
/* 130 */       return a;
/* 131 */     }if ((b == 78) || (b == 110)) {
/* 132 */       r.skip(2);
/* 133 */       return null;
/*     */     }
/* 135 */     throw new ParsingException("ADDRESS parse error");
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.protocol.ENVELOPE
 * JD-Core Version:    0.6.1
 */