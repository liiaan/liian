/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ public class TraceOutputStream extends FilterOutputStream
/*     */ {
/*  51 */   private boolean trace = false;
/*  52 */   private boolean quote = false;
/*     */   private OutputStream traceOut;
/*     */ 
/*     */   public TraceOutputStream(OutputStream out, OutputStream traceOut)
/*     */   {
/*  63 */     super(out);
/*  64 */     this.traceOut = traceOut;
/*     */   }
/*     */ 
/*     */   public void setTrace(boolean trace)
/*     */   {
/*  71 */     this.trace = trace;
/*     */   }
/*     */ 
/*     */   public void setQuote(boolean quote)
/*     */   {
/*  79 */     this.quote = quote;
/*     */   }
/*     */ 
/*     */   public void write(int b)
/*     */     throws IOException
/*     */   {
/*  88 */     if (this.trace) {
/*  89 */       if (this.quote)
/*  90 */         writeByte(b);
/*     */       else
/*  92 */         this.traceOut.write(b);
/*     */     }
/*  94 */     this.out.write(b);
/*     */   }
/*     */ 
/*     */   public void write(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 103 */     if (this.trace) {
/* 104 */       if (this.quote)
/* 105 */         for (int i = 0; i < len; i++)
/* 106 */           writeByte(b[(off + i)]);
/*     */       else
/* 108 */         this.traceOut.write(b, off, len);
/*     */     }
/* 110 */     this.out.write(b, off, len);
/*     */   }
/*     */ 
/*     */   private final void writeByte(int b)
/*     */     throws IOException
/*     */   {
/* 117 */     b &= 255;
/* 118 */     if (b > 127) {
/* 119 */       this.traceOut.write(77);
/* 120 */       this.traceOut.write(45);
/* 121 */       b &= 127;
/*     */     }
/* 123 */     if (b == 13) {
/* 124 */       this.traceOut.write(92);
/* 125 */       this.traceOut.write(114);
/* 126 */     } else if (b == 10) {
/* 127 */       this.traceOut.write(92);
/* 128 */       this.traceOut.write(110);
/* 129 */       this.traceOut.write(10);
/* 130 */     } else if (b == 9) {
/* 131 */       this.traceOut.write(92);
/* 132 */       this.traceOut.write(116);
/* 133 */     } else if (b < 32) {
/* 134 */       this.traceOut.write(94);
/* 135 */       this.traceOut.write(64 + b);
/*     */     } else {
/* 137 */       this.traceOut.write(b);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.util.TraceOutputStream
 * JD-Core Version:    0.6.1
 */