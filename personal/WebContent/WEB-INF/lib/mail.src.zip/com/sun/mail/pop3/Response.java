/*    */ package com.sun.mail.pop3;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ 
/*    */ class Response
/*    */ {
/* 50 */   boolean ok = false;
/* 51 */   String data = null;
/* 52 */   InputStream bytes = null;
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.pop3.Response
 * JD-Core Version:    0.6.1
 */