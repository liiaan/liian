/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ public class CRLFOutputStream extends FilterOutputStream
/*     */ {
/*  49 */   protected int lastb = -1;
/*  50 */   protected boolean atBOL = true;
/*  51 */   private static final byte[] newline = { 13, 10 };
/*     */ 
/*     */   public CRLFOutputStream(OutputStream os) {
/*  54 */     super(os);
/*     */   }
/*     */ 
/*     */   public void write(int b) throws IOException {
/*  58 */     if (b == 13) {
/*  59 */       writeln();
/*  60 */     } else if (b == 10) {
/*  61 */       if (this.lastb != 13)
/*  62 */         writeln();
/*     */     } else {
/*  64 */       this.out.write(b);
/*  65 */       this.atBOL = false;
/*     */     }
/*  67 */     this.lastb = b;
/*     */   }
/*     */ 
/*     */   public void write(byte[] b) throws IOException {
/*  71 */     write(b, 0, b.length);
/*     */   }
/*     */ 
/*     */   public void write(byte[] b, int off, int len) throws IOException {
/*  75 */     int start = off;
/*     */ 
/*  77 */     len += off;
/*  78 */     for (int i = start; i < len; i++) {
/*  79 */       if (b[i] == 13) {
/*  80 */         this.out.write(b, start, i - start);
/*  81 */         writeln();
/*  82 */         start = i + 1;
/*  83 */       } else if (b[i] == 10) {
/*  84 */         if (this.lastb != 13) {
/*  85 */           this.out.write(b, start, i - start);
/*  86 */           writeln();
/*     */         }
/*  88 */         start = i + 1;
/*     */       }
/*  90 */       this.lastb = b[i];
/*     */     }
/*  92 */     if (len - start > 0) {
/*  93 */       this.out.write(b, start, len - start);
/*  94 */       this.atBOL = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void writeln()
/*     */     throws IOException
/*     */   {
/* 102 */     this.out.write(newline);
/* 103 */     this.atBOL = true;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.util.CRLFOutputStream
 * JD-Core Version:    0.6.1
 */