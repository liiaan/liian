/*      */ package com.sun.mail.imap;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ 
/*      */ class LengthCounter extends OutputStream
/*      */ {
/* 2762 */   private int size = 0;
/*      */   private byte[] buf;
/*      */   private int maxsize;
/*      */ 
/*      */   public LengthCounter(int maxsize)
/*      */   {
/* 2767 */     this.buf = new byte[8192];
/* 2768 */     this.maxsize = maxsize;
/*      */   }
/*      */ 
/*      */   public void write(int b) {
/* 2772 */     int newsize = this.size + 1;
/* 2773 */     if (this.buf != null) {
/* 2774 */       if ((newsize > this.maxsize) && (this.maxsize >= 0)) {
/* 2775 */         this.buf = null;
/* 2776 */       } else if (newsize > this.buf.length) {
/* 2777 */         byte[] newbuf = new byte[Math.max(this.buf.length << 1, newsize)];
/* 2778 */         System.arraycopy(this.buf, 0, newbuf, 0, this.size);
/* 2779 */         this.buf = newbuf;
/* 2780 */         this.buf[this.size] = (byte)b;
/*      */       } else {
/* 2782 */         this.buf[this.size] = (byte)b;
/*      */       }
/*      */     }
/* 2785 */     this.size = newsize;
/*      */   }
/*      */ 
/*      */   public void write(byte[] b, int off, int len) {
/* 2789 */     if ((off < 0) || (off > b.length) || (len < 0) || (off + len > b.length) || (off + len < 0))
/*      */     {
/* 2791 */       throw new IndexOutOfBoundsException();
/* 2792 */     }if (len == 0) {
/* 2793 */       return;
/*      */     }
/* 2795 */     int newsize = this.size + len;
/* 2796 */     if (this.buf != null) {
/* 2797 */       if ((newsize > this.maxsize) && (this.maxsize >= 0)) {
/* 2798 */         this.buf = null;
/* 2799 */       } else if (newsize > this.buf.length) {
/* 2800 */         byte[] newbuf = new byte[Math.max(this.buf.length << 1, newsize)];
/* 2801 */         System.arraycopy(this.buf, 0, newbuf, 0, this.size);
/* 2802 */         this.buf = newbuf;
/* 2803 */         System.arraycopy(b, off, this.buf, this.size, len);
/*      */       } else {
/* 2805 */         System.arraycopy(b, off, this.buf, this.size, len);
/*      */       }
/*      */     }
/* 2808 */     this.size = newsize;
/*      */   }
/*      */ 
/*      */   public void write(byte[] b) throws IOException {
/* 2812 */     write(b, 0, b.length);
/*      */   }
/*      */ 
/*      */   public int getSize() {
/* 2816 */     return this.size;
/*      */   }
/*      */ 
/*      */   public byte[] getBytes() {
/* 2820 */     return this.buf;
/*      */   }
/*      */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.LengthCounter
 * JD-Core Version:    0.6.1
 */