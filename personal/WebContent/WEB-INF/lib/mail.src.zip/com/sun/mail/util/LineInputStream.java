/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PushbackInputStream;
/*     */ 
/*     */ public class LineInputStream extends FilterInputStream
/*     */ {
/*  56 */   private char[] lineBuffer = null;
/*     */ 
/*     */   public LineInputStream(InputStream in) {
/*  59 */     super(in);
/*     */   }
/*     */ 
/*     */   public String readLine()
/*     */     throws IOException
/*     */   {
/*  74 */     InputStream in = this.in;
/*  75 */     char[] buf = this.lineBuffer;
/*     */ 
/*  77 */     if (buf == null) {
/*  78 */       buf = this.lineBuffer = new char[''];
/*     */     }
/*     */ 
/*  81 */     int room = buf.length;
/*  82 */     int offset = 0;
/*     */     int c1;
/*  84 */     while (((c1 = in.read()) != -1) && 
/*  85 */       (c1 != 10))
/*     */     {
/*  87 */       if (c1 == 13)
/*     */       {
/*  89 */         int c2 = in.read();
/*  90 */         if (c2 == 13)
/*  91 */           c2 = in.read();
/*  92 */         if (c2 == 10)
/*     */           break;
/*  94 */         if (!(in instanceof PushbackInputStream))
/*  95 */           in = this.in = new PushbackInputStream(in);
/*  96 */         ((PushbackInputStream)in).unread(c2); break;
/*     */       }
/*     */ 
/* 103 */       room--; if (room < 0) {
/* 104 */         buf = new char[offset + 128];
/* 105 */         room = buf.length - offset - 1;
/* 106 */         System.arraycopy(this.lineBuffer, 0, buf, 0, offset);
/* 107 */         this.lineBuffer = buf;
/*     */       }
/* 109 */       buf[(offset++)] = (char)c1;
/*     */     }
/*     */ 
/* 112 */     if ((c1 == -1) && (offset == 0)) {
/* 113 */       return null;
/*     */     }
/* 115 */     return String.copyValueOf(buf, 0, offset);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.util.LineInputStream
 * JD-Core Version:    0.6.1
 */