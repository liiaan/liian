/*    */ package com.sun.mail.iap;
/*    */ 
/*    */ public class BadCommandException extends ProtocolException
/*    */ {
/*    */   private static final long serialVersionUID = 5769722539397237515L;
/*    */ 
/*    */   public BadCommandException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public BadCommandException(String s)
/*    */   {
/* 59 */     super(s);
/*    */   }
/*    */ 
/*    */   public BadCommandException(Response r)
/*    */   {
/* 67 */     super(r);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.iap.BadCommandException
 * JD-Core Version:    0.6.1
 */