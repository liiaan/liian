/*    */ package com.sun.mail.iap;
/*    */ 
/*    */ public class ConnectionException extends ProtocolException
/*    */ {
/*    */   private transient Protocol p;
/*    */   private static final long serialVersionUID = 5749739604257464727L;
/*    */ 
/*    */   public ConnectionException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ConnectionException(String s)
/*    */   {
/* 60 */     super(s);
/*    */   }
/*    */ 
/*    */   public ConnectionException(Protocol p, Response r)
/*    */   {
/* 68 */     super(r);
/* 69 */     this.p = p;
/*    */   }
/*    */ 
/*    */   public Protocol getProtocol() {
/* 73 */     return this.p;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.iap.ConnectionException
 * JD-Core Version:    0.6.1
 */