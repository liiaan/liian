/*    */ package com.sun.mail.imap;
/*    */ 
/*    */ public class AppendUID
/*    */ {
/* 50 */   public long uidvalidity = -1L;
/* 51 */   public long uid = -1L;
/*    */ 
/*    */   public AppendUID(long uidvalidity, long uid) {
/* 54 */     this.uidvalidity = uidvalidity;
/* 55 */     this.uid = uid;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.AppendUID
 * JD-Core Version:    0.6.1
 */