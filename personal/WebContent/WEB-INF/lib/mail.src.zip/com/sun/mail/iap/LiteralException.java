/*    */ package com.sun.mail.iap;
/*    */ 
/*    */ public class LiteralException extends ProtocolException
/*    */ {
/*    */   private static final long serialVersionUID = -6919179828339609913L;
/*    */ 
/*    */   public LiteralException(Response r)
/*    */   {
/* 51 */     super(r.toString());
/* 52 */     this.response = r;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.iap.LiteralException
 * JD-Core Version:    0.6.1
 */