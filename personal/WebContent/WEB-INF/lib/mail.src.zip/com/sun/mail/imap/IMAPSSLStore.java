/*    */ package com.sun.mail.imap;
/*    */ 
/*    */ import javax.mail.Session;
/*    */ import javax.mail.URLName;
/*    */ 
/*    */ public class IMAPSSLStore extends IMAPStore
/*    */ {
/*    */   public IMAPSSLStore(Session session, URLName url)
/*    */   {
/* 52 */     super(session, url, "imaps", true);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.IMAPSSLStore
 * JD-Core Version:    0.6.1
 */