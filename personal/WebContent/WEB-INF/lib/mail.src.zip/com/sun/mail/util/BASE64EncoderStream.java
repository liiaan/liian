/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ public class BASE64EncoderStream extends FilterOutputStream
/*     */ {
/*     */   private byte[] buffer;
/*  53 */   private int bufsize = 0;
/*     */   private byte[] outbuf;
/*  55 */   private int count = 0;
/*     */   private int bytesPerLine;
/*     */   private int lineLimit;
/*  58 */   private boolean noCRLF = false;
/*     */ 
/*  60 */   private static byte[] newline = { 13, 10 };
/*     */ 
/* 206 */   private static final char[] pem_array = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/' };
/*     */ 
/*     */   public BASE64EncoderStream(OutputStream out, int bytesPerLine)
/*     */   {
/*  73 */     super(out);
/*  74 */     this.buffer = new byte[3];
/*  75 */     if ((bytesPerLine == 2147483647) || (bytesPerLine < 4)) {
/*  76 */       this.noCRLF = true;
/*  77 */       bytesPerLine = 76;
/*     */     }
/*  79 */     bytesPerLine = bytesPerLine / 4 * 4;
/*  80 */     this.bytesPerLine = bytesPerLine;
/*  81 */     this.lineLimit = (bytesPerLine / 4 * 3);
/*     */ 
/*  83 */     if (this.noCRLF) {
/*  84 */       this.outbuf = new byte[bytesPerLine];
/*     */     } else {
/*  86 */       this.outbuf = new byte[bytesPerLine + 2];
/*  87 */       this.outbuf[bytesPerLine] = 13;
/*  88 */       this.outbuf[(bytesPerLine + 1)] = 10;
/*     */     }
/*     */   }
/*     */ 
/*     */   public BASE64EncoderStream(OutputStream out)
/*     */   {
/*  99 */     this(out, 76);
/*     */   }
/*     */ 
/*     */   public synchronized void write(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 114 */     int end = off + len;
/*     */ 
/* 117 */     while ((this.bufsize != 0) && (off < end)) {
/* 118 */       write(b[(off++)]);
/*     */     }
/*     */ 
/* 121 */     int blen = (this.bytesPerLine - this.count) / 4 * 3;
/* 122 */     if (off + blen < end)
/*     */     {
/* 124 */       int outlen = encodedSize(blen);
/* 125 */       if (!this.noCRLF) {
/* 126 */         this.outbuf[(outlen++)] = 13;
/* 127 */         this.outbuf[(outlen++)] = 10;
/*     */       }
/* 129 */       this.out.write(encode(b, off, blen, this.outbuf), 0, outlen);
/* 130 */       off += blen;
/* 131 */       this.count = 0;
/*     */     }
/*     */ 
/* 135 */     for (; off + this.lineLimit <= end; off += this.lineLimit) {
/* 136 */       this.out.write(encode(b, off, this.lineLimit, this.outbuf));
/*     */     }
/*     */ 
/* 139 */     if (off + 3 < end) {
/* 140 */       blen = end - off;
/* 141 */       blen = blen / 3 * 3;
/*     */ 
/* 143 */       int outlen = encodedSize(blen);
/* 144 */       this.out.write(encode(b, off, blen, this.outbuf), 0, outlen);
/* 145 */       off += blen;
/* 146 */       this.count += outlen;
/*     */     }
/*     */ 
/* 150 */     for (; off < end; off++)
/* 151 */       write(b[off]);
/*     */   }
/*     */ 
/*     */   public void write(byte[] b)
/*     */     throws IOException
/*     */   {
/* 161 */     write(b, 0, b.length);
/*     */   }
/*     */ 
/*     */   public synchronized void write(int c)
/*     */     throws IOException
/*     */   {
/* 171 */     this.buffer[(this.bufsize++)] = (byte)c;
/* 172 */     if (this.bufsize == 3) {
/* 173 */       encode();
/* 174 */       this.bufsize = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void flush()
/*     */     throws IOException
/*     */   {
/* 185 */     if (this.bufsize > 0) {
/* 186 */       encode();
/* 187 */       this.bufsize = 0;
/*     */     }
/* 189 */     this.out.flush();
/*     */   }
/*     */ 
/*     */   public synchronized void close()
/*     */     throws IOException
/*     */   {
/* 197 */     flush();
/* 198 */     if ((this.count > 0) && (!this.noCRLF)) {
/* 199 */       this.out.write(newline);
/* 200 */       this.out.flush();
/*     */     }
/* 202 */     this.out.close();
/*     */   }
/*     */ 
/*     */   private void encode()
/*     */     throws IOException
/*     */   {
/* 225 */     int osize = encodedSize(this.bufsize);
/* 226 */     this.out.write(encode(this.buffer, 0, this.bufsize, this.outbuf), 0, osize);
/*     */ 
/* 228 */     this.count += osize;
/*     */ 
/* 231 */     if (this.count >= this.bytesPerLine) {
/* 232 */       if (!this.noCRLF)
/* 233 */         this.out.write(newline);
/* 234 */       this.count = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static byte[] encode(byte[] inbuf)
/*     */   {
/* 245 */     if (inbuf.length == 0)
/* 246 */       return inbuf;
/* 247 */     return encode(inbuf, 0, inbuf.length, null);
/*     */   }
/*     */ 
/*     */   private static byte[] encode(byte[] inbuf, int off, int size, byte[] outbuf)
/*     */   {
/* 257 */     if (outbuf == null) {
/* 258 */       outbuf = new byte[encodedSize(size)];
/*     */     }
/*     */ 
/* 261 */     int inpos = off; for (int outpos = 0; size >= 3; outpos += 4) {
/* 262 */       int val = inbuf[(inpos++)] & 0xFF;
/* 263 */       val <<= 8;
/* 264 */       val |= inbuf[(inpos++)] & 0xFF;
/* 265 */       val <<= 8;
/* 266 */       val |= inbuf[(inpos++)] & 0xFF;
/* 267 */       outbuf[(outpos + 3)] = (byte)pem_array[(val & 0x3F)];
/* 268 */       val >>= 6;
/* 269 */       outbuf[(outpos + 2)] = (byte)pem_array[(val & 0x3F)];
/* 270 */       val >>= 6;
/* 271 */       outbuf[(outpos + 1)] = (byte)pem_array[(val & 0x3F)];
/* 272 */       val >>= 6;
/* 273 */       outbuf[(outpos + 0)] = (byte)pem_array[(val & 0x3F)];
/*     */ 
/* 261 */       size -= 3;
/*     */     }
/*     */ 
/* 276 */     if (size == 1) {
/* 277 */       int val = inbuf[(inpos++)] & 0xFF;
/* 278 */       val <<= 4;
/* 279 */       outbuf[(outpos + 3)] = 61;
/* 280 */       outbuf[(outpos + 2)] = 61;
/* 281 */       outbuf[(outpos + 1)] = (byte)pem_array[(val & 0x3F)];
/* 282 */       val >>= 6;
/* 283 */       outbuf[(outpos + 0)] = (byte)pem_array[(val & 0x3F)];
/* 284 */     } else if (size == 2) {
/* 285 */       int val = inbuf[(inpos++)] & 0xFF;
/* 286 */       val <<= 8;
/* 287 */       val |= inbuf[(inpos++)] & 0xFF;
/* 288 */       val <<= 2;
/* 289 */       outbuf[(outpos + 3)] = 61;
/* 290 */       outbuf[(outpos + 2)] = (byte)pem_array[(val & 0x3F)];
/* 291 */       val >>= 6;
/* 292 */       outbuf[(outpos + 1)] = (byte)pem_array[(val & 0x3F)];
/* 293 */       val >>= 6;
/* 294 */       outbuf[(outpos + 0)] = (byte)pem_array[(val & 0x3F)];
/*     */     }
/* 296 */     return outbuf;
/*     */   }
/*     */ 
/*     */   private static int encodedSize(int size)
/*     */   {
/* 304 */     return (size + 2) / 3 * 4;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.util.BASE64EncoderStream
 * JD-Core Version:    0.6.1
 */