/*    */ package com.sun.mail.imap.protocol;
/*    */ 
/*    */ import com.sun.mail.iap.ParsingException;
/*    */ import javax.mail.Flags;
/*    */ import javax.mail.Flags.Flag;
/*    */ 
/*    */ public class FLAGS extends Flags
/*    */   implements Item
/*    */ {
/* 51 */   static final char[] name = { 'F', 'L', 'A', 'G', 'S' };
/*    */   public int msgno;
/*    */   private static final long serialVersionUID = 439049847053756670L;
/*    */ 
/*    */   public FLAGS(IMAPResponse r)
/*    */     throws ParsingException
/*    */   {
/* 60 */     this.msgno = r.getNumber();
/*    */ 
/* 62 */     r.skipSpaces();
/* 63 */     String[] flags = r.readSimpleList();
/* 64 */     if (flags != null)
/* 65 */       for (int i = 0; i < flags.length; i++) {
/* 66 */         String s = flags[i];
/* 67 */         if ((s.length() >= 2) && (s.charAt(0) == '\\'));
/* 68 */         switch (Character.toUpperCase(s.charAt(1))) {
/*    */         case 'S':
/* 70 */           add(Flags.Flag.SEEN);
/* 71 */           break;
/*    */         case 'R':
/* 73 */           add(Flags.Flag.RECENT);
/* 74 */           break;
/*    */         case 'D':
/* 76 */           if (s.length() >= 3) {
/* 77 */             char c = s.charAt(2);
/* 78 */             if ((c == 'e') || (c == 'E'))
/* 79 */               add(Flags.Flag.DELETED);
/* 80 */             else if ((c == 'r') || (c == 'R'))
/* 81 */               add(Flags.Flag.DRAFT);
/*    */           } else {
/* 83 */             add(s);
/* 84 */           }break;
/*    */         case 'A':
/* 86 */           add(Flags.Flag.ANSWERED);
/* 87 */           break;
/*    */         case 'F':
/* 89 */           add(Flags.Flag.FLAGGED);
/* 90 */           break;
/*    */         case '*':
/* 92 */           add(Flags.Flag.USER);
/* 93 */           break;
/*    */         default:
/* 95 */           add(s);
/* 96 */           continue;
/*    */ 
/* 99 */           add(s);
/*    */         }
/*    */       }
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.protocol.FLAGS
 * JD-Core Version:    0.6.1
 */