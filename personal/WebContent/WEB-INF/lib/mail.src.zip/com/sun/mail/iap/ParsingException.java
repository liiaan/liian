/*    */ package com.sun.mail.iap;
/*    */ 
/*    */ public class ParsingException extends ProtocolException
/*    */ {
/*    */   private static final long serialVersionUID = 7756119840142724839L;
/*    */ 
/*    */   public ParsingException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ParsingException(String s)
/*    */   {
/* 59 */     super(s);
/*    */   }
/*    */ 
/*    */   public ParsingException(Response r)
/*    */   {
/* 67 */     super(r);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.iap.ParsingException
 * JD-Core Version:    0.6.1
 */