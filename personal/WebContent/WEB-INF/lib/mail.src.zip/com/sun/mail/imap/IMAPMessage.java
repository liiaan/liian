/*      */ package com.sun.mail.imap;
/*      */ 
/*      */ import com.sun.mail.iap.CommandFailedException;
/*      */ import com.sun.mail.iap.ConnectionException;
/*      */ import com.sun.mail.iap.ProtocolException;
/*      */ import com.sun.mail.iap.Response;
/*      */ import com.sun.mail.imap.protocol.BODY;
/*      */ import com.sun.mail.imap.protocol.BODYSTRUCTURE;
/*      */ import com.sun.mail.imap.protocol.ENVELOPE;
/*      */ import com.sun.mail.imap.protocol.FetchResponse;
/*      */ import com.sun.mail.imap.protocol.IMAPProtocol;
/*      */ import com.sun.mail.imap.protocol.INTERNALDATE;
/*      */ import com.sun.mail.imap.protocol.Item;
/*      */ import com.sun.mail.imap.protocol.MessageSet;
/*      */ import com.sun.mail.imap.protocol.RFC822DATA;
/*      */ import com.sun.mail.imap.protocol.RFC822SIZE;
/*      */ import com.sun.mail.imap.protocol.UID;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Locale;
/*      */ import java.util.Vector;
/*      */ import javax.activation.DataHandler;
/*      */ import javax.mail.Address;
/*      */ import javax.mail.FetchProfile;
/*      */ import javax.mail.FetchProfile.Item;
/*      */ import javax.mail.Flags;
/*      */ import javax.mail.Flags.Flag;
/*      */ import javax.mail.Folder;
/*      */ import javax.mail.FolderClosedException;
/*      */ import javax.mail.Header;
/*      */ import javax.mail.IllegalWriteException;
/*      */ import javax.mail.Message;
/*      */ import javax.mail.Message.RecipientType;
/*      */ import javax.mail.MessageRemovedException;
/*      */ import javax.mail.MessagingException;
/*      */ import javax.mail.Session;
/*      */ import javax.mail.UIDFolder.FetchProfileItem;
/*      */ import javax.mail.internet.ContentType;
/*      */ import javax.mail.internet.InternetAddress;
/*      */ import javax.mail.internet.InternetHeaders;
/*      */ import javax.mail.internet.MimeMessage;
/*      */ import javax.mail.internet.MimeUtility;
/*      */ import javax.mail.internet.ParameterList;
/*      */ 
/*      */ public class IMAPMessage extends MimeMessage
/*      */ {
/*      */   protected BODYSTRUCTURE bs;
/*      */   protected ENVELOPE envelope;
/*      */   private Date receivedDate;
/*   82 */   private int size = -1;
/*      */   private boolean peek;
/*   87 */   private long uid = -1L;
/*      */   protected String sectionId;
/*      */   private String type;
/*      */   private String subject;
/*      */   private String description;
/*   99 */   private boolean headersLoaded = false;
/*      */   private Hashtable loadedHeaders;
/*  112 */   private static String EnvelopeCmd = "ENVELOPE INTERNALDATE RFC822.SIZE";
/*      */ 
/*      */   protected IMAPMessage(IMAPFolder folder, int msgnum)
/*      */   {
/*  118 */     super(folder, msgnum);
/*  119 */     this.flags = null;
/*      */   }
/*      */ 
/*      */   protected IMAPMessage(Session session)
/*      */   {
/*  126 */     super(session);
/*      */   }
/*      */ 
/*      */   protected IMAPProtocol getProtocol()
/*      */     throws ProtocolException, FolderClosedException
/*      */   {
/*  138 */     ((IMAPFolder)this.folder).waitIfIdle();
/*  139 */     IMAPProtocol p = ((IMAPFolder)this.folder).protocol;
/*  140 */     if (p == null) {
/*  141 */       throw new FolderClosedException(this.folder);
/*      */     }
/*  143 */     return p;
/*      */   }
/*      */ 
/*      */   protected boolean isREV1()
/*      */     throws FolderClosedException
/*      */   {
/*  152 */     IMAPProtocol p = ((IMAPFolder)this.folder).protocol;
/*  153 */     if (p == null) {
/*  154 */       throw new FolderClosedException(this.folder);
/*      */     }
/*  156 */     return p.isREV1();
/*      */   }
/*      */ 
/*      */   protected Object getMessageCacheLock()
/*      */   {
/*  164 */     return ((IMAPFolder)this.folder).messageCacheLock;
/*      */   }
/*      */ 
/*      */   protected int getSequenceNumber()
/*      */   {
/*  174 */     return ((IMAPFolder)this.folder).messageCache.seqnumOf(getMessageNumber());
/*      */   }
/*      */ 
/*      */   protected void setMessageNumber(int msgnum)
/*      */   {
/*  182 */     super.setMessageNumber(msgnum);
/*      */   }
/*      */ 
/*      */   protected long getUID() {
/*  186 */     return this.uid;
/*      */   }
/*      */ 
/*      */   protected void setUID(long uid) {
/*  190 */     this.uid = uid;
/*      */   }
/*      */ 
/*      */   protected void setExpunged(boolean set)
/*      */   {
/*  195 */     super.setExpunged(set);
/*      */   }
/*      */ 
/*      */   protected void checkExpunged() throws MessageRemovedException
/*      */   {
/*  200 */     if (this.expunged)
/*  201 */       throw new MessageRemovedException();
/*      */   }
/*      */ 
/*      */   protected void forceCheckExpunged()
/*      */     throws MessageRemovedException, FolderClosedException
/*      */   {
/*  210 */     synchronized (getMessageCacheLock()) {
/*      */       try {
/*  212 */         getProtocol().noop();
/*      */       } catch (ConnectionException cex) {
/*  214 */         throw new FolderClosedException(this.folder, cex.getMessage());
/*      */       }
/*      */       catch (ProtocolException pex) {
/*      */       }
/*      */     }
/*  219 */     if (this.expunged)
/*  220 */       throw new MessageRemovedException();
/*      */   }
/*      */ 
/*      */   protected int getFetchBlockSize()
/*      */   {
/*  225 */     return ((IMAPStore)this.folder.getStore()).getFetchBlockSize();
/*      */   }
/*      */ 
/*      */   public Address[] getFrom()
/*      */     throws MessagingException
/*      */   {
/*  232 */     checkExpunged();
/*  233 */     loadEnvelope();
/*  234 */     return aaclone(this.envelope.from);
/*      */   }
/*      */ 
/*      */   public void setFrom(Address address) throws MessagingException {
/*  238 */     throw new IllegalWriteException("IMAPMessage is read-only");
/*      */   }
/*      */ 
/*      */   public void addFrom(Address[] addresses) throws MessagingException {
/*  242 */     throw new IllegalWriteException("IMAPMessage is read-only");
/*      */   }
/*      */ 
/*      */   public Address getSender()
/*      */     throws MessagingException
/*      */   {
/*  249 */     checkExpunged();
/*  250 */     loadEnvelope();
/*  251 */     if (this.envelope.sender != null) {
/*  252 */       return this.envelope.sender[0];
/*      */     }
/*  254 */     return null;
/*      */   }
/*      */ 
/*      */   public void setSender(Address address) throws MessagingException
/*      */   {
/*  259 */     throw new IllegalWriteException("IMAPMessage is read-only");
/*      */   }
/*      */ 
/*      */   public Address[] getRecipients(Message.RecipientType type)
/*      */     throws MessagingException
/*      */   {
/*  267 */     checkExpunged();
/*  268 */     loadEnvelope();
/*      */ 
/*  270 */     if (type == Message.RecipientType.TO)
/*  271 */       return aaclone(this.envelope.to);
/*  272 */     if (type == Message.RecipientType.CC)
/*  273 */       return aaclone(this.envelope.cc);
/*  274 */     if (type == Message.RecipientType.BCC) {
/*  275 */       return aaclone(this.envelope.bcc);
/*      */     }
/*  277 */     return super.getRecipients(type);
/*      */   }
/*      */ 
/*      */   public void setRecipients(Message.RecipientType type, Address[] addresses) throws MessagingException
/*      */   {
/*  282 */     throw new IllegalWriteException("IMAPMessage is read-only");
/*      */   }
/*      */ 
/*      */   public void addRecipients(Message.RecipientType type, Address[] addresses) throws MessagingException
/*      */   {
/*  287 */     throw new IllegalWriteException("IMAPMessage is read-only");
/*      */   }
/*      */ 
/*      */   public Address[] getReplyTo()
/*      */     throws MessagingException
/*      */   {
/*  294 */     checkExpunged();
/*  295 */     loadEnvelope();
/*  296 */     return aaclone(this.envelope.replyTo);
/*      */   }
/*      */ 
/*      */   public void setReplyTo(Address[] addresses) throws MessagingException {
/*  300 */     throw new IllegalWriteException("IMAPMessage is read-only");
/*      */   }
/*      */ 
/*      */   public String getSubject()
/*      */     throws MessagingException
/*      */   {
/*  307 */     checkExpunged();
/*      */ 
/*  309 */     if (this.subject != null) {
/*  310 */       return this.subject;
/*      */     }
/*  312 */     loadEnvelope();
/*  313 */     if (this.envelope.subject == null) {
/*  314 */       return null;
/*      */     }
/*      */     try
/*      */     {
/*  318 */       this.subject = MimeUtility.decodeText(this.envelope.subject);
/*      */     } catch (UnsupportedEncodingException ex) {
/*  320 */       this.subject = this.envelope.subject;
/*      */     }
/*      */ 
/*  323 */     return this.subject;
/*      */   }
/*      */ 
/*      */   public void setSubject(String subject, String charset) throws MessagingException
/*      */   {
/*  328 */     throw new IllegalWriteException("IMAPMessage is read-only");
/*      */   }
/*      */ 
/*      */   public Date getSentDate()
/*      */     throws MessagingException
/*      */   {
/*  335 */     checkExpunged();
/*  336 */     loadEnvelope();
/*  337 */     if (this.envelope.date == null) {
/*  338 */       return null;
/*      */     }
/*  340 */     return new Date(this.envelope.date.getTime());
/*      */   }
/*      */ 
/*      */   public void setSentDate(Date d) throws MessagingException {
/*  344 */     throw new IllegalWriteException("IMAPMessage is read-only");
/*      */   }
/*      */ 
/*      */   public Date getReceivedDate()
/*      */     throws MessagingException
/*      */   {
/*  351 */     checkExpunged();
/*  352 */     loadEnvelope();
/*  353 */     if (this.receivedDate == null) {
/*  354 */       return null;
/*      */     }
/*  356 */     return new Date(this.receivedDate.getTime());
/*      */   }
/*      */ 
/*      */   public int getSize()
/*      */     throws MessagingException
/*      */   {
/*  366 */     checkExpunged();
/*  367 */     if (this.size == -1)
/*  368 */       loadEnvelope();
/*  369 */     return this.size;
/*      */   }
/*      */ 
/*      */   public int getLineCount()
/*      */     throws MessagingException
/*      */   {
/*  380 */     checkExpunged();
/*  381 */     loadBODYSTRUCTURE();
/*  382 */     return this.bs.lines;
/*      */   }
/*      */ 
/*      */   public String[] getContentLanguage()
/*      */     throws MessagingException
/*      */   {
/*  389 */     checkExpunged();
/*  390 */     loadBODYSTRUCTURE();
/*  391 */     if (this.bs.language != null) {
/*  392 */       return (String[])this.bs.language.clone();
/*      */     }
/*  394 */     return null;
/*      */   }
/*      */ 
/*      */   public void setContentLanguage(String[] languages) throws MessagingException
/*      */   {
/*  399 */     throw new IllegalWriteException("IMAPMessage is read-only");
/*      */   }
/*      */ 
/*      */   public String getInReplyTo()
/*      */     throws MessagingException
/*      */   {
/*  408 */     checkExpunged();
/*  409 */     loadEnvelope();
/*  410 */     return this.envelope.inReplyTo;
/*      */   }
/*      */ 
/*      */   public String getContentType()
/*      */     throws MessagingException
/*      */   {
/*  420 */     checkExpunged();
/*      */ 
/*  423 */     if (this.type == null) {
/*  424 */       loadBODYSTRUCTURE();
/*      */ 
/*  426 */       ContentType ct = new ContentType(this.bs.type, this.bs.subtype, this.bs.cParams);
/*  427 */       this.type = ct.toString();
/*      */     }
/*  429 */     return this.type;
/*      */   }
/*      */ 
/*      */   public String getDisposition()
/*      */     throws MessagingException
/*      */   {
/*  436 */     checkExpunged();
/*  437 */     loadBODYSTRUCTURE();
/*  438 */     return this.bs.disposition;
/*      */   }
/*      */ 
/*      */   public void setDisposition(String disposition) throws MessagingException {
/*  442 */     throw new IllegalWriteException("IMAPMessage is read-only");
/*      */   }
/*      */ 
/*      */   public String getEncoding()
/*      */     throws MessagingException
/*      */   {
/*  449 */     checkExpunged();
/*  450 */     loadBODYSTRUCTURE();
/*  451 */     return this.bs.encoding;
/*      */   }
/*      */ 
/*      */   public String getContentID()
/*      */     throws MessagingException
/*      */   {
/*  458 */     checkExpunged();
/*  459 */     loadBODYSTRUCTURE();
/*  460 */     return this.bs.id;
/*      */   }
/*      */ 
/*      */   public void setContentID(String cid) throws MessagingException {
/*  464 */     throw new IllegalWriteException("IMAPMessage is read-only");
/*      */   }
/*      */ 
/*      */   public String getContentMD5()
/*      */     throws MessagingException
/*      */   {
/*  471 */     checkExpunged();
/*  472 */     loadBODYSTRUCTURE();
/*  473 */     return this.bs.md5;
/*      */   }
/*      */ 
/*      */   public void setContentMD5(String md5) throws MessagingException {
/*  477 */     throw new IllegalWriteException("IMAPMessage is read-only");
/*      */   }
/*      */ 
/*      */   public String getDescription()
/*      */     throws MessagingException
/*      */   {
/*  484 */     checkExpunged();
/*      */ 
/*  486 */     if (this.description != null) {
/*  487 */       return this.description;
/*      */     }
/*  489 */     loadBODYSTRUCTURE();
/*  490 */     if (this.bs.description == null)
/*  491 */       return null;
/*      */     try
/*      */     {
/*  494 */       this.description = MimeUtility.decodeText(this.bs.description);
/*      */     } catch (UnsupportedEncodingException ex) {
/*  496 */       this.description = this.bs.description;
/*      */     }
/*      */ 
/*  499 */     return this.description;
/*      */   }
/*      */ 
/*      */   public void setDescription(String description, String charset) throws MessagingException
/*      */   {
/*  504 */     throw new IllegalWriteException("IMAPMessage is read-only");
/*      */   }
/*      */ 
/*      */   public String getMessageID()
/*      */     throws MessagingException
/*      */   {
/*  511 */     checkExpunged();
/*  512 */     loadEnvelope();
/*  513 */     return this.envelope.messageId;
/*      */   }
/*      */ 
/*      */   public String getFileName()
/*      */     throws MessagingException
/*      */   {
/*  522 */     checkExpunged();
/*      */ 
/*  524 */     String filename = null;
/*  525 */     loadBODYSTRUCTURE();
/*      */ 
/*  527 */     if (this.bs.dParams != null)
/*  528 */       filename = this.bs.dParams.get("filename");
/*  529 */     if ((filename == null) && (this.bs.cParams != null))
/*  530 */       filename = this.bs.cParams.get("name");
/*  531 */     return filename;
/*      */   }
/*      */ 
/*      */   public void setFileName(String filename) throws MessagingException {
/*  535 */     throw new IllegalWriteException("IMAPMessage is read-only");
/*      */   }
/*      */ 
/*      */   protected InputStream getContentStream()
/*      */     throws MessagingException
/*      */   {
/*  546 */     InputStream is = null;
/*  547 */     boolean pk = getPeek();
/*      */ 
/*  550 */     synchronized (getMessageCacheLock()) {
/*      */       try {
/*  552 */         IMAPProtocol p = getProtocol();
/*      */ 
/*  556 */         checkExpunged();
/*      */ 
/*  558 */         if ((p.isREV1()) && (getFetchBlockSize() != -1)) {
/*  559 */           return new IMAPInputStream(this, toSection("TEXT"), this.bs != null ? this.bs.size : -1, pk);
/*      */         }
/*      */ 
/*  562 */         if (p.isREV1())
/*      */         {
/*      */           BODY b;
/*      */           BODY b;
/*  564 */           if (pk)
/*  565 */             b = p.peekBody(getSequenceNumber(), toSection("TEXT"));
/*      */           else
/*  567 */             b = p.fetchBody(getSequenceNumber(), toSection("TEXT"));
/*  568 */           if (b != null)
/*  569 */             is = b.getByteArrayInputStream();
/*      */         } else {
/*  571 */           RFC822DATA rd = p.fetchRFC822(getSequenceNumber(), "TEXT");
/*  572 */           if (rd != null)
/*  573 */             is = rd.getByteArrayInputStream();
/*      */         }
/*      */       } catch (ConnectionException cex) {
/*  576 */         throw new FolderClosedException(this.folder, cex.getMessage());
/*      */       } catch (ProtocolException pex) {
/*  578 */         forceCheckExpunged();
/*  579 */         throw new MessagingException(pex.getMessage(), pex);
/*      */       }
/*      */     }
/*      */ 
/*  583 */     if (is == null) {
/*  584 */       throw new MessagingException("No content");
/*      */     }
/*  586 */     return is;
/*      */   }
/*      */ 
/*      */   public synchronized DataHandler getDataHandler()
/*      */     throws MessagingException
/*      */   {
/*  594 */     checkExpunged();
/*      */ 
/*  596 */     if (this.dh == null) {
/*  597 */       loadBODYSTRUCTURE();
/*  598 */       if (this.type == null)
/*      */       {
/*  600 */         ContentType ct = new ContentType(this.bs.type, this.bs.subtype, this.bs.cParams);
/*      */ 
/*  602 */         this.type = ct.toString();
/*      */       }
/*      */ 
/*  608 */       if (this.bs.isMulti()) {
/*  609 */         this.dh = new DataHandler(new IMAPMultipartDataSource(this, this.bs.bodies, this.sectionId, this));
/*      */       }
/*  613 */       else if ((this.bs.isNested()) && (isREV1()))
/*      */       {
/*  618 */         this.dh = new DataHandler(new IMAPNestedMessage(this, this.bs.bodies[0], this.bs.envelope, this.sectionId + ".1"), this.type);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  627 */     return super.getDataHandler();
/*      */   }
/*      */ 
/*      */   public void setDataHandler(DataHandler content) throws MessagingException
/*      */   {
/*  632 */     throw new IllegalWriteException("IMAPMessage is read-only");
/*      */   }
/*      */ 
/*      */   public void writeTo(OutputStream os)
/*      */     throws IOException, MessagingException
/*      */   {
/*  640 */     InputStream is = null;
/*  641 */     boolean pk = getPeek();
/*      */ 
/*  644 */     synchronized (getMessageCacheLock()) {
/*      */       try {
/*  646 */         IMAPProtocol p = getProtocol();
/*      */ 
/*  648 */         checkExpunged();
/*      */ 
/*  650 */         if (p.isREV1())
/*      */         {
/*      */           BODY b;
/*      */           BODY b;
/*  652 */           if (pk)
/*  653 */             b = p.peekBody(getSequenceNumber(), this.sectionId);
/*      */           else
/*  655 */             b = p.fetchBody(getSequenceNumber(), this.sectionId);
/*  656 */           if (b != null)
/*  657 */             is = b.getByteArrayInputStream();
/*      */         } else {
/*  659 */           RFC822DATA rd = p.fetchRFC822(getSequenceNumber(), null);
/*  660 */           if (rd != null)
/*  661 */             is = rd.getByteArrayInputStream();
/*      */         }
/*      */       } catch (ConnectionException cex) {
/*  664 */         throw new FolderClosedException(this.folder, cex.getMessage());
/*      */       } catch (ProtocolException pex) {
/*  666 */         forceCheckExpunged();
/*  667 */         throw new MessagingException(pex.getMessage(), pex);
/*      */       }
/*      */     }
/*      */ 
/*  671 */     if (is == null) {
/*  672 */       throw new MessagingException("No content");
/*      */     }
/*      */ 
/*  675 */     byte[] bytes = new byte[1024];
/*      */     int count;
/*  677 */     while ((count = is.read(bytes)) != -1)
/*  678 */       os.write(bytes, 0, count);
/*      */   }
/*      */ 
/*      */   public String[] getHeader(String name)
/*      */     throws MessagingException
/*      */   {
/*  685 */     checkExpunged();
/*      */ 
/*  687 */     if (isHeaderLoaded(name)) {
/*  688 */       return this.headers.getHeader(name);
/*      */     }
/*      */ 
/*  691 */     InputStream is = null;
/*      */ 
/*  694 */     synchronized (getMessageCacheLock()) {
/*      */       try {
/*  696 */         IMAPProtocol p = getProtocol();
/*      */ 
/*  700 */         checkExpunged();
/*      */ 
/*  702 */         if (p.isREV1()) {
/*  703 */           BODY b = p.peekBody(getSequenceNumber(), toSection("HEADER.FIELDS (" + name + ")"));
/*      */ 
/*  706 */           if (b != null)
/*  707 */             is = b.getByteArrayInputStream();
/*      */         } else {
/*  709 */           RFC822DATA rd = p.fetchRFC822(getSequenceNumber(), "HEADER.LINES (" + name + ")");
/*      */ 
/*  711 */           if (rd != null)
/*  712 */             is = rd.getByteArrayInputStream();
/*      */         }
/*      */       } catch (ConnectionException cex) {
/*  715 */         throw new FolderClosedException(this.folder, cex.getMessage());
/*      */       } catch (ProtocolException pex) {
/*  717 */         forceCheckExpunged();
/*  718 */         throw new MessagingException(pex.getMessage(), pex);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  724 */     if (is == null) {
/*  725 */       return null;
/*      */     }
/*  727 */     if (this.headers == null)
/*  728 */       this.headers = new InternetHeaders();
/*  729 */     this.headers.load(is);
/*  730 */     setHeaderLoaded(name);
/*      */ 
/*  732 */     return this.headers.getHeader(name);
/*      */   }
/*      */ 
/*      */   public String getHeader(String name, String delimiter)
/*      */     throws MessagingException
/*      */   {
/*  740 */     checkExpunged();
/*      */ 
/*  743 */     if (getHeader(name) == null)
/*  744 */       return null;
/*  745 */     return this.headers.getHeader(name, delimiter);
/*      */   }
/*      */ 
/*      */   public void setHeader(String name, String value) throws MessagingException
/*      */   {
/*  750 */     throw new IllegalWriteException("IMAPMessage is read-only");
/*      */   }
/*      */ 
/*      */   public void addHeader(String name, String value) throws MessagingException
/*      */   {
/*  755 */     throw new IllegalWriteException("IMAPMessage is read-only");
/*      */   }
/*      */ 
/*      */   public void removeHeader(String name) throws MessagingException
/*      */   {
/*  760 */     throw new IllegalWriteException("IMAPMessage is read-only");
/*      */   }
/*      */ 
/*      */   public Enumeration getAllHeaders()
/*      */     throws MessagingException
/*      */   {
/*  767 */     checkExpunged();
/*  768 */     loadHeaders();
/*  769 */     return super.getAllHeaders();
/*      */   }
/*      */ 
/*      */   public Enumeration getMatchingHeaders(String[] names)
/*      */     throws MessagingException
/*      */   {
/*  777 */     checkExpunged();
/*  778 */     loadHeaders();
/*  779 */     return super.getMatchingHeaders(names);
/*      */   }
/*      */ 
/*      */   public Enumeration getNonMatchingHeaders(String[] names)
/*      */     throws MessagingException
/*      */   {
/*  787 */     checkExpunged();
/*  788 */     loadHeaders();
/*  789 */     return super.getNonMatchingHeaders(names);
/*      */   }
/*      */ 
/*      */   public void addHeaderLine(String line) throws MessagingException {
/*  793 */     throw new IllegalWriteException("IMAPMessage is read-only");
/*      */   }
/*      */ 
/*      */   public Enumeration getAllHeaderLines()
/*      */     throws MessagingException
/*      */   {
/*  800 */     checkExpunged();
/*  801 */     loadHeaders();
/*  802 */     return super.getAllHeaderLines();
/*      */   }
/*      */ 
/*      */   public Enumeration getMatchingHeaderLines(String[] names)
/*      */     throws MessagingException
/*      */   {
/*  810 */     checkExpunged();
/*  811 */     loadHeaders();
/*  812 */     return super.getMatchingHeaderLines(names);
/*      */   }
/*      */ 
/*      */   public Enumeration getNonMatchingHeaderLines(String[] names)
/*      */     throws MessagingException
/*      */   {
/*  820 */     checkExpunged();
/*  821 */     loadHeaders();
/*  822 */     return super.getNonMatchingHeaderLines(names);
/*      */   }
/*      */ 
/*      */   public synchronized Flags getFlags()
/*      */     throws MessagingException
/*      */   {
/*  829 */     checkExpunged();
/*  830 */     loadFlags();
/*  831 */     return super.getFlags();
/*      */   }
/*      */ 
/*      */   public synchronized boolean isSet(Flags.Flag flag)
/*      */     throws MessagingException
/*      */   {
/*  839 */     checkExpunged();
/*  840 */     loadFlags();
/*  841 */     return super.isSet(flag);
/*      */   }
/*      */ 
/*      */   public synchronized void setFlags(Flags flag, boolean set)
/*      */     throws MessagingException
/*      */   {
/*  850 */     synchronized (getMessageCacheLock()) {
/*      */       try {
/*  852 */         IMAPProtocol p = getProtocol();
/*  853 */         checkExpunged();
/*  854 */         p.storeFlags(getSequenceNumber(), flag, set);
/*      */       } catch (ConnectionException cex) {
/*  856 */         throw new FolderClosedException(this.folder, cex.getMessage());
/*      */       } catch (ProtocolException pex) {
/*  858 */         throw new MessagingException(pex.getMessage(), pex);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void setPeek(boolean peek)
/*      */   {
/*  870 */     this.peek = peek;
/*      */   }
/*      */ 
/*      */   public synchronized boolean getPeek()
/*      */   {
/*  880 */     return this.peek;
/*      */   }
/*      */ 
/*      */   public synchronized void invalidateHeaders()
/*      */   {
/*  891 */     this.headersLoaded = false;
/*  892 */     this.loadedHeaders = null;
/*  893 */     this.envelope = null;
/*  894 */     this.bs = null;
/*  895 */     this.receivedDate = null;
/*  896 */     this.size = -1;
/*  897 */     this.type = null;
/*  898 */     this.subject = null;
/*  899 */     this.description = null;
/*      */   }
/*      */ 
/*      */   static void fetch(IMAPFolder folder, Message[] msgs, FetchProfile fp)
/*      */     throws MessagingException
/*      */   {
/*  964 */     StringBuffer command = new StringBuffer();
/*  965 */     boolean first = true;
/*  966 */     boolean allHeaders = false;
/*      */ 
/*  968 */     if (fp.contains(FetchProfile.Item.ENVELOPE)) {
/*  969 */       command.append(EnvelopeCmd);
/*  970 */       first = false;
/*      */     }
/*  972 */     if (fp.contains(FetchProfile.Item.FLAGS)) {
/*  973 */       command.append(first ? "FLAGS" : " FLAGS");
/*  974 */       first = false;
/*      */     }
/*  976 */     if (fp.contains(FetchProfile.Item.CONTENT_INFO)) {
/*  977 */       command.append(first ? "BODYSTRUCTURE" : " BODYSTRUCTURE");
/*  978 */       first = false;
/*      */     }
/*  980 */     if (fp.contains(UIDFolder.FetchProfileItem.UID)) {
/*  981 */       command.append(first ? "UID" : " UID");
/*  982 */       first = false;
/*      */     }
/*  984 */     if (fp.contains(IMAPFolder.FetchProfileItem.HEADERS)) {
/*  985 */       allHeaders = true;
/*  986 */       if (folder.protocol.isREV1()) {
/*  987 */         command.append(first ? "BODY.PEEK[HEADER]" : " BODY.PEEK[HEADER]");
/*      */       }
/*      */       else
/*  990 */         command.append(first ? "RFC822.HEADER" : " RFC822.HEADER");
/*  991 */       first = false;
/*      */     }
/*  993 */     if (fp.contains(IMAPFolder.FetchProfileItem.SIZE)) {
/*  994 */       command.append(first ? "RFC822.SIZE" : " RFC822.SIZE");
/*  995 */       first = false;
/*      */     }
/*      */ 
/*  999 */     String[] hdrs = null;
/* 1000 */     if (!allHeaders) {
/* 1001 */       hdrs = fp.getHeaderNames();
/* 1002 */       if (hdrs.length > 0) {
/* 1003 */         if (!first)
/* 1004 */           command.append(" ");
/* 1005 */         command.append(craftHeaderCmd(folder.protocol, hdrs));
/*      */       }
/*      */     }
/*      */ 
/* 1009 */     Utility.Condition condition = new Utility.Condition()
/*      */     {
/*  915 */       private boolean needEnvelope = false;
/*  916 */       private boolean needFlags = false;
/*  917 */       private boolean needBodyStructure = false;
/*  918 */       private boolean needUID = false;
/*  919 */       private boolean needHeaders = false;
/*  920 */       private boolean needSize = false;
/*  921 */       private String[] hdrs = null;
/*      */ 
/*      */       public boolean test(IMAPMessage m)
/*      */       {
/*  941 */         if ((this.needEnvelope) && (m._getEnvelope() == null))
/*  942 */           return true;
/*  943 */         if ((this.needFlags) && (m._getFlags() == null))
/*  944 */           return true;
/*  945 */         if ((this.needBodyStructure) && (m._getBodyStructure() == null))
/*  946 */           return true;
/*  947 */         if ((this.needUID) && (m.getUID() == -1L))
/*  948 */           return true;
/*  949 */         if ((this.needHeaders) && (!m.areHeadersLoaded()))
/*  950 */           return true;
/*  951 */         if ((this.needSize) && (m.size == -1)) {
/*  952 */           return true;
/*      */         }
/*      */ 
/*  955 */         for (int i = 0; i < this.hdrs.length; i++) {
/*  956 */           if (!m.isHeaderLoaded(this.hdrs[i])) {
/*  957 */             return true;
/*      */           }
/*      */         }
/*  960 */         return false;
/*      */       }
/*      */     };
/* 1012 */     synchronized (folder.messageCacheLock)
/*      */     {
/* 1016 */       MessageSet[] msgsets = Utility.toMessageSet(msgs, condition);
/*      */ 
/* 1018 */       if (msgsets == null)
/*      */       {
/* 1020 */         return;
/*      */       }
/* 1022 */       Response[] r = null;
/* 1023 */       Vector v = new Vector();
/*      */       try
/*      */       {
/* 1026 */         r = folder.protocol.fetch(msgsets, command.toString());
/*      */       } catch (ConnectionException cex) {
/* 1028 */         throw new FolderClosedException(folder, cex.getMessage());
/*      */       } catch (CommandFailedException cfx) {
/*      */       }
/*      */       catch (ProtocolException pex) {
/* 1032 */         throw new MessagingException(pex.getMessage(), pex);
/*      */       }
/*      */ 
/* 1035 */       if (r == null) {
/* 1036 */         return;
/*      */       }
/* 1038 */       for (int i = 0; i < r.length; i++) {
/* 1039 */         if (r[i] != null)
/*      */         {
/* 1041 */           if (!(r[i] instanceof FetchResponse)) {
/* 1042 */             v.addElement(r[i]);
/*      */           }
/*      */           else
/*      */           {
/* 1047 */             FetchResponse f = (FetchResponse)r[i];
/*      */ 
/* 1049 */             IMAPMessage msg = folder.getMessageBySeqNumber(f.getNumber());
/*      */ 
/* 1051 */             int count = f.getItemCount();
/* 1052 */             boolean unsolicitedFlags = false;
/*      */ 
/* 1054 */             for (int j = 0; j < count; j++) {
/* 1055 */               Item item = f.getItem(j);
/*      */ 
/* 1058 */               if ((item instanceof Flags)) {
/* 1059 */                 if ((!fp.contains(FetchProfile.Item.FLAGS)) || (msg == null))
/*      */                 {
/* 1062 */                   unsolicitedFlags = true;
/*      */                 }
/* 1064 */                 else msg.flags = ((Flags)item);
/*      */ 
/*      */               }
/* 1068 */               else if ((item instanceof ENVELOPE)) {
/* 1069 */                 msg.envelope = ((ENVELOPE)item);
/* 1070 */               } else if ((item instanceof INTERNALDATE)) {
/* 1071 */                 msg.receivedDate = ((INTERNALDATE)item).getDate();
/* 1072 */               } else if ((item instanceof RFC822SIZE)) {
/* 1073 */                 msg.size = ((RFC822SIZE)item).size;
/*      */               }
/* 1076 */               else if ((item instanceof BODYSTRUCTURE)) {
/* 1077 */                 msg.bs = ((BODYSTRUCTURE)item);
/*      */               }
/* 1079 */               else if ((item instanceof UID)) {
/* 1080 */                 UID u = (UID)item;
/* 1081 */                 msg.uid = u.uid;
/*      */ 
/* 1083 */                 if (folder.uidTable == null)
/* 1084 */                   folder.uidTable = new Hashtable();
/* 1085 */                 folder.uidTable.put(new Long(u.uid), msg);
/*      */               }
/* 1089 */               else if (((item instanceof RFC822DATA)) || ((item instanceof BODY)))
/*      */               {
/*      */                 InputStream headerStream;
/*      */                 InputStream headerStream;
/* 1092 */                 if ((item instanceof RFC822DATA)) {
/* 1093 */                   headerStream = ((RFC822DATA)item).getByteArrayInputStream();
/*      */                 }
/*      */                 else {
/* 1096 */                   headerStream = ((BODY)item).getByteArrayInputStream();
/*      */                 }
/*      */ 
/* 1100 */                 InternetHeaders h = new InternetHeaders();
/* 1101 */                 h.load(headerStream);
/* 1102 */                 if ((msg.headers == null) || (allHeaders)) {
/* 1103 */                   msg.headers = h;
/*      */                 }
/*      */                 else
/*      */                 {
/* 1114 */                   Enumeration e = h.getAllHeaders();
/* 1115 */                   while (e.hasMoreElements()) {
/* 1116 */                     Header he = (Header)e.nextElement();
/* 1117 */                     if (!msg.isHeaderLoaded(he.getName())) {
/* 1118 */                       msg.headers.addHeader(he.getName(), he.getValue());
/*      */                     }
/*      */                   }
/*      */ 
/*      */                 }
/*      */ 
/* 1124 */                 if (allHeaders) {
/* 1125 */                   msg.setHeadersLoaded(true);
/*      */                 }
/*      */                 else {
/* 1128 */                   for (int k = 0; k < hdrs.length; k++) {
/* 1129 */                     msg.setHeaderLoaded(hdrs[k]);
/*      */                   }
/*      */                 }
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/* 1136 */             if (unsolicitedFlags)
/* 1137 */               v.addElement(f);
/*      */           }
/*      */         }
/*      */       }
/* 1141 */       int size = v.size();
/* 1142 */       if (size != 0) {
/* 1143 */         Response[] responses = new Response[size];
/* 1144 */         v.copyInto(responses);
/* 1145 */         folder.handleResponses(responses);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private synchronized void loadEnvelope()
/*      */     throws MessagingException
/*      */   {
/* 1155 */     if (this.envelope != null) {
/* 1156 */       return;
/*      */     }
/* 1158 */     Response[] r = null;
/*      */ 
/* 1161 */     synchronized (getMessageCacheLock()) {
/*      */       try {
/* 1163 */         IMAPProtocol p = getProtocol();
/*      */ 
/* 1165 */         checkExpunged();
/*      */ 
/* 1167 */         int seqnum = getSequenceNumber();
/* 1168 */         r = p.fetch(seqnum, EnvelopeCmd);
/*      */ 
/* 1170 */         for (int i = 0; i < r.length; i++)
/*      */         {
/* 1173 */           if ((r[i] != null) && ((r[i] instanceof FetchResponse)) && (((FetchResponse)r[i]).getNumber() == seqnum))
/*      */           {
/* 1178 */             FetchResponse f = (FetchResponse)r[i];
/*      */ 
/* 1181 */             int count = f.getItemCount();
/* 1182 */             for (int j = 0; j < count; j++) {
/* 1183 */               Item item = f.getItem(j);
/*      */ 
/* 1185 */               if ((item instanceof ENVELOPE))
/* 1186 */                 this.envelope = ((ENVELOPE)item);
/* 1187 */               else if ((item instanceof INTERNALDATE))
/* 1188 */                 this.receivedDate = ((INTERNALDATE)item).getDate();
/* 1189 */               else if ((item instanceof RFC822SIZE)) {
/* 1190 */                 this.size = ((RFC822SIZE)item).size;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/* 1195 */         p.notifyResponseHandlers(r);
/* 1196 */         p.handleResult(r[(r.length - 1)]);
/*      */       } catch (ConnectionException cex) {
/* 1198 */         throw new FolderClosedException(this.folder, cex.getMessage());
/*      */       } catch (ProtocolException pex) {
/* 1200 */         forceCheckExpunged();
/* 1201 */         throw new MessagingException(pex.getMessage(), pex);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1206 */     if (this.envelope == null)
/* 1207 */       throw new MessagingException("Failed to load IMAP envelope");
/*      */   }
/*      */ 
/*      */   private static String craftHeaderCmd(IMAPProtocol p, String[] hdrs)
/*      */   {
/*      */     StringBuffer sb;
/*      */     StringBuffer sb;
/* 1213 */     if (p.isREV1())
/* 1214 */       sb = new StringBuffer("BODY.PEEK[HEADER.FIELDS (");
/*      */     else {
/* 1216 */       sb = new StringBuffer("RFC822.HEADER.LINES (");
/*      */     }
/* 1218 */     for (int i = 0; i < hdrs.length; i++) {
/* 1219 */       if (i > 0)
/* 1220 */         sb.append(" ");
/* 1221 */       sb.append(hdrs[i]);
/*      */     }
/*      */ 
/* 1224 */     if (p.isREV1())
/* 1225 */       sb.append(")]");
/*      */     else {
/* 1227 */       sb.append(")");
/*      */     }
/* 1229 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   private synchronized void loadBODYSTRUCTURE()
/*      */     throws MessagingException
/*      */   {
/* 1237 */     if (this.bs != null) {
/* 1238 */       return;
/*      */     }
/*      */ 
/* 1241 */     synchronized (getMessageCacheLock()) {
/*      */       try {
/* 1243 */         IMAPProtocol p = getProtocol();
/*      */ 
/* 1247 */         checkExpunged();
/*      */ 
/* 1249 */         this.bs = p.fetchBodyStructure(getSequenceNumber());
/*      */       } catch (ConnectionException cex) {
/* 1251 */         throw new FolderClosedException(this.folder, cex.getMessage());
/*      */       } catch (ProtocolException pex) {
/* 1253 */         forceCheckExpunged();
/* 1254 */         throw new MessagingException(pex.getMessage(), pex);
/*      */       }
/* 1256 */       if (this.bs == null)
/*      */       {
/* 1260 */         forceCheckExpunged();
/* 1261 */         throw new MessagingException("Unable to load BODYSTRUCTURE");
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private synchronized void loadHeaders()
/*      */     throws MessagingException
/*      */   {
/* 1270 */     if (this.headersLoaded) {
/* 1271 */       return;
/*      */     }
/* 1273 */     InputStream is = null;
/*      */ 
/* 1276 */     synchronized (getMessageCacheLock()) {
/*      */       try {
/* 1278 */         IMAPProtocol p = getProtocol();
/*      */ 
/* 1282 */         checkExpunged();
/*      */ 
/* 1284 */         if (p.isREV1()) {
/* 1285 */           BODY b = p.peekBody(getSequenceNumber(), toSection("HEADER"));
/*      */ 
/* 1287 */           if (b != null)
/* 1288 */             is = b.getByteArrayInputStream();
/*      */         } else {
/* 1290 */           RFC822DATA rd = p.fetchRFC822(getSequenceNumber(), "HEADER");
/*      */ 
/* 1292 */           if (rd != null)
/* 1293 */             is = rd.getByteArrayInputStream();
/*      */         }
/*      */       } catch (ConnectionException cex) {
/* 1296 */         throw new FolderClosedException(this.folder, cex.getMessage());
/*      */       } catch (ProtocolException pex) {
/* 1298 */         forceCheckExpunged();
/* 1299 */         throw new MessagingException(pex.getMessage(), pex);
/*      */       }
/*      */     }
/*      */ 
/* 1303 */     if (is == null)
/* 1304 */       throw new MessagingException("Cannot load header");
/* 1305 */     this.headers = new InternetHeaders(is);
/* 1306 */     this.headersLoaded = true;
/*      */   }
/*      */ 
/*      */   private synchronized void loadFlags()
/*      */     throws MessagingException
/*      */   {
/* 1313 */     if (this.flags != null) {
/* 1314 */       return;
/*      */     }
/*      */ 
/* 1317 */     synchronized (getMessageCacheLock()) {
/*      */       try {
/* 1319 */         IMAPProtocol p = getProtocol();
/*      */ 
/* 1323 */         checkExpunged();
/*      */ 
/* 1325 */         this.flags = p.fetchFlags(getSequenceNumber());
/*      */ 
/* 1327 */         if (this.flags == null)
/* 1328 */           this.flags = new Flags();
/*      */       } catch (ConnectionException cex) {
/* 1330 */         throw new FolderClosedException(this.folder, cex.getMessage());
/*      */       } catch (ProtocolException pex) {
/* 1332 */         forceCheckExpunged();
/* 1333 */         throw new MessagingException(pex.getMessage(), pex);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private synchronized boolean areHeadersLoaded()
/*      */   {
/* 1342 */     return this.headersLoaded;
/*      */   }
/*      */ 
/*      */   private synchronized void setHeadersLoaded(boolean loaded)
/*      */   {
/* 1349 */     this.headersLoaded = loaded;
/*      */   }
/*      */ 
/*      */   private synchronized boolean isHeaderLoaded(String name)
/*      */   {
/* 1356 */     if (this.headersLoaded) {
/* 1357 */       return true;
/*      */     }
/* 1359 */     return this.loadedHeaders != null ? this.loadedHeaders.containsKey(name.toUpperCase(Locale.ENGLISH)) : false;
/*      */   }
/*      */ 
/*      */   private synchronized void setHeaderLoaded(String name)
/*      */   {
/* 1368 */     if (this.loadedHeaders == null)
/* 1369 */       this.loadedHeaders = new Hashtable(1);
/* 1370 */     this.loadedHeaders.put(name.toUpperCase(Locale.ENGLISH), name);
/*      */   }
/*      */ 
/*      */   private String toSection(String what)
/*      */   {
/* 1378 */     if (this.sectionId == null) {
/* 1379 */       return what;
/*      */     }
/* 1381 */     return this.sectionId + "." + what;
/*      */   }
/*      */ 
/*      */   private InternetAddress[] aaclone(InternetAddress[] aa)
/*      */   {
/* 1388 */     if (aa == null) {
/* 1389 */       return null;
/*      */     }
/* 1391 */     return (InternetAddress[])aa.clone();
/*      */   }
/*      */ 
/*      */   private Flags _getFlags() {
/* 1395 */     return this.flags;
/*      */   }
/*      */ 
/*      */   private ENVELOPE _getEnvelope() {
/* 1399 */     return this.envelope;
/*      */   }
/*      */ 
/*      */   private BODYSTRUCTURE _getBodyStructure() {
/* 1403 */     return this.bs;
/*      */   }
/*      */ 
/*      */   void _setFlags(Flags flags)
/*      */   {
/* 1416 */     this.flags = flags;
/*      */   }
/*      */ 
/*      */   Session _getSession()
/*      */   {
/* 1423 */     return this.session;
/*      */   }
/*      */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.IMAPMessage
 * JD-Core Version:    0.6.1
 */