/*     */ package com.sun.mail.util;
/*     */ 
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ public class QPEncoderStream extends FilterOutputStream
/*     */ {
/*  51 */   private int count = 0;
/*     */   private int bytesPerLine;
/*  53 */   private boolean gotSpace = false;
/*  54 */   private boolean gotCR = false;
/*     */ 
/* 166 */   private static final char[] hex = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*     */ 
/*     */   public QPEncoderStream(OutputStream out, int bytesPerLine)
/*     */   {
/*  64 */     super(out);
/*     */ 
/*  67 */     this.bytesPerLine = (bytesPerLine - 1);
/*     */   }
/*     */ 
/*     */   public QPEncoderStream(OutputStream out)
/*     */   {
/*  76 */     this(out, 76);
/*     */   }
/*     */ 
/*     */   public void write(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/*  90 */     for (int i = 0; i < len; i++)
/*  91 */       write(b[(off + i)]);
/*     */   }
/*     */ 
/*     */   public void write(byte[] b)
/*     */     throws IOException
/*     */   {
/* 100 */     write(b, 0, b.length);
/*     */   }
/*     */ 
/*     */   public void write(int c)
/*     */     throws IOException
/*     */   {
/* 109 */     c &= 255;
/* 110 */     if (this.gotSpace) {
/* 111 */       if ((c == 13) || (c == 10))
/*     */       {
/* 113 */         output(32, true);
/*     */       }
/* 115 */       else output(32, false);
/* 116 */       this.gotSpace = false;
/*     */     }
/*     */ 
/* 119 */     if (c == 13) {
/* 120 */       this.gotCR = true;
/* 121 */       outputCRLF();
/*     */     } else {
/* 123 */       if (c == 10) {
/* 124 */         if (!this.gotCR)
/*     */         {
/* 129 */           outputCRLF();
/*     */         } } else if (c == 32)
/* 131 */         this.gotSpace = true;
/* 132 */       else if ((c < 32) || (c >= 127) || (c == 61))
/*     */       {
/* 134 */         output(c, true);
/*     */       }
/* 136 */       else output(c, false);
/*     */ 
/* 138 */       this.gotCR = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void flush()
/*     */     throws IOException
/*     */   {
/* 148 */     this.out.flush();
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 156 */     this.out.close();
/*     */   }
/*     */ 
/*     */   private void outputCRLF() throws IOException {
/* 160 */     this.out.write(13);
/* 161 */     this.out.write(10);
/* 162 */     this.count = 0;
/*     */   }
/*     */ 
/*     */   protected void output(int c, boolean encode)
/*     */     throws IOException
/*     */   {
/* 172 */     if (encode) {
/* 173 */       if (this.count += 3 > this.bytesPerLine) {
/* 174 */         this.out.write(61);
/* 175 */         this.out.write(13);
/* 176 */         this.out.write(10);
/* 177 */         this.count = 3;
/*     */       }
/* 179 */       this.out.write(61);
/* 180 */       this.out.write(hex[(c >> 4)]);
/* 181 */       this.out.write(hex[(c & 0xF)]);
/*     */     } else {
/* 183 */       if (++this.count > this.bytesPerLine) {
/* 184 */         this.out.write(61);
/* 185 */         this.out.write(13);
/* 186 */         this.out.write(10);
/* 187 */         this.count = 1;
/*     */       }
/* 189 */       this.out.write(c);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.util.QPEncoderStream
 * JD-Core Version:    0.6.1
 */