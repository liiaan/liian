/*    */ package com.sun.mail.pop3;
/*    */ 
/*    */ import javax.mail.Session;
/*    */ import javax.mail.URLName;
/*    */ 
/*    */ public class POP3SSLStore extends POP3Store
/*    */ {
/*    */   public POP3SSLStore(Session session, URLName url)
/*    */   {
/* 49 */     super(session, url, "pop3s", true);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.pop3.POP3SSLStore
 * JD-Core Version:    0.6.1
 */