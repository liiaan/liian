/*    */ package com.sun.mail.handlers;
/*    */ 
/*    */ import javax.activation.ActivationDataFlavor;
/*    */ 
/*    */ public class text_xml extends text_plain
/*    */ {
/* 46 */   private static ActivationDataFlavor myDF = new ActivationDataFlavor(String.class, "text/xml", "XML String");
/*    */ 
/*    */   protected ActivationDataFlavor getDF()
/*    */   {
/* 52 */     return myDF;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.handlers.text_xml
 * JD-Core Version:    0.6.1
 */