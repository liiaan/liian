/*     */ package com.sun.mail.iap;
/*     */ 
/*     */ import com.sun.mail.util.PropUtil;
/*     */ import com.sun.mail.util.SocketFetcher;
/*     */ import com.sun.mail.util.TraceInputStream;
/*     */ import com.sun.mail.util.TraceOutputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.net.Socket;
/*     */ import java.util.Properties;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class Protocol
/*     */ {
/*     */   protected String host;
/*     */   private Socket socket;
/*     */   protected boolean debug;
/*     */   protected boolean quote;
/*     */   protected PrintStream out;
/*     */   protected Properties props;
/*     */   protected String prefix;
/*  65 */   private boolean connected = false;
/*     */   private TraceInputStream traceInput;
/*     */   private volatile ResponseInputStream input;
/*     */   private TraceOutputStream traceOutput;
/*     */   private volatile DataOutputStream output;
/*  72 */   private int tagCounter = 0;
/*     */ 
/*  79 */   private final Vector handlers = new Vector();
/*     */   private volatile long timestamp;
/*  83 */   private static final byte[] CRLF = { 13, 10 };
/*     */ 
/*     */   public Protocol(String host, int port, boolean debug, PrintStream out, Properties props, String prefix, boolean isSSL)
/*     */     throws IOException, ProtocolException
/*     */   {
/*     */     try
/*     */     {
/* 101 */       this.host = host;
/* 102 */       this.debug = debug;
/* 103 */       this.out = out;
/* 104 */       this.props = props;
/* 105 */       this.prefix = prefix;
/*     */ 
/* 107 */       this.socket = SocketFetcher.getSocket(host, port, props, prefix, isSSL);
/* 108 */       this.quote = PropUtil.getBooleanProperty(props, "mail.debug.quote", false);
/*     */ 
/* 111 */       initStreams(out);
/*     */ 
/* 114 */       processGreeting(readResponse());
/*     */ 
/* 116 */       this.timestamp = System.currentTimeMillis();
/*     */ 
/* 118 */       this.connected = true;
/*     */     }
/*     */     finally
/*     */     {
/* 126 */       if (!this.connected)
/* 127 */         disconnect();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void initStreams(PrintStream out) throws IOException {
/* 132 */     this.traceInput = new TraceInputStream(this.socket.getInputStream(), out);
/* 133 */     this.traceInput.setTrace(this.debug);
/* 134 */     this.traceInput.setQuote(this.quote);
/* 135 */     this.input = new ResponseInputStream(this.traceInput);
/*     */ 
/* 137 */     this.traceOutput = new TraceOutputStream(this.socket.getOutputStream(), out);
/* 138 */     this.traceOutput.setTrace(this.debug);
/* 139 */     this.traceOutput.setQuote(this.quote);
/* 140 */     this.output = new DataOutputStream(new BufferedOutputStream(this.traceOutput));
/*     */   }
/*     */ 
/*     */   public Protocol(InputStream in, OutputStream out, boolean debug)
/*     */     throws IOException
/*     */   {
/* 148 */     this.host = "localhost";
/* 149 */     this.debug = debug;
/* 150 */     this.quote = false;
/* 151 */     this.out = System.out;
/*     */ 
/* 154 */     this.traceInput = new TraceInputStream(in, System.out);
/* 155 */     this.traceInput.setTrace(debug);
/* 156 */     this.traceInput.setQuote(this.quote);
/* 157 */     this.input = new ResponseInputStream(this.traceInput);
/*     */ 
/* 159 */     this.traceOutput = new TraceOutputStream(out, System.out);
/* 160 */     this.traceOutput.setTrace(debug);
/* 161 */     this.traceOutput.setQuote(this.quote);
/* 162 */     this.output = new DataOutputStream(new BufferedOutputStream(this.traceOutput));
/*     */ 
/* 164 */     this.timestamp = System.currentTimeMillis();
/*     */   }
/*     */ 
/*     */   public long getTimestamp()
/*     */   {
/* 172 */     return this.timestamp;
/*     */   }
/*     */ 
/*     */   public void addResponseHandler(ResponseHandler h)
/*     */   {
/* 179 */     this.handlers.addElement(h);
/*     */   }
/*     */ 
/*     */   public void removeResponseHandler(ResponseHandler h)
/*     */   {
/* 186 */     this.handlers.removeElement(h);
/*     */   }
/*     */ 
/*     */   public void notifyResponseHandlers(Response[] responses)
/*     */   {
/* 193 */     if (this.handlers.size() == 0) {
/* 194 */       return;
/*     */     }
/* 196 */     for (int i = 0; i < responses.length; i++) {
/* 197 */       Response r = responses[i];
/*     */ 
/* 200 */       if (r != null)
/*     */       {
/* 205 */         Object[] h = this.handlers.toArray();
/*     */ 
/* 208 */         for (int j = 0; j < h.length; j++)
/* 209 */           if (h[j] != null)
/* 210 */             ((ResponseHandler)h[j]).handleResponse(r);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void processGreeting(Response r) throws ProtocolException {
/* 216 */     if (r.isBYE())
/* 217 */       throw new ConnectionException(this, r);
/*     */   }
/*     */ 
/*     */   protected ResponseInputStream getInputStream()
/*     */   {
/* 224 */     return this.input;
/*     */   }
/*     */ 
/*     */   protected OutputStream getOutputStream()
/*     */   {
/* 231 */     return this.output;
/*     */   }
/*     */ 
/*     */   protected synchronized boolean supportsNonSyncLiterals()
/*     */   {
/* 239 */     return false;
/*     */   }
/*     */ 
/*     */   public Response readResponse() throws IOException, ProtocolException
/*     */   {
/* 244 */     return new Response(this);
/*     */   }
/*     */ 
/*     */   protected ByteArray getResponseBuffer()
/*     */   {
/* 255 */     return null;
/*     */   }
/*     */ 
/*     */   public String writeCommand(String command, Argument args)
/*     */     throws IOException, ProtocolException
/*     */   {
/* 262 */     String tag = "A" + Integer.toString(this.tagCounter++, 10);
/*     */ 
/* 264 */     this.output.writeBytes(tag + " " + command);
/*     */ 
/* 266 */     if (args != null) {
/* 267 */       this.output.write(32);
/* 268 */       args.write(this);
/*     */     }
/*     */ 
/* 271 */     this.output.write(CRLF);
/* 272 */     this.output.flush();
/* 273 */     return tag;
/*     */   }
/*     */ 
/*     */   public synchronized Response[] command(String command, Argument args)
/*     */   {
/* 286 */     Vector v = new Vector();
/* 287 */     boolean done = false;
/* 288 */     String tag = null;
/* 289 */     Response r = null;
/*     */     try
/*     */     {
/* 293 */       tag = writeCommand(command, args);
/*     */     } catch (LiteralException lex) {
/* 295 */       v.addElement(lex.getResponse());
/* 296 */       done = true;
/*     */     }
/*     */     catch (Exception ex) {
/* 299 */       v.addElement(Response.byeResponse(ex));
/* 300 */       done = true;
/*     */     }
/*     */ 
/* 303 */     while (!done) {
/*     */       try {
/* 305 */         r = readResponse();
/*     */       }
/*     */       catch (IOException ioex) {
/* 308 */         r = Response.byeResponse(ioex); } catch (ProtocolException pex) {
/*     */       }
/* 310 */       continue;
/*     */ 
/* 313 */       v.addElement(r);
/*     */ 
/* 315 */       if (r.isBYE()) {
/* 316 */         done = true;
/*     */       }
/*     */ 
/* 319 */       if ((r.isTagged()) && (r.getTag().equals(tag))) {
/* 320 */         done = true;
/*     */       }
/*     */     }
/* 323 */     Response[] responses = new Response[v.size()];
/* 324 */     v.copyInto(responses);
/* 325 */     this.timestamp = System.currentTimeMillis();
/* 326 */     return responses;
/*     */   }
/*     */ 
/*     */   public void handleResult(Response response)
/*     */     throws ProtocolException
/*     */   {
/* 333 */     if (response.isOK())
/* 334 */       return;
/* 335 */     if (response.isNO())
/* 336 */       throw new CommandFailedException(response);
/* 337 */     if (response.isBAD())
/* 338 */       throw new BadCommandException(response);
/* 339 */     if (response.isBYE()) {
/* 340 */       disconnect();
/* 341 */       throw new ConnectionException(this, response);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void simpleCommand(String cmd, Argument args)
/*     */     throws ProtocolException
/*     */   {
/* 352 */     Response[] r = command(cmd, args);
/*     */ 
/* 355 */     notifyResponseHandlers(r);
/*     */ 
/* 358 */     handleResult(r[(r.length - 1)]);
/*     */   }
/*     */ 
/*     */   public synchronized void startTLS(String cmd)
/*     */     throws IOException, ProtocolException
/*     */   {
/* 368 */     simpleCommand(cmd, null);
/* 369 */     this.socket = SocketFetcher.startTLS(this.socket, this.host, this.props, this.prefix);
/* 370 */     initStreams(this.out);
/*     */   }
/*     */ 
/*     */   protected synchronized void disconnect()
/*     */   {
/* 377 */     if (this.socket != null) {
/*     */       try {
/* 379 */         this.socket.close();
/*     */       }
/*     */       catch (IOException e) {
/*     */       }
/* 383 */       this.socket = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void finalize()
/*     */     throws Throwable
/*     */   {
/* 391 */     super.finalize();
/* 392 */     disconnect();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.iap.Protocol
 * JD-Core Version:    0.6.1
 */