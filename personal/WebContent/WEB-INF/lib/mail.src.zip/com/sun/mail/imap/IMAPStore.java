/*      */ package com.sun.mail.imap;
/*      */ 
/*      */ import com.sun.mail.iap.BadCommandException;
/*      */ import com.sun.mail.iap.CommandFailedException;
/*      */ import com.sun.mail.iap.ConnectionException;
/*      */ import com.sun.mail.iap.ProtocolException;
/*      */ import com.sun.mail.iap.Response;
/*      */ import com.sun.mail.iap.ResponseHandler;
/*      */ import com.sun.mail.imap.protocol.IMAPProtocol;
/*      */ import com.sun.mail.imap.protocol.Namespaces;
/*      */ import com.sun.mail.imap.protocol.Namespaces.Namespace;
/*      */ import com.sun.mail.util.PropUtil;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.net.InetAddress;
/*      */ import java.net.UnknownHostException;
/*      */ import java.util.Map;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.Vector;
/*      */ import javax.mail.AuthenticationFailedException;
/*      */ import javax.mail.Folder;
/*      */ import javax.mail.MessagingException;
/*      */ import javax.mail.PasswordAuthentication;
/*      */ import javax.mail.Quota;
/*      */ import javax.mail.QuotaAwareStore;
/*      */ import javax.mail.Session;
/*      */ import javax.mail.Store;
/*      */ import javax.mail.StoreClosedException;
/*      */ import javax.mail.URLName;
/*      */ 
/*      */ public class IMAPStore extends Store
/*      */   implements QuotaAwareStore, ResponseHandler
/*      */ {
/*      */   public static final int RESPONSE = 1000;
/*      */   private final String name;
/*      */   private final int defaultPort;
/*      */   private final boolean isSSL;
/*      */   private final int blksize;
/*      */   private final int statusCacheTimeout;
/*      */   private final int appendBufferSize;
/*      */   private final int minIdleTime;
/*  168 */   private int port = -1;
/*      */   private String host;
/*      */   private String user;
/*      */   private String password;
/*      */   private String proxyAuthUser;
/*      */   private String authorizationID;
/*      */   private String saslRealm;
/*      */   private Namespaces namespaces;
/*  180 */   private boolean disableAuthLogin = false;
/*  181 */   private boolean disableAuthPlain = false;
/*  182 */   private boolean enableStartTLS = false;
/*  183 */   private boolean requireStartTLS = false;
/*  184 */   private boolean enableSASL = false;
/*      */   private String[] saslMechanisms;
/*  186 */   private boolean forcePasswordRefresh = false;
/*      */ 
/*  188 */   private boolean enableImapEvents = false;
/*      */ 
/*  199 */   private volatile boolean connectionFailed = false;
/*  200 */   private volatile boolean forceClose = false;
/*  201 */   private final Object connectionFailedLock = new Object();
/*      */   private PrintStream out;
/*      */   private boolean messageCacheDebug;
/*      */   private final ConnectionPool pool;
/*  364 */   private ResponseHandler nonStoreResponseHandler = new ResponseHandler()
/*      */   {
/*      */     public void handleResponse(Response r) {
/*  367 */       if ((r.isOK()) || (r.isNO()) || (r.isBAD()) || (r.isBYE()))
/*  368 */         IMAPStore.this.handleResponseCode(r);
/*  369 */       if ((IMAPStore.this.debug) && (r.isBYE()))
/*  370 */         IMAPStore.this.out.println("DEBUG: IMAPStore non-store connection dead");
/*      */     }
/*  364 */   };
/*      */ 
/*      */   public IMAPStore(Session session, URLName url)
/*      */   {
/*  379 */     this(session, url, "imap", false);
/*      */   }
/*      */ 
/*      */   protected IMAPStore(Session session, URLName url, String name, boolean isSSL)
/*      */   {
/*  387 */     super(session, url);
/*  388 */     if (url != null)
/*  389 */       name = url.getProtocol();
/*  390 */     this.name = name;
/*  391 */     if (!isSSL) {
/*  392 */       isSSL = PropUtil.getBooleanSessionProperty(session, "mail." + name + ".ssl.enable", false);
/*      */     }
/*  394 */     if (isSSL)
/*  395 */       this.defaultPort = 993;
/*      */     else
/*  397 */       this.defaultPort = 143;
/*  398 */     this.isSSL = isSSL;
/*      */ 
/*  400 */     this.debug = session.getDebug();
/*  401 */     this.out = session.getDebugOut();
/*  402 */     if (this.out == null) {
/*  403 */       this.out = System.out;
/*      */     }
/*  405 */     boolean partialFetch = PropUtil.getBooleanSessionProperty(session, "mail." + name + ".partialfetch", true);
/*      */ 
/*  407 */     if (!partialFetch) {
/*  408 */       this.blksize = -1;
/*  409 */       if (this.debug)
/*  410 */         this.out.println("DEBUG: mail.imap.partialfetch: false");
/*      */     } else {
/*  412 */       this.blksize = PropUtil.getIntSessionProperty(session, "mail." + name + ".fetchsize", 16384);
/*      */ 
/*  414 */       if (this.debug) {
/*  415 */         this.out.println("DEBUG: mail.imap.fetchsize: " + this.blksize);
/*      */       }
/*      */     }
/*  418 */     this.statusCacheTimeout = PropUtil.getIntSessionProperty(session, "mail." + name + ".statuscachetimeout", 1000);
/*      */ 
/*  420 */     if (this.debug) {
/*  421 */       this.out.println("DEBUG: mail.imap.statuscachetimeout: " + this.statusCacheTimeout);
/*      */     }
/*      */ 
/*  424 */     this.appendBufferSize = PropUtil.getIntSessionProperty(session, "mail." + name + ".appendbuffersize", -1);
/*      */ 
/*  426 */     if (this.debug) {
/*  427 */       this.out.println("DEBUG: mail.imap.appendbuffersize: " + this.appendBufferSize);
/*      */     }
/*      */ 
/*  430 */     this.minIdleTime = PropUtil.getIntSessionProperty(session, "mail." + name + ".minidletime", 10);
/*      */ 
/*  432 */     if (this.debug) {
/*  433 */       this.out.println("DEBUG: mail.imap.minidletime: " + this.minIdleTime);
/*      */     }
/*      */ 
/*  436 */     String s = session.getProperty("mail." + name + ".proxyauth.user");
/*  437 */     if (s != null) {
/*  438 */       this.proxyAuthUser = s;
/*  439 */       if (this.debug) {
/*  440 */         this.out.println("DEBUG: mail.imap.proxyauth.user: " + this.proxyAuthUser);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  445 */     this.disableAuthLogin = PropUtil.getBooleanSessionProperty(session, "mail." + name + ".auth.login.disable", false);
/*      */ 
/*  447 */     if ((this.debug) && (this.disableAuthLogin)) {
/*  448 */       this.out.println("DEBUG: disable AUTH=LOGIN");
/*      */     }
/*      */ 
/*  451 */     this.disableAuthPlain = PropUtil.getBooleanSessionProperty(session, "mail." + name + ".auth.plain.disable", false);
/*      */ 
/*  453 */     if ((this.debug) && (this.disableAuthPlain)) {
/*  454 */       this.out.println("DEBUG: disable AUTH=PLAIN");
/*      */     }
/*      */ 
/*  457 */     this.enableStartTLS = PropUtil.getBooleanSessionProperty(session, "mail." + name + ".starttls.enable", false);
/*      */ 
/*  459 */     if ((this.debug) && (this.enableStartTLS)) {
/*  460 */       this.out.println("DEBUG: enable STARTTLS");
/*      */     }
/*      */ 
/*  463 */     this.requireStartTLS = PropUtil.getBooleanSessionProperty(session, "mail." + name + ".starttls.required", false);
/*      */ 
/*  465 */     if ((this.debug) && (this.requireStartTLS)) {
/*  466 */       this.out.println("DEBUG: require STARTTLS");
/*      */     }
/*      */ 
/*  469 */     this.enableSASL = PropUtil.getBooleanSessionProperty(session, "mail." + name + ".sasl.enable", false);
/*      */ 
/*  471 */     if ((this.debug) && (this.enableSASL)) {
/*  472 */       this.out.println("DEBUG: enable SASL");
/*      */     }
/*      */ 
/*  475 */     if (this.enableSASL) {
/*  476 */       s = session.getProperty("mail." + name + ".sasl.mechanisms");
/*  477 */       if ((s != null) && (s.length() > 0)) {
/*  478 */         if (this.debug)
/*  479 */           this.out.println("DEBUG: SASL mechanisms allowed: " + s);
/*  480 */         Vector v = new Vector(5);
/*  481 */         StringTokenizer st = new StringTokenizer(s, " ,");
/*  482 */         while (st.hasMoreTokens()) {
/*  483 */           String m = st.nextToken();
/*  484 */           if (m.length() > 0)
/*  485 */             v.addElement(m);
/*      */         }
/*  487 */         this.saslMechanisms = new String[v.size()];
/*  488 */         v.copyInto(this.saslMechanisms);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  493 */     s = session.getProperty("mail." + name + ".sasl.authorizationid");
/*  494 */     if (s != null) {
/*  495 */       this.authorizationID = s;
/*  496 */       if (this.debug) {
/*  497 */         this.out.println("DEBUG: mail.imap.sasl.authorizationid: " + this.authorizationID);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  502 */     s = session.getProperty("mail." + name + ".sasl.realm");
/*  503 */     if (s != null) {
/*  504 */       this.saslRealm = s;
/*  505 */       if (this.debug) {
/*  506 */         this.out.println("DEBUG: mail.imap.sasl.realm: " + this.saslRealm);
/*      */       }
/*      */     }
/*      */ 
/*  510 */     this.forcePasswordRefresh = PropUtil.getBooleanSessionProperty(session, "mail." + name + ".forcepasswordrefresh", false);
/*      */ 
/*  512 */     if ((this.debug) && (this.forcePasswordRefresh)) {
/*  513 */       this.out.println("DEBUG: enable forcePasswordRefresh");
/*      */     }
/*      */ 
/*  516 */     this.enableImapEvents = PropUtil.getBooleanSessionProperty(session, "mail." + name + ".enableimapevents", false);
/*      */ 
/*  518 */     if ((this.debug) && (this.enableImapEvents)) {
/*  519 */       this.out.println("DEBUG: enable IMAP events");
/*      */     }
/*      */ 
/*  522 */     this.messageCacheDebug = PropUtil.getBooleanSessionProperty(session, "mail." + name + ".messagecache.debug", false);
/*      */ 
/*  525 */     this.pool = new ConnectionPool(name, session);
/*      */   }
/*      */ 
/*      */   protected synchronized boolean protocolConnect(String host, int pport, String user, String password)
/*      */     throws MessagingException
/*      */   {
/*  542 */     IMAPProtocol protocol = null;
/*      */ 
/*  545 */     if ((host == null) || (password == null) || (user == null)) {
/*  546 */       if (this.debug) {
/*  547 */         this.out.println("DEBUG: protocolConnect returning false, host=" + host + ", user=" + user + ", password=" + (password != null ? "<non-null>" : "<null>"));
/*      */       }
/*      */ 
/*  552 */       return false;
/*      */     }
/*      */ 
/*  556 */     if (pport != -1)
/*  557 */       this.port = pport;
/*      */     else {
/*  559 */       this.port = PropUtil.getIntSessionProperty(this.session, "mail." + this.name + ".port", this.port);
/*      */     }
/*      */ 
/*  564 */     if (this.port == -1)
/*  565 */       this.port = this.defaultPort;
/*      */     try
/*      */     {
/*      */       boolean poolEmpty;
/*  570 */       synchronized (this.pool) {
/*  571 */         poolEmpty = this.pool.authenticatedConnections.isEmpty();
/*      */       }
/*      */ 
/*  574 */       if (poolEmpty) {
/*  575 */         if (this.debug) {
/*  576 */           this.out.println("DEBUG: trying to connect to host \"" + host + "\", port " + this.port + ", isSSL " + this.isSSL);
/*      */         }
/*  578 */         protocol = new IMAPProtocol(this.name, host, this.port, this.session.getDebug(), this.session.getDebugOut(), this.session.getProperties(), this.isSSL);
/*      */ 
/*  584 */         if (this.debug) {
/*  585 */           this.out.println("DEBUG: protocolConnect login, host=" + host + ", user=" + user + ", password=<non-null>");
/*      */         }
/*      */ 
/*  589 */         login(protocol, user, password);
/*      */ 
/*  591 */         protocol.addResponseHandler(this);
/*      */ 
/*  593 */         this.host = host;
/*  594 */         this.user = user;
/*  595 */         this.password = password;
/*      */ 
/*  597 */         synchronized (this.pool) {
/*  598 */           this.pool.authenticatedConnections.addElement(protocol);
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (CommandFailedException cex) {
/*  603 */       if (protocol != null)
/*  604 */         protocol.disconnect();
/*  605 */       protocol = null;
/*  606 */       throw new AuthenticationFailedException(cex.getResponse().getRest());
/*      */     }
/*      */     catch (ProtocolException pex) {
/*  609 */       throw new MessagingException(pex.getMessage(), pex);
/*      */     } catch (IOException ioex) {
/*  611 */       throw new MessagingException(ioex.getMessage(), ioex);
/*      */     }
/*      */ 
/*  614 */     return true;
/*      */   }
/*      */ 
/*      */   private void login(IMAPProtocol p, String u, String pw)
/*      */     throws ProtocolException
/*      */   {
/*  620 */     if ((this.enableStartTLS) || (this.requireStartTLS)) {
/*  621 */       if (p.hasCapability("STARTTLS")) {
/*  622 */         p.startTLS();
/*      */ 
/*  624 */         p.capability();
/*  625 */       } else if (this.requireStartTLS) {
/*  626 */         if (this.debug)
/*  627 */           this.out.println("DEBUG: STARTTLS required but not supported");
/*  628 */         throw new ProtocolException("STARTTLS required but not supported by server");
/*      */       }
/*      */     }
/*      */ 
/*  632 */     if (p.isAuthenticated()) {
/*  633 */       return;
/*      */     }
/*      */ 
/*  640 */     p.getCapabilities().put("__PRELOGIN__", "");
/*      */     String authzid;
/*      */     String authzid;
/*  642 */     if (this.authorizationID != null) {
/*  643 */       authzid = this.authorizationID;
/*      */     }
/*      */     else
/*      */     {
/*      */       String authzid;
/*  644 */       if (this.proxyAuthUser != null)
/*  645 */         authzid = this.proxyAuthUser;
/*      */       else
/*  647 */         authzid = u;
/*      */     }
/*  649 */     if (this.enableSASL) {
/*  650 */       p.sasllogin(this.saslMechanisms, this.saslRealm, authzid, u, pw);
/*      */     }
/*  652 */     if (!p.isAuthenticated())
/*      */     {
/*  654 */       if ((p.hasCapability("AUTH=PLAIN")) && (!this.disableAuthPlain))
/*  655 */         p.authplain(authzid, u, pw);
/*  656 */       else if (((p.hasCapability("AUTH-LOGIN")) || (p.hasCapability("AUTH=LOGIN"))) && (!this.disableAuthLogin))
/*      */       {
/*  658 */         p.authlogin(u, pw);
/*  659 */       } else if (!p.hasCapability("LOGINDISABLED"))
/*  660 */         p.login(u, pw);
/*      */       else
/*  662 */         throw new ProtocolException("No login methods supported!");
/*      */     }
/*  664 */     if (this.proxyAuthUser != null) {
/*  665 */       p.proxyauth(this.proxyAuthUser);
/*      */     }
/*      */ 
/*  671 */     if (p.hasCapability("__PRELOGIN__"))
/*      */       try {
/*  673 */         p.capability();
/*      */       } catch (ConnectionException cex) {
/*  675 */         throw cex;
/*      */       }
/*      */       catch (ProtocolException pex)
/*      */       {
/*      */       }
/*      */   }
/*      */ 
/*      */   public synchronized void setUsername(String user)
/*      */   {
/*  699 */     this.user = user;
/*      */   }
/*      */ 
/*      */   public synchronized void setPassword(String password)
/*      */   {
/*  713 */     this.password = password;
/*      */   }
/*      */ 
/*      */   IMAPProtocol getProtocol(IMAPFolder folder)
/*      */     throws MessagingException
/*      */   {
/*  723 */     IMAPProtocol p = null;
/*      */ 
/*  726 */     while (p == null)
/*      */     {
/*  734 */       synchronized (this.pool)
/*      */       {
/*  738 */         if ((this.pool.authenticatedConnections.isEmpty()) || ((this.pool.authenticatedConnections.size() == 1) && ((this.pool.separateStoreConnection) || (this.pool.storeConnectionInUse))))
/*      */         {
/*  742 */           if (this.debug)
/*  743 */             this.out.println("DEBUG: no connections in the pool, creating a new one");
/*      */           try
/*      */           {
/*  746 */             if (this.forcePasswordRefresh) {
/*  747 */               refreshPassword();
/*      */             }
/*  749 */             p = new IMAPProtocol(this.name, this.host, this.port, this.session.getDebug(), this.session.getDebugOut(), this.session.getProperties(), this.isSSL);
/*      */ 
/*  756 */             login(p, this.user, this.password);
/*      */           } catch (Exception ex1) {
/*  758 */             if (p != null)
/*      */               try {
/*  760 */                 p.disconnect(); } catch (Exception ex2) {
/*      */               }
/*  762 */             p = null;
/*      */           }
/*      */ 
/*  765 */           if (p == null)
/*  766 */             throw new MessagingException("connection failure");
/*      */         } else {
/*  768 */           if (this.debug) {
/*  769 */             this.out.println("DEBUG: connection available -- size: " + this.pool.authenticatedConnections.size());
/*      */           }
/*      */ 
/*  773 */           p = (IMAPProtocol)this.pool.authenticatedConnections.lastElement();
/*  774 */           this.pool.authenticatedConnections.removeElement(p);
/*      */ 
/*  777 */           long lastUsed = System.currentTimeMillis() - p.getTimestamp();
/*  778 */           if (lastUsed > this.pool.serverTimeoutInterval)
/*      */           {
/*      */             try
/*      */             {
/*  785 */               p.removeResponseHandler(this);
/*  786 */               p.addResponseHandler(this.nonStoreResponseHandler);
/*  787 */               p.noop();
/*  788 */               p.removeResponseHandler(this.nonStoreResponseHandler);
/*  789 */               p.addResponseHandler(this);
/*      */             } catch (ProtocolException pex) {
/*      */               try {
/*  792 */                 p.removeResponseHandler(this.nonStoreResponseHandler);
/*  793 */                 p.disconnect();
/*      */               }
/*      */               finally {
/*  796 */                 p = null;
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*  803 */           p.removeResponseHandler(this);
/*      */         }
/*      */ 
/*  807 */         timeoutConnections();
/*      */ 
/*  810 */         if (folder != null) {
/*  811 */           if (this.pool.folders == null)
/*  812 */             this.pool.folders = new Vector();
/*  813 */           this.pool.folders.addElement(folder);
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  819 */     return p;
/*      */   }
/*      */ 
/*      */   private IMAPProtocol getStoreProtocol()
/*      */     throws ProtocolException
/*      */   {
/*  841 */     IMAPProtocol p = null;
/*      */ 
/*  843 */     while (p == null) {
/*  844 */       synchronized (this.pool) {
/*  845 */         waitIfIdle();
/*      */ 
/*  849 */         if (this.pool.authenticatedConnections.isEmpty()) {
/*  850 */           if (this.pool.debug)
/*  851 */             this.out.println("DEBUG: getStoreProtocol() - no connections in the pool, creating a new one");
/*      */           try
/*      */           {
/*  854 */             if (this.forcePasswordRefresh) {
/*  855 */               refreshPassword();
/*      */             }
/*  857 */             p = new IMAPProtocol(this.name, this.host, this.port, this.session.getDebug(), this.session.getDebugOut(), this.session.getProperties(), this.isSSL);
/*      */ 
/*  864 */             login(p, this.user, this.password);
/*      */           } catch (Exception ex1) {
/*  866 */             if (p != null)
/*      */               try {
/*  868 */                 p.logout(); } catch (Exception ex2) {
/*      */               }
/*  870 */             p = null;
/*      */           }
/*      */ 
/*  873 */           if (p == null) {
/*  874 */             throw new ConnectionException("failed to create new store connection");
/*      */           }
/*      */ 
/*  877 */           p.addResponseHandler(this);
/*  878 */           this.pool.authenticatedConnections.addElement(p);
/*      */         }
/*      */         else
/*      */         {
/*  882 */           if (this.pool.debug) {
/*  883 */             this.out.println("DEBUG: getStoreProtocol() - connection available -- size: " + this.pool.authenticatedConnections.size());
/*      */           }
/*      */ 
/*  886 */           p = (IMAPProtocol)this.pool.authenticatedConnections.firstElement();
/*      */         }
/*      */ 
/*  889 */         if (this.pool.storeConnectionInUse)
/*      */         {
/*      */           try
/*      */           {
/*  893 */             p = null;
/*  894 */             this.pool.wait(); } catch (InterruptedException ex) {
/*      */           }
/*      */         } else {
/*  897 */           this.pool.storeConnectionInUse = true;
/*      */ 
/*  899 */           if (this.pool.debug) {
/*  900 */             this.out.println("DEBUG: getStoreProtocol() -- storeConnectionInUse");
/*      */           }
/*      */         }
/*      */ 
/*  904 */         timeoutConnections();
/*      */       }
/*      */     }
/*  907 */     return p;
/*      */   }
/*      */ 
/*      */   IMAPProtocol getFolderStoreProtocol()
/*      */     throws ProtocolException
/*      */   {
/*  914 */     IMAPProtocol p = getStoreProtocol();
/*  915 */     p.removeResponseHandler(this);
/*  916 */     p.addResponseHandler(this.nonStoreResponseHandler);
/*  917 */     return p;
/*      */   }
/*      */ 
/*      */   private void refreshPassword()
/*      */   {
/*  929 */     if (this.debug)
/*  930 */       this.out.println("DEBUG: refresh password, user: " + this.user);
/*      */     InetAddress addr;
/*      */     try {
/*  933 */       addr = InetAddress.getByName(this.host);
/*      */     } catch (UnknownHostException e) {
/*  935 */       addr = null;
/*      */     }
/*  937 */     PasswordAuthentication pa = this.session.requestPasswordAuthentication(addr, this.port, this.name, null, this.user);
/*      */ 
/*  940 */     if (pa != null) {
/*  941 */       this.user = pa.getUserName();
/*  942 */       this.password = pa.getPassword();
/*      */     }
/*      */   }
/*      */ 
/*      */   boolean allowReadOnlySelect()
/*      */   {
/*  952 */     return PropUtil.getBooleanSessionProperty(this.session, "mail." + this.name + ".allowreadonlyselect", false);
/*      */   }
/*      */ 
/*      */   boolean hasSeparateStoreConnection()
/*      */   {
/*  960 */     return this.pool.separateStoreConnection;
/*      */   }
/*      */ 
/*      */   boolean getConnectionPoolDebug()
/*      */   {
/*  967 */     return this.pool.debug;
/*      */   }
/*      */ 
/*      */   boolean getMessageCacheDebug()
/*      */   {
/*  974 */     return this.messageCacheDebug;
/*      */   }
/*      */ 
/*      */   boolean isConnectionPoolFull()
/*      */   {
/*  982 */     synchronized (this.pool) {
/*  983 */       if (this.pool.debug) {
/*  984 */         this.out.println("DEBUG: current size: " + this.pool.authenticatedConnections.size() + "   pool size: " + this.pool.poolSize);
/*      */       }
/*      */ 
/*  988 */       return this.pool.authenticatedConnections.size() >= this.pool.poolSize;
/*      */     }
/*      */   }
/*      */ 
/*      */   void releaseProtocol(IMAPFolder folder, IMAPProtocol protocol)
/*      */   {
/*  998 */     synchronized (this.pool) {
/*  999 */       if (protocol != null)
/*      */       {
/* 1002 */         if (!isConnectionPoolFull()) {
/* 1003 */           protocol.addResponseHandler(this);
/* 1004 */           this.pool.authenticatedConnections.addElement(protocol);
/*      */ 
/* 1006 */           if (this.debug)
/* 1007 */             this.out.println("DEBUG: added an Authenticated connection -- size: " + this.pool.authenticatedConnections.size());
/*      */         }
/*      */         else
/*      */         {
/* 1011 */           if (this.debug)
/* 1012 */             this.out.println("DEBUG: pool is full, not adding an Authenticated connection");
/*      */           try
/*      */           {
/* 1015 */             protocol.logout();
/*      */           } catch (ProtocolException pex) {
/*      */           }
/*      */         }
/*      */       }
/* 1020 */       if (this.pool.folders != null) {
/* 1021 */         this.pool.folders.removeElement(folder);
/*      */       }
/* 1023 */       timeoutConnections();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void releaseStoreProtocol(IMAPProtocol protocol)
/*      */   {
/* 1035 */     if (protocol == null) {
/* 1036 */       cleanup();
/*      */       return;
/*      */     }
/*      */     boolean failed;
/* 1045 */     synchronized (this.connectionFailedLock) {
/* 1046 */       failed = this.connectionFailed;
/* 1047 */       this.connectionFailed = false;
/*      */     }
/*      */ 
/* 1051 */     synchronized (this.pool) {
/* 1052 */       this.pool.storeConnectionInUse = false;
/* 1053 */       this.pool.notifyAll();
/*      */ 
/* 1055 */       if (this.pool.debug) {
/* 1056 */         this.out.println("DEBUG: releaseStoreProtocol()");
/*      */       }
/* 1058 */       timeoutConnections();
/*      */     }
/*      */ 
/* 1066 */     assert (!Thread.holdsLock(this.pool));
/* 1067 */     if (failed)
/* 1068 */       cleanup();
/*      */   }
/*      */ 
/*      */   void releaseFolderStoreProtocol(IMAPProtocol protocol)
/*      */   {
/* 1075 */     if (protocol == null)
/* 1076 */       return;
/* 1077 */     protocol.removeResponseHandler(this.nonStoreResponseHandler);
/* 1078 */     protocol.addResponseHandler(this);
/* 1079 */     synchronized (this.pool) {
/* 1080 */       this.pool.storeConnectionInUse = false;
/* 1081 */       this.pool.notifyAll();
/*      */ 
/* 1083 */       if (this.pool.debug) {
/* 1084 */         this.out.println("DEBUG: releaseFolderStoreProtocol()");
/*      */       }
/* 1086 */       timeoutConnections();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void emptyConnectionPool(boolean force)
/*      */   {
/* 1095 */     synchronized (this.pool) {
/* 1096 */       for (int index = this.pool.authenticatedConnections.size() - 1; 
/* 1097 */         index >= 0; index--)
/*      */         try {
/* 1099 */           IMAPProtocol p = (IMAPProtocol)this.pool.authenticatedConnections.elementAt(index);
/*      */ 
/* 1101 */           p.removeResponseHandler(this);
/* 1102 */           if (force)
/* 1103 */             p.disconnect();
/*      */           else
/* 1105 */             p.logout();
/*      */         }
/*      */         catch (ProtocolException pex) {
/*      */         }
/* 1109 */       this.pool.authenticatedConnections.removeAllElements();
/*      */     }
/*      */ 
/* 1112 */     if (this.pool.debug)
/* 1113 */       this.out.println("DEBUG: removed all authenticated connections");
/*      */   }
/*      */ 
/*      */   private void timeoutConnections()
/*      */   {
/* 1121 */     synchronized (this.pool)
/*      */     {
/* 1125 */       if ((System.currentTimeMillis() - this.pool.lastTimePruned > this.pool.pruningInterval) && (this.pool.authenticatedConnections.size() > 1))
/*      */       {
/* 1129 */         if (this.pool.debug) {
/* 1130 */           this.out.println("DEBUG: checking for connections to prune: " + (System.currentTimeMillis() - this.pool.lastTimePruned));
/*      */ 
/* 1133 */           this.out.println("DEBUG: clientTimeoutInterval: " + this.pool.clientTimeoutInterval);
/*      */         }
/*      */ 
/* 1142 */         for (int index = this.pool.authenticatedConnections.size() - 1; 
/* 1143 */           index > 0; index--) {
/* 1144 */           IMAPProtocol p = (IMAPProtocol)this.pool.authenticatedConnections.elementAt(index);
/*      */ 
/* 1146 */           if (this.pool.debug) {
/* 1147 */             this.out.println("DEBUG: protocol last used: " + (System.currentTimeMillis() - p.getTimestamp()));
/*      */           }
/*      */ 
/* 1150 */           if (System.currentTimeMillis() - p.getTimestamp() > this.pool.clientTimeoutInterval)
/*      */           {
/* 1153 */             if (this.pool.debug) {
/* 1154 */               this.out.println("DEBUG: authenticated connection timed out");
/*      */ 
/* 1156 */               this.out.println("DEBUG: logging out the connection");
/*      */             }
/*      */ 
/* 1160 */             p.removeResponseHandler(this);
/* 1161 */             this.pool.authenticatedConnections.removeElementAt(index);
/*      */             try
/*      */             {
/* 1164 */               p.logout(); } catch (ProtocolException pex) {
/*      */             }
/*      */           }
/*      */         }
/* 1168 */         this.pool.lastTimePruned = System.currentTimeMillis();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   int getFetchBlockSize()
/*      */   {
/* 1177 */     return this.blksize;
/*      */   }
/*      */ 
/*      */   Session getSession()
/*      */   {
/* 1184 */     return this.session;
/*      */   }
/*      */ 
/*      */   int getStatusCacheTimeout()
/*      */   {
/* 1191 */     return this.statusCacheTimeout;
/*      */   }
/*      */ 
/*      */   int getAppendBufferSize()
/*      */   {
/* 1198 */     return this.appendBufferSize;
/*      */   }
/*      */ 
/*      */   int getMinIdleTime()
/*      */   {
/* 1205 */     return this.minIdleTime;
/*      */   }
/*      */ 
/*      */   public synchronized boolean hasCapability(String capability)
/*      */     throws MessagingException
/*      */   {
/* 1216 */     IMAPProtocol p = null;
/*      */     try {
/* 1218 */       p = getStoreProtocol();
/* 1219 */       return p.hasCapability(capability);
/*      */     } catch (ProtocolException pex) {
/* 1221 */       throw new MessagingException(pex.getMessage(), pex);
/*      */     } finally {
/* 1223 */       releaseStoreProtocol(p);
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized boolean isConnected()
/*      */   {
/* 1232 */     if (!super.isConnected())
/*      */     {
/* 1235 */       return false;
/*      */     }
/*      */ 
/* 1254 */     IMAPProtocol p = null;
/*      */     try {
/* 1256 */       p = getStoreProtocol();
/* 1257 */       p.noop();
/*      */     } catch (ProtocolException pex) {
/*      */     }
/*      */     finally {
/* 1261 */       releaseStoreProtocol(p);
/*      */     }
/*      */ 
/* 1265 */     return super.isConnected();
/*      */   }
/*      */ 
/*      */   public synchronized void close()
/*      */     throws MessagingException
/*      */   {
/* 1272 */     if (!super.isConnected()) {
/* 1273 */       return;
/*      */     }
/* 1275 */     IMAPProtocol protocol = null;
/*      */     try
/*      */     {
/*      */       boolean isEmpty;
/* 1278 */       synchronized (this.pool)
/*      */       {
/* 1281 */         isEmpty = this.pool.authenticatedConnections.isEmpty();
/*      */       }
/*      */ 
/* 1292 */       if (isEmpty) {
/* 1293 */         if (this.pool.debug)
/* 1294 */           this.out.println("DEBUG: close() - no connections ");
/* 1295 */         cleanup();
/* 1296 */         return;
/*      */       }
/*      */ 
/* 1299 */       protocol = getStoreProtocol();
/*      */ 
/* 1306 */       synchronized (this.pool) {
/* 1307 */         this.pool.authenticatedConnections.removeElement(protocol);
/*      */       }
/*      */ 
/* 1325 */       protocol.logout();
/*      */     }
/*      */     catch (ProtocolException pex) {
/* 1328 */       throw new MessagingException(pex.getMessage(), pex);
/*      */     } finally {
/* 1330 */       releaseStoreProtocol(protocol);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void finalize() throws Throwable {
/* 1335 */     super.finalize();
/* 1336 */     close();
/*      */   }
/*      */ 
/*      */   private synchronized void cleanup()
/*      */   {
/* 1344 */     if (!super.isConnected()) {
/* 1345 */       if (this.debug)
/* 1346 */         this.out.println("DEBUG: IMAPStore cleanup, not connected");
/*      */       return;
/*      */     }
/*      */     boolean force;
/* 1357 */     synchronized (this.connectionFailedLock) {
/* 1358 */       force = this.forceClose;
/* 1359 */       this.forceClose = false;
/* 1360 */       this.connectionFailed = false;
/*      */     }
/* 1362 */     if (this.debug) {
/* 1363 */       this.out.println("DEBUG: IMAPStore cleanup, force " + force);
/*      */     }
/* 1365 */     Vector foldersCopy = null;
/* 1366 */     boolean done = true;
/*      */     while (true)
/*      */     {
/* 1378 */       synchronized (this.pool) {
/* 1379 */         if (this.pool.folders != null) {
/* 1380 */           done = false;
/* 1381 */           foldersCopy = this.pool.folders;
/* 1382 */           this.pool.folders = null;
/*      */         } else {
/* 1384 */           done = true;
/*      */         }
/*      */       }
/* 1387 */       if (done)
/*      */       {
/*      */         break;
/*      */       }
/* 1391 */       int i = 0; for (int fsize = foldersCopy.size(); i < fsize; i++) {
/* 1392 */         IMAPFolder f = (IMAPFolder)foldersCopy.elementAt(i);
/*      */         try
/*      */         {
/* 1395 */           if (force) {
/* 1396 */             if (this.debug) {
/* 1397 */               this.out.println("DEBUG: force folder to close");
/*      */             }
/*      */ 
/* 1401 */             f.forceClose();
/*      */           } else {
/* 1403 */             if (this.debug)
/* 1404 */               this.out.println("DEBUG: close folder");
/* 1405 */             f.close(false);
/*      */           }
/*      */         }
/*      */         catch (MessagingException mex)
/*      */         {
/*      */         }
/*      */         catch (IllegalStateException ex)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/* 1416 */     synchronized (this.pool) {
/* 1417 */       emptyConnectionPool(force);
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/* 1422 */       super.close(); } catch (MessagingException mex) {
/*      */     }
/* 1424 */     if (this.debug)
/* 1425 */       this.out.println("DEBUG: IMAPStore cleanup done");
/*      */   }
/*      */ 
/*      */   public synchronized Folder getDefaultFolder()
/*      */     throws MessagingException
/*      */   {
/* 1433 */     checkConnected();
/* 1434 */     return new DefaultFolder(this);
/*      */   }
/*      */ 
/*      */   public synchronized Folder getFolder(String name)
/*      */     throws MessagingException
/*      */   {
/* 1442 */     checkConnected();
/* 1443 */     return new IMAPFolder(name, 65535, this);
/*      */   }
/*      */ 
/*      */   public synchronized Folder getFolder(URLName url)
/*      */     throws MessagingException
/*      */   {
/* 1451 */     checkConnected();
/* 1452 */     return new IMAPFolder(url.getFile(), 65535, this);
/*      */   }
/*      */ 
/*      */   public Folder[] getPersonalNamespaces()
/*      */     throws MessagingException
/*      */   {
/* 1462 */     Namespaces ns = getNamespaces();
/* 1463 */     if ((ns == null) || (ns.personal == null))
/* 1464 */       return super.getPersonalNamespaces();
/* 1465 */     return namespaceToFolders(ns.personal, null);
/*      */   }
/*      */ 
/*      */   public Folder[] getUserNamespaces(String user)
/*      */     throws MessagingException
/*      */   {
/* 1474 */     Namespaces ns = getNamespaces();
/* 1475 */     if ((ns == null) || (ns.otherUsers == null))
/* 1476 */       return super.getUserNamespaces(user);
/* 1477 */     return namespaceToFolders(ns.otherUsers, user);
/*      */   }
/*      */ 
/*      */   public Folder[] getSharedNamespaces()
/*      */     throws MessagingException
/*      */   {
/* 1485 */     Namespaces ns = getNamespaces();
/* 1486 */     if ((ns == null) || (ns.shared == null))
/* 1487 */       return super.getSharedNamespaces();
/* 1488 */     return namespaceToFolders(ns.shared, null);
/*      */   }
/*      */ 
/*      */   private synchronized Namespaces getNamespaces() throws MessagingException {
/* 1492 */     checkConnected();
/*      */ 
/* 1494 */     IMAPProtocol p = null;
/*      */ 
/* 1496 */     if (this.namespaces == null) {
/*      */       try {
/* 1498 */         p = getStoreProtocol();
/* 1499 */         this.namespaces = p.namespace();
/*      */       } catch (BadCommandException bex) {
/*      */       }
/*      */       catch (ConnectionException cex) {
/* 1503 */         throw new StoreClosedException(this, cex.getMessage());
/*      */       } catch (ProtocolException pex) {
/* 1505 */         throw new MessagingException(pex.getMessage(), pex);
/*      */       } finally {
/* 1507 */         releaseStoreProtocol(p);
/*      */       }
/*      */     }
/* 1510 */     return this.namespaces;
/*      */   }
/*      */ 
/*      */   private Folder[] namespaceToFolders(Namespaces.Namespace[] ns, String user)
/*      */   {
/* 1515 */     Folder[] fa = new Folder[ns.length];
/* 1516 */     for (int i = 0; i < fa.length; i++) {
/* 1517 */       String name = ns[i].prefix;
/* 1518 */       if (user == null)
/*      */       {
/* 1520 */         int len = name.length();
/* 1521 */         if ((len > 0) && (name.charAt(len - 1) == ns[i].delimiter))
/* 1522 */           name = name.substring(0, len - 1);
/*      */       }
/*      */       else {
/* 1525 */         name = name + user;
/*      */       }
/* 1527 */       fa[i] = new IMAPFolder(name, ns[i].delimiter, this, user == null);
/*      */     }
/* 1529 */     return fa;
/*      */   }
/*      */ 
/*      */   public synchronized Quota[] getQuota(String root)
/*      */     throws MessagingException
/*      */   {
/* 1550 */     checkConnected();
/* 1551 */     Quota[] qa = null;
/*      */ 
/* 1553 */     IMAPProtocol p = null;
/*      */     try {
/* 1555 */       p = getStoreProtocol();
/* 1556 */       qa = p.getQuotaRoot(root);
/*      */     } catch (BadCommandException bex) {
/* 1558 */       throw new MessagingException("QUOTA not supported", bex);
/*      */     } catch (ConnectionException cex) {
/* 1560 */       throw new StoreClosedException(this, cex.getMessage());
/*      */     } catch (ProtocolException pex) {
/* 1562 */       throw new MessagingException(pex.getMessage(), pex);
/*      */     } finally {
/* 1564 */       releaseStoreProtocol(p);
/*      */     }
/* 1566 */     return qa;
/*      */   }
/*      */ 
/*      */   public synchronized void setQuota(Quota quota)
/*      */     throws MessagingException
/*      */   {
/* 1579 */     checkConnected();
/* 1580 */     IMAPProtocol p = null;
/*      */     try {
/* 1582 */       p = getStoreProtocol();
/* 1583 */       p.setQuota(quota);
/*      */     } catch (BadCommandException bex) {
/* 1585 */       throw new MessagingException("QUOTA not supported", bex);
/*      */     } catch (ConnectionException cex) {
/* 1587 */       throw new StoreClosedException(this, cex.getMessage());
/*      */     } catch (ProtocolException pex) {
/* 1589 */       throw new MessagingException(pex.getMessage(), pex);
/*      */     } finally {
/* 1591 */       releaseStoreProtocol(p);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void checkConnected() {
/* 1596 */     assert (Thread.holdsLock(this));
/* 1597 */     if (!super.isConnected())
/* 1598 */       throw new IllegalStateException("Not connected");
/*      */   }
/*      */ 
/*      */   public void handleResponse(Response r)
/*      */   {
/* 1606 */     if ((r.isOK()) || (r.isNO()) || (r.isBAD()) || (r.isBYE()))
/* 1607 */       handleResponseCode(r);
/* 1608 */     if (r.isBYE()) {
/* 1609 */       if (this.debug) {
/* 1610 */         this.out.println("DEBUG: IMAPStore connection dead");
/*      */       }
/*      */ 
/* 1613 */       synchronized (this.connectionFailedLock) {
/* 1614 */         this.connectionFailed = true;
/* 1615 */         if (r.isSynthetic())
/* 1616 */           this.forceClose = true;
/*      */       }
/* 1618 */       return; }  } 
/*      */   // ERROR //
/*      */   public void idle() throws MessagingException { // Byte code:
/*      */     //   0: aconst_null
/*      */     //   1: astore_1
/*      */     //   2: getstatic 208	com/sun/mail/imap/IMAPStore:$assertionsDisabled	Z
/*      */     //   5: ifne +21 -> 26
/*      */     //   8: aload_0
/*      */     //   9: getfield 101	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
/*      */     //   12: invokestatic 209	java/lang/Thread:holdsLock	(Ljava/lang/Object;)Z
/*      */     //   15: ifeq +11 -> 26
/*      */     //   18: new 210	java/lang/AssertionError
/*      */     //   21: dup
/*      */     //   22: invokespecial 211	java/lang/AssertionError:<init>	()V
/*      */     //   25: athrow
/*      */     //   26: aload_0
/*      */     //   27: dup
/*      */     //   28: astore_2
/*      */     //   29: monitorenter
/*      */     //   30: aload_0
/*      */     //   31: invokespecial 243	com/sun/mail/imap/IMAPStore:checkConnected	()V
/*      */     //   34: aload_2
/*      */     //   35: monitorexit
/*      */     //   36: goto +8 -> 44
/*      */     //   39: astore_3
/*      */     //   40: aload_2
/*      */     //   41: monitorexit
/*      */     //   42: aload_3
/*      */     //   43: athrow
/*      */     //   44: aload_0
/*      */     //   45: getfield 101	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
/*      */     //   48: dup
/*      */     //   49: astore_2
/*      */     //   50: monitorenter
/*      */     //   51: aload_0
/*      */     //   52: invokespecial 191	com/sun/mail/imap/IMAPStore:getStoreProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
/*      */     //   55: astore_1
/*      */     //   56: aload_0
/*      */     //   57: getfield 101	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
/*      */     //   60: invokestatic 281	com/sun/mail/imap/IMAPStore$ConnectionPool:access$1200	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)I
/*      */     //   63: ifne +19 -> 82
/*      */     //   66: aload_1
/*      */     //   67: invokevirtual 282	com/sun/mail/imap/protocol/IMAPProtocol:idleStart	()V
/*      */     //   70: aload_0
/*      */     //   71: getfield 101	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
/*      */     //   74: iconst_1
/*      */     //   75: invokestatic 283	com/sun/mail/imap/IMAPStore$ConnectionPool:access$1202	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;I)I
/*      */     //   78: pop
/*      */     //   79: goto +20 -> 99
/*      */     //   82: aload_0
/*      */     //   83: getfield 101	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
/*      */     //   86: invokevirtual 187	java/lang/Object:wait	()V
/*      */     //   89: goto +4 -> 93
/*      */     //   92: astore_3
/*      */     //   93: aload_2
/*      */     //   94: monitorexit
/*      */     //   95: jsr +183 -> 278
/*      */     //   98: return
/*      */     //   99: aload_0
/*      */     //   100: getfield 101	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
/*      */     //   103: aload_1
/*      */     //   104: invokestatic 284	com/sun/mail/imap/IMAPStore$ConnectionPool:access$1302	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;Lcom/sun/mail/imap/protocol/IMAPProtocol;)Lcom/sun/mail/imap/protocol/IMAPProtocol;
/*      */     //   107: pop
/*      */     //   108: aload_2
/*      */     //   109: monitorexit
/*      */     //   110: goto +10 -> 120
/*      */     //   113: astore 4
/*      */     //   115: aload_2
/*      */     //   116: monitorexit
/*      */     //   117: aload 4
/*      */     //   119: athrow
/*      */     //   120: aload_1
/*      */     //   121: invokevirtual 285	com/sun/mail/imap/protocol/IMAPProtocol:readIdleResponse	()Lcom/sun/mail/iap/Response;
/*      */     //   124: astore_2
/*      */     //   125: aload_0
/*      */     //   126: getfield 101	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
/*      */     //   129: dup
/*      */     //   130: astore_3
/*      */     //   131: monitorenter
/*      */     //   132: aload_2
/*      */     //   133: ifnull +11 -> 144
/*      */     //   136: aload_1
/*      */     //   137: aload_2
/*      */     //   138: invokevirtual 286	com/sun/mail/imap/protocol/IMAPProtocol:processIdleResponse	(Lcom/sun/mail/iap/Response;)Z
/*      */     //   141: ifne +24 -> 165
/*      */     //   144: aload_0
/*      */     //   145: getfield 101	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
/*      */     //   148: iconst_0
/*      */     //   149: invokestatic 283	com/sun/mail/imap/IMAPStore$ConnectionPool:access$1202	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;I)I
/*      */     //   152: pop
/*      */     //   153: aload_0
/*      */     //   154: getfield 101	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
/*      */     //   157: invokevirtual 206	java/lang/Object:notifyAll	()V
/*      */     //   160: aload_3
/*      */     //   161: monitorexit
/*      */     //   162: goto +43 -> 205
/*      */     //   165: aload_3
/*      */     //   166: monitorexit
/*      */     //   167: goto +10 -> 177
/*      */     //   170: astore 5
/*      */     //   172: aload_3
/*      */     //   173: monitorexit
/*      */     //   174: aload 5
/*      */     //   176: athrow
/*      */     //   177: aload_0
/*      */     //   178: getfield 18	com/sun/mail/imap/IMAPStore:enableImapEvents	Z
/*      */     //   181: ifeq +21 -> 202
/*      */     //   184: aload_2
/*      */     //   185: invokevirtual 287	com/sun/mail/iap/Response:isUnTagged	()Z
/*      */     //   188: ifeq +14 -> 202
/*      */     //   191: aload_0
/*      */     //   192: sipush 1000
/*      */     //   195: aload_2
/*      */     //   196: invokevirtual 288	com/sun/mail/iap/Response:toString	()Ljava/lang/String;
/*      */     //   199: invokevirtual 289	com/sun/mail/imap/IMAPStore:notifyStoreListeners	(ILjava/lang/String;)V
/*      */     //   202: goto -82 -> 120
/*      */     //   205: aload_0
/*      */     //   206: invokevirtual 290	com/sun/mail/imap/IMAPStore:getMinIdleTime	()I
/*      */     //   209: istore_2
/*      */     //   210: iload_2
/*      */     //   211: ifle +12 -> 223
/*      */     //   214: iload_2
/*      */     //   215: i2l
/*      */     //   216: invokestatic 291	java/lang/Thread:sleep	(J)V
/*      */     //   219: goto +4 -> 223
/*      */     //   222: astore_3
/*      */     //   223: jsr +55 -> 278
/*      */     //   226: goto +92 -> 318
/*      */     //   229: astore_2
/*      */     //   230: new 132	javax/mail/MessagingException
/*      */     //   233: dup
/*      */     //   234: ldc_w 292
/*      */     //   237: aload_2
/*      */     //   238: invokespecial 134	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
/*      */     //   241: athrow
/*      */     //   242: astore_2
/*      */     //   243: new 260	javax/mail/StoreClosedException
/*      */     //   246: dup
/*      */     //   247: aload_0
/*      */     //   248: aload_2
/*      */     //   249: invokevirtual 261	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
/*      */     //   252: invokespecial 262	javax/mail/StoreClosedException:<init>	(Ljavax/mail/Store;Ljava/lang/String;)V
/*      */     //   255: athrow
/*      */     //   256: astore_2
/*      */     //   257: new 132	javax/mail/MessagingException
/*      */     //   260: dup
/*      */     //   261: aload_2
/*      */     //   262: invokevirtual 133	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
/*      */     //   265: aload_2
/*      */     //   266: invokespecial 134	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
/*      */     //   269: athrow
/*      */     //   270: astore 6
/*      */     //   272: jsr +6 -> 278
/*      */     //   275: aload 6
/*      */     //   277: athrow
/*      */     //   278: astore 7
/*      */     //   280: aload_0
/*      */     //   281: getfield 101	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
/*      */     //   284: dup
/*      */     //   285: astore 8
/*      */     //   287: monitorenter
/*      */     //   288: aload_0
/*      */     //   289: getfield 101	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
/*      */     //   292: aconst_null
/*      */     //   293: invokestatic 284	com/sun/mail/imap/IMAPStore$ConnectionPool:access$1302	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;Lcom/sun/mail/imap/protocol/IMAPProtocol;)Lcom/sun/mail/imap/protocol/IMAPProtocol;
/*      */     //   296: pop
/*      */     //   297: aload 8
/*      */     //   299: monitorexit
/*      */     //   300: goto +11 -> 311
/*      */     //   303: astore 9
/*      */     //   305: aload 8
/*      */     //   307: monitorexit
/*      */     //   308: aload 9
/*      */     //   310: athrow
/*      */     //   311: aload_0
/*      */     //   312: aload_1
/*      */     //   313: invokespecial 227	com/sun/mail/imap/IMAPStore:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
/*      */     //   316: ret 7
/*      */     //   318: return
/*      */     //
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   30	36	39	finally
/*      */     //   39	42	39	finally
/*      */     //   82	89	92	java/lang/InterruptedException
/*      */     //   51	95	113	finally
/*      */     //   99	110	113	finally
/*      */     //   113	117	113	finally
/*      */     //   132	162	170	finally
/*      */     //   165	167	170	finally
/*      */     //   170	174	170	finally
/*      */     //   214	219	222	java/lang/InterruptedException
/*      */     //   44	98	229	com/sun/mail/iap/BadCommandException
/*      */     //   99	223	229	com/sun/mail/iap/BadCommandException
/*      */     //   44	98	242	com/sun/mail/iap/ConnectionException
/*      */     //   99	223	242	com/sun/mail/iap/ConnectionException
/*      */     //   44	98	256	com/sun/mail/iap/ProtocolException
/*      */     //   99	223	256	com/sun/mail/iap/ProtocolException
/*      */     //   44	98	270	finally
/*      */     //   99	226	270	finally
/*      */     //   229	275	270	finally
/*      */     //   288	300	303	finally
/*      */     //   303	308	303	finally } 
/* 1744 */   private void waitIfIdle() throws ProtocolException { assert (Thread.holdsLock(this.pool));
/* 1745 */     while (this.pool.idleState != 0) {
/* 1746 */       if (this.pool.idleState == 1) {
/* 1747 */         this.pool.idleProtocol.idleAbort();
/* 1748 */         this.pool.idleState = 2;
/*      */       }
/*      */       try
/*      */       {
/* 1752 */         this.pool.wait();
/*      */       }
/*      */       catch (InterruptedException ex)
/*      */       {
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   void handleResponseCode(Response r)
/*      */   {
/* 1762 */     String s = r.getRest();
/* 1763 */     boolean isAlert = false;
/* 1764 */     if (s.startsWith("[")) {
/* 1765 */       int i = s.indexOf(']');
/*      */ 
/* 1767 */       if ((i > 0) && (s.substring(0, i + 1).equalsIgnoreCase("[ALERT]"))) {
/* 1768 */         isAlert = true;
/*      */       }
/* 1770 */       s = s.substring(i + 1).trim();
/*      */     }
/* 1772 */     if (isAlert)
/* 1773 */       notifyStoreListeners(1, s);
/* 1774 */     else if ((r.isUnTagged()) && (s.length() > 0))
/*      */     {
/* 1778 */       notifyStoreListeners(2, s);
/*      */     }
/*      */   }
/*      */ 
/*      */   static class ConnectionPool
/*      */   {
/*  212 */     private Vector authenticatedConnections = new Vector();
/*      */     private Vector folders;
/*  218 */     private boolean storeConnectionInUse = false;
/*      */     private long lastTimePruned;
/*      */     private final boolean separateStoreConnection;
/*      */     private final long clientTimeoutInterval;
/*      */     private final long serverTimeoutInterval;
/*      */     private final int poolSize;
/*      */     private final long pruningInterval;
/*      */     private final boolean debug;
/*      */     private static final int RUNNING = 0;
/*      */     private static final int IDLE = 1;
/*      */     private static final int ABORTING = 2;
/*  287 */     private int idleState = 0;
/*      */     private IMAPProtocol idleProtocol;
/*      */ 
/*      */     ConnectionPool(String name, Session session)
/*      */     {
/*  291 */       this.lastTimePruned = System.currentTimeMillis();
/*      */ 
/*  293 */       PrintStream out = session.getDebugOut();
/*  294 */       if (out == null) {
/*  295 */         out = System.out;
/*      */       }
/*  297 */       this.debug = PropUtil.getBooleanSessionProperty(session, "mail." + name + ".connectionpool.debug", false);
/*      */ 
/*  301 */       int size = PropUtil.getIntSessionProperty(session, "mail." + name + ".connectionpoolsize", -1);
/*      */ 
/*  303 */       if (size > 0) {
/*  304 */         this.poolSize = size;
/*  305 */         if (this.debug)
/*  306 */           out.println("DEBUG: mail.imap.connectionpoolsize: " + this.poolSize);
/*      */       }
/*      */       else {
/*  309 */         this.poolSize = 1;
/*      */       }
/*      */ 
/*  312 */       int connectionPoolTimeout = PropUtil.getIntSessionProperty(session, "mail." + name + ".connectionpooltimeout", -1);
/*      */ 
/*  314 */       if (connectionPoolTimeout > 0) {
/*  315 */         this.clientTimeoutInterval = connectionPoolTimeout;
/*  316 */         if (this.debug)
/*  317 */           out.println("DEBUG: mail.imap.connectionpooltimeout: " + this.clientTimeoutInterval);
/*      */       }
/*      */       else {
/*  320 */         this.clientTimeoutInterval = 4500L;
/*      */       }
/*      */ 
/*  323 */       int serverTimeout = PropUtil.getIntSessionProperty(session, "mail." + name + ".servertimeout", -1);
/*      */ 
/*  325 */       if (serverTimeout > 0) {
/*  326 */         this.serverTimeoutInterval = serverTimeout;
/*  327 */         if (this.debug)
/*  328 */           out.println("DEBUG: mail.imap.servertimeout: " + this.serverTimeoutInterval);
/*      */       }
/*      */       else {
/*  331 */         this.serverTimeoutInterval = 1800000L;
/*      */       }
/*      */ 
/*  334 */       int pruning = PropUtil.getIntSessionProperty(session, "mail." + name + ".pruninginterval", -1);
/*      */ 
/*  336 */       if (pruning > 0) {
/*  337 */         this.pruningInterval = pruning;
/*  338 */         if (this.debug)
/*  339 */           out.println("DEBUG: mail.imap.pruninginterval: " + this.pruningInterval);
/*      */       }
/*      */       else {
/*  342 */         this.pruningInterval = 60000L;
/*      */       }
/*      */ 
/*  346 */       this.separateStoreConnection = PropUtil.getBooleanSessionProperty(session, "mail." + name + ".separatestoreconnection", false);
/*      */ 
/*  349 */       if ((this.debug) && (this.separateStoreConnection))
/*  350 */         out.println("DEBUG: dedicate a store connection");
/*      */     }
/*      */   }
/*      */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.IMAPStore
 * JD-Core Version:    0.6.1
 */