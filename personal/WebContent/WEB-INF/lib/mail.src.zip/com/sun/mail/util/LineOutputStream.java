/*    */ package com.sun.mail.util;
/*    */ 
/*    */ import java.io.FilterOutputStream;
/*    */ import java.io.OutputStream;
/*    */ import javax.mail.MessagingException;
/*    */ 
/*    */ public class LineOutputStream extends FilterOutputStream
/*    */ {
/* 57 */   private static byte[] newline = new byte[2];
/*    */ 
/*    */   public LineOutputStream(OutputStream out)
/*    */   {
/* 63 */     super(out);
/*    */   }
/*    */ 
/*    */   public void writeln(String s) throws MessagingException {
/*    */     try {
/* 68 */       byte[] bytes = ASCIIUtility.getBytes(s);
/* 69 */       this.out.write(bytes);
/* 70 */       this.out.write(newline);
/*    */     } catch (Exception ex) {
/* 72 */       throw new MessagingException("IOException", ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void writeln() throws MessagingException {
/*    */     try {
/* 78 */       this.out.write(newline);
/*    */     } catch (Exception ex) {
/* 80 */       throw new MessagingException("IOException", ex);
/*    */     }
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 58 */     newline[0] = 13;
/* 59 */     newline[1] = 10;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.util.LineOutputStream
 * JD-Core Version:    0.6.1
 */