/*    */ package com.sun.mail.imap.protocol;
/*    */ 
/*    */ import com.sun.mail.iap.ParsingException;
/*    */ 
/*    */ public class UID
/*    */   implements Item
/*    */ {
/* 49 */   static final char[] name = { 'U', 'I', 'D' };
/*    */   public int seqnum;
/*    */   public long uid;
/*    */ 
/*    */   public UID(FetchResponse r)
/*    */     throws ParsingException
/*    */   {
/* 58 */     this.seqnum = r.getNumber();
/* 59 */     r.skipSpaces();
/* 60 */     this.uid = r.readLong();
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.protocol.UID
 * JD-Core Version:    0.6.1
 */