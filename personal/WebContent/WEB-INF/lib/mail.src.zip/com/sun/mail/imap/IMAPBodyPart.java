/*     */ package com.sun.mail.imap;
/*     */ 
/*     */ import com.sun.mail.iap.ConnectionException;
/*     */ import com.sun.mail.iap.ProtocolException;
/*     */ import com.sun.mail.imap.protocol.BODY;
/*     */ import com.sun.mail.imap.protocol.BODYSTRUCTURE;
/*     */ import com.sun.mail.imap.protocol.IMAPProtocol;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Enumeration;
/*     */ import javax.activation.DataHandler;
/*     */ import javax.mail.FolderClosedException;
/*     */ import javax.mail.IllegalWriteException;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.Multipart;
/*     */ import javax.mail.internet.ContentType;
/*     */ import javax.mail.internet.InternetHeaders;
/*     */ import javax.mail.internet.MimeBodyPart;
/*     */ import javax.mail.internet.MimeUtility;
/*     */ import javax.mail.internet.ParameterList;
/*     */ 
/*     */ public class IMAPBodyPart extends MimeBodyPart
/*     */ {
/*     */   private IMAPMessage message;
/*     */   private BODYSTRUCTURE bs;
/*     */   private String sectionId;
/*     */   private String type;
/*     */   private String description;
/*  65 */   private boolean headersLoaded = false;
/*     */ 
/*     */   protected IMAPBodyPart(BODYSTRUCTURE bs, String sid, IMAPMessage message)
/*     */   {
/*  69 */     this.bs = bs;
/*  70 */     this.sectionId = sid;
/*  71 */     this.message = message;
/*     */ 
/*  73 */     ContentType ct = new ContentType(bs.type, bs.subtype, bs.cParams);
/*  74 */     this.type = ct.toString();
/*     */   }
/*     */ 
/*     */   protected void updateHeaders()
/*     */   {
/*     */   }
/*     */ 
/*     */   public int getSize()
/*     */     throws MessagingException
/*     */   {
/*  87 */     return this.bs.size;
/*     */   }
/*     */ 
/*     */   public int getLineCount() throws MessagingException {
/*  91 */     return this.bs.lines;
/*     */   }
/*     */ 
/*     */   public String getContentType() throws MessagingException {
/*  95 */     return this.type;
/*     */   }
/*     */ 
/*     */   public String getDisposition() throws MessagingException {
/*  99 */     return this.bs.disposition;
/*     */   }
/*     */ 
/*     */   public void setDisposition(String disposition) throws MessagingException {
/* 103 */     throw new IllegalWriteException("IMAPBodyPart is read-only");
/*     */   }
/*     */ 
/*     */   public String getEncoding() throws MessagingException {
/* 107 */     return this.bs.encoding;
/*     */   }
/*     */ 
/*     */   public String getContentID() throws MessagingException {
/* 111 */     return this.bs.id;
/*     */   }
/*     */ 
/*     */   public String getContentMD5() throws MessagingException {
/* 115 */     return this.bs.md5;
/*     */   }
/*     */ 
/*     */   public void setContentMD5(String md5) throws MessagingException {
/* 119 */     throw new IllegalWriteException("IMAPBodyPart is read-only");
/*     */   }
/*     */ 
/*     */   public String getDescription() throws MessagingException {
/* 123 */     if (this.description != null) {
/* 124 */       return this.description;
/*     */     }
/* 126 */     if (this.bs.description == null)
/* 127 */       return null;
/*     */     try
/*     */     {
/* 130 */       this.description = MimeUtility.decodeText(this.bs.description);
/*     */     } catch (UnsupportedEncodingException ex) {
/* 132 */       this.description = this.bs.description;
/*     */     }
/*     */ 
/* 135 */     return this.description;
/*     */   }
/*     */ 
/*     */   public void setDescription(String description, String charset) throws MessagingException
/*     */   {
/* 140 */     throw new IllegalWriteException("IMAPBodyPart is read-only");
/*     */   }
/*     */ 
/*     */   public String getFileName() throws MessagingException {
/* 144 */     String filename = null;
/* 145 */     if (this.bs.dParams != null)
/* 146 */       filename = this.bs.dParams.get("filename");
/* 147 */     if ((filename == null) && (this.bs.cParams != null))
/* 148 */       filename = this.bs.cParams.get("name");
/* 149 */     return filename;
/*     */   }
/*     */ 
/*     */   public void setFileName(String filename) throws MessagingException {
/* 153 */     throw new IllegalWriteException("IMAPBodyPart is read-only");
/*     */   }
/*     */ 
/*     */   protected InputStream getContentStream() throws MessagingException {
/* 157 */     InputStream is = null;
/* 158 */     boolean pk = this.message.getPeek();
/*     */ 
/* 161 */     synchronized (this.message.getMessageCacheLock()) {
/*     */       try {
/* 163 */         IMAPProtocol p = this.message.getProtocol();
/*     */ 
/* 166 */         this.message.checkExpunged();
/*     */ 
/* 168 */         if ((p.isREV1()) && (this.message.getFetchBlockSize() != -1)) {
/* 169 */           return new IMAPInputStream(this.message, this.sectionId, this.bs.size, pk);
/*     */         }
/*     */ 
/* 173 */         int seqnum = this.message.getSequenceNumber();
/*     */         BODY b;
/*     */         BODY b;
/* 175 */         if (pk)
/* 176 */           b = p.peekBody(seqnum, this.sectionId);
/*     */         else
/* 178 */           b = p.fetchBody(seqnum, this.sectionId);
/* 179 */         if (b != null)
/* 180 */           is = b.getByteArrayInputStream();
/*     */       } catch (ConnectionException cex) {
/* 182 */         throw new FolderClosedException(this.message.getFolder(), cex.getMessage());
/*     */       }
/*     */       catch (ProtocolException pex) {
/* 185 */         throw new MessagingException(pex.getMessage(), pex);
/*     */       }
/*     */     }
/*     */ 
/* 189 */     if (is == null) {
/* 190 */       throw new MessagingException("No content");
/*     */     }
/* 192 */     return is;
/*     */   }
/*     */ 
/*     */   public synchronized DataHandler getDataHandler() throws MessagingException
/*     */   {
/* 197 */     if (this.dh == null) {
/* 198 */       if (this.bs.isMulti()) {
/* 199 */         this.dh = new DataHandler(new IMAPMultipartDataSource(this, this.bs.bodies, this.sectionId, this.message));
/*     */       }
/* 203 */       else if ((this.bs.isNested()) && (this.message.isREV1())) {
/* 204 */         this.dh = new DataHandler(new IMAPNestedMessage(this.message, this.bs.bodies[0], this.bs.envelope, this.sectionId), this.type);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 213 */     return super.getDataHandler();
/*     */   }
/*     */ 
/*     */   public void setDataHandler(DataHandler content) throws MessagingException {
/* 217 */     throw new IllegalWriteException("IMAPBodyPart is read-only");
/*     */   }
/*     */ 
/*     */   public void setContent(Object o, String type) throws MessagingException {
/* 221 */     throw new IllegalWriteException("IMAPBodyPart is read-only");
/*     */   }
/*     */ 
/*     */   public void setContent(Multipart mp) throws MessagingException {
/* 225 */     throw new IllegalWriteException("IMAPBodyPart is read-only");
/*     */   }
/*     */ 
/*     */   public String[] getHeader(String name) throws MessagingException {
/* 229 */     loadHeaders();
/* 230 */     return super.getHeader(name);
/*     */   }
/*     */ 
/*     */   public void setHeader(String name, String value) throws MessagingException
/*     */   {
/* 235 */     throw new IllegalWriteException("IMAPBodyPart is read-only");
/*     */   }
/*     */ 
/*     */   public void addHeader(String name, String value) throws MessagingException
/*     */   {
/* 240 */     throw new IllegalWriteException("IMAPBodyPart is read-only");
/*     */   }
/*     */ 
/*     */   public void removeHeader(String name) throws MessagingException {
/* 244 */     throw new IllegalWriteException("IMAPBodyPart is read-only");
/*     */   }
/*     */ 
/*     */   public Enumeration getAllHeaders() throws MessagingException {
/* 248 */     loadHeaders();
/* 249 */     return super.getAllHeaders();
/*     */   }
/*     */ 
/*     */   public Enumeration getMatchingHeaders(String[] names) throws MessagingException
/*     */   {
/* 254 */     loadHeaders();
/* 255 */     return super.getMatchingHeaders(names);
/*     */   }
/*     */ 
/*     */   public Enumeration getNonMatchingHeaders(String[] names) throws MessagingException
/*     */   {
/* 260 */     loadHeaders();
/* 261 */     return super.getNonMatchingHeaders(names);
/*     */   }
/*     */ 
/*     */   public void addHeaderLine(String line) throws MessagingException {
/* 265 */     throw new IllegalWriteException("IMAPBodyPart is read-only");
/*     */   }
/*     */ 
/*     */   public Enumeration getAllHeaderLines() throws MessagingException {
/* 269 */     loadHeaders();
/* 270 */     return super.getAllHeaderLines();
/*     */   }
/*     */ 
/*     */   public Enumeration getMatchingHeaderLines(String[] names) throws MessagingException
/*     */   {
/* 275 */     loadHeaders();
/* 276 */     return super.getMatchingHeaderLines(names);
/*     */   }
/*     */ 
/*     */   public Enumeration getNonMatchingHeaderLines(String[] names) throws MessagingException
/*     */   {
/* 281 */     loadHeaders();
/* 282 */     return super.getNonMatchingHeaderLines(names);
/*     */   }
/*     */ 
/*     */   private synchronized void loadHeaders() throws MessagingException {
/* 286 */     if (this.headersLoaded) {
/* 287 */       return;
/*     */     }
/* 289 */     if (this.headers == null) {
/* 290 */       this.headers = new InternetHeaders();
/*     */     }
/*     */ 
/* 295 */     synchronized (this.message.getMessageCacheLock()) {
/*     */       try {
/* 297 */         IMAPProtocol p = this.message.getProtocol();
/*     */ 
/* 300 */         this.message.checkExpunged();
/*     */ 
/* 302 */         if (p.isREV1()) {
/* 303 */           int seqnum = this.message.getSequenceNumber();
/* 304 */           BODY b = p.peekBody(seqnum, this.sectionId + ".MIME");
/*     */ 
/* 306 */           if (b == null) {
/* 307 */             throw new MessagingException("Failed to fetch headers");
/*     */           }
/* 309 */           ByteArrayInputStream bis = b.getByteArrayInputStream();
/* 310 */           if (bis == null) {
/* 311 */             throw new MessagingException("Failed to fetch headers");
/*     */           }
/* 313 */           this.headers.load(bis);
/*     */         }
/*     */         else
/*     */         {
/* 322 */           this.headers.addHeader("Content-Type", this.type);
/*     */ 
/* 324 */           this.headers.addHeader("Content-Transfer-Encoding", this.bs.encoding);
/*     */ 
/* 326 */           if (this.bs.description != null) {
/* 327 */             this.headers.addHeader("Content-Description", this.bs.description);
/*     */           }
/*     */ 
/* 330 */           if (this.bs.id != null) {
/* 331 */             this.headers.addHeader("Content-ID", this.bs.id);
/*     */           }
/* 333 */           if (this.bs.md5 != null)
/* 334 */             this.headers.addHeader("Content-MD5", this.bs.md5);
/*     */         }
/*     */       } catch (ConnectionException cex) {
/* 337 */         throw new FolderClosedException(this.message.getFolder(), cex.getMessage());
/*     */       }
/*     */       catch (ProtocolException pex) {
/* 340 */         throw new MessagingException(pex.getMessage(), pex);
/*     */       }
/*     */     }
/* 343 */     this.headersLoaded = true;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.IMAPBodyPart
 * JD-Core Version:    0.6.1
 */