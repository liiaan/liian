package com.sun.mail.iap;

public abstract interface ResponseHandler
{
  public abstract void handleResponse(Response paramResponse);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.iap.ResponseHandler
 * JD-Core Version:    0.6.1
 */