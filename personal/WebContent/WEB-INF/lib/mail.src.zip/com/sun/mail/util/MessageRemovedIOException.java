/*    */ package com.sun.mail.util;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class MessageRemovedIOException extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = 4280468026581616424L;
/*    */ 
/*    */   public MessageRemovedIOException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MessageRemovedIOException(String s)
/*    */   {
/* 67 */     super(s);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.util.MessageRemovedIOException
 * JD-Core Version:    0.6.1
 */