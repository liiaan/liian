/*     */ package com.sun.mail.imap.protocol;
/*     */ 
/*     */ import com.sun.mail.iap.Protocol;
/*     */ import com.sun.mail.iap.ProtocolException;
/*     */ import com.sun.mail.iap.Response;
/*     */ import com.sun.mail.util.ASCIIUtility;
/*     */ import java.io.IOException;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class IMAPResponse extends Response
/*     */ {
/*     */   private String key;
/*     */   private int number;
/*     */ 
/*     */   public IMAPResponse(Protocol c)
/*     */     throws IOException, ProtocolException
/*     */   {
/*  56 */     super(c);
/*     */ 
/*  59 */     if ((isUnTagged()) && (!isOK()) && (!isNO()) && (!isBAD()) && (!isBYE())) {
/*  60 */       this.key = readAtom();
/*     */       try
/*     */       {
/*  64 */         this.number = Integer.parseInt(this.key);
/*  65 */         this.key = readAtom();
/*     */       }
/*     */       catch (NumberFormatException ne)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public IMAPResponse(IMAPResponse r) {
/*  74 */     super(r);
/*  75 */     this.key = r.key;
/*  76 */     this.number = r.number;
/*     */   }
/*     */ 
/*     */   public String[] readSimpleList()
/*     */   {
/*  86 */     skipSpaces();
/*     */ 
/*  88 */     if (this.buffer[this.index] != 40)
/*  89 */       return null;
/*  90 */     this.index += 1;
/*     */ 
/*  92 */     Vector v = new Vector();
/*     */ 
/*  94 */     for (int start = this.index; this.buffer[this.index] != 41; this.index += 1) {
/*  95 */       if (this.buffer[this.index] == 32) {
/*  96 */         v.addElement(ASCIIUtility.toString(this.buffer, start, this.index));
/*  97 */         start = this.index + 1;
/*     */       }
/*     */     }
/* 100 */     if (this.index > start)
/* 101 */       v.addElement(ASCIIUtility.toString(this.buffer, start, this.index));
/* 102 */     this.index += 1;
/*     */ 
/* 104 */     int size = v.size();
/* 105 */     if (size > 0) {
/* 106 */       String[] s = new String[size];
/* 107 */       v.copyInto(s);
/* 108 */       return s;
/*     */     }
/* 110 */     return null;
/*     */   }
/*     */ 
/*     */   public String getKey() {
/* 114 */     return this.key;
/*     */   }
/*     */ 
/*     */   public boolean keyEquals(String k) {
/* 118 */     if ((this.key != null) && (this.key.equalsIgnoreCase(k))) {
/* 119 */       return true;
/*     */     }
/* 121 */     return false;
/*     */   }
/*     */ 
/*     */   public int getNumber() {
/* 125 */     return this.number;
/*     */   }
/*     */ 
/*     */   public static IMAPResponse readResponse(Protocol p) throws IOException, ProtocolException
/*     */   {
/* 130 */     IMAPResponse r = new IMAPResponse(p);
/* 131 */     if (r.keyEquals("FETCH"))
/* 132 */       r = new FetchResponse(r);
/* 133 */     return r;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.protocol.IMAPResponse
 * JD-Core Version:    0.6.1
 */