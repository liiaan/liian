/*    */ package com.sun.mail.imap.protocol;
/*    */ 
/*    */ import com.sun.mail.iap.Argument;
/*    */ import com.sun.mail.iap.ByteArray;
/*    */ import com.sun.mail.iap.ProtocolException;
/*    */ import com.sun.mail.iap.Response;
/*    */ import com.sun.mail.util.ASCIIUtility;
/*    */ import com.sun.mail.util.BASE64DecoderStream;
/*    */ import com.sun.mail.util.BASE64EncoderStream;
/*    */ import com.sun.mail.util.PropUtil;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.io.PrintStream;
/*    */ import java.util.Properties;
/*    */ import java.util.Vector;
/*    */ import javax.security.auth.callback.Callback;
/*    */ import javax.security.auth.callback.CallbackHandler;
/*    */ import javax.security.auth.callback.NameCallback;
/*    */ import javax.security.auth.callback.PasswordCallback;
/*    */ import javax.security.sasl.RealmCallback;
/*    */ import javax.security.sasl.RealmChoiceCallback;
/*    */ import javax.security.sasl.Sasl;
/*    */ import javax.security.sasl.SaslClient;
/*    */ import javax.security.sasl.SaslException;
/*    */ 
/*    */ public class IMAPSaslAuthenticator
/*    */   implements SaslAuthenticator
/*    */ {
/*    */   private IMAPProtocol pr;
/*    */   private String name;
/*    */   private Properties props;
/*    */   private boolean debug;
/*    */   private PrintStream out;
/*    */   private String host;
/*    */ 
/*    */   public IMAPSaslAuthenticator(IMAPProtocol pr, String name, Properties props, boolean debug, PrintStream out, String host)
/*    */   {
/* 65 */     this.pr = pr;
/* 66 */     this.name = name;
/* 67 */     this.props = props;
/* 68 */     this.debug = debug;
/* 69 */     this.out = out;
/* 70 */     this.host = host;
/*    */   }
/*    */ 
/*    */   public boolean authenticate(String[] mechs, final String realm, String authzid, final String u, final String p)
/*    */     throws ProtocolException
/*    */   {
/* 77 */     synchronized (this.pr) {
/* 78 */       Vector v = new Vector();
/* 79 */       String tag = null;
/* 80 */       Response r = null;
/* 81 */       boolean done = false;
/* 82 */       if (this.debug) {
/* 83 */         this.out.print("IMAP SASL DEBUG: Mechanisms:");
/* 84 */         for (int i = 0; i < mechs.length; i++)
/* 85 */           this.out.print(" " + mechs[i]);
/* 86 */         this.out.println();
/*    */       }
/*    */ 
/* 90 */       CallbackHandler cbh = new CallbackHandler() { private final String val$u;
/*    */         private final String val$p;
/*    */         private final String val$realm;
/*    */ 
/* 92 */         public void handle(Callback[] callbacks) { if (IMAPSaslAuthenticator.this.debug) {
/* 93 */             IMAPSaslAuthenticator.this.out.println("IMAP SASL DEBUG: callback length: " + callbacks.length);
/*    */           }
/* 95 */           for (int i = 0; i < callbacks.length; i++) {
/* 96 */             if (IMAPSaslAuthenticator.this.debug) {
/* 97 */               IMAPSaslAuthenticator.this.out.println("IMAP SASL DEBUG: callback " + i + ": " + callbacks[i]);
/*    */             }
/* 99 */             if ((callbacks[i] instanceof NameCallback)) {
/* 100 */               NameCallback ncb = (NameCallback)callbacks[i];
/* 101 */               ncb.setName(u);
/* 102 */             } else if ((callbacks[i] instanceof PasswordCallback)) {
/* 103 */               PasswordCallback pcb = (PasswordCallback)callbacks[i];
/* 104 */               pcb.setPassword(p.toCharArray());
/* 105 */             } else if ((callbacks[i] instanceof RealmCallback)) {
/* 106 */               RealmCallback rcb = (RealmCallback)callbacks[i];
/* 107 */               rcb.setText(realm != null ? realm : rcb.getDefaultText());
/*    */             }
/* 109 */             else if ((callbacks[i] instanceof RealmChoiceCallback)) {
/* 110 */               RealmChoiceCallback rcb = (RealmChoiceCallback)callbacks[i];
/*    */ 
/* 112 */               if (realm == null) {
/* 113 */                 rcb.setSelectedIndex(rcb.getDefaultChoice());
/*    */               }
/*    */               else {
/* 116 */                 String[] choices = rcb.getChoices();
/* 117 */                 for (int k = 0; k < choices.length; k++)
/* 118 */                   if (choices[k].equals(realm)) {
/* 119 */                     rcb.setSelectedIndex(k);
/* 120 */                     break;
/*    */                   }
/*    */               }
/*    */             }
/*    */           } }
/*    */       };
/*    */       SaslClient sc;
/*    */       try
/*    */       {
/* 130 */         sc = Sasl.createSaslClient(mechs, authzid, this.name, this.host, this.props, cbh);
/*    */       }
/*    */       catch (SaslException sex) {
/* 133 */         if (this.debug) {
/* 134 */           this.out.println("IMAP SASL DEBUG: Failed to create SASL client: " + sex);
/*    */         }
/* 136 */         return false;
/*    */       }
/* 138 */       if (sc == null) {
/* 139 */         if (this.debug)
/* 140 */           this.out.println("IMAP SASL DEBUG: No SASL support");
/* 141 */         return false;
/*    */       }
/* 143 */       if (this.debug) {
/* 144 */         this.out.println("IMAP SASL DEBUG: SASL client " + sc.getMechanismName());
/*    */       }
/*    */       try
/*    */       {
/* 148 */         tag = this.pr.writeCommand("AUTHENTICATE " + sc.getMechanismName(), null);
/*    */       }
/*    */       catch (Exception ex) {
/* 151 */         if (this.debug)
/* 152 */           this.out.println("IMAP SASL DEBUG: AUTHENTICATE Exception: " + ex);
/* 153 */         return false;
/*    */       }
/*    */ 
/* 156 */       OutputStream os = this.pr.getIMAPOutputStream();
/*    */ 
/* 171 */       ByteArrayOutputStream bos = new ByteArrayOutputStream();
/* 172 */       byte[] CRLF = { 13, 10 };
/*    */ 
/* 175 */       boolean isXGWTRUSTEDAPP = (sc.getMechanismName().equals("XGWTRUSTEDAPP")) && (PropUtil.getBooleanProperty(this.props, "mail." + this.name + ".sasl.xgwtrustedapphack.enable", true));
/*    */ 
/* 179 */       while (!done) {
/*    */         try {
/* 181 */           r = this.pr.readResponse();
/* 182 */           if (r.isContinuation()) {
/* 183 */             byte[] ba = null;
/* 184 */             if (!sc.isComplete()) {
/* 185 */               ba = r.readByteArray().getNewBytes();
/* 186 */               if (ba.length > 0)
/* 187 */                 ba = BASE64DecoderStream.decode(ba);
/* 188 */               if (this.debug) {
/* 189 */                 this.out.println("IMAP SASL DEBUG: challenge: " + ASCIIUtility.toString(ba, 0, ba.length) + " :");
/*    */               }
/* 191 */               ba = sc.evaluateChallenge(ba);
/*    */             }
/* 193 */             if (ba == null) {
/* 194 */               if (this.debug)
/* 195 */                 this.out.println("IMAP SASL DEBUG: no response");
/* 196 */               os.write(CRLF);
/* 197 */               os.flush();
/* 198 */               bos.reset();
/*    */             } else {
/* 200 */               if (this.debug) {
/* 201 */                 this.out.println("IMAP SASL DEBUG: response: " + ASCIIUtility.toString(ba, 0, ba.length) + " :");
/*    */               }
/* 203 */               ba = BASE64EncoderStream.encode(ba);
/* 204 */               if (isXGWTRUSTEDAPP)
/* 205 */                 bos.write("XGWTRUSTEDAPP ".getBytes());
/* 206 */               bos.write(ba);
/*    */ 
/* 208 */               bos.write(CRLF);
/* 209 */               os.write(bos.toByteArray());
/* 210 */               os.flush();
/* 211 */               bos.reset();
/*    */             }
/* 213 */           } else if ((r.isTagged()) && (r.getTag().equals(tag)))
/*    */           {
/* 215 */             done = true;
/* 216 */           } else if (r.isBYE()) {
/* 217 */             done = true;
/*    */           } else {
/* 219 */             v.addElement(r);
/*    */           }
/*    */         } catch (Exception ioex) { if (this.debug) {
/* 222 */             ioex.printStackTrace();
/*    */           }
/* 224 */           r = Response.byeResponse(ioex);
/* 225 */           done = true;
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/* 230 */       if (sc.isComplete()) {
/* 231 */         String qop = (String)sc.getNegotiatedProperty("javax.security.sasl.qop");
/* 232 */         if ((qop != null) && ((qop.equalsIgnoreCase("auth-int")) || (qop.equalsIgnoreCase("auth-conf"))))
/*    */         {
/* 235 */           if (this.debug) {
/* 236 */             this.out.println("IMAP SASL DEBUG: Mechanism requires integrity or confidentiality");
/*    */           }
/* 238 */           return false;
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/* 248 */       Response[] responses = new Response[v.size()];
/* 249 */       v.copyInto(responses);
/* 250 */       this.pr.notifyResponseHandlers(responses);
/*    */ 
/* 253 */       this.pr.handleResult(r);
/* 254 */       this.pr.setCapabilities(r);
/*    */ 
/* 261 */       if (isXGWTRUSTEDAPP) {
/* 262 */         Argument args = new Argument();
/* 263 */         args.writeString(authzid != null ? authzid : u);
/*    */ 
/* 265 */         responses = this.pr.command("LOGIN", args);
/*    */ 
/* 268 */         this.pr.notifyResponseHandlers(responses);
/*    */ 
/* 271 */         this.pr.handleResult(responses[(responses.length - 1)]);
/*    */ 
/* 273 */         this.pr.setCapabilities(responses[(responses.length - 1)]);
/*    */       }
/* 275 */       return true;
/*    */     }
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.protocol.IMAPSaslAuthenticator
 * JD-Core Version:    0.6.1
 */