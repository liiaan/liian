/*     */ package com.sun.mail.pop3;
/*     */ 
/*     */ import com.sun.mail.util.PropUtil;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import javax.mail.AuthenticationFailedException;
/*     */ import javax.mail.Folder;
/*     */ import javax.mail.MessagingException;
/*     */ import javax.mail.Session;
/*     */ import javax.mail.Store;
/*     */ import javax.mail.URLName;
/*     */ 
/*     */ public class POP3Store extends Store
/*     */ {
/*  60 */   private String name = "pop3";
/*  61 */   private int defaultPort = 110;
/*  62 */   private boolean isSSL = false;
/*     */ 
/*  64 */   private Protocol port = null;
/*  65 */   private POP3Folder portOwner = null;
/*  66 */   private String host = null;
/*  67 */   private int portNum = -1;
/*  68 */   private String user = null;
/*  69 */   private String passwd = null;
/*  70 */   boolean rsetBeforeQuit = false;
/*  71 */   boolean disableTop = false;
/*  72 */   boolean forgetTopHeaders = false;
/*  73 */   Constructor messageConstructor = null;
/*     */ 
/*     */   public POP3Store(Session session, URLName url) {
/*  76 */     this(session, url, "pop3", false);
/*     */   }
/*     */ 
/*     */   public POP3Store(Session session, URLName url, String name, boolean isSSL)
/*     */   {
/*  81 */     super(session, url);
/*  82 */     if (url != null)
/*  83 */       name = url.getProtocol();
/*  84 */     this.name = name;
/*  85 */     if (!isSSL) {
/*  86 */       isSSL = PropUtil.getBooleanSessionProperty(session, "mail." + name + ".ssl.enable", false);
/*     */     }
/*  88 */     if (isSSL)
/*  89 */       this.defaultPort = 995;
/*     */     else
/*  91 */       this.defaultPort = 110;
/*  92 */     this.isSSL = isSSL;
/*     */ 
/*  94 */     this.rsetBeforeQuit = PropUtil.getBooleanSessionProperty(session, "mail." + name + ".rsetbeforequit", false);
/*     */ 
/*  97 */     this.disableTop = PropUtil.getBooleanSessionProperty(session, "mail." + name + ".disabletop", false);
/*     */ 
/* 100 */     this.forgetTopHeaders = PropUtil.getBooleanSessionProperty(session, "mail." + name + ".forgettopheaders", false);
/*     */ 
/* 103 */     String s = session.getProperty("mail." + name + ".message.class");
/* 104 */     if (s != null) {
/* 105 */       if (session.getDebug())
/* 106 */         session.getDebugOut().println("DEBUG: POP3 message class: " + s);
/*     */       try
/*     */       {
/* 109 */         ClassLoader cl = getClass().getClassLoader();
/*     */ 
/* 112 */         Class messageClass = null;
/*     */         try
/*     */         {
/* 117 */           messageClass = cl.loadClass(s);
/*     */         }
/*     */         catch (ClassNotFoundException ex1)
/*     */         {
/* 122 */           messageClass = Class.forName(s);
/*     */         }
/*     */ 
/* 125 */         Class[] c = { Folder.class, Integer.TYPE };
/* 126 */         this.messageConstructor = messageClass.getConstructor(c);
/*     */       } catch (Exception ex) {
/* 128 */         if (session.getDebug())
/* 129 */           session.getDebugOut().println("DEBUG: failed to load POP3 message class: " + ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected synchronized boolean protocolConnect(String host, int portNum, String user, String passwd)
/*     */     throws MessagingException
/*     */   {
/* 139 */     if ((host == null) || (passwd == null) || (user == null)) {
/* 140 */       return false;
/*     */     }
/*     */ 
/* 144 */     if (portNum == -1) {
/* 145 */       portNum = PropUtil.getIntSessionProperty(this.session, "mail." + this.name + ".port", -1);
/*     */     }
/*     */ 
/* 148 */     if (portNum == -1) {
/* 149 */       portNum = this.defaultPort;
/*     */     }
/* 151 */     this.host = host;
/* 152 */     this.portNum = portNum;
/* 153 */     this.user = user;
/* 154 */     this.passwd = passwd;
/*     */     try {
/* 156 */       this.port = getPort(null);
/*     */     } catch (EOFException eex) {
/* 158 */       throw new AuthenticationFailedException(eex.getMessage());
/*     */     } catch (IOException ioex) {
/* 160 */       throw new MessagingException("Connect failed", ioex);
/*     */     }
/*     */ 
/* 163 */     return true;
/*     */   }
/*     */ 
/*     */   public synchronized boolean isConnected()
/*     */   {
/* 179 */     if (!super.isConnected())
/*     */     {
/* 182 */       return false;
/* 183 */     }synchronized (this) {
/*     */       try {
/* 185 */         if (this.port == null)
/* 186 */           this.port = getPort(null);
/*     */         else
/* 188 */           this.port.noop();
/* 189 */         return true;
/*     */       }
/*     */       catch (IOException ioex) {
/*     */         try {
/* 193 */           super.close();
/*     */         }
/*     */         catch (MessagingException mex) {
/*     */         }
/*     */         finally {
/*     */         }
/*     */       }
/*     */     }
/* 201 */     label88: break label88;
/*     */   }
/*     */ 
/*     */   synchronized Protocol getPort(POP3Folder owner)
/*     */     throws IOException
/*     */   {
/* 207 */     if ((this.port != null) && (this.portOwner == null)) {
/* 208 */       this.portOwner = owner;
/* 209 */       return this.port;
/*     */     }
/*     */ 
/* 213 */     Protocol p = new Protocol(this.host, this.portNum, this.session.getDebug(), this.session.getDebugOut(), this.session.getProperties(), "mail." + this.name, this.isSSL);
/*     */ 
/* 217 */     String msg = null;
/* 218 */     if ((msg = p.login(this.user, this.passwd)) != null) {
/*     */       try {
/* 220 */         p.quit();
/*     */       }
/*     */       catch (IOException ioex)
/*     */       {
/*     */       }
/*     */       finally
/*     */       {
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 235 */     if ((this.port == null) && (owner != null)) {
/* 236 */       this.port = p;
/* 237 */       this.portOwner = owner;
/*     */     }
/* 239 */     if (this.portOwner == null)
/* 240 */       this.portOwner = owner;
/* 241 */     return p;
/*     */   }
/*     */ 
/*     */   synchronized void closePort(POP3Folder owner) {
/* 245 */     if (this.portOwner == owner) {
/* 246 */       this.port = null;
/* 247 */       this.portOwner = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void close() throws MessagingException {
/*     */     try {
/* 253 */       if (this.port != null)
/* 254 */         this.port.quit();
/*     */     } catch (IOException ioex) {
/*     */     } finally {
/* 257 */       this.port = null;
/*     */ 
/* 260 */       super.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public Folder getDefaultFolder() throws MessagingException {
/* 265 */     checkConnected();
/* 266 */     return new DefaultFolder(this);
/*     */   }
/*     */ 
/*     */   public Folder getFolder(String name)
/*     */     throws MessagingException
/*     */   {
/* 273 */     checkConnected();
/* 274 */     return new POP3Folder(this, name);
/*     */   }
/*     */ 
/*     */   public Folder getFolder(URLName url) throws MessagingException {
/* 278 */     checkConnected();
/* 279 */     return new POP3Folder(this, url.getFile());
/*     */   }
/*     */ 
/*     */   protected void finalize() throws Throwable {
/* 283 */     super.finalize();
/*     */ 
/* 285 */     if (this.port != null)
/* 286 */       close();
/*     */   }
/*     */ 
/*     */   private void checkConnected() throws MessagingException {
/* 290 */     if (!super.isConnected())
/* 291 */       throw new MessagingException("Not connected");
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.pop3.POP3Store
 * JD-Core Version:    0.6.1
 */