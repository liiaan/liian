/*     */ package com.sun.mail.iap;
/*     */ 
/*     */ class Atom
/*     */ {
/*     */   String string;
/*     */ 
/*     */   Atom(String s)
/*     */   {
/* 295 */     this.string = s;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.iap.Atom
 * JD-Core Version:    0.6.1
 */