/*    */ package com.sun.mail.imap.protocol;
/*    */ 
/*    */ import com.sun.mail.iap.ByteArray;
/*    */ import com.sun.mail.iap.ParsingException;
/*    */ import java.io.ByteArrayInputStream;
/*    */ 
/*    */ public class BODY
/*    */   implements Item
/*    */ {
/* 51 */   static final char[] name = { 'B', 'O', 'D', 'Y' };
/*    */   public int msgno;
/*    */   public ByteArray data;
/*    */   public String section;
/* 56 */   public int origin = 0;
/*    */ 
/*    */   public BODY(FetchResponse r)
/*    */     throws ParsingException
/*    */   {
/* 62 */     this.msgno = r.getNumber();
/*    */ 
/* 64 */     r.skipSpaces();
/*    */     int b;
/* 67 */     while ((b = r.readByte()) != 93) {
/* 68 */       if (b == 0) {
/* 69 */         throw new ParsingException("BODY parse error: missing ``]'' at section end");
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 74 */     if (r.readByte() == 60) {
/* 75 */       this.origin = r.readNumber();
/* 76 */       r.skip(1);
/*    */     }
/*    */ 
/* 79 */     this.data = r.readByteArray();
/*    */   }
/*    */ 
/*    */   public ByteArray getByteArray() {
/* 83 */     return this.data;
/*    */   }
/*    */ 
/*    */   public ByteArrayInputStream getByteArrayInputStream() {
/* 87 */     if (this.data != null) {
/* 88 */       return this.data.toByteArrayInputStream();
/*    */     }
/* 90 */     return null;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     com.sun.mail.imap.protocol.BODY
 * JD-Core Version:    0.6.1
 */