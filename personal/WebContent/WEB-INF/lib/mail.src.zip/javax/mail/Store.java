/*     */ package javax.mail;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import javax.mail.event.FolderEvent;
/*     */ import javax.mail.event.FolderListener;
/*     */ import javax.mail.event.StoreEvent;
/*     */ import javax.mail.event.StoreListener;
/*     */ 
/*     */ public abstract class Store extends Service
/*     */ {
/* 183 */   private volatile Vector storeListeners = null;
/*     */ 
/* 233 */   private volatile Vector folderListeners = null;
/*     */ 
/*     */   protected Store(Session session, URLName urlname)
/*     */   {
/*  70 */     super(session, urlname);
/*     */   }
/*     */ 
/*     */   public abstract Folder getDefaultFolder()
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract Folder getFolder(String paramString)
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract Folder getFolder(URLName paramURLName)
/*     */     throws MessagingException;
/*     */ 
/*     */   public Folder[] getPersonalNamespaces()
/*     */     throws MessagingException
/*     */   {
/* 141 */     return new Folder[] { getDefaultFolder() };
/*     */   }
/*     */ 
/*     */   public Folder[] getUserNamespaces(String user)
/*     */     throws MessagingException
/*     */   {
/* 162 */     return new Folder[0];
/*     */   }
/*     */ 
/*     */   public Folder[] getSharedNamespaces()
/*     */     throws MessagingException
/*     */   {
/* 179 */     return new Folder[0];
/*     */   }
/*     */ 
/*     */   public synchronized void addStoreListener(StoreListener l)
/*     */   {
/* 195 */     if (this.storeListeners == null)
/* 196 */       this.storeListeners = new Vector();
/* 197 */     this.storeListeners.addElement(l);
/*     */   }
/*     */ 
/*     */   public synchronized void removeStoreListener(StoreListener l)
/*     */   {
/* 210 */     if (this.storeListeners != null)
/* 211 */       this.storeListeners.removeElement(l);
/*     */   }
/*     */ 
/*     */   protected void notifyStoreListeners(int type, String message)
/*     */   {
/* 225 */     if (this.storeListeners == null) {
/* 226 */       return;
/*     */     }
/* 228 */     StoreEvent e = new StoreEvent(this, type, message);
/* 229 */     queueEvent(e, this.storeListeners);
/*     */   }
/*     */ 
/*     */   public synchronized void addFolderListener(FolderListener l)
/*     */   {
/* 248 */     if (this.folderListeners == null)
/* 249 */       this.folderListeners = new Vector();
/* 250 */     this.folderListeners.addElement(l);
/*     */   }
/*     */ 
/*     */   public synchronized void removeFolderListener(FolderListener l)
/*     */   {
/* 263 */     if (this.folderListeners != null)
/* 264 */       this.folderListeners.removeElement(l);
/*     */   }
/*     */ 
/*     */   protected void notifyFolderListeners(int type, Folder folder)
/*     */   {
/* 282 */     if (this.folderListeners == null) {
/* 283 */       return;
/*     */     }
/* 285 */     FolderEvent e = new FolderEvent(this, folder, type);
/* 286 */     queueEvent(e, this.folderListeners);
/*     */   }
/*     */ 
/*     */   protected void notifyFolderRenamedListeners(Folder oldF, Folder newF)
/*     */   {
/* 305 */     if (this.folderListeners == null) {
/* 306 */       return;
/*     */     }
/* 308 */     FolderEvent e = new FolderEvent(this, oldF, newF, 3);
/* 309 */     queueEvent(e, this.folderListeners);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.Store
 * JD-Core Version:    0.6.1
 */