/*     */ package javax.mail;
/*     */ 
/*     */ public class Quota
/*     */ {
/*     */   public String quotaRoot;
/*     */   public Resource[] resources;
/*     */ 
/*     */   public Quota(String quotaRoot)
/*     */   {
/*  99 */     this.quotaRoot = quotaRoot;
/*     */   }
/*     */ 
/*     */   public void setResourceLimit(String name, long limit)
/*     */   {
/* 109 */     if (this.resources == null) {
/* 110 */       this.resources = new Resource[1];
/* 111 */       this.resources[0] = new Resource(name, 0L, limit);
/* 112 */       return;
/*     */     }
/* 114 */     for (int i = 0; i < this.resources.length; i++) {
/* 115 */       if (this.resources[i].name.equalsIgnoreCase(name)) {
/* 116 */         this.resources[i].limit = limit;
/* 117 */         return;
/*     */       }
/*     */     }
/* 120 */     Resource[] ra = new Resource[this.resources.length + 1];
/* 121 */     System.arraycopy(this.resources, 0, ra, 0, this.resources.length);
/* 122 */     ra[(ra.length - 1)] = new Resource(name, 0L, limit);
/* 123 */     this.resources = ra;
/*     */   }
/*     */ 
/*     */   public static class Resource
/*     */   {
/*     */     public String name;
/*     */     public long usage;
/*     */     public long limit;
/*     */ 
/*     */     public Resource(String name, long usage, long limit)
/*     */     {
/*  76 */       this.name = name;
/*  77 */       this.usage = usage;
/*  78 */       this.limit = limit;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.Quota
 * JD-Core Version:    0.6.1
 */