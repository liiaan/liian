/*      */ package javax.mail;
/*      */ 
/*      */ import com.sun.mail.util.LineInputStream;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.net.InetAddress;
/*      */ import java.net.URL;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.security.PrivilegedActionException;
/*      */ import java.security.PrivilegedExceptionAction;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Properties;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.Vector;
/*      */ 
/*      */ public final class Session
/*      */ {
/*      */   private final Properties props;
/*      */   private final Authenticator authenticator;
/*  186 */   private final Hashtable authTable = new Hashtable();
/*  187 */   private boolean debug = false;
/*      */   private PrintStream out;
/*  189 */   private final Vector providers = new Vector();
/*  190 */   private final Hashtable providersByProtocol = new Hashtable();
/*  191 */   private final Hashtable providersByClassName = new Hashtable();
/*  192 */   private final Properties addressMap = new Properties();
/*      */ 
/*  195 */   private static Session defaultSession = null;
/*      */ 
/*      */   private Session(Properties props, Authenticator authenticator)
/*      */   {
/*  199 */     this.props = props;
/*  200 */     this.authenticator = authenticator;
/*      */ 
/*  202 */     if (Boolean.valueOf(props.getProperty("mail.debug")).booleanValue()) {
/*  203 */       this.debug = true;
/*      */     }
/*  205 */     if (this.debug)
/*  206 */       pr("DEBUG: JavaMail version 1.4.2");
/*      */     Class cl;
/*      */     Class cl;
/*  210 */     if (authenticator != null)
/*  211 */       cl = authenticator.getClass();
/*      */     else {
/*  213 */       cl = getClass();
/*      */     }
/*  215 */     loadProviders(cl);
/*  216 */     loadAddressMap(cl);
/*      */   }
/*      */ 
/*      */   public static Session getInstance(Properties props, Authenticator authenticator)
/*      */   {
/*  237 */     return new Session(props, authenticator);
/*      */   }
/*      */ 
/*      */   public static Session getInstance(Properties props)
/*      */   {
/*  254 */     return new Session(props, null);
/*      */   }
/*      */ 
/*      */   public static synchronized Session getDefaultInstance(Properties props, Authenticator authenticator)
/*      */   {
/*  303 */     if (defaultSession == null) {
/*  304 */       defaultSession = new Session(props, authenticator);
/*      */     }
/*  307 */     else if (defaultSession.authenticator != authenticator)
/*      */     {
/*  309 */       if ((defaultSession.authenticator == null) || (authenticator == null) || (defaultSession.authenticator.getClass().getClassLoader() != authenticator.getClass().getClassLoader()))
/*      */       {
/*  316 */         throw new SecurityException("Access to default session denied");
/*      */       }
/*      */     }
/*  319 */     return defaultSession;
/*      */   }
/*      */ 
/*      */   public static Session getDefaultInstance(Properties props)
/*      */   {
/*  344 */     return getDefaultInstance(props, null);
/*      */   }
/*      */ 
/*      */   public synchronized void setDebug(boolean debug)
/*      */   {
/*  363 */     this.debug = debug;
/*  364 */     if (debug)
/*  365 */       pr("DEBUG: setDebug: JavaMail version 1.4.2");
/*      */   }
/*      */ 
/*      */   public synchronized boolean getDebug()
/*      */   {
/*  374 */     return this.debug;
/*      */   }
/*      */ 
/*      */   public synchronized void setDebugOut(PrintStream out)
/*      */   {
/*  388 */     this.out = out;
/*      */   }
/*      */ 
/*      */   public synchronized PrintStream getDebugOut()
/*      */   {
/*  399 */     if (this.out == null) {
/*  400 */       return System.out;
/*      */     }
/*  402 */     return this.out;
/*      */   }
/*      */ 
/*      */   public synchronized Provider[] getProviders()
/*      */   {
/*  413 */     Provider[] _providers = new Provider[this.providers.size()];
/*  414 */     this.providers.copyInto(_providers);
/*  415 */     return _providers;
/*      */   }
/*      */ 
/*      */   public synchronized Provider getProvider(String protocol)
/*      */     throws NoSuchProviderException
/*      */   {
/*  435 */     if ((protocol == null) || (protocol.length() <= 0)) {
/*  436 */       throw new NoSuchProviderException("Invalid protocol: null");
/*      */     }
/*      */ 
/*  439 */     Provider _provider = null;
/*      */ 
/*  442 */     String _className = this.props.getProperty("mail." + protocol + ".class");
/*  443 */     if (_className != null) {
/*  444 */       if (this.debug) {
/*  445 */         pr("DEBUG: mail." + protocol + ".class property exists and points to " + _className);
/*      */       }
/*      */ 
/*  449 */       _provider = (Provider)this.providersByClassName.get(_className);
/*      */     }
/*      */ 
/*  452 */     if (_provider != null) {
/*  453 */       return _provider;
/*      */     }
/*      */ 
/*  456 */     _provider = (Provider)this.providersByProtocol.get(protocol);
/*      */ 
/*  459 */     if (_provider == null) {
/*  460 */       throw new NoSuchProviderException("No provider for " + protocol);
/*      */     }
/*  462 */     if (this.debug) {
/*  463 */       pr("DEBUG: getProvider() returning " + _provider.toString());
/*      */     }
/*      */ 
/*  466 */     return _provider;
/*      */   }
/*      */ 
/*      */   public synchronized void setProvider(Provider provider)
/*      */     throws NoSuchProviderException
/*      */   {
/*  481 */     if (provider == null) {
/*  482 */       throw new NoSuchProviderException("Can't set null provider");
/*      */     }
/*  484 */     this.providersByProtocol.put(provider.getProtocol(), provider);
/*  485 */     this.props.put("mail." + provider.getProtocol() + ".class", provider.getClassName());
/*      */   }
/*      */ 
/*      */   public Store getStore()
/*      */     throws NoSuchProviderException
/*      */   {
/*  501 */     return getStore(getProperty("mail.store.protocol"));
/*      */   }
/*      */ 
/*      */   public Store getStore(String protocol)
/*      */     throws NoSuchProviderException
/*      */   {
/*  515 */     return getStore(new URLName(protocol, null, -1, null, null, null));
/*      */   }
/*      */ 
/*      */   public Store getStore(URLName url)
/*      */     throws NoSuchProviderException
/*      */   {
/*  534 */     String protocol = url.getProtocol();
/*  535 */     Provider p = getProvider(protocol);
/*  536 */     return getStore(p, url);
/*      */   }
/*      */ 
/*      */   public Store getStore(Provider provider)
/*      */     throws NoSuchProviderException
/*      */   {
/*  549 */     return getStore(provider, null);
/*      */   }
/*      */ 
/*      */   private Store getStore(Provider provider, URLName url)
/*      */     throws NoSuchProviderException
/*      */   {
/*  569 */     if ((provider == null) || (provider.getType() != Provider.Type.STORE)) {
/*  570 */       throw new NoSuchProviderException("invalid provider");
/*      */     }
/*      */     try
/*      */     {
/*  574 */       return (Store)getService(provider, url); } catch (ClassCastException cce) {
/*      */     }
/*  576 */     throw new NoSuchProviderException("incorrect class");
/*      */   }
/*      */ 
/*      */   public Folder getFolder(URLName url)
/*      */     throws MessagingException
/*      */   {
/*  607 */     Store store = getStore(url);
/*  608 */     store.connect();
/*  609 */     return store.getFolder(url);
/*      */   }
/*      */ 
/*      */   public Transport getTransport()
/*      */     throws NoSuchProviderException
/*      */   {
/*  622 */     return getTransport(getProperty("mail.transport.protocol"));
/*      */   }
/*      */ 
/*      */   public Transport getTransport(String protocol)
/*      */     throws NoSuchProviderException
/*      */   {
/*  636 */     return getTransport(new URLName(protocol, null, -1, null, null, null));
/*      */   }
/*      */ 
/*      */   public Transport getTransport(URLName url)
/*      */     throws NoSuchProviderException
/*      */   {
/*  654 */     String protocol = url.getProtocol();
/*  655 */     Provider p = getProvider(protocol);
/*  656 */     return getTransport(p, url);
/*      */   }
/*      */ 
/*      */   public Transport getTransport(Provider provider)
/*      */     throws NoSuchProviderException
/*      */   {
/*  670 */     return getTransport(provider, null);
/*      */   }
/*      */ 
/*      */   public Transport getTransport(Address address)
/*      */     throws NoSuchProviderException
/*      */   {
/*  686 */     String transportProtocol = (String)this.addressMap.get(address.getType());
/*  687 */     if (transportProtocol == null) {
/*  688 */       throw new NoSuchProviderException("No provider for Address type: " + address.getType());
/*      */     }
/*      */ 
/*  691 */     return getTransport(transportProtocol);
/*      */   }
/*      */ 
/*      */   private Transport getTransport(Provider provider, URLName url)
/*      */     throws NoSuchProviderException
/*      */   {
/*  708 */     if ((provider == null) || (provider.getType() != Provider.Type.TRANSPORT)) {
/*  709 */       throw new NoSuchProviderException("invalid provider");
/*      */     }
/*      */     try
/*      */     {
/*  713 */       return (Transport)getService(provider, url); } catch (ClassCastException cce) {
/*      */     }
/*  715 */     throw new NoSuchProviderException("incorrect class");
/*      */   }
/*      */ 
/*      */   private Object getService(Provider provider, URLName url)
/*      */     throws NoSuchProviderException
/*      */   {
/*  734 */     if (provider == null) {
/*  735 */       throw new NoSuchProviderException("null");
/*      */     }
/*      */ 
/*  739 */     if (url == null) {
/*  740 */       url = new URLName(provider.getProtocol(), null, -1, null, null, null);
/*      */     }
/*      */ 
/*  744 */     Object service = null;
/*      */     ClassLoader cl;
/*      */     ClassLoader cl;
/*  748 */     if (this.authenticator != null)
/*  749 */       cl = this.authenticator.getClass().getClassLoader();
/*      */     else {
/*  751 */       cl = getClass().getClassLoader();
/*      */     }
/*      */ 
/*  754 */     Class serviceClass = null;
/*      */     try
/*      */     {
/*  757 */       ClassLoader ccl = getContextClassLoader();
/*  758 */       if (ccl != null)
/*      */         try {
/*  760 */           serviceClass = ccl.loadClass(provider.getClassName());
/*      */         }
/*      */         catch (ClassNotFoundException ex) {
/*      */         }
/*  764 */       if (serviceClass == null)
/*  765 */         serviceClass = cl.loadClass(provider.getClassName());
/*      */     }
/*      */     catch (Exception ex1)
/*      */     {
/*      */       try
/*      */       {
/*  771 */         serviceClass = Class.forName(provider.getClassName());
/*      */       }
/*      */       catch (Exception ex) {
/*  774 */         if (this.debug) ex.printStackTrace(getDebugOut());
/*  775 */         throw new NoSuchProviderException(provider.getProtocol());
/*      */       }
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  781 */       Class[] c = { Session.class, URLName.class };
/*  782 */       Constructor cons = serviceClass.getConstructor(c);
/*      */ 
/*  784 */       Object[] o = { this, url };
/*  785 */       service = cons.newInstance(o);
/*      */     }
/*      */     catch (Exception ex) {
/*  788 */       if (this.debug) ex.printStackTrace(getDebugOut());
/*  789 */       throw new NoSuchProviderException(provider.getProtocol());
/*      */     }
/*      */ 
/*  792 */     return service;
/*      */   }
/*      */ 
/*      */   public void setPasswordAuthentication(URLName url, PasswordAuthentication pw)
/*      */   {
/*  805 */     if (pw == null)
/*  806 */       this.authTable.remove(url);
/*      */     else
/*  808 */       this.authTable.put(url, pw);
/*      */   }
/*      */ 
/*      */   public PasswordAuthentication getPasswordAuthentication(URLName url)
/*      */   {
/*  818 */     return (PasswordAuthentication)this.authTable.get(url);
/*      */   }
/*      */ 
/*      */   public PasswordAuthentication requestPasswordAuthentication(InetAddress addr, int port, String protocol, String prompt, String defaultUserName)
/*      */   {
/*  844 */     if (this.authenticator != null) {
/*  845 */       return this.authenticator.requestPasswordAuthentication(addr, port, protocol, prompt, defaultUserName);
/*      */     }
/*      */ 
/*  848 */     return null;
/*      */   }
/*      */ 
/*      */   public Properties getProperties()
/*      */   {
/*  858 */     return this.props;
/*      */   }
/*      */ 
/*      */   public String getProperty(String name)
/*      */   {
/*  868 */     return this.props.getProperty(name);
/*      */   }
/*      */ 
/*      */   private void loadProviders(Class cl)
/*      */   {
/*  875 */     StreamLoader loader = new StreamLoader() {
/*      */       public void load(InputStream is) throws IOException {
/*  877 */         Session.this.loadProvidersFromStream(is);
/*      */       }
/*      */ 
/*      */     };
/*      */     try
/*      */     {
/*  883 */       String res = System.getProperty("java.home") + File.separator + "lib" + File.separator + "javamail.providers";
/*      */ 
/*  886 */       loadFile(res, loader);
/*      */     } catch (SecurityException sex) {
/*  888 */       if (this.debug) {
/*  889 */         pr("DEBUG: can't get java.home: " + sex);
/*      */       }
/*      */     }
/*      */ 
/*  893 */     loadAllResources("META-INF/javamail.providers", cl, loader);
/*      */ 
/*  896 */     loadResource("/META-INF/javamail.default.providers", cl, loader);
/*      */ 
/*  898 */     if (this.providers.size() == 0) {
/*  899 */       if (this.debug) {
/*  900 */         pr("DEBUG: failed to load any providers, using defaults");
/*      */       }
/*  902 */       addProvider(new Provider(Provider.Type.STORE, "imap", "com.sun.mail.imap.IMAPStore", "Sun Microsystems, Inc.", "1.4.2"));
/*      */ 
/*  905 */       addProvider(new Provider(Provider.Type.STORE, "imaps", "com.sun.mail.imap.IMAPSSLStore", "Sun Microsystems, Inc.", "1.4.2"));
/*      */ 
/*  908 */       addProvider(new Provider(Provider.Type.STORE, "pop3", "com.sun.mail.pop3.POP3Store", "Sun Microsystems, Inc.", "1.4.2"));
/*      */ 
/*  911 */       addProvider(new Provider(Provider.Type.STORE, "pop3s", "com.sun.mail.pop3.POP3SSLStore", "Sun Microsystems, Inc.", "1.4.2"));
/*      */ 
/*  914 */       addProvider(new Provider(Provider.Type.TRANSPORT, "smtp", "com.sun.mail.smtp.SMTPTransport", "Sun Microsystems, Inc.", "1.4.2"));
/*      */ 
/*  917 */       addProvider(new Provider(Provider.Type.TRANSPORT, "smtps", "com.sun.mail.smtp.SMTPSSLTransport", "Sun Microsystems, Inc.", "1.4.2"));
/*      */     }
/*      */ 
/*  922 */     if (this.debug)
/*      */     {
/*  924 */       pr("DEBUG: Tables of loaded providers");
/*  925 */       pr("DEBUG: Providers Listed By Class Name: " + this.providersByClassName.toString());
/*      */ 
/*  927 */       pr("DEBUG: Providers Listed By Protocol: " + this.providersByProtocol.toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   private void loadProvidersFromStream(InputStream is)
/*      */     throws IOException
/*      */   {
/*  934 */     if (is != null) {
/*  935 */       LineInputStream lis = new LineInputStream(is);
/*      */       String currLine;
/*  939 */       while ((currLine = lis.readLine()) != null)
/*      */       {
/*  941 */         if (!currLine.startsWith("#"))
/*      */         {
/*  943 */           Provider.Type type = null;
/*  944 */           String protocol = null; String className = null;
/*  945 */           String vendor = null; String version = null;
/*      */ 
/*  948 */           StringTokenizer tuples = new StringTokenizer(currLine, ";");
/*  949 */           while (tuples.hasMoreTokens()) {
/*  950 */             String currTuple = tuples.nextToken().trim();
/*      */ 
/*  953 */             int sep = currTuple.indexOf("=");
/*  954 */             if (currTuple.startsWith("protocol=")) {
/*  955 */               protocol = currTuple.substring(sep + 1);
/*  956 */             } else if (currTuple.startsWith("type=")) {
/*  957 */               String strType = currTuple.substring(sep + 1);
/*  958 */               if (strType.equalsIgnoreCase("store"))
/*  959 */                 type = Provider.Type.STORE;
/*  960 */               else if (strType.equalsIgnoreCase("transport"))
/*  961 */                 type = Provider.Type.TRANSPORT;
/*      */             }
/*  963 */             else if (currTuple.startsWith("class=")) {
/*  964 */               className = currTuple.substring(sep + 1);
/*  965 */             } else if (currTuple.startsWith("vendor=")) {
/*  966 */               vendor = currTuple.substring(sep + 1);
/*  967 */             } else if (currTuple.startsWith("version=")) {
/*  968 */               version = currTuple.substring(sep + 1);
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*  973 */           if ((type == null) || (protocol == null) || (className == null) || (protocol.length() <= 0) || (className.length() <= 0))
/*      */           {
/*  976 */             if (this.debug)
/*  977 */               pr("DEBUG: Bad provider entry: " + currLine);
/*      */           }
/*      */           else {
/*  980 */             Provider provider = new Provider(type, protocol, className, vendor, version);
/*      */ 
/*  984 */             addProvider(provider);
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void addProvider(Provider provider)
/*      */   {
/*  996 */     this.providers.addElement(provider);
/*  997 */     this.providersByClassName.put(provider.getClassName(), provider);
/*  998 */     if (!this.providersByProtocol.containsKey(provider.getProtocol()))
/*  999 */       this.providersByProtocol.put(provider.getProtocol(), provider);
/*      */   }
/*      */ 
/*      */   private void loadAddressMap(Class cl)
/*      */   {
/* 1005 */     StreamLoader loader = new StreamLoader() {
/*      */       public void load(InputStream is) throws IOException {
/* 1007 */         Session.this.addressMap.load(is);
/*      */       }
/*      */     };
/* 1012 */     loadResource("/META-INF/javamail.default.address.map", cl, loader);
/*      */ 
/* 1015 */     loadAllResources("META-INF/javamail.address.map", cl, loader);
/*      */     try
/*      */     {
/* 1019 */       String res = System.getProperty("java.home") + File.separator + "lib" + File.separator + "javamail.address.map";
/*      */ 
/* 1022 */       loadFile(res, loader);
/*      */     } catch (SecurityException sex) {
/* 1024 */       if (this.debug) {
/* 1025 */         pr("DEBUG: can't get java.home: " + sex);
/*      */       }
/*      */     }
/* 1028 */     if (this.addressMap.isEmpty()) {
/* 1029 */       if (this.debug)
/* 1030 */         pr("DEBUG: failed to load address map, using defaults");
/* 1031 */       this.addressMap.put("rfc822", "smtp");
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void setProtocolForAddress(String addresstype, String protocol)
/*      */   {
/* 1048 */     if (protocol == null)
/* 1049 */       this.addressMap.remove(addresstype);
/*      */     else
/* 1051 */       this.addressMap.put(addresstype, protocol);
/*      */   }
/*      */ 
/*      */   private void loadFile(String name, StreamLoader loader)
/*      */   {
/* 1058 */     InputStream clis = null;
/*      */     try {
/* 1060 */       clis = new BufferedInputStream(new FileInputStream(name));
/* 1061 */       loader.load(clis);
/* 1062 */       if (this.debug)
/* 1063 */         pr("DEBUG: successfully loaded file: " + name);
/*      */     } catch (FileNotFoundException fex) {
/*      */     }
/*      */     catch (IOException e) {
/* 1067 */       if (this.debug) {
/* 1068 */         pr("DEBUG: not loading file: " + name);
/* 1069 */         pr("DEBUG: " + e);
/*      */       }
/*      */     } catch (SecurityException sex) {
/* 1072 */       if (this.debug) {
/* 1073 */         pr("DEBUG: not loading file: " + name);
/* 1074 */         pr("DEBUG: " + sex);
/*      */       }
/*      */     } finally {
/*      */       try {
/* 1078 */         if (clis != null)
/* 1079 */           clis.close();
/*      */       }
/*      */       catch (IOException ex)
/*      */       {
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void loadResource(String name, Class cl, StreamLoader loader) {
/* 1088 */     InputStream clis = null;
/*      */     try {
/* 1090 */       clis = getResourceAsStream(cl, name);
/* 1091 */       if (clis != null) {
/* 1092 */         loader.load(clis);
/* 1093 */         if (this.debug) {
/* 1094 */           pr("DEBUG: successfully loaded resource: " + name);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/* 1102 */       if (this.debug)
/* 1103 */         pr("DEBUG: " + e);
/*      */     } catch (SecurityException sex) {
/* 1105 */       if (this.debug)
/* 1106 */         pr("DEBUG: " + sex);
/*      */     } finally {
/*      */       try {
/* 1109 */         if (clis != null)
/* 1110 */           clis.close();
/*      */       }
/*      */       catch (IOException ex)
/*      */       {
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void loadAllResources(String name, Class cl, StreamLoader loader) {
/* 1119 */     boolean anyLoaded = false;
/*      */     try
/*      */     {
/* 1122 */       ClassLoader cld = null;
/*      */ 
/* 1124 */       cld = getContextClassLoader();
/* 1125 */       if (cld == null)
/* 1126 */         cld = cl.getClassLoader();
/*      */       URL[] urls;
/*      */       URL[] urls;
/* 1127 */       if (cld != null)
/* 1128 */         urls = getResources(cld, name);
/*      */       else
/* 1130 */         urls = getSystemResources(name);
/* 1131 */       if (urls != null)
/* 1132 */         for (int i = 0; i < urls.length; i++) {
/* 1133 */           URL url = urls[i];
/* 1134 */           InputStream clis = null;
/* 1135 */           if (this.debug)
/* 1136 */             pr("DEBUG: URL " + url);
/*      */           try {
/* 1138 */             clis = openStream(url);
/* 1139 */             if (clis != null) {
/* 1140 */               loader.load(clis);
/* 1141 */               anyLoaded = true;
/* 1142 */               if (this.debug) {
/* 1143 */                 pr("DEBUG: successfully loaded resource: " + url);
/*      */               }
/*      */             }
/* 1146 */             else if (this.debug) {
/* 1147 */               pr("DEBUG: not loading resource: " + url);
/*      */             }
/*      */           } catch (FileNotFoundException fex) {
/*      */           }
/*      */           catch (IOException ioex) {
/* 1152 */             if (this.debug)
/* 1153 */               pr("DEBUG: " + ioex);
/*      */           } catch (SecurityException sex) {
/* 1155 */             if (this.debug)
/* 1156 */               pr("DEBUG: " + sex);
/*      */           } finally {
/*      */             try {
/* 1159 */               if (clis != null)
/* 1160 */                 clis.close();
/*      */             } catch (IOException cex) {
/*      */             }
/*      */           }
/*      */         }
/*      */     } catch (Exception ex) {
/* 1166 */       if (this.debug) {
/* 1167 */         pr("DEBUG: " + ex);
/*      */       }
/*      */     }
/*      */ 
/* 1171 */     if (!anyLoaded)
/*      */     {
/* 1176 */       loadResource("/" + name, cl, loader);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void pr(String str) {
/* 1181 */     getDebugOut().println(str);
/*      */   }
/*      */ 
/*      */   private static ClassLoader getContextClassLoader()
/*      */   {
/* 1189 */     return (ClassLoader)AccessController.doPrivileged(new PrivilegedAction()
/*      */     {
/*      */       public Object run() {
/* 1192 */         ClassLoader cl = null;
/*      */         try {
/* 1194 */           cl = Thread.currentThread().getContextClassLoader(); } catch (SecurityException ex) {
/*      */         }
/* 1196 */         return cl;
/*      */       }
/*      */     });
/*      */   }
/*      */ 
/*      */   private static InputStream getResourceAsStream(Class c, final String name) throws IOException
/*      */   {
/*      */     try {
/* 1204 */       return (InputStream)AccessController.doPrivileged(new PrivilegedExceptionAction() { private final Class val$c;
/*      */         private final String val$name;
/*      */ 
/* 1207 */         public Object run() throws IOException { return this.val$c.getResourceAsStream(name); } } );
/*      */     }
/*      */     catch (PrivilegedActionException e)
/*      */     {
/* 1211 */       throw ((IOException)e.getException());
/*      */     }
/*      */   }
/*      */ 
/*      */   private static URL[] getResources(ClassLoader cl, final String name) {
/* 1216 */     return (URL[])AccessController.doPrivileged(new PrivilegedAction() { private final ClassLoader val$cl;
/*      */       private final String val$name;
/*      */ 
/* 1219 */       public Object run() { URL[] ret = null;
/*      */         try {
/* 1221 */           Vector v = new Vector();
/* 1222 */           Enumeration e = this.val$cl.getResources(name);
/* 1223 */           while ((e != null) && (e.hasMoreElements())) {
/* 1224 */             URL url = (URL)e.nextElement();
/* 1225 */             if (url != null)
/* 1226 */               v.addElement(url);
/*      */           }
/* 1228 */           if (v.size() > 0) {
/* 1229 */             ret = new URL[v.size()];
/* 1230 */             v.copyInto(ret);
/*      */           }
/*      */         } catch (IOException ioex) {
/*      */         } catch (SecurityException ex) {  }
/*      */ 
/* 1234 */         return ret; }
/*      */     });
/*      */   }
/*      */ 
/*      */   private static URL[] getSystemResources(String name)
/*      */   {
/* 1240 */     return (URL[])AccessController.doPrivileged(new PrivilegedAction() {
/*      */       private final String val$name;
/*      */ 
/* 1243 */       public Object run() { URL[] ret = null;
/*      */         try {
/* 1245 */           Vector v = new Vector();
/* 1246 */           Enumeration e = ClassLoader.getSystemResources(this.val$name);
/* 1247 */           while ((e != null) && (e.hasMoreElements())) {
/* 1248 */             URL url = (URL)e.nextElement();
/* 1249 */             if (url != null)
/* 1250 */               v.addElement(url);
/*      */           }
/* 1252 */           if (v.size() > 0) {
/* 1253 */             ret = new URL[v.size()];
/* 1254 */             v.copyInto(ret);
/*      */           }
/*      */         } catch (IOException ioex) {
/*      */         } catch (SecurityException ex) {  }
/*      */ 
/* 1258 */         return ret; }
/*      */     });
/*      */   }
/*      */ 
/*      */   private static InputStream openStream(URL url) throws IOException
/*      */   {
/*      */     try {
/* 1265 */       return (InputStream)AccessController.doPrivileged(new PrivilegedExceptionAction() {
/*      */         private final URL val$url;
/*      */ 
/* 1268 */         public Object run() throws IOException { return this.val$url.openStream(); }
/*      */       });
/*      */     }
/*      */     catch (PrivilegedActionException e) {
/* 1272 */       throw ((IOException)e.getException());
/*      */     }
/*      */   }
/*      */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.Session
 * JD-Core Version:    0.6.1
 */