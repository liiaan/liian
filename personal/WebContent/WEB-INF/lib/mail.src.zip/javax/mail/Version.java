package javax.mail;

class Version
{
  public static final String version = "1.4.2";
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.Version
 * JD-Core Version:    0.6.1
 */