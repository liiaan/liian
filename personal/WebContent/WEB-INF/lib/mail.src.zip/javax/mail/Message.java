/*     */ package javax.mail;
/*     */ 
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.ObjectStreamException;
/*     */ import java.io.Serializable;
/*     */ import java.util.Date;
/*     */ import javax.mail.search.SearchTerm;
/*     */ 
/*     */ public abstract class Message
/*     */   implements Part
/*     */ {
/*  85 */   protected int msgnum = 0;
/*     */ 
/*  90 */   protected boolean expunged = false;
/*     */ 
/*  95 */   protected Folder folder = null;
/*     */ 
/* 100 */   protected Session session = null;
/*     */ 
/*     */   protected Message()
/*     */   {
/*     */   }
/*     */ 
/*     */   protected Message(Folder folder, int msgnum)
/*     */   {
/* 115 */     this.folder = folder;
/* 116 */     this.msgnum = msgnum;
/* 117 */     this.session = folder.store.session;
/*     */   }
/*     */ 
/*     */   protected Message(Session session)
/*     */   {
/* 127 */     this.session = session;
/*     */   }
/*     */ 
/*     */   public abstract Address[] getFrom()
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract void setFrom()
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract void setFrom(Address paramAddress)
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract void addFrom(Address[] paramArrayOfAddress)
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract Address[] getRecipients(RecipientType paramRecipientType)
/*     */     throws MessagingException;
/*     */ 
/*     */   public Address[] getAllRecipients()
/*     */     throws MessagingException
/*     */   {
/* 301 */     Address[] to = getRecipients(RecipientType.TO);
/* 302 */     Address[] cc = getRecipients(RecipientType.CC);
/* 303 */     Address[] bcc = getRecipients(RecipientType.BCC);
/*     */ 
/* 305 */     if ((cc == null) && (bcc == null)) {
/* 306 */       return to;
/*     */     }
/* 308 */     int numRecip = (to != null ? to.length : 0) + (cc != null ? cc.length : 0) + (bcc != null ? bcc.length : 0);
/*     */ 
/* 312 */     Address[] addresses = new Address[numRecip];
/* 313 */     int pos = 0;
/* 314 */     if (to != null) {
/* 315 */       System.arraycopy(to, 0, addresses, pos, to.length);
/* 316 */       pos += to.length;
/*     */     }
/* 318 */     if (cc != null) {
/* 319 */       System.arraycopy(cc, 0, addresses, pos, cc.length);
/* 320 */       pos += cc.length;
/*     */     }
/* 322 */     if (bcc != null) {
/* 323 */       System.arraycopy(bcc, 0, addresses, pos, bcc.length);
/* 324 */       pos += bcc.length;
/*     */     }
/* 326 */     return addresses;
/*     */   }
/*     */ 
/*     */   public abstract void setRecipients(RecipientType paramRecipientType, Address[] paramArrayOfAddress)
/*     */     throws MessagingException;
/*     */ 
/*     */   public void setRecipient(RecipientType type, Address address)
/*     */     throws MessagingException
/*     */   {
/* 360 */     Address[] a = new Address[1];
/* 361 */     a[0] = address;
/* 362 */     setRecipients(type, a);
/*     */   }
/*     */ 
/*     */   public abstract void addRecipients(RecipientType paramRecipientType, Address[] paramArrayOfAddress)
/*     */     throws MessagingException;
/*     */ 
/*     */   public void addRecipient(RecipientType type, Address address)
/*     */     throws MessagingException
/*     */   {
/* 394 */     Address[] a = new Address[1];
/* 395 */     a[0] = address;
/* 396 */     addRecipients(type, a);
/*     */   }
/*     */ 
/*     */   public Address[] getReplyTo()
/*     */     throws MessagingException
/*     */   {
/* 416 */     return getFrom();
/*     */   }
/*     */ 
/*     */   public void setReplyTo(Address[] addresses)
/*     */     throws MessagingException
/*     */   {
/* 440 */     throw new MethodNotSupportedException("setReplyTo not supported");
/*     */   }
/*     */ 
/*     */   public abstract String getSubject()
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract void setSubject(String paramString)
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract Date getSentDate()
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract void setSentDate(Date paramDate)
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract Date getReceivedDate()
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract Flags getFlags()
/*     */     throws MessagingException;
/*     */ 
/*     */   public boolean isSet(Flags.Flag flag)
/*     */     throws MessagingException
/*     */   {
/* 527 */     return getFlags().contains(flag);
/*     */   }
/*     */ 
/*     */   public abstract void setFlags(Flags paramFlags, boolean paramBoolean)
/*     */     throws MessagingException;
/*     */ 
/*     */   public void setFlag(Flags.Flag flag, boolean set)
/*     */     throws MessagingException
/*     */   {
/* 573 */     Flags f = new Flags(flag);
/* 574 */     setFlags(f, set);
/*     */   }
/*     */ 
/*     */   public int getMessageNumber()
/*     */   {
/* 591 */     return this.msgnum;
/*     */   }
/*     */ 
/*     */   protected void setMessageNumber(int msgnum)
/*     */   {
/* 599 */     this.msgnum = msgnum;
/*     */   }
/*     */ 
/*     */   public Folder getFolder()
/*     */   {
/* 610 */     return this.folder;
/*     */   }
/*     */ 
/*     */   public boolean isExpunged()
/*     */   {
/* 631 */     return this.expunged;
/*     */   }
/*     */ 
/*     */   protected void setExpunged(boolean expunged)
/*     */   {
/* 641 */     this.expunged = expunged;
/*     */   }
/*     */ 
/*     */   public abstract Message reply(boolean paramBoolean)
/*     */     throws MessagingException;
/*     */ 
/*     */   public abstract void saveChanges()
/*     */     throws MessagingException;
/*     */ 
/*     */   public boolean match(SearchTerm term)
/*     */     throws MessagingException
/*     */   {
/* 701 */     return term.match(this);
/*     */   }
/*     */ 
/*     */   public static class RecipientType
/*     */     implements Serializable
/*     */   {
/* 216 */     public static final RecipientType TO = new RecipientType("To");
/*     */ 
/* 220 */     public static final RecipientType CC = new RecipientType("Cc");
/*     */ 
/* 224 */     public static final RecipientType BCC = new RecipientType("Bcc");
/*     */     protected String type;
/*     */     private static final long serialVersionUID = -7479791750606340008L;
/*     */ 
/*     */     protected RecipientType(String type)
/*     */     {
/* 240 */       this.type = type;
/*     */     }
/*     */ 
/*     */     protected Object readResolve()
/*     */       throws ObjectStreamException
/*     */     {
/* 251 */       if (this.type.equals("To"))
/* 252 */         return TO;
/* 253 */       if (this.type.equals("Cc"))
/* 254 */         return CC;
/* 255 */       if (this.type.equals("Bcc")) {
/* 256 */         return BCC;
/*     */       }
/* 258 */       throw new InvalidObjectException("Attempt to resolve unknown RecipientType: " + this.type);
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 263 */       return this.type;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.Message
 * JD-Core Version:    0.6.1
 */