package javax.mail;

import java.io.IOException;
import java.io.InputStream;

abstract interface StreamLoader
{
  public abstract void load(InputStream paramInputStream)
    throws IOException;
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.StreamLoader
 * JD-Core Version:    0.6.1
 */