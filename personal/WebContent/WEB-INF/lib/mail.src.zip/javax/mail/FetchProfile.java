/*     */ package javax.mail;
/*     */ 
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class FetchProfile
/*     */ {
/*     */   private Vector specials;
/*     */   private Vector headers;
/*     */ 
/*     */   public FetchProfile()
/*     */   {
/* 152 */     this.specials = null;
/* 153 */     this.headers = null;
/*     */   }
/*     */ 
/*     */   public void add(Item item)
/*     */   {
/* 166 */     if (this.specials == null)
/* 167 */       this.specials = new Vector();
/* 168 */     this.specials.addElement(item);
/*     */   }
/*     */ 
/*     */   public void add(String headerName)
/*     */   {
/* 178 */     if (this.headers == null)
/* 179 */       this.headers = new Vector();
/* 180 */     this.headers.addElement(headerName);
/*     */   }
/*     */ 
/*     */   public boolean contains(Item item)
/*     */   {
/* 187 */     return (this.specials != null) && (this.specials.contains(item));
/*     */   }
/*     */ 
/*     */   public boolean contains(String headerName)
/*     */   {
/* 194 */     return (this.headers != null) && (this.headers.contains(headerName));
/*     */   }
/*     */ 
/*     */   public Item[] getItems()
/*     */   {
/* 203 */     if (this.specials == null) {
/* 204 */       return new Item[0];
/*     */     }
/* 206 */     Item[] s = new Item[this.specials.size()];
/* 207 */     this.specials.copyInto(s);
/* 208 */     return s;
/*     */   }
/*     */ 
/*     */   public String[] getHeaderNames()
/*     */   {
/* 217 */     if (this.headers == null) {
/* 218 */       return new String[0];
/*     */     }
/* 220 */     String[] s = new String[this.headers.size()];
/* 221 */     this.headers.copyInto(s);
/* 222 */     return s;
/*     */   }
/*     */ 
/*     */   public static class Item
/*     */   {
/* 112 */     public static final Item ENVELOPE = new Item("ENVELOPE");
/*     */ 
/* 124 */     public static final Item CONTENT_INFO = new Item("CONTENT_INFO");
/*     */ 
/* 129 */     public static final Item FLAGS = new Item("FLAGS");
/*     */     private String name;
/*     */ 
/*     */     protected Item(String name)
/*     */     {
/* 137 */       this.name = name;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 144 */       return getClass().getName() + "[" + this.name + "]";
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.FetchProfile
 * JD-Core Version:    0.6.1
 */