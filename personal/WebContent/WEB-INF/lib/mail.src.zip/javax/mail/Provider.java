/*     */ package javax.mail;
/*     */ 
/*     */ public class Provider
/*     */ {
/*     */   private Type type;
/*     */   private String protocol;
/*     */   private String className;
/*     */   private String vendor;
/*     */   private String version;
/*     */ 
/*     */   public Provider(Type type, String protocol, String classname, String vendor, String version)
/*     */   {
/*  89 */     this.type = type;
/*  90 */     this.protocol = protocol;
/*  91 */     this.className = classname;
/*  92 */     this.vendor = vendor;
/*  93 */     this.version = version;
/*     */   }
/*     */ 
/*     */   public Type getType()
/*     */   {
/*  98 */     return this.type;
/*     */   }
/*     */ 
/*     */   public String getProtocol()
/*     */   {
/* 103 */     return this.protocol;
/*     */   }
/*     */ 
/*     */   public String getClassName()
/*     */   {
/* 108 */     return this.className;
/*     */   }
/*     */ 
/*     */   public String getVendor()
/*     */   {
/* 113 */     return this.vendor;
/*     */   }
/*     */ 
/*     */   public String getVersion()
/*     */   {
/* 118 */     return this.version;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 123 */     String s = "javax.mail.Provider[" + this.type + "," + this.protocol + "," + this.className;
/*     */ 
/* 126 */     if (this.vendor != null) {
/* 127 */       s = s + "," + this.vendor;
/*     */     }
/* 129 */     if (this.version != null) {
/* 130 */       s = s + "," + this.version;
/*     */     }
/* 132 */     s = s + "]";
/* 133 */     return s;
/*     */   }
/*     */ 
/*     */   public static class Type
/*     */   {
/*  59 */     public static final Type STORE = new Type("STORE");
/*  60 */     public static final Type TRANSPORT = new Type("TRANSPORT");
/*     */     private String type;
/*     */ 
/*     */     private Type(String type)
/*     */     {
/*  65 */       this.type = type;
/*     */     }
/*     */ 
/*     */     public String toString() {
/*  69 */       return this.type;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.Provider
 * JD-Core Version:    0.6.1
 */