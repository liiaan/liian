/*     */ package javax.mail;
/*     */ 
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Vector;
/*     */ import javax.mail.event.ConnectionEvent;
/*     */ import javax.mail.event.ConnectionListener;
/*     */ import javax.mail.event.MailEvent;
/*     */ 
/*     */ public abstract class Service
/*     */ {
/*     */   protected Session session;
/*  67 */   protected URLName url = null;
/*     */ 
/*  73 */   protected boolean debug = false;
/*     */ 
/*  75 */   private boolean connected = false;
/*     */ 
/*  84 */   private final Vector connectionListeners = new Vector();
/*     */   private EventQueue q;
/* 560 */   private Object qLock = new Object();
/*     */ 
/*     */   protected Service(Session session, URLName urlname)
/*     */   {
/*  93 */     this.session = session;
/*  94 */     this.url = urlname;
/*  95 */     this.debug = session.getDebug();
/*     */   }
/*     */ 
/*     */   public void connect()
/*     */     throws MessagingException
/*     */   {
/* 121 */     connect(null, null, null);
/*     */   }
/*     */ 
/*     */   public void connect(String host, String user, String password)
/*     */     throws MessagingException
/*     */   {
/* 172 */     connect(host, -1, user, password);
/*     */   }
/*     */ 
/*     */   public void connect(String user, String password)
/*     */     throws MessagingException
/*     */   {
/* 192 */     connect(null, user, password);
/*     */   }
/*     */ 
/*     */   public synchronized void connect(String host, int port, String user, String password)
/*     */     throws MessagingException
/*     */   {
/* 213 */     if (isConnected()) {
/* 214 */       throw new IllegalStateException("already connected");
/*     */     }
/*     */ 
/* 217 */     boolean connected = false;
/* 218 */     boolean save = false;
/* 219 */     String protocol = null;
/* 220 */     String file = null;
/*     */ 
/* 225 */     if (this.url != null) {
/* 226 */       protocol = this.url.getProtocol();
/* 227 */       if (host == null)
/* 228 */         host = this.url.getHost();
/* 229 */       if (port == -1) {
/* 230 */         port = this.url.getPort();
/*     */       }
/* 232 */       if (user == null) {
/* 233 */         user = this.url.getUsername();
/* 234 */         if (password == null)
/* 235 */           password = this.url.getPassword();
/*     */       }
/* 237 */       else if ((password == null) && (user.equals(this.url.getUsername())))
/*     */       {
/* 239 */         password = this.url.getPassword();
/*     */       }
/*     */ 
/* 242 */       file = this.url.getFile();
/*     */     }
/*     */ 
/* 246 */     if (protocol != null) {
/* 247 */       if (host == null)
/* 248 */         host = this.session.getProperty("mail." + protocol + ".host");
/* 249 */       if (user == null) {
/* 250 */         user = this.session.getProperty("mail." + protocol + ".user");
/*     */       }
/*     */     }
/*     */ 
/* 254 */     if (host == null) {
/* 255 */       host = this.session.getProperty("mail.host");
/*     */     }
/* 257 */     if (user == null) {
/* 258 */       user = this.session.getProperty("mail.user");
/*     */     }
/*     */ 
/* 261 */     if (user == null) {
/*     */       try {
/* 263 */         user = System.getProperty("user.name");
/*     */       } catch (SecurityException sex) {
/* 265 */         if (this.debug) {
/* 266 */           sex.printStackTrace(this.session.getDebugOut());
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 271 */     if ((password == null) && (this.url != null))
/*     */     {
/* 273 */       setURLName(new URLName(protocol, host, port, file, user, null));
/* 274 */       PasswordAuthentication pw = this.session.getPasswordAuthentication(getURLName());
/* 275 */       if (pw != null) {
/* 276 */         if (user == null) {
/* 277 */           user = pw.getUserName();
/* 278 */           password = pw.getPassword();
/* 279 */         } else if (user.equals(pw.getUserName())) {
/* 280 */           password = pw.getPassword();
/*     */         }
/*     */       }
/* 283 */       else save = true;
/*     */ 
/*     */     }
/*     */ 
/* 289 */     AuthenticationFailedException authEx = null;
/*     */     try {
/* 291 */       connected = protocolConnect(host, port, user, password);
/*     */     } catch (AuthenticationFailedException ex) {
/* 293 */       authEx = ex;
/*     */     }
/*     */ 
/* 297 */     if (!connected) {
/*     */       InetAddress addr;
/*     */       try {
/* 300 */         addr = InetAddress.getByName(host);
/*     */       } catch (UnknownHostException e) {
/* 302 */         addr = null;
/*     */       }
/* 304 */       PasswordAuthentication pw = this.session.requestPasswordAuthentication(addr, port, protocol, null, user);
/*     */ 
/* 308 */       if (pw != null) {
/* 309 */         user = pw.getUserName();
/* 310 */         password = pw.getPassword();
/*     */ 
/* 313 */         connected = protocolConnect(host, port, user, password);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 318 */     if (!connected) {
/* 319 */       if (authEx != null) {
/* 320 */         throw authEx;
/*     */       }
/* 322 */       throw new AuthenticationFailedException("failed to connect");
/*     */     }
/*     */ 
/* 325 */     setURLName(new URLName(protocol, host, port, file, user, password));
/*     */ 
/* 327 */     if (save) {
/* 328 */       this.session.setPasswordAuthentication(getURLName(), new PasswordAuthentication(user, password));
/*     */     }
/*     */ 
/* 332 */     setConnected(true);
/*     */ 
/* 335 */     notifyConnectionListeners(1);
/*     */   }
/*     */ 
/*     */   protected boolean protocolConnect(String host, int port, String user, String password)
/*     */     throws MessagingException
/*     */   {
/* 372 */     return false;
/*     */   }
/*     */ 
/*     */   public synchronized boolean isConnected()
/*     */   {
/* 388 */     return this.connected;
/*     */   }
/*     */ 
/*     */   protected synchronized void setConnected(boolean connected)
/*     */   {
/* 405 */     this.connected = connected;
/*     */   }
/*     */ 
/*     */   public synchronized void close()
/*     */     throws MessagingException
/*     */   {
/* 428 */     setConnected(false);
/* 429 */     notifyConnectionListeners(3);
/*     */   }
/*     */ 
/*     */   public synchronized URLName getURLName()
/*     */   {
/* 447 */     if ((this.url != null) && ((this.url.getPassword() != null) || (this.url.getFile() != null))) {
/* 448 */       return new URLName(this.url.getProtocol(), this.url.getHost(), this.url.getPort(), null, this.url.getUsername(), null);
/*     */     }
/*     */ 
/* 452 */     return this.url;
/*     */   }
/*     */ 
/*     */   protected synchronized void setURLName(URLName url)
/*     */   {
/* 473 */     this.url = url;
/*     */   }
/*     */ 
/*     */   public void addConnectionListener(ConnectionListener l)
/*     */   {
/* 486 */     this.connectionListeners.addElement(l);
/*     */   }
/*     */ 
/*     */   public void removeConnectionListener(ConnectionListener l)
/*     */   {
/* 499 */     this.connectionListeners.removeElement(l);
/*     */   }
/*     */ 
/*     */   protected void notifyConnectionListeners(int type)
/*     */   {
/* 518 */     if (this.connectionListeners.size() > 0) {
/* 519 */       ConnectionEvent e = new ConnectionEvent(this, type);
/* 520 */       queueEvent(e, this.connectionListeners);
/*     */     }
/*     */ 
/* 533 */     if (type == 3)
/* 534 */       terminateQueue();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 542 */     URLName url = getURLName();
/* 543 */     if (url != null) {
/* 544 */       return url.toString();
/*     */     }
/* 546 */     return super.toString();
/*     */   }
/*     */ 
/*     */   protected void queueEvent(MailEvent event, Vector vector)
/*     */   {
/* 567 */     synchronized (this.qLock) {
/* 568 */       if (this.q == null) {
/* 569 */         this.q = new EventQueue();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 580 */     Vector v = (Vector)vector.clone();
/* 581 */     this.q.enqueue(event, v);
/*     */   }
/*     */ 
/*     */   private void terminateQueue()
/*     */   {
/* 599 */     synchronized (this.qLock) {
/* 600 */       if (this.q != null) {
/* 601 */         Vector dummyListeners = new Vector();
/* 602 */         dummyListeners.setSize(1);
/* 603 */         this.q.enqueue(new TerminatorEvent(), dummyListeners);
/* 604 */         this.q = null;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void finalize()
/*     */     throws Throwable
/*     */   {
/* 613 */     super.finalize();
/* 614 */     terminateQueue();
/*     */   }
/*     */ 
/*     */   static class TerminatorEvent extends MailEvent
/*     */   {
/*     */     private static final long serialVersionUID = 5542172141759168416L;
/*     */ 
/*     */     TerminatorEvent()
/*     */     {
/* 588 */       super();
/*     */     }
/*     */ 
/*     */     public void dispatch(Object listener)
/*     */     {
/* 593 */       Thread.currentThread().interrupt();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.Service
 * JD-Core Version:    0.6.1
 */