/*     */ package javax.mail;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public abstract class Multipart
/*     */ {
/*  68 */   protected Vector parts = new Vector();
/*     */ 
/*  74 */   protected String contentType = "multipart/mixed";
/*     */   protected Part parent;
/*     */ 
/*     */   protected synchronized void setMultipartDataSource(MultipartDataSource mp)
/*     */     throws MessagingException
/*     */   {
/* 105 */     this.contentType = mp.getContentType();
/*     */ 
/* 107 */     int count = mp.getCount();
/* 108 */     for (int i = 0; i < count; i++)
/* 109 */       addBodyPart(mp.getBodyPart(i));
/*     */   }
/*     */ 
/*     */   public String getContentType()
/*     */   {
/* 122 */     return this.contentType;
/*     */   }
/*     */ 
/*     */   public synchronized int getCount()
/*     */     throws MessagingException
/*     */   {
/* 132 */     if (this.parts == null) {
/* 133 */       return 0;
/*     */     }
/* 135 */     return this.parts.size();
/*     */   }
/*     */ 
/*     */   public synchronized BodyPart getBodyPart(int index)
/*     */     throws MessagingException
/*     */   {
/* 149 */     if (this.parts == null) {
/* 150 */       throw new IndexOutOfBoundsException("No such BodyPart");
/*     */     }
/* 152 */     return (BodyPart)this.parts.elementAt(index);
/*     */   }
/*     */ 
/*     */   public synchronized boolean removeBodyPart(BodyPart part)
/*     */     throws MessagingException
/*     */   {
/* 168 */     if (this.parts == null) {
/* 169 */       throw new MessagingException("No such body part");
/*     */     }
/* 171 */     boolean ret = this.parts.removeElement(part);
/* 172 */     part.setParent(null);
/* 173 */     return ret;
/*     */   }
/*     */ 
/*     */   public synchronized void removeBodyPart(int index)
/*     */     throws MessagingException
/*     */   {
/* 190 */     if (this.parts == null) {
/* 191 */       throw new IndexOutOfBoundsException("No such BodyPart");
/*     */     }
/* 193 */     BodyPart part = (BodyPart)this.parts.elementAt(index);
/* 194 */     this.parts.removeElementAt(index);
/* 195 */     part.setParent(null);
/*     */   }
/*     */ 
/*     */   public synchronized void addBodyPart(BodyPart part)
/*     */     throws MessagingException
/*     */   {
/* 210 */     if (this.parts == null) {
/* 211 */       this.parts = new Vector();
/*     */     }
/* 213 */     this.parts.addElement(part);
/* 214 */     part.setParent(this);
/*     */   }
/*     */ 
/*     */   public synchronized void addBodyPart(BodyPart part, int index)
/*     */     throws MessagingException
/*     */   {
/* 233 */     if (this.parts == null) {
/* 234 */       this.parts = new Vector();
/*     */     }
/* 236 */     this.parts.insertElementAt(part, index);
/* 237 */     part.setParent(this);
/*     */   }
/*     */ 
/*     */   public abstract void writeTo(OutputStream paramOutputStream)
/*     */     throws IOException, MessagingException;
/*     */ 
/*     */   public synchronized Part getParent()
/*     */   {
/* 258 */     return this.parent;
/*     */   }
/*     */ 
/*     */   public synchronized void setParent(Part parent)
/*     */   {
/* 271 */     this.parent = parent;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.Multipart
 * JD-Core Version:    0.6.1
 */