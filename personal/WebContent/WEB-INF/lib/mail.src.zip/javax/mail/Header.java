/*    */ package javax.mail;
/*    */ 
/*    */ public class Header
/*    */ {
/*    */   protected String name;
/*    */   protected String value;
/*    */ 
/*    */   public Header(String name, String value)
/*    */   {
/* 69 */     this.name = name;
/* 70 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 79 */     return this.name;
/*    */   }
/*    */ 
/*    */   public String getValue()
/*    */   {
/* 88 */     return this.value;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.Header
 * JD-Core Version:    0.6.1
 */