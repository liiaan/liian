/*     */ package javax.mail;
/*     */ 
/*     */ import java.net.InetAddress;
/*     */ 
/*     */ public abstract class Authenticator
/*     */ {
/*     */   private InetAddress requestingSite;
/*     */   private int requestingPort;
/*     */   private String requestingProtocol;
/*     */   private String requestingPrompt;
/*     */   private String requestingUserName;
/*     */ 
/*     */   private void reset()
/*     */   {
/*  80 */     this.requestingSite = null;
/*  81 */     this.requestingPort = -1;
/*  82 */     this.requestingProtocol = null;
/*  83 */     this.requestingPrompt = null;
/*  84 */     this.requestingUserName = null;
/*     */   }
/*     */ 
/*     */   final PasswordAuthentication requestPasswordAuthentication(InetAddress addr, int port, String protocol, String prompt, String defaultUserName)
/*     */   {
/* 104 */     reset();
/* 105 */     this.requestingSite = addr;
/* 106 */     this.requestingPort = port;
/* 107 */     this.requestingProtocol = protocol;
/* 108 */     this.requestingPrompt = prompt;
/* 109 */     this.requestingUserName = defaultUserName;
/* 110 */     return getPasswordAuthentication();
/*     */   }
/*     */ 
/*     */   protected final InetAddress getRequestingSite()
/*     */   {
/* 118 */     return this.requestingSite;
/*     */   }
/*     */ 
/*     */   protected final int getRequestingPort()
/*     */   {
/* 125 */     return this.requestingPort;
/*     */   }
/*     */ 
/*     */   protected final String getRequestingProtocol()
/*     */   {
/* 137 */     return this.requestingProtocol;
/*     */   }
/*     */ 
/*     */   protected final String getRequestingPrompt()
/*     */   {
/* 144 */     return this.requestingPrompt;
/*     */   }
/*     */ 
/*     */   protected final String getDefaultUserName()
/*     */   {
/* 151 */     return this.requestingUserName;
/*     */   }
/*     */ 
/*     */   protected PasswordAuthentication getPasswordAuthentication()
/*     */   {
/* 166 */     return null;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.Authenticator
 * JD-Core Version:    0.6.1
 */