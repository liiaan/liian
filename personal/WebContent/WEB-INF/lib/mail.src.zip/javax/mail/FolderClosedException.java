/*    */ package javax.mail;
/*    */ 
/*    */ public class FolderClosedException extends MessagingException
/*    */ {
/*    */   private transient Folder folder;
/*    */   private static final long serialVersionUID = 1687879213433302315L;
/*    */ 
/*    */   public FolderClosedException(Folder folder)
/*    */   {
/* 64 */     this(folder, null);
/*    */   }
/*    */ 
/*    */   public FolderClosedException(Folder folder, String message)
/*    */   {
/* 73 */     super(message);
/* 74 */     this.folder = folder;
/*    */   }
/*    */ 
/*    */   public Folder getFolder()
/*    */   {
/* 81 */     return this.folder;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.FolderClosedException
 * JD-Core Version:    0.6.1
 */