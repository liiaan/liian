/*     */ package javax.mail;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import javax.mail.event.MailEvent;
/*     */ 
/*     */ class EventQueue
/*     */   implements Runnable
/*     */ {
/*  66 */   private QueueElement head = null;
/*  67 */   private QueueElement tail = null;
/*     */   private Thread qThread;
/*     */ 
/*     */   public EventQueue()
/*     */   {
/*  71 */     this.qThread = new Thread(this, "JavaMail-EventQueue");
/*  72 */     this.qThread.setDaemon(true);
/*  73 */     this.qThread.start();
/*     */   }
/*     */ 
/*     */   public synchronized void enqueue(MailEvent event, Vector vector)
/*     */   {
/*  80 */     QueueElement newElt = new QueueElement(event, vector);
/*     */ 
/*  82 */     if (this.head == null) {
/*  83 */       this.head = newElt;
/*  84 */       this.tail = newElt;
/*     */     } else {
/*  86 */       newElt.next = this.head;
/*  87 */       this.head.prev = newElt;
/*  88 */       this.head = newElt;
/*     */     }
/*  90 */     notifyAll();
/*     */   }
/*     */ 
/*     */   private synchronized QueueElement dequeue()
/*     */     throws InterruptedException
/*     */   {
/* 103 */     while (this.tail == null)
/* 104 */       wait();
/* 105 */     QueueElement elt = this.tail;
/* 106 */     this.tail = elt.prev;
/* 107 */     if (this.tail == null)
/* 108 */       this.head = null;
/*     */     else {
/* 110 */       this.tail.next = null;
/*     */     }
/* 112 */     elt.prev = (elt.next = null);
/* 113 */     return elt;
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     try
/*     */     {
/*     */       QueueElement qe;
/* 124 */       while ((qe = dequeue()) != null) {
/* 125 */         MailEvent e = qe.event;
/* 126 */         Vector v = qe.vector;
/*     */ 
/* 128 */         for (int i = 0; i < v.size(); i++) {
/*     */           try {
/* 130 */             e.dispatch(v.elementAt(i));
/*     */           } catch (Throwable t) {
/* 132 */             if (!(t instanceof InterruptedException)) continue; 
/* 133 */           }return;
/*     */         }
/*     */ 
/* 137 */         qe = null; e = null; v = null;
/*     */       }
/*     */     }
/*     */     catch (InterruptedException e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   void stop()
/*     */   {
/* 148 */     if (this.qThread != null) {
/* 149 */       this.qThread.interrupt();
/* 150 */       this.qThread = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   static class QueueElement
/*     */   {
/*  55 */     QueueElement next = null;
/*  56 */     QueueElement prev = null;
/*  57 */     MailEvent event = null;
/*  58 */     Vector vector = null;
/*     */ 
/*     */     QueueElement(MailEvent event, Vector vector) {
/*  61 */       this.event = event;
/*  62 */       this.vector = vector;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.EventQueue
 * JD-Core Version:    0.6.1
 */