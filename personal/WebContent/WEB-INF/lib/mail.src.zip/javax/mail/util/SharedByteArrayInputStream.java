/*     */ package javax.mail.util;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.InputStream;
/*     */ import javax.mail.internet.SharedInputStream;
/*     */ 
/*     */ public class SharedByteArrayInputStream extends ByteArrayInputStream
/*     */   implements SharedInputStream
/*     */ {
/*  55 */   protected int start = 0;
/*     */ 
/*     */   public SharedByteArrayInputStream(byte[] buf)
/*     */   {
/*  64 */     super(buf);
/*     */   }
/*     */ 
/*     */   public SharedByteArrayInputStream(byte[] buf, int offset, int length)
/*     */   {
/*  77 */     super(buf, offset, length);
/*  78 */     this.start = offset;
/*     */   }
/*     */ 
/*     */   public long getPosition()
/*     */   {
/*  88 */     return this.pos - this.start;
/*     */   }
/*     */ 
/*     */   public InputStream newStream(long start, long end)
/*     */   {
/* 104 */     if (start < 0L)
/* 105 */       throw new IllegalArgumentException("start < 0");
/* 106 */     if (end == -1L)
/* 107 */       end = this.count - this.start;
/* 108 */     return new SharedByteArrayInputStream(this.buf, this.start + (int)start, (int)(end - start));
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.util.SharedByteArrayInputStream
 * JD-Core Version:    0.6.1
 */