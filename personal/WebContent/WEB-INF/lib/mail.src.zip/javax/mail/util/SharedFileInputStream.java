/*     */ package javax.mail.util;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.RandomAccessFile;
/*     */ import javax.mail.internet.SharedInputStream;
/*     */ 
/*     */ public class SharedFileInputStream extends BufferedInputStream
/*     */   implements SharedInputStream
/*     */ {
/*  67 */   private static int defaultBufferSize = 2048;
/*     */   protected RandomAccessFile in;
/*     */   protected int bufsize;
/*     */   protected long bufpos;
/*  89 */   protected long start = 0L;
/*     */   protected long datalen;
/* 100 */   private boolean master = true;
/*     */   private SharedFile sf;
/*     */ 
/*     */   private void ensureOpen()
/*     */     throws IOException
/*     */   {
/* 154 */     if (this.in == null)
/* 155 */       throw new IOException("Stream closed");
/*     */   }
/*     */ 
/*     */   public SharedFileInputStream(File file)
/*     */     throws IOException
/*     */   {
/* 165 */     this(file, defaultBufferSize);
/*     */   }
/*     */ 
/*     */   public SharedFileInputStream(String file)
/*     */     throws IOException
/*     */   {
/* 175 */     this(file, defaultBufferSize);
/*     */   }
/*     */ 
/*     */   public SharedFileInputStream(File file, int size)
/*     */     throws IOException
/*     */   {
/* 187 */     super(null);
/* 188 */     if (size <= 0)
/* 189 */       throw new IllegalArgumentException("Buffer size <= 0");
/* 190 */     init(new SharedFile(file), size);
/*     */   }
/*     */ 
/*     */   public SharedFileInputStream(String file, int size)
/*     */     throws IOException
/*     */   {
/* 202 */     super(null);
/* 203 */     if (size <= 0)
/* 204 */       throw new IllegalArgumentException("Buffer size <= 0");
/* 205 */     init(new SharedFile(file), size);
/*     */   }
/*     */ 
/*     */   private void init(SharedFile sf, int size) throws IOException {
/* 209 */     this.sf = sf;
/* 210 */     this.in = sf.open();
/* 211 */     this.start = 0L;
/* 212 */     this.datalen = this.in.length();
/* 213 */     this.bufsize = size;
/* 214 */     this.buf = new byte[size];
/*     */   }
/*     */ 
/*     */   private SharedFileInputStream(SharedFile sf, long start, long len, int bufsize)
/*     */   {
/* 222 */     super(null);
/* 223 */     this.master = false;
/* 224 */     this.sf = sf;
/* 225 */     this.in = sf.open();
/* 226 */     this.start = start;
/* 227 */     this.bufpos = start;
/* 228 */     this.datalen = len;
/* 229 */     this.bufsize = bufsize;
/* 230 */     this.buf = new byte[bufsize];
/*     */   }
/*     */ 
/*     */   private void fill()
/*     */     throws IOException
/*     */   {
/* 241 */     if (this.markpos < 0) {
/* 242 */       this.pos = 0;
/* 243 */       this.bufpos += this.count;
/* 244 */     } else if (this.pos >= this.buf.length) {
/* 245 */       if (this.markpos > 0) {
/* 246 */         int sz = this.pos - this.markpos;
/* 247 */         System.arraycopy(this.buf, this.markpos, this.buf, 0, sz);
/* 248 */         this.pos = sz;
/* 249 */         this.bufpos += this.markpos;
/* 250 */         this.markpos = 0;
/* 251 */       } else if (this.buf.length >= this.marklimit) {
/* 252 */         this.markpos = -1;
/* 253 */         this.pos = 0;
/* 254 */         this.bufpos += this.count;
/*     */       } else {
/* 256 */         int nsz = this.pos * 2;
/* 257 */         if (nsz > this.marklimit)
/* 258 */           nsz = this.marklimit;
/* 259 */         byte[] nbuf = new byte[nsz];
/* 260 */         System.arraycopy(this.buf, 0, nbuf, 0, this.pos);
/* 261 */         this.buf = nbuf;
/*     */       }
/*     */     }
/* 263 */     this.count = this.pos;
/* 264 */     this.in.seek(this.bufpos + this.pos);
/*     */ 
/* 266 */     int len = this.buf.length - this.pos;
/* 267 */     if (this.bufpos - this.start + this.pos + len > this.datalen)
/* 268 */       len = (int)(this.datalen - (this.bufpos - this.start + this.pos));
/* 269 */     int n = this.in.read(this.buf, this.pos, len);
/* 270 */     if (n > 0)
/* 271 */       this.count = (n + this.pos);
/*     */   }
/*     */ 
/*     */   public synchronized int read()
/*     */     throws IOException
/*     */   {
/* 283 */     ensureOpen();
/* 284 */     if (this.pos >= this.count) {
/* 285 */       fill();
/* 286 */       if (this.pos >= this.count)
/* 287 */         return -1;
/*     */     }
/* 289 */     return this.buf[(this.pos++)] & 0xFF;
/*     */   }
/*     */ 
/*     */   private int read1(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 297 */     int avail = this.count - this.pos;
/* 298 */     if (avail <= 0)
/*     */     {
/* 309 */       fill();
/* 310 */       avail = this.count - this.pos;
/* 311 */       if (avail <= 0) return -1;
/*     */     }
/* 313 */     int cnt = avail < len ? avail : len;
/* 314 */     System.arraycopy(this.buf, this.pos, b, off, cnt);
/* 315 */     this.pos += cnt;
/* 316 */     return cnt;
/*     */   }
/*     */ 
/*     */   public synchronized int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 337 */     ensureOpen();
/* 338 */     if ((off | len | off + len | b.length - (off + len)) < 0)
/* 339 */       throw new IndexOutOfBoundsException();
/* 340 */     if (len == 0) {
/* 341 */       return 0;
/*     */     }
/*     */ 
/* 344 */     int n = read1(b, off, len);
/* 345 */     if (n <= 0) return n;
/* 346 */     while (n < len) {
/* 347 */       int n1 = read1(b, off + n, len - n);
/* 348 */       if (n1 <= 0) break;
/* 349 */       n += n1;
/*     */     }
/* 351 */     return n;
/*     */   }
/*     */ 
/*     */   public synchronized long skip(long n)
/*     */     throws IOException
/*     */   {
/* 363 */     ensureOpen();
/* 364 */     if (n <= 0L) {
/* 365 */       return 0L;
/*     */     }
/* 367 */     long avail = this.count - this.pos;
/*     */ 
/* 369 */     if (avail <= 0L)
/*     */     {
/* 377 */       fill();
/* 378 */       avail = this.count - this.pos;
/* 379 */       if (avail <= 0L) {
/* 380 */         return 0L;
/*     */       }
/*     */     }
/* 383 */     long skipped = avail < n ? avail : n;
/* 384 */     this.pos = (int)(this.pos + skipped);
/* 385 */     return skipped;
/*     */   }
/*     */ 
/*     */   public synchronized int available()
/*     */     throws IOException
/*     */   {
/* 397 */     ensureOpen();
/* 398 */     return this.count - this.pos + in_available();
/*     */   }
/*     */ 
/*     */   private int in_available() throws IOException
/*     */   {
/* 403 */     return (int)(this.start + this.datalen - (this.bufpos + this.count));
/*     */   }
/*     */ 
/*     */   public synchronized void mark(int readlimit)
/*     */   {
/* 415 */     this.marklimit = readlimit;
/* 416 */     this.markpos = this.pos;
/*     */   }
/*     */ 
/*     */   public synchronized void reset()
/*     */     throws IOException
/*     */   {
/* 434 */     ensureOpen();
/* 435 */     if (this.markpos < 0)
/* 436 */       throw new IOException("Resetting to invalid mark");
/* 437 */     this.pos = this.markpos;
/*     */   }
/*     */ 
/*     */   public boolean markSupported()
/*     */   {
/* 452 */     return true;
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 462 */     if (this.in == null)
/* 463 */       return;
/*     */     try {
/* 465 */       if (this.master)
/* 466 */         this.sf.forceClose();
/*     */       else
/* 468 */         this.sf.close();
/*     */     } finally {
/* 470 */       this.sf = null;
/* 471 */       this.in = null;
/* 472 */       this.buf = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getPosition()
/*     */   {
/* 484 */     if (this.in == null)
/* 485 */       throw new RuntimeException("Stream closed");
/* 486 */     return this.bufpos + this.pos - this.start;
/*     */   }
/*     */ 
/*     */   public InputStream newStream(long start, long end)
/*     */   {
/* 502 */     if (this.in == null)
/* 503 */       throw new RuntimeException("Stream closed");
/* 504 */     if (start < 0L)
/* 505 */       throw new IllegalArgumentException("start < 0");
/* 506 */     if (end == -1L)
/* 507 */       end = this.datalen;
/* 508 */     return new SharedFileInputStream(this.sf, this.start + (int)start, (int)(end - start), this.bufsize);
/*     */   }
/*     */ 
/*     */   protected void finalize()
/*     */     throws Throwable
/*     */   {
/* 534 */     super.finalize();
/* 535 */     close();
/*     */   }
/*     */ 
/*     */   static class SharedFile
/*     */   {
/*     */     private int cnt;
/*     */     private RandomAccessFile in;
/*     */ 
/*     */     SharedFile(String file)
/*     */       throws IOException
/*     */     {
/* 112 */       this.in = new RandomAccessFile(file, "r");
/*     */     }
/*     */ 
/*     */     SharedFile(File file) throws IOException {
/* 116 */       this.in = new RandomAccessFile(file, "r");
/*     */     }
/*     */ 
/*     */     public RandomAccessFile open() {
/* 120 */       this.cnt += 1;
/* 121 */       return this.in;
/*     */     }
/*     */ 
/*     */     public synchronized void close() throws IOException {
/* 125 */       if ((this.cnt > 0) && (--this.cnt <= 0))
/* 126 */         this.in.close();
/*     */     }
/*     */ 
/*     */     public synchronized void forceClose() throws IOException {
/* 130 */       if (this.cnt > 0)
/*     */       {
/* 132 */         this.cnt = 0;
/* 133 */         this.in.close();
/*     */       }
/*     */       else {
/*     */         try {
/* 137 */           this.in.close(); } catch (IOException ioex) {
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     protected void finalize() throws Throwable {
/* 143 */       super.finalize();
/* 144 */       this.in.close();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.util.SharedFileInputStream
 * JD-Core Version:    0.6.1
 */