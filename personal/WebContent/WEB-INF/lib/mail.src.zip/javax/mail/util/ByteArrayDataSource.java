/*     */ package javax.mail.util;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import javax.activation.DataSource;
/*     */ import javax.mail.internet.ContentType;
/*     */ import javax.mail.internet.MimeUtility;
/*     */ import javax.mail.internet.ParseException;
/*     */ 
/*     */ public class ByteArrayDataSource
/*     */   implements DataSource
/*     */ {
/*     */   private byte[] data;
/*  55 */   private int len = -1;
/*     */   private String type;
/*  57 */   private String name = "";
/*     */ 
/*     */   public ByteArrayDataSource(InputStream is, String type)
/*     */     throws IOException
/*     */   {
/*  80 */     DSByteArrayOutputStream os = new DSByteArrayOutputStream();
/*  81 */     byte[] buf = new byte[8192];
/*     */     int len;
/*  83 */     while ((len = is.read(buf)) > 0)
/*  84 */       os.write(buf, 0, len);
/*  85 */     this.data = os.getBuf();
/*  86 */     this.len = os.getCount();
/*     */ 
/*  95 */     if (this.data.length - this.len > 262144) {
/*  96 */       this.data = os.toByteArray();
/*  97 */       this.len = this.data.length;
/*     */     }
/*  99 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public ByteArrayDataSource(byte[] data, String type)
/*     */   {
/* 110 */     this.data = data;
/* 111 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public ByteArrayDataSource(String data, String type)
/*     */     throws IOException
/*     */   {
/* 127 */     String charset = null;
/*     */     try {
/* 129 */       ContentType ct = new ContentType(type);
/* 130 */       charset = ct.getParameter("charset");
/*     */     }
/*     */     catch (ParseException pex) {
/*     */     }
/* 134 */     if (charset == null) {
/* 135 */       charset = MimeUtility.getDefaultJavaCharset();
/*     */     }
/* 137 */     this.data = data.getBytes(charset);
/* 138 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public InputStream getInputStream()
/*     */     throws IOException
/*     */   {
/* 150 */     if (this.data == null)
/* 151 */       throw new IOException("no data");
/* 152 */     if (this.len < 0)
/* 153 */       this.len = this.data.length;
/* 154 */     return new SharedByteArrayInputStream(this.data, 0, this.len);
/*     */   }
/*     */ 
/*     */   public OutputStream getOutputStream()
/*     */     throws IOException
/*     */   {
/* 165 */     throw new IOException("cannot do this");
/*     */   }
/*     */ 
/*     */   public String getContentType()
/*     */   {
/* 174 */     return this.type;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 184 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 193 */     this.name = name;
/*     */   }
/*     */ 
/*     */   static class DSByteArrayOutputStream extends ByteArrayOutputStream
/*     */   {
/*     */     public byte[] getBuf()
/*     */     {
/*  61 */       return this.buf;
/*     */     }
/*     */ 
/*     */     public int getCount() {
/*  65 */       return this.count;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.util.ByteArrayDataSource
 * JD-Core Version:    0.6.1
 */