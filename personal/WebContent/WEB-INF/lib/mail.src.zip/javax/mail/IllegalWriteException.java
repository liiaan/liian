/*    */ package javax.mail;
/*    */ 
/*    */ public class IllegalWriteException extends MessagingException
/*    */ {
/*    */   private static final long serialVersionUID = 3974370223328268013L;
/*    */ 
/*    */   public IllegalWriteException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public IllegalWriteException(String s)
/*    */   {
/* 64 */     super(s);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.IllegalWriteException
 * JD-Core Version:    0.6.1
 */