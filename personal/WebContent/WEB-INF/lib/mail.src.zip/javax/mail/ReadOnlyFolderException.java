/*    */ package javax.mail;
/*    */ 
/*    */ public class ReadOnlyFolderException extends MessagingException
/*    */ {
/*    */   private transient Folder folder;
/*    */   private static final long serialVersionUID = 5711829372799039325L;
/*    */ 
/*    */   public ReadOnlyFolderException(Folder folder)
/*    */   {
/* 60 */     this(folder, null);
/*    */   }
/*    */ 
/*    */   public ReadOnlyFolderException(Folder folder, String message)
/*    */   {
/* 71 */     super(message);
/* 72 */     this.folder = folder;
/*    */   }
/*    */ 
/*    */   public Folder getFolder()
/*    */   {
/* 80 */     return this.folder;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.ReadOnlyFolderException
 * JD-Core Version:    0.6.1
 */