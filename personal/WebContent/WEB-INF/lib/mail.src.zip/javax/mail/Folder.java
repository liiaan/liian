/*      */ package javax.mail;
/*      */ 
/*      */ import java.util.Vector;
/*      */ import javax.mail.event.ConnectionEvent;
/*      */ import javax.mail.event.ConnectionListener;
/*      */ import javax.mail.event.FolderEvent;
/*      */ import javax.mail.event.FolderListener;
/*      */ import javax.mail.event.MailEvent;
/*      */ import javax.mail.event.MessageChangedEvent;
/*      */ import javax.mail.event.MessageChangedListener;
/*      */ import javax.mail.event.MessageCountEvent;
/*      */ import javax.mail.event.MessageCountListener;
/*      */ import javax.mail.search.SearchTerm;
/*      */ 
/*      */ public abstract class Folder
/*      */ {
/*      */   protected Store store;
/*  126 */   protected int mode = -1;
/*      */   public static final int HOLDS_MESSAGES = 1;
/*      */   public static final int HOLDS_FOLDERS = 2;
/*      */   public static final int READ_ONLY = 1;
/*      */   public static final int READ_WRITE = 2;
/* 1298 */   private volatile Vector connectionListeners = null;
/*      */ 
/* 1365 */   private volatile Vector folderListeners = null;
/*      */ 
/* 1446 */   private volatile Vector messageCountListeners = null;
/*      */ 
/* 1529 */   private volatile Vector messageChangedListeners = null;
/*      */   private EventQueue q;
/* 1591 */   private Object qLock = new Object();
/*      */ 
/*      */   protected Folder(Store store)
/*      */   {
/*  134 */     this.store = store;
/*      */   }
/*      */ 
/*      */   public abstract String getName();
/*      */ 
/*      */   public abstract String getFullName();
/*      */ 
/*      */   public URLName getURLName()
/*      */     throws MessagingException
/*      */   {
/*  167 */     URLName storeURL = getStore().getURLName();
/*  168 */     String fullname = getFullName();
/*  169 */     StringBuffer encodedName = new StringBuffer();
/*      */ 
/*  171 */     if (fullname != null)
/*      */     {
/*  189 */       encodedName.append(fullname);
/*      */     }
/*      */ 
/*  196 */     return new URLName(storeURL.getProtocol(), storeURL.getHost(), storeURL.getPort(), encodedName.toString(), storeURL.getUsername(), null);
/*      */   }
/*      */ 
/*      */   public Store getStore()
/*      */   {
/*  208 */     return this.store;
/*      */   }
/*      */ 
/*      */   public abstract Folder getParent()
/*      */     throws MessagingException;
/*      */ 
/*      */   public abstract boolean exists()
/*      */     throws MessagingException;
/*      */ 
/*      */   public abstract Folder[] list(String paramString)
/*      */     throws MessagingException;
/*      */ 
/*      */   public Folder[] listSubscribed(String pattern)
/*      */     throws MessagingException
/*      */   {
/*  304 */     return list(pattern);
/*      */   }
/*      */ 
/*      */   public Folder[] list()
/*      */     throws MessagingException
/*      */   {
/*  322 */     return list("%");
/*      */   }
/*      */ 
/*      */   public Folder[] listSubscribed()
/*      */     throws MessagingException
/*      */   {
/*  340 */     return listSubscribed("%");
/*      */   }
/*      */ 
/*      */   public abstract char getSeparator()
/*      */     throws MessagingException;
/*      */ 
/*      */   public abstract int getType()
/*      */     throws MessagingException;
/*      */ 
/*      */   public abstract boolean create(int paramInt)
/*      */     throws MessagingException;
/*      */ 
/*      */   public boolean isSubscribed()
/*      */   {
/*  405 */     return true;
/*      */   }
/*      */ 
/*      */   public void setSubscribed(boolean subscribe)
/*      */     throws MessagingException
/*      */   {
/*  426 */     throw new MethodNotSupportedException();
/*      */   }
/*      */ 
/*      */   public abstract boolean hasNewMessages()
/*      */     throws MessagingException;
/*      */ 
/*      */   public abstract Folder getFolder(String paramString)
/*      */     throws MessagingException;
/*      */ 
/*      */   public abstract boolean delete(boolean paramBoolean)
/*      */     throws MessagingException;
/*      */ 
/*      */   public abstract boolean renameTo(Folder paramFolder)
/*      */     throws MessagingException;
/*      */ 
/*      */   public abstract void open(int paramInt)
/*      */     throws MessagingException;
/*      */ 
/*      */   public abstract void close(boolean paramBoolean)
/*      */     throws MessagingException;
/*      */ 
/*      */   public abstract boolean isOpen();
/*      */ 
/*      */   public int getMode()
/*      */   {
/*  637 */     if (!isOpen())
/*  638 */       throw new IllegalStateException("Folder not open");
/*  639 */     return this.mode;
/*      */   }
/*      */ 
/*      */   public abstract Flags getPermanentFlags();
/*      */ 
/*      */   public abstract int getMessageCount()
/*      */     throws MessagingException;
/*      */ 
/*      */   public synchronized int getNewMessageCount()
/*      */     throws MessagingException
/*      */   {
/*  708 */     if (!isOpen()) {
/*  709 */       return -1;
/*      */     }
/*  711 */     int newmsgs = 0;
/*  712 */     int total = getMessageCount();
/*  713 */     for (int i = 1; i <= total; i++) {
/*      */       try {
/*  715 */         if (getMessage(i).isSet(Flags.Flag.RECENT))
/*  716 */           newmsgs++;
/*      */       }
/*      */       catch (MessageRemovedException me)
/*      */       {
/*      */       }
/*      */     }
/*  722 */     return newmsgs;
/*      */   }
/*      */ 
/*      */   public synchronized int getUnreadMessageCount()
/*      */     throws MessagingException
/*      */   {
/*  754 */     if (!isOpen()) {
/*  755 */       return -1;
/*      */     }
/*  757 */     int unread = 0;
/*  758 */     int total = getMessageCount();
/*  759 */     for (int i = 1; i <= total; i++) {
/*      */       try {
/*  761 */         if (!getMessage(i).isSet(Flags.Flag.SEEN))
/*  762 */           unread++;
/*      */       }
/*      */       catch (MessageRemovedException me)
/*      */       {
/*      */       }
/*      */     }
/*  768 */     return unread;
/*      */   }
/*      */ 
/*      */   public synchronized int getDeletedMessageCount()
/*      */     throws MessagingException
/*      */   {
/*  800 */     if (!isOpen()) {
/*  801 */       return -1;
/*      */     }
/*  803 */     int deleted = 0;
/*  804 */     int total = getMessageCount();
/*  805 */     for (int i = 1; i <= total; i++) {
/*      */       try {
/*  807 */         if (getMessage(i).isSet(Flags.Flag.DELETED))
/*  808 */           deleted++;
/*      */       }
/*      */       catch (MessageRemovedException me)
/*      */       {
/*      */       }
/*      */     }
/*  814 */     return deleted;
/*      */   }
/*      */ 
/*      */   public abstract Message getMessage(int paramInt)
/*      */     throws MessagingException;
/*      */ 
/*      */   public synchronized Message[] getMessages(int start, int end)
/*      */     throws MessagingException
/*      */   {
/*  878 */     Message[] msgs = new Message[end - start + 1];
/*  879 */     for (int i = start; i <= end; i++)
/*  880 */       msgs[(i - start)] = getMessage(i);
/*  881 */     return msgs;
/*      */   }
/*      */ 
/*      */   public synchronized Message[] getMessages(int[] msgnums)
/*      */     throws MessagingException
/*      */   {
/*  908 */     int len = msgnums.length;
/*  909 */     Message[] msgs = new Message[len];
/*  910 */     for (int i = 0; i < len; i++)
/*  911 */       msgs[i] = getMessage(msgnums[i]);
/*  912 */     return msgs;
/*      */   }
/*      */ 
/*      */   public synchronized Message[] getMessages()
/*      */     throws MessagingException
/*      */   {
/*  938 */     if (!isOpen())
/*  939 */       throw new IllegalStateException("Folder not open");
/*  940 */     int total = getMessageCount();
/*  941 */     Message[] msgs = new Message[total];
/*  942 */     for (int i = 1; i <= total; i++)
/*  943 */       msgs[(i - 1)] = getMessage(i);
/*  944 */     return msgs;
/*      */   }
/*      */ 
/*      */   public abstract void appendMessages(Message[] paramArrayOfMessage)
/*      */     throws MessagingException;
/*      */ 
/*      */   public void fetch(Message[] msgs, FetchProfile fp)
/*      */     throws MessagingException
/*      */   {
/*      */   }
/*      */ 
/*      */   public synchronized void setFlags(Message[] msgs, Flags flag, boolean value)
/*      */     throws MessagingException
/*      */   {
/* 1038 */     for (int i = 0; i < msgs.length; i++)
/*      */       try {
/* 1040 */         msgs[i].setFlags(flag, value);
/*      */       }
/*      */       catch (MessageRemovedException me)
/*      */       {
/*      */       }
/*      */   }
/*      */ 
/*      */   public synchronized void setFlags(int start, int end, Flags flag, boolean value)
/*      */     throws MessagingException
/*      */   {
/* 1081 */     for (int i = start; i <= end; i++)
/*      */       try {
/* 1083 */         Message msg = getMessage(i);
/* 1084 */         msg.setFlags(flag, value);
/*      */       }
/*      */       catch (MessageRemovedException me)
/*      */       {
/*      */       }
/*      */   }
/*      */ 
/*      */   public synchronized void setFlags(int[] msgnums, Flags flag, boolean value)
/*      */     throws MessagingException
/*      */   {
/* 1123 */     for (int i = 0; i < msgnums.length; i++)
/*      */       try {
/* 1125 */         Message msg = getMessage(msgnums[i]);
/* 1126 */         msg.setFlags(flag, value);
/*      */       }
/*      */       catch (MessageRemovedException me)
/*      */       {
/*      */       }
/*      */   }
/*      */ 
/*      */   public void copyMessages(Message[] msgs, Folder folder)
/*      */     throws MessagingException
/*      */   {
/* 1163 */     if (!folder.exists()) {
/* 1164 */       throw new FolderNotFoundException(folder.getFullName() + " does not exist", folder);
/*      */     }
/*      */ 
/* 1168 */     folder.appendMessages(msgs);
/*      */   }
/*      */ 
/*      */   public abstract Message[] expunge()
/*      */     throws MessagingException;
/*      */ 
/*      */   public Message[] search(SearchTerm term)
/*      */     throws MessagingException
/*      */   {
/* 1227 */     return search(term, getMessages());
/*      */   }
/*      */ 
/*      */   public Message[] search(SearchTerm term, Message[] msgs)
/*      */     throws MessagingException
/*      */   {
/* 1261 */     Vector matchedMsgs = new Vector();
/*      */ 
/* 1264 */     for (int i = 0; i < msgs.length; i++)
/*      */       try {
/* 1266 */         if (msgs[i].match(term))
/* 1267 */           matchedMsgs.addElement(msgs[i]);
/*      */       }
/*      */       catch (MessageRemovedException mrex) {
/*      */       }
/* 1271 */     Message[] m = new Message[matchedMsgs.size()];
/* 1272 */     matchedMsgs.copyInto(m);
/* 1273 */     return m;
/*      */   }
/*      */ 
/*      */   public synchronized void addConnectionListener(ConnectionListener l)
/*      */   {
/* 1311 */     if (this.connectionListeners == null)
/* 1312 */       this.connectionListeners = new Vector();
/* 1313 */     this.connectionListeners.addElement(l);
/*      */   }
/*      */ 
/*      */   public synchronized void removeConnectionListener(ConnectionListener l)
/*      */   {
/* 1327 */     if (this.connectionListeners != null)
/* 1328 */       this.connectionListeners.removeElement(l);
/*      */   }
/*      */ 
/*      */   protected void notifyConnectionListeners(int type)
/*      */   {
/* 1345 */     if (this.connectionListeners != null) {
/* 1346 */       ConnectionEvent e = new ConnectionEvent(this, type);
/* 1347 */       queueEvent(e, this.connectionListeners);
/*      */     }
/*      */ 
/* 1360 */     if (type == 3)
/* 1361 */       terminateQueue();
/*      */   }
/*      */ 
/*      */   public synchronized void addFolderListener(FolderListener l)
/*      */   {
/* 1377 */     if (this.folderListeners == null)
/* 1378 */       this.folderListeners = new Vector();
/* 1379 */     this.folderListeners.addElement(l);
/*      */   }
/*      */ 
/*      */   public synchronized void removeFolderListener(FolderListener l)
/*      */   {
/* 1392 */     if (this.folderListeners != null)
/* 1393 */       this.folderListeners.removeElement(l);
/*      */   }
/*      */ 
/*      */   protected void notifyFolderListeners(int type)
/*      */   {
/* 1412 */     if (this.folderListeners != null) {
/* 1413 */       FolderEvent e = new FolderEvent(this, this, type);
/* 1414 */       queueEvent(e, this.folderListeners);
/*      */     }
/* 1416 */     this.store.notifyFolderListeners(type, this);
/*      */   }
/*      */ 
/*      */   protected void notifyFolderRenamedListeners(Folder folder)
/*      */   {
/* 1437 */     if (this.folderListeners != null) {
/* 1438 */       FolderEvent e = new FolderEvent(this, this, folder, 3);
/*      */ 
/* 1440 */       queueEvent(e, this.folderListeners);
/*      */     }
/* 1442 */     this.store.notifyFolderRenamedListeners(this, folder);
/*      */   }
/*      */ 
/*      */   public synchronized void addMessageCountListener(MessageCountListener l)
/*      */   {
/* 1458 */     if (this.messageCountListeners == null)
/* 1459 */       this.messageCountListeners = new Vector();
/* 1460 */     this.messageCountListeners.addElement(l);
/*      */   }
/*      */ 
/*      */   public synchronized void removeMessageCountListener(MessageCountListener l)
/*      */   {
/* 1474 */     if (this.messageCountListeners != null)
/* 1475 */       this.messageCountListeners.removeElement(l);
/*      */   }
/*      */ 
/*      */   protected void notifyMessageAddedListeners(Message[] msgs)
/*      */   {
/* 1491 */     if (this.messageCountListeners == null) {
/* 1492 */       return;
/*      */     }
/* 1494 */     MessageCountEvent e = new MessageCountEvent(this, 1, false, msgs);
/*      */ 
/* 1500 */     queueEvent(e, this.messageCountListeners);
/*      */   }
/*      */ 
/*      */   protected void notifyMessageRemovedListeners(boolean removed, Message[] msgs)
/*      */   {
/* 1517 */     if (this.messageCountListeners == null) {
/* 1518 */       return;
/*      */     }
/* 1520 */     MessageCountEvent e = new MessageCountEvent(this, 2, removed, msgs);
/*      */ 
/* 1525 */     queueEvent(e, this.messageCountListeners);
/*      */   }
/*      */ 
/*      */   public synchronized void addMessageChangedListener(MessageChangedListener l)
/*      */   {
/* 1542 */     if (this.messageChangedListeners == null)
/* 1543 */       this.messageChangedListeners = new Vector();
/* 1544 */     this.messageChangedListeners.addElement(l);
/*      */   }
/*      */ 
/*      */   public synchronized void removeMessageChangedListener(MessageChangedListener l)
/*      */   {
/* 1558 */     if (this.messageChangedListeners != null)
/* 1559 */       this.messageChangedListeners.removeElement(l);
/*      */   }
/*      */ 
/*      */   protected void notifyMessageChangedListeners(int type, Message msg)
/*      */   {
/* 1573 */     if (this.messageChangedListeners == null) {
/* 1574 */       return;
/*      */     }
/* 1576 */     MessageChangedEvent e = new MessageChangedEvent(this, type, msg);
/* 1577 */     queueEvent(e, this.messageChangedListeners);
/*      */   }
/*      */ 
/*      */   private void queueEvent(MailEvent event, Vector vector)
/*      */   {
/* 1598 */     synchronized (this.qLock) {
/* 1599 */       if (this.q == null) {
/* 1600 */         this.q = new EventQueue();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1611 */     Vector v = (Vector)vector.clone();
/* 1612 */     this.q.enqueue(event, v);
/*      */   }
/*      */ 
/*      */   private void terminateQueue()
/*      */   {
/* 1630 */     synchronized (this.qLock) {
/* 1631 */       if (this.q != null) {
/* 1632 */         Vector dummyListeners = new Vector();
/* 1633 */         dummyListeners.setSize(1);
/* 1634 */         this.q.enqueue(new TerminatorEvent(), dummyListeners);
/* 1635 */         this.q = null;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void finalize() throws Throwable {
/* 1641 */     super.finalize();
/* 1642 */     terminateQueue();
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/* 1652 */     String s = getFullName();
/* 1653 */     if (s != null) {
/* 1654 */       return s;
/*      */     }
/* 1656 */     return super.toString();
/*      */   }
/*      */ 
/*      */   static class TerminatorEvent extends MailEvent
/*      */   {
/*      */     private static final long serialVersionUID = 3765761925441296565L;
/*      */ 
/*      */     TerminatorEvent()
/*      */     {
/* 1619 */       super();
/*      */     }
/*      */ 
/*      */     public void dispatch(Object listener)
/*      */     {
/* 1624 */       Thread.currentThread().interrupt();
/*      */     }
/*      */   }
/*      */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.Folder
 * JD-Core Version:    0.6.1
 */