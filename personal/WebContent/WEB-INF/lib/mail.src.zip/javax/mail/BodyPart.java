/*    */ package javax.mail;
/*    */ 
/*    */ public abstract class BodyPart
/*    */   implements Part
/*    */ {
/*    */   protected Multipart parent;
/*    */ 
/*    */   public Multipart getParent()
/*    */   {
/* 64 */     return this.parent;
/*    */   }
/*    */ 
/*    */   void setParent(Multipart parent)
/*    */   {
/* 76 */     this.parent = parent;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.BodyPart
 * JD-Core Version:    0.6.1
 */