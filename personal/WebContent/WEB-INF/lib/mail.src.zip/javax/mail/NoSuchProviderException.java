/*    */ package javax.mail;
/*    */ 
/*    */ public class NoSuchProviderException extends MessagingException
/*    */ {
/*    */   private static final long serialVersionUID = 8058319293154708827L;
/*    */ 
/*    */   public NoSuchProviderException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public NoSuchProviderException(String message)
/*    */   {
/* 62 */     super(message);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.NoSuchProviderException
 * JD-Core Version:    0.6.1
 */