/*     */ package javax.mail;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ import javax.mail.event.TransportEvent;
/*     */ import javax.mail.event.TransportListener;
/*     */ 
/*     */ public abstract class Transport extends Service
/*     */ {
/* 305 */   private Vector transportListeners = null;
/*     */ 
/*     */   public Transport(Session session, URLName urlname)
/*     */   {
/*  72 */     super(session, urlname);
/*     */   }
/*     */ 
/*     */   public static void send(Message msg)
/*     */     throws MessagingException
/*     */   {
/* 119 */     msg.saveChanges();
/* 120 */     send0(msg, msg.getAllRecipients());
/*     */   }
/*     */ 
/*     */   public static void send(Message msg, Address[] addresses)
/*     */     throws MessagingException
/*     */   {
/* 141 */     msg.saveChanges();
/* 142 */     send0(msg, addresses);
/*     */   }
/*     */ 
/*     */   private static void send0(Message msg, Address[] addresses)
/*     */     throws MessagingException
/*     */   {
/* 149 */     if ((addresses == null) || (addresses.length == 0)) {
/* 150 */       throw new SendFailedException("No recipient addresses");
/*     */     }
/*     */ 
/* 156 */     Hashtable protocols = new Hashtable();
/*     */ 
/* 159 */     Vector invalid = new Vector();
/* 160 */     Vector validSent = new Vector();
/* 161 */     Vector validUnsent = new Vector();
/*     */ 
/* 163 */     for (int i = 0; i < addresses.length; i++)
/*     */     {
/* 165 */       if (protocols.containsKey(addresses[i].getType())) {
/* 166 */         Vector v = (Vector)protocols.get(addresses[i].getType());
/* 167 */         v.addElement(addresses[i]);
/*     */       }
/*     */       else {
/* 170 */         Vector w = new Vector();
/* 171 */         w.addElement(addresses[i]);
/* 172 */         protocols.put(addresses[i].getType(), w);
/*     */       }
/*     */     }
/*     */ 
/* 176 */     int dsize = protocols.size();
/* 177 */     if (dsize == 0) {
/* 178 */       throw new SendFailedException("No recipient addresses");
/*     */     }
/* 180 */     Session s = msg.session != null ? msg.session : Session.getDefaultInstance(System.getProperties(), null);
/*     */ 
/* 187 */     if (dsize == 1) {
/* 188 */       Transport transport = s.getTransport(addresses[0]);
/*     */       try {
/* 190 */         transport.connect();
/* 191 */         transport.sendMessage(msg, addresses);
/*     */       } finally {
/* 193 */         transport.close();
/*     */       }
/* 195 */       return;
/*     */     }
/*     */ 
/* 202 */     Object chainedEx = null;
/* 203 */     boolean sendFailed = false;
/*     */ 
/* 205 */     Enumeration e = protocols.elements();
/* 206 */     while (e.hasMoreElements()) {
/* 207 */       Vector v = (Vector)e.nextElement();
/* 208 */       Address[] protaddresses = new Address[v.size()];
/* 209 */       v.copyInto(protaddresses);
/*     */       Transport transport;
/* 212 */       if ((transport = s.getTransport(protaddresses[0])) == null)
/*     */       {
/* 215 */         for (int j = 0; j < protaddresses.length; j++)
/* 216 */           invalid.addElement(protaddresses[j]);
/*     */       }
/*     */       else {
/*     */         try {
/* 220 */           transport.connect();
/* 221 */           transport.sendMessage(msg, protaddresses);
/*     */         } catch (SendFailedException sex) {
/* 223 */           sendFailed = true;
/*     */ 
/* 225 */           if (chainedEx == null)
/* 226 */             chainedEx = sex;
/*     */           else {
/* 228 */             ((MessagingException)chainedEx).setNextException(sex);
/*     */           }
/*     */ 
/* 231 */           Address[] a = sex.getInvalidAddresses();
/* 232 */           if (a != null) {
/* 233 */             for (int j = 0; j < a.length; j++) {
/* 234 */               invalid.addElement(a[j]);
/*     */             }
/*     */           }
/* 237 */           a = sex.getValidSentAddresses();
/* 238 */           if (a != null) {
/* 239 */             for (int k = 0; k < a.length; k++) {
/* 240 */               validSent.addElement(a[k]);
/*     */             }
/*     */           }
/* 243 */           Address[] c = sex.getValidUnsentAddresses();
/* 244 */           if (c != null)
/* 245 */             for (int l = 0; l < c.length; l++)
/* 246 */               validUnsent.addElement(c[l]);
/*     */         } catch (MessagingException mex) {
/* 248 */           sendFailed = true;
/*     */ 
/* 250 */           if (chainedEx == null)
/* 251 */             chainedEx = mex;
/*     */           else
/* 253 */             ((MessagingException)chainedEx).setNextException(mex);
/*     */         } finally {
/* 255 */           transport.close();
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 260 */     if ((sendFailed) || (invalid.size() != 0) || (validUnsent.size() != 0)) {
/* 261 */       Address[] a = null; Address[] b = null; Address[] c = null;
/*     */ 
/* 264 */       if (validSent.size() > 0) {
/* 265 */         a = new Address[validSent.size()];
/* 266 */         validSent.copyInto(a);
/*     */       }
/* 268 */       if (validUnsent.size() > 0) {
/* 269 */         b = new Address[validUnsent.size()];
/* 270 */         validUnsent.copyInto(b);
/*     */       }
/* 272 */       if (invalid.size() > 0) {
/* 273 */         c = new Address[invalid.size()];
/* 274 */         invalid.copyInto(c);
/*     */       }
/* 276 */       throw new SendFailedException("Sending failed", (Exception)chainedEx, a, b, c);
/*     */     }
/*     */   }
/*     */ 
/*     */   public abstract void sendMessage(Message paramMessage, Address[] paramArrayOfAddress)
/*     */     throws MessagingException;
/*     */ 
/*     */   public synchronized void addTransportListener(TransportListener l)
/*     */   {
/* 317 */     if (this.transportListeners == null)
/* 318 */       this.transportListeners = new Vector();
/* 319 */     this.transportListeners.addElement(l);
/*     */   }
/*     */ 
/*     */   public synchronized void removeTransportListener(TransportListener l)
/*     */   {
/* 332 */     if (this.transportListeners != null)
/* 333 */       this.transportListeners.removeElement(l);
/*     */   }
/*     */ 
/*     */   protected void notifyTransportListeners(int type, Address[] validSent, Address[] validUnsent, Address[] invalid, Message msg)
/*     */   {
/* 349 */     if (this.transportListeners == null) {
/* 350 */       return;
/*     */     }
/* 352 */     TransportEvent e = new TransportEvent(this, type, validSent, validUnsent, invalid, msg);
/*     */ 
/* 354 */     queueEvent(e, this.transportListeners);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.Transport
 * JD-Core Version:    0.6.1
 */