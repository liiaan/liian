/*    */ package javax.mail;
/*    */ 
/*    */ public class MethodNotSupportedException extends MessagingException
/*    */ {
/*    */   private static final long serialVersionUID = -3757386618726131322L;
/*    */ 
/*    */   public MethodNotSupportedException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MethodNotSupportedException(String s)
/*    */   {
/* 64 */     super(s);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.MethodNotSupportedException
 * JD-Core Version:    0.6.1
 */