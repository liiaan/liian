/*     */ package javax.mail;
/*     */ 
/*     */ public class SendFailedException extends MessagingException
/*     */ {
/*     */   protected transient Address[] invalid;
/*     */   protected transient Address[] validSent;
/*     */   protected transient Address[] validUnsent;
/*     */   private static final long serialVersionUID = -6457531621682372913L;
/*     */ 
/*     */   public SendFailedException()
/*     */   {
/*     */   }
/*     */ 
/*     */   public SendFailedException(String s)
/*     */   {
/*  73 */     super(s);
/*     */   }
/*     */ 
/*     */   public SendFailedException(String s, Exception e)
/*     */   {
/*  86 */     super(s, e);
/*     */   }
/*     */ 
/*     */   public SendFailedException(String msg, Exception ex, Address[] validSent, Address[] validUnsent, Address[] invalid)
/*     */   {
/* 104 */     super(msg, ex);
/* 105 */     this.validSent = validSent;
/* 106 */     this.validUnsent = validUnsent;
/* 107 */     this.invalid = invalid;
/*     */   }
/*     */ 
/*     */   public Address[] getValidSentAddresses()
/*     */   {
/* 115 */     return this.validSent;
/*     */   }
/*     */ 
/*     */   public Address[] getValidUnsentAddresses()
/*     */   {
/* 125 */     return this.validUnsent;
/*     */   }
/*     */ 
/*     */   public Address[] getInvalidAddresses()
/*     */   {
/* 134 */     return this.invalid;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.SendFailedException
 * JD-Core Version:    0.6.1
 */