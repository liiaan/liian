package javax.mail;

import javax.activation.DataSource;

public abstract interface MultipartDataSource extends DataSource
{
  public abstract int getCount();

  public abstract BodyPart getBodyPart(int paramInt)
    throws MessagingException;
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.MultipartDataSource
 * JD-Core Version:    0.6.1
 */