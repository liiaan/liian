package javax.mail.event;

import java.util.EventListener;

public abstract interface MessageChangedListener extends EventListener
{
  public abstract void messageChanged(MessageChangedEvent paramMessageChangedEvent);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.event.MessageChangedListener
 * JD-Core Version:    0.6.1
 */