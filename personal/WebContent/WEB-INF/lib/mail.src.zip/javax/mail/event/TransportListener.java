package javax.mail.event;

import java.util.EventListener;

public abstract interface TransportListener extends EventListener
{
  public abstract void messageDelivered(TransportEvent paramTransportEvent);

  public abstract void messageNotDelivered(TransportEvent paramTransportEvent);

  public abstract void messagePartiallyDelivered(TransportEvent paramTransportEvent);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.event.TransportListener
 * JD-Core Version:    0.6.1
 */