package javax.mail.event;

import java.util.EventListener;

public abstract interface ConnectionListener extends EventListener
{
  public abstract void opened(ConnectionEvent paramConnectionEvent);

  public abstract void disconnected(ConnectionEvent paramConnectionEvent);

  public abstract void closed(ConnectionEvent paramConnectionEvent);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.event.ConnectionListener
 * JD-Core Version:    0.6.1
 */