package javax.mail.event;

public abstract class FolderAdapter
  implements FolderListener
{
  public void folderCreated(FolderEvent e)
  {
  }

  public void folderRenamed(FolderEvent e)
  {
  }

  public void folderDeleted(FolderEvent e)
  {
  }
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.event.FolderAdapter
 * JD-Core Version:    0.6.1
 */