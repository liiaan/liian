/*     */ package javax.mail.event;
/*     */ 
/*     */ import javax.mail.Folder;
/*     */ import javax.mail.Message;
/*     */ 
/*     */ public class MessageCountEvent extends MailEvent
/*     */ {
/*     */   public static final int ADDED = 1;
/*     */   public static final int REMOVED = 2;
/*     */   protected int type;
/*     */   protected boolean removed;
/*     */   protected transient Message[] msgs;
/*     */   private static final long serialVersionUID = -7447022340837897369L;
/*     */ 
/*     */   public MessageCountEvent(Folder folder, int type, boolean removed, Message[] msgs)
/*     */   {
/* 104 */     super(folder);
/* 105 */     this.type = type;
/* 106 */     this.removed = removed;
/* 107 */     this.msgs = msgs;
/*     */   }
/*     */ 
/*     */   public int getType()
/*     */   {
/* 115 */     return this.type;
/*     */   }
/*     */ 
/*     */   public boolean isRemoved()
/*     */   {
/* 130 */     return this.removed;
/*     */   }
/*     */ 
/*     */   public Message[] getMessages()
/*     */   {
/* 138 */     return this.msgs;
/*     */   }
/*     */ 
/*     */   public void dispatch(Object listener)
/*     */   {
/* 145 */     if (this.type == 1)
/* 146 */       ((MessageCountListener)listener).messagesAdded(this);
/*     */     else
/* 148 */       ((MessageCountListener)listener).messagesRemoved(this);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.event.MessageCountEvent
 * JD-Core Version:    0.6.1
 */