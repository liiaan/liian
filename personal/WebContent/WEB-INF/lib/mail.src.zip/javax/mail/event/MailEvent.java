/*    */ package javax.mail.event;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ 
/*    */ public abstract class MailEvent extends EventObject
/*    */ {
/*    */   private static final long serialVersionUID = 1846275636325456631L;
/*    */ 
/*    */   public MailEvent(Object source)
/*    */   {
/* 51 */     super(source);
/*    */   }
/*    */ 
/*    */   public abstract void dispatch(Object paramObject);
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.event.MailEvent
 * JD-Core Version:    0.6.1
 */