/*     */ package javax.mail.event;
/*     */ 
/*     */ import javax.mail.Folder;
/*     */ 
/*     */ public class FolderEvent extends MailEvent
/*     */ {
/*     */   public static final int CREATED = 1;
/*     */   public static final int DELETED = 2;
/*     */   public static final int RENAMED = 3;
/*     */   protected int type;
/*     */   protected transient Folder folder;
/*     */   protected transient Folder newFolder;
/*     */   private static final long serialVersionUID = 5278131310563694307L;
/*     */ 
/*     */   public FolderEvent(Object source, Folder folder, int type)
/*     */   {
/*  98 */     this(source, folder, folder, type);
/*     */   }
/*     */ 
/*     */   public FolderEvent(Object source, Folder oldFolder, Folder newFolder, int type)
/*     */   {
/* 112 */     super(source);
/* 113 */     this.folder = oldFolder;
/* 114 */     this.newFolder = newFolder;
/* 115 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public int getType()
/*     */   {
/* 124 */     return this.type;
/*     */   }
/*     */ 
/*     */   public Folder getFolder()
/*     */   {
/* 134 */     return this.folder;
/*     */   }
/*     */ 
/*     */   public Folder getNewFolder()
/*     */   {
/* 149 */     return this.newFolder;
/*     */   }
/*     */ 
/*     */   public void dispatch(Object listener)
/*     */   {
/* 156 */     if (this.type == 1)
/* 157 */       ((FolderListener)listener).folderCreated(this);
/* 158 */     else if (this.type == 2)
/* 159 */       ((FolderListener)listener).folderDeleted(this);
/* 160 */     else if (this.type == 3)
/* 161 */       ((FolderListener)listener).folderRenamed(this);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.event.FolderEvent
 * JD-Core Version:    0.6.1
 */