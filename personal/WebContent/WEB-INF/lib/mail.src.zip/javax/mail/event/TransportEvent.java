/*     */ package javax.mail.event;
/*     */ 
/*     */ import javax.mail.Address;
/*     */ import javax.mail.Message;
/*     */ import javax.mail.Transport;
/*     */ 
/*     */ public class TransportEvent extends MailEvent
/*     */ {
/*     */   public static final int MESSAGE_DELIVERED = 1;
/*     */   public static final int MESSAGE_NOT_DELIVERED = 2;
/*     */   public static final int MESSAGE_PARTIALLY_DELIVERED = 3;
/*     */   protected int type;
/*     */   protected transient Address[] validSent;
/*     */   protected transient Address[] validUnsent;
/*     */   protected transient Address[] invalid;
/*     */   protected transient Message msg;
/*     */   private static final long serialVersionUID = -4729852364684273073L;
/*     */ 
/*     */   public TransportEvent(Transport transport, int type, Address[] validSent, Address[] validUnsent, Address[] invalid, Message msg)
/*     */   {
/*  99 */     super(transport);
/* 100 */     this.type = type;
/* 101 */     this.validSent = validSent;
/* 102 */     this.validUnsent = validUnsent;
/* 103 */     this.invalid = invalid;
/* 104 */     this.msg = msg;
/*     */   }
/*     */ 
/*     */   public int getType()
/*     */   {
/* 112 */     return this.type;
/*     */   }
/*     */ 
/*     */   public Address[] getValidSentAddresses()
/*     */   {
/* 120 */     return this.validSent;
/*     */   }
/*     */ 
/*     */   public Address[] getValidUnsentAddresses()
/*     */   {
/* 130 */     return this.validUnsent;
/*     */   }
/*     */ 
/*     */   public Address[] getInvalidAddresses()
/*     */   {
/* 138 */     return this.invalid;
/*     */   }
/*     */ 
/*     */   public Message getMessage()
/*     */   {
/* 148 */     return this.msg;
/*     */   }
/*     */ 
/*     */   public void dispatch(Object listener)
/*     */   {
/* 155 */     if (this.type == 1)
/* 156 */       ((TransportListener)listener).messageDelivered(this);
/* 157 */     else if (this.type == 2)
/* 158 */       ((TransportListener)listener).messageNotDelivered(this);
/*     */     else
/* 160 */       ((TransportListener)listener).messagePartiallyDelivered(this);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.event.TransportEvent
 * JD-Core Version:    0.6.1
 */