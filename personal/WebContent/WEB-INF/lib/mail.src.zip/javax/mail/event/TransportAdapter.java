package javax.mail.event;

public abstract class TransportAdapter
  implements TransportListener
{
  public void messageDelivered(TransportEvent e)
  {
  }

  public void messageNotDelivered(TransportEvent e)
  {
  }

  public void messagePartiallyDelivered(TransportEvent e)
  {
  }
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.event.TransportAdapter
 * JD-Core Version:    0.6.1
 */