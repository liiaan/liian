package javax.mail.event;

import java.util.EventListener;

public abstract interface MessageCountListener extends EventListener
{
  public abstract void messagesAdded(MessageCountEvent paramMessageCountEvent);

  public abstract void messagesRemoved(MessageCountEvent paramMessageCountEvent);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.event.MessageCountListener
 * JD-Core Version:    0.6.1
 */