/*     */ package javax.mail.event;
/*     */ 
/*     */ import javax.mail.Store;
/*     */ 
/*     */ public class StoreEvent extends MailEvent
/*     */ {
/*     */   public static final int ALERT = 1;
/*     */   public static final int NOTICE = 2;
/*     */   protected int type;
/*     */   protected String message;
/*     */   private static final long serialVersionUID = 1938704919992515330L;
/*     */ 
/*     */   public StoreEvent(Store store, int type, String message)
/*     */   {
/*  84 */     super(store);
/*  85 */     this.type = type;
/*  86 */     this.message = message;
/*     */   }
/*     */ 
/*     */   public int getMessageType()
/*     */   {
/*  97 */     return this.type;
/*     */   }
/*     */ 
/*     */   public String getMessage()
/*     */   {
/* 106 */     return this.message;
/*     */   }
/*     */ 
/*     */   public void dispatch(Object listener)
/*     */   {
/* 113 */     ((StoreListener)listener).notification(this);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.event.StoreEvent
 * JD-Core Version:    0.6.1
 */