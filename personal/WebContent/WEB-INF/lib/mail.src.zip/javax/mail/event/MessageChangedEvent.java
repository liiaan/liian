/*     */ package javax.mail.event;
/*     */ 
/*     */ import javax.mail.Message;
/*     */ 
/*     */ public class MessageChangedEvent extends MailEvent
/*     */ {
/*     */   public static final int FLAGS_CHANGED = 1;
/*     */   public static final int ENVELOPE_CHANGED = 2;
/*     */   protected int type;
/*     */   protected transient Message msg;
/*     */   private static final long serialVersionUID = -4974972972105535108L;
/*     */ 
/*     */   public MessageChangedEvent(Object source, int type, Message msg)
/*     */   {
/*  76 */     super(source);
/*  77 */     this.msg = msg;
/*  78 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public int getMessageChangeType()
/*     */   {
/*  86 */     return this.type;
/*     */   }
/*     */ 
/*     */   public Message getMessage()
/*     */   {
/*  94 */     return this.msg;
/*     */   }
/*     */ 
/*     */   public void dispatch(Object listener)
/*     */   {
/* 101 */     ((MessageChangedListener)listener).messageChanged(this);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.event.MessageChangedEvent
 * JD-Core Version:    0.6.1
 */