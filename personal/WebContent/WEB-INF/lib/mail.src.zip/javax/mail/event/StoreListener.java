package javax.mail.event;

import java.util.EventListener;

public abstract interface StoreListener extends EventListener
{
  public abstract void notification(StoreEvent paramStoreEvent);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.event.StoreListener
 * JD-Core Version:    0.6.1
 */