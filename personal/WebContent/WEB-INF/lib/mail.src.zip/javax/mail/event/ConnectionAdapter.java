package javax.mail.event;

public abstract class ConnectionAdapter
  implements ConnectionListener
{
  public void opened(ConnectionEvent e)
  {
  }

  public void disconnected(ConnectionEvent e)
  {
  }

  public void closed(ConnectionEvent e)
  {
  }
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.event.ConnectionAdapter
 * JD-Core Version:    0.6.1
 */