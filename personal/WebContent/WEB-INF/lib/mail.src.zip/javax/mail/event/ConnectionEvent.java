/*    */ package javax.mail.event;
/*    */ 
/*    */ public class ConnectionEvent extends MailEvent
/*    */ {
/*    */   public static final int OPENED = 1;
/*    */   public static final int DISCONNECTED = 2;
/*    */   public static final int CLOSED = 3;
/*    */   protected int type;
/*    */   private static final long serialVersionUID = -1855480171284792957L;
/*    */ 
/*    */   public ConnectionEvent(Object source, int type)
/*    */   {
/* 71 */     super(source);
/* 72 */     this.type = type;
/*    */   }
/*    */ 
/*    */   public int getType()
/*    */   {
/* 80 */     return this.type;
/*    */   }
/*    */ 
/*    */   public void dispatch(Object listener)
/*    */   {
/* 87 */     if (this.type == 1)
/* 88 */       ((ConnectionListener)listener).opened(this);
/* 89 */     else if (this.type == 2)
/* 90 */       ((ConnectionListener)listener).disconnected(this);
/* 91 */     else if (this.type == 3)
/* 92 */       ((ConnectionListener)listener).closed(this);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.event.ConnectionEvent
 * JD-Core Version:    0.6.1
 */