/*    */ package javax.mail;
/*    */ 
/*    */ public final class PasswordAuthentication
/*    */ {
/*    */   private String userName;
/*    */   private String password;
/*    */ 
/*    */   public PasswordAuthentication(String userName, String password)
/*    */   {
/* 62 */     this.userName = userName;
/* 63 */     this.password = password;
/*    */   }
/*    */ 
/*    */   public String getUserName()
/*    */   {
/* 70 */     return this.userName;
/*    */   }
/*    */ 
/*    */   public String getPassword()
/*    */   {
/* 77 */     return this.password;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.PasswordAuthentication
 * JD-Core Version:    0.6.1
 */