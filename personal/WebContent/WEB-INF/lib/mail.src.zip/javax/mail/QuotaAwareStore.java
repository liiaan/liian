package javax.mail;

public abstract interface QuotaAwareStore
{
  public abstract Quota[] getQuota(String paramString)
    throws MessagingException;

  public abstract void setQuota(Quota paramQuota)
    throws MessagingException;
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.QuotaAwareStore
 * JD-Core Version:    0.6.1
 */