/*    */ package javax.mail;
/*    */ 
/*    */ public class FolderNotFoundException extends MessagingException
/*    */ {
/*    */   private transient Folder folder;
/*    */   private static final long serialVersionUID = 472612108891249403L;
/*    */ 
/*    */   public FolderNotFoundException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public FolderNotFoundException(Folder folder)
/*    */   {
/* 67 */     this.folder = folder;
/*    */   }
/*    */ 
/*    */   public FolderNotFoundException(Folder folder, String s)
/*    */   {
/* 78 */     super(s);
/* 79 */     this.folder = folder;
/*    */   }
/*    */ 
/*    */   public FolderNotFoundException(String s, Folder folder)
/*    */   {
/* 89 */     super(s);
/* 90 */     this.folder = folder;
/*    */   }
/*    */ 
/*    */   public Folder getFolder()
/*    */   {
/* 99 */     return this.folder;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.FolderNotFoundException
 * JD-Core Version:    0.6.1
 */