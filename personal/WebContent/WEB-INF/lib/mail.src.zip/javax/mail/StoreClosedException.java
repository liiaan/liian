/*    */ package javax.mail;
/*    */ 
/*    */ public class StoreClosedException extends MessagingException
/*    */ {
/*    */   private transient Store store;
/*    */   private static final long serialVersionUID = -3145392336120082655L;
/*    */ 
/*    */   public StoreClosedException(Store store)
/*    */   {
/* 64 */     this(store, null);
/*    */   }
/*    */ 
/*    */   public StoreClosedException(Store store, String message)
/*    */   {
/* 73 */     super(message);
/* 74 */     this.store = store;
/*    */   }
/*    */ 
/*    */   public Store getStore()
/*    */   {
/* 81 */     return this.store;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.StoreClosedException
 * JD-Core Version:    0.6.1
 */