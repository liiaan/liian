/*     */ package javax.mail;
/*     */ 
/*     */ public class MessagingException extends Exception
/*     */ {
/*     */   private Exception next;
/*     */   private static final long serialVersionUID = -7569192289819959253L;
/*     */ 
/*     */   public MessagingException()
/*     */   {
/*  64 */     initCause(null);
/*     */   }
/*     */ 
/*     */   public MessagingException(String s)
/*     */   {
/*  73 */     super(s);
/*  74 */     initCause(null);
/*     */   }
/*     */ 
/*     */   public MessagingException(String s, Exception e)
/*     */   {
/*  89 */     super(s);
/*  90 */     this.next = e;
/*  91 */     initCause(null);
/*     */   }
/*     */ 
/*     */   public synchronized Exception getNextException()
/*     */   {
/* 102 */     return this.next;
/*     */   }
/*     */ 
/*     */   public synchronized Throwable getCause()
/*     */   {
/* 112 */     return this.next;
/*     */   }
/*     */ 
/*     */   public synchronized boolean setNextException(Exception ex)
/*     */   {
/* 125 */     Exception theEnd = this;
/*     */ 
/* 127 */     while (((theEnd instanceof MessagingException)) && (((MessagingException)theEnd).next != null)) {
/* 128 */       theEnd = ((MessagingException)theEnd).next;
/*     */     }
/*     */ 
/* 132 */     if ((theEnd instanceof MessagingException)) {
/* 133 */       ((MessagingException)theEnd).next = ex;
/* 134 */       return true;
/*     */     }
/* 136 */     return false;
/*     */   }
/*     */ 
/*     */   public synchronized String toString()
/*     */   {
/* 144 */     String s = super.toString();
/* 145 */     Exception n = this.next;
/* 146 */     if (n == null)
/* 147 */       return s;
/* 148 */     StringBuffer sb = new StringBuffer(s == null ? "" : s);
/* 149 */     while (n != null) {
/* 150 */       sb.append(";\n  nested exception is:\n\t");
/* 151 */       if ((n instanceof MessagingException)) {
/* 152 */         MessagingException mex = (MessagingException)n;
/* 153 */         sb.append(mex.superToString());
/* 154 */         n = mex.next;
/*     */       } else {
/* 156 */         sb.append(n.toString());
/* 157 */         n = null;
/*     */       }
/*     */     }
/* 160 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private final String superToString()
/*     */   {
/* 168 */     return super.toString();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.MessagingException
 * JD-Core Version:    0.6.1
 */