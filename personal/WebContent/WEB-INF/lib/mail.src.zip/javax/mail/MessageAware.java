package javax.mail;

public abstract interface MessageAware
{
  public abstract MessageContext getMessageContext();
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.MessageAware
 * JD-Core Version:    0.6.1
 */