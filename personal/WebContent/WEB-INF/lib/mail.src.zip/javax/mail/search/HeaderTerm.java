/*     */ package javax.mail.search;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import javax.mail.Message;
/*     */ 
/*     */ public final class HeaderTerm extends StringTerm
/*     */ {
/*     */   protected String headerName;
/*     */   private static final long serialVersionUID = 8342514650333389122L;
/*     */ 
/*     */   public HeaderTerm(String headerName, String pattern)
/*     */   {
/*  66 */     super(pattern);
/*  67 */     this.headerName = headerName;
/*     */   }
/*     */ 
/*     */   public String getHeaderName()
/*     */   {
/*  74 */     return this.headerName;
/*     */   }
/*     */ 
/*     */   public boolean match(Message msg)
/*     */   {
/*     */     String[] headers;
/*     */     try
/*     */     {
/*  87 */       headers = msg.getHeader(this.headerName);
/*     */     } catch (Exception e) {
/*  89 */       return false;
/*     */     }
/*     */ 
/*  92 */     if (headers == null) {
/*  93 */       return false;
/*     */     }
/*  95 */     for (int i = 0; i < headers.length; i++)
/*  96 */       if (super.match(headers[i]))
/*  97 */         return true;
/*  98 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 105 */     if (!(obj instanceof HeaderTerm))
/* 106 */       return false;
/* 107 */     HeaderTerm ht = (HeaderTerm)obj;
/*     */ 
/* 109 */     return (ht.headerName.equalsIgnoreCase(this.headerName)) && (super.equals(ht));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 117 */     return this.headerName.toLowerCase(Locale.ENGLISH).hashCode() + super.hashCode();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.search.HeaderTerm
 * JD-Core Version:    0.6.1
 */