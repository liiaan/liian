/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.Address;
/*    */ import javax.mail.internet.InternetAddress;
/*    */ 
/*    */ public abstract class AddressStringTerm extends StringTerm
/*    */ {
/*    */   private static final long serialVersionUID = 3086821234204980368L;
/*    */ 
/*    */   protected AddressStringTerm(String pattern)
/*    */   {
/* 64 */     super(pattern, true);
/*    */   }
/*    */ 
/*    */   protected boolean match(Address a)
/*    */   {
/* 80 */     if ((a instanceof InternetAddress)) {
/* 81 */       InternetAddress ia = (InternetAddress)a;
/*    */ 
/* 86 */       return super.match(ia.toUnicodeString());
/*    */     }
/* 88 */     return super.match(a.toString());
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 95 */     if (!(obj instanceof AddressStringTerm))
/* 96 */       return false;
/* 97 */     return super.equals(obj);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.search.AddressStringTerm
 * JD-Core Version:    0.6.1
 */