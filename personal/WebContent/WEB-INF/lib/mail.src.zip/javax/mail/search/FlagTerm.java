/*     */ package javax.mail.search;
/*     */ 
/*     */ import javax.mail.Flags;
/*     */ import javax.mail.Flags.Flag;
/*     */ import javax.mail.Message;
/*     */ 
/*     */ public final class FlagTerm extends SearchTerm
/*     */ {
/*     */   protected boolean set;
/*     */   protected Flags flags;
/*     */   private static final long serialVersionUID = -142991500302030647L;
/*     */ 
/*     */   public FlagTerm(Flags flags, boolean set)
/*     */   {
/*  75 */     this.flags = flags;
/*  76 */     this.set = set;
/*     */   }
/*     */ 
/*     */   public Flags getFlags()
/*     */   {
/*  83 */     return (Flags)this.flags.clone();
/*     */   }
/*     */ 
/*     */   public boolean getTestSet()
/*     */   {
/*  90 */     return this.set;
/*     */   }
/*     */ 
/*     */   public boolean match(Message msg)
/*     */   {
/*     */     try
/*     */     {
/* 102 */       Flags f = msg.getFlags();
/* 103 */       if (this.set) {
/* 104 */         if (f.contains(this.flags)) {
/* 105 */           return true;
/*     */         }
/* 107 */         return false;
/*     */       }
/*     */ 
/* 114 */       Flags.Flag[] sf = this.flags.getSystemFlags();
/*     */ 
/* 117 */       for (int i = 0; i < sf.length; i++) {
/* 118 */         if (f.contains(sf[i]))
/*     */         {
/* 120 */           return false;
/*     */         }
/*     */       }
/* 123 */       String[] s = this.flags.getUserFlags();
/*     */ 
/* 126 */       for (int i = 0; i < s.length; i++) {
/* 127 */         if (f.contains(s[i]))
/*     */         {
/* 129 */           return false;
/*     */         }
/*     */       }
/* 132 */       return true;
/*     */     } catch (Exception e) {
/*     */     }
/* 135 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 143 */     if (!(obj instanceof FlagTerm))
/* 144 */       return false;
/* 145 */     FlagTerm ft = (FlagTerm)obj;
/* 146 */     return (ft.set == this.set) && (ft.flags.equals(this.flags));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 153 */     return this.set ? this.flags.hashCode() : this.flags.hashCode() ^ 0xFFFFFFFF;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.search.FlagTerm
 * JD-Core Version:    0.6.1
 */