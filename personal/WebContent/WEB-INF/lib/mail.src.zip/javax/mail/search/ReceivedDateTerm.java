/*    */ package javax.mail.search;
/*    */ 
/*    */ import java.util.Date;
/*    */ import javax.mail.Message;
/*    */ 
/*    */ public final class ReceivedDateTerm extends DateTerm
/*    */ {
/*    */   private static final long serialVersionUID = -2756695246195503170L;
/*    */ 
/*    */   public ReceivedDateTerm(int comparison, Date date)
/*    */   {
/* 59 */     super(comparison, date);
/*    */   }
/*    */ 
/*    */   public boolean match(Message msg)
/*    */   {
/*    */     Date d;
/*    */     try
/*    */     {
/* 73 */       d = msg.getReceivedDate();
/*    */     } catch (Exception e) {
/* 75 */       return false;
/*    */     }
/*    */ 
/* 78 */     if (d == null) {
/* 79 */       return false;
/*    */     }
/* 81 */     return super.match(d);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 88 */     if (!(obj instanceof ReceivedDateTerm))
/* 89 */       return false;
/* 90 */     return super.equals(obj);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.search.ReceivedDateTerm
 * JD-Core Version:    0.6.1
 */