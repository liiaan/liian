/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.Address;
/*    */ 
/*    */ public abstract class AddressTerm extends SearchTerm
/*    */ {
/*    */   protected Address address;
/*    */   private static final long serialVersionUID = 2005405551929769980L;
/*    */ 
/*    */   protected AddressTerm(Address address)
/*    */   {
/* 59 */     this.address = address;
/*    */   }
/*    */ 
/*    */   public Address getAddress()
/*    */   {
/* 66 */     return this.address;
/*    */   }
/*    */ 
/*    */   protected boolean match(Address a)
/*    */   {
/* 73 */     return a.equals(this.address);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 80 */     if (!(obj instanceof AddressTerm))
/* 81 */       return false;
/* 82 */     AddressTerm at = (AddressTerm)obj;
/* 83 */     return at.address.equals(this.address);
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 90 */     return this.address.hashCode();
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.search.AddressTerm
 * JD-Core Version:    0.6.1
 */