/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.Message;
/*    */ 
/*    */ public final class MessageIDTerm extends StringTerm
/*    */ {
/*    */   private static final long serialVersionUID = -2121096296454691963L;
/*    */ 
/*    */   public MessageIDTerm(String msgid)
/*    */   {
/* 63 */     super(msgid);
/*    */   }
/*    */ 
/*    */   public boolean match(Message msg)
/*    */   {
/*    */     String[] s;
/*    */     try
/*    */     {
/* 77 */       s = msg.getHeader("Message-ID");
/*    */     } catch (Exception e) {
/* 79 */       return false;
/*    */     }
/*    */ 
/* 82 */     if (s == null) {
/* 83 */       return false;
/*    */     }
/* 85 */     for (int i = 0; i < s.length; i++)
/* 86 */       if (super.match(s[i]))
/* 87 */         return true;
/* 88 */     return false;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 95 */     if (!(obj instanceof MessageIDTerm))
/* 96 */       return false;
/* 97 */     return super.equals(obj);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.search.MessageIDTerm
 * JD-Core Version:    0.6.1
 */