/*     */ package javax.mail.search;
/*     */ 
/*     */ import javax.mail.Address;
/*     */ import javax.mail.Message;
/*     */ import javax.mail.Message.RecipientType;
/*     */ 
/*     */ public final class RecipientStringTerm extends AddressStringTerm
/*     */ {
/*     */   private Message.RecipientType type;
/*     */   private static final long serialVersionUID = -8293562089611618849L;
/*     */ 
/*     */   public RecipientStringTerm(Message.RecipientType type, String pattern)
/*     */   {
/*  71 */     super(pattern);
/*  72 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public Message.RecipientType getRecipientType()
/*     */   {
/*  79 */     return this.type;
/*     */   }
/*     */ 
/*     */   public boolean match(Message msg)
/*     */   {
/*     */     Address[] recipients;
/*     */     try
/*     */     {
/*  94 */       recipients = msg.getRecipients(this.type);
/*     */     } catch (Exception e) {
/*  96 */       return false;
/*     */     }
/*     */ 
/*  99 */     if (recipients == null) {
/* 100 */       return false;
/*     */     }
/* 102 */     for (int i = 0; i < recipients.length; i++)
/* 103 */       if (super.match(recipients[i]))
/* 104 */         return true;
/* 105 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 112 */     if (!(obj instanceof RecipientStringTerm))
/* 113 */       return false;
/* 114 */     RecipientStringTerm rst = (RecipientStringTerm)obj;
/* 115 */     return (rst.type.equals(this.type)) && (super.equals(obj));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 122 */     return this.type.hashCode() + super.hashCode();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.search.RecipientStringTerm
 * JD-Core Version:    0.6.1
 */