/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.Message;
/*    */ 
/*    */ public final class SubjectTerm extends StringTerm
/*    */ {
/*    */   private static final long serialVersionUID = 7481568618055573432L;
/*    */ 
/*    */   public SubjectTerm(String pattern)
/*    */   {
/* 59 */     super(pattern);
/*    */   }
/*    */ 
/*    */   public boolean match(Message msg)
/*    */   {
/*    */     String subj;
/*    */     try
/*    */     {
/* 73 */       subj = msg.getSubject();
/*    */     } catch (Exception e) {
/* 75 */       return false;
/*    */     }
/*    */ 
/* 78 */     if (subj == null) {
/* 79 */       return false;
/*    */     }
/* 81 */     return super.match(subj);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 88 */     if (!(obj instanceof SubjectTerm))
/* 89 */       return false;
/* 90 */     return super.equals(obj);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.search.SubjectTerm
 * JD-Core Version:    0.6.1
 */