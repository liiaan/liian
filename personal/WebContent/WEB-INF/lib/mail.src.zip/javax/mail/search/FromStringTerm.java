/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.Address;
/*    */ import javax.mail.Message;
/*    */ 
/*    */ public final class FromStringTerm extends AddressStringTerm
/*    */ {
/*    */   private static final long serialVersionUID = 5801127523826772788L;
/*    */ 
/*    */   public FromStringTerm(String pattern)
/*    */   {
/* 63 */     super(pattern);
/*    */   }
/*    */ 
/*    */   public boolean match(Message msg)
/*    */   {
/*    */     Address[] from;
/*    */     try
/*    */     {
/* 78 */       from = msg.getFrom();
/*    */     } catch (Exception e) {
/* 80 */       return false;
/*    */     }
/*    */ 
/* 83 */     if (from == null) {
/* 84 */       return false;
/*    */     }
/* 86 */     for (int i = 0; i < from.length; i++)
/* 87 */       if (super.match(from[i]))
/* 88 */         return true;
/* 89 */     return false;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 96 */     if (!(obj instanceof FromStringTerm))
/* 97 */       return false;
/* 98 */     return super.equals(obj);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.search.FromStringTerm
 * JD-Core Version:    0.6.1
 */