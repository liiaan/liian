/*     */ package javax.mail.search;
/*     */ 
/*     */ import javax.mail.Message;
/*     */ import javax.mail.Multipart;
/*     */ import javax.mail.Part;
/*     */ 
/*     */ public final class BodyTerm extends StringTerm
/*     */ {
/*     */   private static final long serialVersionUID = -4888862527916911385L;
/*     */ 
/*     */   public BodyTerm(String pattern)
/*     */   {
/*  58 */     super(pattern);
/*     */   }
/*     */ 
/*     */   public boolean match(Message msg)
/*     */   {
/*  68 */     return matchPart(msg);
/*     */   }
/*     */ 
/*     */   private boolean matchPart(Part p)
/*     */   {
/*     */     try
/*     */     {
/*  81 */       if (p.isMimeType("text/*")) {
/*  82 */         String s = (String)p.getContent();
/*  83 */         if (s == null) {
/*  84 */           return false;
/*     */         }
/*     */ 
/*  93 */         return super.match(s);
/*  94 */       }if (p.isMimeType("multipart/*")) {
/*  95 */         Multipart mp = (Multipart)p.getContent();
/*  96 */         int count = mp.getCount();
/*  97 */         for (int i = 0; i < count; i++)
/*  98 */           if (matchPart(mp.getBodyPart(i)))
/*  99 */             return true;
/* 100 */       } else if (p.isMimeType("message/rfc822")) {
/* 101 */         return matchPart((Part)p.getContent());
/*     */       }
/*     */     } catch (Exception ex) {
/*     */     }
/* 105 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 112 */     if (!(obj instanceof BodyTerm))
/* 113 */       return false;
/* 114 */     return super.equals(obj);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.search.BodyTerm
 * JD-Core Version:    0.6.1
 */