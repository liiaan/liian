/*     */ package javax.mail.search;
/*     */ 
/*     */ public abstract class StringTerm extends SearchTerm
/*     */ {
/*     */   protected String pattern;
/*     */   protected boolean ignoreCase;
/*     */   private static final long serialVersionUID = 1274042129007696269L;
/*     */ 
/*     */   protected StringTerm(String pattern)
/*     */   {
/*  65 */     this.pattern = pattern;
/*  66 */     this.ignoreCase = true;
/*     */   }
/*     */ 
/*     */   protected StringTerm(String pattern, boolean ignoreCase) {
/*  70 */     this.pattern = pattern;
/*  71 */     this.ignoreCase = ignoreCase;
/*     */   }
/*     */ 
/*     */   public String getPattern()
/*     */   {
/*  78 */     return this.pattern;
/*     */   }
/*     */ 
/*     */   public boolean getIgnoreCase()
/*     */   {
/*  85 */     return this.ignoreCase;
/*     */   }
/*     */ 
/*     */   protected boolean match(String s) {
/*  89 */     int len = s.length() - this.pattern.length();
/*  90 */     for (int i = 0; i <= len; i++)
/*  91 */       if (s.regionMatches(this.ignoreCase, i, this.pattern, 0, this.pattern.length()))
/*     */       {
/*  93 */         return true;
/*     */       }
/*  95 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 102 */     if (!(obj instanceof StringTerm))
/* 103 */       return false;
/* 104 */     StringTerm st = (StringTerm)obj;
/* 105 */     if (this.ignoreCase) {
/* 106 */       return (st.pattern.equalsIgnoreCase(this.pattern)) && (st.ignoreCase == this.ignoreCase);
/*     */     }
/*     */ 
/* 109 */     return (st.pattern.equals(this.pattern)) && (st.ignoreCase == this.ignoreCase);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 117 */     return this.ignoreCase ? this.pattern.hashCode() : this.pattern.hashCode() ^ 0xFFFFFFFF;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.search.StringTerm
 * JD-Core Version:    0.6.1
 */