/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.Message;
/*    */ 
/*    */ public final class MessageNumberTerm extends IntegerComparisonTerm
/*    */ {
/*    */   private static final long serialVersionUID = -5379625829658623812L;
/*    */ 
/*    */   public MessageNumberTerm(int number)
/*    */   {
/* 57 */     super(3, number);
/*    */   }
/*    */ 
/*    */   public boolean match(Message msg)
/*    */   {
/*    */     int msgno;
/*    */     try
/*    */     {
/* 70 */       msgno = msg.getMessageNumber();
/*    */     } catch (Exception e) {
/* 72 */       return false;
/*    */     }
/*    */ 
/* 75 */     return super.match(msgno);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 82 */     if (!(obj instanceof MessageNumberTerm))
/* 83 */       return false;
/* 84 */     return super.equals(obj);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.search.MessageNumberTerm
 * JD-Core Version:    0.6.1
 */