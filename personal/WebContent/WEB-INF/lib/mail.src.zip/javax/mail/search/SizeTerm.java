/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.Message;
/*    */ 
/*    */ public final class SizeTerm extends IntegerComparisonTerm
/*    */ {
/*    */   private static final long serialVersionUID = -2556219451005103709L;
/*    */ 
/*    */   public SizeTerm(int comparison, int size)
/*    */   {
/* 58 */     super(comparison, size);
/*    */   }
/*    */ 
/*    */   public boolean match(Message msg)
/*    */   {
/*    */     int size;
/*    */     try
/*    */     {
/* 71 */       size = msg.getSize();
/*    */     } catch (Exception e) {
/* 73 */       return false;
/*    */     }
/*    */ 
/* 76 */     if (size == -1) {
/* 77 */       return false;
/*    */     }
/* 79 */     return super.match(size);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 86 */     if (!(obj instanceof SizeTerm))
/* 87 */       return false;
/* 88 */     return super.equals(obj);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.search.SizeTerm
 * JD-Core Version:    0.6.1
 */