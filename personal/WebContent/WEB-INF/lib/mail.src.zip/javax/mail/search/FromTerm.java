/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.Address;
/*    */ import javax.mail.Message;
/*    */ 
/*    */ public final class FromTerm extends AddressTerm
/*    */ {
/*    */   private static final long serialVersionUID = 5214730291502658665L;
/*    */ 
/*    */   public FromTerm(Address address)
/*    */   {
/* 57 */     super(address);
/*    */   }
/*    */ 
/*    */   public boolean match(Message msg)
/*    */   {
/*    */     Address[] from;
/*    */     try
/*    */     {
/* 70 */       from = msg.getFrom();
/*    */     } catch (Exception e) {
/* 72 */       return false;
/*    */     }
/*    */ 
/* 75 */     if (from == null) {
/* 76 */       return false;
/*    */     }
/* 78 */     for (int i = 0; i < from.length; i++)
/* 79 */       if (super.match(from[i]))
/* 80 */         return true;
/* 81 */     return false;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 88 */     if (!(obj instanceof FromTerm))
/* 89 */       return false;
/* 90 */     return super.equals(obj);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.search.FromTerm
 * JD-Core Version:    0.6.1
 */