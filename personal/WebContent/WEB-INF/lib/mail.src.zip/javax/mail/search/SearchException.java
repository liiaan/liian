/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.MessagingException;
/*    */ 
/*    */ public class SearchException extends MessagingException
/*    */ {
/*    */   private static final long serialVersionUID = -7092886778226268686L;
/*    */ 
/*    */   public SearchException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public SearchException(String s)
/*    */   {
/* 64 */     super(s);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.search.SearchException
 * JD-Core Version:    0.6.1
 */