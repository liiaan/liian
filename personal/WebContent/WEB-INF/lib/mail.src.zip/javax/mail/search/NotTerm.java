/*    */ package javax.mail.search;
/*    */ 
/*    */ import javax.mail.Message;
/*    */ 
/*    */ public final class NotTerm extends SearchTerm
/*    */ {
/*    */   protected SearchTerm term;
/*    */   private static final long serialVersionUID = 7152293214217310216L;
/*    */ 
/*    */   public NotTerm(SearchTerm t)
/*    */   {
/* 58 */     this.term = t;
/*    */   }
/*    */ 
/*    */   public SearchTerm getTerm()
/*    */   {
/* 65 */     return this.term;
/*    */   }
/*    */ 
/*    */   public boolean match(Message msg)
/*    */   {
/* 70 */     return !this.term.match(msg);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 77 */     if (!(obj instanceof NotTerm))
/* 78 */       return false;
/* 79 */     NotTerm nt = (NotTerm)obj;
/* 80 */     return nt.term.equals(this.term);
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 87 */     return this.term.hashCode() << 1;
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.search.NotTerm
 * JD-Core Version:    0.6.1
 */