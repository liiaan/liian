/*     */ package javax.mail.search;
/*     */ 
/*     */ import java.util.Date;
/*     */ 
/*     */ public abstract class DateTerm extends ComparisonTerm
/*     */ {
/*     */   protected Date date;
/*     */   private static final long serialVersionUID = 4818873430063720043L;
/*     */ 
/*     */   protected DateTerm(int comparison, Date date)
/*     */   {
/*  63 */     this.comparison = comparison;
/*  64 */     this.date = date;
/*     */   }
/*     */ 
/*     */   public Date getDate()
/*     */   {
/*  71 */     return new Date(this.date.getTime());
/*     */   }
/*     */ 
/*     */   public int getComparison()
/*     */   {
/*  78 */     return this.comparison;
/*     */   }
/*     */ 
/*     */   protected boolean match(Date d)
/*     */   {
/*  88 */     switch (this.comparison) {
/*     */     case 1:
/*  90 */       return (d.before(this.date)) || (d.equals(this.date));
/*     */     case 2:
/*  92 */       return d.before(this.date);
/*     */     case 3:
/*  94 */       return d.equals(this.date);
/*     */     case 4:
/*  96 */       return !d.equals(this.date);
/*     */     case 5:
/*  98 */       return d.after(this.date);
/*     */     case 6:
/* 100 */       return (d.after(this.date)) || (d.equals(this.date));
/*     */     }
/* 102 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 110 */     if (!(obj instanceof DateTerm))
/* 111 */       return false;
/* 112 */     DateTerm dt = (DateTerm)obj;
/* 113 */     return (dt.date.equals(this.date)) && (super.equals(obj));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 120 */     return this.date.hashCode() + super.hashCode();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.search.DateTerm
 * JD-Core Version:    0.6.1
 */