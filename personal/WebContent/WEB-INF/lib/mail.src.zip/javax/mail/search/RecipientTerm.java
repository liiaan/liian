/*     */ package javax.mail.search;
/*     */ 
/*     */ import javax.mail.Address;
/*     */ import javax.mail.Message;
/*     */ import javax.mail.Message.RecipientType;
/*     */ 
/*     */ public final class RecipientTerm extends AddressTerm
/*     */ {
/*     */   protected Message.RecipientType type;
/*     */   private static final long serialVersionUID = 6548700653122680468L;
/*     */ 
/*     */   public RecipientTerm(Message.RecipientType type, Address address)
/*     */   {
/*  66 */     super(address);
/*  67 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public Message.RecipientType getRecipientType()
/*     */   {
/*  74 */     return this.type;
/*     */   }
/*     */ 
/*     */   public boolean match(Message msg)
/*     */   {
/*     */     Address[] recipients;
/*     */     try
/*     */     {
/*  88 */       recipients = msg.getRecipients(this.type);
/*     */     } catch (Exception e) {
/*  90 */       return false;
/*     */     }
/*     */ 
/*  93 */     if (recipients == null) {
/*  94 */       return false;
/*     */     }
/*  96 */     for (int i = 0; i < recipients.length; i++)
/*  97 */       if (super.match(recipients[i]))
/*  98 */         return true;
/*  99 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 106 */     if (!(obj instanceof RecipientTerm))
/* 107 */       return false;
/* 108 */     RecipientTerm rt = (RecipientTerm)obj;
/* 109 */     return (rt.type.equals(this.type)) && (super.equals(obj));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 116 */     return this.type.hashCode() + super.hashCode();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.search.RecipientTerm
 * JD-Core Version:    0.6.1
 */