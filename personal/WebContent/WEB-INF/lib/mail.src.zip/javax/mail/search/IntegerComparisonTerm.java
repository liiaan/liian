/*     */ package javax.mail.search;
/*     */ 
/*     */ public abstract class IntegerComparisonTerm extends ComparisonTerm
/*     */ {
/*     */   protected int number;
/*     */   private static final long serialVersionUID = -6963571240154302484L;
/*     */ 
/*     */   protected IntegerComparisonTerm(int comparison, int number)
/*     */   {
/*  56 */     this.comparison = comparison;
/*  57 */     this.number = number;
/*     */   }
/*     */ 
/*     */   public int getNumber()
/*     */   {
/*  64 */     return this.number;
/*     */   }
/*     */ 
/*     */   public int getComparison()
/*     */   {
/*  71 */     return this.comparison;
/*     */   }
/*     */ 
/*     */   protected boolean match(int i) {
/*  75 */     switch (this.comparison) {
/*     */     case 1:
/*  77 */       return i <= this.number;
/*     */     case 2:
/*  79 */       return i < this.number;
/*     */     case 3:
/*  81 */       return i == this.number;
/*     */     case 4:
/*  83 */       return i != this.number;
/*     */     case 5:
/*  85 */       return i > this.number;
/*     */     case 6:
/*  87 */       return i >= this.number;
/*     */     }
/*  89 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/*  97 */     if (!(obj instanceof IntegerComparisonTerm))
/*  98 */       return false;
/*  99 */     IntegerComparisonTerm ict = (IntegerComparisonTerm)obj;
/* 100 */     return (ict.number == this.number) && (super.equals(obj));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 107 */     return this.number + super.hashCode();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.search.IntegerComparisonTerm
 * JD-Core Version:    0.6.1
 */