/*    */ package javax.mail.search;
/*    */ 
/*    */ import java.util.Date;
/*    */ import javax.mail.Message;
/*    */ 
/*    */ public final class SentDateTerm extends DateTerm
/*    */ {
/*    */   private static final long serialVersionUID = 5647755030530907263L;
/*    */ 
/*    */   public SentDateTerm(int comparison, Date date)
/*    */   {
/* 59 */     super(comparison, date);
/*    */   }
/*    */ 
/*    */   public boolean match(Message msg)
/*    */   {
/*    */     Date d;
/*    */     try
/*    */     {
/* 73 */       d = msg.getSentDate();
/*    */     } catch (Exception e) {
/* 75 */       return false;
/*    */     }
/*    */ 
/* 78 */     if (d == null) {
/* 79 */       return false;
/*    */     }
/* 81 */     return super.match(d);
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 88 */     if (!(obj instanceof SentDateTerm))
/* 89 */       return false;
/* 90 */     return super.equals(obj);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.search.SentDateTerm
 * JD-Core Version:    0.6.1
 */