/*     */ package javax.mail.search;
/*     */ 
/*     */ import javax.mail.Message;
/*     */ 
/*     */ public final class AndTerm extends SearchTerm
/*     */ {
/*     */   protected SearchTerm[] terms;
/*     */   private static final long serialVersionUID = -3583274505380989582L;
/*     */ 
/*     */   public AndTerm(SearchTerm t1, SearchTerm t2)
/*     */   {
/*  67 */     this.terms = new SearchTerm[2];
/*  68 */     this.terms[0] = t1;
/*  69 */     this.terms[1] = t2;
/*     */   }
/*     */ 
/*     */   public AndTerm(SearchTerm[] t)
/*     */   {
/*  78 */     this.terms = new SearchTerm[t.length];
/*  79 */     for (int i = 0; i < t.length; i++)
/*  80 */       this.terms[i] = t[i];
/*     */   }
/*     */ 
/*     */   public SearchTerm[] getTerms()
/*     */   {
/*  87 */     return (SearchTerm[])this.terms.clone();
/*     */   }
/*     */ 
/*     */   public boolean match(Message msg)
/*     */   {
/* 101 */     for (int i = 0; i < this.terms.length; i++)
/* 102 */       if (!this.terms[i].match(msg))
/* 103 */         return false;
/* 104 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 111 */     if (!(obj instanceof AndTerm))
/* 112 */       return false;
/* 113 */     AndTerm at = (AndTerm)obj;
/* 114 */     if (at.terms.length != this.terms.length)
/* 115 */       return false;
/* 116 */     for (int i = 0; i < this.terms.length; i++)
/* 117 */       if (!this.terms[i].equals(at.terms[i]))
/* 118 */         return false;
/* 119 */     return true;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 126 */     int hash = 0;
/* 127 */     for (int i = 0; i < this.terms.length; i++)
/* 128 */       hash += this.terms[i].hashCode();
/* 129 */     return hash;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.search.AndTerm
 * JD-Core Version:    0.6.1
 */