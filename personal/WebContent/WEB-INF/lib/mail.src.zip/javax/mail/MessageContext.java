/*     */ package javax.mail;
/*     */ 
/*     */ public class MessageContext
/*     */ {
/*     */   private Part part;
/*     */ 
/*     */   public MessageContext(Part part)
/*     */   {
/*  60 */     this.part = part;
/*     */   }
/*     */ 
/*     */   public Part getPart()
/*     */   {
/*  69 */     return this.part;
/*     */   }
/*     */ 
/*     */   public Message getMessage()
/*     */   {
/*     */     try
/*     */     {
/*  81 */       return getMessage(this.part); } catch (MessagingException ex) {
/*     */     }
/*  83 */     return null;
/*     */   }
/*     */ 
/*     */   private static Message getMessage(Part p)
/*     */     throws MessagingException
/*     */   {
/*  97 */     while (p != null) {
/*  98 */       if ((p instanceof Message))
/*  99 */         return (Message)p;
/* 100 */       BodyPart bp = (BodyPart)p;
/* 101 */       Multipart mp = bp.getParent();
/* 102 */       if (mp == null)
/* 103 */         return null;
/* 104 */       p = mp.getParent();
/*     */     }
/* 106 */     return null;
/*     */   }
/*     */ 
/*     */   public Session getSession()
/*     */   {
/* 115 */     Message msg = getMessage();
/* 116 */     return msg != null ? msg.session : null;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.MessageContext
 * JD-Core Version:    0.6.1
 */