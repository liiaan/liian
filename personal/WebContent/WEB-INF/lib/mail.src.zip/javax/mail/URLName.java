/*     */ package javax.mail;
/*     */ 
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.BitSet;
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class URLName
/*     */ {
/*     */   protected String fullURL;
/*     */   private String protocol;
/*     */   private String username;
/*     */   private String password;
/*     */   private String host;
/*     */   private InetAddress hostAddress;
/*  94 */   private boolean hostAddressKnown = false;
/*     */ 
/*  99 */   private int port = -1;
/*     */   private String file;
/*     */   private String ref;
/* 114 */   private int hashCode = 0;
/*     */ 
/* 119 */   private static boolean doEncode = true;
/*     */   static BitSet dontNeedEncoding;
/*     */   static final int caseDiff = 32;
/*     */ 
/*     */   public URLName(String protocol, String host, int port, String file, String username, String password)
/*     */   {
/* 144 */     this.protocol = protocol;
/* 145 */     this.host = host;
/* 146 */     this.port = port;
/*     */     int refStart;
/* 148 */     if ((file != null) && ((refStart = file.indexOf('#')) != -1)) {
/* 149 */       this.file = file.substring(0, refStart);
/* 150 */       this.ref = file.substring(refStart + 1);
/*     */     } else {
/* 152 */       this.file = file;
/* 153 */       this.ref = null;
/*     */     }
/* 155 */     this.username = (doEncode ? encode(username) : username);
/* 156 */     this.password = (doEncode ? encode(password) : password);
/*     */   }
/*     */ 
/*     */   public URLName(URL url)
/*     */   {
/* 163 */     this(url.toString());
/*     */   }
/*     */ 
/*     */   public URLName(String url)
/*     */   {
/* 171 */     parseString(url);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 178 */     if (this.fullURL == null)
/*     */     {
/* 180 */       StringBuffer tempURL = new StringBuffer();
/* 181 */       if (this.protocol != null) {
/* 182 */         tempURL.append(this.protocol);
/* 183 */         tempURL.append(":");
/*     */       }
/*     */ 
/* 186 */       if ((this.username != null) || (this.host != null))
/*     */       {
/* 188 */         tempURL.append("//");
/*     */ 
/* 192 */         if (this.username != null) {
/* 193 */           tempURL.append(this.username);
/*     */ 
/* 195 */           if (this.password != null) {
/* 196 */             tempURL.append(":");
/* 197 */             tempURL.append(this.password);
/*     */           }
/*     */ 
/* 200 */           tempURL.append("@");
/*     */         }
/*     */ 
/* 204 */         if (this.host != null) {
/* 205 */           tempURL.append(this.host);
/*     */         }
/*     */ 
/* 209 */         if (this.port != -1) {
/* 210 */           tempURL.append(":");
/* 211 */           tempURL.append(Integer.toString(this.port));
/*     */         }
/* 213 */         if (this.file != null) {
/* 214 */           tempURL.append("/");
/*     */         }
/*     */       }
/*     */ 
/* 218 */       if (this.file != null) {
/* 219 */         tempURL.append(this.file);
/*     */       }
/*     */ 
/* 223 */       if (this.ref != null) {
/* 224 */         tempURL.append("#");
/* 225 */         tempURL.append(this.ref);
/*     */       }
/*     */ 
/* 229 */       this.fullURL = tempURL.toString();
/*     */     }
/*     */ 
/* 232 */     return this.fullURL;
/*     */   }
/*     */ 
/*     */   protected void parseString(String url)
/*     */   {
/* 241 */     this.protocol = (this.file = this.ref = this.host = this.username = this.password = null);
/* 242 */     this.port = -1;
/*     */ 
/* 244 */     int len = url.length();
/*     */ 
/* 249 */     int protocolEnd = url.indexOf(':');
/* 250 */     if (protocolEnd != -1) {
/* 251 */       this.protocol = url.substring(0, protocolEnd);
/*     */     }
/*     */ 
/* 254 */     if (url.regionMatches(protocolEnd + 1, "//", 0, 2))
/*     */     {
/* 256 */       String fullhost = null;
/* 257 */       int fileStart = url.indexOf('/', protocolEnd + 3);
/* 258 */       if (fileStart != -1) {
/* 259 */         fullhost = url.substring(protocolEnd + 3, fileStart);
/* 260 */         if (fileStart + 1 < len)
/* 261 */           this.file = url.substring(fileStart + 1);
/*     */         else
/* 263 */           this.file = "";
/*     */       } else {
/* 265 */         fullhost = url.substring(protocolEnd + 3);
/*     */       }
/*     */ 
/* 268 */       int i = fullhost.indexOf('@');
/* 269 */       if (i != -1) {
/* 270 */         String fulluserpass = fullhost.substring(0, i);
/* 271 */         fullhost = fullhost.substring(i + 1);
/*     */ 
/* 274 */         int passindex = fulluserpass.indexOf(':');
/* 275 */         if (passindex != -1) {
/* 276 */           this.username = fulluserpass.substring(0, passindex);
/* 277 */           this.password = fulluserpass.substring(passindex + 1);
/*     */         } else {
/* 279 */           this.username = fulluserpass;
/*     */         }
/*     */       }
/*     */       int portindex;
/*     */       int portindex;
/* 285 */       if ((fullhost.length() > 0) && (fullhost.charAt(0) == '['))
/*     */       {
/* 287 */         portindex = fullhost.indexOf(':', fullhost.indexOf(93));
/*     */       }
/* 289 */       else portindex = fullhost.indexOf(':');
/*     */ 
/* 291 */       if (portindex != -1) {
/* 292 */         String portstring = fullhost.substring(portindex + 1);
/* 293 */         if (portstring.length() > 0) {
/*     */           try {
/* 295 */             this.port = Integer.parseInt(portstring);
/*     */           } catch (NumberFormatException nfex) {
/* 297 */             this.port = -1;
/*     */           }
/*     */         }
/*     */ 
/* 301 */         this.host = fullhost.substring(0, portindex);
/*     */       } else {
/* 303 */         this.host = fullhost;
/*     */       }
/*     */     }
/* 306 */     else if (protocolEnd + 1 < len) {
/* 307 */       this.file = url.substring(protocolEnd + 1);
/*     */     }
/*     */     int refStart;
/* 312 */     if ((this.file != null) && ((refStart = this.file.indexOf('#')) != -1)) {
/* 313 */       this.ref = this.file.substring(refStart + 1);
/* 314 */       this.file = this.file.substring(0, refStart);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 323 */     return this.port;
/*     */   }
/*     */ 
/*     */   public String getProtocol()
/*     */   {
/* 331 */     return this.protocol;
/*     */   }
/*     */ 
/*     */   public String getFile()
/*     */   {
/* 339 */     return this.file;
/*     */   }
/*     */ 
/*     */   public String getRef()
/*     */   {
/* 347 */     return this.ref;
/*     */   }
/*     */ 
/*     */   public String getHost()
/*     */   {
/* 355 */     return this.host;
/*     */   }
/*     */ 
/*     */   public String getUsername()
/*     */   {
/* 363 */     return doEncode ? decode(this.username) : this.username;
/*     */   }
/*     */ 
/*     */   public String getPassword()
/*     */   {
/* 371 */     return doEncode ? decode(this.password) : this.password;
/*     */   }
/*     */ 
/*     */   public URL getURL()
/*     */     throws MalformedURLException
/*     */   {
/* 378 */     return new URL(getProtocol(), getHost(), getPort(), getFile());
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 403 */     if (!(obj instanceof URLName))
/* 404 */       return false;
/* 405 */     URLName u2 = (URLName)obj;
/*     */ 
/* 408 */     if ((u2.protocol == null) || (!u2.protocol.equals(this.protocol))) {
/* 409 */       return false;
/*     */     }
/*     */ 
/* 412 */     InetAddress a1 = getHostAddress(); InetAddress a2 = u2.getHostAddress();
/*     */ 
/* 414 */     if ((a1 != null) && (a2 != null)) {
/* 415 */       if (!a1.equals(a2))
/* 416 */         return false;
/*     */     }
/* 418 */     else if ((this.host != null) && (u2.host != null)) {
/* 419 */       if (!this.host.equalsIgnoreCase(u2.host))
/* 420 */         return false;
/*     */     }
/* 422 */     else if (this.host != u2.host) {
/* 423 */       return false;
/*     */     }
/*     */ 
/* 428 */     if ((this.username != u2.username) && ((this.username == null) || (!this.username.equals(u2.username))))
/*     */     {
/* 430 */       return false;
/*     */     }
/*     */ 
/* 436 */     String f1 = this.file == null ? "" : this.file;
/* 437 */     String f2 = u2.file == null ? "" : u2.file;
/*     */ 
/* 439 */     if (!f1.equals(f2)) {
/* 440 */       return false;
/*     */     }
/*     */ 
/* 443 */     if (this.port != u2.port) {
/* 444 */       return false;
/*     */     }
/*     */ 
/* 447 */     return true;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 454 */     if (this.hashCode != 0)
/* 455 */       return this.hashCode;
/* 456 */     if (this.protocol != null)
/* 457 */       this.hashCode += this.protocol.hashCode();
/* 458 */     InetAddress addr = getHostAddress();
/* 459 */     if (addr != null)
/* 460 */       this.hashCode += addr.hashCode();
/* 461 */     else if (this.host != null)
/* 462 */       this.hashCode += this.host.toLowerCase(Locale.ENGLISH).hashCode();
/* 463 */     if (this.username != null)
/* 464 */       this.hashCode += this.username.hashCode();
/* 465 */     if (this.file != null)
/* 466 */       this.hashCode += this.file.hashCode();
/* 467 */     this.hashCode += this.port;
/* 468 */     return this.hashCode;
/*     */   }
/*     */ 
/*     */   private synchronized InetAddress getHostAddress()
/*     */   {
/* 477 */     if (this.hostAddressKnown)
/* 478 */       return this.hostAddress;
/* 479 */     if (this.host == null)
/* 480 */       return null;
/*     */     try {
/* 482 */       this.hostAddress = InetAddress.getByName(this.host);
/*     */     } catch (UnknownHostException ex) {
/* 484 */       this.hostAddress = null;
/*     */     }
/* 486 */     this.hostAddressKnown = true;
/* 487 */     return this.hostAddress;
/*     */   }
/*     */ 
/*     */   static String encode(String s)
/*     */   {
/* 544 */     if (s == null) {
/* 545 */       return null;
/*     */     }
/* 547 */     for (int i = 0; i < s.length(); i++) {
/* 548 */       int c = s.charAt(i);
/* 549 */       if ((c == 32) || (!dontNeedEncoding.get(c)))
/* 550 */         return _encode(s);
/*     */     }
/* 552 */     return s;
/*     */   }
/*     */ 
/*     */   private static String _encode(String s) {
/* 556 */     int maxBytesPerChar = 10;
/* 557 */     StringBuffer out = new StringBuffer(s.length());
/* 558 */     ByteArrayOutputStream buf = new ByteArrayOutputStream(maxBytesPerChar);
/* 559 */     OutputStreamWriter writer = new OutputStreamWriter(buf);
/*     */ 
/* 561 */     for (int i = 0; i < s.length(); i++) {
/* 562 */       int c = s.charAt(i);
/* 563 */       if (dontNeedEncoding.get(c)) {
/* 564 */         if (c == 32) {
/* 565 */           c = 43;
/*     */         }
/* 567 */         out.append((char)c);
/*     */       }
/*     */       else {
/*     */         try {
/* 571 */           writer.write(c);
/* 572 */           writer.flush();
/*     */         } catch (IOException e) {
/* 574 */           buf.reset();
/* 575 */           continue;
/*     */         }
/* 577 */         byte[] ba = buf.toByteArray();
/* 578 */         for (int j = 0; j < ba.length; j++) {
/* 579 */           out.append('%');
/* 580 */           char ch = Character.forDigit(ba[j] >> 4 & 0xF, 16);
/*     */ 
/* 583 */           if (Character.isLetter(ch)) {
/* 584 */             ch = (char)(ch - ' ');
/*     */           }
/* 586 */           out.append(ch);
/* 587 */           ch = Character.forDigit(ba[j] & 0xF, 16);
/* 588 */           if (Character.isLetter(ch)) {
/* 589 */             ch = (char)(ch - ' ');
/*     */           }
/* 591 */           out.append(ch);
/*     */         }
/* 593 */         buf.reset();
/*     */       }
/*     */     }
/*     */ 
/* 597 */     return out.toString();
/*     */   }
/*     */ 
/*     */   static String decode(String s)
/*     */   {
/* 631 */     if (s == null)
/* 632 */       return null;
/* 633 */     if (indexOfAny(s, "+%") == -1) {
/* 634 */       return s;
/*     */     }
/* 636 */     StringBuffer sb = new StringBuffer();
/* 637 */     for (int i = 0; i < s.length(); i++) {
/* 638 */       char c = s.charAt(i);
/* 639 */       switch (c) {
/*     */       case '+':
/* 641 */         sb.append(' ');
/* 642 */         break;
/*     */       case '%':
/*     */         try {
/* 645 */           sb.append((char)Integer.parseInt(s.substring(i + 1, i + 3), 16));
/*     */         }
/*     */         catch (NumberFormatException e) {
/* 648 */           throw new IllegalArgumentException("Illegal URL encoded value: " + s.substring(i, i + 3));
/*     */         }
/*     */ 
/* 652 */         i += 2;
/* 653 */         break;
/*     */       default:
/* 655 */         sb.append(c);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 660 */     String result = sb.toString();
/*     */     try {
/* 662 */       byte[] inputBytes = result.getBytes("8859_1");
/* 663 */       result = new String(inputBytes);
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {
/*     */     }
/* 667 */     return result;
/*     */   }
/*     */ 
/*     */   private static int indexOfAny(String s, String any)
/*     */   {
/* 677 */     return indexOfAny(s, any, 0);
/*     */   }
/*     */ 
/*     */   private static int indexOfAny(String s, String any, int start) {
/*     */     try {
/* 682 */       int len = s.length();
/* 683 */       for (int i = start; i < len; i++) {
/* 684 */         if (any.indexOf(s.charAt(i)) >= 0)
/* 685 */           return i;
/*     */       }
/* 687 */       return -1; } catch (StringIndexOutOfBoundsException e) {
/*     */     }
/* 689 */     return -1;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/* 123 */       doEncode = !Boolean.getBoolean("mail.URLName.dontencode");
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */ 
/* 518 */     dontNeedEncoding = new BitSet(256);
/*     */ 
/* 520 */     for (int i = 97; i <= 122; i++) {
/* 521 */       dontNeedEncoding.set(i);
/*     */     }
/* 523 */     for (i = 65; i <= 90; i++) {
/* 524 */       dontNeedEncoding.set(i);
/*     */     }
/* 526 */     for (i = 48; i <= 57; i++) {
/* 527 */       dontNeedEncoding.set(i);
/*     */     }
/*     */ 
/* 530 */     dontNeedEncoding.set(32);
/* 531 */     dontNeedEncoding.set(45);
/* 532 */     dontNeedEncoding.set(95);
/* 533 */     dontNeedEncoding.set(46);
/* 534 */     dontNeedEncoding.set(42);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.URLName
 * JD-Core Version:    0.6.1
 */