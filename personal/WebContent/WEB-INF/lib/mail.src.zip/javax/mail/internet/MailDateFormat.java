/*     */ package javax.mail.internet;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.text.FieldPosition;
/*     */ import java.text.NumberFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.ParsePosition;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ public class MailDateFormat extends SimpleDateFormat
/*     */ {
/*     */   private static final long serialVersionUID = -8148227605210628779L;
/* 250 */   static boolean debug = false;
/*     */ 
/* 337 */   private static TimeZone tz = TimeZone.getTimeZone("GMT");
/* 338 */   private static Calendar cal = new GregorianCalendar(tz);
/*     */ 
/*     */   public MailDateFormat()
/*     */   {
/* 137 */     super("EEE, d MMM yyyy HH:mm:ss 'XXXXX' (z)", Locale.US);
/*     */   }
/*     */ 
/*     */   public StringBuffer format(Date date, StringBuffer dateStrBuf, FieldPosition fieldPosition)
/*     */   {
/* 161 */     int start = dateStrBuf.length();
/* 162 */     super.format(date, dateStrBuf, fieldPosition);
/* 163 */     int pos = 0;
/*     */ 
/* 166 */     for (pos = start + 25; dateStrBuf.charAt(pos) != 'X'; pos++);
/* 170 */     this.calendar.clear();
/* 171 */     this.calendar.setTime(date);
/* 172 */     int offset = this.calendar.get(15) + this.calendar.get(16);
/*     */ 
/* 175 */     if (offset < 0) {
/* 176 */       dateStrBuf.setCharAt(pos++, '-');
/* 177 */       offset = -offset;
/*     */     } else {
/* 179 */       dateStrBuf.setCharAt(pos++, '+');
/*     */     }
/* 181 */     int rawOffsetInMins = offset / 60 / 1000;
/* 182 */     int offsetInHrs = rawOffsetInMins / 60;
/* 183 */     int offsetInMins = rawOffsetInMins % 60;
/*     */ 
/* 185 */     dateStrBuf.setCharAt(pos++, Character.forDigit(offsetInHrs / 10, 10));
/* 186 */     dateStrBuf.setCharAt(pos++, Character.forDigit(offsetInHrs % 10, 10));
/* 187 */     dateStrBuf.setCharAt(pos++, Character.forDigit(offsetInMins / 10, 10));
/* 188 */     dateStrBuf.setCharAt(pos++, Character.forDigit(offsetInMins % 10, 10));
/*     */ 
/* 191 */     return dateStrBuf;
/*     */   }
/*     */ 
/*     */   public Date parse(String text, ParsePosition pos)
/*     */   {
/* 206 */     return parseDate(text.toCharArray(), pos, isLenient());
/*     */   }
/*     */ 
/*     */   private static Date parseDate(char[] orig, ParsePosition pos, boolean lenient)
/*     */   {
/*     */     try
/*     */     {
/* 258 */       int day = -1;
/* 259 */       int month = -1;
/* 260 */       int year = -1;
/* 261 */       int hours = 0;
/* 262 */       int minutes = 0;
/* 263 */       int seconds = 0;
/* 264 */       int offset = 0;
/*     */ 
/* 266 */       MailDateParser p = new MailDateParser(orig, pos.getIndex());
/*     */ 
/* 269 */       p.skipUntilNumber();
/* 270 */       day = p.parseNumber();
/*     */ 
/* 272 */       if (!p.skipIfChar('-')) {
/* 273 */         p.skipWhiteSpace();
/*     */       }
/*     */ 
/* 277 */       month = p.parseMonth();
/* 278 */       if (!p.skipIfChar('-')) {
/* 279 */         p.skipWhiteSpace();
/*     */       }
/*     */ 
/* 283 */       year = p.parseNumber();
/* 284 */       if (year < 50)
/* 285 */         year += 2000;
/* 286 */       else if (year < 100) {
/* 287 */         year += 1900;
/*     */       }
/*     */ 
/* 293 */       p.skipWhiteSpace();
/* 294 */       hours = p.parseNumber();
/*     */ 
/* 297 */       p.skipChar(':');
/* 298 */       minutes = p.parseNumber();
/*     */ 
/* 301 */       if (p.skipIfChar(':')) {
/* 302 */         seconds = p.parseNumber();
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 308 */         p.skipWhiteSpace();
/* 309 */         offset = p.parseTimeZone();
/*     */       } catch (ParseException pe) {
/* 311 */         if (debug) {
/* 312 */           System.out.println("No timezone? : '" + new String(orig) + "'");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 317 */       pos.setIndex(p.getIndex());
/* 318 */       return ourUTC(year, month, day, hours, minutes, seconds, offset, lenient);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 328 */       if (debug) {
/* 329 */         System.out.println("Bad date: '" + new String(orig) + "'");
/* 330 */         e.printStackTrace();
/*     */       }
/* 332 */       pos.setIndex(1);
/* 333 */     }return null;
/*     */   }
/*     */ 
/*     */   private static synchronized Date ourUTC(int year, int mon, int mday, int hour, int min, int sec, int tzoffset, boolean lenient)
/*     */   {
/* 343 */     cal.clear();
/* 344 */     cal.setLenient(lenient);
/* 345 */     cal.set(1, year);
/* 346 */     cal.set(2, mon);
/* 347 */     cal.set(5, mday);
/* 348 */     cal.set(11, hour);
/* 349 */     cal.set(12, min);
/* 350 */     cal.add(12, tzoffset);
/* 351 */     cal.set(13, sec);
/*     */ 
/* 353 */     return cal.getTime();
/*     */   }
/*     */ 
/*     */   public void setCalendar(Calendar newCalendar)
/*     */   {
/* 361 */     throw new RuntimeException("Method setCalendar() shouldn't be called");
/*     */   }
/*     */ 
/*     */   public void setNumberFormat(NumberFormat newNumberFormat)
/*     */   {
/* 366 */     throw new RuntimeException("Method setNumberFormat() shouldn't be called");
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.internet.MailDateFormat
 * JD-Core Version:    0.6.1
 */