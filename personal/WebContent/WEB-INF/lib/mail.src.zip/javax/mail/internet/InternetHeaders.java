/*     */ package javax.mail.internet;
/*     */ 
/*     */ import com.sun.mail.util.LineInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ import javax.mail.Header;
/*     */ import javax.mail.MessagingException;
/*     */ 
/*     */ public class InternetHeaders
/*     */ {
/*     */   protected List headers;
/*     */ 
/*     */   public InternetHeaders()
/*     */   {
/* 261 */     this.headers = new ArrayList(40);
/* 262 */     this.headers.add(new InternetHeader("Return-Path", null));
/* 263 */     this.headers.add(new InternetHeader("Received", null));
/* 264 */     this.headers.add(new InternetHeader("Resent-Date", null));
/* 265 */     this.headers.add(new InternetHeader("Resent-From", null));
/* 266 */     this.headers.add(new InternetHeader("Resent-Sender", null));
/* 267 */     this.headers.add(new InternetHeader("Resent-To", null));
/* 268 */     this.headers.add(new InternetHeader("Resent-Cc", null));
/* 269 */     this.headers.add(new InternetHeader("Resent-Bcc", null));
/* 270 */     this.headers.add(new InternetHeader("Resent-Message-Id", null));
/* 271 */     this.headers.add(new InternetHeader("Date", null));
/* 272 */     this.headers.add(new InternetHeader("From", null));
/* 273 */     this.headers.add(new InternetHeader("Sender", null));
/* 274 */     this.headers.add(new InternetHeader("Reply-To", null));
/* 275 */     this.headers.add(new InternetHeader("To", null));
/* 276 */     this.headers.add(new InternetHeader("Cc", null));
/* 277 */     this.headers.add(new InternetHeader("Bcc", null));
/* 278 */     this.headers.add(new InternetHeader("Message-Id", null));
/* 279 */     this.headers.add(new InternetHeader("In-Reply-To", null));
/* 280 */     this.headers.add(new InternetHeader("References", null));
/* 281 */     this.headers.add(new InternetHeader("Subject", null));
/* 282 */     this.headers.add(new InternetHeader("Comments", null));
/* 283 */     this.headers.add(new InternetHeader("Keywords", null));
/* 284 */     this.headers.add(new InternetHeader("Errors-To", null));
/* 285 */     this.headers.add(new InternetHeader("MIME-Version", null));
/* 286 */     this.headers.add(new InternetHeader("Content-Type", null));
/* 287 */     this.headers.add(new InternetHeader("Content-Transfer-Encoding", null));
/* 288 */     this.headers.add(new InternetHeader("Content-MD5", null));
/* 289 */     this.headers.add(new InternetHeader(":", null));
/* 290 */     this.headers.add(new InternetHeader("Content-Length", null));
/* 291 */     this.headers.add(new InternetHeader("Status", null));
/*     */   }
/*     */ 
/*     */   public InternetHeaders(InputStream is)
/*     */     throws MessagingException
/*     */   {
/* 309 */     this.headers = new ArrayList(40);
/* 310 */     load(is);
/*     */   }
/*     */ 
/*     */   public void load(InputStream is)
/*     */     throws MessagingException
/*     */   {
/* 330 */     LineInputStream lis = new LineInputStream(is);
/* 331 */     String prevline = null;
/*     */ 
/* 333 */     StringBuffer lineBuffer = new StringBuffer();
/*     */     try
/*     */     {
/*     */       String line;
/*     */       do {
/* 338 */         line = lis.readLine();
/* 339 */         if ((line != null) && ((line.startsWith(" ")) || (line.startsWith("\t"))))
/*     */         {
/* 342 */           if (prevline != null) {
/* 343 */             lineBuffer.append(prevline);
/* 344 */             prevline = null;
/*     */           }
/* 346 */           lineBuffer.append("\r\n");
/* 347 */           lineBuffer.append(line);
/*     */         }
/*     */         else {
/* 350 */           if (prevline != null) {
/* 351 */             addHeaderLine(prevline);
/* 352 */           } else if (lineBuffer.length() > 0)
/*     */           {
/* 354 */             addHeaderLine(lineBuffer.toString());
/* 355 */             lineBuffer.setLength(0);
/*     */           }
/* 357 */           prevline = line;
/*     */         }
/* 359 */         if (line == null) break;  } while (line.length() > 0);
/*     */     } catch (IOException ioex) {
/* 361 */       throw new MessagingException("Error in input stream", ioex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String[] getHeader(String name)
/*     */   {
/* 374 */     Iterator e = this.headers.iterator();
/*     */ 
/* 376 */     List v = new ArrayList();
/*     */ 
/* 378 */     while (e.hasNext()) {
/* 379 */       InternetHeader h = (InternetHeader)e.next();
/* 380 */       if ((name.equalsIgnoreCase(h.getName())) && (h.line != null)) {
/* 381 */         v.add(h.getValue());
/*     */       }
/*     */     }
/* 384 */     if (v.size() == 0) {
/* 385 */       return null;
/*     */     }
/* 387 */     String[] r = new String[v.size()];
/* 388 */     r = (String[])v.toArray(r);
/* 389 */     return r;
/*     */   }
/*     */ 
/*     */   public String getHeader(String name, String delimiter)
/*     */   {
/* 405 */     String[] s = getHeader(name);
/*     */ 
/* 407 */     if (s == null) {
/* 408 */       return null;
/*     */     }
/* 410 */     if ((s.length == 1) || (delimiter == null)) {
/* 411 */       return s[0];
/*     */     }
/* 413 */     StringBuffer r = new StringBuffer(s[0]);
/* 414 */     for (int i = 1; i < s.length; i++) {
/* 415 */       r.append(delimiter);
/* 416 */       r.append(s[i]);
/*     */     }
/* 418 */     return r.toString();
/*     */   }
/*     */ 
/*     */   public void setHeader(String name, String value)
/*     */   {
/* 432 */     boolean found = false;
/*     */ 
/* 434 */     for (int i = 0; i < this.headers.size(); i++) {
/* 435 */       InternetHeader h = (InternetHeader)this.headers.get(i);
/* 436 */       if (name.equalsIgnoreCase(h.getName())) {
/* 437 */         if (!found)
/*     */         {
/*     */           int j;
/* 439 */           if ((h.line != null) && ((j = h.line.indexOf(':')) >= 0)) {
/* 440 */             h.line = (h.line.substring(0, j + 1) + " " + value);
/*     */           }
/*     */           else {
/* 443 */             h.line = (name + ": " + value);
/*     */           }
/* 445 */           found = true;
/*     */         } else {
/* 447 */           this.headers.remove(i);
/* 448 */           i--;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 453 */     if (!found)
/* 454 */       addHeader(name, value);
/*     */   }
/*     */ 
/*     */   public void addHeader(String name, String value)
/*     */   {
/* 474 */     int pos = this.headers.size();
/* 475 */     boolean addReverse = (name.equalsIgnoreCase("Received")) || (name.equalsIgnoreCase("Return-Path"));
/*     */ 
/* 478 */     if (addReverse)
/* 479 */       pos = 0;
/* 480 */     for (int i = this.headers.size() - 1; i >= 0; i--) {
/* 481 */       InternetHeader h = (InternetHeader)this.headers.get(i);
/* 482 */       if (name.equalsIgnoreCase(h.getName())) {
/* 483 */         if (addReverse) {
/* 484 */           pos = i;
/*     */         } else {
/* 486 */           this.headers.add(i + 1, new InternetHeader(name, value));
/* 487 */           return;
/*     */         }
/*     */       }
/*     */ 
/* 491 */       if ((!addReverse) && (h.getName().equals(":")))
/* 492 */         pos = i;
/*     */     }
/* 494 */     this.headers.add(pos, new InternetHeader(name, value));
/*     */   }
/*     */ 
/*     */   public void removeHeader(String name)
/*     */   {
/* 502 */     for (int i = 0; i < this.headers.size(); i++) {
/* 503 */       InternetHeader h = (InternetHeader)this.headers.get(i);
/* 504 */       if (name.equalsIgnoreCase(h.getName()))
/* 505 */         h.line = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Enumeration getAllHeaders()
/*     */   {
/* 519 */     return new matchEnum(this.headers, null, false, false);
/*     */   }
/*     */ 
/*     */   public Enumeration getMatchingHeaders(String[] names)
/*     */   {
/* 528 */     return new matchEnum(this.headers, names, true, false);
/*     */   }
/*     */ 
/*     */   public Enumeration getNonMatchingHeaders(String[] names)
/*     */   {
/* 537 */     return new matchEnum(this.headers, names, false, false);
/*     */   }
/*     */ 
/*     */   public void addHeaderLine(String line)
/*     */   {
/*     */     try
/*     */     {
/* 552 */       char c = line.charAt(0);
/* 553 */       if ((c == ' ') || (c == '\t')) {
/* 554 */         InternetHeader h = (InternetHeader)this.headers.get(this.headers.size() - 1);
/*     */         InternetHeader tmp50_49 = h; tmp50_49.line = (tmp50_49.line + "\r\n" + line);
/*     */       } else {
/* 558 */         this.headers.add(new InternetHeader(line));
/*     */       }
/*     */     }
/*     */     catch (StringIndexOutOfBoundsException e)
/*     */     {
/*     */     }
/*     */     catch (NoSuchElementException e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public Enumeration getAllHeaderLines()
/*     */   {
/* 571 */     return getNonMatchingHeaderLines(null);
/*     */   }
/*     */ 
/*     */   public Enumeration getMatchingHeaderLines(String[] names)
/*     */   {
/* 578 */     return new matchEnum(this.headers, names, true, true);
/*     */   }
/*     */ 
/*     */   public Enumeration getNonMatchingHeaderLines(String[] names)
/*     */   {
/* 585 */     return new matchEnum(this.headers, names, false, true);
/*     */   }
/*     */ 
/*     */   static class matchEnum
/*     */     implements Enumeration
/*     */   {
/*     */     private Iterator e;
/*     */     private String[] names;
/*     */     private boolean match;
/*     */     private boolean want_line;
/*     */     private InternetHeaders.InternetHeader next_header;
/*     */ 
/*     */     matchEnum(List v, String[] n, boolean m, boolean l)
/*     */     {
/* 165 */       this.e = v.iterator();
/* 166 */       this.names = n;
/* 167 */       this.match = m;
/* 168 */       this.want_line = l;
/* 169 */       this.next_header = null;
/*     */     }
/*     */ 
/*     */     public boolean hasMoreElements()
/*     */     {
/* 178 */       if (this.next_header == null)
/* 179 */         this.next_header = nextMatch();
/* 180 */       return this.next_header != null;
/*     */     }
/*     */ 
/*     */     public Object nextElement()
/*     */     {
/* 187 */       if (this.next_header == null) {
/* 188 */         this.next_header = nextMatch();
/*     */       }
/* 190 */       if (this.next_header == null) {
/* 191 */         throw new NoSuchElementException("No more headers");
/*     */       }
/* 193 */       InternetHeaders.InternetHeader h = this.next_header;
/* 194 */       this.next_header = null;
/* 195 */       if (this.want_line) {
/* 196 */         return h.line;
/*     */       }
/* 198 */       return new Header(h.getName(), h.getValue());
/*     */     }
/*     */ 
/*     */     private InternetHeaders.InternetHeader nextMatch()
/*     */     {
/* 207 */       while (this.e.hasNext()) {
/* 208 */         InternetHeaders.InternetHeader h = (InternetHeaders.InternetHeader)this.e.next();
/*     */ 
/* 211 */         if (h.line != null)
/*     */         {
/* 215 */           if (this.names == null) {
/* 216 */             return this.match ? null : h;
/*     */           }
/*     */ 
/* 219 */           for (int i = 0; ; i++) { if (i >= this.names.length) break label97;
/* 220 */             if (this.names[i].equalsIgnoreCase(h.getName())) {
/* 221 */               if (!this.match) break;
/* 222 */               return h;
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 231 */           label97: if (!this.match)
/* 232 */             return h; 
/*     */         }
/*     */       }
/* 234 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static final class InternetHeader extends Header
/*     */   {
/*     */     String line;
/*     */ 
/*     */     public InternetHeader(String l)
/*     */     {
/* 104 */       super("");
/* 105 */       int i = l.indexOf(':');
/* 106 */       if (i < 0)
/*     */       {
/* 108 */         this.name = l.trim();
/*     */       }
/* 110 */       else this.name = l.substring(0, i).trim();
/*     */ 
/* 112 */       this.line = l;
/*     */     }
/*     */ 
/*     */     public InternetHeader(String n, String v)
/*     */     {
/* 119 */       super("");
/* 120 */       if (v != null)
/* 121 */         this.line = (n + ": " + v);
/*     */       else
/* 123 */         this.line = null;
/*     */     }
/*     */ 
/*     */     public String getValue()
/*     */     {
/* 130 */       int i = this.line.indexOf(':');
/* 131 */       if (i < 0) {
/* 132 */         return this.line;
/*     */       }
/*     */ 
/* 135 */       for (int j = i + 1; j < this.line.length(); j++) {
/* 136 */         char c = this.line.charAt(j);
/* 137 */         if ((c != ' ') && (c != '\t') && (c != '\r') && (c != '\n'))
/*     */           break;
/*     */       }
/* 140 */       return this.line.substring(j);
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.internet.InternetHeaders
 * JD-Core Version:    0.6.1
 */