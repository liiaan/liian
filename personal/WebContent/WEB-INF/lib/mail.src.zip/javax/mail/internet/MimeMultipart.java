/*      */ package javax.mail.internet;
/*      */ 
/*      */ import com.sun.mail.util.ASCIIUtility;
/*      */ import com.sun.mail.util.LineInputStream;
/*      */ import com.sun.mail.util.LineOutputStream;
/*      */ import com.sun.mail.util.PropUtil;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.EOFException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.util.Vector;
/*      */ import javax.activation.DataSource;
/*      */ import javax.mail.BodyPart;
/*      */ import javax.mail.MessageAware;
/*      */ import javax.mail.MessageContext;
/*      */ import javax.mail.MessagingException;
/*      */ import javax.mail.Multipart;
/*      */ import javax.mail.MultipartDataSource;
/*      */ 
/*      */ public class MimeMultipart extends Multipart
/*      */ {
/*  118 */   protected DataSource ds = null;
/*      */ 
/*  126 */   protected boolean parsed = true;
/*      */ 
/*  131 */   private boolean complete = true;
/*      */ 
/*  137 */   private String preamble = null;
/*      */ 
/*  143 */   private boolean ignoreMissingEndBoundary = true;
/*  144 */   private boolean ignoreMissingBoundaryParameter = true;
/*  145 */   private boolean ignoreExistingBoundaryParameter = false;
/*  146 */   private boolean allowEmpty = false;
/*  147 */   private boolean bmparse = true;
/*      */ 
/*      */   public MimeMultipart()
/*      */   {
/*  159 */     this("mixed");
/*      */   }
/*      */ 
/*      */   public MimeMultipart(String subtype)
/*      */   {
/*  175 */     String boundary = UniqueValue.getUniqueBoundaryValue();
/*  176 */     ContentType cType = new ContentType("multipart", subtype, null);
/*  177 */     cType.setParameter("boundary", boundary);
/*  178 */     this.contentType = cType.toString();
/*      */   }
/*      */ 
/*      */   public MimeMultipart(DataSource ds)
/*      */     throws MessagingException
/*      */   {
/*  202 */     if ((ds instanceof MessageAware)) {
/*  203 */       MessageContext mc = ((MessageAware)ds).getMessageContext();
/*  204 */       setParent(mc.getPart());
/*      */     }
/*      */ 
/*  207 */     if ((ds instanceof MultipartDataSource))
/*      */     {
/*  209 */       setMultipartDataSource((MultipartDataSource)ds);
/*  210 */       return;
/*      */     }
/*      */ 
/*  215 */     this.parsed = false;
/*  216 */     this.ds = ds;
/*  217 */     this.contentType = ds.getContentType();
/*      */   }
/*      */ 
/*      */   public synchronized void setSubType(String subtype)
/*      */     throws MessagingException
/*      */   {
/*  229 */     ContentType cType = new ContentType(this.contentType);
/*  230 */     cType.setSubType(subtype);
/*  231 */     this.contentType = cType.toString();
/*      */   }
/*      */ 
/*      */   public synchronized int getCount()
/*      */     throws MessagingException
/*      */   {
/*  240 */     parse();
/*  241 */     return super.getCount();
/*      */   }
/*      */ 
/*      */   public synchronized BodyPart getBodyPart(int index)
/*      */     throws MessagingException
/*      */   {
/*  253 */     parse();
/*  254 */     return super.getBodyPart(index);
/*      */   }
/*      */ 
/*      */   public synchronized BodyPart getBodyPart(String CID)
/*      */     throws MessagingException
/*      */   {
/*  266 */     parse();
/*      */ 
/*  268 */     int count = getCount();
/*  269 */     for (int i = 0; i < count; i++) {
/*  270 */       MimeBodyPart part = (MimeBodyPart)getBodyPart(i);
/*  271 */       String s = part.getContentID();
/*  272 */       if ((s != null) && (s.equals(CID)))
/*  273 */         return part;
/*      */     }
/*  275 */     return null;
/*      */   }
/*      */ 
/*      */   public boolean removeBodyPart(BodyPart part)
/*      */     throws MessagingException
/*      */   {
/*  290 */     parse();
/*  291 */     return super.removeBodyPart(part);
/*      */   }
/*      */ 
/*      */   public void removeBodyPart(int index)
/*      */     throws MessagingException
/*      */   {
/*  307 */     parse();
/*  308 */     super.removeBodyPart(index);
/*      */   }
/*      */ 
/*      */   public synchronized void addBodyPart(BodyPart part)
/*      */     throws MessagingException
/*      */   {
/*  323 */     parse();
/*  324 */     super.addBodyPart(part);
/*      */   }
/*      */ 
/*      */   public synchronized void addBodyPart(BodyPart part, int index)
/*      */     throws MessagingException
/*      */   {
/*  343 */     parse();
/*  344 */     super.addBodyPart(part, index);
/*      */   }
/*      */ 
/*      */   public synchronized boolean isComplete()
/*      */     throws MessagingException
/*      */   {
/*  362 */     parse();
/*  363 */     return this.complete;
/*      */   }
/*      */ 
/*      */   public synchronized String getPreamble()
/*      */     throws MessagingException
/*      */   {
/*  375 */     parse();
/*  376 */     return this.preamble;
/*      */   }
/*      */ 
/*      */   public synchronized void setPreamble(String preamble)
/*      */     throws MessagingException
/*      */   {
/*  392 */     this.preamble = preamble;
/*      */   }
/*      */ 
/*      */   protected synchronized void updateHeaders()
/*      */     throws MessagingException
/*      */   {
/*  413 */     for (int i = 0; i < this.parts.size(); i++)
/*  414 */       ((MimeBodyPart)this.parts.elementAt(i)).updateHeaders();
/*      */   }
/*      */ 
/*      */   public synchronized void writeTo(OutputStream os)
/*      */     throws IOException, MessagingException
/*      */   {
/*  423 */     parse();
/*      */ 
/*  425 */     String boundary = "--" + new ContentType(this.contentType).getParameter("boundary");
/*      */ 
/*  427 */     LineOutputStream los = new LineOutputStream(os);
/*      */ 
/*  430 */     if (this.preamble != null) {
/*  431 */       byte[] pb = ASCIIUtility.getBytes(this.preamble);
/*  432 */       los.write(pb);
/*      */ 
/*  434 */       if ((pb.length > 0) && (pb[(pb.length - 1)] != 13) && (pb[(pb.length - 1)] != 10))
/*      */       {
/*  436 */         los.writeln();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  441 */     if (this.parts.size() == 0) {
/*  442 */       if (this.allowEmpty)
/*      */       {
/*  444 */         los.writeln(boundary);
/*  445 */         los.writeln();
/*      */       } else {
/*  447 */         throw new MessagingException("Empty multipart: " + this.contentType);
/*      */       }
/*      */     }
/*  450 */     else for (int i = 0; i < this.parts.size(); i++) {
/*  451 */         los.writeln(boundary);
/*  452 */         ((MimeBodyPart)this.parts.elementAt(i)).writeTo(os);
/*  453 */         los.writeln();
/*      */       }
/*      */ 
/*      */ 
/*  458 */     los.writeln(boundary + "--");
/*      */   }
/*      */ 
/*      */   protected synchronized void parse()
/*      */     throws MessagingException
/*      */   {
/*  471 */     if (this.parsed) {
/*  472 */       return;
/*      */     }
/*      */ 
/*  477 */     this.ignoreMissingEndBoundary = PropUtil.getBooleanSystemProperty("mail.mime.multipart.ignoremissingendboundary", true);
/*      */ 
/*  480 */     this.ignoreMissingBoundaryParameter = PropUtil.getBooleanSystemProperty("mail.mime.multipart.ignoremissingboundaryparameter", true);
/*      */ 
/*  483 */     this.ignoreExistingBoundaryParameter = PropUtil.getBooleanSystemProperty("mail.mime.multipart.ignoreexistingboundaryparameter", false);
/*      */ 
/*  486 */     this.allowEmpty = PropUtil.getBooleanSystemProperty("mail.mime.multipart.allowempty", false);
/*      */ 
/*  489 */     this.bmparse = PropUtil.getBooleanSystemProperty("mail.mime.multipart.bmparse", true);
/*      */ 
/*  492 */     if (this.bmparse) {
/*  493 */       parsebm();
/*  494 */       return;
/*      */     }
/*      */ 
/*  497 */     InputStream in = null;
/*  498 */     SharedInputStream sin = null;
/*  499 */     long start = 0L; long end = 0L;
/*      */     try
/*      */     {
/*  502 */       in = this.ds.getInputStream();
/*  503 */       if ((!(in instanceof ByteArrayInputStream)) && (!(in instanceof BufferedInputStream)) && (!(in instanceof SharedInputStream)))
/*      */       {
/*  506 */         in = new BufferedInputStream(in);
/*      */       }
/*      */     } catch (Exception ex) { throw new MessagingException("No inputstream from datasource", ex); }
/*      */ 
/*  510 */     if ((in instanceof SharedInputStream)) {
/*  511 */       sin = (SharedInputStream)in;
/*      */     }
/*  513 */     ContentType cType = new ContentType(this.contentType);
/*  514 */     String boundary = null;
/*  515 */     if (!this.ignoreExistingBoundaryParameter) {
/*  516 */       String bp = cType.getParameter("boundary");
/*  517 */       if (bp != null)
/*  518 */         boundary = "--" + bp;
/*      */     }
/*  520 */     if ((boundary == null) && (!this.ignoreMissingBoundaryParameter) && (!this.ignoreExistingBoundaryParameter))
/*      */     {
/*  522 */       throw new MessagingException("Missing boundary parameter");
/*      */     }
/*      */     try
/*      */     {
/*  526 */       LineInputStream lin = new LineInputStream(in);
/*  527 */       StringBuffer preamblesb = null;
/*      */ 
/*  529 */       String lineSeparator = null;
/*      */       String line;
/*  530 */       while ((line = lin.readLine()) != null)
/*      */       {
/*  538 */         for (int i = line.length() - 1; i >= 0; i--) {
/*  539 */           char c = line.charAt(i);
/*  540 */           if ((c != ' ') && (c != '\t'))
/*      */             break;
/*      */         }
/*  543 */         line = line.substring(0, i + 1);
/*  544 */         if (boundary != null) {
/*  545 */           if (line.equals(boundary))
/*      */             break;
/*  547 */           if ((line.length() == boundary.length() + 2) && (line.startsWith(boundary)) && (line.endsWith("--")))
/*      */           {
/*  549 */             line = null;
/*  550 */             break;
/*      */           }
/*      */ 
/*      */         }
/*  558 */         else if ((line.startsWith("--")) && 
/*  559 */           (!line.endsWith("--")))
/*      */         {
/*  567 */           boundary = line;
/*  568 */           break;
/*      */         }
/*      */ 
/*  574 */         if (line.length() > 0)
/*      */         {
/*  577 */           if (lineSeparator == null) {
/*      */             try {
/*  579 */               lineSeparator = System.getProperty("line.separator", "\n");
/*      */             }
/*      */             catch (SecurityException ex) {
/*  582 */               lineSeparator = "\n";
/*      */             }
/*      */           }
/*      */ 
/*  586 */           if (preamblesb == null)
/*  587 */             preamblesb = new StringBuffer(line.length() + 2);
/*  588 */           preamblesb.append(line).append(lineSeparator);
/*      */         }
/*      */       }
/*      */ 
/*  592 */       if (preamblesb != null) {
/*  593 */         this.preamble = preamblesb.toString();
/*      */       }
/*  595 */       if (line == null) {
/*  596 */         if (this.allowEmpty) {
/*  597 */           return;
/*      */         }
/*  599 */         throw new MessagingException("Missing start boundary");
/*      */       }
/*      */ 
/*  603 */       byte[] bndbytes = ASCIIUtility.getBytes(boundary);
/*  604 */       int bl = bndbytes.length;
/*      */ 
/*  610 */       boolean done = false;
/*      */ 
/*  612 */       while (!done) {
/*  613 */         InternetHeaders headers = null;
/*  614 */         if (sin != null) {
/*  615 */           start = sin.getPosition();
/*      */ 
/*  617 */           while (((line = lin.readLine()) != null) && (line.length() > 0));
/*  619 */           if (line == null) {
/*  620 */             if (!this.ignoreMissingEndBoundary) {
/*  621 */               throw new MessagingException("missing multipart end boundary");
/*      */             }
/*      */ 
/*  624 */             this.complete = false;
/*  625 */             break;
/*      */           }
/*      */         }
/*      */         else {
/*  629 */           headers = createInternetHeaders(in);
/*      */         }
/*      */ 
/*  632 */         if (!in.markSupported()) {
/*  633 */           throw new MessagingException("Stream doesn't support mark");
/*      */         }
/*  635 */         ByteArrayOutputStream buf = null;
/*      */ 
/*  637 */         if (sin == null)
/*  638 */           buf = new ByteArrayOutputStream();
/*      */         else {
/*  640 */           end = sin.getPosition();
/*      */         }
/*  642 */         boolean bol = true;
/*      */ 
/*  644 */         int eol1 = -1; int eol2 = -1;
/*      */         while (true)
/*      */         {
/*  650 */           if (bol)
/*      */           {
/*  656 */             in.mark(bl + 4 + 1000);
/*      */ 
/*  658 */             for (int i = 0; (i < bl) && 
/*  659 */               (in.read() == (bndbytes[i] & 0xFF)); i++);
/*  661 */             if (i == bl)
/*      */             {
/*  663 */               int b2 = in.read();
/*  664 */               if ((b2 == 45) && 
/*  665 */                 (in.read() == 45)) {
/*  666 */                 this.complete = true;
/*  667 */                 done = true;
/*  668 */                 break;
/*      */               }
/*      */ 
/*  672 */               while ((b2 == 32) || (b2 == 9)) {
/*  673 */                 b2 = in.read();
/*      */               }
/*  675 */               if (b2 == 10)
/*      */                 break;
/*  677 */               if (b2 == 13) {
/*  678 */                 in.mark(1);
/*  679 */                 if (in.read() == 10) break;
/*  680 */                 in.reset(); break;
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/*  685 */             in.reset();
/*      */ 
/*  689 */             if ((buf != null) && (eol1 != -1)) {
/*  690 */               buf.write(eol1);
/*  691 */               if (eol2 != -1)
/*  692 */                 buf.write(eol2);
/*  693 */               eol1 = eol2 = -1;
/*      */             }
/*      */           }
/*      */           int b;
/*  698 */           if ((b = in.read()) < 0) {
/*  699 */             if (!this.ignoreMissingEndBoundary) {
/*  700 */               throw new MessagingException("missing multipart end boundary");
/*      */             }
/*  702 */             this.complete = false;
/*  703 */             done = true;
/*  704 */             break;
/*      */           }
/*      */ 
/*  711 */           if ((b == 13) || (b == 10)) {
/*  712 */             bol = true;
/*  713 */             if (sin != null)
/*  714 */               end = sin.getPosition() - 1L;
/*  715 */             eol1 = b;
/*  716 */             if (b == 13) {
/*  717 */               in.mark(1);
/*  718 */               if ((b = in.read()) == 10)
/*  719 */                 eol2 = b;
/*      */               else
/*  721 */                 in.reset();
/*      */             }
/*      */           } else {
/*  724 */             bol = false;
/*  725 */             if (buf != null)
/*  726 */               buf.write(b);
/*      */           }
/*      */         }
/*      */         MimeBodyPart part;
/*      */         MimeBodyPart part;
/*  734 */         if (sin != null)
/*  735 */           part = createMimeBodyPart(sin.newStream(start, end));
/*      */         else
/*  737 */           part = createMimeBodyPart(headers, buf.toByteArray());
/*  738 */         super.addBodyPart(part);
/*      */       }
/*      */     } catch (IOException ioex) {
/*  741 */       throw new MessagingException("IO Error", ioex);
/*      */     } finally {
/*      */       try {
/*  744 */         in.close();
/*      */       }
/*      */       catch (IOException cex)
/*      */       {
/*      */       }
/*      */     }
/*  750 */     this.parsed = true;
/*      */   }
/*      */ 
/*      */   private synchronized void parsebm()
/*      */     throws MessagingException
/*      */   {
/*  767 */     if (this.parsed) {
/*  768 */       return;
/*      */     }
/*  770 */     InputStream in = null;
/*  771 */     SharedInputStream sin = null;
/*  772 */     long start = 0L; long end = 0L;
/*      */     try
/*      */     {
/*  775 */       in = this.ds.getInputStream();
/*  776 */       if ((!(in instanceof ByteArrayInputStream)) && (!(in instanceof BufferedInputStream)) && (!(in instanceof SharedInputStream)))
/*      */       {
/*  779 */         in = new BufferedInputStream(in);
/*      */       }
/*      */     } catch (Exception ex) { throw new MessagingException("No inputstream from datasource", ex); }
/*      */ 
/*  783 */     if ((in instanceof SharedInputStream)) {
/*  784 */       sin = (SharedInputStream)in;
/*      */     }
/*  786 */     ContentType cType = new ContentType(this.contentType);
/*  787 */     String boundary = null;
/*  788 */     if (!this.ignoreExistingBoundaryParameter) {
/*  789 */       String bp = cType.getParameter("boundary");
/*  790 */       if (bp != null)
/*  791 */         boundary = "--" + bp;
/*      */     }
/*  793 */     if ((boundary == null) && (!this.ignoreMissingBoundaryParameter) && (!this.ignoreExistingBoundaryParameter))
/*      */     {
/*  795 */       throw new MessagingException("Missing boundary parameter");
/*      */     }
/*      */     try
/*      */     {
/*  799 */       LineInputStream lin = new LineInputStream(in);
/*  800 */       StringBuffer preamblesb = null;
/*      */ 
/*  802 */       String lineSeparator = null;
/*      */       String line;
/*  803 */       while ((line = lin.readLine()) != null)
/*      */       {
/*  811 */         for (int i = line.length() - 1; i >= 0; i--) {
/*  812 */           char c = line.charAt(i);
/*  813 */           if ((c != ' ') && (c != '\t'))
/*      */             break;
/*      */         }
/*  816 */         line = line.substring(0, i + 1);
/*  817 */         if (boundary != null) {
/*  818 */           if (line.equals(boundary))
/*      */             break;
/*  820 */           if ((line.length() == boundary.length() + 2) && (line.startsWith(boundary)) && (line.endsWith("--")))
/*      */           {
/*  822 */             line = null;
/*  823 */             break;
/*      */           }
/*      */ 
/*      */         }
/*  831 */         else if ((line.startsWith("--")) && 
/*  832 */           (!line.endsWith("--")))
/*      */         {
/*  840 */           boundary = line;
/*  841 */           break;
/*      */         }
/*      */ 
/*  847 */         if (line.length() > 0)
/*      */         {
/*  850 */           if (lineSeparator == null) {
/*      */             try {
/*  852 */               lineSeparator = System.getProperty("line.separator", "\n");
/*      */             }
/*      */             catch (SecurityException ex) {
/*  855 */               lineSeparator = "\n";
/*      */             }
/*      */           }
/*      */ 
/*  859 */           if (preamblesb == null)
/*  860 */             preamblesb = new StringBuffer(line.length() + 2);
/*  861 */           preamblesb.append(line).append(lineSeparator);
/*      */         }
/*      */       }
/*      */ 
/*  865 */       if (preamblesb != null) {
/*  866 */         this.preamble = preamblesb.toString();
/*      */       }
/*  868 */       if (line == null) {
/*  869 */         if (this.allowEmpty) {
/*  870 */           return;
/*      */         }
/*  872 */         throw new MessagingException("Missing start boundary");
/*      */       }
/*      */ 
/*  876 */       byte[] bndbytes = ASCIIUtility.getBytes(boundary);
/*  877 */       int bl = bndbytes.length;
/*      */ 
/*  884 */       int[] bcs = new int[256];
/*  885 */       for (int i = 0; i < bl; i++) {
/*  886 */         bcs[bndbytes[i]] = (i + 1);
/*      */       }
/*      */ 
/*  889 */       int[] gss = new int[bl];
/*      */ 
/*  891 */       label580: for (int i = bl; i > 0; i--)
/*      */       {
/*  893 */         for (int j = bl - 1; j >= i; j--)
/*      */         {
/*  895 */           if (bndbytes[j] != bndbytes[(j - i)])
/*      */             break label580;
/*  897 */           gss[(j - 1)] = i;
/*      */         }
/*      */ 
/*  904 */         while (j > 0)
/*  905 */           gss[(--j)] = i;
/*      */       }
/*  907 */       gss[(bl - 1)] = 1;
/*      */ 
/*  913 */       boolean done = false;
/*      */ 
/*  915 */       while (!done) {
/*  916 */         InternetHeaders headers = null;
/*  917 */         if (sin != null) {
/*  918 */           start = sin.getPosition();
/*      */ 
/*  920 */           while (((line = lin.readLine()) != null) && (line.length() > 0));
/*  922 */           if (line == null) {
/*  923 */             if (!this.ignoreMissingEndBoundary) {
/*  924 */               throw new MessagingException("missing multipart end boundary");
/*      */             }
/*      */ 
/*  927 */             this.complete = false;
/*  928 */             break;
/*      */           }
/*      */         }
/*      */         else {
/*  932 */           headers = createInternetHeaders(in);
/*      */         }
/*      */ 
/*  935 */         if (!in.markSupported()) {
/*  936 */           throw new MessagingException("Stream doesn't support mark");
/*      */         }
/*  938 */         ByteArrayOutputStream buf = null;
/*      */ 
/*  940 */         if (sin == null)
/*  941 */           buf = new ByteArrayOutputStream();
/*      */         else {
/*  943 */           end = sin.getPosition();
/*      */         }
/*      */ 
/*  955 */         byte[] inbuf = new byte[bl];
/*  956 */         byte[] previnbuf = new byte[bl];
/*  957 */         int inSize = 0;
/*  958 */         int prevSize = 0;
/*      */ 
/*  960 */         boolean first = true;
/*      */         int eolLen;
/*      */         while (true)
/*      */         {
/*  966 */           in.mark(bl + 4 + 1000);
/*  967 */           eolLen = 0;
/*  968 */           inSize = readFully(in, inbuf, 0, bl);
/*  969 */           if (inSize < bl)
/*      */           {
/*  971 */             if (!this.ignoreMissingEndBoundary) {
/*  972 */               throw new MessagingException("missing multipart end boundary");
/*      */             }
/*  974 */             if (sin != null)
/*  975 */               end = sin.getPosition();
/*  976 */             this.complete = false;
/*  977 */             done = true;
/*  978 */             break;
/*      */           }
/*      */ 
/*  982 */           for (int i = bl - 1; (i >= 0) && 
/*  983 */             (inbuf[i] == bndbytes[i]); i--);
/*  986 */           if (i < 0) {
/*  987 */             eolLen = 0;
/*  988 */             if (!first)
/*      */             {
/*  991 */               int b = previnbuf[(prevSize - 1)];
/*  992 */               if ((b == 13) || (b == 10)) {
/*  993 */                 eolLen = 1;
/*  994 */                 if ((b == 10) && (prevSize >= 2)) {
/*  995 */                   b = previnbuf[(prevSize - 2)];
/*  996 */                   if (b == 13)
/*  997 */                     eolLen = 2;
/*      */                 }
/*      */               }
/*      */             }
/* 1001 */             if ((first) || (eolLen > 0)) {
/* 1002 */               if (sin != null)
/*      */               {
/* 1005 */                 end = sin.getPosition() - bl - eolLen;
/*      */               }
/*      */ 
/* 1008 */               int b2 = in.read();
/* 1009 */               if ((b2 == 45) && 
/* 1010 */                 (in.read() == 45)) {
/* 1011 */                 this.complete = true;
/* 1012 */                 done = true;
/* 1013 */                 break;
/*      */               }
/*      */ 
/* 1017 */               while ((b2 == 32) || (b2 == 9)) {
/* 1018 */                 b2 = in.read();
/*      */               }
/* 1020 */               if (b2 == 10)
/*      */                 break;
/* 1022 */               if (b2 == 13) {
/* 1023 */                 in.mark(1);
/* 1024 */                 if (in.read() == 10) break;
/* 1025 */                 in.reset(); break;
/*      */               }
/*      */             }
/*      */ 
/* 1029 */             i = 0;
/*      */           }
/*      */ 
/* 1039 */           int skip = Math.max(i + 1 - bcs[(inbuf[i] & 0x7F)], gss[i]);
/*      */ 
/* 1041 */           if (skip < 2)
/*      */           {
/* 1045 */             if ((sin == null) && (prevSize > 1))
/* 1046 */               buf.write(previnbuf, 0, prevSize - 1);
/* 1047 */             in.reset();
/* 1048 */             skipFully(in, 1L);
/* 1049 */             if (prevSize >= 1)
/*      */             {
/* 1051 */               previnbuf[0] = previnbuf[(prevSize - 1)];
/* 1052 */               previnbuf[1] = inbuf[0];
/* 1053 */               prevSize = 2;
/*      */             }
/*      */             else {
/* 1056 */               previnbuf[0] = inbuf[0];
/* 1057 */               prevSize = 1;
/*      */             }
/*      */           }
/*      */           else
/*      */           {
/* 1062 */             if ((prevSize > 0) && (sin == null)) {
/* 1063 */               buf.write(previnbuf, 0, prevSize);
/*      */             }
/* 1065 */             prevSize = skip;
/* 1066 */             in.reset();
/* 1067 */             skipFully(in, prevSize);
/*      */ 
/* 1069 */             byte[] tmp = inbuf;
/* 1070 */             inbuf = previnbuf;
/* 1071 */             previnbuf = tmp;
/*      */           }
/* 1073 */           first = false;
/*      */         }
/*      */         MimeBodyPart part;
/*      */         MimeBodyPart part;
/* 1080 */         if (sin != null) {
/* 1081 */           part = createMimeBodyPart(sin.newStream(start, end));
/*      */         }
/*      */         else {
/* 1084 */           if (prevSize - eolLen > 0) {
/* 1085 */             buf.write(previnbuf, 0, prevSize - eolLen);
/*      */           }
/*      */ 
/* 1088 */           if ((!this.complete) && (inSize > 0))
/* 1089 */             buf.write(inbuf, 0, inSize);
/* 1090 */           part = createMimeBodyPart(headers, buf.toByteArray());
/*      */         }
/* 1092 */         super.addBodyPart(part);
/*      */       }
/*      */     } catch (IOException ioex) {
/* 1095 */       throw new MessagingException("IO Error", ioex);
/*      */     } finally {
/*      */       try {
/* 1098 */         in.close();
/*      */       }
/*      */       catch (IOException cex)
/*      */       {
/*      */       }
/*      */     }
/* 1104 */     this.parsed = true;
/*      */   }
/*      */ 
/*      */   private static int readFully(InputStream in, byte[] buf, int off, int len)
/*      */     throws IOException
/*      */   {
/* 1123 */     if (len == 0)
/* 1124 */       return 0;
/* 1125 */     int total = 0;
/* 1126 */     while (len > 0) {
/* 1127 */       int bsize = in.read(buf, off, len);
/* 1128 */       if (bsize <= 0)
/*      */         break;
/* 1130 */       off += bsize;
/* 1131 */       total += bsize;
/* 1132 */       len -= bsize;
/*      */     }
/* 1134 */     return total > 0 ? total : -1;
/*      */   }
/*      */ 
/*      */   private void skipFully(InputStream in, long offset)
/*      */     throws IOException
/*      */   {
/* 1142 */     while (offset > 0L) {
/* 1143 */       long cur = in.skip(offset);
/* 1144 */       if (cur <= 0L)
/* 1145 */         throw new EOFException("can't skip");
/* 1146 */       offset -= cur;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected InternetHeaders createInternetHeaders(InputStream is)
/*      */     throws MessagingException
/*      */   {
/* 1163 */     return new InternetHeaders(is);
/*      */   }
/*      */ 
/*      */   protected MimeBodyPart createMimeBodyPart(InternetHeaders headers, byte[] content)
/*      */     throws MessagingException
/*      */   {
/* 1180 */     return new MimeBodyPart(headers, content);
/*      */   }
/*      */ 
/*      */   protected MimeBodyPart createMimeBodyPart(InputStream is)
/*      */     throws MessagingException
/*      */   {
/* 1196 */     return new MimeBodyPart(is);
/*      */   }
/*      */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.internet.MimeMultipart
 * JD-Core Version:    0.6.1
 */