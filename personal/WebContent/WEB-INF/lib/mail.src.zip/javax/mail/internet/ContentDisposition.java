/*     */ package javax.mail.internet;
/*     */ 
/*     */ public class ContentDisposition
/*     */ {
/*     */   private String disposition;
/*     */   private ParameterList list;
/*     */ 
/*     */   public ContentDisposition()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ContentDisposition(String disposition, ParameterList list)
/*     */   {
/*  69 */     this.disposition = disposition;
/*  70 */     this.list = list;
/*     */   }
/*     */ 
/*     */   public ContentDisposition(String s)
/*     */     throws ParseException
/*     */   {
/*  83 */     HeaderTokenizer h = new HeaderTokenizer(s, "()<>@,;:\\\"\t []/?=");
/*     */ 
/*  87 */     HeaderTokenizer.Token tk = h.next();
/*  88 */     if (tk.getType() != -1) {
/*  89 */       throw new ParseException("Expected disposition, got " + tk.getValue());
/*     */     }
/*  91 */     this.disposition = tk.getValue();
/*     */ 
/*  94 */     String rem = h.getRemainder();
/*  95 */     if (rem != null)
/*  96 */       this.list = new ParameterList(rem);
/*     */   }
/*     */ 
/*     */   public String getDisposition()
/*     */   {
/* 105 */     return this.disposition;
/*     */   }
/*     */ 
/*     */   public String getParameter(String name)
/*     */   {
/* 115 */     if (this.list == null) {
/* 116 */       return null;
/*     */     }
/* 118 */     return this.list.get(name);
/*     */   }
/*     */ 
/*     */   public ParameterList getParameterList()
/*     */   {
/* 129 */     return this.list;
/*     */   }
/*     */ 
/*     */   public void setDisposition(String disposition)
/*     */   {
/* 138 */     this.disposition = disposition;
/*     */   }
/*     */ 
/*     */   public void setParameter(String name, String value)
/*     */   {
/* 150 */     if (this.list == null) {
/* 151 */       this.list = new ParameterList();
/*     */     }
/* 153 */     this.list.set(name, value);
/*     */   }
/*     */ 
/*     */   public void setParameterList(ParameterList list)
/*     */   {
/* 162 */     this.list = list;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 174 */     if (this.disposition == null) {
/* 175 */       return null;
/*     */     }
/* 177 */     if (this.list == null) {
/* 178 */       return this.disposition;
/*     */     }
/* 180 */     StringBuffer sb = new StringBuffer(this.disposition);
/*     */ 
/* 185 */     sb.append(this.list.toString(sb.length() + 21));
/* 186 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.internet.ContentDisposition
 * JD-Core Version:    0.6.1
 */