/*     */ package javax.mail.internet;
/*     */ 
/*     */ import javax.mail.Session;
/*     */ 
/*     */ class UniqueValue
/*     */ {
/*  58 */   private static int id = 0;
/*     */ 
/*     */   public static String getUniqueBoundaryValue()
/*     */   {
/*  68 */     StringBuffer s = new StringBuffer();
/*     */ 
/*  71 */     s.append("----=_Part_").append(getUniqueId()).append("_").append(s.hashCode()).append('.').append(System.currentTimeMillis());
/*     */ 
/*  74 */     return s.toString();
/*     */   }
/*     */ 
/*     */   public static String getUniqueMessageIDValue(Session ssn)
/*     */   {
/*  93 */     String suffix = null;
/*     */ 
/*  95 */     InternetAddress addr = InternetAddress.getLocalAddress(ssn);
/*  96 */     if (addr != null)
/*  97 */       suffix = addr.getAddress();
/*     */     else {
/*  99 */       suffix = "javamailuser@localhost";
/*     */     }
/*     */ 
/* 102 */     StringBuffer s = new StringBuffer();
/*     */ 
/* 105 */     s.append(s.hashCode()).append('.').append(getUniqueId()).append('.').append(System.currentTimeMillis()).append('.').append("JavaMail.").append(suffix);
/*     */ 
/* 109 */     return s.toString();
/*     */   }
/*     */ 
/*     */   private static synchronized int getUniqueId()
/*     */   {
/* 117 */     return id++;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.internet.UniqueValue
 * JD-Core Version:    0.6.1
 */