/*     */ package javax.mail.internet;
/*     */ 
/*     */ public class HeaderTokenizer
/*     */ {
/*     */   private String string;
/*     */   private boolean skipComments;
/*     */   private String delimiters;
/*     */   private int currentPos;
/*     */   private int maxPos;
/*     */   private int nextPos;
/*     */   private int peekPos;
/*     */   public static final String RFC822 = "()<>@,;:\\\"\t .[]";
/*     */   public static final String MIME = "()<>@,;:\\\"\t []/?=";
/* 148 */   private static final Token EOFToken = new Token(-4, null);
/*     */ 
/*     */   public HeaderTokenizer(String header, String delimiters, boolean skipComments)
/*     */   {
/* 163 */     this.string = (header == null ? "" : header);
/* 164 */     this.skipComments = skipComments;
/* 165 */     this.delimiters = delimiters;
/* 166 */     this.currentPos = (this.nextPos = this.peekPos = 0);
/* 167 */     this.maxPos = this.string.length();
/*     */   }
/*     */ 
/*     */   public HeaderTokenizer(String header, String delimiters)
/*     */   {
/* 177 */     this(header, delimiters, true);
/*     */   }
/*     */ 
/*     */   public HeaderTokenizer(String header)
/*     */   {
/* 186 */     this(header, "()<>@,;:\\\"\t .[]");
/*     */   }
/*     */ 
/*     */   public Token next()
/*     */     throws ParseException
/*     */   {
/* 201 */     this.currentPos = this.nextPos;
/* 202 */     Token tk = getNext('\000');
/* 203 */     this.nextPos = (this.peekPos = this.currentPos);
/* 204 */     return tk;
/*     */   }
/*     */ 
/*     */   Token next(char endOfAtom)
/*     */     throws ParseException
/*     */   {
/* 212 */     this.currentPos = this.nextPos;
/* 213 */     Token tk = getNext(endOfAtom);
/* 214 */     this.nextPos = (this.peekPos = this.currentPos);
/* 215 */     return tk;
/*     */   }
/*     */ 
/*     */   public Token peek()
/*     */     throws ParseException
/*     */   {
/* 230 */     this.currentPos = this.peekPos;
/* 231 */     Token tk = getNext('\000');
/* 232 */     this.peekPos = this.currentPos;
/* 233 */     return tk;
/*     */   }
/*     */ 
/*     */   public String getRemainder()
/*     */   {
/* 243 */     return this.string.substring(this.nextPos);
/*     */   }
/*     */ 
/*     */   private Token getNext(char endOfAtom)
/*     */     throws ParseException
/*     */   {
/* 253 */     if (this.currentPos >= this.maxPos) {
/* 254 */       return EOFToken;
/*     */     }
/*     */ 
/* 257 */     if (skipWhiteSpace() == -4) {
/* 258 */       return EOFToken;
/*     */     }
/*     */ 
/* 262 */     boolean filter = false;
/*     */ 
/* 264 */     char c = this.string.charAt(this.currentPos);
/*     */ 
/* 268 */     while (c == '(')
/*     */     {
/* 271 */       int start = ++this.currentPos; int nesting = 1;
/*     */ 
/* 273 */       for (; (nesting > 0) && (this.currentPos < this.maxPos); 
/* 273 */         this.currentPos += 1) {
/* 274 */         c = this.string.charAt(this.currentPos);
/* 275 */         if (c == '\\') {
/* 276 */           this.currentPos += 1;
/* 277 */           filter = true;
/* 278 */         } else if (c == '\r') {
/* 279 */           filter = true;
/* 280 */         } else if (c == '(') {
/* 281 */           nesting++;
/* 282 */         } else if (c == ')') {
/* 283 */           nesting--;
/*     */         }
/*     */       }
/* 285 */       if (nesting != 0) {
/* 286 */         throw new ParseException("Unbalanced comments");
/*     */       }
/* 288 */       if (!this.skipComments)
/*     */       {
/*     */         String s;
/*     */         String s;
/* 292 */         if (filter)
/* 293 */           s = filterToken(this.string, start, this.currentPos - 1);
/*     */         else {
/* 295 */           s = this.string.substring(start, this.currentPos - 1);
/*     */         }
/* 297 */         return new Token(-3, s);
/*     */       }
/*     */ 
/* 301 */       if (skipWhiteSpace() == -4)
/* 302 */         return EOFToken;
/* 303 */       c = this.string.charAt(this.currentPos);
/*     */     }
/*     */ 
/* 308 */     if (c == '"') {
/* 309 */       this.currentPos += 1;
/* 310 */       return collectString('"');
/*     */     }
/*     */ 
/* 314 */     if ((c < ' ') || (c >= '') || (this.delimiters.indexOf(c) >= 0)) {
/* 315 */       if ((endOfAtom > 0) && (c != endOfAtom))
/*     */       {
/* 318 */         return collectString(endOfAtom);
/*     */       }
/* 320 */       this.currentPos += 1;
/* 321 */       char[] ch = new char[1];
/* 322 */       ch[0] = c;
/* 323 */       return new Token(c, new String(ch));
/*     */     }
/*     */ 
/* 327 */     for (int start = this.currentPos; this.currentPos < this.maxPos; this.currentPos += 1) {
/* 328 */       c = this.string.charAt(this.currentPos);
/*     */ 
/* 331 */       if ((c < ' ') || (c >= '') || (c == '(') || (c == ' ') || (c == '"') || (this.delimiters.indexOf(c) >= 0))
/*     */       {
/* 333 */         if ((endOfAtom <= 0) || (c == endOfAtom)) {
/*     */           break;
/*     */         }
/* 336 */         this.currentPos = start;
/* 337 */         return collectString(endOfAtom);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 342 */     return new Token(-1, this.string.substring(start, this.currentPos));
/*     */   }
/*     */ 
/*     */   private Token collectString(char eos) throws ParseException
/*     */   {
/* 347 */     boolean filter = false;
/* 348 */     for (int start = this.currentPos; this.currentPos < this.maxPos; this.currentPos += 1) {
/* 349 */       char c = this.string.charAt(this.currentPos);
/* 350 */       if (c == '\\') {
/* 351 */         this.currentPos += 1;
/* 352 */         filter = true;
/* 353 */       } else if (c == '\r') {
/* 354 */         filter = true;
/* 355 */       } else if (c == eos) {
/* 356 */         this.currentPos += 1;
/*     */         String s;
/*     */         String s;
/* 359 */         if (filter)
/* 360 */           s = filterToken(this.string, start, this.currentPos - 1);
/*     */         else {
/* 362 */           s = this.string.substring(start, this.currentPos - 1);
/*     */         }
/* 364 */         if (c != '"') {
/* 365 */           s = trimWhiteSpace(s);
/* 366 */           this.currentPos -= 1;
/*     */         }
/*     */ 
/* 369 */         return new Token(-2, s);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 376 */     if (eos == '"')
/* 377 */       throw new ParseException("Unbalanced quoted string");
/*     */     String s;
/* 381 */     if (filter)
/* 382 */       s = filterToken(this.string, start, this.currentPos);
/*     */     else
/* 384 */       s = this.string.substring(start, this.currentPos);
/* 385 */     String s = trimWhiteSpace(s);
/* 386 */     return new Token(-2, s);
/*     */   }
/*     */ 
/*     */   private int skipWhiteSpace()
/*     */   {
/* 392 */     for (; this.currentPos < this.maxPos; this.currentPos += 1)
/*     */     {
/*     */       char c;
/* 393 */       if (((c = this.string.charAt(this.currentPos)) != ' ') && (c != '\t') && (c != '\r') && (c != '\n'))
/*     */       {
/* 395 */         return this.currentPos; } 
/* 396 */     }return -4;
/*     */   }
/*     */ 
/*     */   private static String trimWhiteSpace(String s)
/*     */   {
/*     */     char c;
/* 403 */     for (int i = s.length() - 1; (i >= 0) && (
/* 404 */       ((c = s.charAt(i)) == ' ') || (c == '\t') || (c == '\r') || (c == '\n')); i--);
/* 408 */     if (i <= 0) {
/* 409 */       return "";
/*     */     }
/* 411 */     return s.substring(0, i + 1);
/*     */   }
/*     */ 
/*     */   private static String filterToken(String s, int start, int end)
/*     */   {
/* 418 */     StringBuffer sb = new StringBuffer();
/*     */ 
/* 420 */     boolean gotEscape = false;
/* 421 */     boolean gotCR = false;
/*     */ 
/* 423 */     for (int i = start; i < end; i++) {
/* 424 */       char c = s.charAt(i);
/* 425 */       if ((c == '\n') && (gotCR))
/*     */       {
/* 428 */         gotCR = false;
/*     */       }
/*     */       else
/*     */       {
/* 432 */         gotCR = false;
/* 433 */         if (!gotEscape)
/*     */         {
/* 435 */           if (c == '\\')
/* 436 */             gotEscape = true;
/* 437 */           else if (c == '\r')
/* 438 */             gotCR = true;
/*     */           else {
/* 440 */             sb.append(c);
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 445 */           sb.append(c);
/* 446 */           gotEscape = false;
/*     */         }
/*     */       }
/*     */     }
/* 449 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static class Token
/*     */   {
/*     */     private int type;
/*     */     private String value;
/*     */     public static final int ATOM = -1;
/*     */     public static final int QUOTEDSTRING = -2;
/*     */     public static final int COMMENT = -3;
/*     */     public static final int EOF = -4;
/*     */ 
/*     */     public Token(int type, String value)
/*     */     {
/*  92 */       this.type = type;
/*  93 */       this.value = value;
/*     */     }
/*     */ 
/*     */     public int getType()
/*     */     {
/* 113 */       return this.type;
/*     */     }
/*     */ 
/*     */     public String getValue()
/*     */     {
/* 125 */       return this.value;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.internet.HeaderTokenizer
 * JD-Core Version:    0.6.1
 */