/*      */ package javax.mail.internet;
/*      */ 
/*      */ import com.sun.mail.util.PropUtil;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.net.InetAddress;
/*      */ import java.net.UnknownHostException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.StringTokenizer;
/*      */ import javax.mail.Address;
/*      */ import javax.mail.Session;
/*      */ 
/*      */ public class InternetAddress extends Address
/*      */   implements Cloneable
/*      */ {
/*      */   protected String address;
/*      */   protected String personal;
/*      */   protected String encodedPersonal;
/*      */   private static final long serialVersionUID = -7507595530758302903L;
/*   80 */   private static boolean ignoreBogusGroupName = PropUtil.getBooleanSystemProperty("mail.mime.address.ignorebogusgroupname", true);
/*      */ 
/*  329 */   private static final String rfc822phrase = "()<>@,;:\\\"\t .[]".replace(' ', '\000').replace('\t', '\000');
/*      */   private static final String specialsNoDotNoAt = "()<>,;:\\\"[]";
/*      */   private static final String specialsNoDot = "()<>,;:\\\"[]@";
/*      */ 
/*      */   public InternetAddress()
/*      */   {
/*      */   }
/*      */ 
/*      */   public InternetAddress(String address)
/*      */     throws AddressException
/*      */   {
/*  107 */     InternetAddress[] a = parse(address, true);
/*      */ 
/*  109 */     if (a.length != 1) {
/*  110 */       throw new AddressException("Illegal address", address);
/*      */     }
/*      */ 
/*  118 */     this.address = a[0].address;
/*  119 */     this.personal = a[0].personal;
/*  120 */     this.encodedPersonal = a[0].encodedPersonal;
/*      */   }
/*      */ 
/*      */   public InternetAddress(String address, boolean strict)
/*      */     throws AddressException
/*      */   {
/*  135 */     this(address);
/*  136 */     if (strict)
/*  137 */       if (isGroup())
/*  138 */         getGroup(true);
/*      */       else
/*  140 */         checkAddress(this.address, true, true);
/*      */   }
/*      */ 
/*      */   public InternetAddress(String address, String personal)
/*      */     throws UnsupportedEncodingException
/*      */   {
/*  153 */     this(address, personal, null);
/*      */   }
/*      */ 
/*      */   public InternetAddress(String address, String personal, String charset)
/*      */     throws UnsupportedEncodingException
/*      */   {
/*  166 */     this.address = address;
/*  167 */     setPersonal(personal, charset);
/*      */   }
/*      */ 
/*      */   public Object clone()
/*      */   {
/*  175 */     InternetAddress a = null;
/*      */     try {
/*  177 */       a = (InternetAddress)super.clone(); } catch (CloneNotSupportedException e) {
/*      */     }
/*  179 */     return a;
/*      */   }
/*      */ 
/*      */   public String getType()
/*      */   {
/*  187 */     return "rfc822";
/*      */   }
/*      */ 
/*      */   public void setAddress(String address)
/*      */   {
/*  196 */     this.address = address;
/*      */   }
/*      */ 
/*      */   public void setPersonal(String name, String charset)
/*      */     throws UnsupportedEncodingException
/*      */   {
/*  214 */     this.personal = name;
/*  215 */     if (name != null)
/*  216 */       this.encodedPersonal = MimeUtility.encodeWord(name, charset, null);
/*      */     else
/*  218 */       this.encodedPersonal = null;
/*      */   }
/*      */ 
/*      */   public void setPersonal(String name)
/*      */     throws UnsupportedEncodingException
/*      */   {
/*  234 */     this.personal = name;
/*  235 */     if (name != null)
/*  236 */       this.encodedPersonal = MimeUtility.encodeWord(name);
/*      */     else
/*  238 */       this.encodedPersonal = null;
/*      */   }
/*      */ 
/*      */   public String getAddress()
/*      */   {
/*  246 */     return this.address;
/*      */   }
/*      */ 
/*      */   public String getPersonal()
/*      */   {
/*  257 */     if (this.personal != null) {
/*  258 */       return this.personal;
/*      */     }
/*  260 */     if (this.encodedPersonal != null) {
/*      */       try {
/*  262 */         this.personal = MimeUtility.decodeText(this.encodedPersonal);
/*  263 */         return this.personal;
/*      */       }
/*      */       catch (Exception ex)
/*      */       {
/*  268 */         return this.encodedPersonal;
/*      */       }
/*      */     }
/*      */ 
/*  272 */     return null;
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/*  283 */     if ((this.encodedPersonal == null) && (this.personal != null))
/*      */       try {
/*  285 */         this.encodedPersonal = MimeUtility.encodeWord(this.personal);
/*      */       } catch (UnsupportedEncodingException ex) {
/*      */       }
/*  288 */     if (this.encodedPersonal != null)
/*  289 */       return quotePhrase(this.encodedPersonal) + " <" + this.address + ">";
/*  290 */     if ((isGroup()) || (isSimple())) {
/*  291 */       return this.address;
/*      */     }
/*  293 */     return "<" + this.address + ">";
/*      */   }
/*      */ 
/*      */   public String toUnicodeString()
/*      */   {
/*  304 */     String p = getPersonal();
/*  305 */     if (p != null)
/*  306 */       return quotePhrase(p) + " <" + this.address + ">";
/*  307 */     if ((isGroup()) || (isSimple())) {
/*  308 */       return this.address;
/*      */     }
/*  310 */     return "<" + this.address + ">";
/*      */   }
/*      */ 
/*      */   private static String quotePhrase(String phrase)
/*      */   {
/*  333 */     int len = phrase.length();
/*  334 */     boolean needQuoting = false;
/*      */ 
/*  336 */     for (int i = 0; i < len; i++) {
/*  337 */       char c = phrase.charAt(i);
/*  338 */       if ((c == '"') || (c == '\\'))
/*      */       {
/*  340 */         StringBuffer sb = new StringBuffer(len + 3);
/*  341 */         sb.append('"');
/*  342 */         for (int j = 0; j < len; j++) {
/*  343 */           char cc = phrase.charAt(j);
/*  344 */           if ((cc == '"') || (cc == '\\'))
/*      */           {
/*  346 */             sb.append('\\');
/*  347 */           }sb.append(cc);
/*      */         }
/*  349 */         sb.append('"');
/*  350 */         return sb.toString();
/*  351 */       }if (((c < ' ') && (c != '\r') && (c != '\n') && (c != '\t')) || (c >= '') || (rfc822phrase.indexOf(c) >= 0))
/*      */       {
/*  354 */         needQuoting = true;
/*      */       }
/*      */     }
/*  357 */     if (needQuoting) {
/*  358 */       StringBuffer sb = new StringBuffer(len + 2);
/*  359 */       sb.append('"').append(phrase).append('"');
/*  360 */       return sb.toString();
/*      */     }
/*  362 */     return phrase;
/*      */   }
/*      */ 
/*      */   private static String unquote(String s) {
/*  366 */     if ((s.startsWith("\"")) && (s.endsWith("\""))) {
/*  367 */       s = s.substring(1, s.length() - 1);
/*      */ 
/*  369 */       if (s.indexOf('\\') >= 0) {
/*  370 */         StringBuffer sb = new StringBuffer(s.length());
/*  371 */         for (int i = 0; i < s.length(); i++) {
/*  372 */           char c = s.charAt(i);
/*  373 */           if ((c == '\\') && (i < s.length() - 1))
/*  374 */             c = s.charAt(++i);
/*  375 */           sb.append(c);
/*      */         }
/*  377 */         s = sb.toString();
/*      */       }
/*      */     }
/*  380 */     return s;
/*      */   }
/*      */ 
/*      */   public boolean equals(Object a)
/*      */   {
/*  387 */     if (!(a instanceof InternetAddress)) {
/*  388 */       return false;
/*      */     }
/*  390 */     String s = ((InternetAddress)a).getAddress();
/*  391 */     if (s == this.address)
/*  392 */       return true;
/*  393 */     if ((this.address != null) && (this.address.equalsIgnoreCase(s))) {
/*  394 */       return true;
/*      */     }
/*  396 */     return false;
/*      */   }
/*      */ 
/*      */   public int hashCode()
/*      */   {
/*  403 */     if (this.address == null) {
/*  404 */       return 0;
/*      */     }
/*  406 */     return this.address.toLowerCase(Locale.ENGLISH).hashCode();
/*      */   }
/*      */ 
/*      */   public static String toString(Address[] addresses)
/*      */   {
/*  422 */     return toString(addresses, 0);
/*      */   }
/*      */ 
/*      */   public static String toString(Address[] addresses, int used)
/*      */   {
/*  446 */     if ((addresses == null) || (addresses.length == 0)) {
/*  447 */       return null;
/*      */     }
/*  449 */     StringBuffer sb = new StringBuffer();
/*      */ 
/*  451 */     for (int i = 0; i < addresses.length; i++) {
/*  452 */       if (i != 0) {
/*  453 */         sb.append(", ");
/*  454 */         used += 2;
/*      */       }
/*      */ 
/*  457 */       String s = addresses[i].toString();
/*  458 */       int len = lengthOfFirstSegment(s);
/*  459 */       if (used + len > 76) {
/*  460 */         sb.append("\r\n\t");
/*  461 */         used = 8;
/*      */       }
/*  463 */       sb.append(s);
/*  464 */       used = lengthOfLastSegment(s, used);
/*      */     }
/*      */ 
/*  467 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   private static int lengthOfFirstSegment(String s)
/*      */   {
/*      */     int pos;
/*  475 */     if ((pos = s.indexOf("\r\n")) != -1) {
/*  476 */       return pos;
/*      */     }
/*  478 */     return s.length();
/*      */   }
/*      */ 
/*      */   private static int lengthOfLastSegment(String s, int used)
/*      */   {
/*      */     int pos;
/*  488 */     if ((pos = s.lastIndexOf("\r\n")) != -1) {
/*  489 */       return s.length() - pos - 2;
/*      */     }
/*  491 */     return s.length() + used;
/*      */   }
/*      */ 
/*      */   public static InternetAddress getLocalAddress(Session session)
/*      */   {
/*  508 */     String user = null; String host = null; String address = null;
/*      */     try {
/*  510 */       if (session == null) {
/*  511 */         user = System.getProperty("user.name");
/*  512 */         host = InetAddress.getLocalHost().getHostName();
/*      */       } else {
/*  514 */         address = session.getProperty("mail.from");
/*  515 */         if (address == null) {
/*  516 */           user = session.getProperty("mail.user");
/*  517 */           if ((user == null) || (user.length() == 0))
/*  518 */             user = session.getProperty("user.name");
/*  519 */           if ((user == null) || (user.length() == 0))
/*  520 */             user = System.getProperty("user.name");
/*  521 */           host = session.getProperty("mail.host");
/*  522 */           if ((host == null) || (host.length() == 0)) {
/*  523 */             InetAddress me = InetAddress.getLocalHost();
/*  524 */             if (me != null) {
/*  525 */               host = me.getHostName();
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*  530 */       if ((address == null) && (user != null) && (user.length() != 0) && (host != null) && (host.length() != 0))
/*      */       {
/*  532 */         address = user + "@" + host;
/*      */       }
/*  534 */       if (address != null)
/*  535 */         return new InternetAddress(address); 
/*      */     } catch (SecurityException sex) {
/*      */     } catch (AddressException ex) {
/*      */     } catch (UnknownHostException ex) {  }
/*      */ 
/*  539 */     return null;
/*      */   }
/*      */ 
/*      */   public static InternetAddress[] parse(String addresslist)
/*      */     throws AddressException
/*      */   {
/*  552 */     return parse(addresslist, true);
/*      */   }
/*      */ 
/*      */   public static InternetAddress[] parse(String addresslist, boolean strict)
/*      */     throws AddressException
/*      */   {
/*  575 */     return parse(addresslist, strict, false);
/*      */   }
/*      */ 
/*      */   public static InternetAddress[] parseHeader(String addresslist, boolean strict)
/*      */     throws AddressException
/*      */   {
/*  600 */     return parse(addresslist, strict, true);
/*      */   }
/*      */ 
/*      */   private static InternetAddress[] parse(String s, boolean strict, boolean parseHdr)
/*      */     throws AddressException
/*      */   {
/*  614 */     int start_personal = -1; int end_personal = -1;
/*  615 */     int length = s.length();
/*  616 */     boolean ignoreErrors = (parseHdr) && (!strict);
/*  617 */     boolean in_group = false;
/*  618 */     boolean route_addr = false;
/*  619 */     boolean rfc822 = false;
/*      */ 
/*  621 */     List v = new ArrayList();
/*      */     int end;
/*  624 */     int start = end = -1; for (int index = 0; index < length; index++) {
/*  625 */       char c = s.charAt(index);
/*      */ 
/*  627 */       switch (c)
/*      */       {
/*      */       case '(':
/*  631 */         rfc822 = true;
/*  632 */         if ((start >= 0) && (end == -1))
/*  633 */           end = index;
/*  634 */         int pindex = index;
/*  635 */         index++; for (int nesting = 1; (index < length) && (nesting > 0); 
/*  636 */           index++) {
/*  637 */           c = s.charAt(index);
/*  638 */           switch (c) {
/*      */           case '\\':
/*  640 */             index++;
/*  641 */             break;
/*      */           case '(':
/*  643 */             nesting++;
/*  644 */             break;
/*      */           case ')':
/*  646 */             nesting--;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  652 */         if (nesting > 0) {
/*  653 */           if (!ignoreErrors) {
/*  654 */             throw new AddressException("Missing ')'", s, index);
/*      */           }
/*      */ 
/*  657 */           index = pindex + 1;
/*      */         }
/*      */         else {
/*  660 */           index--;
/*  661 */           if (start_personal == -1)
/*  662 */             start_personal = pindex + 1;
/*  663 */           if (end_personal == -1)
/*  664 */             end_personal = index;  } break;
/*      */       case ')':
/*  668 */         if (!ignoreErrors) {
/*  669 */           throw new AddressException("Missing '('", s, index);
/*      */         }
/*      */ 
/*  672 */         if (start != -1) continue;
/*  673 */         start = index; break;
/*      */       case '<':
/*  677 */         rfc822 = true;
/*  678 */         if (route_addr) {
/*  679 */           if (!ignoreErrors) {
/*  680 */             throw new AddressException("Extra route-addr", s, index);
/*      */           }
/*      */ 
/*  684 */           if (start == -1) {
/*  685 */             route_addr = false;
/*  686 */             rfc822 = false;
/*  687 */             start = end = -1;
/*  688 */             continue;
/*      */           }
/*  690 */           if (!in_group)
/*      */           {
/*  692 */             if (end == -1)
/*  693 */               end = index;
/*  694 */             String addr = s.substring(start, end).trim();
/*      */ 
/*  696 */             InternetAddress ma = new InternetAddress();
/*  697 */             ma.setAddress(addr);
/*  698 */             if (start_personal >= 0) {
/*  699 */               ma.encodedPersonal = unquote(s.substring(start_personal, end_personal).trim());
/*      */             }
/*      */ 
/*  703 */             v.add(ma);
/*      */ 
/*  705 */             route_addr = false;
/*  706 */             rfc822 = false;
/*  707 */             start = end = -1;
/*  708 */             start_personal = end_personal = -1;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  713 */         int rindex = index;
/*  714 */         boolean inquote = false;
/*      */ 
/*  716 */         for (index++; index < length; index++) {
/*  717 */           c = s.charAt(index);
/*  718 */           switch (c) {
/*      */           case '\\':
/*  720 */             index++;
/*  721 */             break;
/*      */           case '"':
/*  723 */             inquote = !inquote;
/*  724 */             break;
/*      */           case '>':
/*  726 */             if (!inquote)
/*      */             {
/*      */               break label615;
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  735 */         if (inquote) {
/*  736 */           if (!ignoreErrors) {
/*  737 */             throw new AddressException("Missing '\"'", s, index);
/*      */           }
/*      */ 
/*  741 */           for (index = rindex + 1; index < length; index++) {
/*  742 */             c = s.charAt(index);
/*  743 */             if (c == '\\')
/*  744 */               index++;
/*  745 */             else if (c == '>')
/*      */               {
/*      */                 break;
/*      */               }
/*      */           }
/*      */         }
/*  751 */         if (index >= length) {
/*  752 */           if (!ignoreErrors) {
/*  753 */             throw new AddressException("Missing '>'", s, index);
/*      */           }
/*      */ 
/*  756 */           index = rindex + 1;
/*  757 */           if (start == -1)
/*  758 */             start = rindex;
/*      */         }
/*      */         else
/*      */         {
/*  762 */           if (!in_group) {
/*  763 */             start_personal = start;
/*  764 */             if (start_personal >= 0)
/*  765 */               end_personal = rindex;
/*  766 */             start = rindex + 1;
/*      */           }
/*  768 */           route_addr = true;
/*  769 */           end = index;
/*  770 */         }break;
/*      */       case '>':
/*  773 */         if (!ignoreErrors) {
/*  774 */           throw new AddressException("Missing '<'", s, index);
/*      */         }
/*      */ 
/*  777 */         if (start != -1) continue;
/*  778 */         start = index; break;
/*      */       case '"':
/*  782 */         int qindex = index;
/*  783 */         rfc822 = true;
/*  784 */         if (start == -1) {
/*  785 */           start = index;
/*      */         }
/*  787 */         for (index++; index < length; index++) {
/*  788 */           c = s.charAt(index);
/*  789 */           switch (c) {
/*      */           case '\\':
/*  791 */             index++;
/*  792 */             break;
/*      */           case '"':
/*  794 */             break label867;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  799 */         if (index < length) continue;
/*  800 */         if (!ignoreErrors) {
/*  801 */           throw new AddressException("Missing '\"'", s, index);
/*      */         }
/*      */ 
/*  804 */         index = qindex + 1; break;
/*      */       case '[':
/*  809 */         rfc822 = true;
/*  810 */         int lindex = index;
/*      */ 
/*  812 */         for (index++; index < length; index++) {
/*  813 */           c = s.charAt(index);
/*  814 */           switch (c) {
/*      */           case '\\':
/*  816 */             index++;
/*  817 */             break;
/*      */           case ']':
/*  819 */             break label971;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  824 */         if (index < length) continue;
/*  825 */         if (!ignoreErrors) {
/*  826 */           throw new AddressException("Missing ']'", s, index);
/*      */         }
/*      */ 
/*  829 */         index = lindex + 1; break;
/*      */       case ';':
/*  834 */         if (start == -1) {
/*  835 */           route_addr = false;
/*  836 */           rfc822 = false;
/*  837 */           start = end = -1;
/*  838 */           continue;
/*      */         }
/*  840 */         if (in_group) {
/*  841 */           in_group = false;
/*      */ 
/*  848 */           if ((parseHdr) && (!strict) && (index + 1 < length) && (s.charAt(index + 1) == '@')) {
/*      */             continue;
/*      */           }
/*  851 */           InternetAddress ma = new InternetAddress();
/*  852 */           end = index + 1;
/*  853 */           ma.setAddress(s.substring(start, end).trim());
/*  854 */           v.add(ma);
/*      */ 
/*  856 */           route_addr = false;
/*  857 */           rfc822 = false;
/*  858 */           start = end = -1;
/*  859 */           start_personal = end_personal = -1;
/*  860 */           continue;
/*      */         }
/*  862 */         if (!ignoreErrors) {
/*  863 */           throw new AddressException("Illegal semicolon, not in group", s, index);
/*      */         }
/*      */ 
/*      */       case ',':
/*  870 */         if (start == -1) {
/*  871 */           route_addr = false;
/*  872 */           rfc822 = false;
/*  873 */           start = end = -1;
/*      */         }
/*  876 */         else if (in_group) {
/*  877 */           route_addr = false;
/*      */         }
/*      */         else
/*      */         {
/*  881 */           if (end == -1) {
/*  882 */             end = index;
/*      */           }
/*  884 */           String addr = s.substring(start, end).trim();
/*  885 */           String pers = null;
/*  886 */           if ((rfc822) && (start_personal >= 0)) {
/*  887 */             pers = unquote(s.substring(start_personal, end_personal).trim());
/*      */ 
/*  889 */             if (pers.trim().length() == 0) {
/*  890 */               pers = null;
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*  898 */           if ((parseHdr) && (!strict) && (pers != null) && (pers.indexOf('@') >= 0) && (addr.indexOf('@') < 0) && (addr.indexOf('!') < 0))
/*      */           {
/*  901 */             String tmp = addr;
/*  902 */             addr = pers;
/*  903 */             pers = tmp;
/*      */           }
/*  905 */           if ((rfc822) || (strict) || (parseHdr)) {
/*  906 */             if (!ignoreErrors)
/*  907 */               checkAddress(addr, route_addr, false);
/*  908 */             InternetAddress ma = new InternetAddress();
/*  909 */             ma.setAddress(addr);
/*  910 */             if (pers != null)
/*  911 */               ma.encodedPersonal = pers;
/*  912 */             v.add(ma);
/*      */           }
/*      */           else {
/*  915 */             StringTokenizer st = new StringTokenizer(addr);
/*  916 */             while (st.hasMoreTokens()) {
/*  917 */               String a = st.nextToken();
/*  918 */               checkAddress(a, false, false);
/*  919 */               InternetAddress ma = new InternetAddress();
/*  920 */               ma.setAddress(a);
/*  921 */               v.add(ma);
/*      */             }
/*      */           }
/*      */ 
/*  925 */           route_addr = false;
/*  926 */           rfc822 = false;
/*  927 */           start = end = -1;
/*  928 */           start_personal = end_personal = -1;
/*  929 */         }break;
/*      */       case ':':
/*  932 */         label867: rfc822 = true;
/*  933 */         label971: if ((in_group) && 
/*  934 */           (!ignoreErrors))
/*  935 */           throw new AddressException("Nested group", s, index);
/*  936 */         if (start == -1)
/*  937 */           start = index;
/*  938 */         if ((parseHdr) && (!strict))
/*      */         {
/*  944 */           if (index + 1 < length) {
/*  945 */             String addressSpecials = ")>[]:@\\,.";
/*  946 */             char nc = s.charAt(index + 1);
/*  947 */             if (addressSpecials.indexOf(nc) >= 0) {
/*  948 */               if (nc != '@')
/*      */               {
/*      */                 continue;
/*      */               }
/*      */ 
/*  958 */               for (int i = index + 2; i < length; i++) {
/*  959 */                 nc = s.charAt(i);
/*  960 */                 if (nc == ';')
/*      */                   break;
/*  962 */                 if (addressSpecials.indexOf(nc) >= 0)
/*      */                   break;
/*      */               }
/*  965 */               if (nc == ';')
/*      */               {
/*      */                 continue;
/*      */               }
/*      */             }
/*      */           }
/*      */ 
/*  972 */           String gname = s.substring(start, index);
/*  973 */           if ((ignoreBogusGroupName) && ((gname.equalsIgnoreCase("mailto")) || (gname.equalsIgnoreCase("From")) || (gname.equalsIgnoreCase("To")) || (gname.equalsIgnoreCase("Cc")) || (gname.equalsIgnoreCase("Subject")) || (gname.equalsIgnoreCase("Re"))))
/*      */           {
/*  980 */             start = -1;
/*      */           }
/*  982 */           else in_group = true; 
/*      */         }
/*  984 */         else { in_group = true; }
/*  985 */         break;
/*      */       case '\t':
/*      */       case '\n':
/*      */       case '\r':
/*      */       case ' ':
/*  992 */         label615: break;
/*      */       }
/*      */ 
/*  995 */       if (start == -1) {
/*  996 */         start = index;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1001 */     if (start >= 0)
/*      */     {
/* 1007 */       if (end == -1) {
/* 1008 */         end = length;
/*      */       }
/* 1010 */       String addr = s.substring(start, end).trim();
/* 1011 */       String pers = null;
/* 1012 */       if ((rfc822) && (start_personal >= 0)) {
/* 1013 */         pers = unquote(s.substring(start_personal, end_personal).trim());
/*      */ 
/* 1015 */         if (pers.trim().length() == 0) {
/* 1016 */           pers = null;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1024 */       if ((parseHdr) && (!strict) && (pers != null) && (pers.indexOf('@') >= 0) && (addr.indexOf('@') < 0) && (addr.indexOf('!') < 0))
/*      */       {
/* 1027 */         String tmp = addr;
/* 1028 */         addr = pers;
/* 1029 */         pers = tmp;
/*      */       }
/* 1031 */       if ((rfc822) || (strict) || (parseHdr)) {
/* 1032 */         if (!ignoreErrors)
/* 1033 */           checkAddress(addr, route_addr, false);
/* 1034 */         InternetAddress ma = new InternetAddress();
/* 1035 */         ma.setAddress(addr);
/* 1036 */         if (pers != null)
/* 1037 */           ma.encodedPersonal = pers;
/* 1038 */         v.add(ma);
/*      */       }
/*      */       else {
/* 1041 */         StringTokenizer st = new StringTokenizer(addr);
/* 1042 */         while (st.hasMoreTokens()) {
/* 1043 */           String a = st.nextToken();
/* 1044 */           checkAddress(a, false, false);
/* 1045 */           InternetAddress ma = new InternetAddress();
/* 1046 */           ma.setAddress(a);
/* 1047 */           v.add(ma);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1052 */     InternetAddress[] a = new InternetAddress[v.size()];
/* 1053 */     v.toArray(a);
/* 1054 */     return a;
/*      */   }
/*      */ 
/*      */   public void validate()
/*      */     throws AddressException
/*      */   {
/* 1068 */     if (isGroup())
/* 1069 */       getGroup(true);
/*      */     else
/* 1071 */       checkAddress(getAddress(), true, true);
/*      */   }
/*      */ 
/*      */   private static void checkAddress(String addr, boolean routeAddr, boolean validate)
/*      */     throws AddressException
/*      */   {
/* 1087 */     int start = 0;
/*      */ 
/* 1089 */     int len = addr.length();
/* 1090 */     if (len == 0) {
/* 1091 */       throw new AddressException("Empty address", addr);
/*      */     }
/*      */ 
/* 1097 */     if ((routeAddr) && (addr.charAt(0) == '@'))
/*      */     {
/*      */       int i;
/* 1102 */       for (start = 0; (i = indexOfAny(addr, ",:", start)) >= 0; 
/* 1103 */         start = i + 1) {
/* 1104 */         if (addr.charAt(start) != '@')
/* 1105 */           throw new AddressException("Illegal route-addr", addr);
/* 1106 */         if (addr.charAt(i) == ':')
/*      */         {
/* 1108 */           start = i + 1;
/* 1109 */           break;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1122 */     char c = 65535;
/* 1123 */     char lastc = 65535;
/* 1124 */     boolean inquote = false;
/* 1125 */     for (int i = start; i < len; i++) {
/* 1126 */       lastc = c;
/* 1127 */       c = addr.charAt(i);
/*      */ 
/* 1130 */       if ((c != '\\') && (lastc != '\\'))
/*      */       {
/* 1132 */         if (c == '"') {
/* 1133 */           if (inquote)
/*      */           {
/* 1135 */             if ((validate) && (i + 1 < len) && (addr.charAt(i + 1) != '@')) {
/* 1136 */               throw new AddressException("Quote not at end of local address", addr);
/*      */             }
/* 1138 */             inquote = false;
/*      */           } else {
/* 1140 */             if ((validate) && (i != 0)) {
/* 1141 */               throw new AddressException("Quote not at start of local address", addr);
/*      */             }
/* 1143 */             inquote = true;
/*      */           }
/*      */ 
/*      */         }
/* 1147 */         else if (!inquote)
/*      */         {
/* 1149 */           if (c == '@') {
/* 1150 */             if (i != 0) break;
/* 1151 */             throw new AddressException("Missing local name", addr);
/*      */           }
/*      */ 
/* 1154 */           if ((c <= ' ') || (c >= '')) {
/* 1155 */             throw new AddressException("Local address contains control or whitespace", addr);
/*      */           }
/* 1157 */           if ("()<>,;:\\\"[]@".indexOf(c) >= 0)
/* 1158 */             throw new AddressException("Local address contains illegal character", addr); 
/*      */         }
/*      */       }
/*      */     }
/* 1161 */     if (inquote) {
/* 1162 */       throw new AddressException("Unterminated quote", addr);
/*      */     }
/*      */ 
/* 1176 */     if (c != '@') {
/* 1177 */       if (validate)
/* 1178 */         throw new AddressException("Missing final '@domain'", addr);
/* 1179 */       return;
/*      */     }
/*      */ 
/* 1184 */     start = i + 1;
/* 1185 */     if (start >= len) {
/* 1186 */       throw new AddressException("Missing domain", addr);
/*      */     }
/* 1188 */     if (addr.charAt(start) == '.')
/* 1189 */       throw new AddressException("Domain starts with dot", addr);
/* 1190 */     for (i = start; i < len; i++) {
/* 1191 */       c = addr.charAt(i);
/* 1192 */       if (c == '[')
/* 1193 */         return;
/* 1194 */       if ((c <= ' ') || (c >= '')) {
/* 1195 */         throw new AddressException("Domain contains control or whitespace", addr);
/*      */       }
/* 1197 */       if ("()<>,;:\\\"[]@".indexOf(c) >= 0) {
/* 1198 */         throw new AddressException("Domain contains illegal character", addr);
/*      */       }
/* 1200 */       if ((c == '.') && (lastc == '.')) {
/* 1201 */         throw new AddressException("Domain contains dot-dot", addr);
/*      */       }
/* 1203 */       lastc = c;
/*      */     }
/* 1205 */     if (lastc == '.')
/* 1206 */       throw new AddressException("Domain ends with dot", addr);
/*      */   }
/*      */ 
/*      */   private boolean isSimple()
/*      */   {
/* 1214 */     return (this.address == null) || (indexOfAny(this.address, "()<>,;:\\\"[]") < 0);
/*      */   }
/*      */ 
/*      */   public boolean isGroup()
/*      */   {
/* 1228 */     return (this.address != null) && (this.address.endsWith(";")) && (this.address.indexOf(':') > 0);
/*      */   }
/*      */ 
/*      */   public InternetAddress[] getGroup(boolean strict)
/*      */     throws AddressException
/*      */   {
/* 1244 */     String addr = getAddress();
/*      */ 
/* 1246 */     if (!addr.endsWith(";"))
/* 1247 */       return null;
/* 1248 */     int ix = addr.indexOf(':');
/* 1249 */     if (ix < 0) {
/* 1250 */       return null;
/*      */     }
/* 1252 */     String list = addr.substring(ix + 1, addr.length() - 1);
/*      */ 
/* 1254 */     return parseHeader(list, strict);
/*      */   }
/*      */ 
/*      */   private static int indexOfAny(String s, String any)
/*      */   {
/* 1264 */     return indexOfAny(s, any, 0);
/*      */   }
/*      */ 
/*      */   private static int indexOfAny(String s, String any, int start) {
/*      */     try {
/* 1269 */       int len = s.length();
/* 1270 */       for (int i = start; i < len; i++) {
/* 1271 */         if (any.indexOf(s.charAt(i)) >= 0)
/* 1272 */           return i;
/*      */       }
/* 1274 */       return -1; } catch (StringIndexOutOfBoundsException e) {
/*      */     }
/* 1276 */     return -1;
/*      */   }
/*      */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.internet.InternetAddress
 * JD-Core Version:    0.6.1
 */