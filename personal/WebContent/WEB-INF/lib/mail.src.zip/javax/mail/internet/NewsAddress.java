/*     */ package javax.mail.internet;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ import javax.mail.Address;
/*     */ 
/*     */ public class NewsAddress extends Address
/*     */ {
/*     */   protected String newsgroup;
/*     */   protected String host;
/*     */   private static final long serialVersionUID = -4203797299824684143L;
/*     */ 
/*     */   public NewsAddress()
/*     */   {
/*     */   }
/*     */ 
/*     */   public NewsAddress(String newsgroup)
/*     */   {
/*  69 */     this(newsgroup, null);
/*     */   }
/*     */ 
/*     */   public NewsAddress(String newsgroup, String host)
/*     */   {
/*  79 */     this.newsgroup = newsgroup;
/*  80 */     this.host = host;
/*     */   }
/*     */ 
/*     */   public String getType()
/*     */   {
/*  88 */     return "news";
/*     */   }
/*     */ 
/*     */   public void setNewsgroup(String newsgroup)
/*     */   {
/*  97 */     this.newsgroup = newsgroup;
/*     */   }
/*     */ 
/*     */   public String getNewsgroup()
/*     */   {
/* 106 */     return this.newsgroup;
/*     */   }
/*     */ 
/*     */   public void setHost(String host)
/*     */   {
/* 115 */     this.host = host;
/*     */   }
/*     */ 
/*     */   public String getHost()
/*     */   {
/* 124 */     return this.host;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 133 */     return this.newsgroup;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object a)
/*     */   {
/* 140 */     if (!(a instanceof NewsAddress)) {
/* 141 */       return false;
/*     */     }
/* 143 */     NewsAddress s = (NewsAddress)a;
/* 144 */     return (this.newsgroup.equals(s.newsgroup)) && (((this.host == null) && (s.host == null)) || ((this.host != null) && (s.host != null) && (this.host.equalsIgnoreCase(s.host))));
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 153 */     int hash = 0;
/* 154 */     if (this.newsgroup != null)
/* 155 */       hash += this.newsgroup.hashCode();
/* 156 */     if (this.host != null)
/* 157 */       hash += this.host.toLowerCase(Locale.ENGLISH).hashCode();
/* 158 */     return hash;
/*     */   }
/*     */ 
/*     */   public static String toString(Address[] addresses)
/*     */   {
/* 174 */     if ((addresses == null) || (addresses.length == 0)) {
/* 175 */       return null;
/*     */     }
/* 177 */     StringBuffer s = new StringBuffer(((NewsAddress)addresses[0]).toString());
/*     */ 
/* 179 */     for (int i = 1; i < addresses.length; i++) {
/* 180 */       s.append(",").append(((NewsAddress)addresses[i]).toString());
/*     */     }
/* 182 */     return s.toString();
/*     */   }
/*     */ 
/*     */   public static NewsAddress[] parse(String newsgroups)
/*     */     throws AddressException
/*     */   {
/* 196 */     StringTokenizer st = new StringTokenizer(newsgroups, ",");
/* 197 */     Vector nglist = new Vector();
/* 198 */     while (st.hasMoreTokens()) {
/* 199 */       String ng = st.nextToken();
/* 200 */       nglist.addElement(new NewsAddress(ng));
/*     */     }
/* 202 */     int size = nglist.size();
/* 203 */     NewsAddress[] na = new NewsAddress[size];
/* 204 */     if (size > 0)
/* 205 */       nglist.copyInto(na);
/* 206 */     return na;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.internet.NewsAddress
 * JD-Core Version:    0.6.1
 */