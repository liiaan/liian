/*     */ package javax.mail.internet;
/*     */ 
/*     */ import com.sun.mail.util.PropUtil;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class ParameterList
/*     */ {
/*  85 */   private Map list = new LinkedHashMap();
/*     */   private Set multisegmentNames;
/*     */   private Map slist;
/* 132 */   private String lastName = null;
/*     */ 
/* 134 */   private static boolean encodeParameters = PropUtil.getBooleanSystemProperty("mail.mime.encodeparameters", false);
/*     */ 
/* 136 */   private static boolean decodeParameters = PropUtil.getBooleanSystemProperty("mail.mime.decodeparameters", false);
/*     */ 
/* 138 */   private static boolean decodeParametersStrict = PropUtil.getBooleanSystemProperty("mail.mime.decodeparameters.strict", false);
/*     */ 
/* 141 */   private static boolean applehack = PropUtil.getBooleanSystemProperty("mail.mime.applefilenames", false);
/*     */ 
/* 143 */   private static boolean parametersStrict = PropUtil.getBooleanSystemProperty("mail.mime.parameters.strict", true);
/*     */ 
/* 652 */   private static final char[] hex = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*     */ 
/*     */   public ParameterList()
/*     */   {
/* 198 */     if (decodeParameters) {
/* 199 */       this.multisegmentNames = new HashSet();
/* 200 */       this.slist = new HashMap();
/*     */     }
/*     */   }
/*     */ 
/*     */   public ParameterList(String s)
/*     */     throws ParseException
/*     */   {
/* 215 */     this();
/*     */ 
/* 217 */     HeaderTokenizer h = new HeaderTokenizer(s, "()<>@,;:\\\"\t []/?=");
/*     */     while (true) {
/* 219 */       HeaderTokenizer.Token tk = h.next();
/* 220 */       int type = tk.getType();
/*     */ 
/* 223 */       if (type == -4) {
/*     */         break;
/*     */       }
/* 226 */       if ((char)type == ';')
/*     */       {
/* 228 */         tk = h.next();
/*     */ 
/* 230 */         if (tk.getType() == -4) {
/*     */           break;
/*     */         }
/* 233 */         if (tk.getType() != -1) {
/* 234 */           throw new ParseException("Expected parameter name, got \"" + tk.getValue() + "\"");
/*     */         }
/* 236 */         String name = tk.getValue().toLowerCase(Locale.ENGLISH);
/*     */ 
/* 239 */         tk = h.next();
/* 240 */         if ((char)tk.getType() != '=') {
/* 241 */           throw new ParseException("Expected '=', got \"" + tk.getValue() + "\"");
/*     */         }
/*     */ 
/* 245 */         if (parametersStrict)
/* 246 */           tk = h.next();
/*     */         else
/* 248 */           tk = h.next(';');
/* 249 */         type = tk.getType();
/*     */ 
/* 251 */         if ((type != -1) && (type != -2))
/*     */         {
/* 253 */           throw new ParseException("Expected parameter value, got \"" + tk.getValue() + "\"");
/*     */         }
/*     */ 
/* 256 */         String value = tk.getValue();
/* 257 */         this.lastName = name;
/* 258 */         if (decodeParameters)
/* 259 */           putEncodedName(name, value);
/*     */         else {
/* 261 */           this.list.put(name, value);
/*     */         }
/*     */ 
/*     */       }
/* 269 */       else if ((type == -1) && (this.lastName != null) && (((applehack) && ((this.lastName.equals("name")) || (this.lastName.equals("filename")))) || (!parametersStrict)))
/*     */       {
/* 276 */         String lastValue = (String)this.list.get(this.lastName);
/* 277 */         String value = lastValue + " " + tk.getValue();
/* 278 */         this.list.put(this.lastName, value);
/*     */       } else {
/* 280 */         throw new ParseException("Expected ';', got \"" + tk.getValue() + "\"");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 286 */     if (decodeParameters)
/*     */     {
/* 291 */       combineMultisegmentNames(false);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void putEncodedName(String name, String value)
/*     */     throws ParseException
/*     */   {
/* 307 */     int star = name.indexOf('*');
/* 308 */     if (star < 0)
/*     */     {
/* 310 */       this.list.put(name, value);
/* 311 */     } else if (star == name.length() - 1)
/*     */     {
/* 313 */       name = name.substring(0, star);
/* 314 */       this.list.put(name, decodeValue(value));
/*     */     }
/*     */     else {
/* 317 */       String rname = name.substring(0, star);
/* 318 */       this.multisegmentNames.add(rname);
/* 319 */       this.list.put(rname, "");
/*     */       Object v;
/* 322 */       if (name.endsWith("*"))
/*     */       {
/* 324 */         Object v = new Value(null);
/* 325 */         ((Value)v).encodedValue = value;
/* 326 */         ((Value)v).value = value;
/* 327 */         name = name.substring(0, name.length() - 1);
/*     */       }
/*     */       else {
/* 330 */         v = value;
/*     */       }
/* 332 */       this.slist.put(name, v);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void combineMultisegmentNames(boolean keepConsistentOnFailure)
/*     */     throws ParseException
/*     */   {
/* 345 */     boolean success = false;
/*     */     try {
/* 347 */       Iterator it = this.multisegmentNames.iterator();
/* 348 */       while (it.hasNext()) {
/* 349 */         String name = (String)it.next();
/* 350 */         StringBuffer sb = new StringBuffer();
/* 351 */         MultiValue mv = new MultiValue(null);
/*     */ 
/* 356 */         String charset = null;
/*     */ 
/* 358 */         for (int segment = 0; ; segment++) {
/* 359 */           String sname = name + "*" + segment;
/* 360 */           Object v = this.slist.get(sname);
/* 361 */           if (v == null)
/*     */             break;
/* 363 */           mv.add(v);
/* 364 */           String value = null;
/* 365 */           if ((v instanceof Value)) {
/*     */             try {
/* 367 */               Value vv = (Value)v;
/* 368 */               String evalue = vv.encodedValue;
/* 369 */               value = evalue;
/* 370 */               if (segment == 0)
/*     */               {
/* 373 */                 Value vnew = decodeValue(evalue);
/* 374 */                 charset = vv.charset = vnew.charset;
/* 375 */                 value = vv.value = vnew.value;
/*     */               } else {
/* 377 */                 if (charset == null)
/*     */                 {
/* 379 */                   this.multisegmentNames.remove(name);
/* 380 */                   break;
/*     */                 }
/* 382 */                 value = vv.value = decodeBytes(evalue, charset);
/*     */               }
/*     */             } catch (NumberFormatException nex) {
/* 385 */               if (decodeParametersStrict)
/* 386 */                 throw new ParseException(nex.toString());
/*     */             } catch (UnsupportedEncodingException uex) {
/* 388 */               if (decodeParametersStrict)
/* 389 */                 throw new ParseException(uex.toString());
/*     */             } catch (StringIndexOutOfBoundsException ex) {
/* 391 */               if (decodeParametersStrict) {
/* 392 */                 throw new ParseException(ex.toString());
/*     */               }
/*     */             }
/*     */           }
/*     */           else {
/* 397 */             value = (String)v;
/*     */           }
/* 399 */           sb.append(value);
/* 400 */           this.slist.remove(sname);
/*     */         }
/* 402 */         if (segment == 0)
/*     */         {
/* 404 */           this.list.remove(name);
/*     */         } else {
/* 406 */           mv.value = sb.toString();
/* 407 */           this.list.put(name, mv);
/*     */         }
/*     */       }
/* 410 */       success = true;
/*     */     }
/*     */     finally
/*     */     {
/* 417 */       if ((keepConsistentOnFailure) || (success))
/*     */       {
/* 420 */         if (this.slist.size() > 0)
/*     */         {
/* 422 */           Iterator sit = this.slist.values().iterator();
/* 423 */           while (sit.hasNext()) {
/* 424 */             Object v = sit.next();
/* 425 */             if ((v instanceof Value)) {
/* 426 */               Value vv = (Value)v;
/* 427 */               Value vnew = decodeValue(vv.encodedValue);
/* 428 */               vv.charset = vnew.charset;
/* 429 */               vv.value = vnew.value;
/*     */             }
/*     */           }
/* 432 */           this.list.putAll(this.slist);
/*     */         }
/*     */ 
/* 436 */         this.multisegmentNames.clear();
/* 437 */         this.slist.clear();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 448 */     return this.list.size();
/*     */   }
/*     */ 
/*     */   public String get(String name)
/*     */   {
/* 462 */     Object v = this.list.get(name.trim().toLowerCase(Locale.ENGLISH));
/*     */     String value;
/*     */     String value;
/* 463 */     if ((v instanceof MultiValue)) {
/* 464 */       value = ((MultiValue)v).value;
/*     */     }
/*     */     else
/*     */     {
/*     */       String value;
/* 465 */       if ((v instanceof Value))
/* 466 */         value = ((Value)v).value;
/*     */       else
/* 468 */         value = (String)v; 
/*     */     }
/* 469 */     return value;
/*     */   }
/*     */ 
/*     */   public void set(String name, String value)
/*     */   {
/* 482 */     if ((name == null) && (value != null) && (value.equals("DONE")))
/*     */     {
/* 489 */       if ((decodeParameters) && (this.multisegmentNames.size() > 0))
/*     */         try {
/* 491 */           combineMultisegmentNames(true);
/*     */         }
/*     */         catch (ParseException pex)
/*     */         {
/*     */         }
/* 496 */       return;
/*     */     }
/* 498 */     name = name.trim().toLowerCase(Locale.ENGLISH);
/* 499 */     if (decodeParameters)
/*     */       try {
/* 501 */         putEncodedName(name, value);
/*     */       }
/*     */       catch (ParseException pex) {
/* 504 */         this.list.put(name, value);
/*     */       }
/*     */     else
/* 507 */       this.list.put(name, value);
/*     */   }
/*     */ 
/*     */   public void set(String name, String value, String charset)
/*     */   {
/* 523 */     if (encodeParameters) {
/* 524 */       Value ev = encodeValue(value, charset);
/*     */ 
/* 526 */       if (ev != null)
/* 527 */         this.list.put(name.trim().toLowerCase(Locale.ENGLISH), ev);
/*     */       else
/* 529 */         set(name, value);
/*     */     } else {
/* 531 */       set(name, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void remove(String name)
/*     */   {
/* 541 */     this.list.remove(name.trim().toLowerCase(Locale.ENGLISH));
/*     */   }
/*     */ 
/*     */   public Enumeration getNames()
/*     */   {
/* 551 */     return new ParamEnum(this.list.keySet().iterator());
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 561 */     return toString(0);
/*     */   }
/*     */ 
/*     */   public String toString(int used)
/*     */   {
/* 579 */     ToStringBuffer sb = new ToStringBuffer(used);
/* 580 */     Iterator e = this.list.keySet().iterator();
/*     */ 
/* 582 */     while (e.hasNext()) {
/* 583 */       String name = (String)e.next();
/* 584 */       Object v = this.list.get(name);
/* 585 */       if ((v instanceof MultiValue)) {
/* 586 */         MultiValue vv = (MultiValue)v;
/* 587 */         String ns = name + "*";
/* 588 */         for (int i = 0; i < vv.size(); i++) {
/* 589 */           Object va = vv.get(i);
/* 590 */           if ((va instanceof Value))
/* 591 */             sb.addNV(ns + i + "*", ((Value)va).encodedValue);
/*     */           else
/* 593 */             sb.addNV(ns + i, (String)va);
/*     */         }
/* 595 */       } else if ((v instanceof Value)) {
/* 596 */         sb.addNV(name + "*", ((Value)v).encodedValue);
/*     */       } else {
/* 598 */         sb.addNV(name, (String)v);
/*     */       }
/*     */     }
/* 600 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private static String quote(String value)
/*     */   {
/* 649 */     return MimeUtility.quote(value, "()<>@,;:\\\"\t []/?=");
/*     */   }
/*     */ 
/*     */   private static Value encodeValue(String value, String charset)
/*     */   {
/* 664 */     if (MimeUtility.checkAscii(value) == 1)
/* 665 */       return null;
/*     */     byte[] b;
/*     */     try
/*     */     {
/* 669 */       b = value.getBytes(MimeUtility.javaCharset(charset));
/*     */     } catch (UnsupportedEncodingException ex) {
/* 671 */       return null;
/*     */     }
/* 673 */     StringBuffer sb = new StringBuffer(b.length + charset.length() + 2);
/* 674 */     sb.append(charset).append("''");
/* 675 */     for (int i = 0; i < b.length; i++) {
/* 676 */       char c = (char)(b[i] & 0xFF);
/*     */ 
/* 678 */       if ((c <= ' ') || (c >= '') || (c == '*') || (c == '\'') || (c == '%') || ("()<>@,;:\\\"\t []/?=".indexOf(c) >= 0))
/*     */       {
/* 680 */         sb.append('%').append(hex[(c >> '\004')]).append(hex[(c & 0xF)]);
/*     */       }
/* 682 */       else sb.append(c);
/*     */     }
/* 684 */     Value v = new Value(null);
/* 685 */     v.charset = charset;
/* 686 */     v.value = value;
/* 687 */     v.encodedValue = sb.toString();
/* 688 */     return v;
/*     */   }
/*     */ 
/*     */   private static Value decodeValue(String value)
/*     */     throws ParseException
/*     */   {
/* 695 */     Value v = new Value(null);
/* 696 */     v.encodedValue = value;
/* 697 */     v.value = value;
/*     */     try {
/* 699 */       int i = value.indexOf('\'');
/* 700 */       if (i <= 0) {
/* 701 */         if (decodeParametersStrict) {
/* 702 */           throw new ParseException("Missing charset in encoded value: " + value);
/*     */         }
/* 704 */         return v;
/*     */       }
/* 706 */       String charset = value.substring(0, i);
/* 707 */       int li = value.indexOf('\'', i + 1);
/* 708 */       if (li < 0) {
/* 709 */         if (decodeParametersStrict) {
/* 710 */           throw new ParseException("Missing language in encoded value: " + value);
/*     */         }
/* 712 */         return v;
/*     */       }
/* 714 */       String lang = value.substring(i + 1, li);
/* 715 */       value = value.substring(li + 1);
/* 716 */       v.charset = charset;
/* 717 */       v.value = decodeBytes(value, charset);
/*     */     } catch (NumberFormatException nex) {
/* 719 */       if (decodeParametersStrict)
/* 720 */         throw new ParseException(nex.toString());
/*     */     } catch (UnsupportedEncodingException uex) {
/* 722 */       if (decodeParametersStrict)
/* 723 */         throw new ParseException(uex.toString());
/*     */     } catch (StringIndexOutOfBoundsException ex) {
/* 725 */       if (decodeParametersStrict)
/* 726 */         throw new ParseException(ex.toString());
/*     */     }
/* 728 */     return v;
/*     */   }
/*     */ 
/*     */   private static String decodeBytes(String value, String charset)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 744 */     byte[] b = new byte[value.length()];
/*     */ 
/* 746 */     int i = 0; for (int bi = 0; i < value.length(); i++) {
/* 747 */       char c = value.charAt(i);
/* 748 */       if (c == '%') {
/* 749 */         String hex = value.substring(i + 1, i + 3);
/* 750 */         c = (char)Integer.parseInt(hex, 16);
/* 751 */         i += 2;
/*     */       }
/* 753 */       b[(bi++)] = (byte)c;
/*     */     }
/* 755 */     return new String(b, 0, bi, MimeUtility.javaCharset(charset));
/*     */   }
/*     */ 
/*     */   private static class ToStringBuffer
/*     */   {
/*     */     private int used;
/* 610 */     private StringBuffer sb = new StringBuffer();
/*     */ 
/*     */     public ToStringBuffer(int used) {
/* 613 */       this.used = used;
/*     */     }
/*     */ 
/*     */     public void addNV(String name, String value) {
/* 617 */       value = ParameterList.quote(value);
/* 618 */       this.sb.append("; ");
/* 619 */       this.used += 2;
/* 620 */       int len = name.length() + value.length() + 1;
/* 621 */       if (this.used + len > 76) {
/* 622 */         this.sb.append("\r\n\t");
/* 623 */         this.used = 8;
/*     */       }
/* 625 */       this.sb.append(name).append('=');
/* 626 */       this.used += name.length() + 1;
/* 627 */       if (this.used + value.length() > 76)
/*     */       {
/* 629 */         String s = MimeUtility.fold(this.used, value);
/* 630 */         this.sb.append(s);
/* 631 */         int lastlf = s.lastIndexOf('\n');
/* 632 */         if (lastlf >= 0)
/* 633 */           this.used += s.length() - lastlf - 1;
/*     */         else
/* 635 */           this.used += s.length();
/*     */       } else {
/* 637 */         this.sb.append(value);
/* 638 */         this.used += value.length();
/*     */       }
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 643 */       return this.sb.toString();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class ParamEnum
/*     */     implements Enumeration
/*     */   {
/*     */     private Iterator it;
/*     */ 
/*     */     ParamEnum(Iterator it)
/*     */     {
/* 181 */       this.it = it;
/*     */     }
/*     */ 
/*     */     public boolean hasMoreElements() {
/* 185 */       return this.it.hasNext();
/*     */     }
/*     */ 
/*     */     public Object nextElement() {
/* 189 */       return this.it.next();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class MultiValue extends ArrayList
/*     */   {
/*     */     String value;
/*     */ 
/*     */     private MultiValue()
/*     */     {
/*     */     }
/*     */ 
/*     */     MultiValue(ParameterList.1 x0)
/*     */     {
/* 170 */       this();
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class Value
/*     */   {
/*     */     String value;
/*     */     String charset;
/*     */     String encodedValue;
/*     */ 
/*     */     private Value()
/*     */     {
/*     */     }
/*     */ 
/*     */     Value(ParameterList.1 x0)
/*     */     {
/* 157 */       this();
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.internet.ParameterList
 * JD-Core Version:    0.6.1
 */