/*     */ package javax.mail.internet;
/*     */ 
/*     */ import com.sun.mail.util.LineOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Enumeration;
/*     */ import javax.activation.DataHandler;
/*     */ import javax.mail.MessagingException;
/*     */ 
/*     */ public class PreencodedMimeBodyPart extends MimeBodyPart
/*     */ {
/*     */   private String encoding;
/*     */ 
/*     */   public PreencodedMimeBodyPart(String encoding)
/*     */   {
/*  68 */     this.encoding = encoding;
/*     */   }
/*     */ 
/*     */   public String getEncoding()
/*     */     throws MessagingException
/*     */   {
/*  76 */     return this.encoding;
/*     */   }
/*     */ 
/*     */   public void writeTo(OutputStream os)
/*     */     throws IOException, MessagingException
/*     */   {
/*  92 */     LineOutputStream los = null;
/*  93 */     if ((os instanceof LineOutputStream))
/*  94 */       los = (LineOutputStream)os;
/*     */     else {
/*  96 */       los = new LineOutputStream(os);
/*     */     }
/*     */ 
/* 100 */     Enumeration hdrLines = getAllHeaderLines();
/* 101 */     while (hdrLines.hasMoreElements()) {
/* 102 */       los.writeln((String)hdrLines.nextElement());
/*     */     }
/*     */ 
/* 105 */     los.writeln();
/*     */ 
/* 108 */     getDataHandler().writeTo(os);
/* 109 */     os.flush();
/*     */   }
/*     */ 
/*     */   protected void updateHeaders()
/*     */     throws MessagingException
/*     */   {
/* 117 */     super.updateHeaders();
/* 118 */     MimeBodyPart.setEncoding(this, this.encoding);
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.internet.PreencodedMimeBodyPart
 * JD-Core Version:    0.6.1
 */