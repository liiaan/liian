/*      */ package javax.mail.internet;
/*      */ 
/*      */ import com.sun.mail.util.ASCIIUtility;
/*      */ import com.sun.mail.util.BASE64DecoderStream;
/*      */ import com.sun.mail.util.BASE64EncoderStream;
/*      */ import com.sun.mail.util.BEncoderStream;
/*      */ import com.sun.mail.util.LineInputStream;
/*      */ import com.sun.mail.util.PropUtil;
/*      */ import com.sun.mail.util.QDecoderStream;
/*      */ import com.sun.mail.util.QEncoderStream;
/*      */ import com.sun.mail.util.QPDecoderStream;
/*      */ import com.sun.mail.util.QPEncoderStream;
/*      */ import com.sun.mail.util.UUDecoderStream;
/*      */ import com.sun.mail.util.UUEncoderStream;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.OutputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Locale;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.StringTokenizer;
/*      */ import javax.activation.DataHandler;
/*      */ import javax.activation.DataSource;
/*      */ import javax.mail.MessagingException;
/*      */ 
/*      */ public class MimeUtility
/*      */ {
/*      */   public static final int ALL = -1;
/*  144 */   private static boolean decodeStrict = PropUtil.getBooleanSystemProperty("mail.mime.decodetext.strict", true);
/*      */ 
/*  146 */   private static boolean encodeEolStrict = PropUtil.getBooleanSystemProperty("mail.mime.encodeeol.strict", false);
/*      */ 
/*  148 */   private static boolean ignoreUnknownEncoding = PropUtil.getBooleanSystemProperty("mail.mime.ignoreunknownencoding", false);
/*      */ 
/*  157 */   private static boolean foldEncodedWords = PropUtil.getBooleanSystemProperty("mail.mime.foldencodedwords", false);
/*      */ 
/*  159 */   private static boolean foldText = PropUtil.getBooleanSystemProperty("mail.mime.foldtext", true);
/*      */   private static String defaultJavaCharset;
/*      */   private static String defaultMIMECharset;
/*      */   private static Hashtable mime2java;
/* 1224 */   private static Hashtable java2mime = new Hashtable(40);
/*      */   static final int ALL_ASCII = 1;
/*      */   static final int MOSTLY_ASCII = 2;
/*      */   static final int MOSTLY_NONASCII = 3;
/*      */ 
/*      */   public static String getEncoding(DataSource ds)
/*      */   {
/*  187 */     ContentType cType = null;
/*  188 */     InputStream is = null;
/*  189 */     String encoding = null;
/*      */     try
/*      */     {
/*  192 */       cType = new ContentType(ds.getContentType());
/*  193 */       is = ds.getInputStream();
/*      */     } catch (Exception ex) {
/*  195 */       return "base64";
/*      */     }
/*      */ 
/*  198 */     boolean isText = cType.match("text/*");
/*      */ 
/*  200 */     int i = checkAscii(is, -1, !isText);
/*  201 */     switch (i) {
/*      */     case 1:
/*  203 */       encoding = "7bit";
/*  204 */       break;
/*      */     case 2:
/*  206 */       encoding = "quoted-printable";
/*  207 */       break;
/*      */     default:
/*  209 */       encoding = "base64";
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  215 */       is.close();
/*      */     } catch (IOException ioex) {
/*      */     }
/*  218 */     return encoding;
/*      */   }
/*      */ 
/*      */   public static String getEncoding(DataHandler dh)
/*      */   {
/*  235 */     ContentType cType = null;
/*  236 */     String encoding = null;
/*      */ 
/*  251 */     if (dh.getName() != null)
/*  252 */       return getEncoding(dh.getDataSource());
/*      */     try
/*      */     {
/*  255 */       cType = new ContentType(dh.getContentType());
/*      */     } catch (Exception ex) {
/*  257 */       return "base64";
/*      */     }
/*      */ 
/*  260 */     if (cType.match("text/*"))
/*      */     {
/*  262 */       AsciiOutputStream aos = new AsciiOutputStream(false, false);
/*      */       try {
/*  264 */         dh.writeTo(aos);
/*      */       }
/*      */       catch (IOException ex) {
/*      */       }
/*  268 */       switch (aos.getAscii()) {
/*      */       case 1:
/*  270 */         encoding = "7bit";
/*  271 */         break;
/*      */       case 2:
/*  273 */         encoding = "quoted-printable";
/*  274 */         break;
/*      */       default:
/*  276 */         encoding = "base64";
/*      */       }
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*  282 */       AsciiOutputStream aos = new AsciiOutputStream(true, encodeEolStrict);
/*      */       try
/*      */       {
/*  285 */         dh.writeTo(aos); } catch (IOException ex) {
/*      */       }
/*  287 */       if (aos.getAscii() == 1)
/*  288 */         encoding = "7bit";
/*      */       else {
/*  290 */         encoding = "base64";
/*      */       }
/*      */     }
/*  293 */     return encoding;
/*      */   }
/*      */ 
/*      */   public static InputStream decode(InputStream is, String encoding)
/*      */     throws MessagingException
/*      */   {
/*  315 */     if (encoding.equalsIgnoreCase("base64"))
/*  316 */       return new BASE64DecoderStream(is);
/*  317 */     if (encoding.equalsIgnoreCase("quoted-printable"))
/*  318 */       return new QPDecoderStream(is);
/*  319 */     if ((encoding.equalsIgnoreCase("uuencode")) || (encoding.equalsIgnoreCase("x-uuencode")) || (encoding.equalsIgnoreCase("x-uue")))
/*      */     {
/*  322 */       return new UUDecoderStream(is);
/*  323 */     }if ((encoding.equalsIgnoreCase("binary")) || (encoding.equalsIgnoreCase("7bit")) || (encoding.equalsIgnoreCase("8bit")))
/*      */     {
/*  326 */       return is;
/*      */     }
/*  328 */     if (!ignoreUnknownEncoding)
/*  329 */       throw new MessagingException("Unknown encoding: " + encoding);
/*  330 */     return is;
/*      */   }
/*      */ 
/*      */   public static OutputStream encode(OutputStream os, String encoding)
/*      */     throws MessagingException
/*      */   {
/*  348 */     if (encoding == null)
/*  349 */       return os;
/*  350 */     if (encoding.equalsIgnoreCase("base64"))
/*  351 */       return new BASE64EncoderStream(os);
/*  352 */     if (encoding.equalsIgnoreCase("quoted-printable"))
/*  353 */       return new QPEncoderStream(os);
/*  354 */     if ((encoding.equalsIgnoreCase("uuencode")) || (encoding.equalsIgnoreCase("x-uuencode")) || (encoding.equalsIgnoreCase("x-uue")))
/*      */     {
/*  357 */       return new UUEncoderStream(os);
/*  358 */     }if ((encoding.equalsIgnoreCase("binary")) || (encoding.equalsIgnoreCase("7bit")) || (encoding.equalsIgnoreCase("8bit")))
/*      */     {
/*  361 */       return os;
/*      */     }
/*  363 */     throw new MessagingException("Unknown encoding: " + encoding);
/*      */   }
/*      */ 
/*      */   public static OutputStream encode(OutputStream os, String encoding, String filename)
/*      */     throws MessagingException
/*      */   {
/*  385 */     if (encoding == null)
/*  386 */       return os;
/*  387 */     if (encoding.equalsIgnoreCase("base64"))
/*  388 */       return new BASE64EncoderStream(os);
/*  389 */     if (encoding.equalsIgnoreCase("quoted-printable"))
/*  390 */       return new QPEncoderStream(os);
/*  391 */     if ((encoding.equalsIgnoreCase("uuencode")) || (encoding.equalsIgnoreCase("x-uuencode")) || (encoding.equalsIgnoreCase("x-uue")))
/*      */     {
/*  394 */       return new UUEncoderStream(os, filename);
/*  395 */     }if ((encoding.equalsIgnoreCase("binary")) || (encoding.equalsIgnoreCase("7bit")) || (encoding.equalsIgnoreCase("8bit")))
/*      */     {
/*  398 */       return os;
/*      */     }
/*  400 */     throw new MessagingException("Unknown encoding: " + encoding);
/*      */   }
/*      */ 
/*      */   public static String encodeText(String text)
/*      */     throws UnsupportedEncodingException
/*      */   {
/*  441 */     return encodeText(text, null, null);
/*      */   }
/*      */ 
/*      */   public static String encodeText(String text, String charset, String encoding)
/*      */     throws UnsupportedEncodingException
/*      */   {
/*  472 */     return encodeWord(text, charset, encoding, false);
/*      */   }
/*      */ 
/*      */   public static String decodeText(String etext)
/*      */     throws UnsupportedEncodingException
/*      */   {
/*  514 */     String lwsp = " \t\n\r";
/*      */ 
/*  526 */     if (etext.indexOf("=?") == -1) {
/*  527 */       return etext;
/*      */     }
/*      */ 
/*  531 */     StringTokenizer st = new StringTokenizer(etext, lwsp, true);
/*  532 */     StringBuffer sb = new StringBuffer();
/*  533 */     StringBuffer wsb = new StringBuffer();
/*  534 */     boolean prevWasEncoded = false;
/*      */ 
/*  536 */     while (st.hasMoreTokens())
/*      */     {
/*  538 */       String s = st.nextToken();
/*      */       char c;
/*  540 */       if (((c = s.charAt(0)) == ' ') || (c == '\t') || (c == '\r') || (c == '\n'))
/*      */       {
/*  542 */         wsb.append(c);
/*      */       }
/*      */       else {
/*      */         String word;
/*      */         try {
/*  547 */           word = decodeWord(s);
/*      */ 
/*  549 */           if ((!prevWasEncoded) && (wsb.length() > 0))
/*      */           {
/*  553 */             sb.append(wsb);
/*      */           }
/*  555 */           prevWasEncoded = true;
/*      */         }
/*      */         catch (ParseException pex) {
/*  558 */           word = s;
/*      */ 
/*  560 */           if (!decodeStrict) {
/*  561 */             String dword = decodeInnerWords(word);
/*  562 */             if (dword != word)
/*      */             {
/*  565 */               if ((!prevWasEncoded) || (!word.startsWith("=?")))
/*      */               {
/*  570 */                 if (wsb.length() > 0) {
/*  571 */                   sb.append(wsb);
/*      */                 }
/*      */               }
/*  574 */               prevWasEncoded = word.endsWith("?=");
/*  575 */               word = dword;
/*      */             }
/*      */             else {
/*  578 */               if (wsb.length() > 0)
/*  579 */                 sb.append(wsb);
/*  580 */               prevWasEncoded = false;
/*      */             }
/*      */           }
/*      */           else {
/*  584 */             if (wsb.length() > 0)
/*  585 */               sb.append(wsb);
/*  586 */             prevWasEncoded = false;
/*      */           }
/*      */         }
/*  589 */         sb.append(word);
/*  590 */         wsb.setLength(0);
/*      */       }
/*      */     }
/*  593 */     sb.append(wsb);
/*  594 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String encodeWord(String word)
/*      */     throws UnsupportedEncodingException
/*      */   {
/*  620 */     return encodeWord(word, null, null);
/*      */   }
/*      */ 
/*      */   public static String encodeWord(String word, String charset, String encoding)
/*      */     throws UnsupportedEncodingException
/*      */   {
/*  648 */     return encodeWord(word, charset, encoding, true);
/*      */   }
/*      */ 
/*      */   private static String encodeWord(String string, String charset, String encoding, boolean encodingWord)
/*      */     throws UnsupportedEncodingException
/*      */   {
/*  664 */     int ascii = checkAscii(string);
/*  665 */     if (ascii == 1)
/*  666 */       return string;
/*      */     String jcharset;
/*  670 */     if (charset == null) {
/*  671 */       String jcharset = getDefaultJavaCharset();
/*  672 */       charset = getDefaultMIMECharset();
/*      */     } else {
/*  674 */       jcharset = javaCharset(charset);
/*      */     }
/*      */ 
/*  677 */     if (encoding == null)
/*  678 */       if (ascii != 3)
/*  679 */         encoding = "Q";
/*      */       else
/*  681 */         encoding = "B";
/*      */     boolean b64;
/*  685 */     if (encoding.equalsIgnoreCase("B")) {
/*  686 */       b64 = true;
/*      */     }
/*      */     else
/*      */     {
/*      */       boolean b64;
/*  687 */       if (encoding.equalsIgnoreCase("Q"))
/*  688 */         b64 = false;
/*      */       else
/*  690 */         throw new UnsupportedEncodingException("Unknown transfer encoding: " + encoding);
/*      */     }
/*      */     boolean b64;
/*  693 */     StringBuffer outb = new StringBuffer();
/*  694 */     doEncode(string, b64, jcharset, 68 - charset.length(), "=?" + charset + "?" + encoding + "?", true, encodingWord, outb);
/*      */ 
/*  702 */     return outb.toString();
/*      */   }
/*      */ 
/*      */   private static void doEncode(String string, boolean b64, String jcharset, int avail, String prefix, boolean first, boolean encodingWord, StringBuffer buf)
/*      */     throws UnsupportedEncodingException
/*      */   {
/*  712 */     byte[] bytes = string.getBytes(jcharset);
/*      */     int len;
/*      */     int len;
/*  714 */     if (b64)
/*  715 */       len = BEncoderStream.encodedLength(bytes);
/*      */     else
/*  717 */       len = QEncoderStream.encodedLength(bytes, encodingWord);
/*      */     int size;
/*  720 */     if ((len > avail) && ((size = string.length()) > 1))
/*      */     {
/*  723 */       doEncode(string.substring(0, size / 2), b64, jcharset, avail, prefix, first, encodingWord, buf);
/*      */ 
/*  725 */       doEncode(string.substring(size / 2, size), b64, jcharset, avail, prefix, false, encodingWord, buf);
/*      */     }
/*      */     else
/*      */     {
/*  729 */       ByteArrayOutputStream os = new ByteArrayOutputStream();
/*      */       OutputStream eos;
/*      */       OutputStream eos;
/*  731 */       if (b64)
/*  732 */         eos = new BEncoderStream(os);
/*      */       else
/*  734 */         eos = new QEncoderStream(os, encodingWord);
/*      */       try
/*      */       {
/*  737 */         eos.write(bytes);
/*  738 */         eos.close();
/*      */       } catch (IOException ioex) {
/*      */       }
/*  741 */       byte[] encodedBytes = os.toByteArray();
/*      */ 
/*  744 */       if (!first) {
/*  745 */         if (foldEncodedWords)
/*  746 */           buf.append("\r\n ");
/*      */         else
/*  748 */           buf.append(" ");
/*      */       }
/*  750 */       buf.append(prefix);
/*  751 */       for (int i = 0; i < encodedBytes.length; i++)
/*  752 */         buf.append((char)encodedBytes[i]);
/*  753 */       buf.append("?=");
/*      */     }
/*      */   }
/*      */ 
/*      */   public static String decodeWord(String eword)
/*      */     throws ParseException, UnsupportedEncodingException
/*      */   {
/*  773 */     if (!eword.startsWith("=?")) {
/*  774 */       throw new ParseException("encoded word does not start with \"=?\": " + eword);
/*      */     }
/*      */ 
/*  778 */     int start = 2;
/*      */     int pos;
/*  779 */     if ((pos = eword.indexOf('?', start)) == -1) {
/*  780 */       throw new ParseException("encoded word does not include charset: " + eword);
/*      */     }
/*  782 */     String charset = javaCharset(eword.substring(start, pos));
/*      */ 
/*  785 */     start = pos + 1;
/*  786 */     if ((pos = eword.indexOf('?', start)) == -1) {
/*  787 */       throw new ParseException("encoded word does not include encoding: " + eword);
/*      */     }
/*  789 */     String encoding = eword.substring(start, pos);
/*      */ 
/*  792 */     start = pos + 1;
/*  793 */     if ((pos = eword.indexOf("?=", start)) == -1) {
/*  794 */       throw new ParseException("encoded word does not end with \"?=\": " + eword);
/*      */     }
/*      */ 
/*  803 */     String word = eword.substring(start, pos);
/*      */     try
/*      */     {
/*      */       String decodedWord;
/*      */       String decodedWord;
/*  807 */       if (word.length() > 0)
/*      */       {
/*  809 */         ByteArrayInputStream bis = new ByteArrayInputStream(ASCIIUtility.getBytes(word));
/*      */         InputStream is;
/*  814 */         if (encoding.equalsIgnoreCase("B")) {
/*  815 */           is = new BASE64DecoderStream(bis);
/*      */         }
/*      */         else
/*      */         {
/*      */           InputStream is;
/*  816 */           if (encoding.equalsIgnoreCase("Q"))
/*  817 */             is = new QDecoderStream(bis);
/*      */           else
/*  819 */             throw new UnsupportedEncodingException("unknown encoding: " + encoding);
/*      */         }
/*      */         InputStream is;
/*  827 */         int count = bis.available();
/*  828 */         byte[] bytes = new byte[count];
/*      */ 
/*  830 */         count = is.read(bytes, 0, count);
/*      */ 
/*  834 */         decodedWord = count <= 0 ? "" : new String(bytes, 0, count, charset);
/*      */       }
/*      */       else
/*      */       {
/*  838 */         decodedWord = "";
/*      */       }
/*      */       String rest;
/*  840 */       if (pos + 2 < eword.length())
/*      */       {
/*  842 */         rest = eword.substring(pos + 2);
/*  843 */         if (!decodeStrict)
/*  844 */           rest = decodeInnerWords(rest); 
/*      */       }
/*  845 */       return decodedWord + rest;
/*      */     }
/*      */     catch (UnsupportedEncodingException uex)
/*      */     {
/*  851 */       throw uex;
/*      */     }
/*      */     catch (IOException ioex) {
/*  854 */       throw new ParseException(ioex.toString());
/*      */     }
/*      */     catch (IllegalArgumentException iex)
/*      */     {
/*      */     }
/*      */ 
/*  863 */     throw new UnsupportedEncodingException(charset);
/*      */   }
/*      */ 
/*      */   private static String decodeInnerWords(String word)
/*      */     throws UnsupportedEncodingException
/*      */   {
/*  874 */     int start = 0;
/*  875 */     StringBuffer buf = new StringBuffer();
/*      */     int i;
/*  876 */     while ((i = word.indexOf("=?", start)) >= 0) {
/*  877 */       buf.append(word.substring(start, i));
/*      */ 
/*  879 */       int end = word.indexOf('?', i + 2);
/*  880 */       if (end < 0) {
/*      */         break;
/*      */       }
/*  883 */       end = word.indexOf('?', end + 1);
/*  884 */       if (end < 0) {
/*      */         break;
/*      */       }
/*  887 */       end = word.indexOf("?=", end + 1);
/*  888 */       if (end < 0)
/*      */         break;
/*  890 */       String s = word.substring(i, end + 2);
/*      */       try {
/*  892 */         s = decodeWord(s);
/*      */       }
/*      */       catch (ParseException pex) {
/*      */       }
/*  896 */       buf.append(s);
/*  897 */       start = end + 2;
/*      */     }
/*  899 */     if (start == 0)
/*  900 */       return word;
/*  901 */     if (start < word.length())
/*  902 */       buf.append(word.substring(start));
/*  903 */     return buf.toString();
/*      */   }
/*      */ 
/*      */   public static String quote(String word, String specials)
/*      */   {
/*  923 */     int len = word.length();
/*  924 */     if (len == 0) {
/*  925 */       return "\"\"";
/*      */     }
/*      */ 
/*  931 */     boolean needQuoting = false;
/*  932 */     for (int i = 0; i < len; i++) {
/*  933 */       char c = word.charAt(i);
/*  934 */       if ((c == '"') || (c == '\\') || (c == '\r') || (c == '\n'))
/*      */       {
/*  936 */         StringBuffer sb = new StringBuffer(len + 3);
/*  937 */         sb.append('"');
/*  938 */         sb.append(word.substring(0, i));
/*  939 */         int lastc = 0;
/*  940 */         for (int j = i; j < len; j++) {
/*  941 */           char cc = word.charAt(j);
/*  942 */           if ((cc == '"') || (cc == '\\') || (cc == '\r') || (cc == '\n'))
/*      */           {
/*  944 */             if ((cc != '\n') || (lastc != 13))
/*      */             {
/*  947 */               sb.append('\\'); } 
/*  948 */           }sb.append(cc);
/*  949 */           lastc = cc;
/*      */         }
/*  951 */         sb.append('"');
/*  952 */         return sb.toString();
/*  953 */       }if ((c < ' ') || (c >= '') || (specials.indexOf(c) >= 0))
/*      */       {
/*  955 */         needQuoting = true;
/*      */       }
/*      */     }
/*  958 */     if (needQuoting) {
/*  959 */       StringBuffer sb = new StringBuffer(len + 2);
/*  960 */       sb.append('"').append(word).append('"');
/*  961 */       return sb.toString();
/*      */     }
/*  963 */     return word;
/*      */   }
/*      */ 
/*      */   public static String fold(int used, String s)
/*      */   {
/*  983 */     if (!foldText) {
/*  984 */       return s;
/*      */     }
/*      */ 
/*  989 */     for (int end = s.length() - 1; end >= 0; end--) {
/*  990 */       char c = s.charAt(end);
/*  991 */       if ((c != ' ') && (c != '\t') && (c != '\r') && (c != '\n'))
/*      */         break;
/*      */     }
/*  994 */     if (end != s.length() - 1) {
/*  995 */       s = s.substring(0, end + 1);
/*      */     }
/*      */ 
/*  998 */     if (used + s.length() <= 76) {
/*  999 */       return s;
/*      */     }
/*      */ 
/* 1002 */     StringBuffer sb = new StringBuffer(s.length() + 4);
/* 1003 */     char lastc = '\000';
/* 1004 */     while (used + s.length() > 76) {
/* 1005 */       int lastspace = -1;
/* 1006 */       for (int i = 0; (i < s.length()) && (
/* 1007 */         (lastspace == -1) || (used + i <= 76)); i++)
/*      */       {
/* 1009 */         char c = s.charAt(i);
/* 1010 */         if (((c == ' ') || (c == '\t')) && 
/* 1011 */           (lastc != ' ') && (lastc != '\t'))
/* 1012 */           lastspace = i;
/* 1013 */         lastc = c;
/*      */       }
/* 1015 */       if (lastspace == -1)
/*      */       {
/* 1017 */         sb.append(s);
/* 1018 */         s = "";
/* 1019 */         used = 0;
/* 1020 */         break;
/*      */       }
/* 1022 */       sb.append(s.substring(0, lastspace));
/* 1023 */       sb.append("\r\n");
/* 1024 */       lastc = s.charAt(lastspace);
/* 1025 */       sb.append(lastc);
/* 1026 */       s = s.substring(lastspace + 1);
/* 1027 */       used = 1;
/*      */     }
/* 1029 */     sb.append(s);
/* 1030 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   public static String unfold(String s)
/*      */   {
/* 1042 */     if (!foldText) {
/* 1043 */       return s;
/*      */     }
/* 1045 */     StringBuffer sb = null;
/*      */     int i;
/* 1047 */     while ((i = indexOfAny(s, "\r\n")) >= 0) {
/* 1048 */       int start = i;
/* 1049 */       int l = s.length();
/* 1050 */       i++;
/* 1051 */       if ((i < l) && (s.charAt(i - 1) == '\r') && (s.charAt(i) == '\n'))
/* 1052 */         i++;
/* 1053 */       if ((start == 0) || (s.charAt(start - 1) != '\\'))
/*      */       {
/*      */         char c;
/* 1057 */         if ((i < l) && (((c = s.charAt(i)) == ' ') || (c == '\t'))) {
/* 1058 */           i++;
/* 1059 */           while ((i < l) && (((c = s.charAt(i)) == ' ') || (c == '\t')))
/* 1060 */             i++;
/* 1061 */           if (sb == null)
/* 1062 */             sb = new StringBuffer(s.length());
/* 1063 */           if (start != 0) {
/* 1064 */             sb.append(s.substring(0, start));
/* 1065 */             sb.append(' ');
/*      */           }
/* 1067 */           s = s.substring(i);
/*      */         }
/*      */         else
/*      */         {
/* 1071 */           if (sb == null)
/* 1072 */             sb = new StringBuffer(s.length());
/* 1073 */           sb.append(s.substring(0, i));
/* 1074 */           s = s.substring(i);
/*      */         }
/*      */       }
/*      */       else {
/* 1078 */         if (sb == null)
/* 1079 */           sb = new StringBuffer(s.length());
/* 1080 */         sb.append(s.substring(0, start - 1));
/* 1081 */         sb.append(s.substring(start, i));
/* 1082 */         s = s.substring(i);
/*      */       }
/*      */     }
/* 1085 */     if (sb != null) {
/* 1086 */       sb.append(s);
/* 1087 */       return sb.toString();
/*      */     }
/* 1089 */     return s;
/*      */   }
/*      */ 
/*      */   private static int indexOfAny(String s, String any)
/*      */   {
/* 1099 */     return indexOfAny(s, any, 0);
/*      */   }
/*      */ 
/*      */   private static int indexOfAny(String s, String any, int start) {
/*      */     try {
/* 1104 */       int len = s.length();
/* 1105 */       for (int i = start; i < len; i++) {
/* 1106 */         if (any.indexOf(s.charAt(i)) >= 0)
/* 1107 */           return i;
/*      */       }
/* 1109 */       return -1; } catch (StringIndexOutOfBoundsException e) {
/*      */     }
/* 1111 */     return -1;
/*      */   }
/*      */ 
/*      */   public static String javaCharset(String charset)
/*      */   {
/* 1123 */     if ((mime2java == null) || (charset == null))
/*      */     {
/* 1125 */       return charset;
/*      */     }
/* 1127 */     String alias = (String)mime2java.get(charset.toLowerCase(Locale.ENGLISH));
/*      */ 
/* 1129 */     return alias == null ? charset : alias;
/*      */   }
/*      */ 
/*      */   public static String mimeCharset(String charset)
/*      */   {
/* 1146 */     if ((java2mime == null) || (charset == null))
/*      */     {
/* 1148 */       return charset;
/*      */     }
/* 1150 */     String alias = (String)java2mime.get(charset.toLowerCase(Locale.ENGLISH));
/*      */ 
/* 1152 */     return alias == null ? charset : alias;
/*      */   }
/*      */ 
/*      */   public static String getDefaultJavaCharset()
/*      */   {
/* 1169 */     if (defaultJavaCharset == null)
/*      */     {
/* 1174 */       String mimecs = null;
/*      */       try {
/* 1176 */         mimecs = System.getProperty("mail.mime.charset"); } catch (SecurityException ex) {
/*      */       }
/* 1178 */       if ((mimecs != null) && (mimecs.length() > 0)) {
/* 1179 */         defaultJavaCharset = javaCharset(mimecs);
/* 1180 */         return defaultJavaCharset;
/*      */       }
/*      */       try
/*      */       {
/* 1184 */         defaultJavaCharset = System.getProperty("file.encoding", "8859_1");
/*      */       }
/*      */       catch (SecurityException sex)
/*      */       {
/* 1193 */         InputStreamReader reader = new InputStreamReader(new InputStream()
/*      */         {
/*      */           public int read()
/*      */           {
/* 1190 */             return 0;
/*      */           }
/*      */         });
/* 1195 */         defaultJavaCharset = reader.getEncoding();
/* 1196 */         if (defaultJavaCharset == null) {
/* 1197 */           defaultJavaCharset = "8859_1";
/*      */         }
/*      */       }
/*      */     }
/* 1201 */     return defaultJavaCharset;
/*      */   }
/*      */ 
/*      */   static String getDefaultMIMECharset()
/*      */   {
/* 1208 */     if (defaultMIMECharset == null)
/*      */       try {
/* 1210 */         defaultMIMECharset = System.getProperty("mail.mime.charset");
/*      */       } catch (SecurityException ex) {
/*      */       }
/* 1213 */     if (defaultMIMECharset == null)
/* 1214 */       defaultMIMECharset = mimeCharset(getDefaultJavaCharset());
/* 1215 */     return defaultMIMECharset;
/*      */   }
/*      */ 
/*      */   private static void loadMappings(LineInputStream is, Hashtable table)
/*      */   {
/*      */     while (true)
/*      */     {
/*      */       String currLine;
/*      */       try
/*      */       {
/* 1321 */         currLine = is.readLine();
/*      */       } catch (IOException ioex) {
/* 1323 */         break;
/*      */       }
/*      */ 
/* 1326 */       if (currLine == null)
/*      */         break;
/* 1328 */       if ((currLine.startsWith("--")) && (currLine.endsWith("--")))
/*      */       {
/*      */         break;
/*      */       }
/*      */ 
/* 1333 */       if ((currLine.trim().length() != 0) && (!currLine.startsWith("#")))
/*      */       {
/* 1338 */         StringTokenizer tk = new StringTokenizer(currLine, " \t");
/*      */         try {
/* 1340 */           String key = tk.nextToken();
/* 1341 */           String value = tk.nextToken();
/* 1342 */           table.put(key.toLowerCase(Locale.ENGLISH), value);
/*      */         }
/*      */         catch (NoSuchElementException nex)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static int checkAscii(String s)
/*      */   {
/* 1360 */     int ascii = 0; int non_ascii = 0;
/* 1361 */     int l = s.length();
/*      */ 
/* 1363 */     for (int i = 0; i < l; i++) {
/* 1364 */       if (nonascii(s.charAt(i)))
/* 1365 */         non_ascii++;
/*      */       else {
/* 1367 */         ascii++;
/*      */       }
/*      */     }
/* 1370 */     if (non_ascii == 0)
/* 1371 */       return 1;
/* 1372 */     if (ascii > non_ascii) {
/* 1373 */       return 2;
/*      */     }
/* 1375 */     return 3;
/*      */   }
/*      */ 
/*      */   static int checkAscii(byte[] b)
/*      */   {
/* 1389 */     int ascii = 0; int non_ascii = 0;
/*      */ 
/* 1391 */     for (int i = 0; i < b.length; i++)
/*      */     {
/* 1395 */       if (nonascii(b[i] & 0xFF))
/* 1396 */         non_ascii++;
/*      */       else {
/* 1398 */         ascii++;
/*      */       }
/*      */     }
/* 1401 */     if (non_ascii == 0)
/* 1402 */       return 1;
/* 1403 */     if (ascii > non_ascii) {
/* 1404 */       return 2;
/*      */     }
/* 1406 */     return 3;
/*      */   }
/*      */ 
/*      */   static int checkAscii(InputStream is, int max, boolean breakOnNonAscii)
/*      */   {
/* 1431 */     int ascii = 0; int non_ascii = 0;
/*      */ 
/* 1433 */     int block = 4096;
/* 1434 */     int linelen = 0;
/* 1435 */     boolean longLine = false; boolean badEOL = false;
/* 1436 */     boolean checkEOL = (encodeEolStrict) && (breakOnNonAscii);
/* 1437 */     byte[] buf = null;
/* 1438 */     if (max != 0) {
/* 1439 */       block = max == -1 ? 4096 : Math.min(max, 4096);
/* 1440 */       buf = new byte[block];
/*      */     }
/* 1442 */     while (max != 0) {
/*      */       int len;
/*      */       try { if ((len = is.read(buf, 0, block)) == -1)
/*      */           break;
/* 1446 */         int lastb = 0;
/* 1447 */         for (int i = 0; i < len; i++)
/*      */         {
/* 1452 */           int b = buf[i] & 0xFF;
/* 1453 */           if ((checkEOL) && (((lastb == 13) && (b != 10)) || ((lastb != 13) && (b == 10))))
/*      */           {
/* 1456 */             badEOL = true;
/* 1457 */           }if ((b == 13) || (b == 10)) {
/* 1458 */             linelen = 0;
/*      */           } else {
/* 1460 */             linelen++;
/* 1461 */             if (linelen > 998)
/* 1462 */               longLine = true;
/*      */           }
/* 1464 */           if (nonascii(b)) {
/* 1465 */             if (breakOnNonAscii) {
/* 1466 */               return 3;
/*      */             }
/* 1468 */             non_ascii++;
/*      */           } else {
/* 1470 */             ascii++;
/* 1471 */           }lastb = b;
/*      */         }
/*      */       } catch (IOException ioex) {
/* 1474 */         break;
/*      */       }
/* 1476 */       if (max != -1) {
/* 1477 */         max -= len;
/*      */       }
/*      */     }
/* 1480 */     if ((max == 0) && (breakOnNonAscii))
/*      */     {
/* 1487 */       return 3;
/*      */     }
/* 1489 */     if (non_ascii == 0)
/*      */     {
/* 1494 */       if (badEOL) {
/* 1495 */         return 3;
/*      */       }
/* 1497 */       if (longLine) {
/* 1498 */         return 2;
/*      */       }
/* 1500 */       return 1;
/*      */     }
/* 1502 */     if (ascii > non_ascii)
/* 1503 */       return 2;
/* 1504 */     return 3;
/*      */   }
/*      */ 
/*      */   static final boolean nonascii(int b) {
/* 1508 */     return (b >= 127) || ((b < 32) && (b != 13) && (b != 10) && (b != 9));
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/* 1225 */     mime2java = new Hashtable(10);
/*      */     try
/*      */     {
/* 1230 */       InputStream is = MimeUtility.class.getResourceAsStream("/META-INF/javamail.charset.map");
/*      */ 
/* 1234 */       if (is != null) {
/*      */         try {
/* 1236 */           is = new LineInputStream(is);
/*      */ 
/* 1239 */           loadMappings((LineInputStream)is, java2mime);
/*      */ 
/* 1242 */           loadMappings((LineInputStream)is, mime2java);
/*      */         } finally {
/*      */           try {
/* 1245 */             is.close();
/*      */           }
/*      */           catch (Exception cex)
/*      */           {
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*      */     }
/* 1256 */     if (java2mime.isEmpty()) {
/* 1257 */       java2mime.put("8859_1", "ISO-8859-1");
/* 1258 */       java2mime.put("iso8859_1", "ISO-8859-1");
/* 1259 */       java2mime.put("iso8859-1", "ISO-8859-1");
/*      */ 
/* 1261 */       java2mime.put("8859_2", "ISO-8859-2");
/* 1262 */       java2mime.put("iso8859_2", "ISO-8859-2");
/* 1263 */       java2mime.put("iso8859-2", "ISO-8859-2");
/*      */ 
/* 1265 */       java2mime.put("8859_3", "ISO-8859-3");
/* 1266 */       java2mime.put("iso8859_3", "ISO-8859-3");
/* 1267 */       java2mime.put("iso8859-3", "ISO-8859-3");
/*      */ 
/* 1269 */       java2mime.put("8859_4", "ISO-8859-4");
/* 1270 */       java2mime.put("iso8859_4", "ISO-8859-4");
/* 1271 */       java2mime.put("iso8859-4", "ISO-8859-4");
/*      */ 
/* 1273 */       java2mime.put("8859_5", "ISO-8859-5");
/* 1274 */       java2mime.put("iso8859_5", "ISO-8859-5");
/* 1275 */       java2mime.put("iso8859-5", "ISO-8859-5");
/*      */ 
/* 1277 */       java2mime.put("8859_6", "ISO-8859-6");
/* 1278 */       java2mime.put("iso8859_6", "ISO-8859-6");
/* 1279 */       java2mime.put("iso8859-6", "ISO-8859-6");
/*      */ 
/* 1281 */       java2mime.put("8859_7", "ISO-8859-7");
/* 1282 */       java2mime.put("iso8859_7", "ISO-8859-7");
/* 1283 */       java2mime.put("iso8859-7", "ISO-8859-7");
/*      */ 
/* 1285 */       java2mime.put("8859_8", "ISO-8859-8");
/* 1286 */       java2mime.put("iso8859_8", "ISO-8859-8");
/* 1287 */       java2mime.put("iso8859-8", "ISO-8859-8");
/*      */ 
/* 1289 */       java2mime.put("8859_9", "ISO-8859-9");
/* 1290 */       java2mime.put("iso8859_9", "ISO-8859-9");
/* 1291 */       java2mime.put("iso8859-9", "ISO-8859-9");
/*      */ 
/* 1293 */       java2mime.put("sjis", "Shift_JIS");
/* 1294 */       java2mime.put("jis", "ISO-2022-JP");
/* 1295 */       java2mime.put("iso2022jp", "ISO-2022-JP");
/* 1296 */       java2mime.put("euc_jp", "euc-jp");
/* 1297 */       java2mime.put("koi8_r", "koi8-r");
/* 1298 */       java2mime.put("euc_cn", "euc-cn");
/* 1299 */       java2mime.put("euc_tw", "euc-tw");
/* 1300 */       java2mime.put("euc_kr", "euc-kr");
/*      */     }
/* 1302 */     if (mime2java.isEmpty()) {
/* 1303 */       mime2java.put("iso-2022-cn", "ISO2022CN");
/* 1304 */       mime2java.put("iso-2022-kr", "ISO2022KR");
/* 1305 */       mime2java.put("utf-8", "UTF8");
/* 1306 */       mime2java.put("utf8", "UTF8");
/* 1307 */       mime2java.put("ja_jp.iso2022-7", "ISO2022JP");
/* 1308 */       mime2java.put("ja_jp.eucjp", "EUCJIS");
/* 1309 */       mime2java.put("euc-kr", "KSC5601");
/* 1310 */       mime2java.put("euckr", "KSC5601");
/* 1311 */       mime2java.put("us-ascii", "ISO-8859-1");
/* 1312 */       mime2java.put("x-us-ascii", "ISO-8859-1");
/*      */     }
/*      */   }
/*      */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.internet.MimeUtility
 * JD-Core Version:    0.6.1
 */