/*     */ package javax.mail.internet;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ 
/*     */ class MailDateParser
/*     */ {
/* 453 */   int index = 0;
/* 454 */   char[] orig = null;
/*     */ 
/*     */   public MailDateParser(char[] orig, int index) {
/* 457 */     this.orig = orig;
/* 458 */     this.index = index;
/*     */   }
/*     */ 
/*     */   public void skipUntilNumber()
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/*     */       while (true)
/*     */       {
/* 470 */         switch (this.orig[this.index]) {
/*     */         case '0':
/*     */         case '1':
/*     */         case '2':
/*     */         case '3':
/*     */         case '4':
/*     */         case '5':
/*     */         case '6':
/*     */         case '7':
/*     */         case '8':
/*     */         case '9':
/* 481 */           return;
/*     */         }
/*     */ 
/* 484 */         this.index += 1;
/*     */       }
/*     */     }
/*     */     catch (ArrayIndexOutOfBoundsException e) {
/*     */     }
/* 489 */     throw new ParseException("No Number Found", this.index);
/*     */   }
/*     */ 
/*     */   public void skipWhiteSpace()
/*     */   {
/* 497 */     int len = this.orig.length;
/* 498 */     while (this.index < len)
/* 499 */       switch (this.orig[this.index]) {
/*     */       case '\t':
/*     */       case '\n':
/*     */       case '\r':
/*     */       case ' ':
/* 504 */         this.index += 1;
/* 505 */         break;
/*     */       }
/*     */   }
/*     */ 
/*     */   public int peekChar()
/*     */     throws ParseException
/*     */   {
/* 519 */     if (this.index < this.orig.length) {
/* 520 */       return this.orig[this.index];
/*     */     }
/* 522 */     throw new ParseException("No more characters", this.index);
/*     */   }
/*     */ 
/*     */   public void skipChar(char c)
/*     */     throws ParseException
/*     */   {
/* 530 */     if (this.index < this.orig.length) {
/* 531 */       if (this.orig[this.index] == c)
/* 532 */         this.index += 1;
/*     */       else
/* 534 */         throw new ParseException("Wrong char", this.index);
/*     */     }
/*     */     else
/* 537 */       throw new ParseException("No more characters", this.index);
/*     */   }
/*     */ 
/*     */   public boolean skipIfChar(char c)
/*     */     throws ParseException
/*     */   {
/* 546 */     if (this.index < this.orig.length) {
/* 547 */       if (this.orig[this.index] == c) {
/* 548 */         this.index += 1;
/* 549 */         return true;
/*     */       }
/* 551 */       return false;
/*     */     }
/*     */ 
/* 554 */     throw new ParseException("No more characters", this.index);
/*     */   }
/*     */ 
/*     */   public int parseNumber()
/*     */     throws ParseException
/*     */   {
/* 565 */     int length = this.orig.length;
/* 566 */     boolean gotNum = false;
/* 567 */     int result = 0;
/*     */ 
/* 569 */     while (this.index < length) {
/* 570 */       switch (this.orig[this.index]) {
/*     */       case '0':
/* 572 */         result *= 10;
/* 573 */         gotNum = true;
/* 574 */         break;
/*     */       case '1':
/* 577 */         result = result * 10 + 1;
/* 578 */         gotNum = true;
/* 579 */         break;
/*     */       case '2':
/* 582 */         result = result * 10 + 2;
/* 583 */         gotNum = true;
/* 584 */         break;
/*     */       case '3':
/* 587 */         result = result * 10 + 3;
/* 588 */         gotNum = true;
/* 589 */         break;
/*     */       case '4':
/* 592 */         result = result * 10 + 4;
/* 593 */         gotNum = true;
/* 594 */         break;
/*     */       case '5':
/* 597 */         result = result * 10 + 5;
/* 598 */         gotNum = true;
/* 599 */         break;
/*     */       case '6':
/* 602 */         result = result * 10 + 6;
/* 603 */         gotNum = true;
/* 604 */         break;
/*     */       case '7':
/* 607 */         result = result * 10 + 7;
/* 608 */         gotNum = true;
/* 609 */         break;
/*     */       case '8':
/* 612 */         result = result * 10 + 8;
/* 613 */         gotNum = true;
/* 614 */         break;
/*     */       case '9':
/* 617 */         result = result * 10 + 9;
/* 618 */         gotNum = true;
/* 619 */         break;
/*     */       default:
/* 622 */         if (gotNum) {
/* 623 */           return result;
/*     */         }
/* 625 */         throw new ParseException("No Number found", this.index);
/*     */       }
/*     */ 
/* 628 */       this.index += 1;
/*     */     }
/*     */ 
/* 632 */     if (gotNum) {
/* 633 */       return result;
/*     */     }
/*     */ 
/* 636 */     throw new ParseException("No Number found", this.index);
/*     */   }
/*     */ 
/*     */   public int parseMonth()
/*     */     throws ParseException
/*     */   {
/*     */     try
/*     */     {
/*     */       char curr;
/* 649 */       switch (this.orig[(this.index++)])
/*     */       {
/*     */       case 'J':
/*     */       case 'j':
/* 653 */         switch (this.orig[(this.index++)]) {
/*     */         case 'A':
/*     */         case 'a':
/* 656 */           curr = this.orig[(this.index++)];
/* 657 */           if ((curr == 'N') || (curr == 'n')) {
/* 658 */             return 0;
/*     */           }
/*     */ 
/*     */           break;
/*     */         case 'U':
/*     */         case 'u':
/* 664 */           curr = this.orig[(this.index++)];
/* 665 */           if ((curr == 'N') || (curr == 'n'))
/* 666 */             return 5;
/* 667 */           if ((curr == 'L') || (curr == 'l')) {
/* 668 */             return 6;
/*     */           }
/*     */           break;
/*     */         }
/* 672 */         break;
/*     */       case 'F':
/*     */       case 'f':
/* 676 */         curr = this.orig[(this.index++)];
/* 677 */         if ((curr == 'E') || (curr == 'e')) {
/* 678 */           curr = this.orig[(this.index++)];
/* 679 */           if ((curr == 'B') || (curr == 'b')) {
/* 680 */             return 1;
/*     */           }
/*     */         }
/*     */ 
/*     */         break;
/*     */       case 'M':
/*     */       case 'm':
/* 687 */         curr = this.orig[(this.index++)];
/* 688 */         if ((curr == 'A') || (curr == 'a')) {
/* 689 */           curr = this.orig[(this.index++)];
/* 690 */           if ((curr == 'R') || (curr == 'r'))
/* 691 */             return 2;
/* 692 */           if ((curr == 'Y') || (curr == 'y')) {
/* 693 */             return 4;
/*     */           }
/*     */         }
/*     */ 
/*     */         break;
/*     */       case 'A':
/*     */       case 'a':
/* 700 */         curr = this.orig[(this.index++)];
/* 701 */         if ((curr == 'P') || (curr == 'p')) {
/* 702 */           curr = this.orig[(this.index++)];
/* 703 */           if ((curr == 'R') || (curr == 'r'))
/* 704 */             return 3;
/*     */         }
/* 706 */         else if ((curr == 'U') || (curr == 'u')) {
/* 707 */           curr = this.orig[(this.index++)];
/* 708 */           if ((curr == 'G') || (curr == 'g')) {
/* 709 */             return 7;
/*     */           }
/*     */         }
/*     */ 
/*     */         break;
/*     */       case 'S':
/*     */       case 's':
/* 716 */         curr = this.orig[(this.index++)];
/* 717 */         if ((curr == 'E') || (curr == 'e')) {
/* 718 */           curr = this.orig[(this.index++)];
/* 719 */           if ((curr == 'P') || (curr == 'p')) {
/* 720 */             return 8;
/*     */           }
/*     */         }
/*     */ 
/*     */         break;
/*     */       case 'O':
/*     */       case 'o':
/* 727 */         curr = this.orig[(this.index++)];
/* 728 */         if ((curr == 'C') || (curr == 'c')) {
/* 729 */           curr = this.orig[(this.index++)];
/* 730 */           if ((curr == 'T') || (curr == 't')) {
/* 731 */             return 9;
/*     */           }
/*     */         }
/*     */ 
/*     */         break;
/*     */       case 'N':
/*     */       case 'n':
/* 738 */         curr = this.orig[(this.index++)];
/* 739 */         if ((curr == 'O') || (curr == 'o')) {
/* 740 */           curr = this.orig[(this.index++)];
/* 741 */           if ((curr == 'V') || (curr == 'v')) {
/* 742 */             return 10;
/*     */           }
/*     */         }
/*     */ 
/*     */         break;
/*     */       case 'D':
/*     */       case 'd':
/* 749 */         curr = this.orig[(this.index++)];
/* 750 */         if ((curr == 'E') || (curr == 'e')) {
/* 751 */           curr = this.orig[(this.index++)];
/* 752 */           if ((curr == 'C') || (curr == 'c'))
/* 753 */             return 11;  } break;
/*     */       case 'B':
/*     */       case 'C':
/*     */       case 'E':
/*     */       case 'G':
/*     */       case 'H':
/*     */       case 'I':
/*     */       case 'K':
/*     */       case 'L':
/*     */       case 'P':
/*     */       case 'Q':
/*     */       case 'R':
/*     */       case 'T':
/*     */       case 'U':
/*     */       case 'V':
/*     */       case 'W':
/*     */       case 'X':
/*     */       case 'Y':
/*     */       case 'Z':
/*     */       case '[':
/*     */       case '\\':
/*     */       case ']':
/*     */       case '^':
/*     */       case '_':
/*     */       case '`':
/*     */       case 'b':
/*     */       case 'c':
/*     */       case 'e':
/*     */       case 'g':
/*     */       case 'h':
/*     */       case 'i':
/*     */       case 'k':
/*     */       case 'l':
/*     */       case 'p':
/*     */       case 'q':
/* 761 */       case 'r': }  } catch (ArrayIndexOutOfBoundsException e) {  } throw new ParseException("Bad Month", this.index);
/*     */   }
/*     */ 
/*     */   public int parseTimeZone()
/*     */     throws ParseException
/*     */   {
/* 770 */     if (this.index >= this.orig.length) {
/* 771 */       throw new ParseException("No more characters", this.index);
/*     */     }
/* 773 */     char test = this.orig[this.index];
/* 774 */     if ((test == '+') || (test == '-')) {
/* 775 */       return parseNumericTimeZone();
/*     */     }
/* 777 */     return parseAlphaTimeZone();
/*     */   }
/*     */ 
/*     */   public int parseNumericTimeZone()
/*     */     throws ParseException
/*     */   {
/* 793 */     boolean switchSign = false;
/* 794 */     char first = this.orig[(this.index++)];
/* 795 */     if (first == '+')
/* 796 */       switchSign = true;
/* 797 */     else if (first != '-') {
/* 798 */       throw new ParseException("Bad Numeric TimeZone", this.index);
/*     */     }
/*     */ 
/* 801 */     int oindex = this.index;
/* 802 */     int tz = parseNumber();
/* 803 */     if (tz >= 2400)
/* 804 */       throw new ParseException("Numeric TimeZone out of range", oindex);
/* 805 */     int offset = tz / 100 * 60 + tz % 100;
/* 806 */     if (switchSign) {
/* 807 */       return -offset;
/*     */     }
/* 809 */     return offset;
/*     */   }
/*     */ 
/*     */   public int parseAlphaTimeZone()
/*     */     throws ParseException
/*     */   {
/* 819 */     int result = 0;
/* 820 */     boolean foundCommon = false;
/*     */     char curr;
/*     */     try
/*     */     {
/* 824 */       switch (this.orig[(this.index++)]) {
/*     */       case 'U':
/*     */       case 'u':
/* 827 */         curr = this.orig[(this.index++)];
/* 828 */         if ((curr == 'T') || (curr == 't')) {
/* 829 */           result = 0;
/*     */         }
/*     */         else
/* 832 */           throw new ParseException("Bad Alpha TimeZone", this.index);
/*     */         break;
/*     */       case 'G':
/*     */       case 'g':
/* 836 */         curr = this.orig[(this.index++)];
/* 837 */         if ((curr == 'M') || (curr == 'm')) {
/* 838 */           curr = this.orig[(this.index++)];
/* 839 */           if ((curr == 'T') || (curr == 't')) {
/* 840 */             result = 0;
/* 841 */             break;
/*     */           }
/*     */         }
/* 844 */         throw new ParseException("Bad Alpha TimeZone", this.index);
/*     */       case 'E':
/*     */       case 'e':
/* 848 */         result = 300;
/* 849 */         foundCommon = true;
/* 850 */         break;
/*     */       case 'C':
/*     */       case 'c':
/* 854 */         result = 360;
/* 855 */         foundCommon = true;
/* 856 */         break;
/*     */       case 'M':
/*     */       case 'm':
/* 860 */         result = 420;
/* 861 */         foundCommon = true;
/* 862 */         break;
/*     */       case 'P':
/*     */       case 'p':
/* 866 */         result = 480;
/* 867 */         foundCommon = true;
/* 868 */         break;
/*     */       default:
/* 871 */         throw new ParseException("Bad Alpha TimeZone", this.index);
/*     */       }
/*     */     } catch (ArrayIndexOutOfBoundsException e) {
/* 874 */       throw new ParseException("Bad Alpha TimeZone", this.index);
/*     */     }
/*     */ 
/* 877 */     if (foundCommon) {
/* 878 */       curr = this.orig[(this.index++)];
/* 879 */       if ((curr == 'S') || (curr == 's')) {
/* 880 */         curr = this.orig[(this.index++)];
/* 881 */         if ((curr != 'T') && (curr != 't'))
/* 882 */           throw new ParseException("Bad Alpha TimeZone", this.index);
/*     */       }
/* 884 */       else if ((curr == 'D') || (curr == 'd')) {
/* 885 */         curr = this.orig[(this.index++)];
/* 886 */         if ((curr == 'T') || (curr != 't'))
/*     */         {
/* 888 */           result -= 60;
/*     */         }
/* 890 */         else throw new ParseException("Bad Alpha TimeZone", this.index);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 895 */     return result;
/*     */   }
/*     */ 
/*     */   int getIndex() {
/* 899 */     return this.index;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.internet.MailDateParser
 * JD-Core Version:    0.6.1
 */