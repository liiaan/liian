/*      */ package javax.mail.internet;
/*      */ 
/*      */ import com.sun.mail.util.ASCIIUtility;
/*      */ import com.sun.mail.util.FolderClosedIOException;
/*      */ import com.sun.mail.util.LineOutputStream;
/*      */ import com.sun.mail.util.MessageRemovedIOException;
/*      */ import com.sun.mail.util.PropUtil;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Vector;
/*      */ import javax.activation.DataHandler;
/*      */ import javax.activation.FileDataSource;
/*      */ import javax.mail.BodyPart;
/*      */ import javax.mail.FolderClosedException;
/*      */ import javax.mail.Message;
/*      */ import javax.mail.MessageRemovedException;
/*      */ import javax.mail.MessagingException;
/*      */ import javax.mail.Multipart;
/*      */ 
/*      */ public class MimeBodyPart extends BodyPart
/*      */   implements MimePart
/*      */ {
/*   81 */   private static boolean setDefaultTextCharset = PropUtil.getBooleanSystemProperty("mail.mime.setdefaulttextcharset", true);
/*      */ 
/*   85 */   private static boolean setContentTypeFileName = PropUtil.getBooleanSystemProperty("mail.mime.setcontenttypefilename", true);
/*      */ 
/*   89 */   private static boolean encodeFileName = PropUtil.getBooleanSystemProperty("mail.mime.encodefilename", false);
/*      */ 
/*   91 */   private static boolean decodeFileName = PropUtil.getBooleanSystemProperty("mail.mime.decodefilename", false);
/*      */ 
/*   96 */   static boolean cacheMultipart = PropUtil.getBooleanSystemProperty("mail.mime.cachemultipart", true);
/*      */   protected DataHandler dh;
/*      */   protected byte[] content;
/*      */   protected InputStream contentStream;
/*      */   protected InternetHeaders headers;
/*      */   private Object cachedContent;
/*      */ 
/*      */   public MimeBodyPart()
/*      */   {
/*  141 */     this.headers = new InternetHeaders();
/*      */   }
/*      */ 
/*      */   public MimeBodyPart(InputStream is)
/*      */     throws MessagingException
/*      */   {
/*  160 */     if ((!(is instanceof ByteArrayInputStream)) && (!(is instanceof BufferedInputStream)) && (!(is instanceof SharedInputStream)))
/*      */     {
/*  163 */       is = new BufferedInputStream(is);
/*      */     }
/*  165 */     this.headers = new InternetHeaders(is);
/*      */ 
/*  167 */     if ((is instanceof SharedInputStream)) {
/*  168 */       SharedInputStream sis = (SharedInputStream)is;
/*  169 */       this.contentStream = sis.newStream(sis.getPosition(), -1L);
/*      */     } else {
/*      */       try {
/*  172 */         this.content = ASCIIUtility.getBytes(is);
/*      */       } catch (IOException ioex) {
/*  174 */         throw new MessagingException("Error reading input stream", ioex);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public MimeBodyPart(InternetHeaders headers, byte[] content)
/*      */     throws MessagingException
/*      */   {
/*  192 */     this.headers = headers;
/*  193 */     this.content = content;
/*      */   }
/*      */ 
/*      */   public int getSize()
/*      */     throws MessagingException
/*      */   {
/*  213 */     if (this.content != null)
/*  214 */       return this.content.length;
/*  215 */     if (this.contentStream != null)
/*      */       try {
/*  217 */         int size = this.contentStream.available();
/*      */ 
/*  220 */         if (size > 0)
/*  221 */           return size;
/*      */       }
/*      */       catch (IOException ex)
/*      */       {
/*      */       }
/*  226 */     return -1;
/*      */   }
/*      */ 
/*      */   public int getLineCount()
/*      */     throws MessagingException
/*      */   {
/*  242 */     return -1;
/*      */   }
/*      */ 
/*      */   public String getContentType()
/*      */     throws MessagingException
/*      */   {
/*  257 */     String s = getHeader("Content-Type", null);
/*  258 */     if (s == null) {
/*  259 */       s = "text/plain";
/*      */     }
/*  261 */     return s;
/*      */   }
/*      */ 
/*      */   public boolean isMimeType(String mimeType)
/*      */     throws MessagingException
/*      */   {
/*  279 */     return isMimeType(this, mimeType);
/*      */   }
/*      */ 
/*      */   public String getDisposition()
/*      */     throws MessagingException
/*      */   {
/*  296 */     return getDisposition(this);
/*      */   }
/*      */ 
/*      */   public void setDisposition(String disposition)
/*      */     throws MessagingException
/*      */   {
/*  310 */     setDisposition(this, disposition);
/*      */   }
/*      */ 
/*      */   public String getEncoding()
/*      */     throws MessagingException
/*      */   {
/*  325 */     return getEncoding(this);
/*      */   }
/*      */ 
/*      */   public String getContentID()
/*      */     throws MessagingException
/*      */   {
/*  337 */     return getHeader("Content-Id", null);
/*      */   }
/*      */ 
/*      */   public void setContentID(String cid)
/*      */     throws MessagingException
/*      */   {
/*  353 */     if (cid == null)
/*  354 */       removeHeader("Content-ID");
/*      */     else
/*  356 */       setHeader("Content-ID", cid);
/*      */   }
/*      */ 
/*      */   public String getContentMD5()
/*      */     throws MessagingException
/*      */   {
/*  368 */     return getHeader("Content-MD5", null);
/*      */   }
/*      */ 
/*      */   public void setContentMD5(String md5)
/*      */     throws MessagingException
/*      */   {
/*  380 */     setHeader("Content-MD5", md5);
/*      */   }
/*      */ 
/*      */   public String[] getContentLanguage()
/*      */     throws MessagingException
/*      */   {
/*  393 */     return getContentLanguage(this);
/*      */   }
/*      */ 
/*      */   public void setContentLanguage(String[] languages)
/*      */     throws MessagingException
/*      */   {
/*  404 */     setContentLanguage(this, languages);
/*      */   }
/*      */ 
/*      */   public String getDescription()
/*      */     throws MessagingException
/*      */   {
/*  423 */     return getDescription(this);
/*      */   }
/*      */ 
/*      */   public void setDescription(String description)
/*      */     throws MessagingException
/*      */   {
/*  452 */     setDescription(description, null);
/*      */   }
/*      */ 
/*      */   public void setDescription(String description, String charset)
/*      */     throws MessagingException
/*      */   {
/*  483 */     setDescription(this, description, charset);
/*      */   }
/*      */ 
/*      */   public String getFileName()
/*      */     throws MessagingException
/*      */   {
/*  506 */     return getFileName(this);
/*      */   }
/*      */ 
/*      */   public void setFileName(String filename)
/*      */     throws MessagingException
/*      */   {
/*  531 */     setFileName(this, filename);
/*      */   }
/*      */ 
/*      */   public InputStream getInputStream()
/*      */     throws IOException, MessagingException
/*      */   {
/*  551 */     return getDataHandler().getInputStream();
/*      */   }
/*      */ 
/*      */   protected InputStream getContentStream()
/*      */     throws MessagingException
/*      */   {
/*  564 */     if (this.contentStream != null)
/*  565 */       return ((SharedInputStream)this.contentStream).newStream(0L, -1L);
/*  566 */     if (this.content != null) {
/*  567 */       return new ByteArrayInputStream(this.content);
/*      */     }
/*  569 */     throw new MessagingException("No content");
/*      */   }
/*      */ 
/*      */   public InputStream getRawInputStream()
/*      */     throws MessagingException
/*      */   {
/*  588 */     return getContentStream();
/*      */   }
/*      */ 
/*      */   public DataHandler getDataHandler()
/*      */     throws MessagingException
/*      */   {
/*  599 */     if (this.dh == null)
/*  600 */       this.dh = new DataHandler(new MimePartDataSource(this));
/*  601 */     return this.dh;
/*      */   }
/*      */ 
/*      */   public Object getContent()
/*      */     throws IOException, MessagingException
/*      */   {
/*  626 */     if (this.cachedContent != null)
/*  627 */       return this.cachedContent;
/*      */     Object c;
/*      */     try {
/*  630 */       c = getDataHandler().getContent();
/*      */     } catch (FolderClosedIOException fex) {
/*  632 */       throw new FolderClosedException(fex.getFolder(), fex.getMessage());
/*      */     } catch (MessageRemovedIOException mex) {
/*  634 */       throw new MessageRemovedException(mex.getMessage());
/*      */     }
/*  636 */     if ((cacheMultipart) && (((c instanceof Multipart)) || ((c instanceof Message))) && ((this.content != null) || (this.contentStream != null)))
/*      */     {
/*  639 */       this.cachedContent = c;
/*      */     }
/*  641 */     return c;
/*      */   }
/*      */ 
/*      */   public void setDataHandler(DataHandler dh)
/*      */     throws MessagingException
/*      */   {
/*  656 */     this.dh = dh;
/*  657 */     this.cachedContent = null;
/*  658 */     invalidateContentHeaders(this);
/*      */   }
/*      */ 
/*      */   public void setContent(Object o, String type)
/*      */     throws MessagingException
/*      */   {
/*  681 */     if ((o instanceof Multipart))
/*  682 */       setContent((Multipart)o);
/*      */     else
/*  684 */       setDataHandler(new DataHandler(o, type));
/*      */   }
/*      */ 
/*      */   public void setText(String text)
/*      */     throws MessagingException
/*      */   {
/*  708 */     setText(text, null);
/*      */   }
/*      */ 
/*      */   public void setText(String text, String charset)
/*      */     throws MessagingException
/*      */   {
/*  724 */     setText(this, text, charset, "plain");
/*      */   }
/*      */ 
/*      */   public void setText(String text, String charset, String subtype)
/*      */     throws MessagingException
/*      */   {
/*  742 */     setText(this, text, charset, subtype);
/*      */   }
/*      */ 
/*      */   public void setContent(Multipart mp)
/*      */     throws MessagingException
/*      */   {
/*  756 */     setDataHandler(new DataHandler(mp, mp.getContentType()));
/*  757 */     mp.setParent(this);
/*      */   }
/*      */ 
/*      */   public void attachFile(File file)
/*      */     throws IOException, MessagingException
/*      */   {
/*  773 */     FileDataSource fds = new FileDataSource(file);
/*  774 */     setDataHandler(new DataHandler(fds));
/*  775 */     setFileName(fds.getName());
/*      */   }
/*      */ 
/*      */   public void attachFile(String file)
/*      */     throws IOException, MessagingException
/*      */   {
/*  791 */     File f = new File(file);
/*  792 */     attachFile(f);
/*      */   }
/*      */ 
/*      */   public void saveFile(File file)
/*      */     throws IOException, MessagingException
/*      */   {
/*  805 */     OutputStream out = null;
/*  806 */     InputStream in = null;
/*      */     try {
/*  808 */       out = new BufferedOutputStream(new FileOutputStream(file));
/*  809 */       in = getInputStream();
/*  810 */       byte[] buf = new byte[8192];
/*      */       int len;
/*  812 */       while ((len = in.read(buf)) > 0)
/*  813 */         out.write(buf, 0, len);
/*      */     }
/*      */     finally {
/*      */       try {
/*  817 */         if (in != null)
/*  818 */           in.close(); 
/*      */       } catch (IOException ex) {
/*      */       }
/*      */       try { if (out != null)
/*  822 */           out.close();
/*      */       }
/*      */       catch (IOException ex)
/*      */       {
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void saveFile(String file)
/*      */     throws IOException, MessagingException
/*      */   {
/*  837 */     File f = new File(file);
/*  838 */     saveFile(f);
/*      */   }
/*      */ 
/*      */   public void writeTo(OutputStream os)
/*      */     throws IOException, MessagingException
/*      */   {
/*  852 */     writeTo(this, os, null);
/*      */   }
/*      */ 
/*      */   public String[] getHeader(String name)
/*      */     throws MessagingException
/*      */   {
/*  865 */     return this.headers.getHeader(name);
/*      */   }
/*      */ 
/*      */   public String getHeader(String name, String delimiter)
/*      */     throws MessagingException
/*      */   {
/*  882 */     return this.headers.getHeader(name, delimiter);
/*      */   }
/*      */ 
/*      */   public void setHeader(String name, String value)
/*      */     throws MessagingException
/*      */   {
/*  898 */     this.headers.setHeader(name, value);
/*      */   }
/*      */ 
/*      */   public void addHeader(String name, String value)
/*      */     throws MessagingException
/*      */   {
/*  913 */     this.headers.addHeader(name, value);
/*      */   }
/*      */ 
/*      */   public void removeHeader(String name)
/*      */     throws MessagingException
/*      */   {
/*  920 */     this.headers.removeHeader(name);
/*      */   }
/*      */ 
/*      */   public Enumeration getAllHeaders()
/*      */     throws MessagingException
/*      */   {
/*  928 */     return this.headers.getAllHeaders();
/*      */   }
/*      */ 
/*      */   public Enumeration getMatchingHeaders(String[] names)
/*      */     throws MessagingException
/*      */   {
/*  937 */     return this.headers.getMatchingHeaders(names);
/*      */   }
/*      */ 
/*      */   public Enumeration getNonMatchingHeaders(String[] names)
/*      */     throws MessagingException
/*      */   {
/*  946 */     return this.headers.getNonMatchingHeaders(names);
/*      */   }
/*      */ 
/*      */   public void addHeaderLine(String line)
/*      */     throws MessagingException
/*      */   {
/*  953 */     this.headers.addHeaderLine(line);
/*      */   }
/*      */ 
/*      */   public Enumeration getAllHeaderLines()
/*      */     throws MessagingException
/*      */   {
/*  962 */     return this.headers.getAllHeaderLines();
/*      */   }
/*      */ 
/*      */   public Enumeration getMatchingHeaderLines(String[] names)
/*      */     throws MessagingException
/*      */   {
/*  972 */     return this.headers.getMatchingHeaderLines(names);
/*      */   }
/*      */ 
/*      */   public Enumeration getNonMatchingHeaderLines(String[] names)
/*      */     throws MessagingException
/*      */   {
/*  982 */     return this.headers.getNonMatchingHeaderLines(names);
/*      */   }
/*      */ 
/*      */   protected void updateHeaders()
/*      */     throws MessagingException
/*      */   {
/* 1008 */     updateHeaders(this);
/*      */ 
/* 1015 */     if (this.cachedContent != null) {
/* 1016 */       this.dh = new DataHandler(this.cachedContent, getContentType());
/* 1017 */       this.cachedContent = null;
/* 1018 */       this.content = null;
/* 1019 */       if (this.contentStream != null)
/*      */         try {
/* 1021 */           this.contentStream.close();
/*      */         } catch (IOException ioex) {
/*      */         }
/* 1024 */       this.contentStream = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   static boolean isMimeType(MimePart part, String mimeType)
/*      */     throws MessagingException
/*      */   {
/*      */     try
/*      */     {
/* 1037 */       ContentType ct = new ContentType(part.getContentType());
/* 1038 */       return ct.match(mimeType); } catch (ParseException ex) {
/*      */     }
/* 1040 */     return part.getContentType().equalsIgnoreCase(mimeType);
/*      */   }
/*      */ 
/*      */   static void setText(MimePart part, String text, String charset, String subtype)
/*      */     throws MessagingException
/*      */   {
/* 1046 */     if (charset == null) {
/* 1047 */       if (MimeUtility.checkAscii(text) != 1)
/* 1048 */         charset = MimeUtility.getDefaultMIMECharset();
/*      */       else {
/* 1050 */         charset = "us-ascii";
/*      */       }
/*      */     }
/* 1053 */     part.setContent(text, "text/" + subtype + "; charset=" + MimeUtility.quote(charset, "()<>@,;:\\\"\t []/?="));
/*      */   }
/*      */ 
/*      */   static String getDisposition(MimePart part) throws MessagingException
/*      */   {
/* 1058 */     String s = part.getHeader("Content-Disposition", null);
/*      */ 
/* 1060 */     if (s == null) {
/* 1061 */       return null;
/*      */     }
/* 1063 */     ContentDisposition cd = new ContentDisposition(s);
/* 1064 */     return cd.getDisposition();
/*      */   }
/*      */ 
/*      */   static void setDisposition(MimePart part, String disposition) throws MessagingException
/*      */   {
/* 1069 */     if (disposition == null) {
/* 1070 */       part.removeHeader("Content-Disposition");
/*      */     } else {
/* 1072 */       String s = part.getHeader("Content-Disposition", null);
/* 1073 */       if (s != null)
/*      */       {
/* 1079 */         ContentDisposition cd = new ContentDisposition(s);
/* 1080 */         cd.setDisposition(disposition);
/* 1081 */         disposition = cd.toString();
/*      */       }
/* 1083 */       part.setHeader("Content-Disposition", disposition);
/*      */     }
/*      */   }
/*      */ 
/*      */   static String getDescription(MimePart part) throws MessagingException
/*      */   {
/* 1089 */     String rawvalue = part.getHeader("Content-Description", null);
/*      */ 
/* 1091 */     if (rawvalue == null)
/* 1092 */       return null;
/*      */     try
/*      */     {
/* 1095 */       return MimeUtility.decodeText(MimeUtility.unfold(rawvalue)); } catch (UnsupportedEncodingException ex) {
/*      */     }
/* 1097 */     return rawvalue;
/*      */   }
/*      */ 
/*      */   static void setDescription(MimePart part, String description, String charset)
/*      */     throws MessagingException
/*      */   {
/* 1104 */     if (description == null) {
/* 1105 */       part.removeHeader("Content-Description");
/* 1106 */       return;
/*      */     }
/*      */     try
/*      */     {
/* 1110 */       part.setHeader("Content-Description", MimeUtility.fold(21, MimeUtility.encodeText(description, charset, null)));
/*      */     }
/*      */     catch (UnsupportedEncodingException uex) {
/* 1113 */       throw new MessagingException("Encoding error", uex);
/*      */     }
/*      */   }
/*      */ 
/*      */   static String getFileName(MimePart part) throws MessagingException {
/* 1118 */     String filename = null;
/* 1119 */     String s = part.getHeader("Content-Disposition", null);
/*      */ 
/* 1121 */     if (s != null)
/*      */     {
/* 1123 */       ContentDisposition cd = new ContentDisposition(s);
/* 1124 */       filename = cd.getParameter("filename");
/*      */     }
/* 1126 */     if (filename == null)
/*      */     {
/* 1128 */       s = part.getHeader("Content-Type", null);
/* 1129 */       if (s != null)
/*      */         try {
/* 1131 */           ContentType ct = new ContentType(s);
/* 1132 */           filename = ct.getParameter("name");
/*      */         } catch (ParseException pex) {
/*      */         }
/*      */     }
/* 1136 */     if ((decodeFileName) && (filename != null)) {
/*      */       try {
/* 1138 */         filename = MimeUtility.decodeText(filename);
/*      */       } catch (UnsupportedEncodingException ex) {
/* 1140 */         throw new MessagingException("Can't decode filename", ex);
/*      */       }
/*      */     }
/* 1143 */     return filename;
/*      */   }
/*      */ 
/*      */   static void setFileName(MimePart part, String name) throws MessagingException
/*      */   {
/* 1148 */     if ((encodeFileName) && (name != null)) {
/*      */       try {
/* 1150 */         name = MimeUtility.encodeText(name);
/*      */       } catch (UnsupportedEncodingException ex) {
/* 1152 */         throw new MessagingException("Can't encode filename", ex);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1157 */     String s = part.getHeader("Content-Disposition", null);
/* 1158 */     ContentDisposition cd = new ContentDisposition(s == null ? "attachment" : s);
/*      */ 
/* 1160 */     cd.setParameter("filename", name);
/* 1161 */     part.setHeader("Content-Disposition", cd.toString());
/*      */ 
/* 1167 */     if (setContentTypeFileName) {
/* 1168 */       s = part.getHeader("Content-Type", null);
/* 1169 */       if (s != null)
/*      */         try {
/* 1171 */           ContentType cType = new ContentType(s);
/* 1172 */           cType.setParameter("name", name);
/* 1173 */           part.setHeader("Content-Type", cType.toString());
/*      */         }
/*      */         catch (ParseException pex) {
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   static String[] getContentLanguage(MimePart part) throws MessagingException {
/* 1181 */     String s = part.getHeader("Content-Language", null);
/*      */ 
/* 1183 */     if (s == null) {
/* 1184 */       return null;
/*      */     }
/*      */ 
/* 1187 */     HeaderTokenizer h = new HeaderTokenizer(s, "()<>@,;:\\\"\t []/?=");
/* 1188 */     Vector v = new Vector();
/*      */     while (true)
/*      */     {
/* 1194 */       HeaderTokenizer.Token tk = h.next();
/* 1195 */       int tkType = tk.getType();
/* 1196 */       if (tkType == -4)
/*      */         break;
/* 1198 */       if (tkType == -1) {
/* 1199 */         v.addElement(tk.getValue());
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1204 */     if (v.size() == 0) {
/* 1205 */       return null;
/*      */     }
/* 1207 */     String[] language = new String[v.size()];
/* 1208 */     v.copyInto(language);
/* 1209 */     return language;
/*      */   }
/*      */ 
/*      */   static void setContentLanguage(MimePart part, String[] languages) throws MessagingException
/*      */   {
/* 1214 */     StringBuffer sb = new StringBuffer(languages[0]);
/* 1215 */     for (int i = 1; i < languages.length; i++)
/* 1216 */       sb.append(',').append(languages[i]);
/* 1217 */     part.setHeader("Content-Language", sb.toString());
/*      */   }
/*      */ 
/*      */   static String getEncoding(MimePart part) throws MessagingException {
/* 1221 */     String s = part.getHeader("Content-Transfer-Encoding", null);
/*      */ 
/* 1223 */     if (s == null) {
/* 1224 */       return null;
/*      */     }
/* 1226 */     s = s.trim();
/*      */ 
/* 1229 */     if ((s.equalsIgnoreCase("7bit")) || (s.equalsIgnoreCase("8bit")) || (s.equalsIgnoreCase("quoted-printable")) || (s.equalsIgnoreCase("binary")) || (s.equalsIgnoreCase("base64")))
/*      */     {
/* 1233 */       return s;
/*      */     }
/*      */ 
/* 1236 */     HeaderTokenizer h = new HeaderTokenizer(s, "()<>@,;:\\\"\t []/?=");
/*      */     HeaderTokenizer.Token tk;
/*      */     int tkType;
/*      */     do {
/* 1242 */       tk = h.next();
/* 1243 */       tkType = tk.getType();
/* 1244 */       if (tkType == -4) break;
/*      */     }
/* 1246 */     while (tkType != -1);
/* 1247 */     return tk.getValue();
/*      */ 
/* 1251 */     return s;
/*      */   }
/*      */ 
/*      */   static void setEncoding(MimePart part, String encoding) throws MessagingException
/*      */   {
/* 1256 */     part.setHeader("Content-Transfer-Encoding", encoding);
/*      */   }
/*      */ 
/*      */   static void updateHeaders(MimePart part) throws MessagingException {
/* 1260 */     DataHandler dh = part.getDataHandler();
/* 1261 */     if (dh == null)
/* 1262 */       return;
/*      */     try
/*      */     {
/* 1265 */       String type = dh.getContentType();
/* 1266 */       boolean composite = false;
/* 1267 */       boolean needCTHeader = part.getHeader("Content-Type") == null;
/*      */ 
/* 1269 */       ContentType cType = new ContentType(type);
/* 1270 */       if (cType.match("multipart/*"))
/*      */       {
/* 1272 */         composite = true;
/*      */         Object o;
/*      */         Object o;
/* 1274 */         if ((part instanceof MimeBodyPart)) {
/* 1275 */           MimeBodyPart mbp = (MimeBodyPart)part;
/* 1276 */           o = mbp.cachedContent != null ? mbp.cachedContent : dh.getContent();
/*      */         }
/*      */         else
/*      */         {
/*      */           Object o;
/* 1278 */           if ((part instanceof MimeMessage)) {
/* 1279 */             MimeMessage msg = (MimeMessage)part;
/* 1280 */             o = msg.cachedContent != null ? msg.cachedContent : dh.getContent();
/*      */           }
/*      */           else {
/* 1283 */             o = dh.getContent(); } 
/* 1284 */         }if ((o instanceof MimeMultipart))
/* 1285 */           ((MimeMultipart)o).updateHeaders();
/*      */         else {
/* 1287 */           throw new MessagingException("MIME part of type \"" + type + "\" contains object of type " + o.getClass().getName() + " instead of MimeMultipart");
/*      */         }
/*      */       }
/* 1290 */       else if (cType.match("message/rfc822")) {
/* 1291 */         composite = true;
/*      */       }
/*      */ 
/* 1297 */       if (!composite) {
/* 1298 */         if (part.getHeader("Content-Transfer-Encoding") == null) {
/* 1299 */           setEncoding(part, MimeUtility.getEncoding(dh));
/*      */         }
/* 1301 */         if ((needCTHeader) && (setDefaultTextCharset) && (cType.match("text/*")) && (cType.getParameter("charset") == null))
/*      */         {
/* 1315 */           String enc = part.getEncoding();
/*      */           String charset;
/*      */           String charset;
/* 1316 */           if ((enc != null) && (enc.equalsIgnoreCase("7bit")))
/* 1317 */             charset = "us-ascii";
/*      */           else
/* 1319 */             charset = MimeUtility.getDefaultMIMECharset();
/* 1320 */           cType.setParameter("charset", charset);
/* 1321 */           type = cType.toString();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1328 */       if (needCTHeader)
/*      */       {
/* 1335 */         String s = part.getHeader("Content-Disposition", null);
/* 1336 */         if (s != null)
/*      */         {
/* 1338 */           ContentDisposition cd = new ContentDisposition(s);
/* 1339 */           String filename = cd.getParameter("filename");
/* 1340 */           if (filename != null) {
/* 1341 */             cType.setParameter("name", filename);
/* 1342 */             type = cType.toString();
/*      */           }
/*      */         }
/*      */ 
/* 1346 */         part.setHeader("Content-Type", type);
/*      */       }
/*      */     } catch (IOException ex) {
/* 1349 */       throw new MessagingException("IOException updating headers", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   static void invalidateContentHeaders(MimePart part) throws MessagingException
/*      */   {
/* 1355 */     part.removeHeader("Content-Type");
/* 1356 */     part.removeHeader("Content-Transfer-Encoding");
/*      */   }
/*      */ 
/*      */   static void writeTo(MimePart part, OutputStream os, String[] ignoreList)
/*      */     throws IOException, MessagingException
/*      */   {
/* 1363 */     LineOutputStream los = null;
/* 1364 */     if ((os instanceof LineOutputStream))
/* 1365 */       los = (LineOutputStream)os;
/*      */     else {
/* 1367 */       los = new LineOutputStream(os);
/*      */     }
/*      */ 
/* 1371 */     Enumeration hdrLines = part.getNonMatchingHeaderLines(ignoreList);
/* 1372 */     while (hdrLines.hasMoreElements()) {
/* 1373 */       los.writeln((String)hdrLines.nextElement());
/*      */     }
/*      */ 
/* 1376 */     los.writeln();
/*      */ 
/* 1380 */     os = MimeUtility.encode(os, part.getEncoding());
/* 1381 */     part.getDataHandler().writeTo(os);
/* 1382 */     os.flush();
/*      */   }
/*      */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.internet.MimeBodyPart
 * JD-Core Version:    0.6.1
 */