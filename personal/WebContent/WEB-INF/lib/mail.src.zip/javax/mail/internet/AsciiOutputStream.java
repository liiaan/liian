/*      */ package javax.mail.internet;
/*      */ 
/*      */ import java.io.EOFException;
/*      */ import java.io.IOException;
/*      */ import java.io.OutputStream;
/*      */ 
/*      */ class AsciiOutputStream extends OutputStream
/*      */ {
/*      */   private boolean breakOnNonAscii;
/* 1518 */   private int ascii = 0; private int non_ascii = 0;
/* 1519 */   private int linelen = 0;
/* 1520 */   private boolean longLine = false;
/* 1521 */   private boolean badEOL = false;
/* 1522 */   private boolean checkEOL = false;
/* 1523 */   private int lastb = 0;
/* 1524 */   private int ret = 0;
/*      */ 
/*      */   public AsciiOutputStream(boolean breakOnNonAscii, boolean encodeEolStrict) {
/* 1527 */     this.breakOnNonAscii = breakOnNonAscii;
/* 1528 */     this.checkEOL = ((encodeEolStrict) && (breakOnNonAscii));
/*      */   }
/*      */ 
/*      */   public void write(int b) throws IOException {
/* 1532 */     check(b);
/*      */   }
/*      */ 
/*      */   public void write(byte[] b) throws IOException {
/* 1536 */     write(b, 0, b.length);
/*      */   }
/*      */ 
/*      */   public void write(byte[] b, int off, int len) throws IOException {
/* 1540 */     len += off;
/* 1541 */     for (int i = off; i < len; i++)
/* 1542 */       check(b[i]);
/*      */   }
/*      */ 
/*      */   private final void check(int b) throws IOException {
/* 1546 */     b &= 255;
/* 1547 */     if ((this.checkEOL) && (((this.lastb == 13) && (b != 10)) || ((this.lastb != 13) && (b == 10))))
/*      */     {
/* 1549 */       this.badEOL = true;
/* 1550 */     }if ((b == 13) || (b == 10)) {
/* 1551 */       this.linelen = 0;
/*      */     } else {
/* 1553 */       this.linelen += 1;
/* 1554 */       if (this.linelen > 998)
/* 1555 */         this.longLine = true;
/*      */     }
/* 1557 */     if (MimeUtility.nonascii(b)) {
/* 1558 */       this.non_ascii += 1;
/* 1559 */       if (this.breakOnNonAscii) {
/* 1560 */         this.ret = 3;
/* 1561 */         throw new EOFException();
/*      */       }
/*      */     } else {
/* 1564 */       this.ascii += 1;
/* 1565 */     }this.lastb = b;
/*      */   }
/*      */ 
/*      */   public int getAscii()
/*      */   {
/* 1572 */     if (this.ret != 0) {
/* 1573 */       return this.ret;
/*      */     }
/*      */ 
/* 1578 */     if (this.badEOL)
/* 1579 */       return 3;
/* 1580 */     if (this.non_ascii == 0)
/*      */     {
/* 1582 */       if (this.longLine) {
/* 1583 */         return 2;
/*      */       }
/* 1585 */       return 1;
/*      */     }
/* 1587 */     if (this.ascii > this.non_ascii)
/* 1588 */       return 2;
/* 1589 */     return 3;
/*      */   }
/*      */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.internet.AsciiOutputStream
 * JD-Core Version:    0.6.1
 */