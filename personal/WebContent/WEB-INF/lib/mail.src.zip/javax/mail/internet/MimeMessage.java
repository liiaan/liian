/*      */ package javax.mail.internet;
/*      */ 
/*      */ import com.sun.mail.util.ASCIIUtility;
/*      */ import com.sun.mail.util.FolderClosedIOException;
/*      */ import com.sun.mail.util.LineOutputStream;
/*      */ import com.sun.mail.util.MessageRemovedIOException;
/*      */ import com.sun.mail.util.PropUtil;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectStreamException;
/*      */ import java.io.OutputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.text.ParseException;
/*      */ import java.util.Date;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Vector;
/*      */ import javax.activation.DataHandler;
/*      */ import javax.mail.Address;
/*      */ import javax.mail.Flags;
/*      */ import javax.mail.Flags.Flag;
/*      */ import javax.mail.Folder;
/*      */ import javax.mail.FolderClosedException;
/*      */ import javax.mail.Message;
/*      */ import javax.mail.Message.RecipientType;
/*      */ import javax.mail.MessageRemovedException;
/*      */ import javax.mail.MessagingException;
/*      */ import javax.mail.Multipart;
/*      */ import javax.mail.Session;
/*      */ import javax.mail.util.SharedByteArrayInputStream;
/*      */ 
/*      */ public class MimeMessage extends Message
/*      */   implements MimePart
/*      */ {
/*      */   protected DataHandler dh;
/*      */   protected byte[] content;
/*      */   protected InputStream contentStream;
/*      */   protected InternetHeaders headers;
/*      */   protected Flags flags;
/*  143 */   protected boolean modified = false;
/*      */ 
/*  156 */   protected boolean saved = false;
/*      */   Object cachedContent;
/*  168 */   private static MailDateFormat mailDateFormat = new MailDateFormat();
/*      */ 
/*  171 */   private boolean strict = true;
/*      */ 
/* 1653 */   private static final Flags answeredFlag = new Flags(Flags.Flag.ANSWERED);
/*      */ 
/*      */   public MimeMessage(Session session)
/*      */   {
/*  180 */     super(session);
/*  181 */     this.modified = true;
/*  182 */     this.headers = new InternetHeaders();
/*  183 */     this.flags = new Flags();
/*  184 */     initStrict();
/*      */   }
/*      */ 
/*      */   public MimeMessage(Session session, InputStream is)
/*      */     throws MessagingException
/*      */   {
/*  202 */     super(session);
/*  203 */     this.flags = new Flags();
/*  204 */     initStrict();
/*  205 */     parse(is);
/*  206 */     this.saved = true;
/*      */   }
/*      */ 
/*      */   public MimeMessage(MimeMessage source)
/*      */     throws MessagingException
/*      */   {
/*  222 */     super(source.session);
/*  223 */     this.flags = source.getFlags();
/*  224 */     if (this.flags == null) {
/*  225 */       this.flags = new Flags();
/*      */     }
/*  227 */     int size = source.getSize();
/*      */     ByteArrayOutputStream bos;
/*      */     ByteArrayOutputStream bos;
/*  228 */     if (size > 0)
/*  229 */       bos = new ByteArrayOutputStream(size);
/*      */     else
/*  231 */       bos = new ByteArrayOutputStream();
/*      */     try {
/*  233 */       this.strict = source.strict;
/*  234 */       source.writeTo(bos);
/*  235 */       bos.close();
/*  236 */       SharedByteArrayInputStream bis = new SharedByteArrayInputStream(bos.toByteArray());
/*      */ 
/*  238 */       parse(bis);
/*  239 */       bis.close();
/*  240 */       this.saved = true;
/*      */     }
/*      */     catch (IOException ex) {
/*  243 */       throw new MessagingException("IOException while copying message", ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected MimeMessage(Folder folder, int msgnum)
/*      */   {
/*  255 */     super(folder, msgnum);
/*  256 */     this.flags = new Flags();
/*  257 */     this.saved = true;
/*  258 */     initStrict();
/*      */   }
/*      */ 
/*      */   protected MimeMessage(Folder folder, InputStream is, int msgnum)
/*      */     throws MessagingException
/*      */   {
/*  276 */     this(folder, msgnum);
/*  277 */     initStrict();
/*  278 */     parse(is);
/*      */   }
/*      */ 
/*      */   protected MimeMessage(Folder folder, InternetHeaders headers, byte[] content, int msgnum)
/*      */     throws MessagingException
/*      */   {
/*  295 */     this(folder, msgnum);
/*  296 */     this.headers = headers;
/*  297 */     this.content = content;
/*  298 */     initStrict();
/*      */   }
/*      */ 
/*      */   private void initStrict()
/*      */   {
/*  305 */     if (this.session != null)
/*  306 */       this.strict = PropUtil.getBooleanSessionProperty(this.session, "mail.mime.address.strict", true);
/*      */   }
/*      */ 
/*      */   protected void parse(InputStream is)
/*      */     throws MessagingException
/*      */   {
/*  323 */     if ((!(is instanceof ByteArrayInputStream)) && (!(is instanceof BufferedInputStream)) && (!(is instanceof SharedInputStream)))
/*      */     {
/*  326 */       is = new BufferedInputStream(is);
/*      */     }
/*  328 */     this.headers = createInternetHeaders(is);
/*      */ 
/*  330 */     if ((is instanceof SharedInputStream)) {
/*  331 */       SharedInputStream sis = (SharedInputStream)is;
/*  332 */       this.contentStream = sis.newStream(sis.getPosition(), -1L);
/*      */     } else {
/*      */       try {
/*  335 */         this.content = ASCIIUtility.getBytes(is);
/*      */       } catch (IOException ioex) {
/*  337 */         throw new MessagingException("IOException", ioex);
/*      */       }
/*      */     }
/*      */ 
/*  341 */     this.modified = false;
/*      */   }
/*      */ 
/*      */   public Address[] getFrom()
/*      */     throws MessagingException
/*      */   {
/*  358 */     Address[] a = getAddressHeader("From");
/*  359 */     if (a == null) {
/*  360 */       a = getAddressHeader("Sender");
/*      */     }
/*  362 */     return a;
/*      */   }
/*      */ 
/*      */   public void setFrom(Address address)
/*      */     throws MessagingException
/*      */   {
/*  379 */     if (address == null)
/*  380 */       removeHeader("From");
/*      */     else
/*  382 */       setHeader("From", address.toString());
/*      */   }
/*      */ 
/*      */   public void setFrom()
/*      */     throws MessagingException
/*      */   {
/*  397 */     InternetAddress me = InternetAddress.getLocalAddress(this.session);
/*  398 */     if (me != null)
/*  399 */       setFrom(me);
/*      */     else
/*  401 */       throw new MessagingException("No From address");
/*      */   }
/*      */ 
/*      */   public void addFrom(Address[] addresses)
/*      */     throws MessagingException
/*      */   {
/*  417 */     addAddressHeader("From", addresses);
/*      */   }
/*      */ 
/*      */   public Address getSender()
/*      */     throws MessagingException
/*      */   {
/*  434 */     Address[] a = getAddressHeader("Sender");
/*  435 */     if ((a == null) || (a.length == 0))
/*  436 */       return null;
/*  437 */     return a[0];
/*      */   }
/*      */ 
/*      */   public void setSender(Address address)
/*      */     throws MessagingException
/*      */   {
/*  455 */     if (address == null)
/*  456 */       removeHeader("Sender");
/*      */     else
/*  458 */       setHeader("Sender", address.toString());
/*      */   }
/*      */ 
/*      */   public Address[] getRecipients(Message.RecipientType type)
/*      */     throws MessagingException
/*      */   {
/*  519 */     if (type == RecipientType.NEWSGROUPS) {
/*  520 */       String s = getHeader("Newsgroups", ",");
/*  521 */       return s == null ? null : NewsAddress.parse(s);
/*      */     }
/*  523 */     return getAddressHeader(getHeaderName(type));
/*      */   }
/*      */ 
/*      */   public Address[] getAllRecipients()
/*      */     throws MessagingException
/*      */   {
/*  538 */     Address[] all = super.getAllRecipients();
/*  539 */     Address[] ng = getRecipients(RecipientType.NEWSGROUPS);
/*      */ 
/*  541 */     if (ng == null)
/*  542 */       return all;
/*  543 */     if (all == null) {
/*  544 */       return ng;
/*      */     }
/*  546 */     Address[] addresses = new Address[all.length + ng.length];
/*  547 */     System.arraycopy(all, 0, addresses, 0, all.length);
/*  548 */     System.arraycopy(ng, 0, addresses, all.length, ng.length);
/*  549 */     return addresses;
/*      */   }
/*      */ 
/*      */   public void setRecipients(Message.RecipientType type, Address[] addresses)
/*      */     throws MessagingException
/*      */   {
/*  569 */     if (type == RecipientType.NEWSGROUPS) {
/*  570 */       if ((addresses == null) || (addresses.length == 0))
/*  571 */         removeHeader("Newsgroups");
/*      */       else
/*  573 */         setHeader("Newsgroups", NewsAddress.toString(addresses));
/*      */     }
/*  575 */     else setAddressHeader(getHeaderName(type), addresses);
/*      */   }
/*      */ 
/*      */   public void setRecipients(Message.RecipientType type, String addresses)
/*      */     throws MessagingException
/*      */   {
/*  598 */     if (type == RecipientType.NEWSGROUPS) {
/*  599 */       if ((addresses == null) || (addresses.length() == 0))
/*  600 */         removeHeader("Newsgroups");
/*      */       else
/*  602 */         setHeader("Newsgroups", addresses);
/*      */     }
/*  604 */     else setAddressHeader(getHeaderName(type), InternetAddress.parse(addresses));
/*      */   }
/*      */ 
/*      */   public void addRecipients(Message.RecipientType type, Address[] addresses)
/*      */     throws MessagingException
/*      */   {
/*  621 */     if (type == RecipientType.NEWSGROUPS) {
/*  622 */       String s = NewsAddress.toString(addresses);
/*  623 */       if (s != null)
/*  624 */         addHeader("Newsgroups", s);
/*      */     } else {
/*  626 */       addAddressHeader(getHeaderName(type), addresses);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void addRecipients(Message.RecipientType type, String addresses)
/*      */     throws MessagingException
/*      */   {
/*  646 */     if (type == RecipientType.NEWSGROUPS) {
/*  647 */       if ((addresses != null) && (addresses.length() != 0))
/*  648 */         addHeader("Newsgroups", addresses);
/*      */     }
/*  650 */     else addAddressHeader(getHeaderName(type), InternetAddress.parse(addresses));
/*      */   }
/*      */ 
/*      */   public Address[] getReplyTo()
/*      */     throws MessagingException
/*      */   {
/*  665 */     Address[] a = getAddressHeader("Reply-To");
/*  666 */     if ((a == null) || (a.length == 0))
/*  667 */       a = getFrom();
/*  668 */     return a;
/*      */   }
/*      */ 
/*      */   public void setReplyTo(Address[] addresses)
/*      */     throws MessagingException
/*      */   {
/*  683 */     setAddressHeader("Reply-To", addresses);
/*      */   }
/*      */ 
/*      */   private Address[] getAddressHeader(String name)
/*      */     throws MessagingException
/*      */   {
/*  689 */     String s = getHeader(name, ",");
/*  690 */     return s == null ? null : InternetAddress.parseHeader(s, this.strict);
/*      */   }
/*      */ 
/*      */   private void setAddressHeader(String name, Address[] addresses)
/*      */     throws MessagingException
/*      */   {
/*  696 */     String s = InternetAddress.toString(addresses);
/*  697 */     if (s == null)
/*  698 */       removeHeader(name);
/*      */     else
/*  700 */       setHeader(name, s);
/*      */   }
/*      */ 
/*      */   private void addAddressHeader(String name, Address[] addresses) throws MessagingException
/*      */   {
/*  705 */     String s = InternetAddress.toString(addresses);
/*  706 */     if (s == null)
/*  707 */       return;
/*  708 */     addHeader(name, s);
/*      */   }
/*      */ 
/*      */   public String getSubject()
/*      */     throws MessagingException
/*      */   {
/*  727 */     String rawvalue = getHeader("Subject", null);
/*      */ 
/*  729 */     if (rawvalue == null)
/*  730 */       return null;
/*      */     try
/*      */     {
/*  733 */       return MimeUtility.decodeText(MimeUtility.unfold(rawvalue)); } catch (UnsupportedEncodingException ex) {
/*      */     }
/*  735 */     return rawvalue;
/*      */   }
/*      */ 
/*      */   public void setSubject(String subject)
/*      */     throws MessagingException
/*      */   {
/*  767 */     setSubject(subject, null);
/*      */   }
/*      */ 
/*      */   public void setSubject(String subject, String charset)
/*      */     throws MessagingException
/*      */   {
/*  799 */     if (subject == null)
/*  800 */       removeHeader("Subject");
/*      */     else
/*      */       try {
/*  803 */         setHeader("Subject", MimeUtility.fold(9, MimeUtility.encodeText(subject, charset, null)));
/*      */       }
/*      */       catch (UnsupportedEncodingException uex) {
/*  806 */         throw new MessagingException("Encoding error", uex);
/*      */       }
/*      */   }
/*      */ 
/*      */   public Date getSentDate()
/*      */     throws MessagingException
/*      */   {
/*  823 */     String s = getHeader("Date", null);
/*  824 */     if (s != null) {
/*      */       try {
/*  826 */         synchronized (mailDateFormat) {
/*  827 */           return mailDateFormat.parse(s);
/*      */         }
/*      */       } catch (ParseException pex) {
/*  830 */         return null;
/*      */       }
/*      */     }
/*      */ 
/*  834 */     return null;
/*      */   }
/*      */ 
/*      */   public void setSentDate(Date d)
/*      */     throws MessagingException
/*      */   {
/*  850 */     if (d == null)
/*  851 */       removeHeader("Date");
/*      */     else
/*  853 */       synchronized (mailDateFormat) {
/*  854 */         setHeader("Date", mailDateFormat.format(d));
/*      */       }
/*      */   }
/*      */ 
/*      */   public Date getReceivedDate()
/*      */     throws MessagingException
/*      */   {
/*  873 */     return null;
/*      */   }
/*      */ 
/*      */   public int getSize()
/*      */     throws MessagingException
/*      */   {
/*  894 */     if (this.content != null)
/*  895 */       return this.content.length;
/*  896 */     if (this.contentStream != null)
/*      */       try {
/*  898 */         int size = this.contentStream.available();
/*      */ 
/*  901 */         if (size > 0)
/*  902 */           return size;
/*      */       }
/*      */       catch (IOException ex)
/*      */       {
/*      */       }
/*  907 */     return -1;
/*      */   }
/*      */ 
/*      */   public int getLineCount()
/*      */     throws MessagingException
/*      */   {
/*  924 */     return -1;
/*      */   }
/*      */ 
/*      */   public String getContentType()
/*      */     throws MessagingException
/*      */   {
/*  941 */     String s = getHeader("Content-Type", null);
/*  942 */     if (s == null)
/*  943 */       return "text/plain";
/*  944 */     return s;
/*      */   }
/*      */ 
/*      */   public boolean isMimeType(String mimeType)
/*      */     throws MessagingException
/*      */   {
/*  962 */     return MimeBodyPart.isMimeType(this, mimeType);
/*      */   }
/*      */ 
/*      */   public String getDisposition()
/*      */     throws MessagingException
/*      */   {
/*  980 */     return MimeBodyPart.getDisposition(this);
/*      */   }
/*      */ 
/*      */   public void setDisposition(String disposition)
/*      */     throws MessagingException
/*      */   {
/*  995 */     MimeBodyPart.setDisposition(this, disposition);
/*      */   }
/*      */ 
/*      */   public String getEncoding()
/*      */     throws MessagingException
/*      */   {
/* 1011 */     return MimeBodyPart.getEncoding(this);
/*      */   }
/*      */ 
/*      */   public String getContentID()
/*      */     throws MessagingException
/*      */   {
/* 1026 */     return getHeader("Content-Id", null);
/*      */   }
/*      */ 
/*      */   public void setContentID(String cid)
/*      */     throws MessagingException
/*      */   {
/* 1041 */     if (cid == null)
/* 1042 */       removeHeader("Content-ID");
/*      */     else
/* 1044 */       setHeader("Content-ID", cid);
/*      */   }
/*      */ 
/*      */   public String getContentMD5()
/*      */     throws MessagingException
/*      */   {
/* 1059 */     return getHeader("Content-MD5", null);
/*      */   }
/*      */ 
/*      */   public void setContentMD5(String md5)
/*      */     throws MessagingException
/*      */   {
/* 1072 */     setHeader("Content-MD5", md5);
/*      */   }
/*      */ 
/*      */   public String getDescription()
/*      */     throws MessagingException
/*      */   {
/* 1092 */     return MimeBodyPart.getDescription(this);
/*      */   }
/*      */ 
/*      */   public void setDescription(String description)
/*      */     throws MessagingException
/*      */   {
/* 1121 */     setDescription(description, null);
/*      */   }
/*      */ 
/*      */   public void setDescription(String description, String charset)
/*      */     throws MessagingException
/*      */   {
/* 1152 */     MimeBodyPart.setDescription(this, description, charset);
/*      */   }
/*      */ 
/*      */   public String[] getContentLanguage()
/*      */     throws MessagingException
/*      */   {
/* 1168 */     return MimeBodyPart.getContentLanguage(this);
/*      */   }
/*      */ 
/*      */   public void setContentLanguage(String[] languages)
/*      */     throws MessagingException
/*      */   {
/* 1184 */     MimeBodyPart.setContentLanguage(this, languages);
/*      */   }
/*      */ 
/*      */   public String getMessageID()
/*      */     throws MessagingException
/*      */   {
/* 1202 */     return getHeader("Message-ID", null);
/*      */   }
/*      */ 
/*      */   public String getFileName()
/*      */     throws MessagingException
/*      */   {
/* 1226 */     return MimeBodyPart.getFileName(this);
/*      */   }
/*      */ 
/*      */   public void setFileName(String filename)
/*      */     throws MessagingException
/*      */   {
/* 1250 */     MimeBodyPart.setFileName(this, filename);
/*      */   }
/*      */ 
/*      */   private String getHeaderName(Message.RecipientType type)
/*      */     throws MessagingException
/*      */   {
/*      */     String headerName;
/* 1257 */     if (type == Message.RecipientType.TO) {
/* 1258 */       headerName = "To";
/*      */     }
/*      */     else
/*      */     {
/*      */       String headerName;
/* 1259 */       if (type == Message.RecipientType.CC) {
/* 1260 */         headerName = "Cc";
/*      */       }
/*      */       else
/*      */       {
/*      */         String headerName;
/* 1261 */         if (type == Message.RecipientType.BCC) {
/* 1262 */           headerName = "Bcc";
/*      */         }
/*      */         else
/*      */         {
/*      */           String headerName;
/* 1263 */           if (type == RecipientType.NEWSGROUPS)
/* 1264 */             headerName = "Newsgroups";
/*      */           else
/* 1266 */             throw new MessagingException("Invalid Recipient Type");
/*      */         }
/*      */       }
/*      */     }
/*      */     String headerName;
/* 1267 */     return headerName;
/*      */   }
/*      */ 
/*      */   public InputStream getInputStream()
/*      */     throws IOException, MessagingException
/*      */   {
/* 1288 */     return getDataHandler().getInputStream();
/*      */   }
/*      */ 
/*      */   protected InputStream getContentStream()
/*      */     throws MessagingException
/*      */   {
/* 1305 */     if (this.contentStream != null)
/* 1306 */       return ((SharedInputStream)this.contentStream).newStream(0L, -1L);
/* 1307 */     if (this.content != null) {
/* 1308 */       return new SharedByteArrayInputStream(this.content);
/*      */     }
/* 1310 */     throw new MessagingException("No content");
/*      */   }
/*      */ 
/*      */   public InputStream getRawInputStream()
/*      */     throws MessagingException
/*      */   {
/* 1329 */     return getContentStream();
/*      */   }
/*      */ 
/*      */   public synchronized DataHandler getDataHandler()
/*      */     throws MessagingException
/*      */   {
/* 1362 */     if (this.dh == null)
/* 1363 */       this.dh = new DataHandler(new MimePartDataSource(this));
/* 1364 */     return this.dh;
/*      */   }
/*      */ 
/*      */   public Object getContent()
/*      */     throws IOException, MessagingException
/*      */   {
/* 1391 */     if (this.cachedContent != null)
/* 1392 */       return this.cachedContent;
/*      */     Object c;
/*      */     try {
/* 1395 */       c = getDataHandler().getContent();
/*      */     } catch (FolderClosedIOException fex) {
/* 1397 */       throw new FolderClosedException(fex.getFolder(), fex.getMessage());
/*      */     } catch (MessageRemovedIOException mex) {
/* 1399 */       throw new MessageRemovedException(mex.getMessage());
/*      */     }
/* 1401 */     if ((MimeBodyPart.cacheMultipart) && (((c instanceof Multipart)) || ((c instanceof Message))) && ((this.content != null) || (this.contentStream != null)))
/*      */     {
/* 1404 */       this.cachedContent = c;
/*      */     }
/* 1406 */     return c;
/*      */   }
/*      */ 
/*      */   public synchronized void setDataHandler(DataHandler dh)
/*      */     throws MessagingException
/*      */   {
/* 1422 */     this.dh = dh;
/* 1423 */     this.cachedContent = null;
/* 1424 */     MimeBodyPart.invalidateContentHeaders(this);
/*      */   }
/*      */ 
/*      */   public void setContent(Object o, String type)
/*      */     throws MessagingException
/*      */   {
/* 1448 */     if ((o instanceof Multipart))
/* 1449 */       setContent((Multipart)o);
/*      */     else
/* 1451 */       setDataHandler(new DataHandler(o, type));
/*      */   }
/*      */ 
/*      */   public void setText(String text)
/*      */     throws MessagingException
/*      */   {
/* 1474 */     setText(text, null);
/*      */   }
/*      */ 
/*      */   public void setText(String text, String charset)
/*      */     throws MessagingException
/*      */   {
/* 1490 */     MimeBodyPart.setText(this, text, charset, "plain");
/*      */   }
/*      */ 
/*      */   public void setText(String text, String charset, String subtype)
/*      */     throws MessagingException
/*      */   {
/* 1508 */     MimeBodyPart.setText(this, text, charset, subtype);
/*      */   }
/*      */ 
/*      */   public void setContent(Multipart mp)
/*      */     throws MessagingException
/*      */   {
/* 1523 */     setDataHandler(new DataHandler(mp, mp.getContentType()));
/* 1524 */     mp.setParent(this);
/*      */   }
/*      */ 
/*      */   public Message reply(boolean replyToAll)
/*      */     throws MessagingException
/*      */   {
/* 1557 */     MimeMessage reply = createMimeMessage(this.session);
/*      */ 
/* 1565 */     String subject = getHeader("Subject", null);
/* 1566 */     if (subject != null) {
/* 1567 */       if (!subject.regionMatches(true, 0, "Re: ", 0, 4))
/* 1568 */         subject = "Re: " + subject;
/* 1569 */       reply.setHeader("Subject", subject);
/*      */     }
/* 1571 */     Address[] a = getReplyTo();
/* 1572 */     reply.setRecipients(Message.RecipientType.TO, a);
/* 1573 */     if (replyToAll) {
/* 1574 */       Vector v = new Vector();
/*      */ 
/* 1576 */       InternetAddress me = InternetAddress.getLocalAddress(this.session);
/* 1577 */       if (me != null) {
/* 1578 */         v.addElement(me);
/*      */       }
/* 1580 */       String alternates = null;
/* 1581 */       if (this.session != null)
/* 1582 */         alternates = this.session.getProperty("mail.alternates");
/* 1583 */       if (alternates != null) {
/* 1584 */         eliminateDuplicates(v, InternetAddress.parse(alternates, false));
/*      */       }
/*      */ 
/* 1587 */       String replyallccStr = null;
/* 1588 */       boolean replyallcc = false;
/* 1589 */       if (this.session != null) {
/* 1590 */         replyallcc = PropUtil.getBooleanSessionProperty(this.session, "mail.replyallcc", false);
/*      */       }
/*      */ 
/* 1593 */       eliminateDuplicates(v, a);
/* 1594 */       a = getRecipients(Message.RecipientType.TO);
/* 1595 */       a = eliminateDuplicates(v, a);
/* 1596 */       if ((a != null) && (a.length > 0)) {
/* 1597 */         if (replyallcc)
/* 1598 */           reply.addRecipients(Message.RecipientType.CC, a);
/*      */         else
/* 1600 */           reply.addRecipients(Message.RecipientType.TO, a);
/*      */       }
/* 1602 */       a = getRecipients(Message.RecipientType.CC);
/* 1603 */       a = eliminateDuplicates(v, a);
/* 1604 */       if ((a != null) && (a.length > 0)) {
/* 1605 */         reply.addRecipients(Message.RecipientType.CC, a);
/*      */       }
/* 1607 */       a = getRecipients(RecipientType.NEWSGROUPS);
/* 1608 */       if ((a != null) && (a.length > 0)) {
/* 1609 */         reply.setRecipients(RecipientType.NEWSGROUPS, a);
/*      */       }
/*      */     }
/* 1612 */     String msgId = getHeader("Message-Id", null);
/* 1613 */     if (msgId != null) {
/* 1614 */       reply.setHeader("In-Reply-To", msgId);
/*      */     }
/*      */ 
/* 1630 */     String refs = getHeader("References", " ");
/* 1631 */     if (refs == null)
/*      */     {
/* 1633 */       refs = getHeader("In-Reply-To", " ");
/*      */     }
/* 1635 */     if (msgId != null) {
/* 1636 */       if (refs != null)
/* 1637 */         refs = MimeUtility.unfold(refs) + " " + msgId;
/*      */       else
/* 1639 */         refs = msgId;
/*      */     }
/* 1641 */     if (refs != null)
/* 1642 */       reply.setHeader("References", MimeUtility.fold(12, refs));
/*      */     try
/*      */     {
/* 1645 */       setFlags(answeredFlag, true);
/*      */     }
/*      */     catch (MessagingException mex) {
/*      */     }
/* 1649 */     return reply;
/*      */   }
/*      */ 
/*      */   private Address[] eliminateDuplicates(Vector v, Address[] addrs)
/*      */   {
/* 1661 */     if (addrs == null)
/* 1662 */       return null;
/* 1663 */     int gone = 0;
/* 1664 */     for (int i = 0; i < addrs.length; i++) {
/* 1665 */       boolean found = false;
/*      */ 
/* 1667 */       for (int j = 0; j < v.size(); j++) {
/* 1668 */         if (((InternetAddress)v.elementAt(j)).equals(addrs[i]))
/*      */         {
/* 1670 */           found = true;
/* 1671 */           gone++;
/* 1672 */           addrs[i] = null;
/* 1673 */           break;
/*      */         }
/*      */       }
/* 1676 */       if (!found) {
/* 1677 */         v.addElement(addrs[i]);
/*      */       }
/*      */     }
/* 1680 */     if (gone != 0)
/*      */     {
/*      */       Address[] a;
/*      */       Address[] a;
/* 1684 */       if ((addrs instanceof InternetAddress[]))
/* 1685 */         a = new InternetAddress[addrs.length - gone];
/*      */       else
/* 1687 */         a = new Address[addrs.length - gone];
/* 1688 */       int i = 0; for (int j = 0; i < addrs.length; i++)
/* 1689 */         if (addrs[i] != null)
/* 1690 */           a[(j++)] = addrs[i];
/* 1691 */       addrs = a;
/*      */     }
/* 1693 */     return addrs;
/*      */   }
/*      */ 
/*      */   public void writeTo(OutputStream os)
/*      */     throws IOException, MessagingException
/*      */   {
/* 1718 */     writeTo(os, null);
/*      */   }
/*      */ 
/*      */   public void writeTo(OutputStream os, String[] ignoreList)
/*      */     throws IOException, MessagingException
/*      */   {
/* 1738 */     if (!this.saved) {
/* 1739 */       saveChanges();
/*      */     }
/* 1741 */     if (this.modified) {
/* 1742 */       MimeBodyPart.writeTo(this, os, ignoreList);
/* 1743 */       return;
/*      */     }
/*      */ 
/* 1748 */     Enumeration hdrLines = getNonMatchingHeaderLines(ignoreList);
/* 1749 */     LineOutputStream los = new LineOutputStream(os);
/* 1750 */     while (hdrLines.hasMoreElements()) {
/* 1751 */       los.writeln((String)hdrLines.nextElement());
/*      */     }
/*      */ 
/* 1754 */     los.writeln();
/*      */ 
/* 1757 */     if (this.content == null)
/*      */     {
/* 1760 */       InputStream is = getContentStream();
/*      */ 
/* 1762 */       byte[] buf = new byte[8192];
/*      */       int len;
/* 1764 */       while ((len = is.read(buf)) > 0)
/* 1765 */         os.write(buf, 0, len);
/* 1766 */       is.close();
/* 1767 */       buf = null;
/*      */     } else {
/* 1769 */       os.write(this.content);
/*      */     }
/* 1771 */     os.flush();
/*      */   }
/*      */ 
/*      */   public String[] getHeader(String name)
/*      */     throws MessagingException
/*      */   {
/* 1789 */     return this.headers.getHeader(name);
/*      */   }
/*      */ 
/*      */   public String getHeader(String name, String delimiter)
/*      */     throws MessagingException
/*      */   {
/* 1806 */     return this.headers.getHeader(name, delimiter);
/*      */   }
/*      */ 
/*      */   public void setHeader(String name, String value)
/*      */     throws MessagingException
/*      */   {
/* 1827 */     this.headers.setHeader(name, value);
/*      */   }
/*      */ 
/*      */   public void addHeader(String name, String value)
/*      */     throws MessagingException
/*      */   {
/* 1847 */     this.headers.addHeader(name, value);
/*      */   }
/*      */ 
/*      */   public void removeHeader(String name)
/*      */     throws MessagingException
/*      */   {
/* 1860 */     this.headers.removeHeader(name);
/*      */   }
/*      */ 
/*      */   public Enumeration getAllHeaders()
/*      */     throws MessagingException
/*      */   {
/* 1879 */     return this.headers.getAllHeaders();
/*      */   }
/*      */ 
/*      */   public Enumeration getMatchingHeaders(String[] names)
/*      */     throws MessagingException
/*      */   {
/* 1891 */     return this.headers.getMatchingHeaders(names);
/*      */   }
/*      */ 
/*      */   public Enumeration getNonMatchingHeaders(String[] names)
/*      */     throws MessagingException
/*      */   {
/* 1903 */     return this.headers.getNonMatchingHeaders(names);
/*      */   }
/*      */ 
/*      */   public void addHeaderLine(String line)
/*      */     throws MessagingException
/*      */   {
/* 1916 */     this.headers.addHeaderLine(line);
/*      */   }
/*      */ 
/*      */   public Enumeration getAllHeaderLines()
/*      */     throws MessagingException
/*      */   {
/* 1927 */     return this.headers.getAllHeaderLines();
/*      */   }
/*      */ 
/*      */   public Enumeration getMatchingHeaderLines(String[] names)
/*      */     throws MessagingException
/*      */   {
/* 1939 */     return this.headers.getMatchingHeaderLines(names);
/*      */   }
/*      */ 
/*      */   public Enumeration getNonMatchingHeaderLines(String[] names)
/*      */     throws MessagingException
/*      */   {
/* 1951 */     return this.headers.getNonMatchingHeaderLines(names);
/*      */   }
/*      */ 
/*      */   public synchronized Flags getFlags()
/*      */     throws MessagingException
/*      */   {
/* 1967 */     return (Flags)this.flags.clone();
/*      */   }
/*      */ 
/*      */   public synchronized boolean isSet(Flags.Flag flag)
/*      */     throws MessagingException
/*      */   {
/* 1990 */     return this.flags.contains(flag);
/*      */   }
/*      */ 
/*      */   public synchronized void setFlags(Flags flag, boolean set)
/*      */     throws MessagingException
/*      */   {
/* 2006 */     if (set)
/* 2007 */       this.flags.add(flag);
/*      */     else
/* 2009 */       this.flags.remove(flag);
/*      */   }
/*      */ 
/*      */   public void saveChanges()
/*      */     throws MessagingException
/*      */   {
/* 2037 */     this.modified = true;
/* 2038 */     this.saved = true;
/* 2039 */     updateHeaders();
/*      */   }
/*      */ 
/*      */   protected void updateMessageID()
/*      */     throws MessagingException
/*      */   {
/* 2050 */     setHeader("Message-ID", "<" + UniqueValue.getUniqueMessageIDValue(this.session) + ">");
/*      */   }
/*      */ 
/*      */   protected void updateHeaders()
/*      */     throws MessagingException
/*      */   {
/* 2071 */     MimeBodyPart.updateHeaders(this);
/* 2072 */     setHeader("MIME-Version", "1.0");
/* 2073 */     updateMessageID();
/*      */ 
/* 2081 */     if (this.cachedContent != null) {
/* 2082 */       this.dh = new DataHandler(this.cachedContent, getContentType());
/* 2083 */       this.cachedContent = null;
/* 2084 */       this.content = null;
/* 2085 */       if (this.contentStream != null)
/*      */         try {
/* 2087 */           this.contentStream.close();
/*      */         } catch (IOException ioex) {
/*      */         }
/* 2090 */       this.contentStream = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected InternetHeaders createInternetHeaders(InputStream is)
/*      */     throws MessagingException
/*      */   {
/* 2107 */     return new InternetHeaders(is);
/*      */   }
/*      */ 
/*      */   protected MimeMessage createMimeMessage(Session session)
/*      */     throws MessagingException
/*      */   {
/* 2123 */     return new MimeMessage(session);
/*      */   }
/*      */ 
/*      */   public static class RecipientType extends Message.RecipientType
/*      */   {
/*      */     private static final long serialVersionUID = -5468290701714395543L;
/*  475 */     public static final RecipientType NEWSGROUPS = new RecipientType("Newsgroups");
/*      */ 
/*      */     protected RecipientType(String type) {
/*  478 */       super();
/*      */     }
/*      */ 
/*      */     protected Object readResolve() throws ObjectStreamException {
/*  482 */       if (this.type.equals("Newsgroups")) {
/*  483 */         return NEWSGROUPS;
/*      */       }
/*  485 */       return super.readResolve();
/*      */     }
/*      */   }
/*      */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.internet.MimeMessage
 * JD-Core Version:    0.6.1
 */