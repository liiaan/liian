/*     */ package javax.mail.internet;
/*     */ 
/*     */ public class ContentType
/*     */ {
/*     */   private String primaryType;
/*     */   private String subType;
/*     */   private ParameterList list;
/*     */ 
/*     */   public ContentType()
/*     */   {
/*     */   }
/*     */ 
/*     */   public ContentType(String primaryType, String subType, ParameterList list)
/*     */   {
/*  71 */     this.primaryType = primaryType;
/*  72 */     this.subType = subType;
/*  73 */     this.list = list;
/*     */   }
/*     */ 
/*     */   public ContentType(String s)
/*     */     throws ParseException
/*     */   {
/*  85 */     HeaderTokenizer h = new HeaderTokenizer(s, "()<>@,;:\\\"\t []/?=");
/*     */ 
/*  89 */     HeaderTokenizer.Token tk = h.next();
/*  90 */     if (tk.getType() != -1) {
/*  91 */       throw new ParseException("Expected MIME type, got " + tk.getValue());
/*     */     }
/*  93 */     this.primaryType = tk.getValue();
/*     */ 
/*  96 */     tk = h.next();
/*  97 */     if ((char)tk.getType() != '/') {
/*  98 */       throw new ParseException("Expected '/', got " + tk.getValue());
/*     */     }
/*     */ 
/* 101 */     tk = h.next();
/* 102 */     if (tk.getType() != -1) {
/* 103 */       throw new ParseException("Expected MIME subtype, got " + tk.getValue());
/*     */     }
/* 105 */     this.subType = tk.getValue();
/*     */ 
/* 108 */     String rem = h.getRemainder();
/* 109 */     if (rem != null)
/* 110 */       this.list = new ParameterList(rem);
/*     */   }
/*     */ 
/*     */   public String getPrimaryType()
/*     */   {
/* 118 */     return this.primaryType;
/*     */   }
/*     */ 
/*     */   public String getSubType()
/*     */   {
/* 126 */     return this.subType;
/*     */   }
/*     */ 
/*     */   public String getBaseType()
/*     */   {
/* 137 */     return this.primaryType + '/' + this.subType;
/*     */   }
/*     */ 
/*     */   public String getParameter(String name)
/*     */   {
/* 146 */     if (this.list == null) {
/* 147 */       return null;
/*     */     }
/* 149 */     return this.list.get(name);
/*     */   }
/*     */ 
/*     */   public ParameterList getParameterList()
/*     */   {
/* 159 */     return this.list;
/*     */   }
/*     */ 
/*     */   public void setPrimaryType(String primaryType)
/*     */   {
/* 167 */     this.primaryType = primaryType;
/*     */   }
/*     */ 
/*     */   public void setSubType(String subType)
/*     */   {
/* 175 */     this.subType = subType;
/*     */   }
/*     */ 
/*     */   public void setParameter(String name, String value)
/*     */   {
/* 186 */     if (this.list == null) {
/* 187 */       this.list = new ParameterList();
/*     */     }
/* 189 */     this.list.set(name, value);
/*     */   }
/*     */ 
/*     */   public void setParameterList(ParameterList list)
/*     */   {
/* 197 */     this.list = list;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 208 */     if ((this.primaryType == null) || (this.subType == null)) {
/* 209 */       return null;
/*     */     }
/* 211 */     StringBuffer sb = new StringBuffer();
/* 212 */     sb.append(this.primaryType).append('/').append(this.subType);
/* 213 */     if (this.list != null)
/*     */     {
/* 217 */       sb.append(this.list.toString(sb.length() + 14));
/*     */     }
/* 219 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public boolean match(ContentType cType)
/*     */   {
/* 242 */     if (!this.primaryType.equalsIgnoreCase(cType.getPrimaryType())) {
/* 243 */       return false;
/*     */     }
/* 245 */     String sType = cType.getSubType();
/*     */ 
/* 248 */     if ((this.subType.charAt(0) == '*') || (sType.charAt(0) == '*')) {
/* 249 */       return true;
/*     */     }
/*     */ 
/* 252 */     if (!this.subType.equalsIgnoreCase(sType)) {
/* 253 */       return false;
/*     */     }
/* 255 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean match(String s)
/*     */   {
/*     */     try
/*     */     {
/* 276 */       return match(new ContentType(s)); } catch (ParseException pex) {
/*     */     }
/* 278 */     return false;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.internet.ContentType
 * JD-Core Version:    0.6.1
 */