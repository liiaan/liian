/*     */ package javax.mail.internet;
/*     */ 
/*     */ public class AddressException extends ParseException
/*     */ {
/*  52 */   protected String ref = null;
/*     */ 
/*  59 */   protected int pos = -1;
/*     */   private static final long serialVersionUID = 9134583443539323120L;
/*     */ 
/*     */   public AddressException()
/*     */   {
/*     */   }
/*     */ 
/*     */   public AddressException(String s)
/*     */   {
/*  75 */     super(s);
/*     */   }
/*     */ 
/*     */   public AddressException(String s, String ref)
/*     */   {
/*  86 */     super(s);
/*  87 */     this.ref = ref;
/*     */   }
/*     */ 
/*     */   public AddressException(String s, String ref, int pos)
/*     */   {
/*  96 */     super(s);
/*  97 */     this.ref = ref;
/*  98 */     this.pos = pos;
/*     */   }
/*     */ 
/*     */   public String getRef()
/*     */   {
/* 106 */     return this.ref;
/*     */   }
/*     */ 
/*     */   public int getPos()
/*     */   {
/* 114 */     return this.pos;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 118 */     String s = super.toString();
/* 119 */     if (this.ref == null)
/* 120 */       return s;
/* 121 */     s = s + " in string ``" + this.ref + "''";
/* 122 */     if (this.pos < 0)
/* 123 */       return s;
/* 124 */     return s + " at position " + this.pos;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.internet.AddressException
 * JD-Core Version:    0.6.1
 */