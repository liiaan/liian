/*     */ package javax.mail.internet;
/*     */ 
/*     */ import com.sun.mail.util.PropUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.UnknownServiceException;
/*     */ import javax.activation.DataSource;
/*     */ import javax.mail.MessageAware;
/*     */ import javax.mail.MessageContext;
/*     */ import javax.mail.MessagingException;
/*     */ 
/*     */ public class MimePartDataSource
/*     */   implements DataSource, MessageAware
/*     */ {
/*     */   protected MimePart part;
/*     */   private MessageContext context;
/*  64 */   private static boolean ignoreMultipartEncoding = PropUtil.getBooleanSystemProperty("mail.mime.ignoremultipartencoding", true);
/*     */ 
/*     */   public MimePartDataSource(MimePart part)
/*     */   {
/*  72 */     this.part = part;
/*     */   }
/*     */ 
/*     */   public InputStream getInputStream()
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/*     */       InputStream is;
/*  95 */       if ((this.part instanceof MimeBodyPart)) {
/*  96 */         is = ((MimeBodyPart)this.part).getContentStream();
/*     */       }
/*     */       else
/*     */       {
/*     */         InputStream is;
/*  97 */         if ((this.part instanceof MimeMessage))
/*  98 */           is = ((MimeMessage)this.part).getContentStream();
/*     */         else
/* 100 */           throw new MessagingException("Unknown part");
/*     */       }
/*     */       InputStream is;
/* 102 */       String encoding = restrictEncoding(this.part.getEncoding(), this.part);
/* 103 */       if (encoding != null) {
/* 104 */         return MimeUtility.decode(is, encoding);
/*     */       }
/* 106 */       return is;
/*     */     } catch (MessagingException mex) {
/* 108 */       throw new IOException(mex.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   private static String restrictEncoding(String encoding, MimePart part)
/*     */     throws MessagingException
/*     */   {
/* 119 */     if ((!ignoreMultipartEncoding) || (encoding == null)) {
/* 120 */       return encoding;
/*     */     }
/* 122 */     if ((encoding.equalsIgnoreCase("7bit")) || (encoding.equalsIgnoreCase("8bit")) || (encoding.equalsIgnoreCase("binary")))
/*     */     {
/* 125 */       return encoding;
/*     */     }
/* 127 */     String type = part.getContentType();
/* 128 */     if (type == null) {
/* 129 */       return encoding;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 137 */       ContentType cType = new ContentType(type);
/* 138 */       if ((cType.match("multipart/*")) || (cType.match("message/*")))
/* 139 */         return null;
/*     */     }
/*     */     catch (ParseException pex) {
/*     */     }
/* 143 */     return encoding;
/*     */   }
/*     */ 
/*     */   public OutputStream getOutputStream()
/*     */     throws IOException
/*     */   {
/* 153 */     throw new UnknownServiceException("Writing not supported");
/*     */   }
/*     */ 
/*     */   public String getContentType()
/*     */   {
/*     */     try
/*     */     {
/* 164 */       return this.part.getContentType();
/*     */     }
/*     */     catch (MessagingException mex)
/*     */     {
/*     */     }
/*     */ 
/* 170 */     return "application/octet-stream";
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*     */     try
/*     */     {
/* 181 */       if ((this.part instanceof MimeBodyPart))
/* 182 */         return ((MimeBodyPart)this.part).getFileName();
/*     */     }
/*     */     catch (MessagingException mex) {
/*     */     }
/* 186 */     return "";
/*     */   }
/*     */ 
/*     */   public synchronized MessageContext getMessageContext()
/*     */   {
/* 194 */     if (this.context == null)
/* 195 */       this.context = new MessageContext(this.part);
/* 196 */     return this.context;
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.internet.MimePartDataSource
 * JD-Core Version:    0.6.1
 */