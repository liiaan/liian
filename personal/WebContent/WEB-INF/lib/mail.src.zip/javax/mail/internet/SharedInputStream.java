package javax.mail.internet;

import java.io.InputStream;

public abstract interface SharedInputStream
{
  public abstract long getPosition();

  public abstract InputStream newStream(long paramLong1, long paramLong2);
}

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.internet.SharedInputStream
 * JD-Core Version:    0.6.1
 */