/*    */ package javax.mail.internet;
/*    */ 
/*    */ import javax.mail.MessagingException;
/*    */ 
/*    */ public class ParseException extends MessagingException
/*    */ {
/*    */   private static final long serialVersionUID = 7649991205183658089L;
/*    */ 
/*    */   public ParseException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ParseException(String s)
/*    */   {
/* 64 */     super(s);
/*    */   }
/*    */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.internet.ParseException
 * JD-Core Version:    0.6.1
 */