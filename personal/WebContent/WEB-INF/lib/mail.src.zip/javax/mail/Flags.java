/*     */ package javax.mail;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Locale;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class Flags
/*     */   implements Cloneable, Serializable
/*     */ {
/*  98 */   private int system_flags = 0;
/*  99 */   private Hashtable user_flags = null;
/*     */   private static final int ANSWERED_BIT = 1;
/*     */   private static final int DELETED_BIT = 2;
/*     */   private static final int DRAFT_BIT = 4;
/*     */   private static final int FLAGGED_BIT = 8;
/*     */   private static final int RECENT_BIT = 16;
/*     */   private static final int SEEN_BIT = 32;
/*     */   private static final int USER_BIT = -2147483648;
/*     */   private static final long serialVersionUID = 6243590407214169028L;
/*     */ 
/*     */   public Flags()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Flags(Flags flags)
/*     */   {
/* 191 */     this.system_flags = flags.system_flags;
/* 192 */     if (flags.user_flags != null)
/* 193 */       this.user_flags = ((Hashtable)flags.user_flags.clone());
/*     */   }
/*     */ 
/*     */   public Flags(Flag flag)
/*     */   {
/* 202 */     this.system_flags |= flag.bit;
/*     */   }
/*     */ 
/*     */   public Flags(String flag)
/*     */   {
/* 211 */     this.user_flags = new Hashtable(1);
/* 212 */     this.user_flags.put(flag.toLowerCase(Locale.ENGLISH), flag);
/*     */   }
/*     */ 
/*     */   public void add(Flag flag)
/*     */   {
/* 221 */     this.system_flags |= flag.bit;
/*     */   }
/*     */ 
/*     */   public void add(String flag)
/*     */   {
/* 230 */     if (this.user_flags == null)
/* 231 */       this.user_flags = new Hashtable(1);
/* 232 */     this.user_flags.put(flag.toLowerCase(Locale.ENGLISH), flag);
/*     */   }
/*     */ 
/*     */   public void add(Flags f)
/*     */   {
/* 242 */     this.system_flags |= f.system_flags;
/*     */ 
/* 244 */     if (f.user_flags != null) {
/* 245 */       if (this.user_flags == null) {
/* 246 */         this.user_flags = new Hashtable(1);
/*     */       }
/* 248 */       Enumeration e = f.user_flags.keys();
/*     */ 
/* 250 */       while (e.hasMoreElements()) {
/* 251 */         String s = (String)e.nextElement();
/* 252 */         this.user_flags.put(s, f.user_flags.get(s));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void remove(Flag flag)
/*     */   {
/* 263 */     this.system_flags &= (flag.bit ^ 0xFFFFFFFF);
/*     */   }
/*     */ 
/*     */   public void remove(String flag)
/*     */   {
/* 272 */     if (this.user_flags != null)
/* 273 */       this.user_flags.remove(flag.toLowerCase(Locale.ENGLISH));
/*     */   }
/*     */ 
/*     */   public void remove(Flags f)
/*     */   {
/* 283 */     this.system_flags &= (f.system_flags ^ 0xFFFFFFFF);
/*     */ 
/* 285 */     if (f.user_flags != null) {
/* 286 */       if (this.user_flags == null) {
/* 287 */         return;
/*     */       }
/* 289 */       Enumeration e = f.user_flags.keys();
/* 290 */       while (e.hasMoreElements())
/* 291 */         this.user_flags.remove(e.nextElement());
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean contains(Flag flag)
/*     */   {
/* 301 */     return (this.system_flags & flag.bit) != 0;
/*     */   }
/*     */ 
/*     */   public boolean contains(String flag)
/*     */   {
/* 310 */     if (this.user_flags == null) {
/* 311 */       return false;
/*     */     }
/* 313 */     return this.user_flags.containsKey(flag.toLowerCase(Locale.ENGLISH));
/*     */   }
/*     */ 
/*     */   public boolean contains(Flags f)
/*     */   {
/* 325 */     if ((f.system_flags & this.system_flags) != f.system_flags) {
/* 326 */       return false;
/*     */     }
/*     */ 
/* 329 */     if (f.user_flags != null) {
/* 330 */       if (this.user_flags == null)
/* 331 */         return false;
/* 332 */       Enumeration e = f.user_flags.keys();
/*     */ 
/* 334 */       while (e.hasMoreElements()) {
/* 335 */         if (!this.user_flags.containsKey(e.nextElement())) {
/* 336 */           return false;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 341 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 350 */     if (!(obj instanceof Flags)) {
/* 351 */       return false;
/*     */     }
/* 353 */     Flags f = (Flags)obj;
/*     */ 
/* 356 */     if (f.system_flags != this.system_flags) {
/* 357 */       return false;
/*     */     }
/*     */ 
/* 360 */     if ((f.user_flags == null) && (this.user_flags == null))
/* 361 */       return true;
/* 362 */     if ((f.user_flags != null) && (this.user_flags != null) && (f.user_flags.size() == this.user_flags.size()))
/*     */     {
/* 364 */       Enumeration e = f.user_flags.keys();
/*     */ 
/* 366 */       while (e.hasMoreElements()) {
/* 367 */         if (!this.user_flags.containsKey(e.nextElement()))
/* 368 */           return false;
/*     */       }
/* 370 */       return true;
/*     */     }
/*     */ 
/* 373 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 382 */     int hash = this.system_flags;
/* 383 */     if (this.user_flags != null) {
/* 384 */       Enumeration e = this.user_flags.keys();
/* 385 */       while (e.hasMoreElements())
/* 386 */         hash += ((String)e.nextElement()).hashCode();
/*     */     }
/* 388 */     return hash;
/*     */   }
/*     */ 
/*     */   public Flag[] getSystemFlags()
/*     */   {
/* 398 */     Vector v = new Vector();
/* 399 */     if ((this.system_flags & 0x1) != 0)
/* 400 */       v.addElement(Flag.ANSWERED);
/* 401 */     if ((this.system_flags & 0x2) != 0)
/* 402 */       v.addElement(Flag.DELETED);
/* 403 */     if ((this.system_flags & 0x4) != 0)
/* 404 */       v.addElement(Flag.DRAFT);
/* 405 */     if ((this.system_flags & 0x8) != 0)
/* 406 */       v.addElement(Flag.FLAGGED);
/* 407 */     if ((this.system_flags & 0x10) != 0)
/* 408 */       v.addElement(Flag.RECENT);
/* 409 */     if ((this.system_flags & 0x20) != 0)
/* 410 */       v.addElement(Flag.SEEN);
/* 411 */     if ((this.system_flags & 0x80000000) != 0) {
/* 412 */       v.addElement(Flag.USER);
/*     */     }
/* 414 */     Flag[] f = new Flag[v.size()];
/* 415 */     v.copyInto(f);
/* 416 */     return f;
/*     */   }
/*     */ 
/*     */   public String[] getUserFlags()
/*     */   {
/* 426 */     Vector v = new Vector();
/* 427 */     if (this.user_flags != null) {
/* 428 */       Enumeration e = this.user_flags.elements();
/*     */ 
/* 430 */       while (e.hasMoreElements()) {
/* 431 */         v.addElement(e.nextElement());
/*     */       }
/*     */     }
/* 434 */     String[] f = new String[v.size()];
/* 435 */     v.copyInto(f);
/* 436 */     return f;
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 443 */     Flags f = null;
/*     */     try {
/* 445 */       f = (Flags)super.clone();
/*     */     }
/*     */     catch (CloneNotSupportedException cex) {
/*     */     }
/* 449 */     if ((this.user_flags != null) && (f != null))
/* 450 */       f.user_flags = ((Hashtable)this.user_flags.clone());
/* 451 */     return f;
/*     */   }
/*     */ 
/*     */   public static final class Flag
/*     */   {
/* 120 */     public static final Flag ANSWERED = new Flag(1);
/*     */ 
/* 127 */     public static final Flag DELETED = new Flag(2);
/*     */ 
/* 133 */     public static final Flag DRAFT = new Flag(4);
/*     */ 
/* 139 */     public static final Flag FLAGGED = new Flag(8);
/*     */ 
/* 148 */     public static final Flag RECENT = new Flag(16);
/*     */ 
/* 159 */     public static final Flag SEEN = new Flag(32);
/*     */ 
/* 170 */     public static final Flag USER = new Flag(-2147483648);
/*     */     private int bit;
/*     */ 
/*     */     private Flag(int bit)
/*     */     {
/* 175 */       this.bit = bit;
/*     */     }
/*     */   }
/*     */ }

/* Location:           E:\workspace\finawinWeb\WebContent\WEB-INF\lib\mail.jar
 * Qualified Name:     javax.mail.Flags
 * JD-Core Version:    0.6.1
 */